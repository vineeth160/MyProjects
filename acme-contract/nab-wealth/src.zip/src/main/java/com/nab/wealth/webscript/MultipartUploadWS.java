package com.nab.wealth.webscript;

import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Iterator;

import com.nab.wealth.model.NABWContentModel;
import org.alfresco.service.namespace.QName;
import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.DuplicateChildNodeNameException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.NamespacePrefixResolver;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.error.AlfrescoRuntimeException;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.util.ISO9075;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;

import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.servlet.FormData;
import org.springframework.extensions.webscripts.servlet.FormData.FormField;

import com.nab.wealth.model.NABWContentModel.FinancialStatement;
import com.nab.wealth.model.NABWContentModel.ProductConfirmation;


public class MultipartUploadWS extends DeclarativeWebScript {

	private ServiceRegistry serviceRegistry;
	private final String UPLOAD_DESTINATION = "workspace://SpacesStore/4d5d684c-da4f-4009-a264-849b5a0fb5dc";
     
	
	Map<String, Object> model = new HashMap<String, Object>(5);
	String siteName = null;

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest request, Status status, Cache cache) {

			
		List<FormField> fieldList = new ArrayList<FormField>();
		Map<QName, Serializable> props = new HashMap<>();
		NodeRef docNodeRef = null;
		//String folderName = null;
		String metadata = null;
		String docType = null;

		try {
			
			if (request.getContentType().equalsIgnoreCase("multipart/form-data")) {
				FormData formData = (FormData) request.parseContent();
				FormData.FormField[] fields = formData.getFields();
				for (FormData.FormField field : fields) {
					switch (field.getName()) {
					case "fileData":
						if (field.getIsFile()) {
							fieldList.add(field);
						} else {
							model.put("code", "400");
							model.put("message", "file is null/empty in the request");
						}
						break;
					
					  case "docType": 
						 
					  docType=field.getValue().replaceAll(".+:","");
					  System.out.println("doctype filedlst::"+docType); 
					  
					  
					 if(StringUtils.isEmpty(field.getFilename())) {
					  
					  model.put("code", "400"); model.put("message",
					  "metadata is null/empty in the request"); } break;
					 
					 
						
					case "metaData":
						
						metadata=field.getValue();						
						System.out.println("metadata filedlst::"+metadata);
						
						
						if(StringUtils.isEmpty(metadata)) {
						    System.out.println();
							model.put("code", "400");
							model.put("message", "metadata is null/empty in the request");
						}
						break;
						
						
						/*
						 * case "folderName": if (!StringUtils.isEmpty(field.getName())) { folderName =
						 * field.getValue(); } else { model.put("code", "400"); model.put("message",
						 * "folderName is null/empty in the request"); } break;
						 */
					}

				}

			    //NodeRef descFolderNodeRef = getPathNodeRef(folderName);
				//NodeRef descFolderNodeRef = getCompanyHome();
				 NodeRef descFolderNodeRef = new NodeRef(UPLOAD_DESTINATION);

				for (FormField field : fieldList) {
					
					//////
					List<HashMap<String,String>> response=new ArrayList<>();
					JSONArray jsonarray=null;
					try {
						jsonarray=new JSONArray(metadata);
						for(int i=0;i<jsonarray.length();i++) {
							JSONObject jsonObject= jsonarray.getJSONObject(i);
							Iterator<?>iterator=jsonObject.keys();
							HashMap<String,String>map=new HashMap<>();
							while (iterator.hasNext()) {
								
								Object key =iterator.hasNext();
								Object value= jsonObject.get(key.toString());
								map.put(key.toString(),value.toString());
							}
							response.add(map);
						}
					}catch(JSONException e) {
						
						e.printStackTrace();
							
							
						}
					
					
					
					
					
					
					//////
										
					JSONObject propValues = new JSONObject(metadata);	
					/*
					 * Iterator<?>iterator=propValues.keys(); HashMap<String,String>map=new
					 * HashMap<>(); while (iterator.hasNext()) { Object key =iterator.next();
					 */
					System.out.println("JSON_metadata propValues::"+propValues);
					
					
					props.put(ContentModel.PROP_NAME, field.getFilename());		
					if(docType.equals("financialStatement")) {
					//FinancialStatement metadata
						//props.put(FinancialStatement.Prop.FINANCIALSTATEMENT_NAME,propValues.getString(key.toString()));	
					//props.put(QName.resolveToQName(NamespacePrefixResolver.getNamespaceURI("nabw"),map.get(key)),propValues.get(key.toString()));	
                    props.put(FinancialStatement.Prop.FINANCIALSTATEMENT_NAME,propValues.getString("nabw:name"));
                    props.put(FinancialStatement.Prop.FINANCIALSTATEMENT_DOB,propValues.getString("nabw:dateOfBirth"));
                    props.put(FinancialStatement.Prop.FINANCIALSTATEMENT_RDCTABN,propValues.getString("nabw:rdctAbn"));
                    props.put(FinancialStatement.Prop.FINANCIALSTATEMENT_FUNDNAME,propValues.getString("nabw:fundName"));
                    props.put(FinancialStatement.Prop.FINANCIALSTATEMENT_TRUSTNAME,propValues.getString("nabw:trustName"));
                    
                    System.out.println("FinancialStatement_props???"+props);
					}
					else if(docType.equals("productConfirmation")) {
                    //ProductConfirmation metadata	
                    props.put(ProductConfirmation.Prop.PRODUCTCONFIRMATION_NAME,propValues.getString("nabw:investorAccountName"));
                    props.put(ProductConfirmation.Prop.PRODUCTCONFIRMATION_EMAIL,propValues.getString("nabw:email"));
                    props.put(ProductConfirmation.Prop.PRODUCTCONFIRMATION_SERVICE,propValues.getString("nabw:superServiceUSI"));
                    props.put(ProductConfirmation.Prop.PRODUCTCONFIRMATION_ACCOUNTTYPE,propValues.getString("nabw:accountType"));
                    props.put(ProductConfirmation.Prop.PRODUCTCONFIRMATION_TAXFILENO,propValues.getString("nabw:taxFileNumber"));
                    props.put(ProductConfirmation.Prop.PRODUCTCONFIRMATION_DATE,propValues.getString("nabw:dateOfSubmission"));
                    props.put(ProductConfirmation.Prop.PRODUCTCONFIRMATION_ACCNUMBER,propValues.getString("nabw:investorAccountNumber"));                   
                    props.put(ProductConfirmation.Prop.PRODUCTCONFIRMATION_TXNTYPE,propValues.getString("nabw:transactionType"));
                    props.put(ProductConfirmation.Prop.PRODUCTCONFIRMATION_VALUE,propValues.getString("nabw:totalPortfolioValue"));
                    props.put(ProductConfirmation.Prop.PRODUCTCONFIRMATION_ADVISORNAME,propValues.getString("nabw:advisorName"));
                    props.put(ProductConfirmation.Prop.PRODUCTCONFIRMATION_USI,propValues.getString("nabw:pensionServiceUSI"));
                    props.put(ProductConfirmation.Prop.PRODUCTCONFIRMATION_TXNRECEIPTNO,propValues.getString("nabw:transactionReceiptNumber"));
                    props.put(ProductConfirmation.Prop.PRODUCTCONFIRMATION_INVESTORADDRESS,propValues.getString("nabw:investorAddress"));
                    props.put(ProductConfirmation.Prop.PRODUCTCONFIRMATION_INVESTORNO,propValues.getString("nabw:investorNumber"));
				    System.out.println("ProductConfirmation_props???"+props);
					}
					else {
						System.out.println("no docType found???");
					}
					
				/*
					 * docNodeRef = serviceRegistry.getNodeService() .createNode(descFolderNodeRef,
					 * ContentModel.ASSOC_CONTAINS,
					 * QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI,
					 * field.getFilename()), FinancialStatement.QNAME, props) .getChildRef();
					 */
					 docNodeRef = serviceRegistry.getNodeService() .createNode(descFolderNodeRef,
					 ContentModel.ASSOC_CONTAINS,
					 QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI,
					 field.getFilename()), NABWContentModel.nabw(docType), props) .getChildRef();
						 
                    
					boolean successFlag = writeContentStreamToCustomDocument(field.getInputStream(), docNodeRef,
							field.getMimetype());

					
					if (successFlag) {
						model.put("code", "200");
						model.put("message", "Metadata Updated Successfully");
					} else {
						model.put("code", "400");
						model.put("message", "Metadata Updated is Failed ");
					}
					/*}
					
				
			
				}*/
			//}

				}
			}
		}
				catch (DuplicateChildNodeNameException e) {
			model.put("code", "400");
			model.put("message", "DuplicateChildNodeNameException Occured " + e);
		} catch (Exception e) {
			model.put("code", "400");
			model.put("message", e);
			model.put("message", e.getMessage());
		}

		return model;
	}

	private NodeRef getPathNodeRef(String foldername) {

		String alfrescoFolderName = ISO9075.encode(foldername);
		Map<String, Serializable> params = new HashMap<>();
		/*
		 * params.put("query", "./app:company_home/st:sites/cm:" + siteName +
		 * "/cm:documentLibrary/cm:" + alfrescoFolderName);
		 */

		  params.put("query", "./app:company_home/cm:" + alfrescoFolderName);
		 
		return serviceRegistry.getNodeLocatorService().getNode("xpath", null, params);

	}
	

    //If you want to test with CompanyHome first use this method instead of the NodeRef
    @SuppressWarnings("unused")
    private NodeRef getCompanyHome() {
        StoreRef storeRef = new StoreRef(StoreRef.PROTOCOL_WORKSPACE, "SpacesStore");
        serviceRegistry.getSearchService();
        ResultSet rs = serviceRegistry.getSearchService().query(storeRef, SearchService.LANGUAGE_XPATH, "/app:company_home");
        NodeRef descFolderNodeRef = null;
        try {
            if (rs.length() == 0) {
                throw new AlfrescoRuntimeException("Didn't find Company Home");
            }
            descFolderNodeRef = rs.getNodeRef(0);
        } finally {
            rs.close();
        }
        return descFolderNodeRef;
    }

	public boolean writeContentStreamToCustomDocument(InputStream contentInputStream, NodeRef docNodeRef,
			String mimeType) {
		boolean successFlag = false;
		try {
			ContentWriter writer = serviceRegistry.getContentService().getWriter(docNodeRef, ContentModel.PROP_CONTENT,
					true);
			writer.setMimetype(mimeType);
			writer.putContent(contentInputStream);
			successFlag = true;
		} catch (Exception e) {
			model.put("code", "400");
			model.put("message", "Exception Occurred " + e);
			model.put("message", "Exception Occurred " + e.getMessage());
		}
		return successFlag;
	}
	
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
}
	
	