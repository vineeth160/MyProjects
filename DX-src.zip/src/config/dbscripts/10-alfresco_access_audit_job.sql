begin
  DBMS_SCHEDULER.create_job (
    job_name        => 'alfresco_access_audit_job',
    job_type        => 'PLSQL_BLOCK',
    job_action      => 'BEGIN alfresco_access_proc(1);END;',
    start_date      => sysdate,
    enabled         => TRUE,
    repeat_interval => 'freq=daily; byhour=5,23; byminute=50; bysecond=0');
end;
/