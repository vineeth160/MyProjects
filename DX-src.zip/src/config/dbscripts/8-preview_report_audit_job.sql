begin
  DBMS_SCHEDULER.create_job (
    job_name        => 'preview_report_audit_job',
    job_type        => 'PLSQL_BLOCK',
    job_action      => 'BEGIN preview_report_proc(1);END;',
    start_date      => sysdate,
    enabled         => TRUE,
    repeat_interval => 'freq=daily; byhour=4,22; byminute=30; bysecond=0');
end;
/