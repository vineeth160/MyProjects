begin
  DBMS_SCHEDULER.create_job (
    job_name        => 'download_report_audit_job',
    job_type        => 'PLSQL_BLOCK',
    job_action      => 'BEGIN download_report_proc(1);END;',
    start_date      => sysdate,
    enabled         => TRUE,
    repeat_interval => 'freq=daily; byhour=5,23; byminute=0; bysecond=0');
end;
/