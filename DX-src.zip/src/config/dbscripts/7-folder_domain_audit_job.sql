begin
  DBMS_SCHEDULER.create_job (
    job_name        => 'folder_domain_audit_job',
    job_type        => 'PLSQL_BLOCK',
    job_action      => 'BEGIN folder_domain_proc(1);END;',
    start_date      => sysdate,
    enabled         => TRUE,
    repeat_interval => 'freq=daily; byhour=4,22; byminute=0; bysecond=0');
end;
/