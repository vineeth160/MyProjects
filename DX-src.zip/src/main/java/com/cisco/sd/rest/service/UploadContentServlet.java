package com.cisco.sd.rest.service;

import static com.cisco.sd.rest.service.MigrationConstants.FILE_EXCEPTION;
import static com.cisco.sd.rest.service.MigrationConstants.FOLDER_PATH;
import static com.cisco.sd.rest.service.MigrationConstants.NULL_EXCEPTION;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_FIELD;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_FILE_NAME;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_FILE_NODE_REF;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_FOLDER_NODE_REF;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_ROOT_PATH_NODE_REF;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_STATUS_MSG;
import static com.cisco.sd.rest.service.MigrationConstants.ROOT_PATH;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.alfresco.model.ContentModel;
import org.alfresco.query.PagingRequest;
import org.alfresco.query.PagingResults;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.transaction.RetryingTransactionHelper.RetryingTransactionCallback;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.CopyService.CopyInfo;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.servlet.FormData;
import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.edcsng.util.EDCSUtil;

/**
 * 
 * @author gpotla, nathammi
 * 
 */
public class UploadContentServlet extends DeclarativeWebScript {

	private static final Logger LOG = Logger.getLogger(UploadContentServlet.class);

	private ServiceRegistry serviceRegistry;
	protected NodeService nodeService;
	private FileMetaDataServieImpl fileMetaDataService;
	private FolderServiceImpl folderService;
	private BehaviourFilter policyFilter;

	public FileMetaDataServieImpl getFileMetaDataService() {
		return fileMetaDataService;
	}

	public void setFileMetaDataService(
			FileMetaDataServieImpl fileMetaDataService) {
		this.fileMetaDataService = fileMetaDataService;
	}

	public FolderServiceImpl getFolderService() {
		return folderService;
	}

	public void setFolderService(FolderServiceImpl folderService) {
		this.folderService = folderService;
	}

	// for Spring injection
	public void setServiceRegistry(ServiceRegistry registry) {
		this.serviceRegistry = registry;
	}

	
	public void setPolicyFilter(BehaviourFilter policyFilter) {
		this.policyFilter = policyFilter;
	}

	/**
     * 
     */
	private void loadConfig() {
		LOG.info("In UploadContentServlet.loadConfig() ");
		this.nodeService = this.serviceRegistry.getNodeService();
	}

	/**
     * 
     */
	public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status,	final Cache cache) {
		LOG.info("Custom UploadContentServlet.executeImpl() Start ");
		// -------------------------------//
		//subject = "Document published";
		// --------------------------------//
		loadConfig();

		Map<String, Object> result = new HashMap<String, Object>();

		String rootPath = req.getParameter(ROOT_PATH);
		String folderPath = req.getParameter(FOLDER_PATH);
		String publisher = req.getParameter(MigrationConstants.PARAM_PUBLISHER);
		String externalUsers = req.getParameter("finalUsers");
		LOG.info("rootPath : " + rootPath + " ;folderPath : " + folderPath + " ;publisher : " + publisher + " Final Users : " + externalUsers);
		
		FormData formData = (FormData) req.parseContent();

		NodeRef existingNodeRef = null;
		try {
			NodeRef rootPathRef = EDCSUtil.doSearch(rootPath + "\"", serviceRegistry);
			LOG.info("rootPathRef : " + rootPathRef);
			if (rootPathRef != null) {
				
				/**
				 * Step 1: Adding users to repository
				 */
				/*if(finalUsers != null && !finalUsers.isEmpty()){
					folderService.addExternalUsers(finalUsers);
				}*/
				
				/**
				 * Step 1: Folder path creation
				 */
				// Performing folder related activities
				result = folderService.constructFolderPath(rootPath, folderPath, req, externalUsers);

				existingNodeRef = (NodeRef) result.get("uploadFolderNodeRef");

				LOG.info(" Existing Folder NodeRef from FolderserviceImpl is ::: " + existingNodeRef);

				result.put(PARAM_ROOT_PATH_NODE_REF, (rootPathRef == null) ? "Root Path not exist."	: rootPathRef.toString());
				result.put(PARAM_FILE_NODE_REF,	(existingNodeRef == null) ? "Fodler not exist."	: existingNodeRef.toString());
				result.put(PARAM_FILE_NAME, "File import is in progress.");

				/**
				 * Step 2: Content Creation or Updation
				 */
				FormData.FormField[] fields = formData.getFields();
				for (FormData.FormField field : fields) {
					if (field.getName().equals(PARAM_FIELD) && field.getIsFile()) {
						result = fileMetaDataService.writeContent(field, existingNodeRef, req);
					}
				}

				String nodeRef = (String) result.get(PARAM_FILE_NODE_REF);
				NodeRef uploadedNode = new NodeRef(nodeRef);
				
				/**
				 * Step 3: Delete older published version
				 */
				
				
				policyFilter.disableBehaviour(uploadedNode, CiscoModelConstants.CISCO_MODEL);
				
				LOG.info(" Version Check Start ");
				VersionHistory versionHistory = serviceRegistry.getVersionService().getVersionHistory(uploadedNode);
				LOG.info(" versionHistory :::: " + versionHistory);
				if (versionHistory != null) {
					Collection<Version> collection = serviceRegistry.getVersionService()
							.getVersionHistory(uploadedNode).getAllVersions();
					int count = 0;
					for (Version node : collection) {
						Boolean isExternalyShared = false;
						LOG.info(" node :::: " + node);
						NodeRef versionFrozenNode = node.getFrozenStateNodeRef();
						String strFrozenNode = versionFrozenNode.toString().replace("versionStore://version2Store/", "workspace://version2Store/");
						NodeRef frozenNode = new NodeRef(strFrozenNode);
						LOG.info(" frozenNode :::: " + frozenNode);
						if (frozenNode != null) {
							isExternalyShared = (Boolean) nodeService.getProperty(frozenNode, MigrationConstants.CISCO_EXTERNAL_IS_EXTERNALLY_SHARED_PROP);
							LOG.info(" isExternalyShared :::: "	+ isExternalyShared+" frozenNode Path :::: "+ nodeService.getPath(frozenNode));

						}

						LOG.info(" count " + count);
						if (count > 0 && isExternalyShared != null && isExternalyShared) {
							deleteVersionedNode(frozenNode);
							LOG.info(" Deletion Success ");
						}
						count++;

					}

				}
				//start US8623 Publish a file from Doc Central to multiple target folders in Doc Exchange
				 String strExtTargetNodeRef = req.getParameter("externalTargetNodeRefID");
				 LOG.info("strExtTargetNodeRef Folder nodes ::: "+strExtTargetNodeRef);
                 if(strExtTargetNodeRef != null && !strExtTargetNodeRef.equals("")&& strExtTargetNodeRef.contains("workspace://SpacesStore/")){
                 List<String> externalTargetNodeRefs = new ArrayList<String>(Arrays.asList(strExtTargetNodeRef.split(",")));
                 if(externalTargetNodeRefs.contains(existingNodeRef.toString())){
                	 LOG.info("source Folder nodes :::::: "+existingNodeRef);
         			externalTargetNodeRefs.remove(existingNodeRef.toString());
         			}
                 if(!externalTargetNodeRefs.isEmpty() && externalTargetNodeRefs.size()>0){
                     for (int i = 0; i < externalTargetNodeRefs.size(); i++) {
                    	 if(externalTargetNodeRefs.get(i) != null && !externalTargetNodeRefs.get(i).equals("")&& externalTargetNodeRefs.get(i).contains("workspace://SpacesStore/")){
                         	NodeRef folderNodeId = new NodeRef(externalTargetNodeRefs.get(i));
                         	 if(nodeService.exists(folderNodeId)){
                         		LOG.info("Updated Found Copy of node in target folder for :: " +uploadedNode +" in Folder node :::: "+folderNodeId);
                       		 PagingRequest pagingRequest = new PagingRequest(1);
                       		 PagingResults<CopyInfo> previousCopiesOfPublishNodePage = serviceRegistry.getCopyService().getCopies(uploadedNode, folderNodeId, pagingRequest);
                       		 List<CopyInfo> pageResultsPublishedNodes = previousCopiesOfPublishNodePage.getPage();
                       		 if (!previousCopiesOfPublishNodePage.getPage().isEmpty() && previousCopiesOfPublishNodePage.getPage().size()>0)
                       	      {
                       			 for (CopyInfo copyInfo : pageResultsPublishedNodes)
                       			 	{
		                    		 	try{
		                    		 	policyFilter.disableBehaviour(copyInfo.getNodeRef(), CiscoModelConstants.CISCO_MODEL);
		                    		 	LOG.info("CopyInfo Version Check Start ");
		                 				VersionHistory copiedVersionHistory = serviceRegistry.getVersionService().getVersionHistory(copyInfo.getNodeRef());
		                 				LOG.info(" CopyInfo versionHistory :::: " + copiedVersionHistory);
		                 				if (copiedVersionHistory != null) {
		                 					Collection<Version> copiedCollection = serviceRegistry.getVersionService()
		                 							.getVersionHistory(copyInfo.getNodeRef()).getAllVersions();
		                 					int copiedNodeCount = 0;
		                 					for (Version copiedNode : copiedCollection) {
		                 						Boolean copiedIsExternalyShared = false;
		                 						LOG.info("copiedNode :::: " + copiedNode);
		                 						NodeRef copiedVersionFrozenNode = copiedNode.getFrozenStateNodeRef();
		                 						String strCopiedFrozenNode = copiedVersionFrozenNode.toString().replace("versionStore://version2Store/", "workspace://version2Store/");
		                 						NodeRef copiedFrozenNode = new NodeRef(strCopiedFrozenNode);
		                 						LOG.info(" copiedFrozenNode :::: " + copiedFrozenNode);
		                 						if (copiedFrozenNode != null) {
		                 							copiedIsExternalyShared = (Boolean) nodeService.getProperty(copiedFrozenNode, MigrationConstants.CISCO_EXTERNAL_IS_EXTERNALLY_SHARED_PROP);
		                 							LOG.info(" copiedIsExternalyShared :::: "	+ copiedIsExternalyShared+" frozenNode Path :::: "+ nodeService.getPath(copiedFrozenNode));
		                 						}
		                 						LOG.info(" count " + copiedNodeCount);
		                 						if (copiedNodeCount > 0 && copiedIsExternalyShared != null && copiedIsExternalyShared) {
		                 							deleteVersionedNode(copiedFrozenNode);
		                 							LOG.info(" Deletion Success ");
		                 						}
		                 						copiedNodeCount++;
		                 					}
		                 				}
                    		 		}finally {
                 					policyFilter.enableBehaviour(copyInfo.getNodeRef(), CiscoModelConstants.CISCO_MODEL);
                    		 		 }
                       			 	}
                       	      	}
                         	 }
                    	 }
                     }
                 }
                 }
                 else
                 {
				PagingRequest pagingRequest = new PagingRequest(1000);
       		 	PagingResults<CopyInfo> previousVersionCopiesOfPublishNodePage = serviceRegistry.getCopyService().getCopies(uploadedNode, pagingRequest);
       		 	List<CopyInfo> pageResultsVersionPublishedNodes = previousVersionCopiesOfPublishNodePage.getPage();
       		 	if (!previousVersionCopiesOfPublishNodePage.getPage().isEmpty() && previousVersionCopiesOfPublishNodePage.getPage().size()>0)
       		 	{
       		 	LOG.info("Updated Found Copy of node: " +uploadedNode +" in case of auto publish & republish");
       		 		for (CopyInfo copyInfoNode : pageResultsVersionPublishedNodes)
       		 		{
       		 		try{
       		 		policyFilter.disableBehaviour(copyInfoNode.getNodeRef(), CiscoModelConstants.CISCO_MODEL);
       		 		LOG.info("CopyInfo Version Check Start ");
    				VersionHistory copiedVersionHistory = serviceRegistry.getVersionService().getVersionHistory(copyInfoNode.getNodeRef());
    				LOG.info("CopyInfo versionHistory :::: " + copiedVersionHistory);
    				if (copiedVersionHistory != null) {
    					Collection<Version> copiedCollection = serviceRegistry.getVersionService()
    							.getVersionHistory(copyInfoNode.getNodeRef()).getAllVersions();
    					int copiedNodeCount = 0;
    					for (Version copiedNode : copiedCollection) {
    						Boolean copiedIsExternalyShared = false;
    						LOG.info(" copiedNode :::: " + copiedNode);
    						NodeRef copiedVersionFrozenNode = copiedNode.getFrozenStateNodeRef();
    						String strCopiedFrozenNode = copiedVersionFrozenNode.toString().replace("versionStore://version2Store/", "workspace://version2Store/");
    						NodeRef copiedFrozenNode = new NodeRef(strCopiedFrozenNode);
    						LOG.info(" copiedFrozenNode :::: " + copiedFrozenNode);
    						if (copiedFrozenNode != null) {
    							copiedIsExternalyShared = (Boolean) nodeService.getProperty(copiedFrozenNode, MigrationConstants.CISCO_EXTERNAL_IS_EXTERNALLY_SHARED_PROP);
    							LOG.info(" copiedIsExternalyShared :::: "	+ copiedIsExternalyShared+" frozenNode Path :::: "+ nodeService.getPath(copiedFrozenNode));

    						}
    						LOG.info(" count " + copiedNodeCount);
    						if (copiedNodeCount > 0 && copiedIsExternalyShared != null && copiedIsExternalyShared) {
    							deleteVersionedNode(copiedFrozenNode);
    							LOG.info(" Deletion Success ");
    						}
    						copiedNodeCount++;
    					}
    				}
       		 		}finally {
    					policyFilter.enableBehaviour(copyInfoNode.getNodeRef(), CiscoModelConstants.CISCO_MODEL);
       		 		}
       		 			
       		 		}
       		 	}
       		 	}
                 //end of US8623 Publish a file from Doc Central to multiple target folders in Doc Exchange
				
				
				try {
					
					//String strExtTargetNodeRef = req.getParameter("externalTargetNodeRefID");
					setModifierAsPublisher(existingNodeRef, publisher, uploadedNode,strExtTargetNodeRef);
					// end mkatnam
					LOG.info(" modifyDefaultProperties - set done");

					// START US5919: prbadam moved Publish Notification component from Doc Central to Doc Exchange, because for first time inherited users(from Doc Exchange) are not coming in mail.
				    //UploadDocumentNotification.publishNotificationDetails(uploadedNode,serviceRegistry);
					//LOG.info("Mail sent successfully------");
					// END US5919: prbadam moved Publish Notification component from Doc Central to Doc Exchange, because for first time inherited users(from Doc Exchange) are not coming in mail.

				} finally {
					policyFilter.enableBehaviour(uploadedNode, CiscoModelConstants.CISCO_MODEL);
					LOG.info(" modifyDefaultProperties - finally enabled.");
				}

			} else {
				result.put(PARAM_STATUS_MSG, "Provided Root Path not exist.");
				result.put(PARAM_FOLDER_NODE_REF, "Root Folder Path not exist.");
				result.put(PARAM_FILE_NODE_REF, "Root File Path not exist.");
				result.put(PARAM_FILE_NAME, "File not imported due to Root Folder Path not exist.");
			}

		} catch (Exception e) {
			LOG.error("Exeption occured in uploadContentServlet class :::: "+ e, e);

			result.put(PARAM_STATUS_MSG, (e != null) ? e.getMessage(): NULL_EXCEPTION);
			result.put(PARAM_FOLDER_NODE_REF,"Folder not created due to exception.");
			result.put(PARAM_FILE_NODE_REF, FILE_EXCEPTION);
			result.put(PARAM_FILE_NAME, FILE_EXCEPTION);
		} finally {
			LOG.info("Custom UploadContentServlet.executeImpl()  finally block End ");
		}

		return result;
	}
	
	private void setModifierAsPublisher(final NodeRef parentNode, final String publisher, final NodeRef uploadedNode,final String strExtTargetNodeRef) throws Exception{
		serviceRegistry.getTransactionService().getRetryingTransactionHelper().doInTransaction(new RetryingTransactionCallback<Void>(){
			@Override
			public Void execute() throws Throwable {
				policyFilter.disableBehaviour(parentNode, ContentModel.ASPECT_AUDITABLE);
				policyFilter.disableBehaviour(uploadedNode,	ContentModel.ASPECT_AUDITABLE);
				LOG.error("Before setting modifier and creator on documentNodeRef");
				Map<QName, Serializable> properties = new HashMap<QName, Serializable>();
				properties.put(ContentModel.PROP_MODIFIER, publisher);
				properties.put(ContentModel.PROP_CREATOR, publisher);
				nodeService.addProperties(uploadedNode, properties);
				
				LOG.error("Before setting modifier on doc Parent NodeRef");
				serviceRegistry.getNodeService().setProperty(parentNode, ContentModel.PROP_MODIFIER, publisher);
				
				 //start US8623 Publish a file from Doc Central to multiple target folders in Doc Exchange
				PagingRequest pagingRequest = new PagingRequest(1000);
       		 	PagingResults<CopyInfo> previousCopiesOfPublishNodePage = serviceRegistry.getCopyService().getCopies(uploadedNode, pagingRequest);
       		 	List<CopyInfo> pageResultsPublishedNodes = previousCopiesOfPublishNodePage.getPage();
       		 	if (!previousCopiesOfPublishNodePage.getPage().isEmpty() && previousCopiesOfPublishNodePage.getPage().size()>0)
       		 	{
       		 	LOG.info("Updated Found Copy of node: " +uploadedNode +" in case of auto publish & republish");
       		 		//List<NodeRef> publishedNoderesults = new ArrayList<NodeRef>(pageResultsPublishedNodes.size());
       		 		for (CopyInfo copyInfo : pageResultsPublishedNodes)
       		 		{
       		 		policyFilter.disableBehaviour(copyInfo.getNodeRef(), ContentModel.ASPECT_AUDITABLE);
       		 		serviceRegistry.getNodeService().setProperty(copyInfo.getNodeRef(), ContentModel.PROP_CREATOR, publisher);
       		 		serviceRegistry.getNodeService().setProperty(copyInfo.getNodeRef(), ContentModel.PROP_MODIFIER, publisher);
       		 		policyFilter.enableBehaviour(copyInfo.getNodeRef(),	ContentModel.ASPECT_AUDITABLE);
       		 		}
				
       		 	}
       		 LOG.info("request strExtTargetNodeRef Folder nodeRefs:::::::::::: "+strExtTargetNodeRef);
       		 if(strExtTargetNodeRef != null && !strExtTargetNodeRef.equals("")&& strExtTargetNodeRef.contains("workspace://SpacesStore/")){
                 List<String> externalTargetNodeRefs = Arrays.asList(strExtTargetNodeRef.split(","));
                 LOG.info("externalTargetNodeRefs Folder nodeRefs:::::::::::: "+externalTargetNodeRefs.toString());
                 for (int i = 0; i < externalTargetNodeRefs.size(); i++) {
                 	 if(externalTargetNodeRefs.get(i) != null && !externalTargetNodeRefs.get(i).equals("")&& externalTargetNodeRefs.get(i).contains("workspace://SpacesStore/")){
                 	NodeRef folderNodeId = new NodeRef(externalTargetNodeRefs.get(i));
                 	 if(nodeService.exists(folderNodeId)){
                 		policyFilter.disableBehaviour(folderNodeId, ContentModel.ASPECT_AUDITABLE);
           		 		serviceRegistry.getNodeService().setProperty(folderNodeId, ContentModel.PROP_MODIFIER, publisher);
           		 		policyFilter.enableBehaviour(folderNodeId,	ContentModel.ASPECT_AUDITABLE);
                 	 }
                 	 }
                 }
       		 }
       		 //end US8623 Publish a file from Doc Central to multiple target folders in Doc Exchange
				policyFilter.enableBehaviour(uploadedNode,	ContentModel.ASPECT_AUDITABLE);
				policyFilter.enableBehaviour(parentNode, ContentModel.ASPECT_AUDITABLE);	           	    			

				return null;
			}
		}, false, true); 
	}
	
	/**
	 * Delete older published version
	 */
	private void deleteVersionedNode(final NodeRef versionedNode) {
		try{
		serviceRegistry.getTransactionService().getRetryingTransactionHelper()
				.doInTransaction(new RetryingTransactionCallback<Void>() {
					@Override
					public Void execute() throws Throwable {
						nodeService.deleteNode(versionedNode);
						return null;
					}
				}, false, true);
		LOG.error("After removing older published version of doc");
		}catch(Exception exe){
			LOG.error("Exeption occured in uploadContentServlet class deleteVersionedNode:::: "+ exe.getMessage());
		}
	}
	
}