package com.cisco.sd.rest.service;

import static com.cisco.sd.rest.service.MigrationConstants.ADMIN_USER;
import static com.cisco.sd.rest.service.MigrationConstants.CISCODOC_TYPE;
import static com.cisco.sd.rest.service.MigrationConstants.CISCO_MODEL_NAMESPACE;
import static com.cisco.sd.rest.service.MigrationConstants.EMPTY_STRING;
import static com.cisco.sd.rest.service.MigrationConstants.FOLDER_PATH;
import static com.cisco.sd.rest.service.MigrationConstants.NULL_EXCEPTION;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_ATTACH_FILE_METADATA;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_ATTACH_FILE_TAGGING;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_ENCODING;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_FILE_NAME;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_FILE_NODE_REF;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_FOLDER_NODE_REF;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_JSON_COMMON_PROPS;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_JSON_METADATA;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_OVERWRITE;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_QNAME;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_STATUS_MSG;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_TAGGING_ATTRIBUTES;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_VERSIONABLE;
import static com.cisco.sd.rest.service.MigrationConstants.PROP_RETENTION_END_RANGE;
import static com.cisco.sd.rest.service.MigrationConstants.PROP_RETENTION_PERIOD;
import static com.cisco.sd.rest.service.MigrationConstants.PROP_RETENTION_START_RANGE;
import static com.cisco.sd.rest.service.MigrationConstants.RETENTION_ASPECT;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.alfresco.model.ContentModel;
import org.alfresco.query.PagingRequest;
import org.alfresco.query.PagingResults;
import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.content.encoding.ContentCharsetFinder;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.transaction.RetryingTransactionHelper.RetryingTransactionCallback;
import org.alfresco.repo.version.VersionModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileFolderService;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.CopyService.CopyInfo;
import org.alfresco.service.cmr.repository.MimetypeService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthenticationService;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.OwnableService;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionService;
import org.alfresco.service.cmr.version.VersionType;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.servlet.FormData;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.edcsng.util.DocIdGenerator;
import com.cisco.alfresco.ext.workflow.util.WFMailRootscopedObject;
import com.cisco.alfresco.external.common.util.CiscoCopyServiceUtil;
import com.cisco.alfresco.external.utils.CharUtil;


/**
 * 
 * @author gpotla
 * 
 */
public class FileMetaDataServieImpl extends TaggingAspects implements IFileMetaDataService
{

    private static final Logger LOGGER = Logger.getLogger(FileMetaDataServieImpl.class);

    private ServiceRegistry serviceRegistry;

    private NodeService nodeService;

    private FileFolderService fileFolderService;

    private ContentService contentService;

    private VersionService versionService;

    private OwnableService ownableService;

    private AuthenticationService authenticationService;

    private MimetypeService mimetypeService;

    // private String mimeType = null; //local

    // private List<String> aspectsList = null;

    // private NodeRef uploadFileNode = null; //local

    private static String ACTION_NAME = "republish";

    private AuditComponent auditComponent;

	private PermissionService permissionService;
	
	private DocIdGenerator docIdGenBean;
	
	private CiscoCopyServiceUtil ciscoCopyService;
    
	public CiscoCopyServiceUtil getCiscoCopyService() {
		return ciscoCopyService;
	}

	public void setCiscoCopyService(CiscoCopyServiceUtil ciscoCopyService) {
		this.ciscoCopyService = ciscoCopyService;
	}

	public PermissionService getPermissionService()
    {
        return permissionService;
    }

    public void setPermissionService(PermissionService permissionService)
    {
        this.permissionService = permissionService;
    }

    public void setAuditComponent(AuditComponent auditComponent)
    {
        this.auditComponent = auditComponent;
    }

    public String getBannerAlfrescoUrl()
    {
        return bannerAlfrescoUrl;
    }

    public void setBannerAlfrescoUrl(String bannerAlfrescoUrl)
    {
        this.bannerAlfrescoUrl = bannerAlfrescoUrl;
    }

    private String bannerAlfrescoUrl;

    // Map<String, Object> result = null;

    public OwnableService getOwnableService()
    {
        return ownableService;
    }

    public void setOwnableService(OwnableService ownableService)
    {
        this.ownableService = ownableService;
    }

    // for Spring injection
    public VersionService getVersionService()
    {
        return versionService;
    }

    public void setVersionService(VersionService versionService)
    {
        this.versionService = versionService;
    }

    public void setServiceRegistry(ServiceRegistry registry)
    {
        this.serviceRegistry = registry;
    }

    public void setAuthenticationService(AuthenticationService authenticationService)
    {
        this.authenticationService = authenticationService;
    }

	public DocIdGenerator getDocIdGenBean() {
		return docIdGenBean;
	}

	public void setDocIdGenBean(DocIdGenerator docIdGenBean) {
		this.docIdGenBean = docIdGenBean;
	}
    /**
     * 
     */
    public void init()
    {
        LOGGER.info("In FileMetaDataServieImpl.init() ");
        this.nodeService = serviceRegistry.getNodeService();
        this.fileFolderService = serviceRegistry.getFileFolderService();
        this.contentService = serviceRegistry.getContentService();
        this.mimetypeService = serviceRegistry.getMimetypeService();
        // result = new HashMap<String, Object>();
    }

    /**
     * 
     * @param parentNode
     * @param fileName
     * @return
     */
    private NodeRef createContentNode(final NodeRef parentNode, final String fileName, final String mimeType)
    {
        LOGGER.info("In FileMetaDataServieImpl.createContentNode() Start");

        return (NodeRef) AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
        {

            public Object doWork() throws Exception
            {
                try
                {
                    NodeRef contentNode = null;

                    Map<QName, Serializable> propertyMap = new HashMap<QName, Serializable>();
                    propertyMap.put(ContentModel.PROP_NAME, fileName);

                    ChildAssociationRef childAssocRef = nodeService.createNode(parentNode, ContentModel.ASSOC_CONTAINS,
                        QName.createQName(CISCO_MODEL_NAMESPACE, QName.createValidLocalName(fileName)), CISCODOC_TYPE,
                        propertyMap);

                    LOGGER.info(" Created node " + childAssocRef.getChildRef().toString() + " for the file " + fileName
                            + "    mimeType" + mimeType);

                    nodeService.setProperty(childAssocRef.getChildRef(), ContentModel.PROP_CONTENT, mimeType);

                    contentNode = childAssocRef.getChildRef();

                    return contentNode;

                }
                catch (Exception e)
                {
                    LOGGER.error(e, e);
                    throw new Exception((e != null) ? e.getMessage() : NULL_EXCEPTION);
                }
                finally
                {
                    LOGGER.info("In FileMetaDataServieImpl.createContentNode() finally block End ");
                }
            }
        }, ADMIN_USER);

    }

    /**
     * 
     * @param request
     * @param uploadFileNode
     * @return
     */
    @SuppressWarnings("unchecked")
    private Map<QName, Serializable> attachMetaData(final WebScriptRequest request, final NodeRef uploadFileNode)
    {
        LOGGER.info(" In FileMetaDataServieImpl.attachMetaData() Start ");
        return (Map<QName, Serializable>) AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
        {

            public Object doWork() throws Exception
            {
                Map<QName, Serializable> metaDataProps = null;

                JSONParser jsonParser = new JSONParser();
                JSONObject aspectsJsonObject = null;
                String qName = null;
                String property = null;
                Serializable propValue = null;
                try
                {
                    aspectsJsonObject = (JSONObject) jsonParser.parse(request.getParameter(PARAM_JSON_METADATA));
                    LOGGER.info(" aspects JsonObject --- >" + aspectsJsonObject);

                    String aspect = null;
                    String aspectQname = null;
                    for (Object aspectName : aspectsJsonObject.keySet())
                    {
                        metaDataProps = new HashMap<QName, Serializable>();

                        aspect = aspectName.toString();
                        // aspectsList.add(aspect);

                        LOGGER.info("Aspect -->" + aspect);

                        JSONArray jsonArray = (JSONArray) aspectsJsonObject.get(aspectName);

                        if (aspect.equals(RETENTION_ASPECT))
                        {
                            metaDataProps = attachRecordsInfoAspect(metaDataProps, aspect, jsonArray);
                            for (Object properties : (JSONArray) aspectsJsonObject.get(aspectName))
                            {
                                aspectQname = (String) ((JSONObject) properties).get(PARAM_QNAME);
                                break;
                            }
                        }
                        else
                        {
                            for (Object properties : jsonArray)
                            {

                                LOGGER.info("Properties ::: " + ((JSONObject) properties).keySet());
                                for (Object objects : ((JSONObject) properties).keySet())
                                {

                                    property = objects.toString();
                                    LOGGER.info(" Property KEYSET from JSON .. " + property);

                                    if (property.equals(PARAM_QNAME))
                                    {
                                        qName = (String) ((JSONObject) properties).get(property);
                                        aspectQname = qName;
                                    }

                                    LOGGER.info(" Aspects QName is .. " + qName);

                                    propValue = (Serializable) ((JSONObject) properties).get(property);
                                    if (!property.toString().equals(PARAM_QNAME))
                                    {
                                        metaDataProps.put(QName.createQName(qName, property), propValue);
                                    }
                                }
                                LOGGER.info(aspect + " final metaDataProps  ::: " + metaDataProps);
                            }
                        }
                        // Adding all the aspects and it's corresponding
                        // propperties
                        addMetaDataAspect(metaDataProps, aspect.toString(), aspectQname, uploadFileNode);
                    }

                }
                catch (Exception e)
                {
                    LOGGER.error(" Exception while parsing json object .. " + e, e);
                    throw new Exception((e != null) ? e.getMessage() : NULL_EXCEPTION);
                }
                finally
                {
                    LOGGER.info("In FileMetaDataServieImpl.attachMetaData() finally block End ");
                }

                return metaDataProps;
            }
        }, ADMIN_USER);
    }

    /**
     * 
     * @param metaDataProps
     * @param aspectName
     * @param jsonArray
     * @return
     */
    public Map<QName, Serializable> attachRecordsInfoAspect(Map<QName, Serializable> metaDataProps, String aspectName,
            JSONArray jsonArray) throws Exception
    {
        LOGGER.info(" In FileMetaDataServieImpl.attachRecordsInfoAspect() Start ");
        String qName = null;
        String property = null;
        Serializable propValue = null;
        for (Object properties : jsonArray)
        {
            for (Object objects : ((JSONObject) properties).keySet())
            {

                property = objects.toString();
                LOGGER.info("Property KEYSET from .. " + property);
                if (property.equals(PARAM_QNAME))
                {
                    qName = (String) ((JSONObject) properties).get(property);
                }
                LOGGER.info(" Aspects QName value from attachRecordsInfoAspect() .. " + qName);
                propValue = (Serializable) ((JSONObject) properties).get(objects);

                if (property.equals(PROP_RETENTION_PERIOD))
                {

                    String[] propsArray = propValue.toString().split(",");
                    if (propsArray.length >= 2)
                    {
                        String period = propsArray[0];
                        String startRange = propsArray[1].split("-")[0].trim();
                        String endRange = propsArray[1].split("-")[1].trim();
                        metaDataProps.put(QName.createQName(qName, PROP_RETENTION_PERIOD), period);
                        metaDataProps.put(QName.createQName(qName, PROP_RETENTION_START_RANGE), startRange);
                        metaDataProps.put(QName.createQName(qName, PROP_RETENTION_END_RANGE), endRange);
                    }
                    else
                    {
                        metaDataProps.put(QName.createQName(qName, property), propValue);
                    }

                }
                else
                {
                    if (!property.toString().equals(PARAM_QNAME))
                    {
                        metaDataProps.put(QName.createQName(qName, property), propValue);
                    }
                }
            }
            LOGGER.info("For " + aspectName + " final attachRecordsInfoAspect  metaDataProps  ::: " + metaDataProps);
        }
        LOGGER.info(" In FileMetaDataServieImpl.attachRecordsInfoAspect() End ");
        return metaDataProps;
    }

    /**
     * 
     * @param request
     * @param uploadFileNode
     */
    private void attachCommonProperties(WebScriptRequest request, NodeRef uploadFileNode) throws Exception
    {
        LOGGER.info(" In FileMetaDataServieImpl.attachCommonProperties()  Start ");
        Map<QName, Serializable> metaDataProps = new HashMap<QName, Serializable>();
        JSONParser jsonParser = new JSONParser();
        JSONArray propertiesJsonarray = null;
        String qName = null;
        String property = null;
        Serializable propValue = null;
        try
        {
            propertiesJsonarray = (JSONArray) jsonParser.parse(request.getParameter(PARAM_JSON_COMMON_PROPS));
            LOGGER.info(" propertiesJsonarray .." + propertiesJsonarray);

            String publisher = request.getParameter(MigrationConstants.PARAM_PUBLISHER);

            for (int i = 0; i < propertiesJsonarray.size(); i++)
            {
                for (Object objects : ((JSONObject) propertiesJsonarray.get(i)).keySet())
                {

                    property = objects.toString();
                    LOGGER.info("Property KEYSET .. " + property);
                    if (property.equals(PARAM_QNAME))
                    {
                        qName = (String) ((JSONObject) propertiesJsonarray.get(i)).get(property);
                    }
                    LOGGER.info(" Aspects QName value from attachCommonProperties() .. " + qName);
                    propValue = (Serializable) ((JSONObject) propertiesJsonarray.get(i)).get(objects);

                    if (!property.toString().equals(PARAM_QNAME))
                    {
                        metaDataProps.put(QName.createQName(qName, property), propValue);
                    }
                }
            }
            LOGGER.info(" final attachCommonProperties " + metaDataProps);
            nodeService.addProperties(uploadFileNode, metaDataProps);
            serviceRegistry.getNodeService().setProperty(uploadFileNode, ContentModel.PROP_CREATOR, publisher);

            if (serviceRegistry.getNodeService().hasAspect(uploadFileNode, ContentModel.ASPECT_OWNABLE))
            {
                serviceRegistry.getNodeService().setProperty(uploadFileNode, ContentModel.PROP_OWNER, publisher);
            }
            else
            {
                Map<QName, Serializable> ownableAspectValues = new HashMap<QName, Serializable>();
                ownableAspectValues.put(ContentModel.PROP_OWNER, publisher);

                serviceRegistry.getNodeService().addAspect(uploadFileNode, ContentModel.ASPECT_OWNABLE,
                    ownableAspectValues);
            }

            LOGGER.info(" publisher :::" + publisher);
            LOGGER.info(" cm:creator ::: "
                    + serviceRegistry.getNodeService().getProperty(uploadFileNode, ContentModel.PROP_CREATOR));

        }
        catch (Exception e)
        {
            LOGGER.error(" Exception while attachCommonProperties parsing json object .." + e, e);
            throw new Exception((e != null) ? e.getMessage() : NULL_EXCEPTION);
        }
        finally
        {
            LOGGER.info(" In FileMetaDataServieImpl.attachCommonProperties() End ");
        }

    }

    /**
     * 
     * @param metaDataProps
     * @param aspectName
     * @param queueName
     * @param currentNodeRef
     */
    public void addMetaDataAspect(final Map<QName, Serializable> metaDataProps, final String aspectName,
            final String queueName, final NodeRef currentNodeRef) throws Exception
    {
        LOGGER.info("In FileMetaDataServieImpl.AddMetaDataAspect() Start");
        AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
        {

            public Object doWork() throws Exception
            {
                String fileName = (String) nodeService.getProperty(currentNodeRef, ContentModel.PROP_NAME);

                boolean hasAspect = nodeService.hasAspect(currentNodeRef, QName.createQName(queueName, aspectName));
                LOGGER.info(fileName + " is having Aspect ---" + aspectName + " ? " + hasAspect);

                LOGGER.info(" for the ASPECT " + aspectName + ", metaDataProps is " + metaDataProps);

                if (!hasAspect)
                {
                    nodeService.addAspect(currentNodeRef, QName.createQName(queueName, aspectName), metaDataProps);
                }
                else
                {
                    nodeService.addProperties(currentNodeRef, metaDataProps);
                }
                LOGGER.info(" Adding Aspect complted for " + aspectName);

                return null;
            }
        }, ADMIN_USER);
        LOGGER.info("In FileMetaDataServieImpl.AddMetaDataAspect() End");
    }

    /**
     * 
     * @param fileUploadNodeRef
     */
    public void doCreateVersions(NodeRef fileUploadNodeRef) throws Exception
    {

        LOGGER.info(" FileMetaDataServieImpl.doCreateVersions() UploadNodeRef ::: " + fileUploadNodeRef);

        boolean hasAspect = nodeService.hasAspect(fileUploadNodeRef, ContentModel.ASPECT_VERSIONABLE);

        LOGGER.info(" Is ASPECT_VERSIONABLE ? " + hasAspect);

        if (hasAspect)
        {
            Map<String, Serializable> versionProperties = new HashMap<String, Serializable>();
            versionProperties.put(Version.PROP_DESCRIPTION, "Migrationed Version");
            versionProperties.put(VersionModel.PROP_VERSION_TYPE, VersionType.MINOR);
            this.versionService.createVersion(fileUploadNodeRef, versionProperties);
        }
        else
        {
            Map<QName, Serializable> versionProperties = new HashMap<QName, Serializable>();
            versionProperties.put(ContentModel.PROP_VERSION_TYPE, VersionType.MAJOR);
            versionProperties.put(ContentModel.PROP_AUTO_VERSION, true);
            nodeService.addAspect(fileUploadNodeRef, ContentModel.ASPECT_VERSIONABLE, versionProperties);
        }
    }

    /**
     * 
     * @param request
     * @param uploadFileNode
     */
    public void attachMandatoryMetadata(final WebScriptRequest request, final NodeRef uploadFileNode) throws Exception
    {

        LOGGER.info(" FileMetaDataServieImpl.attachMandatoryMetadata()  for file Node ::: " + uploadFileNode);

        AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
        {

            @Override
            public Object doWork() throws Exception
            {

                attachCommonProperties(request, uploadFileNode);

                // aspectsList = new ArrayList<String>();

                attachMetaData(request, uploadFileNode);

                String fileTagging = request.getParameter(PARAM_ATTACH_FILE_TAGGING);
                boolean attachFileTagging = false;
                if (fileTagging != null && !fileTagging.trim().equals(EMPTY_STRING))
                {
                    attachFileTagging = Boolean.parseBoolean(fileTagging);
                }

                // setting Tag attributes to the files
                if (attachFileTagging)
                {
                    attachTagAttributes(uploadFileNode, request);
                }

                return null;
            }
        }, ADMIN_USER);

    }

    /*
     * private String getExternalUsers(String externalUsers, String publisher) throws Exception { if (null !=
     * externalUsers && externalUsers.contains(publisher)) { String publisherRole =
     * externalUsers.substring(externalUsers.indexOf(publisher + "("));// .substring(0, // endIndex); publisherRole =
     * publisherRole.substring(0, publisherRole.indexOf(")") + 1); externalUsers = externalUsers.replace(publisherRole,
     * ""); if (externalUsers.startsWith(",")) { externalUsers = externalUsers.substring(1); } if
     * (externalUsers.endsWith(",")) { externalUsers = externalUsers.substring(0, externalUsers.lastIndexOf(",")); } if
     * (externalUsers.contains(",,")) { externalUsers = externalUsers.replace(",,", ","); } } return externalUsers; }
     */

    private String getUserRole(String permRole) throws Exception
    {
        String role = null;
        if (permRole != null)
        {
            if (permRole.equals("User"))
            {
                role = MigrationConstants.PERM_USER_ROLE;
            }
            else if (permRole.equals("Viewer"))
            {
                role = MigrationConstants.PERM_VIEWER_ROLE;
            }
            else if (permRole.equals("Reader"))
            {
                role = MigrationConstants.PERM_READER_ROLE;
            }
            else if (permRole.equals("Editor"))
            {
                role = MigrationConstants.PERM_EDITOR_ROLE;
            }
            else if (permRole.equals("Owner"))
            {
                role = MigrationConstants.PERM_OWNER_ROLE;
            }
        }
        return role;
    }

    /**
     * 
     * @param request
     * @param uploadFileNode
     */

    private void attachPermissions(final WebScriptRequest request, final NodeRef uploadFileNode) throws Exception
    {

        try
        {
            AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
            {

                @Override
                public Object doWork() throws Exception
                {

                    // String permRole = request.getParameter(MigrationConstants.PARAM_PERM_ROLE);
                    String inhertPerm = request.getParameter(MigrationConstants.PARAM_INHERIT_PERM);
                    boolean isInheritPerm = inhertPerm != null ? Boolean.valueOf(inhertPerm) : false;
                    // boolean addUsersToFolder = request.getParameter("addUsersToFolder") != null ?
                    // Boolean.valueOf(request.getParameter("addUsersToFolder")) : false;
                    String externalUsers = request.getParameter(MigrationConstants.PARAM_EXTERNAL_USERS);
                    final String publisher = request.getParameter(MigrationConstants.PARAM_PUBLISHER);
                    String publishExpirationDateStr = request
                            .getParameter(MigrationConstants.PARAM_PUBLISH_EXPIRATION_DATE_STR);
                    LOGGER.info("publishExpirationDateStr :::" + publishExpirationDateStr);
                    DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss z");
                    Date publishExpirationDate = df.parse(publishExpirationDateStr);
                    LOGGER.info("publishExpirationDate :::" + publishExpirationDate);
                    serviceRegistry.getNodeService().setProperty(uploadFileNode,
                        MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP, publishExpirationDate);
                    // String role = null;

                    ChildAssociationRef childAssociationRef = serviceRegistry.getNodeService().getPrimaryParent(
                        uploadFileNode);
                    NodeRef parentFolderNodeRef = childAssociationRef.getParentRef();

                    PermissionService permissionService = serviceRegistry.getPermissionService();

                    // permissionService.setInheritParentPermissions(parentFolderNodeRef, false);

                    permissionService.setInheritParentPermissions(uploadFileNode, false);

                    Set<AccessPermission> nodeAccessPermissions = permissionService
                            .getAllSetPermissions(uploadFileNode);
                    Iterator<AccessPermission> nodeIterator = nodeAccessPermissions.iterator();
                    LOGGER.info("externalUsers before replace ::: " + externalUsers);

                    if (externalUsers != null && !externalUsers.equals(""))
                    {
                        serviceRegistry.getPermissionService().deletePermissions(uploadFileNode);

                        // externalUsers = getExternalUsers(externalUsers, publisher);
                        LOGGER.info("publisher ::: " + publisher);
                        String[] externalUserList = externalUsers.split(",");
                        LOGGER.info("external users length :::" + externalUserList.length);
                        for (int i = 0; i < externalUserList.length; i++)
                        {
                            if (externalUserList[i] != null && !externalUserList[i].isEmpty())
                            {
                                int index = externalUserList[i].indexOf("(");
                                String userName = "";
                                if (index != -1)
                                {
                                    userName = externalUserList[i].substring(0, externalUserList[i].indexOf("("));
                                }
                                else
                                {
                                    userName = externalUserList[i].substring(0);
                                }
                                // String userName = externalUserList[i].substring(0, externalUserList[i].indexOf("("));
                                if (!userName.isEmpty() && !userName.equals(publisher))
                                {
                                    String userRole = externalUserList[i].substring(
                                        externalUserList[i].indexOf("(") + 1, externalUserList[i].indexOf(")"));
                                    if (userRole.trim().equalsIgnoreCase("Owner"))
                                    {
                                        userRole = "Editor";
                                    }
                                    LOGGER.info("userRole ::: " + userRole + " userName : " + userName);

                                    serviceRegistry.getPermissionService().setPermission(uploadFileNode, userName,
                                        getUserRole(userRole), true);
                                    LOGGER.info("userName ::: " + userName + " Created on node " + uploadFileNode);
                                }
                            }
                        }
                        if (publisher != null && !publisher.equals(MigrationConstants.ADMIN_USER))
                        {
                            serviceRegistry.getPermissionService().setPermission(uploadFileNode, publisher,
                                MigrationConstants.PERM_OWNER_ROLE, true);
                        }
                    }
                    else
                    {
                        while (nodeIterator.hasNext())
                        {
                            AccessPermission nodeAccessPermission = (AccessPermission) nodeIterator.next();
                            if (nodeAccessPermission.getAuthorityType() == AuthorityType.USER)
                            {
                                if (nodeAccessPermission.getAuthority().equals(publisher))
                                {
                                    serviceRegistry.getPermissionService().clearPermission(uploadFileNode, publisher);
                                }
                                else if (nodeAccessPermission.getPermission().equalsIgnoreCase(
                                    MigrationConstants.PERM_OWNER_ROLE))
                                {
                                    serviceRegistry.getPermissionService().clearPermission(uploadFileNode,
                                        nodeAccessPermission.getAuthority());
                                    serviceRegistry.getPermissionService().setPermission(uploadFileNode,
                                        nodeAccessPermission.getAuthority(), MigrationConstants.PERM_EDITOR_ROLE, true);
                                }
                            }
                        }
                        if (publisher != null && !publisher.equals(MigrationConstants.ADMIN_USER))
                        {
                            serviceRegistry.getPermissionService().setPermission(uploadFileNode, publisher,
                                MigrationConstants.PERM_OWNER_ROLE, true);
                        }
                    }

                    if (publisher != null && !publisher.equals(MigrationConstants.ADMIN_USER))
                    {
                        Set<AccessPermission> parentNodeAccessPermissions = permissionService
                                .getAllSetPermissions(parentFolderNodeRef);
                        /**
                         * If parent node have any permissions then check, is publisher have any permission on the node.
                         * If the parent node doesn't have any permissions then set the publisher as editor(else block)
                         * on the parent node.
                         */
                        if (parentNodeAccessPermissions != null && parentNodeAccessPermissions.size() > 0)
                        {
                            boolean isPublisherAddedtoFolder = false;
                            Iterator<AccessPermission> parentNodeIterator = parentNodeAccessPermissions.iterator();
                            while (parentNodeIterator.hasNext())
                            {
                                AccessPermission folderNodeAccessPermission = (AccessPermission) parentNodeIterator
                                        .next();
                                if (folderNodeAccessPermission.getAuthorityType() == AuthorityType.USER)
                                {
                                    if (folderNodeAccessPermission.getAuthority().equals(publisher))
                                    {
                                        isPublisherAddedtoFolder = true;
                                        /**
                                         * If the publisher is not Editor or AdminRole on the parent node, clear the
                                         * existing permission and assign publisher as editor in the parent node. If the
                                         * publisher is already have either Editor or AdminRole on parent node, then
                                         * simply ignore.
                                         */
                                        if (!folderNodeAccessPermission.getPermission().equals(
                                            MigrationConstants.PERM_FOLDER_ADMIN_ROLE)
                                                && !folderNodeAccessPermission.getPermission().equals(
                                                    MigrationConstants.PERM_EDITOR_ROLE))
                                        {
                                            serviceRegistry.getPermissionService().clearPermission(parentFolderNodeRef,
                                                publisher);
                                            serviceRegistry.getPermissionService().setPermission(parentFolderNodeRef,
                                                publisher, MigrationConstants.PERM_EDITOR_ROLE, true);
                                        }
                                    }
                                }
                            }
                            if (!isPublisherAddedtoFolder)
                            {
                                serviceRegistry.getPermissionService().setPermission(parentFolderNodeRef, publisher,
                                    MigrationConstants.PERM_EDITOR_ROLE, true);
                            }
                        }
                        else
                        {
                            serviceRegistry.getPermissionService().setPermission(parentFolderNodeRef, publisher,
                                MigrationConstants.PERM_EDITOR_ROLE, true);
                        }
                    }

                    if (isInheritPerm)
                    {
                        permissionService.setInheritParentPermissions(uploadFileNode, true);
                    }

                    return null;
                }

            }, ADMIN_USER);
        }
        catch (Exception e)
        {
           LOGGER.error(e);
        }

    }

    /**
     * 
     * @param field
     * @param parentNode
     * @return
     */
    public synchronized Map<String, Object> writeContent(final FormData.FormField field, final NodeRef parentNode,
            final WebScriptRequest request) throws Exception
    {
        return serviceRegistry
                .getTransactionService()
                    .getRetryingTransactionHelper()
                    .doInTransaction(new RetryingTransactionCallback<Map<String, Object>>()
                    {
                        @Override
                        public Map<String, Object> execute() throws Throwable
                        {
                            return createContent(field, parentNode, request);
                        }
                    }, false, true);

    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> createContent(final FormData.FormField field, final NodeRef parentNode,
            final WebScriptRequest request) throws Exception
    {
        final String currentLoginUserName = authenticationService.getCurrentUserName();
        LOGGER.info("In FileMetaDataServieImpl.writeContent() Start 11");
        return (Map<String, Object>) AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
        {

            public Object doWork() throws Exception
            {

                Map<String, Object> result = new HashMap<String, Object>();
                boolean isOverWrite = Boolean.valueOf(request.getParameter(PARAM_OVERWRITE));

                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = null;
                try
                {
                    jsonObject = (JSONObject) jsonParser.parse(request.getParameter(PARAM_JSON_METADATA));
                }
                catch (ParseException e)
                {
                    LOGGER.error(" Exception while parsing jsonMetadata " + e);
                    throw new Exception((e != null) ? e.getMessage() : NULL_EXCEPTION);
                }
                // String fileName = field.getFilename();
                // LOG.info("fileName before for" + fileName);
                String fileName = null;
                for (Object objectName : jsonObject.keySet())
                {
                    JSONArray jsonArray = (JSONArray) jsonObject.get(objectName);
                    LOGGER.info("jsonArray::" + jsonArray);
                    for (Object properties : jsonArray)
                    {
                        LOGGER.info("properties::" + properties);
                        for (Object objects : ((JSONObject) properties).keySet())
                        {

                            String property = objects.toString();
                            LOGGER.info("property::" + property);
                            Serializable propValue = (Serializable) ((JSONObject) properties).get(property);
                            LOGGER.info("propValue" + propValue);
                            if (property.toString().equals("fileName"))
                            {
                                fileName = propValue.toString();
                                break;
                            }
                        }
                    }

                }
                LOGGER.info("fileName after for" + fileName);

                boolean isVersionableAspect = (jsonObject != null && jsonObject
                        .keySet()
                            .toString()
                            .contains(PARAM_VERSIONABLE)) ? true : false;

                boolean success = false;

                // String fileName = field.getFilename();
                Content content = field.getContent();
                InputStream is = content.getInputStream();
                String mimeType = request.getParameter("mimeType");// getting the actual MIMETYPE from internal server
                                                                   // from request obj

                LOGGER.error("fileName :: " + fileName + " \t mimetype :: " + mimeType + " \t  parentNode :: "
                        + parentNode);

                BufferedInputStream inputStream = new BufferedInputStream(is);
                boolean isFileExist = false;
                NodeRef uploadFileNode = null;
                Date extCreatedDate = null;
                Date extExpiryDate = null;
                boolean isExpirationDateChanged = false;
                try
                {
                    String encoding = request.getParameter(PARAM_ENCODING);
                    if (encoding == null || encoding.length() == 0)
                    {
                        ContentCharsetFinder charsetFinder = mimetypeService.getContentCharsetFinder();
                        Charset charset = charsetFinder.getCharset(inputStream, mimeType);
                        encoding = charset.name();
                    }

                    String docExchangeFolderPath = "";
                    String qnamePath = serviceRegistry
                            .getNodeService()
                                .getPath(parentNode)
                                .toDisplayPath(serviceRegistry.getNodeService(), serviceRegistry.getPermissionService());
                    String parentFolderName = (String) nodeService.getProperty(parentNode, ContentModel.PROP_NAME);
                    LOGGER.info("qnamePath :::" + qnamePath + "parentFolderName :::" + parentFolderName);
                    if (qnamePath.contains("/documentLibrary"))
                    {
                        String[] parts = qnamePath.split("/documentLibrary");
                        if (qnamePath.endsWith("/documentLibrary"))
                        {
                            docExchangeFolderPath = "/" + parentFolderName;
                        }
                        else
                        {
                            qnamePath = parts[1];
                            docExchangeFolderPath = qnamePath + "/" + parentFolderName;
                        }
                    }

                    String docCentralFolderPath = request.getParameter(FOLDER_PATH);

                    LOGGER.info("docCentralFolderPath " + docCentralFolderPath + " docExchangeFolderPath : "
                            + docExchangeFolderPath);

                    NodeRef externalNode = null;
                    String strExtNodeRef = request.getParameter("strExtNodeRef");

                    NodeRef existFileNodeRef = fileFolderService.searchSimple(parentNode, fileName);
                    if (strExtNodeRef != null && !strExtNodeRef.equals("")
                            && strExtNodeRef.contains("workspace://SpacesStore/"))
                    {
                        externalNode = new NodeRef(strExtNodeRef);
                    }
                    if (externalNode != null && nodeService.exists(externalNode)
                            && docCentralFolderPath.equals(docExchangeFolderPath))
                    {
                        hasDocumentCheckdout(externalNode);

                        WFMailRootscopedObject mailRootscopedObject = new WFMailRootscopedObject(serviceRegistry);
                        mailRootscopedObject.cancelWFandSendMail(externalNode.toString(), ACTION_NAME,
                            currentLoginUserName, bannerAlfrescoUrl);

                        uploadFileNode = externalNode;
                        isFileExist = true;
                    }
                    else if (existFileNodeRef != null)
                    {
                        hasDocumentCheckdout(existFileNodeRef);

                        WFMailRootscopedObject mailRootscopedObject = new WFMailRootscopedObject(serviceRegistry);
                        mailRootscopedObject.cancelWFandSendMail(existFileNodeRef.toString(), ACTION_NAME,
                            currentLoginUserName, bannerAlfrescoUrl);

                        uploadFileNode = existFileNodeRef;
                        isFileExist = true;
                    }
                    else
                    {
                        LOGGER.info("ELSE creatign new file ::: ");
                        uploadFileNode = createContentNode(parentNode, fileName, mimeType);
                    }

                    LOGGER.info(" isFileExist :: " + isFileExist + " \t isOverWrite ::  " + isOverWrite
                            + "\t isVersionableAspect :: " + isVersionableAspect);

                    String obj = request.getParameter(PARAM_ATTACH_FILE_METADATA);
                    boolean attachFileMetadata = false;
                    if (obj != null && !obj.trim().equals(EMPTY_STRING))
                    {
                        attachFileMetadata = Boolean.parseBoolean(obj);
                    }
                    LOGGER.info(" Is attachFileMetadata ? " + attachFileMetadata);

                    // attachSharableAspect(request, uploadFileNode);
                    Map<QName, Serializable> shareableAspectValues = new HashMap<QName, Serializable>();
                    shareableAspectValues.put(MigrationConstants.CISCO_EXTERNAL_IS_EXTERNALLY_SHARED_PROP, true);
                    if (serviceRegistry.getNodeService().hasAspect(uploadFileNode,
                        MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT))
                    {
                        serviceRegistry.getNodeService().setProperty(uploadFileNode,
                            MigrationConstants.CISCO_EXTERNAL_IS_EXTERNALLY_SHARED_PROP, true);
                    }
                    else
                    {
                        serviceRegistry.getNodeService().addAspect(uploadFileNode,
                            MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT, shareableAspectValues);
                    }

                    // if (!isFileExist)
                    if (!isFileExist || (isFileExist && isOverWrite && !isVersionableAspect))
                    {

                        if (attachFileMetadata)
                        {
                            attachMandatoryMetadata(request, uploadFileNode);
                        }
                        attachPermissions(request, uploadFileNode);
                        nodeService.setProperty(uploadFileNode, ContentModel.PROP_NAME, fileName);
                    }
                    else if (isFileExist && isOverWrite && isVersionableAspect)
                    {
                        if (attachFileMetadata)
                        {
                            attachMandatoryMetadata(request, uploadFileNode);
                        }
                        attachPermissions(request, uploadFileNode);
                        nodeService.setProperty(uploadFileNode, ContentModel.PROP_NAME, fileName);
                    }
                    else if (isFileExist && !isOverWrite)
                    {
                        result.put("statusMessage", "File already exist.");
                        result.put("uploadFolderNodeRef", parentNode.toString());
                        result.put("uploadFileNodeRef", uploadFileNode.toString());
                        result.put("fileName", fileName);
                        return result;
                    }
                    // try {
                    ContentWriter writer = contentService.getWriter(uploadFileNode, ContentModel.PROP_CONTENT, true);
                    if (writer != null)
                    {
                        writer.setMimetype(mimeType);
                        writer.setEncoding("UTF-8");
                        writer.putContent(inputStream);
                        // added by Saranyan - Start
                        Map<String, Serializable> versionProperties = new HashMap<String, Serializable>();

                        versionProperties.put(VersionModel.PROP_VERSION_TYPE, VersionType.MAJOR);

                        // Deepak
                        versionProperties.put(ContentModel.PROP_AUTO_VERSION_PROPS.getLocalName(), false);
                        // Deepak

                        final Version version1_1 = versionService.createVersion(uploadFileNode, versionProperties);
                        LOGGER.info("Stored next version of node: " + version1_1.getVersionLabel());
                        // added by Saranyan - End
                        // dhshaw
                        nodeService.setProperty(uploadFileNode, ContentModel.PROP_AUTO_VERSION_PROPS, false);
                        nodeService.setProperty(uploadFileNode, CiscoModelConstants.CISCO_WORKFLOW_STATUS_PROP, "NA");
                        // dhshaw
                        //start US8623 Publish a file from Doc Central to multiple target folders in Doc Exchange
                        String strExtTargetNodeRef = request.getParameter("externalTargetNodeRefID");
                        String publisherId = request.getParameter(MigrationConstants.PARAM_PUBLISHER);
                        LOGGER.info("strExtTargetNodeRef Folder nodes :: "+strExtTargetNodeRef);
                        if(strExtTargetNodeRef != null && !strExtTargetNodeRef.equals("")&& strExtTargetNodeRef.contains("workspace://SpacesStore/")){
                        List<String> externalTargetNodeRefs = new ArrayList<String>(Arrays.asList(strExtTargetNodeRef.split(",")));
                        if(externalTargetNodeRefs.contains(parentNode.toString())){
                        	 LOGGER.info("source Folder nodes :::"+parentNode);
                			externalTargetNodeRefs.remove(parentNode.toString());
                		}
                        //LOGGER.info("externalTargetNodeRefs.size() Folder nodes:::::::::::: "+externalTargetNodeRefs.size());
                        LOGGER.info("externalTargetNodeRefs Folder nodeRefs ::::: "+externalTargetNodeRefs.toString());
                        if(!externalTargetNodeRefs.isEmpty() && externalTargetNodeRefs.size()>0){
                        for (int i = 0; i < externalTargetNodeRefs.size(); i++) {
                        	 if(externalTargetNodeRefs.get(i) != null && !externalTargetNodeRefs.get(i).equals("")&& externalTargetNodeRefs.get(i).contains("workspace://SpacesStore/")){
                        	NodeRef folderNodeId = new NodeRef(externalTargetNodeRefs.get(i));
                        	 if(nodeService.exists(folderNodeId)){
                        		 LOGGER.info("Updated Found Copy of node in target folder for :: " +uploadFileNode +" in Folder node:: "+folderNodeId);
                        		 PagingRequest pagingRequest = new PagingRequest(1);
                        		 PagingResults<CopyInfo> previousCopiesOfPublishNodePage = serviceRegistry.getCopyService().getCopies(uploadFileNode, folderNodeId, pagingRequest);
                        		 List<CopyInfo> pageResultsPublishedNodes = previousCopiesOfPublishNodePage.getPage();
                        		 if (!previousCopiesOfPublishNodePage.getPage().isEmpty() && previousCopiesOfPublishNodePage.getPage().size()>0)
                        	      {
                        			 List<NodeRef> publishedNoderesults = new ArrayList<NodeRef>(pageResultsPublishedNodes.size());
                        			 for (CopyInfo copyInfo : pageResultsPublishedNodes)
                        			 {
                        				 publishedNoderesults.add(copyInfo.getNodeRef());
                        			 }
                        			 //LOGGER.info("Copying of publishedNoderesults ::: " +publishedNoderesults.size());
                        			 LOGGER.info("Copying of publishedNoderesults ::: " +publishedNoderesults.toString());
                        			 //start of cancel checkout and workflows
                        			 hasDocumentCheckdout(publishedNoderesults.get(0));
                                     WFMailRootscopedObject mailRootscopedObject = new WFMailRootscopedObject(serviceRegistry);
                                     mailRootscopedObject.cancelWFandSendMail(publishedNoderesults.get(0).toString(), ACTION_NAME,
                                         currentLoginUserName, bannerAlfrescoUrl);
                                     //end of cancel checkout and workflows
                        			 //String edcsId=(String)serviceRegistry.getNodeService().getProperty(publishedNoderesults.get(0), CiscoModelConstants.PROP_ALF_ID);
                        			 //Start of DE3828
                                     //serviceRegistry.getCopyService().copy(uploadFileNode, publishedNoderesults.get(0));
                                     ciscoCopyService.copy(uploadFileNode, publishedNoderesults.get(0));
                                     attachPermissions(request, publishedNoderesults.get(0));
                        			 //set creator edcsId and owner for copied node
                        			 //LOGGER.info("Copying of publishedNoderesults edcsId ::: " +edcsId);
                        			 //serviceRegistry.getNodeService().setProperty(publishedNoderesults.get(0), CiscoModelConstants.PROP_ALF_ID, edcsId);
                        			 serviceRegistry.getNodeService().setProperty(publishedNoderesults.get(0), ContentModel.PROP_CREATOR, publisherId);
                        	         if (serviceRegistry.getNodeService().hasAspect(publishedNoderesults.get(0), ContentModel.ASPECT_OWNABLE))
                        	            {
                        	                serviceRegistry.getNodeService().setProperty(publishedNoderesults.get(0), ContentModel.PROP_OWNER, publisherId);
                        	            }
                        	         else
                        	            {
                        	                Map<QName, Serializable> ownableAspectValues = new HashMap<QName, Serializable>();
                        	                ownableAspectValues.put(ContentModel.PROP_OWNER, publisherId);
                        	                serviceRegistry.getNodeService().addAspect(publishedNoderesults.get(0), ContentModel.ASPECT_OWNABLE,
                        	                    ownableAspectValues);
                        	            }
                        	         Map<String, Serializable> copyVersionProperties = new HashMap<String, Serializable>();
                        	         copyVersionProperties.put(VersionModel.PROP_VERSION_TYPE, VersionType.MAJOR);
                        	         final Version copyVersion1_1 = versionService.createVersion(publishedNoderesults.get(0), copyVersionProperties);
                                     LOGGER.info("Stored next copy version of node::: " + copyVersion1_1.getVersionLabel());
                        	         //end of set creator and owner for copied node
                                     //DE4867 audit 
                                     String externalUsers = request.getParameter("externalUsers");
                                     auditPublishedDocument((NodeRef)publishedNoderesults.get(0), publisherId, externalUsers);
                        	            LOGGER.info(" publisher Updated Found Copy of node  :::" + publisherId);
                        	            LOGGER.info(" cm:creator Updated Found Copy of node::: "+ serviceRegistry.getNodeService().getProperty(uploadFileNode, ContentModel.PROP_CREATOR));
                        			 
                        	      }else{
                        	    	  LOGGER.info("Fisrt time Copying of node: " +uploadFileNode +" to Folder node::::: "+folderNodeId);
                        	    	  //Start of DE3828
                        	    	  String uniquieFileName=getUniqueFileName(fileName,folderNodeId);
                        	    	  LOGGER.info("Fisrt time Copying of nodes unique filename: " +uniquieFileName);
                        	        	FileInfo copiedInfo=serviceRegistry.getFileFolderService().copy(uploadFileNode, folderNodeId,uniquieFileName);
                        	        	//set creator edcsId and owner for copied node
                           			 serviceRegistry.getNodeService().setProperty(copiedInfo.getNodeRef(), ContentModel.PROP_CREATOR, publisherId);
                           			 //serviceRegistry.getNodeService().setProperty(copiedInfo.getNodeRef(), CiscoModelConstants.PROP_ALF_ID, getAlfrescoEdcsId());
                           	         if (serviceRegistry.getNodeService().hasAspect(copiedInfo.getNodeRef(), ContentModel.ASPECT_OWNABLE))
                           	            {
                           	                serviceRegistry.getNodeService().setProperty(copiedInfo.getNodeRef(), ContentModel.PROP_OWNER, publisherId);
                           	            }
                           	         else
                           	            {
                           	                Map<QName, Serializable> ownableAspectValues = new HashMap<QName, Serializable>();
                           	                ownableAspectValues.put(ContentModel.PROP_OWNER, publisherId);
                           	                serviceRegistry.getNodeService().addAspect(copiedInfo.getNodeRef(), ContentModel.ASPECT_OWNABLE,
                           	                    ownableAspectValues);
                           	            }
                           	      Map<String, Serializable> copyVersionProperties = new HashMap<String, Serializable>();
                           	      copyVersionProperties.put(VersionModel.PROP_VERSION_TYPE, VersionType.MAJOR);
                           	      final Version copyVersion1_1 = versionService.createVersion(copiedInfo.getNodeRef(), copyVersionProperties);
                                  LOGGER.info("Stored next copy version of node: " + copyVersion1_1.getVersionLabel());
                           	         //end of set creator and owner for copied node
                                  //DE4867 audit 
                                  String externalUsers = request.getParameter("externalUsers");
                                  auditPublishedDocument(copiedInfo.getNodeRef(), publisherId, externalUsers);
                        	        }
                        	 }else{
                        		 //ContentModel.PROP_LINK_DESTINATION
                        		 LOGGER.info("Folder Node doesn't exists to Copying of node: " +uploadFileNode +" to Folder node::::: "+folderNodeId);
                        	 }
                        	}
                        }
                        }
                        }else{
                        	//in case of republish of published copied documents
                        	PagingRequest pagingRequest = new PagingRequest(1000);
                   		 	PagingResults<CopyInfo> previousCopiesOfPublishNodePage = serviceRegistry.getCopyService().getCopies(uploadFileNode, pagingRequest);
                   		 	List<CopyInfo> pageResultsPublishedNodes = previousCopiesOfPublishNodePage.getPage();
                   		 	if (!previousCopiesOfPublishNodePage.getPage().isEmpty() && previousCopiesOfPublishNodePage.getPage().size()>0)
                   		 	{
                   		 	LOGGER.info("Updated Found Copy of node::: " +uploadFileNode +" in case of auto publish & republish");
                   		 		List<NodeRef> publishedNoderesults = new ArrayList<NodeRef>(pageResultsPublishedNodes.size());
                   		 		for (CopyInfo copyInfo : pageResultsPublishedNodes)
                   		 		{
                   		 			publishedNoderesults.add(copyInfo.getNodeRef());
                   		 			//start of cancel checkout and workflows
                   		 			hasDocumentCheckdout(copyInfo.getNodeRef());
                   		 			WFMailRootscopedObject mailRootscopedObject = new WFMailRootscopedObject(serviceRegistry);
                   		 			mailRootscopedObject.cancelWFandSendMail(copyInfo.getNodeRef().toString(), ACTION_NAME,
                                     currentLoginUserName, bannerAlfrescoUrl);
                   		 			 attachPermissions(request, copyInfo.getNodeRef());
                   		 			//end of cancel checkout and workflows
                   		 			//String edcsId=(String)serviceRegistry.getNodeService().getProperty(copyInfo.getNodeRef(), CiscoModelConstants.PROP_ALF_ID);
                   		 			//Start of DE3828
                   		 			//serviceRegistry.getCopyService().copy(uploadFileNode, copyInfo.getNodeRef());
                   		 			 ciscoCopyService.copy(uploadFileNode, copyInfo.getNodeRef());
                   		 			 //set creator, owner,edcsId and version for copied node
                   		 		 //LOGGER.info("previous edcsId for copy of node: " + edcsId);
                   		 		 //serviceRegistry.getNodeService().setProperty(copyInfo.getNodeRef(), CiscoModelConstants.PROP_ALF_ID, edcsId);
                   		 		 serviceRegistry.getNodeService().setProperty(copyInfo.getNodeRef(), ContentModel.PROP_CREATOR, publisherId);
                      	         if (serviceRegistry.getNodeService().hasAspect(copyInfo.getNodeRef(), ContentModel.ASPECT_OWNABLE))
                      	            {
                      	                serviceRegistry.getNodeService().setProperty(copyInfo.getNodeRef(), ContentModel.PROP_OWNER, publisherId);
                      	            }
                      	         else
                      	            {
                      	                Map<QName, Serializable> ownableAspectValues = new HashMap<QName, Serializable>();
                      	                ownableAspectValues.put(ContentModel.PROP_OWNER, publisherId);
                      	                serviceRegistry.getNodeService().addAspect(copyInfo.getNodeRef(), ContentModel.ASPECT_OWNABLE,
                      	                    ownableAspectValues);
                      	            }
                      	         	Map<String, Serializable> copyVersionProperties = new HashMap<String, Serializable>();
                      	         	copyVersionProperties.put(VersionModel.PROP_VERSION_TYPE, VersionType.MAJOR);
                      	         	final Version copyVersion1_1 = versionService.createVersion(copyInfo.getNodeRef(), copyVersionProperties);
                               LOGGER.info("Stored next copy version of node::: " + copyVersion1_1.getVersionLabel());
                      	         	//end of set creator and owner for copied node
                               //DE4867 audit 
                               String externalUsers = request.getParameter("externalUsers");
                               auditPublishedDocument(copyInfo.getNodeRef(), publisherId, externalUsers);
                   		 		}
                   		 	LOGGER.info("final Copying of publishedNoderesults ::: " +publishedNoderesults.toString());
                   		 	}
                        }
                        	
                       //end of  US8623
                        
                        extCreatedDate =(Date) serviceRegistry.getNodeService().getProperty(uploadFileNode, ContentModel.PROP_CREATED);
                        extExpiryDate =(Date) serviceRegistry.getNodeService().getProperty(uploadFileNode, MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP);
						isExpirationDateChanged = serviceRegistry.getNodeService().getProperty(uploadFileNode,
								MigrationConstants.IS_EXP_DATE_CHANGED_PROP) == null ? false
										: (boolean) serviceRegistry.getNodeService().getProperty(uploadFileNode,
												MigrationConstants.IS_EXP_DATE_CHANGED_PROP);
                        LOGGER.info("isExpirationDateChanged------" +isExpirationDateChanged);
                        success = true;
                    }

                    // setModifierOnParent(parentNode, request.getParameter(MigrationConstants.PARAM_PUBLISHER));

                }
                catch (Exception e)
                {
                    LOGGER.error("Exception while writing content :: " + e, e);
                    result.put(PARAM_STATUS_MSG, (e != null) ? e.getMessage() : NULL_EXCEPTION);
                    result.put(PARAM_FOLDER_NODE_REF, parentNode.toString());
                    result.put(PARAM_FILE_NODE_REF, String.valueOf(uploadFileNode));
                    result.put(PARAM_FILE_NAME, fileName);
                    result.put("extCreatedDate", "");
                    result.put("extExpiryDate", "");
                    result.put("isExpirationDateChanged", "");
                }
                finally
                {
                    if (inputStream != null)
                    {
                        inputStream.close();
                    }
                    if (is != null)
                    {
                        is.close();
                    }
                    LOGGER.info("In FileMetaDataServieImpl.writeContent() End ");
                }

                if (success)
                {
                    result.put(PARAM_STATUS_MSG, "File Uploaded successfully.");
                    result.put(PARAM_FOLDER_NODE_REF, parentNode.toString());
                    result.put(PARAM_FILE_NODE_REF, uploadFileNode.toString());
                    result.put(PARAM_FILE_NAME, fileName);
                    result.put("extCreatedDate", extCreatedDate.toString());
                    result.put("extExpiryDate", extExpiryDate.toString());
                    result.put("isExpirationDateChanged", isExpirationDateChanged);
                    result.put(MigrationConstants.PARAM_IS_FILE_EXIST, isFileExist);
                }

                recordPublishAuditIno(request, result);
                LOGGER.error("Final Result in WriteContent method is : " + result.toString());
                return result;
            }
        }, ADMIN_USER);
    }

    /*
     * private void attachSharableAspect(final WebScriptRequest request, final NodeRef uploadFileNode) {
     * 
     * AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
     * 
     * @Override public Object doWork() throws Exception {
     * 
     * ChildAssociationRef childAssociationRef = serviceRegistry.getNodeService().getPrimaryParent( uploadFileNode);
     * NodeRef parentFolderNodeRef = childAssociationRef.getParentRef();
     * 
     * Map<QName, Serializable> shareableAspectValues = new HashMap<QName, Serializable>();
     * shareableAspectValues.put(MigrationConstants.CISCO_EXTERNAL_IS_EXTERNALLY_SHARED_PROP, true);
     * 
     * if (serviceRegistry.getNodeService().hasAspect(parentFolderNodeRef,
     * MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT)) {
     * serviceRegistry.getNodeService().setProperty(parentFolderNodeRef,
     * MigrationConstants.CISCO_EXTERNAL_IS_EXTERNALLY_SHARED_PROP, true); } else {
     * serviceRegistry.getNodeService().addAspect(parentFolderNodeRef,
     * MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT, shareableAspectValues); }
     * 
     * if (serviceRegistry.getNodeService().hasAspect(uploadFileNode,
     * MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT)) {
     * serviceRegistry.getNodeService().setProperty(uploadFileNode,
     * MigrationConstants.CISCO_EXTERNAL_IS_EXTERNALLY_SHARED_PROP, true); } else {
     * serviceRegistry.getNodeService().addAspect(uploadFileNode, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT,
     * shareableAspectValues); }
     * 
     * return null; } }, ADMIN_USER);
     * 
     * }
     */

    /**
     * 
     * @param tagNodeRef
     * @param tagsList
     */
    public void attachTagAttributes(NodeRef tagNodeRef, WebScriptRequest request) throws Exception
    {
        String tagAttributes = request.getParameter(PARAM_TAGGING_ATTRIBUTES);
        LOGGER.info(" tagAttributes  =  " + tagAttributes);
        List<String> tagsList = new ArrayList<String>();
        for (String tag : tagAttributes.split(","))
        {
            tagsList.add(tag.trim());
        }
        if (tagsList.size() > 0)
        {
            this.serviceRegistry.getTaggingService().addTags(tagNodeRef, tagsList);
        }

    }

    // added by mkatnam for publish audit application.
    /**
     * auditing publish event info
     * 
     * @param req
     * @param result
     * @throws java.text.ParseException
     * @throws Exception
     */
    public void recordPublishAuditIno(WebScriptRequest req, Map<String, Object> result)
            throws java.text.ParseException, Exception
    {
        try
        {
            LOGGER.error(" Execution started recordPublishAuditIno()");
            java.text.SimpleDateFormat sourceFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss ZZZ yyyy");
            java.text.SimpleDateFormat destFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
            Date expDate;

            NodeRef node = new NodeRef((String) result.get(PARAM_FILE_NODE_REF));
            String prefixPath = nodeService.getPath(node).toPrefixString(serviceRegistry.getNamespaceService());

            Map<QName, Serializable> nodeProp = nodeService.getProperties(node);

            Version currentVersion = versionService.getCurrentVersion(node);

            Map<String, Serializable> auditValues = new HashMap<String, Serializable>();
            auditValues.put("docname", nodeProp.get(ContentModel.PROP_NAME));
            auditValues.put("creator", req.getParameter(MigrationConstants.PARAM_PUBLISHER));
            auditValues.put("publisher", req.getParameter(MigrationConstants.PARAM_PUBLISHER));
            auditValues.put("path", nodeService.getPath(node).toDisplayPath(nodeService, permissionService));
            auditValues.put("edcsid", nodeProp.get(CiscoModelConstants.PROP_ALF_ID));
            auditValues.put("security", nodeProp.get(CiscoModelConstants.CISCO_SECURITY_PROP));
            if (nodeProp.get(MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP) != null)
            {
                expDate = sourceFormat.parse(nodeProp.get(
                    MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP).toString());
                TimeZone timeZone = TimeZone.getTimeZone("GMT");
                destFormat.setTimeZone(timeZone);
                String gmtFormat = destFormat.format(expDate);
                auditValues.put("publishExpirationDate", gmtFormat);
            }
            auditValues.put("publishedDate", nodeProp.get(ContentModel.PROP_MODIFIED));
            auditValues.put("externalUsers", req
                    .getParameter(MigrationConstants.PARAM_EXTERNAL_USERS)
                        .toString()
                        .replaceAll(",", ";"));
            auditValues.put("description", nodeProp.get(ContentModel.PROP_DESCRIPTION));
            auditValues
                    .put("contentSize", CharUtil.formatFileSize(fileFolderService.getReader(node).getContentData().getSize()));
            auditValues.put("status", nodeProp.get(CiscoModelConstants.PROP_DOC_STATUS));
            auditValues.put("workflowStatus", nodeProp.get(CiscoModelConstants.CISCO_WORKFLOW_STATUS_PROP));
            auditValues.put("modified", nodeProp.get(ContentModel.PROP_MODIFIED));
            auditValues.put("modifier", req.getParameter(MigrationConstants.PARAM_PUBLISHER));
            auditValues.put("event", "PUBLISH");
            auditValues.put("noderef", node);
            auditValues.put("prefixPath", prefixPath);
            if (currentVersion != null)
            {
                auditValues.put("version", currentVersion.getVersionLabel());
            }
            
            String docPublisher = req.getParameter(MigrationConstants.PARAM_PUBLISHER);
			String userEmail = "";
			String company = "";
			PersonService personService = serviceRegistry.getPersonService();
			if (docPublisher != null && personService.personExists(docPublisher)) {
				NodeRef currentLoginUserRef = personService.getPerson(docPublisher);
				userEmail = (String) nodeService.getProperty(currentLoginUserRef, ContentModel.PROP_EMAIL);
				company = (String) nodeService.getProperty(currentLoginUserRef, ContentModel.PROP_ORGANIZATION);
			}
			
			auditValues.put("email", userEmail);
			auditValues.put("company", company);

            LOGGER.error(" Calling Audit compoent ");
            LOGGER.error(" Audit Values ::" + auditValues.toString());
            auditComponent.recordAuditValues("/publish-report/document", auditValues);
            LOGGER.error(" Audit component called successfully");

        }
        catch (WebScriptException e)
        {
            LOGGER.error(" Exception while parsing publish audit info " + e);
        }

    }

    public void hasDocumentCheckdout(NodeRef docNodeRef) throws Exception
    {
        NodeRef workingCopyNodeRef = serviceRegistry.getCheckOutCheckInService().getWorkingCopy(docNodeRef);
        LOGGER.info("workingCopyNodeRef : " + workingCopyNodeRef);
        if (workingCopyNodeRef != null)
        {
            serviceRegistry.getCheckOutCheckInService().cancelCheckout(workingCopyNodeRef);
        }
    }

    /**
     * get docID for documents
     */
    public Serializable getAlfrescoEdcsId() {
            Serializable alfrescoId = 0;
            LOGGER.info("Invoking docID gen Bean");
            alfrescoId = docIdGenBean.getDocIdNextVal();
            LOGGER.info(" After: New EDCS ID: " + alfrescoId);
            return alfrescoId;
    }
    /**
     * get unique name for documents
     */
    public String getUniqueFileName(String name , NodeRef parentNodeRef){
    	boolean fileNameExists=true;
    	String filename=name;
    	String tempFileName=name;
    	int dotIndex,counter=1;
    	while(fileNameExists){
    		NodeRef node =serviceRegistry.getFileFolderService().searchSimple(parentNodeRef, tempFileName);
    		if(node!=null){
    			dotIndex = filename.lastIndexOf(".");
				if (dotIndex == 0) {
					// File didn't have a proper 'name' instead it had just a suffix and started with a ".", create "1.txt"
					tempFileName = counter + filename;
				} else if (dotIndex > 0) {
					// Filename contained ".", create "filename-1.txt"
					tempFileName = filename.substring(0, dotIndex) + "_"	+ counter + filename.substring(dotIndex);
				} else {
					// Filename didn't contain a dot at all, create "filename-1"
					tempFileName = filename + "-" + counter;
				}
    			counter++;
    		}else{
    			fileNameExists=false;
    		}
    	}
    	
    	return tempFileName;
    }
    /**
     * auditing multiple target folder publish event info
     * 
     * @param node
     * @param publisher
     * @param externalUsers
     * @throws java.text.ParseException
     * @throws Exception
     */
    private void auditPublishedDocument(NodeRef node, String publisher, String externalUsers) throws java.text.ParseException, Exception
    {
    	try
        {
            LOGGER.error(" Execution started recordPublishAuditIno()");
            java.text.SimpleDateFormat sourceFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss ZZZ yyyy");
            java.text.SimpleDateFormat destFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
            Date expDate;
            String prefixPath = nodeService.getPath(node).toPrefixString(serviceRegistry.getNamespaceService());
            Map<QName, Serializable> nodeProp = nodeService.getProperties(node);
            Version currentVersion = versionService.getCurrentVersion(node);
            Map<String, Serializable> auditValues = new HashMap<String, Serializable>();
            auditValues.put("docname", nodeProp.get(ContentModel.PROP_NAME));
            auditValues.put("creator", publisher);
            auditValues.put("publisher", publisher);
            auditValues.put("path", nodeService.getPath(node).toDisplayPath(nodeService, permissionService));
            auditValues.put("edcsid", nodeProp.get(CiscoModelConstants.PROP_ALF_ID));
            auditValues.put("security", nodeProp.get(CiscoModelConstants.CISCO_SECURITY_PROP));
            if (nodeProp.get(MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP) != null)
            {
                expDate = sourceFormat.parse(nodeProp.get(
                    MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP).toString());
                TimeZone timeZone = TimeZone.getTimeZone("GMT");
                destFormat.setTimeZone(timeZone);
                String gmtFormat = destFormat.format(expDate);
                auditValues.put("publishExpirationDate", gmtFormat);
            }
            auditValues.put("publishedDate", nodeProp.get(ContentModel.PROP_MODIFIED));
            auditValues.put("externalUsers", externalUsers.replaceAll(",", ";"));
            auditValues.put("description", nodeProp.get(ContentModel.PROP_DESCRIPTION));
            auditValues.put("contentSize", CharUtil.formatFileSize(fileFolderService.getReader(node).getContentData().getSize()));
            auditValues.put("status", nodeProp.get(CiscoModelConstants.PROP_DOC_STATUS));
            auditValues.put("workflowStatus", nodeProp.get(CiscoModelConstants.CISCO_WORKFLOW_STATUS_PROP));
            auditValues.put("modified", nodeProp.get(ContentModel.PROP_MODIFIED));
            auditValues.put("modifier", publisher);
            auditValues.put("event", "PUBLISH");
            auditValues.put("noderef", node);
            auditValues.put("prefixPath", prefixPath);
            if (currentVersion != null)
            {
                auditValues.put("version", currentVersion.getVersionLabel());
            }
            
			String userEmail = "";
			String company = "";
			PersonService personService = serviceRegistry.getPersonService();
			if (publisher != null && personService.personExists(publisher)) {
				NodeRef currentLoginUserRef = personService.getPerson(publisher);
				userEmail = (String) nodeService.getProperty(currentLoginUserRef, ContentModel.PROP_EMAIL);
				company = (String) nodeService.getProperty(currentLoginUserRef, ContentModel.PROP_ORGANIZATION);
			}
			auditValues.put("email", userEmail);
			auditValues.put("company", company);
            LOGGER.error(" Calling Audit compoent ");
            LOGGER.error(" Audit Values ::" + auditValues.toString());
            auditComponent.recordAuditValues("/publish-report/document", auditValues);
            LOGGER.error(" Audit component called successfully");
        }
        catch (WebScriptException e)
        {
            LOGGER.error(" Exception while parsing publish audit info " + e);
        }
    }
    
}
