package com.cisco.sd.rest.service;

import static com.cisco.sd.rest.service.MigrationConstants.ADMIN_USER;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

public class DuplicateFileNameCheck extends DeclarativeWebScript {
	private static final Logger LOG = Logger.getLogger(DuplicateFileNameCheck.class);

	private ServiceRegistry serviceRegistry;

	public void setServiceRegistry(ServiceRegistry registry) {
		this.serviceRegistry = registry;
	}
	
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status,	Cache cache) {

		final Map<String, Object> result = new HashMap<String, Object>();
		
		try{
			List<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();
			final String parameters = req.getParameter("jsonParameters");
			LOG.info("Parameter String is : " + parameters);
			org.json.JSONArray jsonArray = new JSONArray(parameters);
			for (int i = 0; i < jsonArray.length(); i++)
			{
				org.json.JSONObject jsonObj = jsonArray.getJSONObject(i);
				HashMap<String, String> documentInfoMap =  checkDuplicateFileNames(jsonObj);
				list.add(documentInfoMap);
			}
			
			result.put("filesList", list);
			
		} catch(Exception e){
			LOG.error("Exception from duplicate File check is : " + e.getStackTrace(),e);
		}
		

		return result;
	}
	
private HashMap<String, String> checkDuplicateFileNames(org.json.JSONObject json) throws JSONException, Exception{
		
		final String filename = json.getString("fileName");
		final String externalNodeRefString = json.getString("externalNodeRef");
		final String folderPath = json.getString("folderPath");
		final HashMap<String, String> documentInfo = new HashMap<String, String>();
		
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			public Object doWork() throws Exception {

				int counter = 1, dotIndex;
				String tmpFilename = "";
				NodeRef existingFolderRef = null;
				boolean isFileNameAlreadyExists = false;
				boolean isExternalNodeRefExists = false;

				NodeRef parentFolderNodeRef = serviceRegistry.getSiteService().getContainer("edcsng", "documentlibrary");
				LOG.info("externalSharingFolderNodeRef : " + parentFolderNodeRef);
				String[] folderPathSplit = folderPath.split("/");
				NodeRef parentNodeRef = null;
				
				/**
				 * Checking for the document's parent folder location in the repository startign from the documentlibrary using database services.
				 * (In doc exchange lucene is creating problem. thats the reason used database services for finding the folder location)
				 */
				if(parentFolderNodeRef != null){
					if(folderPathSplit != null){
						for(int i=0; i < folderPathSplit.length;i++){
							if(folderPathSplit[i] != null && !folderPathSplit[i].isEmpty()){
								if(i == 1){
									parentNodeRef = serviceRegistry.getFileFolderService().searchSimple(parentFolderNodeRef, folderPathSplit[i]);
									if(parentNodeRef == null){
										break;
									}
								} else {
									parentNodeRef = serviceRegistry.getFileFolderService().searchSimple(parentNodeRef, folderPathSplit[i]);
									if(parentNodeRef == null){
										break;
									}
								}
							}
						}
					}
				}
				LOG.info("finla fodler node ref : " + parentNodeRef);
				
				/**
				 * First check for the file name in parent folder.
				 * if the document name exist in the folder then rename the filename with '_' (ex: sample_1.txt)
				 */
				if(parentNodeRef != null){
					existingFolderRef = serviceRegistry.getFileFolderService().searchSimple(parentNodeRef, filename);

					while (existingFolderRef != null) {
						dotIndex = filename.lastIndexOf(".");
						if (dotIndex == 0) {
							// File didn't have a proper 'name' instead it had just a suffix and started with a ".", create "1.txt"
							tmpFilename = counter + filename;
						} else if (dotIndex > 0) {
							// Filename contained ".", create "filename-1.txt"
							tmpFilename = filename.substring(0, dotIndex) + "_"	+ counter + filename.substring(dotIndex);
						} else {
							// Filename didn't contain a dot at all, create "filename-1"
							tmpFilename = filename + "-" + counter;
						}
						existingFolderRef = serviceRegistry.getFileFolderService().searchSimple(parentNodeRef, tmpFilename);
						counter++;
					}
					
					LOG.info("oldFileName is ::: " + filename + " ;NewFileName is : " + tmpFilename);
					if(!tmpFilename.isEmpty() && !filename.equals(tmpFilename)){
						isFileNameAlreadyExists = true;
					}
					
					
					if(externalNodeRefString != null && !externalNodeRefString.isEmpty() && externalNodeRefString.contains("workspace://SpacesStore/")){
						NodeRef externalNodeRef = new NodeRef(externalNodeRefString);
						isExternalNodeRefExists = serviceRegistry.getFileFolderService().exists(externalNodeRef);						
					}
				}
				
				documentInfo.put("fileName", tmpFilename);
				documentInfo.put("isFileNameAlreadyExists", String.valueOf(isFileNameAlreadyExists));
				documentInfo.put("isExternalNodeRefExists", String.valueOf(isExternalNodeRefExists));
				documentInfo.put("existingFileName", filename);

				return null;
			}
		}, ADMIN_USER);
		
		return documentInfo;
	}

}
