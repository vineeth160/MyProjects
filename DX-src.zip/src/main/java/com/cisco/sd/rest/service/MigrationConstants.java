package com.cisco.sd.rest.service;

import org.alfresco.service.namespace.QName;


/**
 * 
 * @author gpotla
 * 
 */
public class MigrationConstants
{

    final static String CISCO_EXT_URI = "http://www.alfresco.org/model/external/content/1.0";

    public static final String RETENTION_ASPECT = "recordsInfo";

    public static final String ADMIN_USER = "admin";

    public static final String PARAM_ATTACH_FOLDER_METADATA = "attachFolderMetadata";

    public static final String PARAM_ATTACH_FOLDER_TAGGING = "attachFolderTagging";

    public static final String PARAM_ATTACH_FILE_TAGGING = "attachFileTagging";

    public static final String PARAM_TAGGING_ATTRIBUTES = "taggingAttributes";

    public static final String PARAM_ATTACH_FILE_METADATA = "attachFileMetadata";

    public static final String PARAM_CONTENT_OWNER = "contentowner";

    public static final String PARAM_JSON_METADATA = "jsonMetadata";

    public static final String PARAM_QNAME = "aspectQName";

    public static final String PARAM_JSON_COMMON_PROPS = "jsonCommonProperties";

    public static final String PARAM_OVERWRITE = "overwrite";

    public static final String PARAM_VERSIONABLE = "versionable";

    public static final String PARAM_MIMETYPE = "fileMimeType";

    public static final String PARAM_ENCODING = "encoding";

    public static final String CISCO_MODEL_NAMESPACE = "http://www.cisco.com/model/content/1.0";

    public static final QName CISCODOC_TYPE = QName.createQName(CISCO_MODEL_NAMESPACE, "ciscodoc");

    public static final String PROP_RETENTION_PERIOD = "retentionPeriod";

    public static final String PROP_RETENTION_START_RANGE = "retentionStartRange";

    public static final String PROP_RETENTION_END_RANGE = "retentionEndRange";

    public static final String ROOT_PATH = "rootPath";

    public static final String FOLDER_PATH = "folderPath";

    public static final String PARAM_FOLDER_NODE_REF = "uploadFolderNodeRef";

    public static final String PARAM_STATUS_MSG = "statusMessage";

    public static final String PARAM_FILE_NODE_REF = "uploadFileNodeRef";

    public static final String PARAM_FILE_NAME = "fileName";

    public static final String PARAM_FIELD = "filedata";

    public static final String PARAM_ROOT_PATH_NODE_REF = "rootPathNodeRef";

    public static final String PERM_OWNER_ROLE = "OwnerRole";

    public static final String NULL_EXCEPTION = "java.lang.NullPointerException";

    public static final String FILE_EXCEPTION = "File not imported due to exception.";

    public static final String EMPTY_STRING = "";

    public static final String PARAM_PERM_ROLE = "permRole";

    public static final String PARAM_INHERIT_PERM = "isInheritPerm";

    public static final String PARAM_EXTERNAL_USERS = "externalUsers";

    public static final String PARAM_PUBLISH_EXPIRATION_DATE_STR = "publishExpirationDateStr";

    public final static QName CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP = QName.createQName(CISCO_EXT_URI,
        "publishExpirationDate");

    public static final String PERM_USER_ROLE = "UserRole";

    public static final String PERM_VIEWER_ROLE = "ViewerRole";

    public static final String PERM_READER_ROLE = "ReaderRole";

    public static final String PERM_EDITOR_ROLE = "EditorRole";
    
    public static final String PERM_FOLDER_ADMIN_ROLE = "AdminRole";

    public static final String PARAM_PUBLISHER = "publisher";

    public static final String PARAM_IS_FILE_EXIST = "isFileExist";

    public final static QName CISCO_EXTERNAL_USERS_PROP = QName.createQName(CISCO_EXT_URI, "externalUsers");

    public final static QName CISCO_EXTERNAL_SHARAEABLE_ASPECT = QName.createQName(CISCO_EXT_URI, "extShareableAspect");

    public final static QName CISCO_EXTERNAL_IS_EXTERNALLY_SHARED_PROP = QName.createQName(CISCO_EXT_URI,
        "isExternalyShared");
    
    // added by mkatnam for external Users
    
    public final static QName CISCO_EXTERNAL_USER_ASPECT = QName.createQName(CISCO_EXT_URI, "externalUserAspect");
    public final static QName CISCO_EXTERNAL_USER_ACCESS_PROP = QName.createQName(CISCO_EXT_URI, "extUserAccessLevel");
    
    // mkatnam end
    
    // vepagada Start
    //added for fodler or doc move reason
    public final static QName CISCO_MOVECOMMENT_ASPECT = QName.createQName(CISCO_EXT_URI, "moveReasonAspect");
    public final static QName CISCO_QNAME_COMMENT_REASON_PROP = QName.createQName(CISCO_EXT_URI, "moveReason");
    
  //added for domain aspect
  	public static final QName CISCO_DOMAIN_ASPECT = QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domainAspect");
  	public static final QName CISCO_DOMAIN_NAME_PROP = QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name");
  	//vepagada End
  	
  	public static final QName IS_EXP_DATE_CHANGED_PROP = QName.createQName("{http://www.alfresco.org/model/external/content/1.0}isExpirationDateChanged");
    
    /**
     * 
     */
    private MigrationConstants()
    {

    }

}
