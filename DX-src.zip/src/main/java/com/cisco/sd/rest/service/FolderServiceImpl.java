package com.cisco.sd.rest.service;

import static com.cisco.sd.rest.service.MigrationConstants.EMPTY_STRING;
import static com.cisco.sd.rest.service.MigrationConstants.NULL_EXCEPTION;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_ATTACH_FOLDER_METADATA;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_ATTACH_FOLDER_TAGGING;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_CONTENT_OWNER;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_FOLDER_NODE_REF;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_JSON_METADATA;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_OVERWRITE;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_QNAME;
import static com.cisco.sd.rest.service.MigrationConstants.PARAM_STATUS_MSG;
import static com.cisco.sd.rest.service.MigrationConstants.RETENTION_ASPECT;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.transaction.NotSupportedException;
import javax.transaction.SystemException;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.transaction.RetryingTransactionHelper.RetryingTransactionCallback;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileFolderService;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthenticationService;
import org.alfresco.service.cmr.security.AuthorityService;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.MutableAuthenticationService;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.apache.lucene.queryParser.QueryParser;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.manageMailerGroups.MailerGroupSearchUtil;

/**
 * 
 * @author gpotla
 * 
 */
public class FolderServiceImpl implements IFolderService {

	private static final Logger LOG = Logger.getLogger(FolderServiceImpl.class);

	private static String zoneId = AuthorityService.ZONE_AUTH_EXT_PREFIX + "ldap";
	private static final String GROUP_IDENTITY ="GROUP_";
	private static final String CISCO_MAILID="@cisco.com";
	
	private ServiceRegistry serviceRegistry;
	private NodeService nodeService;
	protected FileFolderService fileFolderService;
	private FileMetaDataServieImpl fileMetaDataService;
	private BehaviourFilter policyFilter;
	private PermissionService permissionService;
	private AuditComponent auditComponent;
	private PersonService personService;
	private AuthenticationService authenticationService;
	private ExternalLDAPUtil ldapUtil;
	private MailerGroupSearchUtil mailerGroupLdapUtil;
	
	public PermissionService getPermissionService() {
		return permissionService;
	}

	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}

	public AuditComponent getAuditComponent() {
		return auditComponent;
	}

	public void setAuditComponent(AuditComponent auditComponent) {
		this.auditComponent = auditComponent;
	}

	public BehaviourFilter getPolicyFilter()
	{
		return policyFilter;
	}

	public void setPolicyFilter(BehaviourFilter policyFilter) {
		this.policyFilter = policyFilter;
	}

	public void setServiceRegistry(ServiceRegistry registry) {
		this.serviceRegistry = registry;
	}

	public FileMetaDataServieImpl getFileMetaDataService() {
		return fileMetaDataService;
	}

	public void setFileMetaDataService(FileMetaDataServieImpl fileMetaDataService) {
		this.fileMetaDataService = fileMetaDataService;
	}

	public ExternalLDAPUtil getLdapUtil() {
		return ldapUtil;
	}

	public void setLdapUtil(ExternalLDAPUtil ldapUtil) {
		this.ldapUtil = ldapUtil;
	}
	public MailerGroupSearchUtil getMailerGroupLdapUtil() {
		return mailerGroupLdapUtil;
	}

	public void setMailerGroupLdapUtil(MailerGroupSearchUtil mailerGroupLdapUtil) {
		this.mailerGroupLdapUtil = mailerGroupLdapUtil;
	}

	/**
	 * 
	 */
	 public void loadConfig() {
		LOG.info("In FolderServiceImpl.loadConfig() Start ");
		this.fileFolderService = serviceRegistry.getFileFolderService();
		personService = serviceRegistry.getPersonService();
		authenticationService = serviceRegistry.getAuthenticationService();
		//result = new HashMap<String, Object>();
	 }

	 /**
	  * Checking for folder path existance. if not we are creating
	  * 
	  * @param rootPath
	  * @param folderPath
	  * @param request
	  * @return 
	  * @throws Exception
	  */
	 public synchronized Map<String, Object> constructFolderPath(final String rootPath, final String folderPath, final WebScriptRequest request, final String externalUsers) throws Exception {

		 LOG.info("construct folder path method:");

		 return serviceRegistry.getTransactionService().getRetryingTransactionHelper().doInTransaction(new RetryingTransactionCallback<Map<String, Object>>() {
			 @Override
			 public Map<String, Object> execute() throws Throwable {
				 if(externalUsers != null && !externalUsers.isEmpty()){
					 addExternalUsers(externalUsers);
				 }
				 return createFolder(rootPath, folderPath, request);
			 }
		 }, false, true);
	 }

	 /**
	  * 
	  * @param rootPath
	  * @param folderPath
	  * @param request
	  * @return
	  * @throws Exception
	  */
	 private Map<String, Object> createFolder(String rootPath, String folderPath, final WebScriptRequest request) throws Exception {
		 LOG.info("In FolderServiceImpl.constructFolderPath Start ");
		 NodeRef existingFolderRef = null;
		 String folderPathQry = rootPath;
		 String[] folderNames = folderPath.split("/");
		 String existingPath = rootPath;
		 Map<String, Object> result = new HashMap<String, Object>();
		 String dataClassification = request.getParameter("dataClassification");

		 LOG.info("rootPath = " + existingPath + "\t  folderPath = " + folderPath);

		 try {
			 NodeRef parentNodeRef = EDCSUtil.doSearch(folderPathQry + "\"", serviceRegistry);
			 boolean isOverWrite = Boolean.valueOf(request.getParameter(PARAM_OVERWRITE));

			 for (int i = 0; i < folderNames.length; i++) {
				 existingFolderRef = null;
				 if (folderNames[i] != null && !folderNames[i].trim().equals(EMPTY_STRING)) {

					 folderPathQry = folderPathQry + "/cm:" + QueryParser.escape(folderNames[i]);

					 LOG.info(" folderPathQry ::: " + folderPathQry + "  ;;parentNodeRef : " + parentNodeRef);

					 existingFolderRef = fileFolderService.searchSimple(parentNodeRef, folderNames[i]);
					 folderPath = folderPath.substring(folderPath.indexOf(folderNames[i]), folderPath.length());
					 LOG.info(" Folder Path is " + folderPath);

					 LOG.info(" ExistingFolderRef from fileFolderService.searchSimple is " + existingFolderRef);
					 if (existingFolderRef == null) {

						 //folderPath = folderPath.substring(folderPath.indexOf(folderNames[i]), folderPath.length());

						 LOG.info(" Folder Path exist. we are creating  at from " + folderPath);
						 existingFolderRef = createFolderPath(existingPath, folderPath, parentNodeRef, request);

						 LOG.info("After commition final nodeRef is " + existingFolderRef);
						 result.put(PARAM_STATUS_MSG, "Folder created successfully!!!");
						 result.put(PARAM_FOLDER_NODE_REF, existingFolderRef);

						 addSharableAspectToLastLeafFolder(existingFolderRef, request);
						 if(dataClassification != null && "Cisco Restricted".equals(dataClassification)){
							 applyVeraProtectionToLastLeafFolder(existingFolderRef, request.getParameter(MigrationConstants.PARAM_PUBLISHER));
						 }
						// addTitledAspect(existingFolderRef, request);

						 return result;
					 } else {
						 // if already the folder path is existing
						 existingPath = folderPathQry;
						 parentNodeRef = existingFolderRef;

						 if(isOverWrite) {
							 attachTagsToFolders(request, parentNodeRef);
						 }
						 result.put(PARAM_STATUS_MSG, "Folder already exist!!!");
						 result.put(PARAM_FOLDER_NODE_REF, existingFolderRef);
					 }
				 }
			 }

			 /**
			  * If folder path already exist then we need to add following Aspects
			  */
			 if (!(serviceRegistry.getNodeService().hasAspect(existingFolderRef, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT))) {
				 LOG.error(" foder admins about to create ...");
				 createFolderAdmins(request.getParameter("folderAdmin"), existingFolderRef);
			 }
			 /*List<FileInfo> files = fileFolderService.listFiles(existingFolderRef);
			 if(files == null || files.size() ==0){
				 
				 createFolderAdmins(request.getParameter("folderAdmin"), existingFolderRef);
			 }*/
			 addSharableAspectToLastLeafFolder(existingFolderRef, request);
			 if(dataClassification != null && "Cisco Restricted".equals(dataClassification)){
				 applyVeraProtectionToLastLeafFolder(existingFolderRef, request.getParameter(MigrationConstants.PARAM_PUBLISHER));
			 }
			 //addTitledAspect(existingFolderRef, request);

		 } catch (Exception e) {
			 LOG.error(" Exception while creating folder ..." + e, e);
			 throw new Exception((e != null) ? e.getMessage() : NULL_EXCEPTION);
		 } finally {
			 LOG.info("In FolderServiceImpl.constructFolderPath() finally block End ");
		 }

		 return result;

	 }

	 /**
	  * creating the folder path under specified root Path
	  * 
	  * @param folderPathQry
	  * @param folderPath
	  * @throws SystemException
	  * @throws NotSupportedException
	  */
	 private NodeRef createFolderPath(final String folderPathQry, final String folderPath, final NodeRef existingNodeRef, final WebScriptRequest request) throws Exception {

		 LOG.info("In FolderServiceImpl.createFolderPath() Start :: folderPath = " + folderPath + " \t folderPathQry = " + folderPathQry);
		 String publisher = request.getParameter(MigrationConstants.PARAM_PUBLISHER);
		 String folderAdminUsers = request.getParameter("folderAdmin");
		 String domainProperty = request.getParameter("domainProperty");
		 LOG.info(" folderAdminUsers are : = " + folderAdminUsers + " ;domain_name Property is : = "+domainProperty + " ;Publisher is : " + publisher);

		 NodeRef parentNodeRef = existingNodeRef;
		 String[] folderNames = folderPath.split("/");

		 String obj = request.getParameter(PARAM_ATTACH_FOLDER_METADATA);
		 boolean attachFolderMetadata = false;
		 if (obj != null && !obj.trim().equals(EMPTY_STRING)) {
			 attachFolderMetadata = Boolean.parseBoolean(obj);
		 }

		 LOG.info(" attachFolderMetadata  =  " + attachFolderMetadata);

		 String contentowner = request.getParameter(PARAM_CONTENT_OWNER);
		 LOG.info(" contentowner = " + contentowner);
		 String folderName = null;
		 FileInfo fileinfo = null;
		 for (int i = 0; i < folderNames.length; i++) {
			 if (folderNames[i] != null && !folderNames[i].trim().equals(EMPTY_STRING)) {
				 folderName = folderNames[i];
				 LOG.info(" Creating folder  with the Name :: " + folderNames[i]);
				 fileinfo = fileFolderService.create(parentNodeRef, folderName, ContentModel.TYPE_FOLDER);
				 parentNodeRef = fileinfo.getNodeRef();
				 
				 addTitledAspect(parentNodeRef,folderName,request);

				 LOG.info(" folder created  at " + folderPath);

				 // setting aspects to the created folders
				 if (attachFolderMetadata) {
					 attachMetaData(request, parentNodeRef);
				 }

				 // setting Tag attributes to the created folders
				 attachTagsToFolders(request, parentNodeRef);

				 // Setting the content owner to the created folders
				 serviceRegistry.getOwnableService().setOwner(parentNodeRef, contentowner);
				 LOG.info(" contentowner set to --- > " + parentNodeRef + " as " + contentowner);

				 // adding domainAspect to the Parent node
				 if(domainProperty != null && !domainProperty.isEmpty()){
					 Map<QName, Serializable> domainProp = new HashMap<QName, Serializable>(1);
					 domainProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"),domainProperty);
					 serviceRegistry.getNodeService().addAspect(parentNodeRef,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domainAspect"), domainProp);
				 }

				 //added by vpotnuru for domain audit
				 if(domainProperty != null && domainProperty.length() >0){
					 recordAuditInfo(parentNodeRef,folderName,null,domainProperty.replaceAll(",", ";"),publisher,"Domain Added");
				 }

				 //setting Folder Admin on newly created last leaf folder

				 if((i+1) == folderNames.length){
					 createFolderAdmins(folderAdminUsers, parentNodeRef);
				 }

				 try{ 

					 /**
					  * Setting Creator and Modifier as PUBLISHER on newly created folders
					  */
					 nodeService = serviceRegistry.getNodeService();
					 policyFilter.disableBehaviour(parentNodeRef, ContentModel.ASPECT_AUDITABLE);
					 nodeService.setProperty(parentNodeRef, ContentModel.PROP_CREATOR, publisher);
					 nodeService.setProperty(parentNodeRef, ContentModel.PROP_MODIFIER, publisher);
					 LOG.info(" Folder CREATOR:: "+nodeService.getProperty(parentNodeRef, ContentModel.PROP_CREATOR));
				 } finally {
					 policyFilter.enableBehaviour(parentNodeRef,ContentModel.ASPECT_AUDITABLE);
					 LOG.info(" modifyDefaultProperties - finally enabled.");
				 }

			 }

		 }
		 LOG.info("parentNodeRef : " + parentNodeRef);
		 return parentNodeRef;
	 }
	 
	 private void createFolderAdmins(String folderAdminUsers, final NodeRef parentNodeRef) throws Exception {
		 LOG.info("Folder admin mehtod started..");
		 if(folderAdminUsers != null && !folderAdminUsers.isEmpty()){
			 String[] folderAdminUsersArray = folderAdminUsers.split(",");
			 //final NodeRef parentNode = fileinfo.getNodeRef();
			 boolean isPermInhirited = serviceRegistry.getPermissionService().getInheritParentPermissions(parentNodeRef);
			 if(isPermInhirited){
				 serviceRegistry.getPermissionService().setInheritParentPermissions(parentNodeRef, false);
			 }
			 final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
			 AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				 @Override
				 public Object doWork() throws Exception {
					 accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(parentNodeRef));
					 return null;
				 }
			 }, "admin");

			 if(isPermInhirited){
				 serviceRegistry.getPermissionService().setInheritParentPermissions(parentNodeRef, true);
			 }

			 //Checking whether user already  presented on the parent folder or not?
			 for(int k=0; k<folderAdminUsersArray.length;k++){
				 if(folderAdminUsersArray[k] != null && !(folderAdminUsersArray[k].isEmpty() || folderAdminUsersArray[k].contains(GROUP_IDENTITY))){
					 boolean isUserPresentedOnParent = false;

					 for (AccessPermission accessPermissionObj : accessPermission) {
						 if(accessPermissionObj.getAuthority().equals(folderAdminUsersArray[k]) && accessPermissionObj.getPermission().equals(MigrationConstants.PERM_FOLDER_ADMIN_ROLE)){
							 isUserPresentedOnParent = true;
							 LOG.info("User "+folderAdminUsersArray[k]+ " alread presented. so, not addig on newly created folder : ");
						 }
					 }
					 if(!isUserPresentedOnParent){
						 LOG.info("User "+folderAdminUsersArray[k]+" added on folder  : ");
						 serviceRegistry.getPermissionService().setPermission(parentNodeRef, folderAdminUsersArray[k], MigrationConstants.PERM_FOLDER_ADMIN_ROLE, true);
					 }
				 }
			 }

		 }
	 }

	 /**
	  * 
	  * @param request
	  * @param uploadFileNode
	  * @return
	  */
	 private void attachMetaData(final WebScriptRequest request, final NodeRef uploadFileNode)throws Exception {
		 LOG.info(" In folder attachMetaData...");

		 Map<QName, Serializable> metaDataProps = null;

		 JSONParser jsonParser = new JSONParser();
		 JSONObject aspectsJsonObject = null;
		 try {
			 aspectsJsonObject = (JSONObject) jsonParser.parse(request.getParameter(PARAM_JSON_METADATA));
			 LOG.info(" aspects JsonObject = " + aspectsJsonObject);
			 String aspect = null;
			 String aspectQname = null;
			 for (Object aspectName : aspectsJsonObject.keySet()) {
				 metaDataProps = new HashMap<QName, Serializable>();

				 aspect = aspectName.toString();

				 LOG.info("Aspect = " + aspect);

				 JSONArray jsonArray = (JSONArray) aspectsJsonObject.get(aspectName);

				 if (aspect.equals(RETENTION_ASPECT)) {

					 for (Object properties : (JSONArray) aspectsJsonObject.get(aspectName)) {
						 LOG.info("Folder Meta data Properties ::: " + ((JSONObject) properties).keySet());
						 aspectQname = (String) ((JSONObject) properties).get(PARAM_QNAME);
						 break;
					 }
					 metaDataProps = fileMetaDataService.attachRecordsInfoAspect(metaDataProps, aspect, jsonArray);
					 LOG.info("For " + aspect + " metaDataProps  ::: " + metaDataProps);
					 fileMetaDataService.addMetaDataAspect(metaDataProps, aspect.toString(), aspectQname,
							 uploadFileNode);
				 }
			 }

		 } catch (Exception e) {
			 LOG.error(" Exception while parsing json object ..." + e, e);
			 throw new Exception((e != null) ? e.getMessage() : NULL_EXCEPTION);
		 } finally {
			 LOG.info("In FolderServiceImpl.attachMetaData() finally block End ");
		 }
	 }

	 public void recordAuditInfo(NodeRef folderNodeRef, String folderName, String oldDomain, String folderDomain, String publisher, String event) throws Exception {
		 //String modifier = AuthenticationUtil.getFullyAuthenticatedUser();
		 Map<String, Serializable> auditEntry = new HashMap<String, Serializable>();
		 auditEntry.put("foldername",folderName);
		 auditEntry.put("noderef", folderNodeRef);
		 auditEntry.put("creator", publisher);
		 auditEntry.put("modifier", publisher);
		 String nodePath = serviceRegistry.getNodeService().getPath(folderNodeRef).toDisplayPath(serviceRegistry.getNodeService(), permissionService);
		 auditEntry.put("path",nodePath);
		 auditEntry.put("folderprefixpath", serviceRegistry.getNodeService().getPath(folderNodeRef).toPrefixString(serviceRegistry.getNamespaceService()));
		 auditEntry.put("olddomain", oldDomain);
		 auditEntry.put("newdomain",folderDomain );
		 auditEntry.put("event", event);

		 auditComponent.recordAuditValues("/folder-domain/folder", auditEntry);

	 }

	 /**
	  * 
	  * @param request
	  * @param tagNodeRef
	  */
	 private void attachTagsToFolders(WebScriptRequest request, NodeRef tagNodeRef) throws Exception{
		 String folderTagging = request.getParameter(PARAM_ATTACH_FOLDER_TAGGING);
		 boolean attachFolderTagging = false;
		 if (folderTagging != null && !folderTagging.trim().equals(EMPTY_STRING)) {
			 attachFolderTagging = Boolean.parseBoolean(folderTagging);
		 }

		 LOG.info(" attachFolderTagging  =  " + attachFolderTagging);

		 if (attachFolderTagging) {
			 fileMetaDataService.attachTagAttributes(tagNodeRef, request);
		 }

	 }

	 private void addTitledAspect(NodeRef existingFolderRef, String folderName, WebScriptRequest request) throws Exception {
		 LOG.info(" existingFolderRef  =  " + existingFolderRef);
		 nodeService = serviceRegistry.getNodeService();
		 if(!nodeService.hasAspect(existingFolderRef,ContentModel.ASPECT_TITLED)){
			 Map<QName, Serializable> titleAspectProp = new HashMap<QName, Serializable>();
			 
			 if(!request.getParameter("folderTitle").isEmpty()){
				 titleAspectProp.put(ContentModel.PROP_TITLE, request.getParameter("folderTitle"));
			 }else{
				 titleAspectProp.put(ContentModel.PROP_TITLE, folderName);
			 }
			 
			 titleAspectProp.put(ContentModel.PROP_DESCRIPTION, request.getParameter("folderDesc"));
			 nodeService.addAspect(existingFolderRef, ContentModel.ASPECT_TITLED, titleAspectProp);

		 }else{
			 if(nodeService.getProperty(existingFolderRef, ContentModel.PROP_TITLE) == null){
				 nodeService.setProperty(existingFolderRef, ContentModel.PROP_TITLE, request.getParameter("folderTitle"));
			 }
			 if(nodeService.getProperty(existingFolderRef, ContentModel.PROP_DESCRIPTION) == null){
				 nodeService.setProperty(existingFolderRef, ContentModel.PROP_DESCRIPTION, request.getParameter("folderDesc"));
			 }
		 }
	 }
	 
	 private void applyVeraProtectionToLastLeafFolder(NodeRef leafFolderNodeRef, String veraEnabledBy){
		 String applyVeraProtection = (String)serviceRegistry.getNodeService().getProperty(leafFolderNodeRef, ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
		 LOG.info("applyVeraProtection value : " + applyVeraProtection);
		 if(applyVeraProtection == null || applyVeraProtection.isEmpty()){
			 LOG.info("Going to apply Vera Protection..");
			 Map<QName, Serializable> verFolderProtectionProps = new HashMap<>(6);
			 verFolderProtectionProps.put(ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION,"Cisco Restricted");
			 verFolderProtectionProps.put(ExternalSharingConstants.PROP_IS_VERA_ROOT_FOLDER,true);
			 verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ENABLED_DATE,new Date());
			 verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ENABLED_BY,veraEnabledBy);
			 verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ROOT_FOLDER_NODEREF,leafFolderNodeRef.toString());
			 serviceRegistry.getNodeService().addAspect(leafFolderNodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION, verFolderProtectionProps);
		 }
	 }

	 private void addSharableAspectToLastLeafFolder(NodeRef existingFolderRef, WebScriptRequest request) throws Exception {

		 Map<QName, Serializable> shareableAspectValues = new HashMap<QName, Serializable>();
		 shareableAspectValues.put(MigrationConstants.CISCO_EXTERNAL_IS_EXTERNALLY_SHARED_PROP, true);

		 if (serviceRegistry.getNodeService().hasAspect(existingFolderRef, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT))
		 {
			 serviceRegistry.getNodeService().setProperty(existingFolderRef, MigrationConstants.CISCO_EXTERNAL_IS_EXTERNALLY_SHARED_PROP, true);
		 }
		 else
		 {
			 serviceRegistry.getNodeService().addAspect(existingFolderRef, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT, shareableAspectValues);
		 }
	 }

	 public void addExternalUsers(String finalUsers) throws Exception{
		 final Set<String> zoneSet = getZones(zoneId);
		 LOG.info("final users object in folder impl for publish is ======" + finalUsers);
		 String[] ids = finalUsers.split(",");
		 LOG.info("array final users object in folder impl for publish is  ======" + ids.toString());
		 for (int i = 0; i < ids.length; i++)
		 {
			 LOG.info("publush user or group id is ======" + ids[i]);
			 /* Nagaraju Code for grouper sync  START*/
			 if(ids[i].contains(GROUP_IDENTITY)){
			 boolean groupExistInRepo=serviceRegistry.getAuthorityService().authorityExists(ids[i]);
			 LOG.info(ids[i]+" Group ExistInRepo :::::  "+groupExistInRepo);
 			if (!groupExistInRepo)	
              {
 				 createLDAPGroupInRepository(ids[i]);
              }
 			 /* Nagaraju Code for grouper sync  END*/
			 }else{
			 boolean isUserExists = personService.personExists(ids[i]);
			 if (!isUserExists)
			 {
				 String firstName = "", lastName = "";
				 String idAndName = ldapUtil.getUserDetailsFromLDAP(ids[i]);
				 String userName = (idAndName.split("::"))[0];
				 String name = (idAndName.split("::"))[1];
				 String organization = (idAndName.split("::"))[2];
				 if (name.contains(" "))
				 {
					 firstName = (name.split(" "))[0];
					 lastName = (name.split(" "))[1];
				 }
				 else
					 firstName = name;

				 String email = ldapUtil.getManagerEmailFromLDAP(ids[i]);
				 LOG.info("email ======" + email);

				 /* boolean isUserExists = personService.personExists(userName);
            if (!isUserExists)
            {*/
				 final HashMap<QName, Serializable> properties = new HashMap<QName, Serializable>();
				 properties.put(ContentModel.PROP_USERNAME, userName);
				 // properties.put(ContentModel.PROP_HOMEFOLDER, userNodeRef);
				 properties.put(ContentModel.PROP_FIRSTNAME, firstName);
				 properties.put(ContentModel.PROP_LASTNAME, lastName);
				 properties.put(ContentModel.PROP_EMAIL, email);
				 properties.put(ContentModel.PROP_ORGANIZATION, organization);
				 LOG.info("zoneSet ======" + zoneSet + " properties : " + properties.toString());

				/* NodeRef newPerson = serviceRegistry.getTransactionService().getRetryingTransactionHelper().doInTransaction(new RetryingTransactionCallback<NodeRef>(){
					 @Override
					 public NodeRef execute() throws Throwable {

						 return personService.createPerson(properties, zoneSet);
						 //return null;
					 }
				 }, false, true);*/

				 NodeRef newPerson = personService.createPerson(properties, zoneSet);

				 // added by mkatnam for External User Access Level -- Start
				 if(!serviceRegistry.getNodeService().hasAspect(newPerson, MigrationConstants.CISCO_EXTERNAL_USER_ASPECT)){
					 Map<QName, Serializable> extUserProp = new HashMap<QName, Serializable>();
					 LOG.info("::before calling accessLevel::");
					 int accessLevel = Integer.parseInt(ldapUtil.getUserAccessLevelFromLDAP(ids[i]));
					 LOG.info("::after calling accessLevel::>" +accessLevel);
					 extUserProp.put(MigrationConstants.CISCO_EXTERNAL_USER_ACCESS_PROP, accessLevel);
					 serviceRegistry.getNodeService().addAspect(newPerson, MigrationConstants.CISCO_EXTERNAL_USER_ASPECT, extUserProp);
				 }
				 //mkatnam --END

				 // authenticationService.getAuthenticationEnabled("");
				 LOG.info("newPerson::" + newPerson);
				 // ensure the user can access their own Person object
				 // permissionService.setPermission(newPerson,"GROUP_EVERYONE", permissionService.getAllPermission(),
				 // true);
				 // create the ACEGI Authentication instance for the new user
				 ((MutableAuthenticationService) authenticationService).createAuthentication(userName, userName.toCharArray());
			 }
		 }
		 }
	 }
	 /* Nagaraju Code for grouper sync  START*/
	 /**
	     * @param groupId
	     * @return create group with members
	     */
	    @SuppressWarnings("unused")
		public void createLDAPGroupInRepository(String groupId)
	    {
	    	String groupType="allgroups";//mailer or hrgroup or allgroups
	    	LOG.info("Looking for members for " + groupId);
	    	groupId = groupId.replaceAll(GROUP_IDENTITY, "");
	    	LOG.info("group name is ::"+groupId);
			Map<String, Set<String>> members = mailerGroupLdapUtil.getGroupMembers(groupId);
			LOG.info("again the real group name is::"+groupId);
			//LOG.info("totel members in group"+members);
			LOG.info("size of the members"+ members.size());
			if( members.size() > 1) {
				LOG.info("Unable to create groups. Search for " + groupId + " " +
						"matched multiple group names and it must match only a single group.");
			} else if( members.size() == 0 ) {
				LOG.info("Unable to create groups. Search for " + groupId + " " +
						"matched no group names.");
			} else {
				for( Entry<String, Set<String>> curGroup : members.entrySet() ) {
					String displayName = curGroup.getKey();
					
					String givenName = serviceRegistry.getAuthorityService().createAuthority(AuthorityType.GROUP, groupId);
					displayName=displayName.replace("displayName: ", "");
					LOG.info("Created group " + givenName + " with display " + displayName );
					serviceRegistry.getAuthorityService().setAuthorityDisplayName(givenName, displayName);
					List<String> groupAsList = Arrays.asList(new String [] { givenName });
					//Add users!
					for( String childName : curGroup.getValue() ){
						LOG.info("User Exited in Repo :" +childName);
						String userEmail = ldapUtil.getManagerEmailFromLDAP(childName);
						if(userEmail!=null && userEmail!="" ){
						LOG.info("user email address::"+userEmail);
						 boolean isCiscoDomainUser = userEmail.contains(CISCO_MAILID);
						 LOG.info("is user exists in cisco::"+isCiscoDomainUser);
						//Adding only cisco domain users to Groups
						if(isCiscoDomainUser && serviceRegistry.getPersonService().getPerson(childName) != null)
							serviceRegistry.getAuthorityService().addAuthority(groupAsList, childName);
						else
							LOG.info("Couldn't find authority to add: " + childName);
						}else{
							LOG.info("Couldn't add inactive user authority to group: " + childName);
						}
					}
					LOG.info("Added " + serviceRegistry.getAuthorityService().getContainedAuthorities(null, givenName, true).size());
				}
				LOG.info("Successfully created group ::::  " + groupId);
			}
	    }
	    /* Nagaraju Code for grouper sync  End*/

	 private Set<String> getZones(final String zoneId) throws Exception {
		 Set<String> zones = new HashSet<String>(5);
		 zones.add(AuthorityService.ZONE_APP_DEFAULT);
		 zones.add(zoneId);
		 LOG.info("zones : " + zones + " service is : " + AuthorityService.ZONE_APP_DEFAULT);
		 return zones;
	 }


}
