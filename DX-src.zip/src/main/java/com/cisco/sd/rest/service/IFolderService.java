package com.cisco.sd.rest.service;

import java.util.Map;

import org.springframework.extensions.webscripts.WebScriptRequest;


/**
 * 
 * @author gpotla
 * 
 */
public interface IFolderService
{

	public Map<String, Object> constructFolderPath(String rootPath, String folderPath, WebScriptRequest request, String externalUsers) throws Exception;

	public void addExternalUsers(String users) throws Exception;

}
