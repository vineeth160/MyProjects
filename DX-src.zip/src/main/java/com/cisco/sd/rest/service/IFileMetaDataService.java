package com.cisco.sd.rest.service;

import java.io.Serializable;
import java.util.Map;

import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.QName;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.servlet.FormData;


/**
 * 
 * @author gpotla
 * 
 */
public interface IFileMetaDataService
{

    public Map<String, Object> writeContent(FormData.FormField field, NodeRef parentNode, WebScriptRequest request) throws Exception;

    public void addMetaDataAspect(Map<QName, Serializable> metaDataProps, String aspectName, String queueName, NodeRef currentNodeRef) throws Exception;

}
