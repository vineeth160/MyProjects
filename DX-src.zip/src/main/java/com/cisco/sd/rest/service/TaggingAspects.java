package com.cisco.sd.rest.service;

import java.io.Serializable;
import java.util.Map;

import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.QName;
import org.json.simple.JSONArray;
import org.springframework.extensions.webscripts.WebScriptRequest;


/**
 * 
 * @author gpotla
 * 
 */
public abstract class TaggingAspects
{

    /**
     * 
     * @param metaDataProps
     * @param aspectName
     * @param jsonArray
     * @return
     */
    public abstract Map<QName, Serializable> attachRecordsInfoAspect(Map<QName, Serializable> metaDataProps,
            String aspectName, JSONArray jsonArray) throws Exception;

    /**
     * 
     * @param tagNodeRef
     * @param tagsList
     * @throws Exception 
     */
    public abstract void attachTagAttributes(NodeRef tagNodeRef, WebScriptRequest request) throws Exception;

}
