package com.cisco.migration.service.webscripts;

import static com.cisco.migration.service.webscripts.MigrationConstants.NULL_EXCEPTION;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FILE_NODE_REF;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_STATUS_MSG;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.version.VersionType;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

/**
 * 
 * @author gpotla
 * 
 */
public class MigrationVersionableAspectWebScript extends DeclarativeWebScript {

    private static final Logger LOG = Logger.getLogger(MigrationVersionableAspectWebScript.class);

    private ServiceRegistry serviceRegistry;
    
    private NodeService nodeService;

    public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}


	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}


	/**
     * 
     */
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status,
			Cache cache) {
		LOG.info("In MigrationVersionableAspectWebScript.executeImpl() Start ");
		
		Map<String, Object> result = new HashMap<String, Object>();
		
		String docNodeRef = req.getParameter(MigrationConstants.PARAM_BASE_FILE_NODEREF);
		try{
			if(docNodeRef != null && !docNodeRef.trim().equals("")) {
				String statusMsg = attachVersionableAspect(new NodeRef(docNodeRef));
				result.put(PARAM_STATUS_MSG, statusMsg);
	            result.put(PARAM_FILE_NODE_REF, docNodeRef);
			}else{
				result.put(PARAM_STATUS_MSG, "Please provide the Base File NodeRef.");
	            result.put(PARAM_FILE_NODE_REF, "");
			}
			
			} catch (Exception e) {
				LOG.error(" Exception while Adding aspect ..." + e, e);
				result.put(PARAM_STATUS_MSG, (e != null) ? e.getMessage() : NULL_EXCEPTION);
	            result.put(PARAM_FILE_NODE_REF, "");
			} finally {
				LOG.info("In MigrationVersionableAspectWebScript.executeImpl() finally block End ");
			}
			

        return result;
	}
	
	
	 /**
     * 
     * @param contentNodeRef
     */
    public String attachVersionableAspect(NodeRef contentNodeRef) throws Exception {

        LOG.info(" MigrationVersionableAspectWebScript.attachVersionableAspect() UploadNodeRef ::: " + contentNodeRef);
        String statusMsg = " Versionable Aspect already added.";
        boolean hasAspect = this.serviceRegistry.getVersionService().isVersioned(contentNodeRef);
        
        try {
	        if (!hasAspect) {
	            Map<QName, Serializable> versionProperties = new HashMap<QName, Serializable>();
	            versionProperties.put(ContentModel.PROP_VERSION_TYPE, VersionType.MAJOR);
	            versionProperties.put(ContentModel.PROP_AUTO_VERSION_PROPS, false);
	            versionProperties.put(ContentModel.PROP_AUTO_VERSION, false);
	            this.nodeService.addAspect(contentNodeRef, ContentModel.ASPECT_VERSIONABLE, versionProperties);
	            statusMsg = " Versionable Aspect added.";
	        }
        }catch (Exception e) {
            LOG.error(" Exception while adding versionable Aspect..." + e, e);
            throw new Exception(e.getMessage());
        }finally {
        	LOG.info(" MigrationVersionableAspectWebScript.attachVersionableAspect() finally block ");
        }
        
        return statusMsg;
    }

}
