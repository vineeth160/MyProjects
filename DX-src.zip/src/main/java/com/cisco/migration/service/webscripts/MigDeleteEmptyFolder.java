package com.cisco.migration.service.webscripts;

import java.util.HashMap;
import java.util.Map;
import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;


public class MigDeleteEmptyFolder extends DeclarativeWebScript{

    private static final Logger LOGGER = Logger.getLogger(MigDeleteEmptyFolder.class);

    private ServiceRegistry serviceRegistry;

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	/**
     * @param req
     * @param status
     * @param cache
     */
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status,
			Cache cache) {
		LOGGER.info("In MigDeleteEmptyFolder.executeImpl() Start ");
		
		Map<String, Object> result = new HashMap<String, Object>();
		
		String docNodeRef = req.getParameter("nodeRef");
		try{
			if(docNodeRef != null && !docNodeRef.trim().equals("")) {
				String statusMsg = deleteFolder(new NodeRef(docNodeRef));
				result.put("STATUS", statusMsg);
			}else{
				result.put("STATUS", "Please provide the Base Folder NodeRef.");
			}
			
			} catch (Exception e) {
				LOGGER.error(" Exception while Deleting folder ..." + e, e);
				result.put("STATUS", (e != null) ? e.getMessage() : "java.lang.NullPointerException");
			} finally {
				LOGGER.info("In MigDeleteEmptyFolder.executeImpl() finally block End here.. ");
			}
        return result;
	}
	
	
	 /**
     * 
     * @param nodeRef
     */
    public String deleteFolder(NodeRef nodeRef) throws Exception {

        try {
        	int childrensCount = serviceRegistry.getNodeService().countChildAssocs(nodeRef, true);
    		boolean isDocument = serviceRegistry.getDictionaryService()
    				.isSubClass(serviceRegistry.getNodeService().getType(nodeRef), ContentModel.TYPE_CONTENT);
    		if (!isDocument) {
    			LOGGER.error("Noderef is folder++++++++++++++");
    			LOGGER.info("*************** Inside MigDeleteEmptyFolder count *****************" + childrensCount);
    			if (childrensCount == 0) {
    				serviceRegistry.getNodeService().deleteNode(nodeRef);
    				LOGGER.error("folder deleted successfuly");
    				String statusMsg = "SUCCESS";
    				return statusMsg;
    			} else {
    				LOGGER.error("folder is not empty!!!!Delete opertaion can't be performed");
    				String statusMsg = "FAILED";
    				return statusMsg;
    			}

    		} else {
    			LOGGER.error("Noderef is a file!!!Delete opertaion can't be performed");
    			String statusMsg = "FAILED";
				return statusMsg;
    		}
        	
        }catch (Exception e) {
        	LOGGER.error(" Exception while doing MigDeleteEmptyFolders..." + e, e);
            throw new Exception(e.getMessage());
        }finally {
        	LOGGER.info(" MigDeleteEmptyFolder.deleteFolder() finally block ");
        }
    }
	
}	
	
	

