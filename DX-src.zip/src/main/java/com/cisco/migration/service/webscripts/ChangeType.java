package com.cisco.migration.service.webscripts;

import java.util.HashMap;
import java.util.Map;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.QName;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

public class ChangeType extends DeclarativeWebScript {
	private ServiceRegistry serviceRegistry;
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}
	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {
		Map<String,Object> model = new HashMap<String, Object>();
		String nodeRef = req.getParameter("noderef");
		String type = req.getParameter("type");
		try{
			if(nodeRef==null || nodeRef==""){
				status.setCode(Status.STATUS_BAD_REQUEST);
				model.put("status", Status.STATUS_BAD_REQUEST);
				model.put("message", "NodeRef not specified");
			}else if(type==null || type == ""){
				status.setCode(Status.STATUS_BAD_REQUEST);
				model.put("status", Status.STATUS_BAD_REQUEST);
				model.put("message", "Type not specified");
			}else{
				NodeRef node = new NodeRef(nodeRef);
				QName typeQname = QName.createQName(type, serviceRegistry.getNamespaceService());
				serviceRegistry.getNodeService().setType(node,typeQname);
				
				model.put("status", Status.STATUS_ACCEPTED);
				model.put("message", "Successfully changed node type to "+type);
			}
			
		}catch(Exception e){
			model.put("status", Status.STATUS_INTERNAL_SERVER_ERROR);
			model.put("message", e.getMessage());
		}
		return model;
	}

}
