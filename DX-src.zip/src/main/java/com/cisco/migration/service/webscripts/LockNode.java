package com.cisco.migration.service.webscripts;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationComponent;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.coci.CheckOutCheckInService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

/**
 * 
 * @author apulluri
 *
 */

public class LockNode extends DeclarativeWebScript {
	private static final Logger LOG = Logger.getLogger(LockNode.class);
	private ServiceRegistry serviceRegistry;
	private AuthenticationComponent authComponent;
	private CheckOutCheckInService checkOutCheckInService;
	private static final String CHECK_OUT="checkout";
	
	public CheckOutCheckInService getCheckOutCheckInService() {
		return checkOutCheckInService;
	}

	public void setCheckOutCheckInService(
			CheckOutCheckInService checkOutCheckInService) {
		this.checkOutCheckInService = checkOutCheckInService;
	}

	public AuthenticationComponent getAuthComponent() {
		return authComponent;
	}

	public void setAuthComponent(AuthenticationComponent authComponent) {
		this.authComponent = authComponent;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public Map<String, Object> executeImpl(WebScriptRequest req, Status status,
			Cache cache) {
		Map<String,Object> model = new HashMap<String, Object>();
		ResourceBundle propertiesFile = getResources();
		try{
			JSONObject json = new JSONObject(req.getContent().getContent());
			if(!json.has("checkoutOwner")){
				status.setMessage(propertiesFile.getString("message.owner.missing"));
				status.setCode(Status.STATUS_BAD_REQUEST);
			}else if(!json.has("nodeRef")){
				status.setMessage(propertiesFile.getString("message.noderef.missing"));
				status.setCode(Status.STATUS_BAD_REQUEST);
			}else if(!json.has("mode")){
				status.setMessage(propertiesFile.getString("message.mode.missing"));
				status.setCode(Status.STATUS_BAD_REQUEST);
			}else{
				final NodeRef contentNode = new NodeRef(json.getString("nodeRef").toString());
				final String userName = json.getString("checkoutOwner");
				final String mode = json.getString("mode");
				String nodeName = serviceRegistry.getNodeService().getProperty(contentNode, ContentModel.PROP_NAME).toString();
				authComponent.setCurrentUser(userName);
				AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>(){
					@Override
					public Object doWork() throws Exception {
						if(mode.equalsIgnoreCase(CHECK_OUT)){
							
							NodeRef checkedOutRef = checkOutCheckInService.checkout(contentNode);
						}else{
							NodeRef checkedInRef = checkOutCheckInService.getWorkingCopy(contentNode);						
							checkOutCheckInService.checkin(checkedInRef,null);
						}
						return null;
					}
					
				}, "admin");
				status.setCode(Status.STATUS_OK);
				status.setMessage(MessageFormat.format(propertiesFile.getString("message.success"), nodeName,mode ));
				model.put("nodeRef", contentNode.toString());
				model.put("owner", userName);
			}
			
		}catch(Exception e){
			status.setCode(Status.STATUS_INTERNAL_SERVER_ERROR);
			status.setMessage(e.getMessage());
			e.printStackTrace();
			LOG.error(e.getStackTrace(),e);
		}
		return model;
	}

}
