package com.cisco.migration.service.webscripts;

import com.cisco.migration.service.util.MigPostScriptConstants;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.version.common.VersionUtil;
import org.alfresco.service.cmr.dictionary.DictionaryService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MigrationApplyPropertiesWS extends AbstractWebScript {

	private static final Logger log = Logger.getLogger(MigrationApplyPropertiesWS.class);

	private VersionService versionService;
	private BehaviourFilter policyFilter;
	private NodeService nodeService;
	private NamespaceService namespaceService;
	private DictionaryService dictionaryService;

	public void setVersionService(VersionService versionService) {
		this.versionService = versionService;
	}

	public void setPolicyFilter(BehaviourFilter policyFilter) {
		this.policyFilter = policyFilter;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public void setNamespaceService(NamespaceService namespaceService) {
		this.namespaceService = namespaceService;
	}

	public void setDictionaryService(DictionaryService dictionaryService) {
		this.dictionaryService = dictionaryService;
	}

	@Override
	public void execute(WebScriptRequest request, WebScriptResponse response) throws IOException {

		// build a json object
		Map<String, Object> responseObj = new HashMap<String, Object>();
		String contentNodeRef = request.getParameter(MigPostScriptConstants.RES_OBJECT_NODEREF);
		String nodeType = request.getParameter(MigPostScriptConstants.PARAM_NODE_TYPE);

		try {
			log.debug("=======================MigrationApplyPropertiesWS===================");
			log.debug("Content NodeRef ===> " + contentNodeRef);
			// log.debug("Properties json ===> " + propertiesJson);

			if (nodeType.equalsIgnoreCase("folder")) {
				String propertiesJson = request.getParameter("properties");
				if ((contentNodeRef != null && !contentNodeRef.isEmpty())
						&& (propertiesJson != null && !propertiesJson.isEmpty())) {
					updateNodeProperties(new NodeRef(contentNodeRef.trim()), propertiesJson, responseObj);
					responseObj.put(MigPostScriptConstants.PARAM_FILE_NODE_REF, contentNodeRef);
					response.getWriter().write(convertMapToJSON(responseObj));
					return;
				} else {
					responseObj.put(MigPostScriptConstants.PARAM_FILE_NODE_REF, contentNodeRef);
					responseObj.put(MigPostScriptConstants.PARAM_STATUS_MSG,
							"eighter content nodeRef of properties json is missing nodeRef value ===> " + contentNodeRef
									+ "  propertiesJson ======> " + propertiesJson);
					response.getWriter().write(convertMapToJSON(responseObj));
					return;
				}
			} else {
				String alfOriginalNodeString = request.getParameter(MigPostScriptConstants.PARAM_ORIGINAL_NODEREF);
				//String docOwner = request.getParameter(MigPostScriptConstants.PARAM_CONTENT_OWNER);
				updateNodeProperties(contentNodeRef, responseObj, alfOriginalNodeString);
				response.getWriter().write(convertMapToJSON(responseObj));
			}
		} catch (Exception ex) {
			log.error(" Exception while updating properties ..." + ex, ex);
			responseObj.put(MigPostScriptConstants.PARAM_STATUS_MSG,
					(ex != null) ? ex.getMessage() : MigPostScriptConstants.NULL_EXCEPTION);
			responseObj.put(MigPostScriptConstants.PARAM_FILE_NODE_REF, contentNodeRef);
			response.getWriter().write(convertMapToJSON(responseObj));
		} finally {
			log.debug("MigrationApplyPropertiesWS execute Method finally block...");
		}

	}

	private void updateNodeProperties(String contentNodeRef, Map<String, Object> responseObj,
			String alfOriginalNodeString) {
		if (contentNodeRef == null || contentNodeRef.isEmpty() || contentNodeRef.length() > 0) {
			responseObj.put(MigPostScriptConstants.PARAM_FILE_NODE_REF, contentNodeRef);
			responseObj.put(MigPostScriptConstants.PARAM_STATUS_MSG,
					"invalid NodeRef null or empty ===> " + contentNodeRef);
		}

		NodeRef alfUpdateNodeRef = new NodeRef(contentNodeRef);
		if (!nodeService.exists(alfUpdateNodeRef)) {
			responseObj.put(MigPostScriptConstants.PARAM_FILE_NODE_REF, contentNodeRef);
			responseObj.put(MigPostScriptConstants.PARAM_STATUS_MSG,
					"NodeRef not exist in the Alfresco Repository ===> " + contentNodeRef);
		}

		try {

			boolean isVersionfileUpate = versionService.isAVersion(alfUpdateNodeRef);
			if (isVersionfileUpate) {

				// Need to check wheather updaing live node or version node.
				if (alfOriginalNodeString != null && nodeService.exists(new NodeRef(alfOriginalNodeString))) {
					NodeRef alfOriginalNodeRef = new NodeRef(alfOriginalNodeString);
					Version currentVersionRef = versionService.getCurrentVersion(alfOriginalNodeRef);
					NodeRef alfOrgNodeVersionNode = currentVersionRef.getFrozenStateNodeRef();
					if (alfOrgNodeVersionNode != null
							&& alfOrgNodeVersionNode.toString().equalsIgnoreCase(alfUpdateNodeRef.toString())) {
						alfUpdateNodeRef = alfOriginalNodeRef;
					} else {
						alfUpdateNodeRef = VersionUtil.convertNodeRef(alfUpdateNodeRef);
					}
				}

			}
			contentNodeRef = alfUpdateNodeRef.toString();
			log.debug("Current Processing NodeRef ===> " + contentNodeRef);
			responseObj.put(MigPostScriptConstants.PARAM_FILE_NODE_REF, contentNodeRef);
			policyFilter.disableBehaviour(alfUpdateNodeRef, ContentModel.ASPECT_AUDITABLE);
			policyFilter.disableBehaviour(alfUpdateNodeRef, MigPostScriptConstants.CISCODOC_TYPE);
			policyFilter.disableBehaviour(alfUpdateNodeRef, ContentModel.ASPECT_VERSIONABLE);

			Map<QName, Serializable> updatePropsMap = new HashMap<>();

			Map<QName, Serializable> alfNodePropMap = nodeService.getProperties(alfUpdateNodeRef);

			Date versionModifiedDate = (Date) alfNodePropMap.get(MigPostScriptConstants.MIG_DOCORIVERMODDATE_PROP);
			String versionModifiedBy = (String) alfNodePropMap.get(MigPostScriptConstants.MIG_DOCORIVERMODBY_PROP);
			Date versionCreatedDate = (Date) alfNodePropMap.get(MigPostScriptConstants.MIG_DOCORIVERCREDATE_PROP);
			String versionCreatedBy = (String) alfNodePropMap.get(MigPostScriptConstants.MIG_DOCORIVERCREBY_PROP);

			// Here we need map the properties for node
			updatePropsMap.put(ContentModel.PROP_MODIFIER, versionModifiedBy);
			updatePropsMap.put(ContentModel.PROP_MODIFIED, versionModifiedDate);

			// updatePropsMap.put(MigPostScriptConstants.MIG_PROP_CONTENT_MODIFIER,
			// versionModifiedBy);
			//updatePropsMap.put(MigPostScriptConstants.MIG_PROP_CONTENT_MODIFIER, versionCreatedBy);
			//updatePropsMap.put(MigPostScriptConstants.MIG_PROP_CONTENT_MODIFIED_DATE, versionCreatedDate);
			//updatePropsMap.put(MigPostScriptConstants.MIG_PROP_RETENTION_BASE_DATE, versionCreatedDate);

			updatePropsMap.put(ContentModel.PROP_IS_CONTENT_INDEXED, Boolean.TRUE);
			updatePropsMap.put(ContentModel.PROP_IS_INDEXED, Boolean.TRUE);
			updatePropsMap.put(ContentModel.PROP_AUTO_VERSION, Boolean.TRUE);

			// updated
			updatePropsMap.put(ContentModel.PROP_CREATOR, versionCreatedBy);
			updatePropsMap.put(ContentModel.PROP_CREATED, versionCreatedDate);

			/*if (nodeService.hasAspect(alfUpdateNodeRef, ContentModel.ASPECT_OWNABLE)) {
				updatePropsMap.put(ContentModel.PROP_OWNER, docOwner);
			} else {
				updatePropsMap.put(ContentModel.PROP_OWNER, docOwner);
				Map<QName, Serializable> ownerProp = new HashMap<>();
				ownerProp.put(ContentModel.PROP_OWNER, docOwner);
				nodeService.addAspect(alfUpdateNodeRef, ContentModel.ASPECT_OWNABLE, ownerProp);
			}*/
			nodeService.addProperties(alfUpdateNodeRef, updatePropsMap);

			policyFilter.enableBehaviour(alfUpdateNodeRef, ContentModel.ASPECT_VERSIONABLE);
			policyFilter.enableBehaviour(alfUpdateNodeRef, MigPostScriptConstants.CISCODOC_TYPE);
			policyFilter.enableBehaviour(alfUpdateNodeRef, ContentModel.ASPECT_AUDITABLE);
			responseObj.put(MigPostScriptConstants.PARAM_STATUS_MSG, " properties updated successfully.. ");
		} catch (Exception ex) {
			responseObj.put(MigPostScriptConstants.PARAM_FILE_NODE_REF, contentNodeRef);
			responseObj.put(MigPostScriptConstants.PARAM_STATUS_MSG, " Exception in Process" + ex);
			log.error("Exception in Process ====> ",ex);
		}

	}

	private void updateNodeProperties(NodeRef contentNodeRef, String propertiesJson, Map<String, Object> responseObj) {

		log.info(" MigrationApplyPropertiesWS.update node props  ::: " + contentNodeRef);
		String statusMsg = "Properties update initiated";
		try {

			if (versionService.isAVersion(contentNodeRef)) {
				contentNodeRef = VersionUtil.convertNodeRef(contentNodeRef);
			}
			Map<QName, Serializable> nodeProps = new HashMap<>();
			Map<String, Serializable> propertiesMap = getPropertiesMap(propertiesJson);
			if (propertiesMap != null && propertiesMap.size() > 0) {
				// Need to convert each key to QName Values
				for (String propStringName : propertiesMap.keySet()) {
					Serializable PROPERTY_VALUE = propertiesMap.get(propStringName);
					String[] propertyName = propStringName.split(":");
					String propPrefix = propertyName[0];
					String propLocalName = propertyName[1];
					String nameSpace = namespaceService.getNamespaceURI(propPrefix);
					QName PROP_QNAME_PROPERTY = QName.createQName(nameSpace, propLocalName);
					nodeProps.put(PROP_QNAME_PROPERTY, PROPERTY_VALUE);
				}

				// Is it a folder
				QName typeQName = nodeService.getType(contentNodeRef);

				if (dictionaryService.isSubClass(typeQName, ContentModel.TYPE_FOLDER)) {
					policyFilter.disableBehaviour(contentNodeRef, ContentModel.ASPECT_AUDITABLE);
					policyFilter.disableBehaviour(contentNodeRef, MigPostScriptConstants.CISCODOC_TYPE);
					nodeService.addProperties(contentNodeRef, nodeProps);
					policyFilter.enableBehaviour(contentNodeRef, ContentModel.ASPECT_AUDITABLE);
					policyFilter.enableBehaviour(contentNodeRef, MigPostScriptConstants.CISCODOC_TYPE);
					statusMsg = '"' + "properties updated successfully.." + '"';
				} else {
					statusMsg = " Skipped to apply properties as it is not a Folder";
				}

			}
		} catch (Exception e) {
			log.error(" Exception while updating propereties...inside updateNodeProperties" + e, e);
			statusMsg = "Exception while updating propereties...inside updateNodeProperties" + e;
			throw e;
		} finally {
			log.info(" MigrationUpdateNodeService.updateNodeDetails() finally block ");
		}
		responseObj.put(MigPostScriptConstants.PARAM_STATUS_MSG, statusMsg);
	}

	private Map<String, Serializable> getPropertiesMap(String propertiesJson) {
		Map<String, Serializable> propertiesMap = new HashMap<>();
		if (propertiesJson != null && !propertiesJson.isEmpty() && propertiesJson.length() > 0) {
			ObjectMapper mapper = new ObjectMapper();
			// convert JSON string to Map
			try {
				propertiesMap = mapper.readValue(propertiesJson, new TypeReference<Map<String, String>>() {
				});
			} catch (JsonMappingException jex) {
				throw new RuntimeException("Json Mapping failed" + jex.getMessage());
			} catch (JsonParseException jpe) {
				new RuntimeException("Json Parse failed" + jpe.getMessage());
			} catch (IOException ioe) {
				new RuntimeException("IO Exception " + ioe.getMessage());
			} catch (Exception ex) {
				log.error("Error while converting json object");
				throw ex;
			}
		}
		return propertiesMap;
	}

	private String convertMapToJSON(Map<String, Object> resultMap) throws JsonProcessingException {
		String resultString = "";
		if (resultMap != null && resultMap.size() > 0) {
			resultString = new ObjectMapper().writeValueAsString(resultMap);
		}
		return resultString;
	}
}