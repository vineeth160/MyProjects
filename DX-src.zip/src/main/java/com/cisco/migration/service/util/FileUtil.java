package com.cisco.migration.service.util;

import static com.cisco.migration.service.webscripts.MigrationConstants.CISCODOC_TYPE;
import static com.cisco.migration.service.webscripts.MigrationConstants.NULL_EXCEPTION;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FILE_NAME;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FILE_NODE_REF;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FOLDER_NODE_REF;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_STATUS_CODE;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_STATUS_MSG;
import static com.cisco.migration.service.webscripts.MigrationConstants.PERM_OWNER_ROLE;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.content.encoding.ContentCharsetFinder;
import org.alfresco.repo.version.VersionModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileFolderService;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.MimetypeService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.cmr.version.VersionType;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.servlet.FormData;


/**
 * 
 * @author gpotla
 * 
 */
public class FileUtil
{
    private static final Logger LOGGER = Logger.getLogger(FileUtil.class);

    private ServiceRegistry serviceRegistry;

    private NodeService nodeService;

    private MimetypeService mimetypeService;

    private FileFolderService fileFolderService;

    private MigrationUtils migrationUtils;

    private PermissionsUtil permissionsUtil;

    public PermissionsUtil getPermissionsUtil()
    {
        return permissionsUtil;
    }

    public void setPermissionsUtil(PermissionsUtil permissionsUtil)
    {
        this.permissionsUtil = permissionsUtil;
    }

    public void setMigrationUtils(MigrationUtils migrationUtils)
    {
        this.migrationUtils = migrationUtils;
    }

    public void setFileFolderService(FileFolderService fileFolderService)
    {
        this.fileFolderService = fileFolderService;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    public void setMimetypeService(MimetypeService mimetypeService)
    {
        this.mimetypeService = mimetypeService;
    }

    /**
     * 
     * @param field
     * @param parentNode
     * @param isOverWrite
     * @param jsonMetadaProp
     * @param reqFileName
     * @param mimeType
     * @param encoding
     * @param attachFileTagging
     * @param attachFileMetadata
     * @param jsonCommnProp
     * @param tagAttributes
     * @param contentowner
     * @return Map<String, Object>
     * @throws Exception
     */
    public Map<String, Object> writeContent(String fileLocation, NodeRef parentNode, boolean isOverWrite,
            String jsonMetadaProp, String reqFileName, String mimeType, String encoding, boolean attachFileTagging,
            boolean attachFileMetadata, String jsonCommnProp, String tagAttributes, String contentowner,
            boolean isVersionable, String permissionsJson, boolean cascadeFolderPermissions,
            Map<String, Object> result, String alfServiceDelimeter, NodeRef baseFileNodeRef, String dateFormat,
            String timeZone) throws Exception
    {

        LOGGER.info("In FileUtil.writeContent() Start ");

        NodeRef uploadFileNode = null;
        InputStream fileInputStream = null;
        String versionNodeRef = null;
        BufferedInputStream inputStream = null;
        boolean success = false;

        File fileObject = new File(fileLocation);

        String fileName = new String(fileObject.getName().getBytes(), "UTF-8");
        LOGGER.info(" File Name from new String()  ::: " + fileName);

        try
        {
            fileInputStream = new FileInputStream(fileObject);
            /*
             * } catch (FileNotFoundException e) { LOG.error(" Exception while getting inputStream :: " + e); throw new
             * Exception((e != null) ? e.getMessage() : NULL_EXCEPTION); }
             */

            LOGGER.info("reqFileName :: " + reqFileName);

            LOGGER.info("fileName :: " + fileName + " \t mimetype :: " + mimeType + " \t  parentNode :: " + parentNode);

            inputStream = new BufferedInputStream(fileInputStream);

            if (encoding == null || encoding.length() == 0)
            {
                ContentCharsetFinder charsetFinder = mimetypeService.getContentCharsetFinder();
                Charset charset = charsetFinder.getCharset(inputStream, mimeType);
                encoding = charset.name();
            }

            NodeRef existFileNodeRef = null;

            // will Create Versions based on existing file Nodererence
            if (isOverWrite && isVersionable)
            {
                existFileNodeRef = baseFileNodeRef;
            }
            else
            {
                existFileNodeRef = fileFolderService.searchSimple(parentNode, fileName);
            }

            boolean isFileExist = false;
            LOGGER.info("Is uploading File Already Exist ::: " + existFileNodeRef);

            if (existFileNodeRef == null)
            {
                uploadFileNode = createContentNode(parentNode, fileName, mimeType);
            }
            else
            {
                uploadFileNode = existFileNodeRef;
                isFileExist = true;
            }

            LOGGER.info(" isFileExist :: " + isFileExist + " \t isOverWrite ::  " + isOverWrite
                    + "\t isVersionableAspect :: " + isVersionable);

            LOGGER.info(" Is attachFileMetadata ? " + attachFileMetadata);

            if (!isFileExist || (isFileExist && isOverWrite && !isVersionable))
            {
                if (attachFileMetadata)
                {
                    migrationUtils.attachMandatoryMetadata(jsonCommnProp, jsonMetadaProp, attachFileTagging,
                        tagAttributes, uploadFileNode, alfServiceDelimeter, dateFormat, timeZone);
                }
                attachPermissions(contentowner, uploadFileNode, permissionsJson, cascadeFolderPermissions);
                nodeService.setProperty(uploadFileNode, ContentModel.PROP_CONTENT, mimeType);
                nodeService.setProperty(uploadFileNode, ContentModel.PROP_NAME, fileName);
            }
            else if (isFileExist && isOverWrite && isVersionable)
            {
                if (attachFileMetadata)
                {
                    migrationUtils.attachMandatoryMetadata(jsonCommnProp, jsonMetadaProp, attachFileTagging,
                        tagAttributes, uploadFileNode, alfServiceDelimeter, dateFormat, timeZone);
                }
                attachPermissions(contentowner, uploadFileNode, permissionsJson, cascadeFolderPermissions);
                nodeService.setProperty(uploadFileNode, ContentModel.PROP_CONTENT, mimeType);
                // nodeService.setProperty(uploadFileNode, ContentModel.PROP_NAME, fileName);

                // creating versions
                versionNodeRef = doCreateVersions(uploadFileNode);
                LOGGER.info(" Created versionNodeRef ---> " + versionNodeRef);

            }
            else if (isFileExist && !isOverWrite)
            {
                result.put(PARAM_STATUS_MSG, "File already exist.");
                result.put(PARAM_FOLDER_NODE_REF, parentNode.toString());
                result.put(PARAM_FILE_NODE_REF, String.valueOf(uploadFileNode));
                result.put(PARAM_FILE_NAME, fileName);
                result.put(PARAM_STATUS_CODE, "200");
                return result;
            }

            // try {
            ContentWriter writer = this.serviceRegistry.getContentService().getWriter(uploadFileNode,
                ContentModel.PROP_CONTENT, true);
            if (writer != null)
            {
                writer.setMimetype(mimeType);

                writer.setEncoding(encoding);

                writer.putContent(inputStream);

                success = true;
            }

        }
        catch (Exception e)
        {
            LOGGER.error("Exception while writing content :: " + e, e);
            result.put(PARAM_STATUS_MSG, (e != null) ? e.getMessage() : NULL_EXCEPTION);
            result.put(PARAM_FOLDER_NODE_REF, parentNode.toString());
            if (versionNodeRef == null)
            {
                result.put(PARAM_FILE_NODE_REF, String.valueOf(uploadFileNode));
            }
            else
            {
                result.put(PARAM_FILE_NODE_REF, versionNodeRef);
            }
            result.put(PARAM_FILE_NAME, fileName);
            result.put(PARAM_STATUS_CODE, "400");
        }
        finally
        {
            if (inputStream != null)
            {
                inputStream.close();
            }
            if (fileInputStream != null)
            {
                fileInputStream.close();
            }
            LOGGER.info("In FileUtil.writeContent() End ");
        }

        if (success)
        {
            result.put(PARAM_STATUS_MSG, "File Uploaded successfully.");
            result.put(PARAM_FOLDER_NODE_REF, parentNode.toString());
            if (versionNodeRef == null)
            {
                result.put(PARAM_FILE_NODE_REF, String.valueOf(uploadFileNode));
            }
            else
            {
                result.put(PARAM_FILE_NODE_REF, versionNodeRef);
            }
            result.put(PARAM_FILE_NAME, fileName);
            result.put(PARAM_STATUS_CODE, "200");
        }

        return result;
    }

    /**
     * 
     * @param field
     * @param parentNode
     * @param isOverWrite
     * @param jsonMetadaProp
     * @param reqFileName
     * @param mimeType
     * @param encoding
     * @param attachFileTagging
     * @param attachFileMetadata
     * @param jsonCommnProp
     * @param tagAttributes
     * @param contentowner
     * @return Map<String, Object>
     * @throws Exception
     */
    public Map<String, Object> writeContent(FormData.FormField field, NodeRef parentNode, boolean isOverWrite,
            String jsonMetadaProp, String reqFileName, String mimeType, String encoding, boolean attachFileTagging,
            boolean attachFileMetadata, String jsonCommnProp, String tagAttributes, String contentowner,
            boolean isVersionable, String permissionsJson, boolean cascadeFolderPermissions,
            Map<String, Object> result, String alfServiceDelimeter, NodeRef baseFileNodeRef, String dateFormat,
            String timeZone) throws Exception
    {

        LOGGER.info("In FileUtil.writeContent() Start ");

        NodeRef uploadFileNode = null;

        BufferedInputStream inputStream = null;

        String versionNodeRef = null;

        boolean success = false;

        LOGGER.info("reqFileName :: " + reqFileName);

        String fileName = (reqFileName == null) ? field.getFilename() : reqFileName;

        Content content = field.getContent();
        InputStream is = content.getInputStream();

        LOGGER.info("fileName :: " + fileName + " \t mimetype :: " + mimeType + " \t  parentNode :: " + parentNode);

        try
        {
            inputStream = new BufferedInputStream(is);

            if (encoding == null || encoding.length() == 0)
            {
                ContentCharsetFinder charsetFinder = mimetypeService.getContentCharsetFinder();
                Charset charset = charsetFinder.getCharset(inputStream, mimeType);
                encoding = charset.name();
            }

            NodeRef existFileNodeRef = null;

            // will Create Versions based on existing file Nodererence
            if (isOverWrite && isVersionable)
            {
                existFileNodeRef = baseFileNodeRef;
            }
            else
            {
                existFileNodeRef = fileFolderService.searchSimple(parentNode, fileName);
            }

            boolean isFileExist = false;
            LOGGER.info("Is uploading File Already Exist ::: " + existFileNodeRef);

            if (existFileNodeRef == null)
            {
                uploadFileNode = createContentNode(parentNode, fileName, mimeType);
            }
            else
            {
                uploadFileNode = existFileNodeRef;
                isFileExist = true;
            }

            LOGGER.info(" isFileExist :: " + isFileExist + " \t isOverWrite ::  " + isOverWrite
                    + "\t isVersionableAspect :: " + isVersionable);

            LOGGER.info(" Is attachFileMetadata ? " + attachFileMetadata);

            if (!isFileExist || (isFileExist && isOverWrite && !isVersionable))
            {

                if (attachFileMetadata)
                {
                    migrationUtils.attachMandatoryMetadata(jsonCommnProp, jsonMetadaProp, attachFileTagging,
                        tagAttributes, uploadFileNode, alfServiceDelimeter, dateFormat, timeZone);
                }
                attachPermissions(contentowner, uploadFileNode, permissionsJson, cascadeFolderPermissions);
                nodeService.setProperty(uploadFileNode, ContentModel.PROP_CONTENT, mimeType);
                nodeService.setProperty(uploadFileNode, ContentModel.PROP_NAME, fileName);
            }
            else if (isFileExist && isOverWrite && isVersionable)
            {
                if (attachFileMetadata)
                {
                    migrationUtils.attachMandatoryMetadata(jsonCommnProp, jsonMetadaProp, attachFileTagging,
                        tagAttributes, uploadFileNode, alfServiceDelimeter, dateFormat, timeZone);
                }
                attachPermissions(contentowner, uploadFileNode, permissionsJson, cascadeFolderPermissions);
                nodeService.setProperty(uploadFileNode, ContentModel.PROP_CONTENT, mimeType);
                // nodeService.setProperty(uploadFileNode, ContentModel.PROP_NAME, fileName);

                // creating versions
                versionNodeRef = doCreateVersions(uploadFileNode);
            }
            else if (isFileExist && !isOverWrite)
            {
                result.put(PARAM_STATUS_MSG, "File already exist.");
                result.put(PARAM_FOLDER_NODE_REF, parentNode.toString());
                result.put(PARAM_FILE_NODE_REF, String.valueOf(uploadFileNode));
                result.put(PARAM_FILE_NAME, fileName);
                result.put(PARAM_STATUS_CODE, "200");
                return result;
            }

            // try {
            ContentWriter writer = this.serviceRegistry.getContentService().getWriter(uploadFileNode,
                ContentModel.PROP_CONTENT, true);
            if (writer != null)
            {
                writer.setMimetype(mimeType);

                writer.setEncoding(encoding);

                writer.putContent(inputStream);

                success = true;
            }

        }
        catch (Exception e)
        {
            LOGGER.error("Exception while writing content :: " + e, e);
            result.put(PARAM_STATUS_MSG, (e != null) ? e.getMessage() : NULL_EXCEPTION);
            result.put(PARAM_FOLDER_NODE_REF, parentNode.toString());
            if (versionNodeRef == null)
            {
                result.put(PARAM_FILE_NODE_REF, String.valueOf(uploadFileNode));
            }
            else
            {
                result.put(PARAM_FILE_NODE_REF, versionNodeRef);
            }
            result.put(PARAM_FILE_NAME, fileName);
            result.put(PARAM_STATUS_CODE, "400");
        }
        finally
        {
            if (inputStream != null)
            {
                inputStream.close();
            }
            if (is != null)
            {
                is.close();
            }
            LOGGER.info("In FileUtil.writeContent() End ");
        }

        if (success)
        {
            result.put(PARAM_STATUS_MSG, "File Uploaded successfully.");
            result.put(PARAM_FOLDER_NODE_REF, parentNode.toString());
            if (versionNodeRef == null)
            {
                result.put(PARAM_FILE_NODE_REF, String.valueOf(uploadFileNode));
            }
            else
            {
                result.put(PARAM_FILE_NODE_REF, versionNodeRef);
            }
            result.put(PARAM_FILE_NAME, fileName);
            result.put(PARAM_STATUS_CODE, "200");
        }

        return result;
    }

    /**
     * 
     * @param parentNode
     * @param fileName
     * @param mimeType
     * @return
     * @throws Exception
     */
    private NodeRef createContentNode(NodeRef parentNode, String fileName, String mimeType) throws Exception
    {
        LOGGER.info("In FileUtil.createContentNode() Start");
        NodeRef contentNode = null;

        try
        {

            Map<QName, Serializable> propertyMap = new HashMap<QName, Serializable>();
            propertyMap.put(ContentModel.PROP_NAME, fileName);

            FileInfo fileInfo = fileFolderService.create(parentNode, fileName, CISCODOC_TYPE);
            contentNode = fileInfo.getNodeRef();

            LOGGER.info(" Created node " + contentNode.toString() + " for the file " + fileName);

            this.nodeService.setProperty(contentNode, ContentModel.PROP_CONTENT, mimeType);

        }
        catch (Exception e)
        {
            LOGGER.error(e, e);
            throw new Exception((e != null) ? e.getMessage() : NULL_EXCEPTION);
        }
        finally
        {
            LOGGER.info("In FileUtil.createContentNode() finally block End ");
        }

        return contentNode;
    }

    /**
     * 
     * @param contentowner
     * @param uploadFileNode
     * @throws Exception
     */
    private void attachPermissions(String contentowner, NodeRef uploadFileNode, String permissionsJson,
            boolean cascadeFolderPermissions) throws Exception
    {

        LOGGER.info(" FileUtil.attachPermissions()  for file Node ::: " + uploadFileNode);

        if (cascadeFolderPermissions)
        {
            ChildAssociationRef childAssociationRef = this.nodeService.getPrimaryParent(uploadFileNode);
            NodeRef parentNodeRef = childAssociationRef.getParentRef();
            permissionsUtil.setInheritPermissions(parentNodeRef, cascadeFolderPermissions);
        }

        if (permissionsJson != null)
        {
            permissionsUtil.attachPermissions(uploadFileNode, permissionsJson);
        }

        if (contentowner != null && !contentowner.trim().equals(""))
        {
            // Setting permission to contetnOwner
            serviceRegistry.getPermissionService().setPermission(uploadFileNode, contentowner, PERM_OWNER_ROLE, true);
        }

    }

    /**
     * 
     * @param contentNodeRef
     */
    public String doCreateVersions(NodeRef contentNodeRef) throws Exception
    {

        LOGGER.info(" FileUtil.doCreateVersions() UploadNodeRef ::: " + contentNodeRef);
        boolean hasAspect = this.serviceRegistry.getVersionService().isVersioned(contentNodeRef);
        String versionNode = null;

        try
        {

            Version retVer = null;

            if (hasAspect)
            {
                Map<String, Serializable> versionProperties = new HashMap<String, Serializable>();
                versionProperties.put(VersionModel.PROP_VERSION_TYPE, VersionType.MAJOR);
                LOGGER.info(" Creating MINOR versions.....");
                retVer = (Version) this.serviceRegistry.getVersionService().createVersion(contentNodeRef,
                    versionProperties);

                // Getting created version NodeRef
                VersionHistory history = this.serviceRegistry.getVersionService().getVersionHistory(contentNodeRef);
                Version version = history.getVersion(retVer.getVersionLabel());
                NodeRef versionNodeRef = version.getFrozenStateNodeRef();

                LOGGER.info(" Created Version Lable ---> " + retVer.getVersionLabel());
                LOGGER.info(" Created Version FrozenStateNodeRef ---> " + versionNodeRef);

                versionNode = versionNodeRef.toString();
            }
        }
        catch (Exception e)
        {
            LOGGER.error(" Exception while creating version(s) ..." + e, e);
            throw new Exception(e.getMessage());
        }
        finally
        {
            LOGGER.info(" FileUtil.doCreateVersions() finally block ");
        }

        return versionNode;
    }

}
