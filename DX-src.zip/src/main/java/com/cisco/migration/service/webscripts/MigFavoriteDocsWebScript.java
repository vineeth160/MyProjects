package com.cisco.migration.service.webscripts;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.namespace.RegexQNamePattern;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.migration.service.util.MigPostScriptConstants;

/**
 * @author parreddy
 *
 */
public class MigFavoriteDocsWebScript extends DeclarativeWebScript {
	private Logger logs = Logger.getLogger(MigFavoriteDocsWebScript.class);
	private NodeService nodeService;
	private PersonService personService;
	private BehaviourFilter policyFilter;

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}

	public void setPolicyFilter(BehaviourFilter policyFilter) {
		this.policyFilter = policyFilter;
	}

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {
		logs.debug("Migration Subscription task start !!");
		HashMap<String, Object> model = new HashMap<>();
		String nodeRef = req.getParameter("nodeRef");
		String userName = req.getParameter("user");
		try {
			if (nodeRef != null && userName != null && nodeService.exists(new NodeRef(nodeRef))) {
				String actionType = req.getParameter("action");

				markAsFavorite(nodeRef, userName, actionType);

				model.put("msg", "SUCCESS");
			} else {
				logs.debug("Invalid NodeRef or UserName");
				model.put("msg", "FAILED");
			}
		} catch (Exception e) {
			e.getMessage();
			model.put("msg", "FAILED");
			logs.error("Exception while making favorite ==> ", e);
		}
		logs.debug("Migration Subscription task end !!");
		return model;

	}

	private void markAsFavorite(String alfNodeRefString, String alfUserName, String actionType) {

		NodeRef personNodereff = personService.getPerson(alfUserName);
		NodeRef alfNodeRef = new NodeRef(alfNodeRefString);
		List<ChildAssociationRef> personChildAssocList = nodeService.getChildAssocs(personNodereff,
				MigPostScriptConstants.ASSOC_NAME_MYFAVORITE_ASSOCIATE, RegexQNamePattern.MATCH_ALL);

		boolean isNodeExist = false;

		for (ChildAssociationRef personChildRef : personChildAssocList) {
			NodeRef childNodeRef = personChildRef.getChildRef();
			if (alfNodeRefString.equalsIgnoreCase(childNodeRef.toString())) {
				if (actionType.equalsIgnoreCase("remove")) {
					try {
						policyFilter.disableBehaviour(alfNodeRef, ContentModel.ASPECT_AUDITABLE);
						nodeService.removeChildAssociation(personChildRef);
					} catch (Exception ex) {
						throw ex;
					} finally {
						policyFilter.enableBehaviour(alfNodeRef, ContentModel.ASPECT_AUDITABLE);
					}
				}
				isNodeExist = true;
				break;

			}

		}

		if (actionType.equalsIgnoreCase("add") && !isNodeExist) {

			try {
				policyFilter.disableBehaviour(alfNodeRef, ContentModel.ASPECT_AUDITABLE);

				if (nodeService.hasAspect(personNodereff, MigPostScriptConstants.ASPECT_MYFAVORITEDOCS) == false) {
					this.nodeService.addAspect(personNodereff, MigPostScriptConstants.ASPECT_MYFAVORITEDOCS, null);
					nodeService.addChild(personNodereff, alfNodeRef,
							MigPostScriptConstants.ASSOC_NAME_MYFAVORITE_ASSOCIATE,
							QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, alfNodeRef.getId()));
				} else {
					nodeService.addChild(personNodereff, alfNodeRef,
							MigPostScriptConstants.ASSOC_NAME_MYFAVORITE_ASSOCIATE,
							QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, alfNodeRef.getId()));
				}

			} catch (Exception ex) {
				throw ex;
			} finally {
				policyFilter.enableBehaviour(alfNodeRef, ContentModel.ASPECT_AUDITABLE);
			}

		}

	}

}
