package com.cisco.migration.service.util;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.processor.BaseProcessorExtension;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;

/**
 * @author 
 */
public class MigBehaviourPolicyFilter extends BaseProcessorExtension {
	
	private static Logger logger = Logger.getLogger(MigBehaviourPolicyFilter.class);
	private BehaviourFilter behaviourFilter;
	
	public BehaviourFilter getBehaviourFilter() {
		return behaviourFilter;
	}

	public void setBehaviourFilter(BehaviourFilter behaviourFilter) {
		this.behaviourFilter = behaviourFilter;
	}

	/** Disabling the behaviour
	 * @param nodeRefStr
	 * @param qNameStr
	 */
	public void disableBehaviour(NodeRef nodeRef, String qNameStr)
    {
        try
        {
            QName nodeQName = QName.createQName(qNameStr);

            behaviourFilter.disableBehaviour(nodeRef, nodeQName);
        }
        catch (Exception e)
        {
        	logger.error(e.getMessage(),e);
        }
    }

    /** Enabling behaviour
     * @param nodeRefStr
     * @param qNameStr
     */
    public void enableBehaviour(NodeRef nodeRef, String qNameStr)
    {
        try
        {
            QName nodeQName = QName.createQName(qNameStr);
            behaviourFilter.enableBehaviour(nodeRef, nodeQName);
        }
        catch (Exception e)
        {
        	logger.error(e.getMessage(),e);
        }
    }
}
