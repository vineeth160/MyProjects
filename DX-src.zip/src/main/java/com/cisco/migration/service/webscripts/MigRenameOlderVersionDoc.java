package com.cisco.migration.service.webscripts;

import java.util.HashMap;
import java.util.Map;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.*;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.extensions.webscripts.*;
import com.cisco.migration.service.util.MigPostScriptConstants;

public class MigRenameOlderVersionDoc extends DeclarativeWebScript
{
	private Logger log = Logger.getLogger(MigRenameOlderVersionDoc.class);
	private ServiceRegistry serviceRegistry;
	private BehaviourFilter policyBehaviourFilter;

	public BehaviourFilter getPolicyBehaviourFilter()
	{
		return policyBehaviourFilter;
	}

	public void setPolicyBehaviourFilter(BehaviourFilter policyBehaviourFilter)
	{
		this.policyBehaviourFilter = policyBehaviourFilter;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry)
	{
		this.serviceRegistry = serviceRegistry;
	}

	public ServiceRegistry getServiceRegistry()
	{
		return serviceRegistry;
	}

	Map<String, Object> model = new HashMap<String, Object>();

	@SuppressWarnings("unchecked")
	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
	{
		JSONArray respArray = new JSONArray();
		JSONParser parser = new JSONParser();

		JSONObject versionReName = null;
		try
		{
			versionReName = (JSONObject) parser.parse(req.getParameter("namejson"));
			String nodeRef = (String) versionReName.get("nodeRef");
			String type=(String) versionReName.get("type");
			String name=(String) versionReName.get("name");
			if ((versionReName != null && !versionReName.isEmpty()) && (nodeRef != null && !nodeRef.trim().isEmpty()))
			{
				JSONArray jsonArray = (JSONArray) versionReName.get("versionNodeIds");
				if (jsonArray != null && jsonArray.size() > 0)
				{
					VersionHistory versionHistory = getServiceRegistry().getVersionService()
							.getVersionHistory(new NodeRef(nodeRef));
					for (int i = 0; i < jsonArray.size(); i++)
					{
						JSONObject json = (JSONObject) jsonArray.get(i);
						String versionNoderef = (String) json.get("versionNoderef");
						log.info("version noderef in json!!!" + versionNoderef);
						String versionName = (String) json.get("versionName");
						log.info("version name in json!!!" + versionName);
						String mimeType=(String) json.get("mimeType");
						respArray.add(setVersionName(versionHistory, versionNoderef, versionName, nodeRef,mimeType));
					}
				}
				else if ((nodeRef != null && !nodeRef.trim().isEmpty()))
				{
					respArray.add(setLiveNodeName(nodeRef,type,name));
				}
			}
			else
			{
				throw new NullPointerException();
			}
			log.info("Noderef is ::: " + nodeRef);
		}
		catch (ParseException ex)
		{
			JSONObject json = new JSONObject();
			json.put("nodeRef", null);
			json.put("status", "ParseException : Invalid input json");
			respArray.add(json);
			log.error("ParseException", ex);
		}
		catch (NullPointerException ex)
		{
			JSONObject json = new JSONObject();
			json.put("nodeRef", null);
			json.put("status", "NullPointerException : Either nodeRef or versionNodeIds are null or Empty");
			respArray.add(json);
			log.error("NullPointerException", ex);
		}
		catch (Exception ex)
		{
			JSONObject json = new JSONObject();
			json.put("nodeRef", null);
			json.put("status", "Exception : " + ex.getClass().getName());
			respArray.add(json);
			log.error("Exception", ex);
		}
		model.put("result", respArray);
		
		if (log.isDebugEnabled())
		{
			log.debug("final model reponse ::::: " + model);
		}
		return model;
	}

	
	
	@SuppressWarnings("unchecked")
	private JSONObject setLiveNodeName(String nodeRef, String type,String name)
	{
		JSONObject json = new JSONObject();

		try{
			if(type == null || type.trim().length() < 1){
				throw new Exception("mime type value is null or missing..");
			}
			
			if(name == null || name.trim().length() < 1){
				throw new Exception("mime type value is null or missing..");
			}
			
			NodeRef liveNode= new NodeRef(nodeRef);
			policyBehaviourFilter.disableBehaviour(liveNode, ContentModel.ASPECT_AUDITABLE);
			policyBehaviourFilter.disableBehaviour(liveNode, MigPostScriptConstants.CISCODOC_TYPE);
			policyBehaviourFilter.disableBehaviour(liveNode, ContentModel.ASPECT_VERSIONABLE);
			ContentWriter content = serviceRegistry.getContentService().getWriter(liveNode,
					ContentModel.PROP_CONTENT, true);
			content.setMimetype(type);
			log.info("inside else MimeType changed successfully");
			log.info("check mime type" + content.getMimetype());
			serviceRegistry.getNodeService().setProperty(liveNode, ContentModel.PROP_NAME, name);
			policyBehaviourFilter.enableBehaviour(liveNode, ContentModel.ASPECT_VERSIONABLE);
			policyBehaviourFilter.enableBehaviour(liveNode, MigPostScriptConstants.CISCODOC_TYPE);
			policyBehaviourFilter.enableBehaviour(liveNode, ContentModel.ASPECT_AUDITABLE);
			
			log.info("LiveNode renamed successfully");
			json.put("nodeRef", nodeRef);
			json.put("status", "liveNodeRenamed");
			return json;
		}
		catch (Exception ex)
		{
			log.error("Exception", ex);
			json.put("nodeRef", nodeRef);
			json.put("status", "Failed due to unknown exception pls refer logs for details");
		}
		log.info("json:::::" + json);
		return json;
	}
	
	@SuppressWarnings("unchecked")
	private JSONObject setVersionName(VersionHistory versionHistory, String versionNodeRef, String verName,
			String nodeRef,String mimeType)
	{
		JSONObject json = new JSONObject();

		try
		{
			if (null != versionHistory)
			{
				log.info("inside if versionHistory not null+++");
				boolean isNodeExists = false;
				for (Version v1 : versionHistory.getAllVersions())
				{
					NodeRef vNoderef = new NodeRef("workspace://version2Store/" + v1.getFrozenStateNodeRef().getId());
					log.info("final vNoderef :: " + vNoderef);
					log.info("final versionNodeRef ::  " + versionNodeRef);
					if (vNoderef.toString().trim().equals(versionNodeRef.trim()))
					{
						isNodeExists = true;
						log.info("inside if version noderef equal to given+++" + vNoderef);
						if (verName.trim() != null && verName.trim().length() > 0)
						{
							policyBehaviourFilter.disableBehaviour(vNoderef, ContentModel.ASPECT_AUDITABLE);
							policyBehaviourFilter.disableBehaviour(vNoderef, MigPostScriptConstants.CISCODOC_TYPE);
							policyBehaviourFilter.disableBehaviour(vNoderef, ContentModel.ASPECT_VERSIONABLE);
							/*ContentWriter content = serviceRegistry.getContentService().getWriter(vNoderef,
									ContentModel.PROP_CONTENT, true);*/
							
							ContentData contentData = (ContentData) serviceRegistry.getNodeService().getProperty(vNoderef, ContentModel.PROP_CONTENT);
							ContentData newcontentData = ContentData.setMimetype(contentData,mimeType);
							serviceRegistry.getNodeService().setProperty(vNoderef, ContentModel.PROP_CONTENT, newcontentData);
							log.info("MimeType changed successfully");
							log.info("check mime type" + contentData.getMimetype());
							serviceRegistry.getNodeService().setProperty(vNoderef, ContentModel.PROP_NAME, verName);
							policyBehaviourFilter.enableBehaviour(vNoderef, ContentModel.ASPECT_VERSIONABLE);
							policyBehaviourFilter.enableBehaviour(vNoderef, MigPostScriptConstants.CISCODOC_TYPE);
							policyBehaviourFilter.enableBehaviour(vNoderef, ContentModel.ASPECT_AUDITABLE);
							json.put("nodeRef", versionNodeRef);
							json.put("status", "successfully applied..");
							log.info("renamed successfully");
						}
						else
						{
							json.put("nodeRef", versionNodeRef);
							json.put("status", "version name is null or empty!");
						}
						return json;
					}
				}
				if (!isNodeExists)
				{
					json.put("nodeRef", versionNodeRef);
					json.put("status", "failed");
					return json;
				}
			}
			else
			{
				log.error("noderef not found!!");
				json.put("nodeRef", nodeRef);
				json.put("status", "No version found for NodeRef");
				return json;
			}
		}
		catch (InvalidNodeRefException ex)
		{
			log.error("InvalidNodeRefException", ex);
			json.put("nodeRef", nodeRef);
			json.put("status", "InvalidNodeRef");
		}
		catch (NullPointerException ex)
		{
			log.error("NullPointerException", ex);
			json.put("nodeRef", versionNodeRef);
			json.put("status", "versionNodeRef is null");
		}
		catch (Exception ex)
		{
			log.error("Exception", ex);
			json.put("nodeRef", nodeRef);
			json.put("status", "Failed due to unknown exception pls refer logs for details");
		}
		if (log.isDebugEnabled())
		{
			log.debug("json:::::" + json);
		}
		
		return json;
	}
}
