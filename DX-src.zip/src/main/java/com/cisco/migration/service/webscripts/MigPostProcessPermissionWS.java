package com.cisco.migration.service.webscripts;

import static com.cisco.migration.service.util.MigPostScriptConstants.PARAM_CONTENT_OWNER;
import static com.cisco.migration.service.util.MigPostScriptConstants.PARAM_PERMISSION_JSON;
import static com.cisco.migration.service.util.MigPostScriptConstants.PARAM_STATUS_MSG;
import static com.cisco.migration.service.util.MigPostScriptConstants.RES_OBJECT_NODEREF;

import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.migration.service.util.MigPostScriptConstants;
import com.cisco.migration.service.util.MigPostProcessPermissionsUtil;


/**
 * 
 * @author parreddy
 * 
 */
public class MigPostProcessPermissionWS extends DeclarativeWebScript {

	private static final Logger LOG = Logger.getLogger(MigPostProcessPermissionWS.class);

	private ServiceRegistry serviceRegistry;

	private MigPostProcessPermissionsUtil permissionsUtil;
	
	private BehaviourFilter policyFilter;

	public void setPolicyFilter(BehaviourFilter policyFilter) {
		this.policyFilter = policyFilter;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public void setPermissionsUtil(MigPostProcessPermissionsUtil permissionsUtil) {
		this.permissionsUtil = permissionsUtil;
	}

	/**
	* 
	*/
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("In MigrationPermissionManagerWebScript.executeImpl() Start ");
		}

		Map<String, Object> result = new HashMap<String, Object>();

		String contentNodeRef = req.getParameter(RES_OBJECT_NODEREF);

		String contentowner = req.getParameter(PARAM_CONTENT_OWNER);
		if (LOG.isDebugEnabled()) {
			LOG.info(" contentowner = " + contentowner);
		}

		String inhertPerm = req.getParameter(MigPostScriptConstants.PARAM_INHERIT_PERM);

		String permissionsJson = req.getParameter(PARAM_PERMISSION_JSON);

		if (contentNodeRef != null) {
			result.put(RES_OBJECT_NODEREF, contentNodeRef);
			NodeRef objectNodeRef = new NodeRef(contentNodeRef);
			try {
				
				//Disable Audit Policy
				policyFilter.disableBehaviour(objectNodeRef, ContentModel.ASPECT_AUDITABLE);
				policyFilter.disableBehaviour(objectNodeRef, MigPostScriptConstants.CISCODOC_TYPE);
				policyFilter.disableBehaviour(objectNodeRef, ContentModel.ASPECT_VERSIONABLE);
				
				boolean isInheritPerm =	permissionsUtil.getInheritPermissions(objectNodeRef);				//(inhertPerm != null) ? Boolean.valueOf(inhertPerm) : false;
				
				if (LOG.isDebugEnabled()) {
					LOG.info("Node Ref id =====> " + contentNodeRef);
					LOG.info("Permissions Json  =====> " + permissionsJson);
					LOG.info("Is Inherit ====> " + isInheritPerm);
					LOG.info("Content Owner ====> " + contentowner);
				}
				
				if (inhertPerm != null && !inhertPerm.isEmpty() && inhertPerm.length() > 0 && !String.valueOf(isInheritPerm).equalsIgnoreCase(inhertPerm)) {
					//isInheritPerm = Boolean.valueOf(inhertPerm);
					isInheritPerm = Boolean.valueOf(inhertPerm);
				}
				result = this.permissionsUtil.attachPermissions(objectNodeRef, permissionsJson , isInheritPerm);
				//result.put(PARAM_STATUS_MSG, "Permission(s) added successfully!!!");
				
				//Enable Audit Policy
				policyFilter.enableBehaviour(objectNodeRef, ContentModel.ASPECT_AUDITABLE);
				policyFilter.enableBehaviour(objectNodeRef, MigPostScriptConstants.CISCODOC_TYPE);
				policyFilter.enableBehaviour(objectNodeRef, ContentModel.ASPECT_VERSIONABLE);
			} catch (Exception e) {
				LOG.error(" Exception while adding Permission(s) ..." + e, e);
				result.put(PARAM_STATUS_MSG, e.getMessage());
				//result.put(RES_OBJECT_NODEREF, "");
			} finally {
				policyFilter.enableBehaviour(objectNodeRef, ContentModel.ASPECT_AUDITABLE);
				policyFilter.enableBehaviour(objectNodeRef, MigPostScriptConstants.CISCODOC_TYPE);
				policyFilter.enableBehaviour(objectNodeRef, ContentModel.ASPECT_VERSIONABLE);
				if (LOG.isDebugEnabled()) {
					LOG.info("In MigrationPermissionManagerWebScript.executeImpl() finally block End ");
				}
			}

		} else {
			result.put(PARAM_STATUS_MSG, "Please Provide File/Folder Node Reference as Request Parameter.");
			result.put(RES_OBJECT_NODEREF, "");
		}
		
		LOG.info("Permissions applied successfully for node ==> " + contentNodeRef);
		return result;
	}

}
