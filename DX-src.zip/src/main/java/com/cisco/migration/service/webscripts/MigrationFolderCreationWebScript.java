package com.cisco.migration.service.webscripts;

import static com.cisco.migration.service.webscripts.MigrationConstants.FOLDER_PATH;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_ATTACH_FOLDER_METADATA;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_ATTACH_FOLDER_TAGGING;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_CASCADE_PERMISSIONS;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_CONTENT_OWNER;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_DATE_FORMAT;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_DELIMETER;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FLDR_JSON_METADATA;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FOLDER_DESC;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FOLDER_NAME;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FOLDER_NODE_REF;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FOLDER_NODE_REF_LIST;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FOLDER_TITLE;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_OVERWRITE;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_PERMISSION_JSON;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_STATUS_CODE;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_STATUS_MSG;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_TAGGING_ATTRIBUTES;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_TIME_ZONE;
import static com.cisco.migration.service.webscripts.MigrationConstants.ROOT_PATH;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.migration.service.util.FolderUtil;

/**
 * 
 * @author gpotla
 * 
 */
public class MigrationFolderCreationWebScript extends DeclarativeWebScript {

    private static final Logger LOG = Logger.getLogger(MigrationFolderCreationWebScript.class);

    private FolderUtil folderUtil;

    public void setFolderUtil(FolderUtil folderUtil) {
		this.folderUtil = folderUtil;
	}
    
    /**
	 * 
	 */
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status,
			Cache cache) {
		LOG.info("In MigrationFolderCreationWebScript.executeImpl() Start ");
		
		Map<String, Object> result = new HashMap<String, Object>();
		
		String rootPath = req.getParameter(ROOT_PATH);
		String folderPath = req.getParameter(FOLDER_PATH);
		 LOG.info(" rootPath = " + rootPath +" \t folderPath = "+ folderPath);
		
        String overwriteObj = req.getParameter(PARAM_OVERWRITE);
        boolean isOverWrite = overwriteObj == null ? false : Boolean.valueOf(overwriteObj);
        LOG.info(" isOverWrite  == "+ isOverWrite);
       
        String fldrMetaObj = req.getParameter(PARAM_ATTACH_FOLDER_METADATA);
        boolean attachFolderMetadata = (fldrMetaObj == null) ? false : Boolean.parseBoolean(fldrMetaObj);
        LOG.info(" attachFolderMetadata  =  " + attachFolderMetadata);
        
        // ContentOwner is the mandatory Property
        String contentowner = req.getParameter(PARAM_CONTENT_OWNER);
        LOG.info(" contentowner = " + contentowner);
        
        
        String folderTagging = req.getParameter(PARAM_ATTACH_FOLDER_TAGGING);
        boolean attachFolderTagging = (folderTagging == null) ? false : Boolean.parseBoolean(folderTagging);
        LOG.info(" attachFolderTagging = " + attachFolderTagging);
        
        String inheritPerms = req.getParameter(PARAM_CASCADE_PERMISSIONS);
        boolean cascadeFolderPermissions = (inheritPerms == null) ? false : Boolean.parseBoolean(inheritPerms);
        LOG.info(" cascadeFolderPermissions = " + cascadeFolderPermissions);
        
        // folder tagging attributes
        String tagAttributes = req.getParameter(PARAM_TAGGING_ATTRIBUTES);
        LOG.info(" tagAttributes = " + tagAttributes);
        
        // getting folderMetadata Aspect
        String jsonMetaProp = req.getParameter(PARAM_FLDR_JSON_METADATA);
        
        // getting Permissions JSON
        String permissionsJson = req.getParameter(PARAM_PERMISSION_JSON);
        
        String folderTitle = req.getParameter(PARAM_FOLDER_TITLE);
        String folderDesc = req.getParameter(PARAM_FOLDER_DESC);
        
        String alfServiceDelimeter = req.getParameter(PARAM_DELIMETER);
        
        String timeZone = req.getParameter(PARAM_TIME_ZONE);
        
        String dateFormat = req.getParameter(PARAM_DATE_FORMAT);
        
		if(rootPath != null && folderPath != null) {
			
			try {

				result = folderUtil.createFolders(rootPath, folderPath, folderTitle, folderDesc, isOverWrite, attachFolderMetadata, jsonMetaProp, attachFolderTagging, tagAttributes, contentowner, cascadeFolderPermissions, permissionsJson, alfServiceDelimeter, dateFormat, timeZone);

			} catch (Exception e) {
				LOG.error(" Exception while creating folder ..." + e, e);
				result.put(PARAM_STATUS_MSG, e.getMessage());
				result.put(PARAM_FOLDER_NODE_REF, "");
				result.put(PARAM_FOLDER_NODE_REF_LIST, new HashMap<String , Object>());
				result.put(PARAM_FOLDER_NAME, "");
				result.put(PARAM_STATUS_CODE, "400");
			} finally {
				LOG.info("In MigrationFolderCreationWebScript.executeImpl() finally block End ");
			}
			
		} else {
			result.put(PARAM_STATUS_MSG, "Please Provide rootPath and folderPath as HTTPPost request parameter.");
			result.put(PARAM_FOLDER_NODE_REF, "");
			result.put(PARAM_FOLDER_NODE_REF_LIST, new HashMap<String , Object>());
			result.put(PARAM_FOLDER_NAME, "");
			result.put(PARAM_STATUS_CODE, "400");
		}

        return result;
	}

}
