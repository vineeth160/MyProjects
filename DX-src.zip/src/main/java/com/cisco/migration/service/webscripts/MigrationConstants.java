package com.cisco.migration.service.webscripts;

import org.alfresco.service.namespace.QName;

/**
 * 
 * @author gpotla
 * 
 */
public class MigrationConstants {

	public static final String RETENTION_ASPECT = "recordsInfo";

	public static final String ADMIN_USER = "admin";

	public static final String PARAM_ATTACH_FOLDER_METADATA = "attachFolderMetadata";

	public static final String PARAM_ATTACH_FOLDER_TAGGING = "attachFolderTagging";

	public static final String PARAM_ATTACH_FILE_TAGGING = "attachFileTagging";

	public static final String PARAM_TAGGING_ATTRIBUTES = "taggingAttributes";

	public static final String PARAM_ATTACH_FILE_METADATA = "attachFileMetadata";

	public static final String PARAM_CONTENT_OWNER = "contentowner";

	public static final String PARAM_JSON_METADATA = "jsonMetadata";

	public static final String PARAM_QNAME = "aspectQName";

	public static final String PARAM_JSON_COMMON_PROPS = "jsonCommonProperties";

	public static final String PARAM_OVERWRITE = "overwrite";

	public static final String PARAM_VERSIONABLE = "versionable";

	public static final String PARAM_MIMETYPE = "fileMimeType";

	public static final String PARAM_ENCODING = "encoding";

	public static final String CISCO_MODEL_NAMESPACE = "http://www.cisco.com/model/content/1.0";

	public static final QName CISCODOC_TYPE = QName.createQName(
			CISCO_MODEL_NAMESPACE, "ciscodoc");

	public static final String PROP_RETENTION_PERIOD = "retentionPeriod";

	public static final String PROP_RETENTION_START_RANGE = "retentionStartRange";

	public static final String PROP_RETENTION_END_RANGE = "retentionEndRange";

	public static final String ROOT_PATH = "rootPath";

	public static final String FOLDER_PATH = "folderPath";

	public static final String PARAM_FOLDER_NODE_REF = "uploadFolderNodeRef";

	public static final String PARAM_STATUS_MSG = "statusMessage";

	public static final String PARAM_FILE_NODE_REF = "uploadFileNodeRef";

	public static final String PARAM_FILE_NAME = "fileName";

	public static final String PARAM_FIELD = "filedata";

	public static final String PARAM_ROOT_PATH_NODE_REF = "rootPathNodeRef";

	public static final String PERM_OWNER_ROLE = "OwnerRole";

	public static final String NULL_EXCEPTION = "java.lang.NullPointerException";

	public static final String FILE_EXCEPTION = "File not imported due to exception.";

	public static final String EMPTY_STRING = "";

	public static final String PARAM_STATUS_CODE = "statusCode";

	public static final String PERM_USER_ROLE = "UserRole";

	public static final String PERM_VIEWER_ROLE = "ViewerRole";

	public static final String PERM_READER_ROLE = "ReaderRole";

	public static final String PERM_EDITOR_ROLE = "EditorRole";

	public static final String PARAM_PERM_ROLE = "permRole";

	public static final String PARAM_INHERIT_PERM = "isInheritPerm";

	public static final String PARAM_USER = "User";

	public static final String PARAM_VIEWER = "Viewer";

	public static final String PARAM_READER = "Reader";

	public static final String PARAM_EDITOR = "Editor";

	public static final String RES_OBJECT_NODEREF = "objectNodeRef";

	public static final String PARAM_FOLDER_NODE_REF_LIST = "folderNodeList";

	public static final String PARAM_FOLDER_NAME = "folderName";

	public static final String PARAM_MOUNT_POINT_FILE_LOC = "mountPointFileLocation";

	public static final String PARAM_CASCADE_PERMISSIONS = "cascadeFolderPermissions";

	public static final String PARAM_FLDR_JSON_METADATA = "folderJsonMetadata";

	public static final String PARAM_PERMISSION_JSON = "permissionsJson";

	public static final String PARAM_FOLDER_TITLE = "folderTitle";

	public static final String PARAM_FOLDER_DESC = "folderDesc";

	public static final String PARAM_DELIMETER = "alfServiceDelimeter";

	public static final String PARAM_BASE_FILE_NODEREF = "baseFileNodeRef";

	public static final String PARAM_IS_VERSIONABLE = "isVersionable";
	
	public static final String PARAM_TIME_ZONE = "TimeZone";
	
	public static final String PARAM_DATE_FORMAT = "dateFormat";

	/**
     * 
     */
	private MigrationConstants() {

	}

}
