package com.cisco.migration.service.webscripts;

import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_STATUS_MSG;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_ROOT_PATH_NODE_REF;
import static com.cisco.migration.service.webscripts.MigrationConstants.ROOT_PATH;

import java.util.HashMap;
import java.util.Map;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.edcsng.util.EDCSUtil;

/**
 * 
 * @author gpotla
 * 
 */
public class NodeRefByPathWebscript extends DeclarativeWebScript {

	private static final Logger LOG = Logger.getLogger(NodeRefByPathWebscript.class);

	private ServiceRegistry serviceRegistry;

	// for Spring injection
	public void setServiceRegistry(ServiceRegistry registry) {
		this.serviceRegistry = registry;
	}

	/**
	 * 
	 */
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status,
			Cache cache) {
		LOG.info("Custom NodeRefByPathWebscript.executeImpl() Start ");

		String rootPath = null;

		Map<String, Object> result = new HashMap<String, Object>();

		rootPath = req.getParameter(ROOT_PATH);
		LOG.info("rootPath --> "+rootPath);
		try {
			if(rootPath != null) {
				NodeRef rootPathRef = EDCSUtil.doSearch(rootPath + "\"", serviceRegistry);
				LOG.info("rootPathRef --> "+rootPathRef);
				if(rootPathRef != null) { 
					result.put(PARAM_ROOT_PATH_NODE_REF, rootPathRef.toString());
					result.put(PARAM_STATUS_MSG, "DocumentLibrary Path exist!!!");
				}else{
					throw new Exception();
				}
			}else{
				result.put(PARAM_ROOT_PATH_NODE_REF, "");
				result.put(PARAM_STATUS_MSG, "Please Provide rootPath as HTTPPost request parameter.");
			}
		} catch (Exception e) {
			LOG.error("Exeption occured in NodeRefByPathWebscript class :::: "+ e, e);
			result.put(PARAM_ROOT_PATH_NODE_REF, "");
			result.put(PARAM_STATUS_MSG, "Didn't find DocumentLibrary Path in Repository!!!");
		} finally {
			LOG.info("Custom NodeRefByPathWebscript.executeImpl()  finally block End ");
		}
		return result;
	}
}
