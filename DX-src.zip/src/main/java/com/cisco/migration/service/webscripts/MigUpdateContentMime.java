package com.cisco.migration.service.webscripts;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.version.common.VersionUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentData;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.migration.service.util.MigPostScriptConstants;

public class MigUpdateContentMime extends AbstractWebScript {
	private Logger log = Logger.getLogger(MigUpdateContentMime.class);
	private ServiceRegistry serviceRegistry;
	private BehaviourFilter policyBehaviourFilter;

	public BehaviourFilter getPolicyBehaviourFilter() {
		return policyBehaviourFilter;
	}

	public void setPolicyBehaviourFilter(BehaviourFilter policyBehaviourFilter) {
		this.policyBehaviourFilter = policyBehaviourFilter;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	Map<String, Object> model = new HashMap<String, Object>();

	@SuppressWarnings("unchecked")
	public void execute(WebScriptRequest webReq, WebScriptResponse webRes) throws IOException {

		String alfNodeRefString = webReq.getParameter(MigPostScriptConstants.PARAM_ORIGINAL_NODEREF);
		String mimeTypeString = webReq.getParameter(MigPostScriptConstants.PARAM_MIMETYPE_STRING);
		String fileExtension = webReq.getParameter(MigPostScriptConstants.PARAM_FILE_EXTENSION);

		NodeService nodeService = null;
		JSONObject responseObj = new JSONObject();
		responseObj.put(MigPostScriptConstants.PARAM_ORIGINAL_NODEREF, alfNodeRefString);
		responseObj.put(MigPostScriptConstants.PARAM_MIMETYPE_STRING, mimeTypeString);
		responseObj.put(MigPostScriptConstants.PARAM_FILE_EXTENSION, fileExtension);

		try {

			if (!isValueExist(alfNodeRefString) || !isValueExist(mimeTypeString)) {
				throw new WebScriptException("mandatory parameter is missing alfNodeRefString ==> " + alfNodeRefString
						+ " mimeTypeString ==> " + mimeTypeString);
			}

			nodeService = serviceRegistry.getNodeService();
			NodeRef alfNodeRef = new NodeRef(alfNodeRefString);
			if (!nodeService.exists(alfNodeRef)) {
				throw new WebScriptException("invalid nodeRef in the Request.." + alfNodeRefString);
			}

			// convert the version ref to update mimetype.
			if (serviceRegistry.getVersionService().isAVersion(alfNodeRef)) {
				alfNodeRef = VersionUtil.convertNodeRef(alfNodeRef);
			}

			policyBehaviourFilter.disableBehaviour(alfNodeRef, ContentModel.ASPECT_AUDITABLE);
			policyBehaviourFilter.disableBehaviour(alfNodeRef, MigPostScriptConstants.CISCODOC_TYPE);
			policyBehaviourFilter.disableBehaviour(alfNodeRef, ContentModel.ASPECT_VERSIONABLE);
			ContentData contentData = (ContentData) serviceRegistry.getNodeService().getProperty(alfNodeRef,
					ContentModel.PROP_CONTENT);
			ContentData newcontentData = ContentData.setMimetype(contentData, mimeTypeString);

			Map<QName, Serializable> nodePropMap = new HashMap<QName, Serializable>();
			nodePropMap.put(ContentModel.PROP_CONTENT, newcontentData);
			String originalFileName = (String) serviceRegistry.getNodeService().getProperty(alfNodeRef,
					ContentModel.PROP_NAME);
			String updatedFileName = originalFileName;
			if (isValueExist(fileExtension)) {
				String newFileName = replaceExtension(updatedFileName, fileExtension);
				updatedFileName = newFileName;
			}

			NodeRef parentNodeRef = serviceRegistry.getNodeService().getPrimaryParent(alfNodeRef).getParentRef();

			updatedFileName = getUniqueFileName(updatedFileName, parentNodeRef, alfNodeRef);
			// nodePropMap.put(ContentModel.PROP_NAME,updatedFileName);

			// nodeService.setProperty(alfNodeRef, ContentModel.PROP_CONTENT,
			// newcontentData);

			nodeService.addProperties(alfNodeRef, nodePropMap);

			if (updatedFileName != null && !updatedFileName.equalsIgnoreCase(originalFileName)) {
				serviceRegistry.getFileFolderService().rename(alfNodeRef, updatedFileName);
			}

			log.info("MimeType changed successfully");
			policyBehaviourFilter.enableBehaviour(alfNodeRef, ContentModel.ASPECT_VERSIONABLE);
			policyBehaviourFilter.enableBehaviour(alfNodeRef, MigPostScriptConstants.CISCODOC_TYPE);
			policyBehaviourFilter.enableBehaviour(alfNodeRef, ContentModel.ASPECT_AUDITABLE);
			responseObj.put("status", "update completed");
			responseObj.put(MigPostScriptConstants.PARAM_STATUS_MSG, "update finished successfully.");
			webRes.getWriter().write(responseObj.toString());

		} catch (Exception ex) {
			log.error("Error found in MigUpdateContentMime WebScript ==> ", ex);
			responseObj.put("status", "update failed");
			responseObj.put(MigPostScriptConstants.PARAM_ORIGINAL_NODEREF, alfNodeRefString);
			responseObj.put(MigPostScriptConstants.PARAM_MIMETYPE_STRING, mimeTypeString);
			responseObj.put(MigPostScriptConstants.PARAM_STATUS_MSG,
					isValueExist(ex.getMessage()) ? ex.getMessage() : "unknown Server error");
			webRes.getWriter().write(responseObj.toString());
		}

	}

	private boolean isValueExist(String fieldValue) {
		boolean valueExist = false;
		if (fieldValue != null && fieldValue.trim().length() != 0) {
			valueExist = true;
		}
		return valueExist;
	}

	private static String replaceExtension(String alfFileName, String extension) {
		String ext = "";
		String finalFileName = alfFileName;
		if (alfFileName != null && extension != null) {
			alfFileName = alfFileName.trim();
			int index = alfFileName.lastIndexOf('.');
			if (index > -1 && (index < alfFileName.length() - 1)) {
				finalFileName = alfFileName.substring(0, index).concat(".").concat(extension);
			} else {
				finalFileName = alfFileName.concat(".").concat(extension);
			}
		}
		return finalFileName;
	}

	public String getUniqueFileName(String name, NodeRef parentNodeRef, NodeRef currentNodeRef) {
		boolean fileNameExists = true;
		String filename = name;
		String tempFileName = name;
		int dotIndex, counter = 1;
		while (fileNameExists) {
			NodeRef node = serviceRegistry.getFileFolderService().searchSimple(parentNodeRef, tempFileName);
			if (node != null && !currentNodeRef.equals(node)) {
				dotIndex = filename.lastIndexOf(".");
				if (dotIndex == 0) {
					// File didn't have a proper 'name' instead it had just a suffix and started
					// with a ".", create "1.txt"
					tempFileName = counter + filename;
				} else if (dotIndex > 0) {

					String fileNameWithoutExtension = filename.substring(0, dotIndex);
					Pattern p = Pattern.compile("(.*)-[\\d]+$");
					Matcher m = p.matcher(fileNameWithoutExtension);

					String updatedName = fileNameWithoutExtension;
					if (m.matches()) {
						updatedName = m.group(1);
					}

					// Filename contained ".", create "filename-1.txt"
					// tempFileName = filename.substring(0, dotIndex) + "-" + counter +
					// filename.substring(dotIndex);

					tempFileName = updatedName + "-" + counter + filename.substring(dotIndex);

				} else {
					// Filename didn't contain a dot at all, create "filename-1"
					tempFileName = filename + "-" + counter;
				}
				counter++;
			} else {
				fileNameExists = false;
			}
		}

		return tempFileName;
	}

}
