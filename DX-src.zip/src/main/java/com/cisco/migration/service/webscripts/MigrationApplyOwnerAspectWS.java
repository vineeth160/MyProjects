package com.cisco.migration.service.webscripts;

import static com.cisco.migration.service.util.MigPostScriptConstants.PARAM_BASE_FILE_NODEREF;
import static com.cisco.migration.service.util.MigPostScriptConstants.PARAM_STATUS_MSG;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.version.common.VersionUtil;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.version.VersionService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.migration.service.util.MigPostScriptConstants;

public class MigrationApplyOwnerAspectWS extends AbstractWebScript {

	private static final Logger LOG = Logger.getLogger(MigrationApplyOwnerAspectWS.class);
	private NodeService nodeService;
	private BehaviourFilter policyBehaviourFilter;
	private VersionService versionService;

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public void setPolicyBehaviourFilter(BehaviourFilter policyBehaviourFilter) {
		this.policyBehaviourFilter = policyBehaviourFilter;
	}

	public void setVersionService(VersionService versionService) {
		this.versionService = versionService;
	}

	@Override
	public void execute(WebScriptRequest request, WebScriptResponse response) throws IOException {

		String docNodeRef = request.getParameter(PARAM_BASE_FILE_NODEREF);
		if (LOG.isDebugEnabled()) {
			LOG.info("********MigrationApplyOwnerAspectWS execute start********");
			LOG.info("Current Processing NodeRef ====> " + docNodeRef);
		}

		JSONObject responseObj = new JSONObject();

		try {
			if (docNodeRef != null && !docNodeRef.trim().equals("")) {
				String docOwner = request.getParameter(MigPostScriptConstants.PARAM_CONTENT_OWNER);
				String statusMsg = applyOwnerAspect(new NodeRef(docNodeRef.trim()), docOwner);
				responseObj.put(PARAM_STATUS_MSG, statusMsg);
				responseObj.put(PARAM_BASE_FILE_NODEREF, docNodeRef);
			} else {
				responseObj.put(PARAM_STATUS_MSG, "Please provide the Base File NodeRef.");
				responseObj.put(PARAM_BASE_FILE_NODEREF, "");
			}

		} catch (Exception e) {
			LOG.error(" Exception while applying owner Aspect in execute..." + e, e);
			try {
				responseObj.put(PARAM_STATUS_MSG, (e != null) ? e.getMessage() : "Exception Obj is Null");
				responseObj.put(PARAM_BASE_FILE_NODEREF, docNodeRef);
			} catch (JSONException e1) {
				LOG.error("*******Exception parsing Json**********");
				e1.printStackTrace();
			}
		} finally {
			LOG.info("In MigrationApplyOwnerAspectWS.executeImpl() finally block End ");
		}
		response.getWriter().write(responseObj.toString());
	}

	private String applyOwnerAspect(NodeRef nodeRef, String docOwner) {
		if (LOG.isDebugEnabled()) {
			LOG.debug(" apply ownser aspect method ::: " + nodeRef);
		}
		String statusMsg = "applying owner aspect failed";

		NodeRef contentNodeRef = nodeRef;

		if (LOG.isDebugEnabled()) {
			LOG.debug(" Current NodeRef =====> " + contentNodeRef.toString());
			LOG.debug(" isVersioned NodeRef or  Not ====> " + versionService.isAVersion(contentNodeRef));
			LOG.debug(" new Versioned NodeRef ====> " + VersionUtil.convertNodeRef(contentNodeRef).toString());
		}

		if (versionService.isAVersion(contentNodeRef)) {
			contentNodeRef = VersionUtil.convertNodeRef(contentNodeRef);
		}

		boolean hasAspect = this.nodeService.hasAspect(contentNodeRef, ContentModel.ASPECT_OWNABLE);

		try {
			policyBehaviourFilter.disableBehaviour(contentNodeRef, ContentModel.ASPECT_AUDITABLE);
			policyBehaviourFilter.disableBehaviour(contentNodeRef, MigPostScriptConstants.CISCODOC_TYPE);
			policyBehaviourFilter.disableBehaviour(contentNodeRef, ContentModel.ASPECT_VERSIONABLE);
			if (hasAspect) {
				nodeService.setProperty(contentNodeRef, ContentModel.PROP_OWNER, docOwner);
			} else {
				Map<QName, Serializable> updatePropsMap = new HashMap<>();
				updatePropsMap.put(ContentModel.PROP_OWNER, docOwner);
				nodeService.addAspect(contentNodeRef, ContentModel.ASPECT_OWNABLE, updatePropsMap);
			}
			statusMsg = "Owner aspect updated..";
		} catch (Exception e) {
			LOG.error(" Exception while adding owner Aspect..." + e, e);
			throw e;
		} finally {
			policyBehaviourFilter.enableBehaviour(contentNodeRef, ContentModel.ASPECT_VERSIONABLE);
			policyBehaviourFilter.enableBehaviour(contentNodeRef, ContentModel.ASPECT_AUDITABLE);
			policyBehaviourFilter.enableBehaviour(contentNodeRef, MigPostScriptConstants.CISCODOC_TYPE);
		}

		return statusMsg;
	}

}
