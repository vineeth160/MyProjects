package com.cisco.migration.service.webscripts;

import static com.cisco.migration.service.util.MigPostScriptConstants.PARAM_BASE_FILE_NODEREF;
import static com.cisco.migration.service.util.MigPostScriptConstants.PARAM_STATUS_MSG;

import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.migration.service.util.MigPostProcessPermissionsUtil;
import com.cisco.migration.service.util.MigPostScriptConstants;

public class MigApplyUserPreferenceWS extends AbstractWebScript {

	private static final Logger log = Logger.getLogger(MigApplyUserPreferenceWS.class);

	private BehaviourFilter policyFilter;
	private NodeService nodeService;
	private MigPostProcessPermissionsUtil processPermUtil;

	public void setPolicyFilter(BehaviourFilter policyFilter) {
		this.policyFilter = policyFilter;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public void setProcessPermUtil(MigPostProcessPermissionsUtil processPermUtil) {
		this.processPermUtil = processPermUtil;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void execute(WebScriptRequest request, WebScriptResponse response) throws IOException {

		// build a json object
		JSONObject responseObj = new JSONObject();
		String contentNodeRef = request.getParameter(MigPostScriptConstants.RES_OBJECT_NODEREF);
		Map<String, String> templateArgs = request.getServiceMatch().getTemplateVars();
		String actionString = templateArgs.get("action");
		Boolean actionType = null;
		if(actionString.equalsIgnoreCase("add")) {
			actionType = true;
		}else if(actionString.equalsIgnoreCase("remove")) {
			actionType = false;
		}else {
			responseObj.put(PARAM_STATUS_MSG, "provide valide action type");
			responseObj.put(PARAM_BASE_FILE_NODEREF, contentNodeRef);
			response.getWriter().write(responseObj.toJSONString());
			return;
		}
		
		

		try {
			log.debug("=======================MigApplyUserPreferenceWS===================");
			log.debug("Content NodeRef ===> " + contentNodeRef);

			if (contentNodeRef != null && !contentNodeRef.trim().equals("")) {
				NodeRef folderRef = new NodeRef(contentNodeRef.trim());
				if (!nodeService.exists(folderRef)) {
					responseObj.put(PARAM_STATUS_MSG, "folder noderef not exist");
					responseObj.put(PARAM_BASE_FILE_NODEREF, contentNodeRef);
					response.getWriter().write(responseObj.toJSONString());
					return;
				}

				policyFilter.disableBehaviour(folderRef, ContentModel.ASPECT_AUDITABLE);
				policyFilter.disableBehaviour(folderRef, MigPostScriptConstants.CISCODOC_TYPE);
				policyFilter.disableBehaviour(folderRef, ContentModel.ASPECT_VERSIONABLE);

				Set<AccessPermission> userPermisions = processPermUtil.getNodePermissions(folderRef);
				NodeRef alfParentRef = nodeService.getPrimaryParent(folderRef).getParentRef();
				//Set<String> parentUserPermSet = processPermUtil.getParentNodeUsers(alfParentRef);
				String nodeOwner = (String) nodeService.getProperty(alfParentRef,ContentModel.PROP_CREATOR);
				log.debug("Parent Node Owner ====> " + nodeOwner);
				
				Set<String> parentPermissionsList = new HashSet<>();
				Set<AccessPermission> userParentPermissions = processPermUtil.getNodePermissions(alfParentRef);
				if(userParentPermissions != null && userParentPermissions.size() > 0) {
					for(AccessPermission accessPermission : userParentPermissions) {
						if(!accessPermission.isInherited()) {
							parentPermissionsList.add(accessPermission.getAuthority());
						}
					}
				}
				
				
				String currentNodeOwner = (String) nodeService.getProperty(folderRef,ContentModel.PROP_CREATOR);
				Boolean isRootFolder = (Boolean) nodeService.getProperty(folderRef,MigPostScriptConstants.MIG_IS_ROOT_FOLDER);
				
				String statusMsg = "preference apply failed";
				for (AccessPermission permission : userPermisions) {
					String alfAuthority = permission.getAuthority();
					AuthorityType authType = permission.getAuthorityType();
					if (actionType) {
						
						log.debug("Preference update for nodeRef ===> " + folderRef + " user==>" + alfAuthority);
						log.debug(" parent compare ===> " + alfAuthority.trim().equalsIgnoreCase(nodeOwner));
						log.debug(" same node compare ===> " + alfAuthority.trim().equalsIgnoreCase(currentNodeOwner));
						
						if (!permission.isInherited()
								&& (authType.equals(AuthorityType.USER) || authType.equals(AuthorityType.ADMIN)
										|| authType.equals(AuthorityType.OWNER)) && isValidUserName(alfAuthority))
						{
								if(Boolean.TRUE.equals(isRootFolder)) {
									processPermUtil.updateUserPreference(alfAuthority, folderRef, actionType);
								}
								/*//current user is created the parent node
								else if(alfAuthority.trim().equalsIgnoreCase(nodeOwner)) {
										if(!alfAuthority.trim().equalsIgnoreCase(currentNodeOwner)) {
											processPermUtil.updateUserPreference(alfAuthority, folderRef, actionType);
										}
								}else {
									if(!alfAuthority.trim().equalsIgnoreCase(currentNodeOwner)) {
										processPermUtil.updateUserPreference(alfAuthority, folderRef, actionType);
									}
								}*/
								
								else if(!alfAuthority.trim().equalsIgnoreCase(currentNodeOwner)) {
									if(!processPermUtil.isNodeExistingUserPreference(alfAuthority,alfParentRef) && !parentPermissionsList.contains(alfAuthority)) {
										processPermUtil.updateUserPreference(alfAuthority, folderRef, actionType);
									}
								}
						}
					} else {
						if (!permission.isInherited() && (authType.equals(AuthorityType.USER)
								|| authType.equals(AuthorityType.ADMIN) || authType.equals(AuthorityType.OWNER))) {
							processPermUtil.updateUserPreference(alfAuthority, folderRef, actionType);
						}
					}
				}
				statusMsg = "apply preference completed..";
				policyFilter.enableBehaviour(folderRef, ContentModel.ASPECT_VERSIONABLE);
				policyFilter.enableBehaviour(folderRef, MigPostScriptConstants.CISCODOC_TYPE);
				policyFilter.enableBehaviour(folderRef, ContentModel.ASPECT_AUDITABLE);
				responseObj.put(PARAM_STATUS_MSG, statusMsg);
				responseObj.put(PARAM_BASE_FILE_NODEREF, contentNodeRef);

			} else {
				responseObj.put(PARAM_STATUS_MSG, "Please provide the Base File NodeRef.");
				responseObj.put(PARAM_BASE_FILE_NODEREF, contentNodeRef);
			}
			response.getWriter().write(responseObj.toJSONString());
		} catch (Exception ex) {
			log.error(" Exception while updating properties ..." + ex, ex);
			responseObj.put(MigPostScriptConstants.PARAM_STATUS_MSG,
					(ex != null) ? ex.getMessage() : MigPostScriptConstants.NULL_EXCEPTION);
			responseObj.put(MigPostScriptConstants.PARAM_FILE_NODE_REF, contentNodeRef);
			response.getWriter().write(responseObj.toString());
		} finally {
			log.debug("MigApplyUserPreferenceWS execute Method finally block...");
		}

	}
	private boolean isValidUserName(String userName)
    {
        boolean isValid = false;
        Pattern pattern = Pattern.compile("([\"*\\\\><?/:|]+)|([.]?[.]+$)");
        Matcher matcher = pattern.matcher(userName);
        isValid = !matcher.find();
        return isValid;
    }

}