package com.cisco.migration.service.webscripts;

import static com.cisco.migration.service.util.MigPostScriptConstants.PARAM_BASE_FILE_NODEREF;
import static com.cisco.migration.service.util.MigPostScriptConstants.PARAM_STATUS_MSG;

import java.io.IOException;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.version.common.VersionUtil;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.version.VersionService;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.migration.service.util.MigPostScriptConstants;


public class MigrationManageHiddenAspectWS extends AbstractWebScript {

	private static final Logger LOG = Logger.getLogger(MigrationManageHiddenAspectWS.class);
	private NodeService nodeService;
	private BehaviourFilter policyBehaviourFilter;
	private VersionService versionService;

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public void setPolicyBehaviourFilter(BehaviourFilter policyBehaviourFilter) {
		this.policyBehaviourFilter = policyBehaviourFilter;
	}

	
	public void setVersionService(VersionService versionService) {
		this.versionService = versionService;
	}

	@Override
	public void execute(WebScriptRequest request, WebScriptResponse response) throws IOException {

		String docNodeRef = request.getParameter(PARAM_BASE_FILE_NODEREF);
		if (LOG.isDebugEnabled()) {
			LOG.info("********MigrationManageAspectWS execute start********");
			LOG.info("Current Processing NodeRef ====> " + docNodeRef);
		}

		JSONObject responseObj = new JSONObject();

		try {
			if (docNodeRef != null && !docNodeRef.trim().equals("")) {
				String statusMsg = removeHiddenAspect(new NodeRef(docNodeRef.trim()));
				responseObj.put(PARAM_STATUS_MSG, statusMsg);
				responseObj.put(PARAM_BASE_FILE_NODEREF, docNodeRef);
			} else {
				responseObj.put(PARAM_STATUS_MSG, "Please provide the Base File NodeRef.");
				responseObj.put(PARAM_BASE_FILE_NODEREF, "");
			}

		} catch (Exception e) {
			LOG.error(" Exception while removing Hidden Aspect ..." + e, e);
			try {
				responseObj.put(PARAM_STATUS_MSG, (e != null) ? e.getMessage() : "Exception Obj is Null");
				responseObj.put(PARAM_BASE_FILE_NODEREF, docNodeRef);
			} catch (JSONException e1) {
				LOG.error("*******Exception parsing Json**********");
				e1.printStackTrace();
			}
		} finally {
			LOG.info("In MigrationVersionableAspectWebScript.executeImpl() finally block End ");
		}
		response.getWriter().write(responseObj.toString());
	}

	private String removeHiddenAspect(NodeRef nodeRef) {
		if (LOG.isDebugEnabled()) {
			LOG.debug(" Removing Hidden Aspect inside MigrationManageHiddenAspectWS ::: " + nodeRef);
		}
		String statusMsg = " Hidden Aspect not found for this node.";

		NodeRef contentNodeRef = nodeRef;

		if (LOG.isDebugEnabled()) {
			LOG.debug(" Current NodeRef =====> " + contentNodeRef.toString());
			LOG.debug(" isVersioned NodeRef or  Not ====> " + versionService.isAVersion(contentNodeRef));
			LOG.debug(" new Versioned NodeRef ====> " + VersionUtil.convertNodeRef(contentNodeRef).toString());
		}

		if (versionService.isAVersion(contentNodeRef)) {
			contentNodeRef = VersionUtil.convertNodeRef(contentNodeRef);
		}

		boolean hasAspect = this.nodeService.hasAspect(contentNodeRef, ContentModel.ASPECT_HIDDEN);

		try {
			if (hasAspect) {
				policyBehaviourFilter.disableBehaviour(contentNodeRef, ContentModel.ASPECT_AUDITABLE);
				policyBehaviourFilter.disableBehaviour(contentNodeRef, MigPostScriptConstants.CISCODOC_TYPE);
				this.nodeService.removeAspect(contentNodeRef, ContentModel.ASPECT_HIDDEN);
				policyBehaviourFilter.enableBehaviour(contentNodeRef, ContentModel.ASPECT_AUDITABLE);
				policyBehaviourFilter.enableBehaviour(contentNodeRef, MigPostScriptConstants.CISCODOC_TYPE);
				statusMsg = " Hidden Aspect removed.";
			}
		} catch (Exception e) {
			LOG.error(" Exception while removing Hidden Aspect..." + e, e);
			throw e;
		}
		return statusMsg;
	}

}
