package com.cisco.migration.service.webscripts;

import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_STATUS_MSG;
import static com.cisco.migration.service.webscripts.MigrationConstants.RES_OBJECT_NODEREF;

import java.util.HashMap;
import java.util.Map;

import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.migration.service.util.VersionsUtil;

/**
 * 
 * @author gpotla
 * 
 */
public class MigrationVersioningWebScript extends DeclarativeWebScript {

    private static final Logger LOG = Logger.getLogger(MigrationVersioningWebScript.class);

    private VersionsUtil versionsUtil;
    
	public void setVersionsUtil(VersionsUtil versionsUtil) {
		this.versionsUtil = versionsUtil;
	}

	
    /**
	 * 
	 */
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status,
			Cache cache) {
		LOG.info("In MigrationVersioningWebScript.executeImpl() Start ");
		
		Map<String, Object> result = new HashMap<String, Object>();
		
		String contentNodeRef = req.getParameter(RES_OBJECT_NODEREF);
        
        
		if(contentNodeRef != null) {
			
			try {
				NodeRef objectNodeRef = new NodeRef(contentNodeRef);
				result = this.versionsUtil.doCreateVersions(objectNodeRef);
			} catch (Exception e) {
				LOG.error(" Exception while creating version(s) ..." + e, e);
				result.put(PARAM_STATUS_MSG, e.getMessage());
				result.put(RES_OBJECT_NODEREF, "");
			} finally {
				LOG.info("In MigrationVersioningWebScript.executeImpl() finally block End ");
			}
			
		} else {
			result.put(PARAM_STATUS_MSG, "Please Provide File/Folder Node Reference as Request Parameter.");
			result.put(RES_OBJECT_NODEREF, "");
		}

        return result;
	}

}
