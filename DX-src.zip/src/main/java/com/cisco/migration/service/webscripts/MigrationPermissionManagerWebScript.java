package com.cisco.migration.service.webscripts;

import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_CONTENT_OWNER;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_PERMISSION_JSON;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_STATUS_MSG;
import static com.cisco.migration.service.webscripts.MigrationConstants.RES_OBJECT_NODEREF;

import java.util.HashMap;
import java.util.Map;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.migration.service.util.PermissionsUtil;

/**
 * 
 * @author gpotla
 * 
 */
public class MigrationPermissionManagerWebScript extends DeclarativeWebScript {

    private static final Logger LOG = Logger.getLogger(MigrationPermissionManagerWebScript.class);
    
    private ServiceRegistry serviceRegistry;

	private PermissionsUtil  permissionsUtil;

    public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
    
	public void setPermissionsUtil(PermissionsUtil permissionsUtil) {
		this.permissionsUtil = permissionsUtil;
	}

   /**
    * 
    */
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status,
			Cache cache) {
		LOG.info("In MigrationPermissionManagerWebScript.executeImpl() Start ");
		
		Map<String, Object> result = new HashMap<String, Object>();
		
		String contentNodeRef = req.getParameter(RES_OBJECT_NODEREF);
        
        String contentowner = req.getParameter(PARAM_CONTENT_OWNER);
        LOG.info(" contentowner = " + contentowner);
        
        String inhertPerm = req.getParameter(MigrationConstants.PARAM_INHERIT_PERM);
        boolean isInheritPerm = (inhertPerm != null) ? Boolean.valueOf(inhertPerm) : false;
        
        String permissionsJson = req.getParameter(PARAM_PERMISSION_JSON);
        
		if(contentNodeRef != null) {
			
			try {
				NodeRef objectNodeRef = new NodeRef(contentNodeRef);
				if(isInheritPerm) {
			        ChildAssociationRef childAssociationRef = this.serviceRegistry.getNodeService().getPrimaryParent(objectNodeRef);
			    	NodeRef parentNodeRef = childAssociationRef.getParentRef();
			    	permissionsUtil.setInheritPermissions(parentNodeRef, isInheritPerm);
		        }
				result = this.permissionsUtil.attachPermissions(objectNodeRef, permissionsJson);
				
				
			} catch (Exception e) {
				LOG.error(" Exception while adding Permission(s) ..." + e, e);
				result.put(PARAM_STATUS_MSG, e.getMessage());
				result.put(RES_OBJECT_NODEREF, "");
			} finally {
				LOG.info("In MigrationPermissionManagerWebScript.executeImpl() finally block End ");
			}
			
		} else {
			result.put(PARAM_STATUS_MSG, "Please Provide File/Folder Node Reference as Request Parameter.");
			result.put(RES_OBJECT_NODEREF, "");
		}

        return result;
	}

}
