package com.cisco.migration.service.util;

import org.alfresco.service.cmr.security.AccessStatus;
import org.alfresco.service.cmr.security.AuthorityType;

public class UserPermission {

	private AuthorityType  authorityType = AuthorityType.USER;
	private boolean isInherited = false;
	private String permission = "Read";
	private AccessStatus accessStatus = AccessStatus.ALLOWED;
	

	public AuthorityType getAuthorityType() {
		return authorityType;
	}
	public void setAuthorityType(AuthorityType authorityType) {
		this.authorityType = authorityType;
	}
	public boolean isInherited() {
		return isInherited;
	}
	public void setInherited(boolean isInherited) {
		this.isInherited = isInherited;
	}
	public String getPermission() {
		return permission;
	}
	public void setPermission(String permission) {
		this.permission = permission;
	}
	
	
	public AccessStatus getAccessStatus() {
		return accessStatus;
	}
	public void setAccessStatus(AccessStatus accessStatus) {
		this.accessStatus = accessStatus;
	}
	@Override
	public String toString() {
		return "UserPermission [authorityType=" + authorityType + ", isInherited=" + isInherited + ", permission="
				+ permission + ", accessStatus=" + accessStatus + "]";
	}
	
}
