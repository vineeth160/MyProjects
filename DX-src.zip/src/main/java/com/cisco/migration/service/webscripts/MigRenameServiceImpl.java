package com.cisco.migration.service.webscripts;

import java.io.FileWriter;
import java.io.IOException;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileExistsException;
import org.alfresco.service.cmr.model.FileFolderService;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.model.FileNotFoundException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.NamespaceService;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;
import com.cisco.migration.service.util.MigPostScriptConstants;
import com.csvreader.CsvWriter;

/**
 * Service for renaming a file or folder
 * 
 * @author mumuthar
 *
 */
public class MigRenameServiceImpl extends AbstractWebScript {

	private ServiceRegistry serviceRegistry;
	private FileFolderService fileFolderService;
	private NodeService nodeService;
	private NamespaceService namespaceService;
	private BehaviourFilter policyBehaviourFilter;

	// Delimiter used in CSV file

	private static final String DELIMITER = "|";

	private static final String NEW_LINE_SEPARATOR = "\n";

	private Logger logger = Logger.getLogger(MigRenameServiceImpl.class);

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse resp)
			throws IOException {
		fileFolderService = serviceRegistry.getFileFolderService();
		nodeService = serviceRegistry.getNodeService();
		namespaceService = serviceRegistry.getNamespaceService();

		String strNodeRef = req.getParameter("nodeRef");
		String modifiedFileName = req.getParameter("name");
		String outputFileLocation = req.getParameter("outputFileLocation");
		FileWriter fileWriter = new FileWriter(outputFileLocation,true);
		CsvWriter csvWriter = new CsvWriter(fileWriter, ',');
		csvWriter.write("nodeRef");
		csvWriter.write("original name");
		csvWriter.write("modified name");
		csvWriter.endRecord();
		NodeRef nodeRef = new NodeRef(strNodeRef);
		String originalName  = fileFolderService.getFileInfo(nodeRef).getName();
		/*List<FileInfo> subFolders = fileFolderService.listDeepFolders(nodeRef,
				null);
		for (FileInfo fileInfo : subFolders) {
			try {*/
				/*String modifiedFileName = fileInfo.getName().replaceFirst("_",
						",").replaceFirst("_", "");*/
				FileInfo renamedFileInfo = null;
				try {
					
					policyBehaviourFilter.disableBehaviour(nodeRef, ContentModel.ASPECT_AUDITABLE);
					policyBehaviourFilter.disableBehaviour(nodeRef, MigPostScriptConstants.CISCODOC_TYPE);
					policyBehaviourFilter.disableBehaviour(nodeRef, ContentModel.ASPECT_VERSIONABLE);
					renamedFileInfo = fileFolderService.rename(
							nodeRef, modifiedFileName);
				} catch (FileExistsException | FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally{
					policyBehaviourFilter.enableBehaviour(nodeRef, ContentModel.ASPECT_VERSIONABLE);
					policyBehaviourFilter.enableBehaviour(nodeRef, MigPostScriptConstants.CISCODOC_TYPE);
					policyBehaviourFilter.enableBehaviour(nodeRef, ContentModel.ASPECT_AUDITABLE);
				}
				//if(!fileInfo.getName().equals(renamedFileInfo.getName())){
				csvWriter.write(renamedFileInfo.getNodeRef().toString());
				csvWriter.write(originalName);
				csvWriter.write(renamedFileInfo.getName());
				csvWriter.endRecord();
				//}
				System.out.println(renamedFileInfo.getName());
			/*} catch (FileExistsException | FileNotFoundException e) {
				logger.error(e.getMessage());
			}
		}*/
		
		csvWriter.close();

	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
	
	public void setPolicyBehaviourFilter(BehaviourFilter policyBehaviourFilter)
	{
		this.policyBehaviourFilter = policyBehaviourFilter;
	}

}
