package com.cisco.migration.service.util;

import static com.cisco.migration.service.webscripts.MigrationConstants.EMPTY_STRING;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FOLDER_NAME;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FOLDER_NODE_REF;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FOLDER_NODE_REF_LIST;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_STATUS_CODE;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_STATUS_MSG;

import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileFolderService;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;

/**
 * 
 * @author gpotla
 *
 */
public class FolderUtil {
	
	private static final Logger LOG = Logger.getLogger(FolderUtil.class);

	private ServiceRegistry serviceRegistry;

	private FileFolderService fileFolderService;
	
	private PermissionsUtil permissionsUtil;

	private MigrationUtils migrationUtils;
	

	public PermissionsUtil getPermissionsUtil() {
		return permissionsUtil;
	}

	public void setPermissionsUtil(PermissionsUtil permissionsUtil) {
		this.permissionsUtil = permissionsUtil;
	}
	
	public void setMigrationUtils(MigrationUtils migrationUtils) {
		this.migrationUtils = migrationUtils;
	}
	
	public void setFileFolderService(FileFolderService fileFolderService) {
		this.fileFolderService = fileFolderService;
	}

	public void setServiceRegistry(ServiceRegistry registry) {
		this.serviceRegistry = registry;
	}
	
	/**
	 * 
	 * @param rootPath
	 * @param folderPath
	 * @param isOverWrite
	 * @param attachFolderMetadata
	 * @param tagAttributes
	 * @return Map<String, Object>
	 */
    public Map<String, Object> createFolders(String rootPath, String folderPath, String folderTitle, String folderDesc, boolean isOverWrite, boolean attachFolderMetadata, String jsonMetaProp, 
    		boolean attachFolderTagging, String tagAttributes, String contentowner, boolean cascadeFolderPermissions, String permissionsJson, String alfServiceDelimeter, String dateFormat, String timeZone)
            throws Exception {
        LOG.info("In FolderUtil.createFolders Start ");
        
        NodeRef existingFolderRef = null;
        
        NodeRef rootPathNodeRef = new NodeRef(rootPath);
        
        String[] folderNames = folderPath.split("/");
       
        Map<String, Object> result = new HashMap<String, Object>();
        
        Map<String, Object> folderNodeList = new HashMap<String, Object>();
        
        int folderCount = 0;

        LOG.info("rootPath = " + rootPathNodeRef + "\t  folderPath = " + folderPath);
        
        try {
            
            for (int i = 0; i < folderNames.length; i++) {
                if (folderNames[i] != null && !folderNames[i].trim().equals(EMPTY_STRING)) {

                    LOG.info(" folderName ::: " + folderNames[i] + "\t  parentNodeRef = " + rootPathNodeRef);

                    existingFolderRef = fileFolderService.searchSimple(rootPathNodeRef, folderNames[i]);

                    LOG.info(" ExistingFolderRef from fileFolderService.searchSimple is " + existingFolderRef);

                    if (existingFolderRef == null) {
                    	folderCount = folderCount+1;
                    	FileInfo fileInfo = fileFolderService.create(rootPathNodeRef, folderNames[i], ContentModel.TYPE_FOLDER);
                    	rootPathNodeRef = fileInfo.getNodeRef();
                    	
                    	// Adding created folderName and nodeRef to response object
                    	folderNodeList.put(folderCount+"~"+folderNames[i], rootPathNodeRef.toString());
                    	
                    	if(folderTitle != null) {
                    		this.serviceRegistry.getNodeService().setProperty(rootPathNodeRef, ContentModel.PROP_TITLE, folderTitle);
                    	}
                    	
                    	if(folderDesc != null) {
                    		this.serviceRegistry.getNodeService().setProperty(rootPathNodeRef, ContentModel.PROP_DESCRIPTION, folderDesc);
                    	}
                    	
                    	// Setting inherit parent permissions
                    	this.serviceRegistry.getPermissionService().setInheritParentPermissions(rootPathNodeRef, cascadeFolderPermissions);
                    	
                    	LOG.info(" Folder we are created nodeRef is (fileFolderService.create)" + rootPathNodeRef);
                    	
                    	// setting aspects to the created folders
                        if (attachFolderMetadata) {
                        	LOG.info(" JSON folder MetaData --- "+ jsonMetaProp);
                            migrationUtils.attachMetaData(jsonMetaProp, rootPathNodeRef, alfServiceDelimeter, dateFormat, timeZone);
                        }
                        
                        // setting Tag attributes to the created folders
                        attachTagsToFolders(attachFolderTagging, tagAttributes, rootPathNodeRef, alfServiceDelimeter);
                       
                        // Setting the content owner to the created folders
                        attachPermissions(rootPathNodeRef, contentowner,permissionsJson, cascadeFolderPermissions );
                        
                        LOG.info(" contentowner set to --- > " + rootPathNodeRef + " as " + contentowner);
                        
                        result.put(PARAM_STATUS_MSG, "Folder created successfully!!!");

                    } else {
                    	folderCount = 0;
                    	// if already the folder path is existing
                        rootPathNodeRef = existingFolderRef;

                        if(isOverWrite) {
                            attachTagsToFolders(attachFolderTagging, tagAttributes, rootPathNodeRef, alfServiceDelimeter);
                        }
                        result.put(PARAM_STATUS_MSG, "Folder already exist!!!");
                    }
                    
                    result.put(PARAM_FOLDER_NODE_REF, rootPathNodeRef.toString());
                    result.put(PARAM_FOLDER_NODE_REF_LIST, folderNodeList);
                    result.put(PARAM_FOLDER_NAME, folderNames[i]);
                    result.put(PARAM_STATUS_CODE, "200");
                }
            }
        } catch (Exception e) {
            LOG.error(" Exception while creating folder ..." + e, e);
            result.put(PARAM_STATUS_MSG, e.getMessage());
            result.put(PARAM_FOLDER_NODE_REF, folderNodeList);
            result.put(PARAM_FOLDER_NODE_REF_LIST, new HashMap<String , Object>());
            result.put(PARAM_FOLDER_NAME, "");
            result.put(PARAM_STATUS_CODE, "400");
        } finally {
            LOG.info("In FolderServiceImpl.constructFolderPath() finally block End ");
        }
        
        return result;
    }
    
    /**
     * 
     * @param request
     * @param tagNodeRef
     */
    public void attachTagsToFolders(boolean attachFolderTagging, String tagAttributes, NodeRef tagNodeRef , String alfServiceDelimeter) {
        LOG.info(" attachFolderTagging  =  " + attachFolderTagging);
        if (attachFolderTagging) {
        	migrationUtils.attachTagAttributes(tagNodeRef, tagAttributes, alfServiceDelimeter);
        }

    }
    
    /**
     * 
     * @param request
     * @param uploadFileNode
     * @throws Exception 
     */
    public void attachPermissions(NodeRef folderNodeRef, String contentowner, String permissionsJson, boolean cascadeFolderPermissions) throws Exception {
        LOG.info(" FolderUtil.attachPermissions()  for folder Node ::: " + folderNodeRef);
        
        if(permissionsJson != null) {
        	permissionsUtil.attachPermissions(folderNodeRef, permissionsJson);
        }
        
        if(contentowner != null && !contentowner.trim().equals("")) {
	        // Setting Content Owner
	    	this.serviceRegistry.getOwnableService().setOwner(folderNodeRef, contentowner);
        }
    }
}