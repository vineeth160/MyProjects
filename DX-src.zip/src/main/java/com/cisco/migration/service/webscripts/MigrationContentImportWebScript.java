package com.cisco.migration.service.webscripts;

import static com.cisco.migration.service.webscripts.MigrationConstants.EMPTY_STRING;
import static com.cisco.migration.service.webscripts.MigrationConstants.FOLDER_PATH;
import static com.cisco.migration.service.webscripts.MigrationConstants.NULL_EXCEPTION;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_ATTACH_FILE_METADATA;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_ATTACH_FILE_TAGGING;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_BASE_FILE_NODEREF;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_CASCADE_PERMISSIONS;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_CONTENT_OWNER;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_DELIMETER;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_ENCODING;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FIELD;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FILE_NAME;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FILE_NODE_REF;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FOLDER_NAME;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FOLDER_NODE_REF;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_FOLDER_NODE_REF_LIST;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_IS_VERSIONABLE;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_JSON_COMMON_PROPS;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_JSON_METADATA;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_MIMETYPE;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_MOUNT_POINT_FILE_LOC;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_OVERWRITE;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_PERMISSION_JSON;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_STATUS_CODE;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_STATUS_MSG;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_TAGGING_ATTRIBUTES;
import static com.cisco.migration.service.webscripts.MigrationConstants.ROOT_PATH;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_TIME_ZONE;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_DATE_FORMAT;

import java.util.HashMap;
import java.util.Map;

import org.alfresco.service.cmr.model.FileFolderService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.servlet.FormData;

import com.cisco.migration.service.util.FileUtil;

/**
 * 
 * @author gpotla
 * 
 */
public class MigrationContentImportWebScript extends DeclarativeWebScript {

    private static final Logger LOG = Logger.getLogger(MigrationContentImportWebScript.class);

    private FileUtil fileUtil;
    
    private FileFolderService fileFolderService;
    
	public void setFileFolderService(FileFolderService fileFolderService) {
		this.fileFolderService = fileFolderService;
	}

    public void setFileUtil(FileUtil fileUtil) {
		this.fileUtil = fileUtil;
	}

    /**
     * 
     */
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status,
			Cache cache) {
		LOG.info("In MigrationContentImportWebScript.executeImpl() Start ");
		
		Map<String, Object> result = new HashMap<String, Object>();
		
		String rootPath = req.getParameter(ROOT_PATH);
		String folderPath = req.getParameter(FOLDER_PATH);
		 LOG.info(" rootPath = " + rootPath +" \t folderPath = "+ folderPath);
		
        String overwriteObj = req.getParameter(PARAM_OVERWRITE);
        boolean isOverWrite = overwriteObj == null ? false : Boolean.valueOf(overwriteObj);
        LOG.info(" isOverWrite  == "+ isOverWrite);
       
//        String fldrMetaObj = req.getParameter(PARAM_ATTACH_FOLDER_METADATA);
//        boolean attachFolderMetadata = (fldrMetaObj == null) ? false : Boolean.parseBoolean(fldrMetaObj);
//        LOG.info(" attachFolderMetadata  =  " + attachFolderMetadata);
        
        // ContentOwner is the mandatory Property
        String contentowner = req.getParameter(PARAM_CONTENT_OWNER);
        LOG.info(" contentowner = " + contentowner);
        
        
//        String folderTagging = req.getParameter(PARAM_ATTACH_FOLDER_TAGGING);
//        boolean attachFolderTagging = (folderTagging == null) ? false : Boolean.parseBoolean(folderTagging);
//        LOG.info(" attachFolderTagging = " + attachFolderTagging);
        
        // folder tagging attributes
        String tagAttributes = req.getParameter(PARAM_TAGGING_ATTRIBUTES);
        LOG.info(" tagAttributes = " + tagAttributes);
        
        //getting folderMetadata Aspect details
        String jsonMetaProp = req.getParameter(PARAM_JSON_METADATA);
        
        // getting actual formData content from request
        FormData formData = null;
        String fileLocation = null;
        if(req.parseContent() != null) {
        	formData = (FormData) req.parseContent();
        }
        
        fileLocation = req.getParameter(PARAM_MOUNT_POINT_FILE_LOC);
        
        LOG.info(" FormData -- >"+ formData);
        
        String inheritPerms = req.getParameter(PARAM_CASCADE_PERMISSIONS);
        boolean cascadeFolderPermissions = (inheritPerms == null) ? false : Boolean.parseBoolean(inheritPerms);
        LOG.info(" cascadeFolderPermissions = " + cascadeFolderPermissions);
        
        String versionable = req.getParameter(PARAM_IS_VERSIONABLE);
        boolean isVersionable = versionable == null ? false : Boolean.parseBoolean(versionable);
        LOG.info(" versionable = " + isVersionable);
        
        
        // getting required file related information from request
        String reqFileName = req.getParameter(PARAM_FILE_NAME);
        String mimeType = req.getParameter(PARAM_MIMETYPE);
        String encoding = req.getParameter(PARAM_ENCODING);
        String jsonCommnProp = req.getParameter(PARAM_JSON_COMMON_PROPS);
       
        String fileTagging = req.getParameter(PARAM_ATTACH_FILE_TAGGING);
        boolean attachFileTagging = (fileTagging != null && !fileTagging.trim().equals(EMPTY_STRING)) ? Boolean.parseBoolean(fileTagging) : false;
        
        
        String obj = req.getParameter(PARAM_ATTACH_FILE_METADATA);
        boolean attachFileMetadata = (obj != null && !obj.trim().equals(EMPTY_STRING))? Boolean.parseBoolean(obj) : false ;
        
        String permissionsJson = req.getParameter(PARAM_PERMISSION_JSON);
        
        String alfServiceDelimeter = req.getParameter(PARAM_DELIMETER);
        
        String timeZone = req.getParameter(PARAM_TIME_ZONE);
        
        String dateFormat = req.getParameter(PARAM_DATE_FORMAT);
        
        NodeRef baseFileNodeRef = null;
        if(isVersionable) {
        	if(req.getParameter(PARAM_BASE_FILE_NODEREF) != null && NodeRef.isNodeRef(req.getParameter(PARAM_BASE_FILE_NODEREF))) {
        		baseFileNodeRef = new NodeRef(req.getParameter(PARAM_BASE_FILE_NODEREF));
        	}else {
        		result.put(PARAM_STATUS_MSG, "Base File NodeRef is not exist/Created");
	            result.put(PARAM_FOLDER_NODE_REF, "");
	            result.put(PARAM_FILE_NODE_REF, "");
	            result.put(PARAM_FILE_NAME, reqFileName);
	            result.put(PARAM_STATUS_CODE, "400");
	            result.put(PARAM_FOLDER_NODE_REF_LIST, new HashMap<String , Object>());
                result.put(PARAM_FOLDER_NAME, "");
                return result;
        	}
        }
       
        
        NodeRef folderNodeRef = null;
        
        Map<String, Object> folderNodeRefList = new HashMap<String, Object>();
        
		if(rootPath != null && folderPath != null) {
			
			try {
				
				if(!NodeRef.isNodeRef(folderPath)) {
					
					//result = folderUtil.createFolders(rootPath, folderPath, isOverWrite, attachFolderMetadata, jsonMetaProp, attachFolderTagging, 
						//								tagAttributes, contentowner, cascadeFolderPermissions, permissionsJson);
					folderNodeRef = new NodeRef(rootPath);
					NodeRef existingFolderRef = null;
					String[] folderNames = folderPath.split("/");
					 for (int i = 0; i < folderNames.length; i++) {
			                if (folderNames[i] != null && !folderNames[i].trim().equals(EMPTY_STRING)) {
			                    LOG.info(" folderName ::: " + folderNames[i] + "\t  parentNodeRef = " + folderNodeRef);
			                    existingFolderRef = fileFolderService.searchSimple(folderNodeRef, folderNames[i]);
			                    
			                    if (existingFolderRef != null) {
			                    	folderNodeRef = existingFolderRef;
			                    	result.put(PARAM_FOLDER_NAME, folderNames[i]);
			                    }else{
			                    	 result.put(PARAM_STATUS_MSG, "Folder is not Exist. Please Create Folder first then try to migrate file.");
			                         result.put(PARAM_FOLDER_NODE_REF, "");
			                         result.put(PARAM_FOLDER_NODE_REF_LIST, new HashMap<String , Object>());
			                         result.put(PARAM_FOLDER_NAME, folderNames[i]);
			         	             result.put(PARAM_FILE_NODE_REF, "");
			         	             result.put(PARAM_FILE_NAME, reqFileName);
			         	             result.put(PARAM_STATUS_CODE, "400");
			                         return result;
			                    }
			                }
					 }
					
					//folderNodeRef = new NodeRef((String)result.get(PARAM_FOLDER_NODE_REF));
					//folderNodeRefList = (Map<String, Object>) result.get(PARAM_FOLDER_NODE_REF_LIST);
					
				} else {
					folderNodeRef = new NodeRef(folderPath);
	                result.put(PARAM_FOLDER_NODE_REF, folderNodeRef.toString());
	                result.put(PARAM_FOLDER_NODE_REF_LIST, new HashMap<String , Object>());
	                result.put(PARAM_FOLDER_NAME, "");
				}
				
				LOG.info(" Existing/Created Folder NodeRef ::: " + folderNodeRef);
				
				if(formData != null && req.getParameter(PARAM_FIELD) != null) {
					FormData.FormField[] fields = formData.getFields();
					
	                // Performing file related activities
	                for (FormData.FormField field : fields) {
	                    if (field.getName().equals(PARAM_FIELD) && field.getIsFile()) {
	                    	
							result = fileUtil.writeContent(field, folderNodeRef, isOverWrite, jsonMetaProp, reqFileName, mimeType, encoding, attachFileTagging,
															attachFileMetadata, jsonCommnProp, tagAttributes, contentowner, isVersionable, permissionsJson, cascadeFolderPermissions, result, alfServiceDelimeter, baseFileNodeRef, dateFormat, timeZone);
						}
	                }
				}else{
					result = fileUtil.writeContent(fileLocation, folderNodeRef, isOverWrite, jsonMetaProp, reqFileName, mimeType, encoding, attachFileTagging,
							attachFileMetadata, jsonCommnProp, tagAttributes, contentowner, isVersionable, permissionsJson, cascadeFolderPermissions,result,alfServiceDelimeter, baseFileNodeRef, dateFormat, timeZone);
				}
                LOG.info(" Response result ::: " + result);
                
                result.put(PARAM_FOLDER_NODE_REF_LIST, folderNodeRefList);

			} catch (Exception e) {
				LOG.error(" Exception while importing document ..." + e, e);
				result.put(PARAM_STATUS_MSG, (e != null) ? e.getMessage() : NULL_EXCEPTION);
	            result.put(PARAM_FOLDER_NODE_REF, "");
	            result.put(PARAM_FILE_NODE_REF, "");
	            result.put(PARAM_FILE_NAME, reqFileName);
	            result.put(PARAM_STATUS_CODE, "400");
	            result.put(PARAM_FOLDER_NODE_REF_LIST, new HashMap<String , Object>());
                result.put(PARAM_FOLDER_NAME, "");
			} finally {
				LOG.info("In MigrationContentImportWebScript.executeImpl() finally block End ");
			}
			
		} else {
			result.put(PARAM_STATUS_MSG, "Please Provide rootPath and folderPath as HTTPPost request parameter.");
			result.put(PARAM_FOLDER_NODE_REF, "");
			result.put(PARAM_FILE_NODE_REF, "");
			result.put(PARAM_FILE_NAME, reqFileName);
			result.put(PARAM_STATUS_CODE, "400");
			result.put(PARAM_FOLDER_NODE_REF_LIST, new HashMap<String , Object>());
            result.put(PARAM_FOLDER_NAME, "");
		}

        return result;
	}

}
