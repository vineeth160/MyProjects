package com.cisco.migration.service.util;

import static com.cisco.migration.service.util.MigPostScriptConstants.PARAM_STATUS_MSG;
import static com.cisco.migration.service.util.MigPostScriptConstants.RES_OBJECT_NODEREF;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.OwnableService;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.cisco.alfresco.external.utils.CiscoStringUtils;

/**
 * 
 * @author parreddy
 *
 */
public class MigPostProcessPermissionsUtil {
	private static final Logger LOG = Logger.getLogger(MigPostProcessPermissionsUtil.class);
	private static String preferenceFilter = "org.alfresco.share.folders.favourites";

	private static String restricteSitePerm[] = new String[]{"SiteAdmin","SiteEditor","SiteManager","SiteOwner","SiteViewer","SiteReader"};
	private static List<String> restrictedPerms = Arrays.asList(restricteSitePerm);

	private ServiceRegistry serviceRegistry;

	private PermissionService permissionService;

	private OwnableService ownableService;

	private Properties globalProperties;

	private PreferenceService preferenceService;

	public void setOwnableService(OwnableService ownableService) {
		this.ownableService = ownableService;
	}

	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public void setGlobalProperties(Properties globalProperties) {
		this.globalProperties = globalProperties;
	}
	
	public void setPreferenceService(PreferenceService preferenceService) {
		this.preferenceService = preferenceService;
	}

	/**
	 * 
	 * @param objectNodeRef
	 * @param contentowner
	 * @param isInheritPerm
	 * @param permissionJsonSet
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> attachPermissions(NodeRef objectNodeRef, String permissionJsonSet,
			boolean inheritPermission) throws Exception {
		LOG.info(" PermissionsUtil.attachPermissions()  for file Node ::: " + objectNodeRef + "folder value ====> "
				+ globalProperties.getProperty("postscript.folder.inheritperm.default"));

		LOG.debug(" PermissionsUtil.attachPermissions()  for file Node ::: " + objectNodeRef + " permissions set ==> "
				+ permissionJsonSet);

		Map<String, Object> result = new HashMap<String, Object>();
		// result.put(RES_OBJECT_NODEREF, objectNodeRef);
		result.put(RES_OBJECT_NODEREF, objectNodeRef.toString());
		JSONParser jsonParser = new JSONParser();
		JSONArray permissionsSet = null;

		try {
			if (permissionJsonSet != null) {
				permissionsSet = (JSONArray) jsonParser.parse(permissionJsonSet);
				List<String> permUserList = null;

				Map<String, UserPermission> alfNodePermissionMap = getNodePermissions(objectNodeRef, false);
				LOG.debug(" alfNodePermissionMap =====> " + alfNodePermissionMap);
				QName alfNodeType = serviceRegistry.getNodeService().getType(objectNodeRef);

				if (ContentModel.TYPE_FOLDER.equals(alfNodeType)) {
					
					//NodeRef alfParentRef = serviceRegistry.getNodeService().getPrimaryParent(objectNodeRef).getParentRef();
					//Set<String> inheritedPermUsersList = getParentNodeUsers(alfParentRef);
					
					// Need to off the inherit based on requirment.
					inheritPermission = false;
					Set<String> inputJsonUsersSet = new HashSet<String>();
					for (int i = 0; i < permissionsSet.size(); i++) {
						String permissionName = (String) ((JSONObject) permissionsSet.get(i)).get("permissionLevel");
						String userType = (String) ((JSONObject) permissionsSet.get(i)).get("type");
						permUserList = (ArrayList<String>) ((JSONObject) permissionsSet.get(i)).get("userId");
						// boolean inheritedPermission = (Boolean) ((JSONObject)
						// permissionsSet.get(i)).get("inherit");
						if (LOG.isDebugEnabled()) {
							LOG.info("Permission Name ===> " + permissionName);
							LOG.info("User Type ======> " + userType);
							LOG.info("Perm User List =====> " + permUserList);
						}
						// we need not to set the permission if it is inherited.
						// if (!inheritedPermission) {
						for (Object user : permUserList) {
							/*
							 * boolean hasPermission = hasPermission(permissionService, user.toString(),
							 * permissionName, objectNodeRef);
							 */
							boolean hasPermission = alfNodePermissionMap.containsKey(user.toString());
							if (!hasPermission) {
								LOG.debug("Permissions not found so applying on node ====> " + user.toString()
										+ " permission name ===> " + permissionName);
								permissionService.setPermission(objectNodeRef, user.toString(), permissionName, true);
								result.put(RES_OBJECT_NODEREF, objectNodeRef.toString());
								result.put(PARAM_STATUS_MSG, "Permission(s) added successfully!!!");
							} else {
								result.put(RES_OBJECT_NODEREF, objectNodeRef.toString());
								result.put(PARAM_STATUS_MSG, "Permission(s) already Exist!!!");

								LOG.debug(" inside else Permission already exist ====> " + user.toString()
										+ " permission name ===> " + permissionName);
								// if existing permissions is same and not
								// inherited then leave else we need to apply.
								UserPermission userExistingPerm = alfNodePermissionMap.get(user.toString());
								if (!(!userExistingPerm.isInherited()
										&& (userExistingPerm.getPermission().equalsIgnoreCase(permissionName)))) {
									if (!userExistingPerm.isInherited()
											&& !(userExistingPerm.getPermission().equalsIgnoreCase(permissionName))) {
										LOG.debug(" exist permissions of the user with different so delete ====> "
												+ user.toString() + " permission name ===> " + permissionName);
										// need to remove existing and reapply.
										permissionService.deletePermission(objectNodeRef, user.toString(),
												userExistingPerm.getPermission());
									}
									LOG.debug("Reapplying in permissions " + user.toString() + " permission name ===> "
											+ permissionName);
									permissionService.setPermission(objectNodeRef, user.toString(), permissionName,
											true);
									result.put(PARAM_STATUS_MSG, "Permission(s) modified successfully!!!");
								}
							}
							inputJsonUsersSet.add(user.toString());
							LOG.debug("************** Preference commented in permissons apply");
							/*LOG.debug("Parent Node permissionsSet ====> " + inheritedPermUsersList);
							// setting preference service only based on if the user already not having permissions on parent.
							if(!inheritedPermUsersList.contains(user.toString())) {
								updateUserPreference(user.toString(), objectNodeRef, true);
								LOG.debug("adding preference to user ===>  " + user.toString() + " for noderef===> " + objectNodeRef);
							} */

						}
						// }

					}

					LOG.debug(" Input Json User Set =====> " + inputJsonUsersSet);
					// deleting users those are not in input json list and
					// applied previously.
					for (String existingUsers : alfNodePermissionMap.keySet()) {
						if (!inputJsonUsersSet.contains(existingUsers)) {
							UserPermission userExistingPerm = alfNodePermissionMap.get(existingUsers);
							LOG.debug(" Deleting unwanted permissions =====> " + existingUsers + " Permission ==> "
									+ userExistingPerm.getPermission() + "  NodeRef=====> " + objectNodeRef);
							if(!restrictedPerms.contains(userExistingPerm.getPermission())) {
								permissionService.deletePermission(objectNodeRef, existingUsers,
										userExistingPerm.getPermission());
								//need to update the preferences.
								updateUserPreference(existingUsers, objectNodeRef, false);
							}
							
						}
					}

				} else {
					// its not a folder so treting as doc we need to decide

					Set<String> inputJsonUsersSet = new HashSet<String>();
					// wheather inherit is on off based on input.
					for (int i = 0; i < permissionsSet.size(); i++) {
						String permissionName = (String) ((JSONObject) permissionsSet.get(i)).get("permissionLevel");
						String userType = (String) ((JSONObject) permissionsSet.get(i)).get("type");
						permUserList = (ArrayList<String>) ((JSONObject) permissionsSet.get(i)).get("userId");
						// boolean inheritedPermission = (Boolean) ((JSONObject)
						// permissionsSet.get(i)).get("inherit");

						if (LOG.isDebugEnabled()) {
							LOG.info("Permission Name ===> " + permissionName);
							LOG.info("User Type ======> " + userType);
							LOG.info("Perm User List =====> " + permUserList);
						}

						// currently we are setting perm only if it is not
						// inherited
						// if (!inheritedPermission) {
						for (Object user : permUserList) {
							/*
							 * boolean hasPermission = hasPermission(permissionService, user.toString(),
							 * permissionName, objectNodeRef);
							 */

							boolean hasPermission = alfNodePermissionMap.containsKey(user.toString());
							if (!hasPermission) {
								permissionService.setPermission(objectNodeRef, user.toString(), permissionName, true);
								result.put(RES_OBJECT_NODEREF, objectNodeRef.toString());
								result.put(PARAM_STATUS_MSG, "Permission(s) added successfully!!!");
							} else {
								result.put(RES_OBJECT_NODEREF, objectNodeRef.toString());
								result.put(PARAM_STATUS_MSG, "Permission(s) already Exist!!!");

								// if existing permissions is same and not
								// inherited then leave else we need to apply.
								UserPermission userExistingPerm = alfNodePermissionMap.get(user.toString());
								if (!(!userExistingPerm.isInherited()
										&& (userExistingPerm.getPermission().equalsIgnoreCase(permissionName)))) {
									if (!userExistingPerm.isInherited()
											&& !(userExistingPerm.getPermission().equalsIgnoreCase(permissionName))) {
										// need to remove existing and reapply.
										permissionService.deletePermission(objectNodeRef, user.toString(),
												userExistingPerm.getPermission());
									}

									permissionService.setPermission(objectNodeRef, user.toString(), permissionName,
											true);
									result.put(PARAM_STATUS_MSG, "Permission(s) modified successfully!!!");
								}
							}
							inputJsonUsersSet.add(user.toString());
						}
						/*
						 * }else{
						 * 
						 * // need to handle the inherited permissions of doc
						 * 
						 * 
						 * }
						 */

					}

					// deleting users those are not in input json list and
					// applied previously.
					for (String existingUsers : alfNodePermissionMap.keySet()) {
						if (!inputJsonUsersSet.contains(existingUsers)) {
							UserPermission userExistingPerm = alfNodePermissionMap.get(existingUsers);
							permissionService.deletePermission(objectNodeRef, existingUsers,
									userExistingPerm.getPermission());
						}
					}

				}
				// Need to set the inherit permission
				permissionService.setInheritParentPermissions(objectNodeRef, inheritPermission);
				result.put(PARAM_STATUS_MSG, "Permission(s) processed successfully!!!");
			}

		} catch (Exception e) {
			LOG.error(" Exception while applying permissions ..." + e, e);
			result.put(PARAM_STATUS_MSG, e.getMessage());
			result.put(RES_OBJECT_NODEREF, "");
		} finally {
			if (LOG.isDebugEnabled()) {
				LOG.debug("In PermissionsUtil.attachPermissions() finally block End ");
			}
		}

		return result;
	}

	/**
	 * 
	 * @param objectNodeRef
	 * @return
	 */
	public boolean hasOwnerPermissionChange(NodeRef objectNodeRef, String owner, String permUser) {

		if (LOG.isDebugEnabled()) {
			LOG.info(" PermissionsUtil.hasOwnerPermissionChange()  for file Node ::: " + objectNodeRef);
		}
		boolean hasOwnerPermissionChange = false;

		if (owner.equalsIgnoreCase(permUser)) {
			hasOwnerPermissionChange = true;
		}
		if (LOG.isDebugEnabled()) {
			LOG.info(" PermissionsUtil.hasOwnerPermissionChange()  Owner is ::: " + owner
					+ " :: and  hasOwnerPermissionChange ? " + hasOwnerPermissionChange);
		}
		return hasOwnerPermissionChange;
	}

	/**
	 * 
	 * @param objectNodeRef
	 * @param inheritPerms
	 */
	public void setInheritPermissions(NodeRef objectNodeRef, boolean inheritPerms) {
		if (LOG.isDebugEnabled()) {
			LOG.debug(" PermissionsUtil.setInheritPermissions()  for Parent Node ::: " + objectNodeRef);
		}
		this.permissionService.setInheritParentPermissions(objectNodeRef, inheritPerms);
	}

	/**
	 * 
	 * @param objectNodeRef
	 * @param inheritPerms
	 */
	public boolean getInheritPermissions(NodeRef objectNodeRef) {
		return this.permissionService.getInheritParentPermissions(objectNodeRef);
	}

	/**
	 * 
	 * @param permissionService
	 * @param user
	 * @param permRoleKey
	 * @param objectNodeRef
	 * @return
	 */
	public boolean hasPermission(PermissionService permissionService, String user, String permRoleKey,
			NodeRef objectNodeRef) {

		Set<AccessPermission> allAccessPermissions = permissionService.getAllSetPermissions(objectNodeRef);
		String userAuthority = null;
		String userPermission = null;
		boolean hasPermission = false;

		for (AccessPermission accessPermission : allAccessPermissions) {

			userAuthority = accessPermission.getAuthority();
			userPermission = accessPermission.getPermission();

			if (userAuthority.equals(user.toString()) && userPermission.equals(permRoleKey.toString())) {
				if (LOG.isDebugEnabled()) {
					LOG.debug("  Authority ::: " + accessPermission.getAuthority() + " ---> user  ::: " + user);
					LOG.debug("  getPermission ::: " + accessPermission.getPermission() + " ---> permRoleKey ::: "
							+ permRoleKey);
				}
				return true;
			}
		}
		return hasPermission;

	}

	public Map<String, UserPermission> getNodePermissions(NodeRef alfNodeRef, boolean needInheritedPerm) {
		Map<String, UserPermission> userpermissionsMap = new HashMap<>();
		if (alfNodeRef != null) {
			Set<AccessPermission> userPermisions = permissionService.getAllSetPermissions(alfNodeRef);
			if (userPermisions != null && userPermisions.size() > 0) {
				for (AccessPermission permission : userPermisions) {
					boolean isInherited = permission.isInherited();
					String authority = permission.getAuthority();
					UserPermission userPermObj = new UserPermission();
					userPermObj.setPermission(permission.getPermission());
					userPermObj.setAuthorityType(permission.getAuthorityType());
					userPermObj.setInherited(isInherited);
					if (!(isInherited && !needInheritedPerm)) {
						userpermissionsMap.put(authority, userPermObj);
					}
				}
			}
		}
		return userpermissionsMap;
	}
	
	public Set<AccessPermission> getNodePermissions(NodeRef alfNodeRef){
		Set<AccessPermission> userPermisions = new HashSet<>();
		if(alfNodeRef != null) {
			userPermisions = permissionService.getAllSetPermissions(alfNodeRef);
		}
		return userPermisions;
	}
	
	
	public Set<String>getParentNodeUsers(NodeRef parentAlfNodeRef) {
		Set<String> parentNodeUsers = new HashSet<>();
		if (parentAlfNodeRef != null) {
			Set<AccessPermission> userPermisions = permissionService.getAllSetPermissions(parentAlfNodeRef);
			if (userPermisions != null && userPermisions.size() > 0) {
				for (AccessPermission permission : userPermisions) {
					String authority = permission.getAuthority();
					parentNodeUsers.add(authority);
				}
			}
		}
		return parentNodeUsers;
	}
	
	public void updateUserPreference(String userName, NodeRef nodeRef, boolean enablePreference) {
			try {
			Map<String, Serializable> preferences = null;
			Map<String, Serializable> updatedPreferences = null;
			// AuthenticationUtil.setFullyAuthenticatedUser("admin");
			preferences = preferenceService.getPreferences(userName, preferenceFilter);
			updatedPreferences = updatedPreference(preferences, preferenceFilter, nodeRef.toString(), enablePreference);
			preferenceService.setPreferences(userName, updatedPreferences);
		} catch (Exception e) {
			throw e;
		}
	}
	
	public boolean isNodeExistingUserPreference(String userName, NodeRef nodeRef) {
		boolean isExist = false;
		try {
			Map<String, Serializable> preferences = preferenceService.getPreferences(userName, preferenceFilter);
			if (preferences.containsKey(preferenceFilter)) {
				String filteredPreference = (String) preferences.get(preferenceFilter);
				LOG.debug("Parent filteredPreference String ====> " + filteredPreference);
				Set<String> prefeRenceSet = CiscoStringUtils.convertStringToSet(filteredPreference, ",");
				LOG.debug("Parent prefeRenceList ===> " + prefeRenceSet);
				if (prefeRenceSet.contains(nodeRef.toString())) {
					isExist = true;
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return isExist;
	}

	private Map<String, Serializable> updatedPreference(Map<String, Serializable> preferences, String preferenceFilter,
			String values, boolean enablePreference) {
		LOG.debug("Values-----------" + values);
		LOG.debug("Preference size------" + preferences.size());
		try {
			if (preferences.containsKey(preferenceFilter)) {
				String item = (String) preferences.get(preferenceFilter);
				LOG.debug("item----------"+item);
				String[] itemArray = item.split(",");
				List<String> list = new ArrayList<String>();
				if (itemArray.length > 0) {
					Collections.addAll(list, itemArray);
					LOG.debug("list----------"+ list + "\n");
					LOG.debug("itemArray----------"+ itemArray);
				}
				if (list.contains(values)) {
					list.remove(values);
				}
				if (enablePreference) {
					list.add(values);
				}
				
				if(!enablePreference) {
					list.remove(values);
				}
				
				 LOG.debug("list----------:"+list);
				preferences.put(preferenceFilter, StringUtils.join(list, ","));
			} else {
				preferences.put(preferenceFilter, values);
			}
		} catch (Exception e) {
			LOG.error("Exception in updatedPreference mothod-----------",e);
			throw e;
			//e.printStackTrace();
		}
		return preferences;
	}
	
}
