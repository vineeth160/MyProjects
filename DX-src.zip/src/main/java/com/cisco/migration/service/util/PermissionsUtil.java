package com.cisco.migration.service.util;

import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_STATUS_MSG;
import static com.cisco.migration.service.webscripts.MigrationConstants.RES_OBJECT_NODEREF;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.OwnableService;
import org.alfresco.service.cmr.security.PermissionService;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 * 
 * @author gpotla
 *
 */
public class PermissionsUtil {
	private static final Logger LOG = Logger.getLogger(PermissionsUtil.class);
	
	private ServiceRegistry serviceRegistry;
	
	private PermissionService permissionService;
	
	private OwnableService ownableService;
	
	public void setOwnableService(OwnableService ownableService) {
		this.ownableService = ownableService;
	}

	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

    /**
     * 
     * @param objectNodeRef
     * @param contentowner
     * @param isInheritPerm
     * @param permissionJsonSet
     * @return
     * @throws Exception
     */
    public Map<String, Object> attachPermissions(NodeRef objectNodeRef, String permissionJsonSet)  throws Exception{
    	LOG.info(" PermissionsUtil.attachPermissions()  for file Node ::: " + objectNodeRef);
    	
    	Map<String, Object> result = new HashMap<String, Object>();
    	
    	JSONParser jsonParser = new JSONParser();
        JSONArray permissionsSet = null;

        try {
			if (permissionJsonSet != null) {
				permissionsSet = (JSONArray) jsonParser.parse(permissionJsonSet);
				
				 List permUserList = null;
		         LOG.info(" Permission User		:: \t Role	\t ");
		         
		         for (int i =0;i< permissionsSet.size(); i++) {
		        	 
		        	 for  (Object permRoleKey : ((JSONObject)permissionsSet.get(i)).keySet()) {
		        		 permUserList = (ArrayList)((JSONObject)permissionsSet.get(i)).get(permRoleKey);
		        		 LOG.info(permRoleKey+" 	 :: \t "+permUserList+"	\t ");
		        	
						for (Object user : permUserList) {
							boolean hasPermission = hasPermission(permissionService, user.toString(), permRoleKey.toString(), objectNodeRef);
							if(!hasPermission) {
								permissionService.setPermission(objectNodeRef, user.toString(), permRoleKey.toString(), true);
    							result.put(RES_OBJECT_NODEREF, objectNodeRef.toString());
    							result.put(PARAM_STATUS_MSG, "Permission(s) added successfully!!!");
							}else{
								result.put(RES_OBJECT_NODEREF, objectNodeRef.toString());
    							result.put(PARAM_STATUS_MSG, "Permission(s) already Exist!!!");
							}
						}
		        	 }

		        	
		         }

			}
    	 
        } catch (Exception e) {
            LOG.error(" Exception while applying permissions ..." + e, e);
            result.put(PARAM_STATUS_MSG, e.getMessage());
            result.put(RES_OBJECT_NODEREF, "");
        } finally {
            LOG.info("In PermissionsUtil.attachPermissions() finally block End ");
        }
        
        return result;
    }
    
    
    /**
     * 
     * @param objectNodeRef
     * @return
     */
    public boolean hasOwnerPermissionChange(NodeRef objectNodeRef, String owner, String permUser) {

    	LOG.info(" PermissionsUtil.hasOwnerPermissionChange()  for file Node ::: " + objectNodeRef);
    	boolean hasOwnerPermissionChange = false;
		
		if (owner.equalsIgnoreCase(permUser)) {
			hasOwnerPermissionChange  = true;
		}

		LOG.info(" PermissionsUtil.hasOwnerPermissionChange()  Owner is ::: " + owner +" :: and  hasOwnerPermissionChange ? "+ hasOwnerPermissionChange);
		return hasOwnerPermissionChange;
	}
    
    
    /**
     * 
     * @param objectNodeRef
     * @param inheritPerms
     */
    public void setInheritPermissions(NodeRef objectNodeRef, boolean inheritPerms) {
    	LOG.info(" PermissionsUtil.setInheritPermissions()  for Parent Node ::: " + objectNodeRef);
    	this.permissionService.setInheritParentPermissions(objectNodeRef, inheritPerms);
    }
    
    /**
     * 
     * @param permissionService
     * @param user
     * @param permRoleKey
     * @param objectNodeRef
     * @return
     */
    public boolean hasPermission(PermissionService permissionService, String user, String permRoleKey, NodeRef objectNodeRef) {
    	
    	Set<AccessPermission>  allAccessPermissions = 	permissionService.getAllSetPermissions(objectNodeRef);
		String userAuthority = null;
		String userPermission = null;
		boolean hasPermission = false;
		
		for(AccessPermission accessPermission : allAccessPermissions ) {
			
			userAuthority = accessPermission.getAuthority();
			userPermission = accessPermission.getPermission();
			
			if(userAuthority.equals(user.toString()) && userPermission.equals(permRoleKey.toString())) {
				LOG.info("  Authority ::: "+accessPermission.getAuthority() +" ---> user  ::: "+user);
				LOG.info("  getPermission ::: "+accessPermission.getPermission()+" ---> permRoleKey ::: "+permRoleKey);
				return true;
			}
		}
		return hasPermission;
    
    }
    
}
