package com.cisco.migration.service.webscripts;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentData;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.Path;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.util.ISO9075;
import org.alfresco.util.TempFileProvider;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.external.common.util.ExternalSharingConstants;

public class UsersContentReport extends AbstractWebScript {
	private static final Logger logger = Logger.getLogger(UsersContentReport.class);
	private static final String DOC_QNAME_PATH = "{http://www.cisco.com/model/content/1.0}";
	private static final String FILE_HEADER = "CREATER,NAME,MODIFIED_DATE,DOCID,CREATOR,MODIFIER,CREATE_DATE,PATH";
	private static final String USERS_HEADER="USERSLIST,DOCCOUNT,TOTALFILECOUNT";
	private static final String COMMA_DELIMITER = ",";
	private static final String NEW_LINE_SEPARATOR = "\n";
	private static String PATH_DOCS_QUERY = "TYPE:\"cs:ciscodoc\" AND  PATH:\"/app:company_home/st:sites/cm:edcsng/cm:documentLibrary//*\" AND @cm\\:creator:\"";
	private ServiceRegistry serviceRegistry;

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse resp) throws IOException {
		File tempDir = TempFileProvider.getTempDir("/usersinfo.txt");
		logger.info("===tempDir===" + tempDir.getAbsolutePath());
		BufferedReader br = new BufferedReader(new FileReader(tempDir));
		String userID;
		long finalDocSize = 0L;
		long finalNoderefSize = 0L;
		Set<NodeRef> docsNoderefs = null;
		String totalNodeRefSize=null;
		int count=0;
		int usersize=0;
		
		JSONArray array = new JSONArray();
		Set<String>userslist=new HashSet<String>();
		
		
		while ((userID = br.readLine()) != null) {
			//logger.info("===userID===" + userID);
			String usersQuery = PATH_DOCS_QUERY + userID + "\"";
			logger.info("===usersQuery===" + usersQuery);
			docsNoderefs = getUsersList(usersQuery);
			logger.info("===docsNoderefs==SIZE " + docsNoderefs.size());
			StringBuffer filePaths = new StringBuffer();
			filePaths.append(TempFileProvider.getTempDir()).append("/userscontentreport.csv");
			File file = new File(filePaths.toString());

			for (NodeRef nodeRef : docsNoderefs) {
				long size = ((ContentData) serviceRegistry.getNodeService().getProperty(nodeRef,
						ContentModel.PROP_CONTENT)).getSize();
				//logger.info("===size===" + size);
				finalDocSize = finalDocSize + size;
				////logger.info("===finalDocSize===" + finalDocSize);
				String docName = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NAME);
				String createdDate = getGMTDateFormat(
						(Date) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_CREATED));
				String docID = (String) serviceRegistry.getNodeService().getProperty(nodeRef,
						ExternalSharingConstants.PROP_EDCS_ID);
				String modifier = (String) serviceRegistry.getNodeService().getProperty(nodeRef,
						ContentModel.PROP_MODIFIER);

				String docCreater = (String) serviceRegistry.getNodeService().getProperty(nodeRef,
						ContentModel.PROP_CREATOR);
				String modified = getGMTDateFormat(
						(Date) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_MODIFIED));

				Path path = serviceRegistry.getNodeService().getPath(nodeRef);
				String prefixPath = getDocPath(path, nodeRef);
				exportToCSV(userID, docName, modified, docID, docCreater, modifier, createdDate, prefixPath,file);

			}
			
			
			count=count+docsNoderefs.size();
			userslist.add(userID);
			usersize=userslist.size();
			logger.info("==count==" + count);
			logger.info("==usersize==" + usersize);
			String totalSize = formatFileSize(finalDocSize);
			finalNoderefSize = finalNoderefSize + finalDocSize;
			JSONObject obj = new JSONObject();
			try {
				obj.put("UserID", userID);
				obj.put("Noderef's Count", docsNoderefs.size());
				obj.put("doccount", totalSize);
				array.put(obj);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		 totalNodeRefSize = formatFileSize(finalNoderefSize);
		Map<String, String> map = new HashMap<String, String>();
		map.put("totalNodeRefSize", totalNodeRefSize);
		map.put("TotalNodeRefcount", String.valueOf(count));
		map.put("TotalUserslist", String.valueOf(usersize));
		array.put(map);
		
		// build a JSON string and send it back
		String jsonString = array.toString();
		resp.getWriter().write(jsonString);
		exportToCSVtotalCount(usersize,count,totalNodeRefSize);
	}

	private void exportToCSVtotalCount(int usersize, int count, String totalNodeRefSize) throws IOException {
		// TODO Auto-generated method stub
		logger.info("Enter into exportCSV1----------");
		logger.info("==totalNodeRefSize==" + totalNodeRefSize);

		StringBuffer filePaths = new StringBuffer();
		filePaths.append(TempFileProvider.getTempDir()).append("/totalfilecount.csv");
		File file = new File(filePaths.toString());
		//logger.info("file ------------>" + file.getAbsolutePath());
		PrintWriter pw = null;
		try {

			boolean fileExists = file.exists();
			//logger.info("fileExists----->" + fileExists);
			if (fileExists) {
				//logger.info("Enter into if---");
				FileWriter fstream = new FileWriter(file.getAbsolutePath(), true);

				BufferedWriter fbw = new BufferedWriter(fstream);

				String rowData = usersize + COMMA_DELIMITER + count + COMMA_DELIMITER + totalNodeRefSize;

				//logger.info("data1---->" + data1);
				fbw.write(rowData);

				fbw.newLine();
				fbw.close();
			} else {
				logger.info("Enter into Else----------");
				pw = new PrintWriter(file);

				StringBuilder builder = new StringBuilder();
				// No need give the headers Like: id, Name on builder.append
				builder.append(USERS_HEADER + NEW_LINE_SEPARATOR);

				String data = usersize + COMMA_DELIMITER + count + COMMA_DELIMITER + totalNodeRefSize;

				builder.append(data);
				// LOGGER.info("builder.append(data)------->"+builder.append(data));
				builder.append(NEW_LINE_SEPARATOR);
				pw.write(builder.toString());

				pw.close();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}

	private Set<NodeRef> getUsersList(String searchQuery) {
		int skipCount = 0;
		Set<NodeRef> nodeRefList = null;
		while (true) {
			SearchParameters sp = new SearchParameters();
			sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
			sp.setLanguage(SearchService.LANGUAGE_LUCENE);
			sp.setMaxItems(200);
			sp.setSkipCount(skipCount);
			sp.setQuery(searchQuery);
			ResultSet results = serviceRegistry.getSearchService().query(sp);
			if(skipCount == 0)
				nodeRefList = new HashSet<NodeRef>();
			if (null == results || results.length() <= 0)
				break;
			if(results != null && results.length() > 0) {
			for (ResultSetRow row : results) {
				nodeRefList.add(row.getNodeRef());
			}
			 results.close();
			}else {
				logger.info("No Search Results found");
				break;
			}
			skipCount += 200;
		}
		return nodeRefList;
	}

	public static String formatFileSize(long size) {
		String hrSize = null;

		double b = size;
		double k = size / 1024.0;
		double m = ((size / 1024.0) / 1024.0);
		double g = (((size / 1024.0) / 1024.0) / 1024.0);
		double t = ((((size / 1024.0) / 1024.0) / 1024.0) / 1024.0);

		DecimalFormat dec = new DecimalFormat("0.00");

		if (t > 1) {
			hrSize = dec.format(t).concat(" TB");
		} else if (g > 1) {
			hrSize = dec.format(g).concat(" GB");
		} else if (m > 1) {
			hrSize = dec.format(m).concat(" MB");
		} else if (k > 1) {
			hrSize = dec.format(k).concat(" KB");
		} else {
			hrSize = dec.format(b).concat(" Bytes");
		}
		return hrSize;
	}

	private String getDocPath(Path filepath, NodeRef nodeRef) {
		String filePath = "";
		if (filepath != null) {
			filePath = filepath.toString();
			filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/application/1.0\\}", "");
			filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "");
			filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}", "");
		}
		filePath = filePath.replace("/company_home/sites/edcsng/documentLibrary", "");
		String name = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NAME);
		if (filePath.length() > DOC_QNAME_PATH.length() && filePath.contains(DOC_QNAME_PATH)) {
			String filePathWithName = filePath.substring(filePath.lastIndexOf('{') - 1, filePath.length());
			filePath = filePath.replace(filePathWithName, "");
			filePath = ISO9075.decode(filePath);
			//logger.info("filePath  :::::: " + filePath);
		} else {
			filePath = ISO9075.decode(filePath).replace("/" + name, "");
			//logger.info("filePath  ::::::: " + filePath);
		}
		return filePath;

	}

	private void exportToCSV(String userID, String docName, String modified, String docID, String docCreater,
			String modifier, String createdDate, String prefixPath,File file) throws IOException {
		logger.info("Enter into exportCSV----------");

		
		//logger.info("file ------------>" + file.getAbsolutePath());
		PrintWriter pw = null;
		try {

			boolean fileExists = file.exists();
			//logger.info("fileExists----->" + fileExists);
			if (fileExists) {
				logger.info("Enter into if---");
				FileWriter fstream = new FileWriter(file.getAbsolutePath(), true);

				BufferedWriter fbw = new BufferedWriter(fstream);

				String rowData = userID + COMMA_DELIMITER + docName + COMMA_DELIMITER + modified + COMMA_DELIMITER + docID
						+ COMMA_DELIMITER + docCreater + COMMA_DELIMITER + modifier + COMMA_DELIMITER + createdDate
						+ COMMA_DELIMITER + prefixPath;

				//logger.info("rowData---->" + rowData);
				fbw.write(rowData);

				fbw.newLine();
				fbw.close();
			} else {
				//logger.info("Enter into Else----------");
				pw = new PrintWriter(file);

				StringBuilder builder = new StringBuilder();
				// No need give the headers Like: id, Name on builder.append
				builder.append(FILE_HEADER + NEW_LINE_SEPARATOR);

				String data = userID + COMMA_DELIMITER + docName + COMMA_DELIMITER + modified + COMMA_DELIMITER + docID
						+ COMMA_DELIMITER + docCreater + COMMA_DELIMITER + modifier + COMMA_DELIMITER + createdDate
						+ COMMA_DELIMITER + prefixPath;

				builder.append(data);
				// LOGGER.info("builder.append(data)------->"+builder.append(data));
				builder.append(NEW_LINE_SEPARATOR);
				pw.write(builder.toString());

				pw.close();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static String getGMTDateFormat(Date date) {
		DateFormat df;
		String formatedDate = "";
		try {
			df = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));
			if (date != null) {
				formatedDate = df.format(date);
			}
		} catch (Exception e) {
			logger.error("Exception....." + e);
		}
		return formatedDate;
	}

	

}
