package com.cisco.migration.service.util;

import static com.cisco.migration.service.webscripts.MigrationConstants.NULL_EXCEPTION;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_STATUS_MSG;
import static com.cisco.migration.service.webscripts.MigrationConstants.RES_OBJECT_NODEREF;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.repo.version.VersionModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.cmr.version.VersionService;
import org.alfresco.service.cmr.version.VersionType;
import org.apache.log4j.Logger;

/**
 * 
 * @author gpotla
 *
 */
public class VersionsUtil {
	
	private static final Logger LOG = Logger.getLogger(VersionsUtil.class);
	private ServiceRegistry serviceRegistry;
	private NodeService nodeService;
	private VersionService versionService;

	// 	for Spring injection
	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
	
	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public void setVersionService(VersionService versionService) {
		this.versionService = versionService;
	}

	/**
     * 
     * @param contentNodeRef
     */
    public Map<String, Object> doCreateVersions(NodeRef contentNodeRef) {

        LOG.info(" VersionsUtil.doCreateVersions() UploadNodeRef ::: " + contentNodeRef);
        
        Map<String, Object> result = new HashMap<String, Object>();

        boolean hasAspect = this.versionService.isVersioned(contentNodeRef);
        String versionNode = null;
        
        try {
        	
        	Version retVer=null;
        	
	        if (hasAspect) {
	        	Map<String, Serializable> versionProperties = new HashMap<String, Serializable>();
	            versionProperties.put(VersionModel.PROP_VERSION_TYPE, VersionType.MINOR);
	            LOG.info(" Creating MINOR versions.....");
	            retVer = (Version)this.versionService.createVersion(contentNodeRef, versionProperties);
	            LOG.info(" Created Version is ---> "+retVer.getVersionLabel());
	            
	            // Getting created version NodeRef
	            VersionHistory history = this.serviceRegistry.getVersionService().getVersionHistory(contentNodeRef);
	            Version version = history.getVersion(retVer.getVersionLabel());
	            NodeRef versionNodeRef = version.getFrozenStateNodeRef();
	            
	            LOG.info(" Created Version Lable ---> "+retVer.getVersionLabel());
	            LOG.info(" Created Version FrozenStateNodeRef ---> "+versionNodeRef);
	            
	            versionNode = versionNodeRef.toString();
	        } 
	        result.put(PARAM_STATUS_MSG, "Version(s) created successfully!!!");
	        result.put(RES_OBJECT_NODEREF, versionNode);
	        
        }catch (Exception e) {
            LOG.error(" Exception while creating version(s) ..." + e, e);
            result.put(PARAM_STATUS_MSG, (e != null) ? e.getMessage() : NULL_EXCEPTION);
            result.put(RES_OBJECT_NODEREF, "");
        }finally {
        	LOG.info(" VersionsUtil.doCreateVersions() finally block ");
        }
        
        return result;
    }

}
