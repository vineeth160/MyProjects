package com.cisco.migration.service.webscripts;

import java.util.HashMap;
import java.util.Map;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.security.AuthorityService;
import org.alfresco.service.cmr.security.PersonService;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

/**
 * 
 * @author Mahesh
 *
 */
public class PersonGroupFinder extends DeclarativeWebScript {
	private static Logger _log = Logger.getLogger(PersonGroupFinder.class);

	private ServiceRegistry serviceRegistry;

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	
	final Map<String, Object> model = new HashMap<String, Object>();

	/**
	 * 
	 */
	protected Map<String, Object> executeImpl(WebScriptRequest req,
			Status status, Cache cache) {
		String name = req.getParameter("name");
		String type = req.getParameter("type");
		_log.info("Check for name:" + name + " type:" + type);

		boolean isExist = false;
		if (type != null && !type.trim().equals("")) {
			if (type.trim().equals("person")) {
				_log.info("Checking for person");
				isExist = isPersonExist(name);
			} else if (type.trim().equals("group")) {
				_log.info("checking for group");
				isExist = isGroupExist(name);
			}
			model.put("input_name", name);
			model.put("input_type", type);
			model.put("isExist", isExist);
		}

		return model;
	}

	/**
	 * 
	 * @param name
	 * @return
	 */
	private boolean isPersonExist(String name) {
		boolean isExist = false;
		if (name != null && !name.trim().equals("")) {
			PersonService personService = serviceRegistry.getPersonService();
			isExist = personService.personExists(name);
		}
		return isExist;
	}

	/**
	 * 
	 * @param name
	 * @return
	 */
	private boolean isGroupExist(String name) {
		boolean isExist = false;
		if (name != null && !name.trim().equals("")) {
			AuthorityService authorityService = serviceRegistry
					.getAuthorityService();
			isExist = authorityService.authorityExists("GROUP_" + name);
		}
		return isExist;
	}

}
