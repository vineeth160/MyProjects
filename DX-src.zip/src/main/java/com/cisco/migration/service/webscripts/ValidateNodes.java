package com.cisco.migration.service.webscripts;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.Stack;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.SubFolderFilter;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.ContentData;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

/**
 * 
 * @author apulluri
 *
 */
public class ValidateNodes extends DeclarativeWebScript {
	protected static final Log logger = LogFactory.getLog(ValidateNodes.class);
	private ServiceRegistry serviceRegistry;
	
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {
		ResourceBundle resourceBundle=getResources();
		Map<String, Object> model = new HashMap<String, Object>();
		String validate = req.getParameter(resourceBundle.getString("param.validate"));
		String nodeRef = req.getParameter(resourceBundle.getString("param.noderef"));
		String property = req.getParameter(resourceBundle.getString("param.validate.property"));
		String propertyType = req.getParameter(resourceBundle.getString("param.validate.property"));
		try{
			
			if(nodeRef==null){
				status.setCode(status.STATUS_BAD_REQUEST);
				model.put("status", status.STATUS_BAD_REQUEST);
				model.put("message", MessageFormat.format(resourceBundle.getString("message.notfound"), resourceBundle.getString("param.noderef")));
			}else if(validate==null){
				status.setCode(status.STATUS_BAD_REQUEST);
				model.put("status", status.STATUS_BAD_REQUEST);
				model.put("message", MessageFormat.format(resourceBundle.getString("message.notfound"), resourceBundle.getString("param.validate")));
			} else{
				if(validate.equalsIgnoreCase(resourceBundle.getString("param.validate.content"))){
					logger.info("--------------------content validation----------------------");
					List<NodeRef> contentNodes = listSimpleDeep(new NodeRef(nodeRef), true, false, null);
					Iterator<NodeRef> nodeIterator = contentNodes.iterator();
					List<NodeRef> contentLessNodes = new ArrayList<NodeRef>();
					while(nodeIterator.hasNext()){
						NodeRef node = nodeIterator.next();
						ContentData content=serviceRegistry.getContentService().getReader(node, ContentModel.PROP_CONTENT).getContentData();
						logger.info(content.getSize());
						if(content.getSize()<=0){
							contentLessNodes.add(node);
						}
					}
					status.setCode(status.STATUS_OK);
					model.put("status", status.STATUS_OK);
					model.put(resourceBundle.getString("model.key.nodes"), contentLessNodes);
				}else if(validate.equalsIgnoreCase(resourceBundle.getString("param.validate.property"))){
					if(property==null){
						status.setCode(status.STATUS_BAD_REQUEST);
						status.setMessage(MessageFormat.format(resourceBundle.getString("message.notfound"), resourceBundle.getString("param.validate.property")));
						model.put("status", status.STATUS_BAD_REQUEST);
						model.put("message", MessageFormat.format(resourceBundle.getString("message.notfound"), resourceBundle.getString("param.validate.property")));
					}else{
						List<NodeRef> nullPropNodes = new ArrayList<NodeRef>();
						List<NodeRef> nodes = listSimpleDeep(new NodeRef(nodeRef), true, false, null);
						Iterator<NodeRef> nodeIterator = nodes.iterator();
						NamespaceService namespaceService = serviceRegistry.getNamespaceService();
						NodeService nodeService = serviceRegistry.getNodeService();
						QName propertyQName = QName.createQName(propertyType, namespaceService);
						logger.info("***********************************");
						logger.info(propertyType);
						while(nodeIterator.hasNext()){
							List<NodeRef> contentLessNodes = new ArrayList<NodeRef>();
							NodeRef node = nodeIterator.next();
							String propValue = nodeService.getProperty(node, propertyQName)==null?"":nodeService.getProperty(node, propertyQName).toString();
							logger.info(propertyType+" property value "+propValue.length());
							if(propValue.length()<=0){
								logger.info(node);
								nullPropNodes.add(node);
							}
						}
						logger.info(nullPropNodes);
						logger.info("***********************************");
						status.setCode(status.STATUS_OK);
						model.put("status", status.STATUS_OK);
						model.put(resourceBundle.getString("model.key.nodes"), nullPropNodes);
					}
				}else if(validate.equalsIgnoreCase(resourceBundle.getString("param.validate.duplicate"))){
					List<NodeRef> nodes = listSimpleDeep(new NodeRef(nodeRef), true, false, null);
					logger.info("8****************************************************************");
					Map<String,String> duplicates=getDuplicateValueNodes(propertyType, nodes);
					status.setCode(status.STATUS_OK);
					model.put("status", status.STATUS_OK);
					model.put(resourceBundle.getString("model.key.nodes"), duplicates);
					logger.info("8****************************************************************");
				}else{
					List<NodeRef> contentNodes = listSimpleDeep(new NodeRef(nodeRef), true, false, null);
					Iterator<NodeRef> nodeIterator = contentNodes.iterator();
					logger.info("---------------------------------comparing mimetype");
					List<NodeRef> octetNodes = new ArrayList<NodeRef>();
					while(nodeIterator.hasNext()){
						NodeRef node = nodeIterator.next();
						String mimeType=serviceRegistry.getContentService().getWriter(node, ContentModel.PROP_CONTENT, false).getMimetype();
						logger.info("***********************************");
						logger.info(mimeType);
						logger.info(resourceBundle.getString("content.mimetype"));
						logger.info("***********************************");
						if(mimeType.equalsIgnoreCase(resourceBundle.getString("content.mimetype"))){
							octetNodes.add(node);
						}
					}
					status.setCode(status.STATUS_OK);
					model.put("status", status.STATUS_OK);
					model.put(resourceBundle.getString("model.key.nodes"), octetNodes);
				}
			}
		}catch(Exception e){
			status.setCode(status.STATUS_INTERNAL_SERVER_ERROR);
			status.setMessage(e.getMessage());
			logger.error(e.getStackTrace(), e);
			model.put("status", status.STATUS_INTERNAL_SERVER_ERROR);
			model.put("message", e.getMessage());
		}
		return model;
	}
	
	/**
	 * returns the folder types from retrieved nodes
	 * 
	 * */
	public Set<QName> buildFolderTypes()
    {
        Set<QName> folderTypeQNames = new HashSet<QName>(50);
        
        // Build a list of folder types
        Collection<QName> qnames = serviceRegistry.getDictionaryService().getSubTypes(ContentModel.TYPE_FOLDER, true);
        folderTypeQNames.addAll(qnames);
        folderTypeQNames.add(ContentModel.TYPE_FOLDER);
        
        // Remove 'system' folders
        qnames = serviceRegistry.getDictionaryService().getSubTypes(ContentModel.TYPE_SYSTEM_FOLDER, true);
        folderTypeQNames.removeAll(qnames);
        folderTypeQNames.remove(ContentModel.TYPE_SYSTEM_FOLDER);
        
        return folderTypeQNames;
    }
	/**
	 * returns file types from the retrieved nodes
	 * */
	public Set<QName> buildFileTypes()
    {
        Set<QName> fileTypeQNames = new HashSet<QName>(50);
        
        // Build a list of file types
        Collection<QName> qnames = serviceRegistry.getDictionaryService().getSubTypes(ContentModel.TYPE_CONTENT, true);
        fileTypeQNames.addAll(qnames);
        fileTypeQNames.add(ContentModel.TYPE_CONTENT);
        qnames = serviceRegistry.getDictionaryService().getSubTypes(ContentModel.TYPE_LINK, true);
        fileTypeQNames.addAll(qnames);
        fileTypeQNames.add(ContentModel.TYPE_LINK);
        
        return fileTypeQNames;
    }
	/**
	 * @param contextNodeRef
	 * @param files
	 * @param folders
	 * @param folderFilter
	 * it lists all the deep folders and files under specified noderef
	 * */
 	public List<NodeRef> listSimpleDeep(NodeRef contextNodeRef, boolean files, boolean folders, SubFolderFilter folderFilter)
    {

        // To hold the results.
        List<NodeRef> result = new ArrayList<NodeRef>();
        
        // Build a list of folder types
        Set<QName> folderTypeQNames = buildFolderTypes();
        Set<QName> fileTypeQNames = (files ? buildFileTypes() : new HashSet<QName>(0));
        
        if(!folders && !files)
        {
            return Collections.emptyList();
            
        }
        
        // Shortcut
        if (folderTypeQNames.size() == 0)
        {
            return Collections.emptyList();
        }
        
        Stack<NodeRef> toSearch = new Stack<NodeRef>();
        toSearch.push(contextNodeRef);
        
        // Now we need to walk down the folders.
        while(!toSearch.empty())
        {
            NodeRef currentDir = toSearch.pop();
            
            List<ChildAssociationRef> folderAssocRefs = serviceRegistry.getNodeService().getChildAssocs(currentDir, folderTypeQNames);
            
            for (ChildAssociationRef folderRef : folderAssocRefs)
            {
                // We have some child folders
                boolean include = true;
                if(folderFilter != null)
                {
                    include = folderFilter.isEnterSubfolder(folderRef);
                    if(include)
                    {
                        // yes search in these subfolders
                        toSearch.push(folderRef.getChildRef());
                    }
                }
                else
                {
                    // No filter - Add the folders in the currentDir
                    toSearch.push(folderRef.getChildRef());
                }
                
                if(folders && include)
                {
                    result.add(folderRef.getChildRef());
                }
            }
                
            if(files)
            {
                // Add the files in the current dir
                List<ChildAssociationRef> fileAssocRefs = serviceRegistry.getNodeService().getChildAssocs(currentDir, fileTypeQNames);
                for (ChildAssociationRef fileRef : fileAssocRefs)
                {
                    result.add(fileRef.getChildRef());
                }
            }
        }
        

 
        // Done
        return result;
    }
 	public Map<String, String> getDuplicateValueNodes(String propertyType,List<NodeRef> nodes){
 		Map<String, String> duplicates = new HashMap<String, String>();
 		Map<String, String> nodesMap = new HashMap<String, String>();
 		QName propetyQName = QName.createQName(propertyType, serviceRegistry.getNamespaceService());
 		NodeService nodeService = serviceRegistry.getNodeService();
 		Iterator<NodeRef> nodesIterator = nodes.iterator();
 		logger.info("size of nodes : "+nodes.size());
 		while(nodesIterator.hasNext()){
 			NodeRef node= nodesIterator.next();
 			String propertyValue = nodeService.getProperty(node, propetyQName)==null?"":nodeService.getProperty(node, propetyQName).toString();
 			logger.info("id : "+propertyValue+"\n");
 			if(nodesMap.get(propertyValue)==null){
 				logger.info(propetyQName);
 				logger.info(propertyValue);
 				nodesMap.put(propertyValue, node.toString());
 			}else{
 				String value=nodesMap.get(propertyValue);
 				nodesMap.put(propertyValue, value+","+node.toString()); 
 			}
 		}
 		logger.info("nodes map size ; "+nodesMap.size());
 		Iterator<String> mapIterator = nodesMap.keySet().iterator();
 		while(mapIterator.hasNext()){
 			String key = mapIterator.next();
 			String nodeRefs = nodesMap.get(key);
 			String[] nodeArray = nodeRefs.split(",");
 			if(nodeArray.length<2 && (key!="" || key!=null)){
 				mapIterator.remove();
 			}
 		}
 		return nodesMap;
 	}
}
