package com.cisco.migration.service.webscripts;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.SubFolderFilter;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;


public class GetChildFolderAndFilesCount extends DeclarativeWebScript {
	
	
	private static Logger _logger = Logger.getLogger(GetChildFolderAndFilesCount.class);
	
	private ServiceRegistry serviceRegistry;

    public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	@Override
    protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
    {
		
		
		
		Map<String, Object> model = new HashMap<String, Object>();
		try {			
			int folderCount=0,filesCount=0,versionCount=0;
			long fileSize=0l,versionsSize=0l;
			String nodeRef = req.getParameter("folderRef");
			String fromDate = req.getParameter("fromDate");
			String toDate = req.getParameter("toDate");
			String aspect = req.getParameter("aspect");
			String property = req.getParameter("property");
			
			
			
			
			if(nodeRef==""||nodeRef==null)
			{
				model.put("error", "true");
				model.put("statusCode", "400");
				model.put("message", "NodeRef not specified");
			}else{
				//contextNodeRef, false, true, filter
				_logger.info("Noderef :"+nodeRef);
				NodeRef node = new NodeRef(nodeRef);
				List<NodeRef> folderNodeRefs = listSimpleDeep(node, false, true, null);
				List<NodeRef> fileNodeRefs = listSimpleDeep(node, true, false, null);
				_logger.info("Folders found :"+folderNodeRefs.size());
				_logger.info("Files Found"+fileNodeRefs.size());
				if(fromDate==null && toDate==null && aspect==null && property==null){
					folderCount=folderNodeRefs.size();
					for(NodeRef singleFileNode : fileNodeRefs){
						if(serviceRegistry.getVersionService().isVersioned(singleFileNode)){
							filesCount+=1;
							versionCount+=getVersions(singleFileNode).size();
							String[] filesSize = getVersionedFileSize(singleFileNode).split(",");
							versionsSize+=Long.parseLong(filesSize[0]);
							fileSize+=Long.parseLong(filesSize[1]);
						}else{
							_logger.debug(singleFileNode+" has no versions");
							filesCount+=1;
							fileSize+=getFileSize(singleFileNode);
						}
						
					}
				}else{
					_logger.info("Applying filters");
					
					if(fromDate!=null && toDate!=null && aspect==null && property==null){
						if(isValidDates(fromDate, toDate)){        				
							_logger.info("applying date filters");
							List<NodeRef> filteredFolderNodeRefs = getDateFilteredNodes(folderNodeRefs, fromDate, toDate);
							List<NodeRef> filteredFileNodeRefs =  getDateFilteredNodes(fileNodeRefs, fromDate, toDate);
							folderCount = filteredFolderNodeRefs.size();
							versionCount= getVersions(filteredFileNodeRefs).size();
							filesCount=getHeadVersions(filteredFileNodeRefs).size();
							List<NodeRef> versions = getVersions(filteredFileNodeRefs);
							List<NodeRef> headFiles = getHeadVersions(filteredFileNodeRefs);
							for(NodeRef versionNode : versions){
								versionsSize+=getFileSize(versionNode);
							}
							for(NodeRef headNode : headFiles){
								fileSize+=getFileSize(headNode);
							}
						}
					}else if(fromDate!=null && toDate!=null && aspect!=null && property==null){
						if(isValidDates(fromDate, toDate)){        				
							_logger.info("applying date and aspect filter");
							List<NodeRef> filteredFolderNodeRefs = getDateFilteredNodes(folderNodeRefs, fromDate, toDate);
							List<NodeRef> filteredFileNodeRefs =  getDateFilteredNodes(fileNodeRefs, fromDate, toDate);
							List<NodeRef> aspectFolders = getAspectFilteredNodes(filteredFolderNodeRefs,aspect);
							List<NodeRef> aspectFiles = getAspectFilteredNodes(filteredFileNodeRefs,aspect);
							folderCount=aspectFolders.size();
							filesCount=getHeadVersions(aspectFiles).size();
							versionCount=getVersions(aspectFiles).size();
							List<NodeRef> versions = getVersions(aspectFiles);
							List<NodeRef> headFiles = getHeadVersions(aspectFiles);
							for(NodeRef versionNode : versions){
								versionsSize+=getFileSize(versionNode);
							}
							for(NodeRef headNode : headFiles){
								fileSize+=getFileSize(headNode);
							}
						}
					}else if(fromDate!=null && toDate!=null && aspect==null && property!=null){
						if(isValidDates(fromDate, toDate)){        				
							_logger.info("applying date and property filter");
							List<NodeRef> filteredFileNodeRefs =  getDateFilteredNodes(fileNodeRefs, fromDate, toDate);
							List<NodeRef> propertyFiles = getPropertyFilteredNodes(filteredFileNodeRefs,property);
							folderCount=0;
							List<NodeRef> versions = getVersions(propertyFiles);
							List<NodeRef> headFiles = getHeadVersions(propertyFiles);
							filesCount=headFiles.size();
							versionCount = versions.size();
							for(NodeRef versionNode : versions){
								versionsSize+=getFileSize(versionNode);
							}
							for(NodeRef headNode : headFiles){
								fileSize+=getFileSize(headNode);
							}
						}
					}else if(fromDate==null && toDate==null && aspect!=null && property!=null){
						_logger.info("applying aspect and property filter");
						List<NodeRef> aspectFolders = getAspectFilteredNodes(folderNodeRefs,aspect);
						List<NodeRef> aspectFiles = getAspectFilteredNodes(fileNodeRefs,aspect);
						List<NodeRef> propertyFiles = getPropertyFilteredNodes(aspectFiles,property);
						folderCount=aspectFolders.size();
						filesCount= getHeadVersions(propertyFiles).size();
						versionCount = getVersions(propertyFiles).size();
						List<NodeRef> versions = getVersions(propertyFiles);
						List<NodeRef> headFiles = getHeadVersions(propertyFiles);
						for(NodeRef versionNode : versions){
							versionsSize+=getFileSize(versionNode);
						}
						for(NodeRef headNode : headFiles){
							fileSize+=getFileSize(headNode);
						}
					}else if(fromDate==null && toDate==null && aspect!=null && property==null){
						_logger.info("applying aspect filter");
						List<NodeRef> aspectFolders = getAspectFilteredNodes(folderNodeRefs,aspect);
						List<NodeRef> aspectFiles = getAspectFilteredNodes(fileNodeRefs,aspect);
						folderCount = aspectFolders.size();
						filesCount = getHeadVersions(aspectFiles).size();
						versionCount = getVersions(aspectFiles).size();
						List<NodeRef> versions = getVersions(aspectFiles);
						List<NodeRef> headFiles = getHeadVersions(aspectFiles);
						for(NodeRef versionNode : versions){
							versionsSize+=getFileSize(versionNode);
						}
						for(NodeRef headNode : headFiles){
							fileSize+=getFileSize(headNode);
						}
						
					}else if(fromDate==null && toDate==null && aspect==null && property!=null){
						_logger.info("applying property filter");
						List<NodeRef> propertyFiles = getPropertyFilteredNodes(fileNodeRefs,property);
						folderCount = 0;
						filesCount = getHeadVersions(propertyFiles).size();
						versionCount = getVersions(propertyFiles).size();
						List<NodeRef> versions = getVersions(propertyFiles);
						List<NodeRef> headFiles = getHeadVersions(propertyFiles);
						for(NodeRef versionNode : versions){
							versionsSize+=getFileSize(versionNode);
						}
						for(NodeRef headNode : headFiles){
							fileSize+=getFileSize(headNode);
						}
					}else{
						if(isValidDates(fromDate, toDate)){        				
							_logger.info("applying date, aspect and property filter");
							List<NodeRef> filteredFolderNodeRefs = getDateFilteredNodes(folderNodeRefs, fromDate, toDate);
							List<NodeRef> filteredFileNodeRefs =  getDateFilteredNodes(fileNodeRefs, fromDate, toDate);
							List<NodeRef> aspectFolders = getAspectFilteredNodes(filteredFolderNodeRefs,aspect);
							List<NodeRef> aspectFiles = getAspectFilteredNodes(filteredFileNodeRefs,aspect);
							List<NodeRef> propertyFiles = getPropertyFilteredNodes(aspectFiles,property);
							folderCount = aspectFolders.size();
							filesCount = getHeadVersions(propertyFiles).size();
							versionCount = getVersions(propertyFiles).size();
							List<NodeRef> versions = getVersions(propertyFiles);
							List<NodeRef> headFiles = getHeadVersions(propertyFiles);
							for(NodeRef versionNode : versions){
								versionsSize+=getFileSize(versionNode);
							}
							for(NodeRef headNode : headFiles){
								fileSize+=getFileSize(headNode);
							}
						}
					}
					_logger.info("filters applied succesfully");
				}
				_logger.info("folderscount : "+folderCount);
				_logger.info("filescount : "+filesCount);
				_logger.info("versioncount : "+ versionCount);
				_logger.info("filessize : "+ fileSize);
				_logger.info("versionsize : "+ versionsSize);
				model.put("folderscount", folderCount);
				model.put("filescount", filesCount);
				model.put("versioncount", versionCount);
				model.put("filessize", fileSize);
				model.put("versionsize", versionsSize);
			}
		}catch(Exception e){
			_logger.error(GetChildFolderAndFilesCount.class+" thrown an error");
			model.put("error", "true");
			model.put("statusCode", status.getCode());
			_logger.error(e.getStackTrace(),e);
			model.put("message", e.getMessage());
    	}
    	
    	return model;
    }
	
	
	/**
	 * @author apulluri
	 * @param nodes
	 * @param property
	 * accepts the list of nodes as a parameter and applies property filter to list
	 * */
	private List<NodeRef> getPropertyFilteredNodes(
			List<NodeRef> nodes, String property) {
		List<NodeRef> propertyNodes = new ArrayList<NodeRef>();
		String qname = "mg:legacySourceSystem".replace("mg:", "{http://www.alfresco.org/model/migration/1.0}");
		for(NodeRef node : nodes){
			Serializable propertyValue = serviceRegistry.getNodeService().getProperty(node, QName.createQName(qname));
			if(propertyValue!=null && property.toString().equals(propertyValue)){
				_logger.info(node+" is a valid after property filter applied");
				propertyNodes.add(node);
			}
		}
		return propertyNodes;
	}
	/**
	 * @author apulluri
	 * @param nodes
	 * @param aspect
	 * accepts the list of nodes as a parameter and applies aspect filter to list and returns filtered list
	 * */
	private List<NodeRef> getAspectFilteredNodes(
			List<NodeRef> nodes,String aspect) {
		List<NodeRef> aspectNodes = new ArrayList<NodeRef>();
		String qname = aspect.replace("cm:", "{http://www.alfresco.org/model/content/1.0}").replace("mg:", "{http://www.alfresco.org/model/migration/1.0}");
		for(NodeRef node : nodes){
			if(serviceRegistry.getNodeService().hasAspect(node, QName.createQName(qname))){
				_logger.info(node+" is a valid after aspect filter applied");
				aspectNodes.add(node);
			}
		}
		return aspectNodes;
	}
	/**
	 * @author apulluri
	 * @param nodes
	 * @param fromDate
	 * @param toDate
	 * accepts list of nodes as a parameter and applies dates filter to list and returns the filtered list
	 * */
	public List<NodeRef> getDateFilteredNodes(List<NodeRef> nodes,String fromDate,String toDate){
		List<NodeRef> filteredNodes = new ArrayList<NodeRef>();
		for(NodeRef node : nodes){
			if(isValidNode(fromDate, toDate, serviceRegistry.getNodeService().getProperty(node, ContentModel.PROP_CREATED).toString())){
				_logger.info(node+" is valid after date filter applied");
				filteredNodes.add(node);
			}
		}
		return filteredNodes;
	}
	/**
	 * @author apulluri
	 * @param fromDate
	 * @param toDate
	 * @param nodeDate
	 * accepts node date as a parameter and checks whether date on node is valid or not
	 * it returns true id date is valid else returns false
	 * */
	 public boolean isValidNode(String fromDate, String toDate, String nodeDate)
	    {
		 	_logger.info("checking for valid date");
	        boolean valid = false;
	        String inputFormat = "MM/dd/yyyy";
	        String nodeDateFormat = "EEE MMM dd HH:mm:ss z yyyy";
	        SimpleDateFormat createdDate = new SimpleDateFormat(nodeDateFormat);
	        SimpleDateFormat formattedDate = new SimpleDateFormat(inputFormat);
	        Date fromDateObj = null;
	        Date toDateObj = null;
	        Date nodePropDate = null;
	        try
	        {
	            fromDateObj = formattedDate.parse(fromDate);
	            toDateObj = formattedDate.parse(toDate);
	            nodePropDate = createdDate.parse(nodeDate);
	            Calendar cal = Calendar.getInstance();
	            cal.setTime(nodePropDate);
	            cal.set(11, 0);
	            cal.set(12, 0);
	            cal.set(13, 0);
	            cal.set(14, 0);
	            nodePropDate.setTime(cal.getTimeInMillis());
	            if(nodePropDate.equals(toDateObj) || nodePropDate.equals(fromDateObj) || nodePropDate.after(fromDateObj) && nodePropDate.before(toDateObj))
	            {
	            	_logger.info(nodeDate+" is valid");
	                valid = true;
	            }
	        }
	        catch(ParseException e)
	        {
	            e.printStackTrace();
	        }
	        return valid;
	    }
	 
	 /**
	  * @author apulluri
	  * @param node
	  * accepts the noderef as a parameter and returns the list of versions
	  * it returns only head versions
	  * */
	public List<NodeRef> getVersions(NodeRef node) {
		_logger.info("into getVersions method");
		List<NodeRef> nodes = new ArrayList<NodeRef>();
		VersionHistory versionHistory = serviceRegistry.getVersionService().getVersionHistory(node);
		Collection<Version> versions=versionHistory.getAllVersions();
		if(versions.size()>0){
			for(Version version : versions){
				if(!version.getVersionLabel().equals("1.0")){	
					nodes.add(version.getFrozenStateNodeRef());
				}
			}
		}
		return nodes;
	}
	/**
	 * @author apulluri
	 * @param fileNodes
	 * accepts the list of nodes as a parameters and returns the list of versions as a result
	 * */
	public List<NodeRef> getVersions(List<NodeRef> fileNodes) {
		List<NodeRef> nodes = new ArrayList<NodeRef>();
		for(NodeRef node : fileNodes){
			if(serviceRegistry.getVersionService().isVersioned(node)){
				VersionHistory versionHistory = serviceRegistry.getVersionService().getVersionHistory(node);
				Collection<Version> versions=versionHistory.getAllVersions();
				_logger.info(node+" has "+versions.size()+" versions");
				if(versions.size()>0){
					for(Version version : versions){
						if(!version.getVersionLabel().equals("1.0")){					
							nodes.add(version.getFrozenStateNodeRef());
						}
					}
				}
			}
		}
		return nodes;
	}
	/**
	 * @author apulluri
	 * @param fileNodes
	 * accepts the list of nodeRefs as parameter and retuns the list of head versions to get the head files count
	 * */
	public List<NodeRef> getHeadVersions(List<NodeRef> fileNodes) {
		List<NodeRef> nodes = new ArrayList<NodeRef>();
		for(NodeRef node : fileNodes){
			if(serviceRegistry.getVersionService().isVersioned(node)){				
				VersionHistory versionHistory = serviceRegistry.getVersionService().getVersionHistory(node);
				Collection<Version> versions=versionHistory.getAllVersions();
				if(versions.size()>0){
					for(Version version : versions){
						if(version.getVersionLabel().equals("1.0")){					
							nodes.add(version.getFrozenStateNodeRef());
						}
					}
				}
			}else{
				nodes.add(node);
			}
		}
		return nodes;
	}
	
	/**
	 * @author apulluri
	 * @param nodeRef
	 * accepts the noderef as a parameter and returns the file size
	 * */
	public long getFileSize(NodeRef nodeRef){
		long fileSize=0l;
		fileSize=serviceRegistry.getFileFolderService().getFileInfo(nodeRef).getContentData().getSize();
		return fileSize;
	}
	/**
	 * @author apulluri
	 * @param nodeRef
	 * accepts the noderef as a parameter and returns the versions files size as a result
	 * */
	public String getVersionedFileSize(NodeRef nodeRef){
		long versionFileSize=0l;
		long headFileSize=0l;
		VersionHistory versionHistory = serviceRegistry.getVersionService().getVersionHistory(nodeRef);
		Collection<Version> versions=versionHistory.getAllVersions();
		if(versions.size()>0){
			for(Version version : versions){
				if(!version.getVersionLabel().equals("1.0")){					
					versionFileSize+=getFileSize(version.getFrozenStateNodeRef());
				}else{
					headFileSize+=getFileSize(version.getFrozenStateNodeRef());
				}
			}
		}
		return versionFileSize+","+headFileSize;
	}
	//start of deep folder fetch
	
	/**
	 * returns the folder types from retrieved nodes
	 * 
	 * */
	public Set<QName> buildFolderTypes()
    {
        Set<QName> folderTypeQNames = new HashSet<QName>(50);
        
        // Build a list of folder types
        Collection<QName> qnames = serviceRegistry.getDictionaryService().getSubTypes(ContentModel.TYPE_FOLDER, true);
        folderTypeQNames.addAll(qnames);
        folderTypeQNames.add(ContentModel.TYPE_FOLDER);
        
        // Remove 'system' folders
        qnames = serviceRegistry.getDictionaryService().getSubTypes(ContentModel.TYPE_SYSTEM_FOLDER, true);
        folderTypeQNames.removeAll(qnames);
        folderTypeQNames.remove(ContentModel.TYPE_SYSTEM_FOLDER);
        
        return folderTypeQNames;
    }
	/**
	 * returns file types from the retrieved nodes
	 * */
	public Set<QName> buildFileTypes()
    {
        Set<QName> fileTypeQNames = new HashSet<QName>(50);
        
        // Build a list of file types
        Collection<QName> qnames = serviceRegistry.getDictionaryService().getSubTypes(ContentModel.TYPE_CONTENT, true);
        fileTypeQNames.addAll(qnames);
        fileTypeQNames.add(ContentModel.TYPE_CONTENT);
        qnames = serviceRegistry.getDictionaryService().getSubTypes(ContentModel.TYPE_LINK, true);
        fileTypeQNames.addAll(qnames);
        fileTypeQNames.add(ContentModel.TYPE_LINK);
        
        return fileTypeQNames;
    }
	/**
	 * @param contextNodeRef
	 * @param files
	 * @param folders
	 * @param folderFilter
	 * it lists all the deep folders and files under specified noderef
	 * */
 	public List<NodeRef> listSimpleDeep(NodeRef contextNodeRef, boolean files, boolean folders, SubFolderFilter folderFilter)
    {

        // To hold the results.
        List<NodeRef> result = new ArrayList<NodeRef>();
        
        // Build a list of folder types
        Set<QName> folderTypeQNames = buildFolderTypes();
        Set<QName> fileTypeQNames = (files ? buildFileTypes() : new HashSet<QName>(0));
        
        if(!folders && !files)
        {
            return Collections.emptyList();
            
        }
        
        // Shortcut
        if (folderTypeQNames.size() == 0)
        {
            return Collections.emptyList();
        }
        
        Stack<NodeRef> toSearch = new Stack<NodeRef>();
        toSearch.push(contextNodeRef);
        
        // Now we need to walk down the folders.
        while(!toSearch.empty())
        {
            NodeRef currentDir = toSearch.pop();
            
            List<ChildAssociationRef> folderAssocRefs = serviceRegistry.getNodeService().getChildAssocs(currentDir, folderTypeQNames);
            
            for (ChildAssociationRef folderRef : folderAssocRefs)
            {
                // We have some child folders
                boolean include = true;
                if(folderFilter != null)
                {
                    include = folderFilter.isEnterSubfolder(folderRef);
                    if(include)
                    {
                        // yes search in these subfolders
                        toSearch.push(folderRef.getChildRef());
                    }
                }
                else
                {
                    // No filter - Add the folders in the currentDir
                    toSearch.push(folderRef.getChildRef());
                }
                
                if(folders && include)
                {
                    result.add(folderRef.getChildRef());
                }
            }
                
            if(files)
            {
                // Add the files in the current dir
                List<ChildAssociationRef> fileAssocRefs = serviceRegistry.getNodeService().getChildAssocs(currentDir, fileTypeQNames);
                for (ChildAssociationRef fileRef : fileAssocRefs)
                {
                    result.add(fileRef.getChildRef());
                }
            }
        }
        

 
        // Done
        return result;
    }
 	/**
 	 * @author apulluri
 	 * @param from
 	 * @param to
 	 * accepts two date strings as a paramaters and checks whether from date is lesser than to date if condition satifies it will return true
 	 * */
 	public boolean isValidDates(String from, String to)
    {
        boolean valid = false;
        String dateFormat = "MM/dd/yyyy";
        SimpleDateFormat formatDate = new SimpleDateFormat(dateFormat);
        Date fromDate = null;
        Date toDate = null;
        try
        {
            fromDate = formatDate.parse(from);
            toDate = formatDate.parse(to);
            if(fromDate.before(toDate) || fromDate.equals(toDate))
            {
                valid = true;
            }
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        return valid;
    }
 	
 	//end of deep folder fetch
	
}
