package com.cisco.migration.service.webscripts;

import java.io.IOException;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.OwnableService;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

public class MigSetOwnerRole extends AbstractWebScript {

	private static final Logger log = Logger.getLogger(MigSetOwnerRole.class);
	private OwnableService ownService;
	private PermissionService permissionService;
	private BehaviourFilter policyBehaviourFilter;

	public void setPolicyBehaviourFilter(BehaviourFilter policyBehaviourFilter) {
		this.policyBehaviourFilter = policyBehaviourFilter;
	}

	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}

	public void setOwnService(OwnableService ownService) {
		this.ownService = ownService;
	}

	public static final String CISCO_MODEL_NAMESPACE = "http://www.cisco.com/model/content/1.0";
	public static final QName CISCODOC_TYPE = QName.createQName(CISCO_MODEL_NAMESPACE, "ciscodoc");

	@SuppressWarnings("unchecked")
	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {

		JSONObject result = new JSONObject();
		String nodeValue = null;
		String ownerName = null;
		String type=null;
		NodeRef nodeRef = null;

		try {
			nodeValue = req.getParameter("nodeRef");
			type=req.getParameter("type");

			if (nodeValue != null && !nodeValue.trim().isEmpty()
					&& (nodeValue.startsWith("workspace") || nodeValue.startsWith("versionStore"))) {
				nodeRef = new NodeRef(nodeValue.trim());

				log.debug("NodeRef Created ---> " + nodeRef);
			} else {
				log.debug("NodeRef not created for nodeValue... " + nodeValue);
			}
			if (nodeRef != null) {
				ownerName = ownService.getOwner(nodeRef);

				log.debug("NodeRef " + nodeRef + " Owner Name" + ownerName);
				// setting permissions after disabling the modified properties
				policyBehaviourFilter.disableBehaviour(nodeRef, CISCODOC_TYPE);
				policyBehaviourFilter.disableBehaviour(nodeRef, ContentModel.ASPECT_AUDITABLE);
				policyBehaviourFilter.disableBehaviour(nodeRef, ContentModel.ASPECT_VERSIONABLE);
				if(type.equalsIgnoreCase("file"))
				{
				permissionService.setPermission(nodeRef, ownerName, "OwnerRole", true);
				//log.error("File ---> NodeRef " + nodeRef + " Owner Name" + ownerName);
				result.put("Status", "Success");
				result.put("Message", "Owner Permission given to  " + ownerName);
				}
				else if(type.equalsIgnoreCase("folder"))
				{
					permissionService.setPermission(nodeRef, ownerName, "AdminRole", true);
					//log.error("Folder ---> NodeRef " + nodeRef + " Owner Name" + ownerName);
					result.put("Status", "Success");
					result.put("Message", "FolderAdmin Permission given to  " + ownerName);
				}
				// enabling properties after setting the permission
				policyBehaviourFilter.enableBehaviour(nodeRef, ContentModel.ASPECT_VERSIONABLE);
				policyBehaviourFilter.enableBehaviour(nodeRef, CISCODOC_TYPE);
				policyBehaviourFilter.enableBehaviour(nodeRef, ContentModel.ASPECT_AUDITABLE);

			} else {
				result.put("Status", "Failed");
				result.put("Message", "Unable to Create NodeRef " + nodeValue);
			}
		} catch (Exception e) {

			log.error("Exception Occured", e);
			log.error(" NodeRef " + nodeValue);
			result.put("Status", "Failed");
			result.put("Message", "Invalid Inputs");
		}

		finally {
			String jsonString = result.toString();
			res.getWriter().write(jsonString);
		}

	}

}
