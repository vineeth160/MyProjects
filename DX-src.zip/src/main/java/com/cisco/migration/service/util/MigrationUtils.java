package com.cisco.migration.service.util;

import static com.cisco.migration.service.webscripts.MigrationConstants.NULL_EXCEPTION;
import static com.cisco.migration.service.webscripts.MigrationConstants.PARAM_QNAME;
import static com.cisco.migration.service.webscripts.MigrationConstants.RETENTION_ASPECT;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.dictionary.PropertyDefinition;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 * 
 * @author gpotla
 *
 */
public class MigrationUtils {
	
	private static final Logger LOG = Logger.getLogger(MigrationUtils.class);

	private ServiceRegistry serviceRegistry;
	
	private NodeService nodeService;
	
	private static final String REPLACE_EMPTY_CHARACTER = " ";
	private String tagPattern = "[<>:\"\\/|?*\\n\\r\\t]";

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public void setServiceRegistry(ServiceRegistry registry) {
		this.serviceRegistry = registry;
	}
	
	
	/**
	 * 
	 * @param request
	 * @param uploadFileNode
	 * @throws Exception
	 */
    public void attachMandatoryMetadata(String jsonCommnProp, String jsonMetadaProp, boolean attachFileTagging, String tagAttributes, NodeRef uploadFileNode, String delimeter, String dateFormat,String timeZone) throws Exception {

        LOG.info(" MigrationUtils.attachMandatoryMetadata()  for file Node ::: " + uploadFileNode);
        
        attachCommonProperties(jsonCommnProp, uploadFileNode, delimeter,dateFormat, timeZone);

        attachMetaData(jsonMetadaProp, uploadFileNode, delimeter,dateFormat, timeZone);
        
        // setting Tag attributes to the files
        if (attachFileTagging) {
            attachTagAttributes(uploadFileNode, tagAttributes, delimeter);
        }
    }
    
    /**
     * 
     * @param request
     * @param uploadFileNode
     * @return
     */
    public Map<QName, Serializable> attachMetaData(String jsonMetaProp, NodeRef uploadFileNode, String delimeter, String dateFormat, String timeZone) throws Exception {
        LOG.info(" In MigrationUtils.attachMetaData() Start ");
           Map<QName, Serializable> metaDataProps = null;

            JSONParser jsonParser = new JSONParser();
            JSONObject aspectsJsonObject = null;
            String qName = null;
            String property = null;
            Serializable propValue = null;
            try {
            	if( jsonMetaProp != null) {
                    aspectsJsonObject = (JSONObject) jsonParser.parse(jsonMetaProp);
                    LOG.info(" aspects JsonObject --- >" + aspectsJsonObject);

                    String aspect = null;
                    String aspectQname = null;
                    for (Object aspectName : aspectsJsonObject.keySet()) {
                        metaDataProps = new HashMap<QName, Serializable>();

                        aspect = aspectName.toString();

                        LOG.info("Aspect -->" + aspect);

                        JSONArray jsonArray = (JSONArray) aspectsJsonObject.get(aspectName);

                        if (aspect.equals(RETENTION_ASPECT)) {
                            metaDataProps = attachRecordsInfoAspect(metaDataProps, aspect, jsonArray,delimeter,dateFormat, timeZone );
                            for (Object properties : (JSONArray) aspectsJsonObject.get(aspectName)) {
                                aspectQname = (String) ((JSONObject) properties).get(PARAM_QNAME);
                                break;
                            }
                        } else {
                            for (Object properties : jsonArray) {

                                LOG.info("Properties ::: " + ((JSONObject) properties).keySet());
                                for (Object objects : ((JSONObject) properties).keySet()) {

                                    property = objects.toString();
                                    LOG.info(" Property KEYSET from JSON .. " + property);

                                    if (property.equals(PARAM_QNAME)) {
                                        qName = (String) ((JSONObject) properties).get(property);
                                        aspectQname = qName;
                                    }

                                    LOG.info(" Aspects QName is .. " + qName);

                                    propValue = (Serializable) ((JSONObject) properties).get(property);
                                    if (!property.toString().equals(PARAM_QNAME)) {
                                    	String propDataType = getDataType(QName.createQName(qName, property));
                                    	boolean propMultiValued = getRepetitiveProperty(QName.createQName(qName, property));
                                    	propValue = setDataTypeValue(propDataType, propValue, propMultiValued, delimeter, dateFormat, timeZone);
                                        metaDataProps.put(QName.createQName(qName, property), propValue);
                                    }
                                }
                                LOG.info(aspect + " final metaDataProps  ::: " + metaDataProps);
                            }
                        }
                        // Adding all the aspects and it's corresponding propperties
                        addMetaDataAspect(metaDataProps, aspect.toString(), aspectQname, uploadFileNode);
                    }
            	}

            } catch (Exception e) {
                LOG.error(" Exception while parsing json object .. " + e, e);
                throw new Exception((e != null) ? e.getMessage() : NULL_EXCEPTION);
            } finally {
                LOG.info("In MigrationUtils.attachMetaData() finally block End ");
            }

            return metaDataProps;
    }
    /**
     * 
     * @param request
     * @param uploadFileNode
     */
    public void attachCommonProperties(String jsonCommnProp, NodeRef uploadFileNode, String delimeter, String dateFormat, String timeZone) throws Exception {
        LOG.info(" In MigrationUtils.attachCommonProperties()  Start ");
        final Map<QName, Serializable> metaDataProps = new HashMap<QName, Serializable>();
        JSONParser jsonParser = new JSONParser();
        JSONArray propertiesJsonarray = null;
        String qName = null;
        String property = null;
        Serializable propValue = null;
        try {
        	if(jsonCommnProp != null) {
	            propertiesJsonarray = (JSONArray) jsonParser.parse(jsonCommnProp);
	            LOG.info(" propertiesJsonarray .." + propertiesJsonarray);
	
	            for (int i = 0; i < propertiesJsonarray.size(); i++) {
	                for (Object objects : ((JSONObject) propertiesJsonarray.get(i)).keySet()) {
	
	                    property = objects.toString();
	                    LOG.info("Property KEYSET .. " + property);
	                    if (property.equals(PARAM_QNAME)) {
	                        qName = (String) ((JSONObject) propertiesJsonarray.get(i)).get(property);
	                    }
	                    LOG.info(" Aspects QName value from attachCommonProperties() .. " + qName);
	                    propValue = (Serializable) ((JSONObject) propertiesJsonarray.get(i)).get(objects);
	
	                    if (!property.toString().equals(PARAM_QNAME)) {
	                    	String propDataType = getDataType(QName.createQName(qName, property));
	                    	boolean propMultiValued = getRepetitiveProperty(QName.createQName(qName, property));
	                    	propValue = setDataTypeValue(propDataType, propValue, propMultiValued, delimeter, dateFormat,timeZone);
	                    	metaDataProps.put(QName.createQName(qName, property), propValue);
	                    }
	                }
	            }
        	}
        				// adding metadata properties to created file node
						LOG.info(" final attachCommonProperties "+ metaDataProps);
						nodeService.addProperties(uploadFileNode, metaDataProps);

        } catch (Exception e) {
            LOG.error(" Exception while attachCommonProperties parsing json object .." + e, e);
            throw new Exception((e != null) ? e.getMessage() : NULL_EXCEPTION);
        } finally {
            LOG.info(" In MigrationUtils.attachCommonProperties() End ");
        }

    }
	
	/**
     * 
     * @param tagNodeRef
     * @param tagsList
     */
    public void attachTagAttributes(NodeRef tagNodeRef,  String tagAttributes, String delimeter) {
        LOG.info(" MigrationUtils -- tagAttributes  =  " + tagAttributes +"\t  tagPattern -->"+tagPattern);
        
        Pattern pattern = Pattern.compile(tagPattern);
        Matcher matcher = null;
        
        if(tagAttributes != null) {
	        for(String tag : tagAttributes.split(delimeter)) {
	    		matcher = pattern.matcher(tag);
	    		if(matcher.find()) {
	    			tag = matcher.replaceAll(REPLACE_EMPTY_CHARACTER).trim();
	    			LOG.info(" UnAllowed Tag Pattern Found and final Tag is --->"+tag); 
	    		}
	        	this.serviceRegistry.getTaggingService().addTag(tagNodeRef, tag);
	        }
        }
    }
    
    
    /**
     * 
     * @param metaDataProps
     * @param aspectName
     * @param queueName
     * @param currentNodeRef
     */
    public void addMetaDataAspect(Map<QName, Serializable> metaDataProps, String aspectName,
            String queueName, NodeRef currentNodeRef) {
        LOG.info("In MigrationUtils.AddMetaDataAspect() Start");

            String fileName = (String) this.serviceRegistry.getNodeService().getProperty(currentNodeRef, ContentModel.PROP_NAME);

            boolean hasAspect = this.serviceRegistry.getNodeService().hasAspect(currentNodeRef, QName.createQName(queueName, aspectName));
            LOG.info(fileName + " is having Aspect ---" + aspectName + " ? " + hasAspect);

            LOG.info(" for the ASPECT " + aspectName + ", metaDataProps is " + metaDataProps);

            if (!hasAspect) {
                nodeService.addAspect(currentNodeRef, QName.createQName(queueName, aspectName), metaDataProps);
            } else {
                nodeService.addProperties(currentNodeRef, metaDataProps);
            }
            LOG.info(" Adding Aspect complted for " + aspectName);

        LOG.info("In MigrationUtils.AddMetaDataAspect() End");
    }
    
    
    /**
     * 
     * @param metaDataProps
     * @param aspectName
     * @param jsonArray
     * @return
     * @throws Exception 
     */
    public Map<QName, Serializable> attachRecordsInfoAspect(Map<QName, Serializable> metaDataProps, String aspectName, JSONArray jsonArray, String delimeter, String dateFormat, String timeZone) throws Exception {
        LOG.info(" In MigrationUtils.attachRecordsInfoAspect() Start ");
        String qName = null;
        String property = null;
        Serializable propValue = null;
        for (Object properties : jsonArray) {
            for (Object objects : ((JSONObject) properties).keySet()) {

                property = objects.toString();
                LOG.info("Property KEYSET from .. " + property);
                if (property.equals(PARAM_QNAME)) {
                    qName = (String) ((JSONObject) properties).get(property);
                }
                LOG.info(" Aspects QName value from attachRecordsInfoAspect() .. " + qName);
                propValue = (Serializable) ((JSONObject) properties).get(objects);

                if (!property.toString().equals(PARAM_QNAME)) {
                	String propDataType = getDataType(QName.createQName(qName, property));
                	boolean propMultiValued = getRepetitiveProperty(QName.createQName(qName, property));
                	propValue = setDataTypeValue(propDataType, propValue, propMultiValued, delimeter, dateFormat, timeZone);
                    metaDataProps.put(QName.createQName(qName, property), propValue);
                }
            }
            LOG.info("For " + aspectName + " final attachRecordsInfoAspect  metaDataProps  ::: " + metaDataProps);
        }
        LOG.info(" In MigrationUtils.attachRecordsInfoAspect() End ");
        return metaDataProps;
    }
    
    /**
     * 
     * @param multipleVals
     */
    public void setRepetitivePropertyValues(String multipleVals, NodeRef objectNodeRef) {
    	Map<QName, Serializable> RepetitiveProps = new HashMap<QName, Serializable>();
    	
    	List<String> multiList = new ArrayList<String>();
    	multiList.addAll(Arrays.asList(multipleVals.split(",")));
    	
    	RepetitiveProps.put(ContentModel.PROP_TAGS, (Serializable)multiList);
    	
    	this.nodeService.addProperties(objectNodeRef, RepetitiveProps);
    }
    
    /**
     * 
     * @param qName
     * @return
     */
    public String getDataType(QName qName) {
     
    	PropertyDefinition pd= this.serviceRegistry.getDictionaryService().getProperty(qName);
    	String dataType =  pd.getDataType().getName().getLocalName();
    	
    	LOG.info(" Data TYPE getName().getLocalName() ::::::::::: "+pd.getDataType().getName().getLocalName());
    	LOG.info(" Data TYPE getName().getPrefixString() ::::::::::: "+pd.getDataType().getName().getPrefixString());
    	return dataType;
    }
    
   /**
    * 
    * @param dataType
    * @param propValue
    * @param propMultiValued
    * @return
 * @throws ParseException 
    */
	public Serializable setDataTypeValue(String dataType, Serializable propValue, boolean propMultiValued, String delimeter, String dateFormat, String timeZone) throws Exception {
		
		SimpleDateFormat dformat = null;

		if(dataType.equals("date") || dataType.equals("datetime")) {
			if(dateFormat != null && !dateFormat.trim().equals("")) {
				dformat = new SimpleDateFormat(dateFormat);
			} else{
				throw new Exception("Please pass the DateFormat as request parameter.");
			}
			if(timeZone != null && !timeZone.trim().equals("")) {
				dformat.setTimeZone(TimeZone.getTimeZone(timeZone));
			}
			LOG.info(" Formated("+dateFormat+") date to "+timeZone+" <-- propValue -->"+propValue);
		}

		LOG.info(" In setDataTypeValue ::  propMultiValued is " + propMultiValued +"\t propValue ::: "+ propValue+"\t dataType ::: "+ dataType);
		if (propMultiValued) {
			List<Serializable> multipleValues = new ArrayList<Serializable>();
			LOG.info("  propMultiValued " + propMultiValued +"\t propValue ::: "+ propValue+"\t delimeter ::: "+ delimeter);
				Serializable multiVal = null;
				for(String listVal : ((String) propValue).split(delimeter)) {
						if(listVal != null && !listVal.trim().equals("")) {
						LOG.info(" Splitted listVal ::: "+ listVal);
						if (dataType.equals("boolean")) {
							multiVal = Boolean.parseBoolean(listVal);
							multipleValues.add(multiVal);
						} else if (dataType.equals("date")) {
							if(listVal != null && !listVal.trim().equals("")) {
								multiVal = dformat.parse(listVal);
							}else{
								multiVal = null;
							}
							multipleValues.add(multiVal);
						} else if (dataType.equals("noderef")) {
							multiVal = new NodeRef(listVal);
							multipleValues.add(multiVal);
						} else if (dataType.equals("long")) {
							multiVal = new Long(listVal);
							multipleValues.add(multiVal);
						} else if (dataType.equals("float")) {
							multiVal = new Float( listVal);
							multipleValues.add(multiVal);
						} else if (dataType.equals("double")) {
							multiVal = new Double( listVal);
							multipleValues.add(multiVal);
						} else if (dataType.equals("datetime")) {
							if(listVal != null && !listVal.trim().equals("")) {
								multiVal = new Timestamp(dformat.parse(listVal).getTime());
							}else{
								multiVal = null;
							}
							multipleValues.add(multiVal);
						} else if (dataType.equals("int")) {
							multiVal = new Integer(listVal);
							multipleValues.add(multiVal);
						}else{
							multipleValues.add(listVal);
						}
					}
				}
			
			LOG.info(" Setting repetitive / Multiple type Values ::: "+ multipleValues);
			return (Serializable) multipleValues;

		} else {

			if(propValue != null && !propValue.toString().trim().equals("")) {
				if (dataType.equals("boolean")) {
					if(propValue instanceof Boolean) {
						propValue = propValue;
					}else{
						propValue = Boolean.parseBoolean((String)propValue);
					}
				} else if (dataType.equals("date")) {
					if(propValue != null && !propValue.toString().trim().equals("")) {
						propValue = dformat.parse((String)propValue);
					}
				} else if (dataType.equals("noderef")) {
					propValue = new NodeRef((String) propValue);
				} else if (dataType.equals("long")) {
					propValue = new Long((String) propValue);
				} else if (dataType.equals("float")) {
					propValue = new Float((String) propValue);
				} else if (dataType.equals("double")) {
					propValue = new Double((String) propValue);
				} else if (dataType.equals("datetime")) {
					if(propValue != null && !propValue.toString().trim().equals("")) {
						propValue = new Timestamp(dformat.parse((String)propValue).getTime());
					}
				} else if (dataType.equals("int")) {
					propValue = new Integer((String) propValue);
				}
			}else{
				propValue = null;
			}
			LOG.info(" Setting Single property type Value ::: "+ propValue);
			return propValue;
		}

	}
    
    /**
     * 
     * @param qName
     * @return
     */
	public boolean getRepetitiveProperty(QName qName) {
		LOG.info(" QNAME from getRepetitiveProperty :: " + qName);
		boolean isMultiValued = this.serviceRegistry.getDictionaryService().getProperty(qName).isMultiValued();
		LOG.info(" Property Type MultiValued :: " + isMultiValued);
		return isMultiValued;
	}

}
