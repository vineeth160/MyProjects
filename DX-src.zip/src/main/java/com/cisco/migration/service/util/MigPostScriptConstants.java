package com.cisco.migration.service.util;

import org.alfresco.service.namespace.QName;

public class MigPostScriptConstants {

	public static final String CISCO_MODEL_NAMESPACE = "http://www.cisco.com/model/content/1.0";

	public static final QName CISCODOC_TYPE = QName.createQName(CISCO_MODEL_NAMESPACE, "ciscodoc");

	public static final String PARAM_BASE_FILE_NODEREF = "baseFileNodeRef";

	public static final String PARAM_STATUS_MSG = "statusMessage";

	public static final String RES_OBJECT_NODEREF = "objectNodeRef";

	public static final String PARAM_PERMISSION_JSON = "permissionsJson";

	public static final String PARAM_CONTENT_OWNER = "contentowner";

	public static final String PARAM_INHERIT_PERM = "isInheritPerm";

	public static final String PARAM_FILE_NODE_REF = "uploadFileNodeRef";

	public static final String NULL_EXCEPTION = "java.lang.NullPointerException";

	public final static String MIGRATION_MODEL_URI = "http://www.alfresco.org/model/migration/1.0";

	public final static QName MIG_DOCORIVERCREDATE_PROP = QName.createQName(MIGRATION_MODEL_URI, "versionCreatedDate");
	
	public final static QName MIG_DOCORIVERMODDATE_PROP = QName.createQName(MIGRATION_MODEL_URI, "versionModifiedDate");

	public static final QName MIG_DOCORIVERCREBY_PROP = QName.createQName(MIGRATION_MODEL_URI, "versionCreatedBy");
	
	public static final QName MIG_DOCORIVERMODBY_PROP = QName.createQName(MIGRATION_MODEL_URI, "versionModifiedBy");

	public static final String PARAM_ORIGINAL_NODEREF = "alfNodeRef";
	
	public static final String PARAM_NODE_TYPE = "nodeType";
	
	public static final String PARAM_TARGET_NODE_REF = "targetNodeRef";

	public static final String PARAM_ACTION_NODE_REF = "actionNodeRef";
	
	public static final QName MIG_PROP_CISCO_NO_OF_DOWNLOADS = QName.createQName(CISCO_MODEL_NAMESPACE, "noOfDownloads");
	
	public static final QName MIG_IS_ROOT_FOLDER = QName.createQName(MIGRATION_MODEL_URI, "isRootFolder");
	
	public static final QName ASSOC_NAME_MYFAVORITE_ASSOCIATE = QName.createQName(CISCO_MODEL_NAMESPACE, "myFavorite");
	
	public static final QName ASPECT_MYFAVORITEDOCS = QName.createQName(CISCO_MODEL_NAMESPACE, "FavAspect");
	
	public static final String PARAM_MIMETYPE_STRING = "mimetype";
	
	public static final String PARAM_FILE_EXTENSION = "fileExtension";
	
	public MigPostScriptConstants() {
		super();
	}

}
