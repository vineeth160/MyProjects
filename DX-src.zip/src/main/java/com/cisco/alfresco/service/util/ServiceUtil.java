/**
 * 
 */
package com.cisco.alfresco.service.util;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.alfresco.repo.dictionary.constraint.ListOfValuesConstraint;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.dictionary.ConstraintDefinition;
import org.alfresco.service.cmr.dictionary.PropertyDefinition;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.QueryConsistency;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.AccessStatus;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.service.commons.ServiceConstants;

/**
 * @author kaudutta
 *
 */
public class ServiceUtil {
    private static Logger log = Logger.getRootLogger();
	private static DateFormat formatter = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL, Locale.US);
	private ServiceUtil(){}
	
	/**
	 * @author kaudutta returns a list of NodeRef object after passing a EDCS ID in String format (Hybrid and recommended)
	 * @param query
	 * @param registry
	 * @return
	 */
	public static NodeRef getNodeRef(String edcsId, ServiceRegistry registry) {
		NodeRef nodeRef = getNodeRefThroughIndex(edcsId.trim(), registry);
		log.error("\n Trying transactional query.");
		if (nodeRef == null){
			return getNodeRefTransactional(edcsId, registry);
		}
		return nodeRef;		
	}
	
	/**
	 * @author kaudutta returns a list of NodeRef object after passing a EDCS ID in String format (Using Index)
	 * @param query
	 * @param registry
	 * @return
	 */
	public static NodeRef getNodeRefThroughIndex(String edcsId, ServiceRegistry registry) {
		if (null==edcsId || edcsId.trim().equals("")){
			return null;
		}
		
		NodeRef nodeRef = forceSearchById(edcsId, registry);
		if(null == nodeRef){
			nodeRef = (NodeRef) registry.getAttributeService().getAttribute(edcsId);
			if(null==nodeRef){
				return null;
			}
			return nodeRef;
		}
		if(registry.getAttributeService().exists(edcsId)){
			registry.getAttributeService().removeAttribute(edcsId);
		}
		return nodeRef;
	}
	public static NodeRef getNodeRefThroughCustomIndex(String edcsId, ServiceRegistry registry) {
		if (null==edcsId || edcsId.trim().equals("")){
			return null;
		}
		NodeRef nodeRef = forceSearchByCiscoId(edcsId, registry);
		if(null == nodeRef){
			nodeRef = (NodeRef) registry.getAttributeService().getAttribute(edcsId);
			if(null==nodeRef){
				return null;
			}
		}
		if(registry.getAttributeService().exists(edcsId)){
			registry.getAttributeService().removeAttribute(edcsId);
		}
		return nodeRef;
	}
	/**
	 * @author kaudutta returns a list of NodeRef object after passing a EDCS ID in String format (Using Index)
	 * @param query
	 * @param registry
	 * @return
	 */
	private static NodeRef forceSearchById(final String edcsId, final ServiceRegistry registry) {
		return AuthenticationUtil.runAsSystem(new AuthenticationUtil.RunAsWork<NodeRef>() {
			@Override
			public NodeRef doWork() throws Exception {
				SearchParameters sp = new SearchParameters();
				sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
				sp.setLanguage(SearchService.LANGUAGE_LUCENE);
				sp.setQuery("@cs\\:alf_id:=" + edcsId.trim());
				ResultSet results = null;
				try {
					results = registry.getSearchService().query(sp);
					if(null == results || results.length()==0){
						log.error("Trying to fetch nodeRef by edcs ID, the following lucene query failed: \n"
								+ "@cs\\:alf_id:=" + edcsId.trim());						
						return null;
					}
					for (ResultSetRow row : results) {
						if(!registry.getCheckOutCheckInService().isWorkingCopy(row.getNodeRef()) && registry.getNodeService().getProperty(row.getNodeRef(),CiscoModelConstants.PROP_ALF_ID).equals(edcsId.trim())){
							return row.getNodeRef();
						}
					}
				} finally {
					if (null!=results) {
						results.close();
					}
				}
				return null;
			}
		});
	}	
	
	/**
	 * @author kaudutta returns a list of NodeRef object after passing a EDCS ID in String format (Using Index)
	 * @param query
	 * @param registry
	 * @return
	 */
	public static NodeRef forceSearch(final String query, final ServiceRegistry registry) {
		return AuthenticationUtil.runAsSystem(new AuthenticationUtil.RunAsWork<NodeRef>() {
			@Override
			public NodeRef doWork() throws Exception {
				SearchParameters sp = new SearchParameters();
				sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
				sp.setLanguage(SearchService.LANGUAGE_LUCENE);
				sp.setQuery(query);
				ResultSet results = null;
				try {
					results = registry.getSearchService().query(sp);
					if(null == results || results.length()==0 || results.length()>2 ){
						log.error("Trying to fetch nodeRef, the following lucene query failed: \n"
								+ query);						
						return null;
					}
					for (ResultSetRow row : results) {
						if(!registry.getCheckOutCheckInService().isWorkingCopy(row.getNodeRef())){
							return row.getNodeRef();
						}
					}
				} finally {
					if (null!=results) {
						results.close();
					}
				}
				return null;
			}
		});
	}	
	
	/**
	 * @author kaudutta returns a list of NodeRef object after passing a EDCS ID in String format (Using CMIS)
	 * @param query
	 * @param registry
	 * @return
	 */
	public static NodeRef getNodeRefTransactional(String edcsId, ServiceRegistry registry) {
		SearchParameters sp = new SearchParameters();
		sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
		sp.setLanguage(SearchService.LANGUAGE_CMIS_ALFRESCO);
        sp.setQueryConsistency(QueryConsistency.TRANSACTIONAL);            
        String query= "SELECT D.alfcmis:nodeRef, O.* FROM cs:ciscodoc AS D JOIN cs:ciscoMetaData AS O ON D.cmis:objectId = O.cmis:objectId where O.cs:alf_id = '"+ edcsId.trim() +"' ";
		sp.setQuery(query);
		ResultSet results = null;
		try {
			results = registry.getSearchService().query(sp);
			if (null == results || results.length() <= 0){
				log.error("\nFailed transaction query:\n" + query);
				return null;
			}
			for (ResultSetRow row : results) {
				if(!registry.getCheckOutCheckInService().isWorkingCopy(row.getNodeRef())){
					return row.getNodeRef();
				}
			}
		} catch(Exception e){
			log.error(formatter.format(new Date()) + "- Error from com.cisco.alfresco.service.util.ServiceUtil.java [get noderef from EDCS ID]. Error definition:: " + e.fillInStackTrace() +"\n StackTrace as follows: \n");
			log.error(ExceptionUtils.getFullStackTrace(e));
			return null;
		}finally {
			if (null!=results) {
				results.close();
			}
		}
		return null;
	}
	
	public static NodeRef doSearch(String query, ServiceRegistry registry) {
		NodeRef nodeRef = forceSearch(query, registry);
		return registry.getPermissionService().hasPermission(nodeRef, PermissionService.READ).equals(AccessStatus.ALLOWED)?nodeRef:null;
	}
	
	/**
	 * @author kaudutta returns a Object of NodeRef/Boolean after passing a CiscoDocs ID in String format (Hybrid and recommended)
	 * @param edcsId
	 * @param registry
	 * @return
	 */
	public static NodeRef getNodeRefFromCiscoDocID(String edcsId, ServiceRegistry registry) {
		NodeRef nodeRef = getNodeRefThroughCustomIndex(edcsId.trim(), registry);
		log.error("\n Trying transactional query.");
		if (nodeRef == null){
			return getNodeRefByCiscoDocIDTransactional(edcsId, registry);
		}
		return nodeRef;		
	}
	
	/**
	 * @author kaudutta returns a list of NodeRef object after passing a CISCODOCS ID in String format (Using CMIS)
	 * @param query
	 * @param registry
	 * @return
	 */
	public static NodeRef getNodeRefByCiscoDocIDTransactional(String edcsId, ServiceRegistry registry) {
		SearchParameters sp = new SearchParameters();
		sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
		sp.setLanguage(SearchService.LANGUAGE_CMIS_ALFRESCO);
        sp.setQueryConsistency(QueryConsistency.TRANSACTIONAL);            
        String query= "SELECT D.alfcmis:nodeRef, O.* FROM cs:ciscodoc AS D JOIN mg:migration AS O ON D.cmis:objectId = O.cmis:objectId where O.mg:oldUrl = '"+ edcsId.trim() +"' ";
		sp.setQuery(query);
		ResultSet results = null;
		try {
			results = registry.getSearchService().query(sp);
			if (null == results || results.length() <= 0){
				log.error("\nFailed transaction query:\n" + query);				
				return null;
			}
			for (ResultSetRow row : results) {
				if(!registry.getCheckOutCheckInService().isWorkingCopy(row.getNodeRef())){
					return row.getNodeRef();
				}
			}
		} catch(Exception e){
			log.error(formatter.format(new Date()) + "- Error from com.cisco.alfresco.service.util.ServiceUtil.java [get noderef from CiscoDocs ID]. Error definition:: " + e.fillInStackTrace() +"\n StackTrace as follows: \n");
			log.error(ExceptionUtils.getFullStackTrace(e));
			return null;
		}finally {
			if (null!=results) {
				results.close();
			}
		}
		return null;
	}
	
	

	/**
	 * @author kaudutta returns a list of NodeRef object after passing a lucene
	 *         query in String format
	 * @param query
	 * @param registry
	 * @return
	 */
	public static List<NodeRef> getNodeRefList(String query,
			ServiceRegistry registry) {
		List<NodeRef> arrNodeRef = null;
		SearchParameters sp = new SearchParameters();
		sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
		sp.setLanguage(SearchService.LANGUAGE_LUCENE);
		sp.setQuery(query);
		ResultSet results = registry.getSearchService().query(sp);
		if (null == results || results.length() <= 0){
			log.error("Trying to fetch nodeRef, the following lucene query failed: \n"
					+ query);	
			return null;
		}
		arrNodeRef = new ArrayList<NodeRef>();
		for (ResultSetRow row : results) {
			arrNodeRef.add(row.getNodeRef());
		}
		results.close();
		return arrNodeRef;
	}

	public static boolean isValidId(final String userId, final String edcsId, final ServiceRegistry registry) {
		return AuthenticationUtil.runAsSystem(new AuthenticationUtil.RunAsWork<Boolean>() {
			@SuppressWarnings("unchecked")
			@Override
			public Boolean doWork() throws Exception {
				if(!edcsId.startsWith("EDCSX-")){
					return false;
				}
				if (null!= getNodeRefThroughIndex(edcsId, registry)){
					return false;
				}
				String id = edcsId.substring(edcsId.indexOf("EDCSX-")+5);
				String KEY_USERID_DOCNUMBER = "_docnumbers";
				try {
					if (null != ServiceUtil.getNodeRefThroughIndex(edcsId, registry)){
						return false;
					}
					if(!(registry.getAttributeService().exists(userId+KEY_USERID_DOCNUMBER))){
						return false;
					}
					return Arrays.asList((((HashMap<String, String>) registry.getAttributeService().getAttribute(userId+KEY_USERID_DOCNUMBER)).get(userId)).split(",")).contains(id);
				} catch (Exception e) {
					return false;
				}
			}
		});
	}
	
	/**
	 * @author harschau returns a Object of NodeRef/Boolean after passing a Object_d(mg:old_url) in String format 
	 * @param edcsId
	 * @param registry
	 * @return
	 */
	private static NodeRef forceSearchByCiscoId(final String edcsId, final ServiceRegistry registry) {
		return AuthenticationUtil.runAsSystem(new AuthenticationUtil.RunAsWork<NodeRef>() {
			
			@Override
			public NodeRef doWork() throws Exception {
				SearchParameters sp = new SearchParameters();
				sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
				sp.setLanguage(SearchService.LANGUAGE_FTS_ALFRESCO);
				sp.setQuery("@mg\\:oldUrl:" + edcsId.trim());
				ResultSet results = null;
				try {
					results = registry.getSearchService().query(sp);
					if(null == results || results.length()==0){
						log.error("Trying to fetch nodeRef by old URL, the following lucene query failed: \n"
								+ "@mg\\:oldUrl:" + edcsId.trim());							
						return null;
					}
					for (ResultSetRow row : results) {
						if(!registry.getCheckOutCheckInService().isWorkingCopy(row.getNodeRef()) && registry.getNodeService().getProperty(row.getNodeRef(),CiscoModelConstants.MIGRATION_OLD_URL).equals(edcsId.trim())){
							return row.getNodeRef();
						}
					}
				} finally {
					if (null!=results) {
						results.close();
					}
				}
				return null;
			}
		});
	}	
	
	/**
	 * @author kaudutta returns a list of NodeRef object after passing a lucene
	 *         query in String format
	 * @param query
	 * @param registry
	 * @return
	 */
	public static List<NodeRef> getNodeRefListPagination(String query,
			ServiceRegistry registry, int maxResult, int skipCount) {
		List<NodeRef> arrNodeRef = null;
		SearchParameters sp = new SearchParameters();
		sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
		sp.setLanguage(SearchService.LANGUAGE_LUCENE);
		sp.setQuery(query);
		sp.setMaxItems(maxResult);
		sp.setSkipCount(skipCount);
		ResultSet results = registry.getSearchService().query(sp);
		if (null == results || results.length() <= 0){
			log.error("Trying to fetch nodeRef, the following lucene query failed: \n"
					+ query);				
			return null;
		}
		arrNodeRef = new ArrayList<NodeRef>();
		for (ResultSetRow row : results) {
			arrNodeRef.add(row.getNodeRef());
		}
		results.close();
		return arrNodeRef;
	}
	//Added by veerai for US9408 - start
	public static JSONObject getInvalidMetadataProperties(final JSONObject metadataJsonObject,ServiceRegistry registry) {
		Map<String, QName> multiValueQNameMap = new HashMap<String, QName>();
		multiValueQNameMap.put("docType", CiscoModelConstants.CISCO_DOC_TYPE_PROP);
		multiValueQNameMap.put("securityLevel", CiscoModelConstants.CISCO_SECURITY_PROP);
		multiValueQNameMap.put("theatre", CiscoModelConstants.CISCO_THEATRE_PROP);
		multiValueQNameMap.put("status", CiscoModelConstants.CISCO_DOC_STATUS);
		JSONObject invalidPropertyList = new JSONObject();
		for (Map.Entry<String, QName> qNameEntry : multiValueQNameMap.entrySet()) {
			ListOfValuesConstraint lovConstraint = null;
			QName qName = qNameEntry.getValue();
			String propertyName =qNameEntry.getKey();
			PropertyDefinition propertyDef = registry.getDictionaryService().getProperty(qName);
			List<ConstraintDefinition> constraints = propertyDef.getConstraints();
			for (ConstraintDefinition constraintDefinition : constraints) {
				if (constraintDefinition.getConstraint() instanceof ListOfValuesConstraint) {
					lovConstraint = (ListOfValuesConstraint) constraintDefinition.getConstraint();
					List<String> allowedValues = lovConstraint.getAllowedValues();
					if(metadataJsonObject.has(propertyName)){
						try {
							JSONArray metadataMltifieldJSONArray = null;
							JSONArray invalidPropertyValues = new JSONArray();
							if (metadataJsonObject.get(propertyName) instanceof JSONArray) {
								metadataMltifieldJSONArray = (JSONArray) metadataJsonObject.get(propertyName);
								for (int i = 0; i < metadataMltifieldJSONArray.length(); i++) {
									if (!allowedValues.contains(metadataMltifieldJSONArray.getString(i).trim()))
										invalidPropertyValues.put(metadataMltifieldJSONArray.getString(i).trim());								
								}
								if (invalidPropertyValues.length() > 0)
									invalidPropertyList.put(propertyName, invalidPropertyValues);
							}else if(metadataJsonObject.get(propertyName) instanceof String){
								if (!" ".equals(metadataJsonObject.get(propertyName).toString()) && !allowedValues.contains(metadataJsonObject.get(propertyName).toString().trim()))
									invalidPropertyList.put(propertyName, metadataJsonObject.get(propertyName).toString());
							}
						} catch (JSONException e) {
							log.error(formatter.format(new Date()) + "  :: JSONException while Checking Invalid metadata in multi-field");
							e.printStackTrace();
						}
					}
				}
			}
		}
		return invalidPropertyList;
	}
	
	public static JSONArray getInvalidPermission(JSONArray authorityJsonArray,ServiceRegistry registry) throws JSONException{
		JSONArray jsonArray =  new JSONArray();
		if (null!= authorityJsonArray && authorityJsonArray.length()>0){
			for(int i = 0 ; i< authorityJsonArray.length(); i++){
				JSONArray permissionJsonArray = ((JSONObject) authorityJsonArray.get(i)).getJSONArray("permissions");
				for(int j = 0 ; j< permissionJsonArray.length(); j++){
				JSONObject permissionJsonObject = (JSONObject) permissionJsonArray.get(j);
					if(!registry.getAuthorityService().authorityExists(permissionJsonObject.getString("authority")) || 
							null == ServiceConstants.PERMISSION_MAP.get(permissionJsonObject.getString("permission").toLowerCase())){
						jsonArray.put(permissionJsonObject);
					}
				}
			}
		}
		return jsonArray;
	}
	
	public static JSONArray getCustomInvalidPermission(JSONArray permissionJsonArray,ServiceRegistry registry) throws JSONException{
		JSONArray jsonArray =  new JSONArray();
		if (null!= permissionJsonArray && permissionJsonArray.length()>0){
			for(int i = 0 ; i< permissionJsonArray.length(); i++){
				JSONObject permissionJsonObject = (JSONObject) permissionJsonArray.get(i);
					if(!registry.getAuthorityService().authorityExists(permissionJsonObject.getString("authority")) || 
							null == ServiceConstants.PERMISSION_MAP.get(permissionJsonObject.getString("permission").toLowerCase())){
						jsonArray.put(permissionJsonObject);
					}
			}
		}
		return jsonArray;
	}
	
	public static JSONArray getInvalidAspects(String[] arrAspects, ServiceRegistry registry) {
		Set<QName> setAspects = new HashSet<>(registry.getDictionaryService().getAllAspects());
		Set<String> aspectsLocalName = new HashSet<String>();
		for (QName aspect : setAspects)
			aspectsLocalName.add(aspect.getLocalName().trim());
		JSONArray jsonArray = new JSONArray();
		for (String aspectName : arrAspects) {
			if (!aspectsLocalName.contains(aspectName.trim()))
				jsonArray.put(aspectName);
		}
		return jsonArray;
	}

}