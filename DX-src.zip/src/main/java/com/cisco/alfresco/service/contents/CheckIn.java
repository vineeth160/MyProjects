/**
 * 
 */
package com.cisco.alfresco.service.contents;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.transaction.RetryingTransactionHelper;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;
import org.springframework.extensions.webscripts.servlet.FormData;

import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.service.constants.ErrorStatus;
import com.cisco.vera.utils.VeraProtectionUtil;

/**
 * @author kaudutta
 *
 */
public class CheckIn extends AbstractWebScript {

	private ServiceRegistry registry;

	protected VeraProtectionUtil veraProtectionUtil;
	
	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}
	/**
     * @param veraProtectionUtil VeraProtectionUtil
     */
    public VeraProtectionUtil getVeraProtectionUtil() {
		return veraProtectionUtil;
	}
    
    public void setVeraProtectionUtil(VeraProtectionUtil veraProtectionUtil) {
		this.veraProtectionUtil = veraProtectionUtil;
    }
	private static Logger log = Logger.getLogger(CheckIn.class);
	private DateFormat formatter = DateFormat.getDateTimeInstance(
			DateFormat.FULL, DateFormat.FULL, Locale.US);

	private static SimpleDateFormat sdt = new SimpleDateFormat(
			"MM-dd-yyyy_hh-mm-ss-S-a-zzz");
	
	private static final String WORKSPACE_VERSIONSTORE ="workspace://version2Store/";

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res)
			throws IOException {
		JSONObject responseObject = new JSONObject();
		FormData formData = (FormData) req.parseContent();
		FormData.FormField[] fields = formData.getFields();
		String mimetype = null;
		InputStream in = null;
		String nodeRefString = req.getParameter("nodeRef");
		log.info(formatter.format(new Date())
				+ "  :: Check in called for noderef/versionref/PATH:: "
				+ nodeRefString);
		if (nodeRefString == null || "".equals(nodeRefString)) {
			log.error(formatter.format(new Date())
					+ "  :: Invalid noderef for checkin:: " + nodeRefString);
			res.setStatus(ErrorStatus.STATUS_CODE_NULL_NODEREF);
			try {
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject
						.put("error", ErrorStatus.STATUS_MSG_NULL_NODEREF);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			} catch (JSONException e) {
				e.printStackTrace();
				return;
			}
		}

		JSONObject jsonObject = null;
		String metadata = null;
		try {
			metadata = req.getParameter("metadata").trim();
		} catch (Exception e) {
			metadata = null;
		}
		log.info("METADATA:: " + metadata);
		try {
			if (null != metadata) {
				jsonObject = new JSONObject(metadata);
			}
		} catch (JSONException e2) {
			try {
				log.error(formatter.format(new Date())
						+ "  :: Invalid metadata format for checkin:: "
						+ nodeRefString);
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("error", "Malformed metadata JSON object.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			} catch (JSONException e1) {
				e1.printStackTrace();
				return;
			}
		}

		NodeRef nodeRef = null;
		String currentLoginUserName = registry.getAuthenticationService().getCurrentUserName();
		try {
			nodeRef = new NodeRef(nodeRefString);
			log.info(formatter.format(new Date())
					+ ":: Check in : NODEEXISTS?? "
					+ registry.getNodeService().exists(nodeRef));
			if (!registry.getNodeService().exists(nodeRef)) {
				log.error(formatter.format(new Date())
						+ ":: Check in error: Node doesn't exist.");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("error",
						ErrorStatus.STATUS_MSG_INVALID_NODEREF);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}

		} catch (Exception e) {
			log.error(formatter.format(new Date())
					+ "  :: Invalid/deleted noderef for checkin:: "
					+ nodeRefString);

			res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
			try {
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("error",
						ErrorStatus.STATUS_MSG_INVALID_NODEREF);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			} catch (JSONException e1) {
				e1.printStackTrace();
				return;
			}
		}
		
		if(registry.getFileFolderService().getFileInfo(nodeRef).isFolder()){
			log.error(formatter.format(new Date()) + "  :: Check in: invalid noderef:: " + nodeRefString);
			res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
			res.getWriter().write("Can not perform check in on a folder.");			
			res.getWriter().close();
			return;
			
		}

		if (nodeRefString.indexOf("version") >= 0) {
			nodeRef = registry.getVersionService().getCurrentVersion(nodeRef)
					.getVersionedNodeRef();
			log.info(formatter.format(new Date())
					+ "  :: Check in -current NodeRef:: " + nodeRef);

		}
		
		String versionRef = registry.getVersionService().getCurrentVersion(nodeRef).getFrozenStateNodeRef().toString();
		if (!registry.getCheckOutCheckInService().isCheckedOut(nodeRef)) {
			log.error(formatter.format(new Date())
					+ "  :: Check in -current NodeRef not checked out:: "
					+ nodeRef);
			res.setStatus(ErrorStatus.STATUS_CODE_INVALID_CANCEL_CHECKOUT);
			try {
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("error",
						ErrorStatus.STATUS_MSG_INVALID_CANCEL_CHECKOUT);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			} catch (JSONException e) {
				e.printStackTrace();
				return;
			}

		}
		String fileName = null;
		boolean isVeraProtectedDoc=false;
		if (null != metadata) {
			try {
				fileName = (String) jsonObject.get("fileName");
				for (FormData.FormField field : fields) {
					if (field.getName().equals("file") && field.getIsFile()) {
						//Added by prbadam and nathammi for check-in
						boolean isVeraEncryptedDoc=veraProtectionUtil.isVeraEncryptedDoc(getFileContentAsStream(fields));
						log.info(formatter.format(new Date()) + "  :: CheckIn : isVeraEncryptedDoc:: "
								+ isVeraEncryptedDoc);
						if (isVeraEncryptedDoc) {
							try {
								if(fileName.substring(fileName.lastIndexOf('.')+1).equals("html")){
								int index = fileName.lastIndexOf(".");
					            fileName = fileName.substring(0, index != -1 ? index : fileName.length());
								}
								log.info("CheckIn originalFileName ::: "+fileName);
								String veraDocId = veraProtectionUtil.getVeraAppDocId(getFileContentAsStream(fields),currentLoginUserName);
								log.info("veraDocId :: "+veraDocId);
								if(!veraProtectionUtil.checkUserAccess(getFileContentAsStream(fields),currentLoginUserName,veraDocId)){
									log.error(formatter.format(new Date()) + "  :: Check in: You don't have premissions on vara secured document:: ");
									res.setStatus(ErrorStatus.STATUS_CODE_INVALID_PERMISSION);
									responseObject.put("versionRef", "");
									responseObject.put("versionLabel", "");
									responseObject.put("message", "");
									responseObject.put("error",
											ErrorStatus.STATUS_MSG_INVALID_PERMISSION);
									res.getWriter().write(responseObject.toString());
									res.setContentType("application/json");
									res.getWriter().close();
									return;
								}
								in = veraProtectionUtil.getVeraFileContentAsStream(getFileContentAsStream(fields),currentLoginUserName,veraDocId);
								isVeraProtectedDoc=true;
					            int mimetypeIndex = fileName.lastIndexOf(".");
					            mimetype = fileName.substring(mimetypeIndex + 1);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
				            }
				            else {
				              mimetype = field.getMimetype();
				              in = field.getInputStream();
				              fileName = field.getFilename();
				            }
					}
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			
			for (FormData.FormField field : fields) {
				if (field.getName().equals("file") && field.getIsFile()) {
					//Added by prbadam and nathammi for US10830
					boolean isVeraEncryptedDoc=veraProtectionUtil.isVeraEncryptedDoc(getFileContentAsStream(fields));
					log.info(formatter.format(new Date()) + "  :: CheckIn : isVeraEncryptedDoc:: "
							+ isVeraEncryptedDoc);
					if (isVeraEncryptedDoc) {
						try {
							fileName = field.getFilename();
							if(fileName.substring(fileName.lastIndexOf('.')+1).equals("html")){
								int index = fileName.lastIndexOf(".");
					            fileName = fileName.substring(0, index != -1 ? index : fileName.length());
								}
							log.info("CheckIn originalFileName ::: "+fileName);
							String veraDocId = veraProtectionUtil.getVeraAppDocId(getFileContentAsStream(fields),currentLoginUserName);
							if(!veraProtectionUtil.checkUserAccess(getFileContentAsStream(fields),currentLoginUserName,veraDocId)){
								log.error(formatter.format(new Date()) + "  :: Check in: You don't have premissions on vara secured document:: ");
								res.setStatus(ErrorStatus.STATUS_CODE_INVALID_PERMISSION);
								responseObject.put("versionRef", "");
								responseObject.put("versionLabel", "");
								responseObject.put("message", "");
								responseObject.put("error",
										ErrorStatus.STATUS_MSG_INVALID_PERMISSION);
								res.getWriter().write(responseObject.toString());
								res.setContentType("application/json");
								res.getWriter().close();
								return;
							}
				            in = veraProtectionUtil.getVeraFileContentAsStream(getFileContentAsStream(fields),currentLoginUserName,veraDocId);
				            isVeraProtectedDoc=true;
				            int mimetypeIndex = fileName.lastIndexOf(".");
				            mimetype = fileName.substring(mimetypeIndex + 1);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			            }
			            else {
			              mimetype = field.getMimetype();
			              in = field.getInputStream();
			              fileName = field.getFilename();
			            }
				}
			}
		}

		responseObject = checkIn(registry, nodeRef, registry.getNodeService()
				.getPrimaryParent(nodeRef).getParentRef(), in, fileName,
				mimetype,isVeraProtectedDoc);

		try {
			if (responseObject.getString("versionRef").equals("")) {
				res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
				res.setContentType("application/json");
				res.getWriter().write(responseObject.toString());
				res.getWriter().close();
				return;
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String versionUUID =  versionRef.substring(versionRef.lastIndexOf("/") +1 );
		String versionStoreStr = registry.getVersionService().getVersionStoreReference()+ "/" + versionUUID;
		registry.getNodeService().removeAspect(new NodeRef(versionStoreStr), ContentModel.ASPECT_CHECKED_OUT);
		registry.getNodeService().removeAspect(new NodeRef(versionStoreStr), ContentModel.ASPECT_LOCKABLE);

		res.setContentType("application/json");
		res.getWriter().write(responseObject.toString());
		res.getWriter().close();

	}

	private JSONObject checkIn(final ServiceRegistry registry,
			final NodeRef nodeRef, final NodeRef parentRef,
			final InputStream in, final String fileName, final String mimetype,final boolean isVeraProtectedDoc) {
		return registry
				.getTransactionService()
				.getRetryingTransactionHelper()
				.doInTransaction(
						new RetryingTransactionHelper.RetryingTransactionCallback<JSONObject>() {
							public JSONObject execute() throws Throwable {
								JSONObject responseObject = new JSONObject();
								log.debug(formatter.format(new Date())
										+ "  :: Check In: Executing transaction. File Name: "
										+ fileName);
								Map<QName, Serializable> propMap = new HashMap<QName, Serializable>();
								NodeRef newNodeRef = null;
								try {
									newNodeRef = registry
											.getCheckOutCheckInService()
											.checkin(
													registry.getCheckOutCheckInService()
															.getWorkingCopy(
																	nodeRef),
													null);
									ContentWriter writer = registry
											.getContentService().getWriter(
													nodeRef,
													ContentModel.TYPE_CONTENT,
													true);
									writer.setMimetype(mimetype);
									writer.putContent(in);
									String newFileName = fileName;
									NodeRef tempNodeRef = registry
											.getNodeService()
											.getChildByName(
													registry.getNodeService()
															.getPrimaryParent(
																	nodeRef)
															.getParentRef(),
													ContentModel.ASSOC_CONTAINS,
													fileName);
									if (null != tempNodeRef && !String.valueOf(tempNodeRef).equals(String.valueOf(nodeRef))) {
										if (fileName.lastIndexOf(".") > 0) {
											String extensionString = fileName
													.substring(fileName
															.lastIndexOf("."));
											newFileName = fileName.substring(0,
													fileName.lastIndexOf("."))
													+ "-"
													+ sdt.format(new Date())
													+ extensionString;
										} else {
											newFileName = fileName.substring(0,
													fileName.lastIndexOf("."))
													+ "-"
													+ sdt.format(new Date());
										}
										log.debug(formatter.format(new Date())
												+ "  Check In: FINAL FILE NAME:::: "
												+ newFileName);
									}
									log.debug(formatter.format(new Date())
											+ "  :: Check In:Final File name:: "
											+ newFileName);
									registry.getFileFolderService().rename(
											newNodeRef, newFileName);
									propMap.put(ContentModel.PROP_MODIFIER,
											registry.getAuthenticationService()
													.getCurrentUserName());
									propMap.put(ContentModel.PROP_NAME,
											newFileName);
									registry.getVersionService()
											.ensureVersioningEnabled(
													newNodeRef, propMap);
									registry.getVersionService().createVersion(
											newNodeRef, null);
									registry.getNodeService().setProperty(
											newNodeRef, ContentModel.PROP_NAME,
											newFileName);
									if((registry.getNodeService().exists(nodeRef)) && isVeraProtectedDoc){
										applyVeraProtectionOnDoc(nodeRef);
										VersionHistory versionHistory = registry.getVersionService()
												.getVersionHistory(nodeRef);
										if (null != versionHistory) {
											for (Version versionId : versionHistory.getAllVersions()) {
												NodeRef versionNodeRefId = new NodeRef(WORKSPACE_VERSIONSTORE
														+ versionId.getFrozenStateNodeRef().getId());
												applyVeraProtectionOnDoc(versionNodeRefId);
											}
										}
									}
									responseObject.put("versionRef", registry
											.getVersionService()
											.getCurrentVersion(newNodeRef)
											.getFrozenStateNodeRef());
									responseObject.put("versionLabel", registry
											.getVersionService()
											.getCurrentVersion(newNodeRef)
											.getVersionLabel());
									responseObject.put("message",
											"Successfully checked in.");
									responseObject.put("error", "");
									return responseObject;
								} catch (JSONException e) {
									log.error("Error from "
											+ this.getClass()
													.getCanonicalName()
											+ ":: \n" + e.fillInStackTrace());
									e.printStackTrace();
									try {
										responseObject.put("versionRef", "");
										responseObject.put("versionLabel", "");
										responseObject.put("message", "");
										responseObject.put("error",
												ErrorStatus.STATUS_MSG_FAILURE);
										return responseObject;
									} catch (JSONException e1) {
										e1.printStackTrace();
										return null;
									}
								} catch (Exception e) {
									log.error(formatter.format(new Date())
											+ "  :: Error while Checking In:: \n"
											+ e.fillInStackTrace());
									e.printStackTrace();
									responseObject.put("versionRef", "");
									responseObject.put("versionLabel", "");
									responseObject.put("message", "");
									responseObject.put("error",
											ErrorStatus.STATUS_MSG_FAILURE);
									return responseObject;
								}

							}

						}, false, true);
	}
	
	private InputStream getFileContentAsStream(final FormData.FormField[] fields){
		InputStream instrm = null;
		for (FormData.FormField field : fields) {
			if (field.getName().equals("file") && field.getIsFile()) {
				instrm = field.getInputStream();
			}
		}
		return instrm;
	}
	
	private void applyVeraProtectionOnDoc(NodeRef sourceNodeRef){
		if(registry.getNodeService().hasAspect(sourceNodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION)){
			registry.getNodeService().setProperty(sourceNodeRef, ExternalSharingConstants.PROP_IS_DOCUMENT_VERA_PROTECTED, true);
		}else{
			Map<QName, Serializable> verDocumentProtectionProps = new HashMap<>(1);
			verDocumentProtectionProps.put(ExternalSharingConstants.PROP_IS_DOCUMENT_VERA_PROTECTED, true);
			registry.getNodeService().addAspect(sourceNodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION, verDocumentProtectionProps);
		}
	}
}
