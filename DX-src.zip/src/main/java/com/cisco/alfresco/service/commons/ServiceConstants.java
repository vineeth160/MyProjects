/**
 * 
 */
package com.cisco.alfresco.service.commons;

import java.util.HashMap;
import java.util.Map;

import org.alfresco.service.namespace.QName;

/**
 * @author kaudutta
 *
 */
public class ServiceConstants {
	
	public static final Map<String, String> PERMISSION_MAP = new HashMap<String, String>();
	static {
		PERMISSION_MAP.put("folder admin", "AdminRole");
		PERMISSION_MAP.put("owner", "OwnerRole");
		PERMISSION_MAP.put("editor", "EditorRole");
		PERMISSION_MAP.put("workflow editor", "WorkflowEditorRole");
		PERMISSION_MAP.put("reader", "ReaderRole");
		PERMISSION_MAP.put("viewer", "ViewerRole");
		PERMISSION_MAP.put("user", "UserRole");
	}
	//added by skorutla for DE4854
	public static final String READER = "Reader";
	public static final String EDITOR = "Editor";
	public static final String VIEWER ="Viewer";
	public static final String FOLDER_ADMIN = "Folder Admin";
	//end by skorutla for DE4854	
	public static final String CISCO_MODEL_URI = "http://www.cisco.com/model/content/1.0";
	public static final String CONTENT_MODEL_URI = "http://www.alfresco.org/model/content/1.0";
	public static final QName TYPE_CISCODOCS = QName.createQName(CISCO_MODEL_URI, "ciscodoc");
	public static final QName TYPE_CONTENT = QName.createQName(CONTENT_MODEL_URI, "content");
	public static final QName ASPECT_CISCOMETADATA= QName.createQNameWithValidLocalName(CISCO_MODEL_URI, "ciscoMetaData");
	//added by skorutla for DE4266
	public static final String Cisco_Corporate_Document = "Cisco Corporate Document";
	public static final String Cisco_Engineering_Document = "Cisco Engineering Document";
	public static final String Cisco_Finance_Document = "Cisco Finance Document";
	public static final String Cisco_General_Document = "Cisco General Document";
	public static final String Cisco_HR_Document = "Cisco HR Document";
	public static final String Cisco_IT_Document = "Cisco IT Document";
	public static final String Cisco_Marketing_Document = "Cisco Marketing Document";
	public static final String Cisco_Legal_Document = "Cisco Legal Document";
	public static final String Cisco_Operations_Document = "Cisco Operations Document";
	public static final String Cisco_Sales_Document = "Cisco Sales Document";
	public static final String Cisco_Services_Document  = "Cisco Services Document";
   //end by skorutla for DE4266
   //added by skorutla for DE4915
	public static final String N_A = "N/A";
	public static final String AMERICAS = "Americas";
	public static final String APAC_JAPAN_CHINA = "APAC/Japan/China";
	public static final String EMEA = "EMEA";
	public static final String EMERGING = "Emerging";
	public static final String GLOBAL_ENTERPRISE = "Global Enterprise";
	//end by skorutla for DE4915
	//added by skorutla for 4916
	public static final String CISCO_RESTRICTED = "Cisco Restricted";
	public static final String CISCO_HIGHLY_CONFIDENTIAL = "Cisco Highly Confidential";
	public static final String CISCO_CONFIDENTIAL = "Cisco Confidential";	
	public static final String CISCO_PUBLIC = "Cisco Public";
	//end by skorutla for DE4916
	//added by skorutla for 4914
	public static final String APPROVAL_N_A= "Approval.N.A";
	public static final String DRAFT= "Draft";
	//end by skorutla for DE4914
     
}
