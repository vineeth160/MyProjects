package com.cisco.alfresco.service.contents;

import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.JSONException;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.service.commons.ServiceConstants;
import com.cisco.alfresco.service.constants.ErrorStatus;
import com.cisco.vera.utils.VeraProtectionUtil;

public class CheckOut extends AbstractWebScript {
	protected ServiceRegistry registry;
	protected VeraProtectionUtil veraProtectionUtil;
	private String searchUser;
	
	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}
	
	/**
     * @param veraProtectionUtil VeraProtectionUtil
     */
    public VeraProtectionUtil getVeraProtectionUtil() {
		return veraProtectionUtil;
	}
    
    public void setVeraProtectionUtil(VeraProtectionUtil veraProtectionUtil) {
		this.veraProtectionUtil = veraProtectionUtil;
	}

	public String getSearchUser() {
		return searchUser;
	}

	public void setSearchUser(String searchUser) {
		this.searchUser = searchUser;
	}

    
	final Logger log = Logger.getRootLogger();
	private DateFormat formatter = DateFormat.getDateTimeInstance( DateFormat.FULL, 
            DateFormat.FULL, 
            Locale.US);

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res)
			throws IOException {
		String nodeRefString = req.getParameter("nodeRef");
		String doDownload = req.getParameter("download");
		if (null != doDownload){
			doDownload = doDownload.trim().toLowerCase();
		}
		log.info(formatter.format(new Date()) + "  :: Check out called for noderef/versionref/PATH:: " + nodeRefString);
		
		NodeRef nodeRef = null;
		boolean isCheckout = false;
		if (null == nodeRefString || "".equals(nodeRefString.trim())) {
			res.setStatus(ErrorStatus.STATUS_CODE_NULL_NODEREF);
			res.getWriter().write(ErrorStatus.STATUS_MSG_NULL_NODEREF);
			res.getWriter().close();
			return;
		}

		try {
			nodeRef = new NodeRef(nodeRefString);
			if (!registry.getNodeService().exists(nodeRef)){
				log.error(formatter.format(new Date()) + "  :: Check out: noderef does not exist:: " + nodeRefString);
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				res.getWriter().write(ErrorStatus.STATUS_MSG_INVALID_NODEREF);
				res.getWriter().close();
				return;
			}

		} catch (Exception e) {
			log.error(formatter.format(new Date()) + "  :: Check out: invalid noderef:: " + nodeRefString);
			res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
			res.getWriter().write(ErrorStatus.STATUS_MSG_INVALID_NODEREF);
			res.getWriter().close();
			return;
		}
		
		if(registry.getFileFolderService().getFileInfo(nodeRef).isFolder()){
			log.error(formatter.format(new Date()) + "  :: Check out: invalid noderef:: " + nodeRefString);
			res.setStatus(ErrorStatus.STATUS_CODE_INVALID_CHECKOUT_NODE);
			res.getWriter().write(ErrorStatus.STATUS_MSG_INVALID_CHECKOUT_NODE);			
			res.getWriter().close();
			return;
			
		}
		
		if(nodeRefString.indexOf("version")>=0){
			//added by skorutla for DE4703
			String CurrentVerionRef = registry.getVersionService().getVersionHistory(nodeRef).getHeadVersion().getFrozenStateNodeRef().toString();
			log.error("Latest VerionRef::"+CurrentVerionRef);
			if(!(CurrentVerionRef).equalsIgnoreCase(nodeRefString)){
				JSONObject responseObject = new JSONObject();
				log.error("Old verionRef ::"+nodeRefString);
				log.error(formatter.format(new Date()) + "  :: Check out: invalid versionRef:: " + nodeRefString);
				try {
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_CHECKOUT_NODE);
					responseObject.put("error","Checkout should perform on latest versionRef only.");
					res.getWriter().write(responseObject.toString());
					res.setContentType("application/json");
					res.getWriter().close();
					return;
				} catch (JSONException e) {
					e.printStackTrace();
				}
				
			}//end by skorutla for DE4703
			nodeRef = registry.getVersionService().getCurrentVersion(nodeRef).getVersionedNodeRef();
		}
		log.debug(formatter.format(new Date()) + "  :: Check out: Actual noderef:: " + nodeRef);

		isCheckout = registry.getCheckOutCheckInService().isCheckedOut(
				nodeRef);
		log.debug(formatter.format(new Date()) + "  :: Check out: noderef checked out? " + isCheckout);

		if (!isCheckout) {
			try {
				registry.getCheckOutCheckInService().checkout(nodeRef);
				if(null!= doDownload && doDownload.equals("false")){
					res.setStatus(200);
					res.getWriter().write("File checked out successfully.");
					res.getWriter().close();
					log.info(formatter.format(new Date()) + "  :: Check out successful for " + nodeRefString);
					return;
					
				}
				String userAgent = req.getHeader("user-agent");
				boolean isInternetExplorer = (userAgent.indexOf("MSIE") > -1);
				byte[] fileNameBytes = registry.getFileFolderService().getFileInfo(nodeRef).getName().getBytes((isInternetExplorer) ? ("windows-1250") : ("utf-8"));
				String dispositionFileName = "";
				String currentLoginUserName = registry.getAuthenticationService().getCurrentUserName();
				Boolean isDocVeraProtected = (Boolean) registry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.PROP_IS_DOCUMENT_VERA_PROTECTED);
				if (!(searchUser !=null && searchUser.contains(currentLoginUserName)) && veraProtectionUtil.getVersUserProfile(currentLoginUserName,nodeRef)!=null && (isDocVeraProtected != null && isDocVeraProtected)) {
					//To provide vera encrypted document based on user and security type
					log.info(" :::::: before applyVeraProtectionPolicy in CheckOut Service ::::::");
					veraProtectionUtil.applyVeraProtectionPolicy(nodeRef.toString(),req,res,currentLoginUserName);
					return;
				}else{
				
			    for (byte b: fileNameBytes) dispositionFileName += (char)(b & 0xff);

			    String disposition = "attachment; filename=\"" + dispositionFileName + "\"";
			    
				res.setHeader("Content-disposition", disposition);
				log.info(formatter.format(new Date()) + "  :: Check out successful for " + nodeRefString);
				
				ContentReader reader = registry.getContentService().getReader(nodeRef, ServiceConstants.TYPE_CISCODOCS);
				if (null == reader){
					reader = registry.getContentService().getReader(nodeRef, ContentModel.TYPE_CONTENT);
				}
				
				res.setContentType(reader.getMimetype());
				reader.getContent(res.getOutputStream());
				return;
			}
			} catch (Exception e) {
				log.error(formatter.format(new Date()) + "  :: Check out failed for " + nodeRefString);
				e.printStackTrace();
				res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
				res.getWriter().write(ErrorStatus.STATUS_MSG_FAILURE);
				res.getWriter().close();
				return;
			}
		}
		log.error(formatter.format(new Date()) + "  :: Check out successful for " + nodeRefString);

		res.setStatus(ErrorStatus.STATUS_CODE_INVALID_CHECKOUT);
		res.getWriter().write(ErrorStatus.STATUS_MSG_INVALID_CHECKOUT);
		res.getWriter().close();

	}
}
