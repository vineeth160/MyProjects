package com.cisco.alfresco.service.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Base64;

import javax.crypto.SecretKey;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CryptoUtil {
	private CryptoUtil(){}
	  private static final Log logger = LogFactory.getLog(CryptoUtil.class);	
	  private static final byte[] KEYSTORE_PASSWORD = "DX#C@che#@$tUpl0@der".getBytes();
	public static String generateKeyString(){
		String keyStoreLocation = "/apps/alfcmadm/tools/security/mongo.keystore";
        KeyStore ks = null;
        try
        {
            ks = KeyStore.getInstance("JCEKS");
        }
        catch (KeyStoreException e1)
        {
            e1.printStackTrace();
            logger.error("Unable to get keystore" + e1);
        }		
		
        char[] password = new String(Base64.getDecoder().decode(KEYSTORE_PASSWORD)).toCharArray();
        FileInputStream fis = null;
        try
        {
            fis = new FileInputStream(keyStoreLocation);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
            logger.error("Unable to read keystore file" + e);
        }
        
        try
        {
            ks.load(fis, password);
        }
        catch (NoSuchAlgorithmException e1)
        {
            logger.error(e1);
        }
        catch (CertificateException e1)
        {
            logger.error(e1);
        }
        catch (IOException e1)
        {
            logger.error(e1);
        }

        SecretKey secret = null;
        try
        {
            secret = (SecretKey) ks.getKey("contentEncSecretKey", "password".toCharArray());
        }
        catch (UnrecoverableKeyException e1)
        {
            logger.error(e1);
        }
        catch (KeyStoreException e1)
        {
            logger.error(e1);
        }
        catch (NoSuchAlgorithmException e1)
        {
            logger.error(e1);
        }

        try
        {
            fis.close();
        }
        catch (IOException e1)
        {
            e1.printStackTrace();
        }
        logger.error("ENCRYPTION:::::::::" + secret.getAlgorithm());
        return new String(Base64.getEncoder().encode(secret.getEncoded()));
	}
	
	public static SecretKey generateKey(){
		String keyStoreLocation = "/apps/alfcmadm/tools/security/mongo.keystore";
        KeyStore ks = null;
        try
        {
            ks = KeyStore.getInstance("JCEKS");
        }
        catch (KeyStoreException e1)
        {
            e1.printStackTrace();
            logger.error("Unable to get keystore" + e1);
        }		
		
        char[] password = new String(Base64.getDecoder().decode(KEYSTORE_PASSWORD)).toCharArray();
        FileInputStream fis = null;
        try
        {
            fis = new FileInputStream(keyStoreLocation);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
            logger.error("Unable to read keystore file" + e);
        }
        
        try
        {
            ks.load(fis, password);
        }
        catch (NoSuchAlgorithmException e1)
        {
            logger.error(e1);
        }
        catch (CertificateException e1)
        {
            logger.error(e1);
        }
        catch (IOException e1)
        {
            logger.error(e1);
        }

        SecretKey secret = null;
        try
        {
            secret = (SecretKey) ks.getKey("contentEncSecretKey", "password".toCharArray());
        }
        catch (UnrecoverableKeyException e1)
        {
            logger.error(e1);
        }
        catch (KeyStoreException e1)
        {
            logger.error(e1);
        }
        catch (NoSuchAlgorithmException e1)
        {
            logger.error(e1);
        }

        try
        {
            fis.close();
        }
        catch (IOException e1)
        {
            e1.printStackTrace();
        }
        logger.error("ENCRYPTION ALGORITHM:::::::::" + secret.getAlgorithm());
        return secret;
	}	
}
