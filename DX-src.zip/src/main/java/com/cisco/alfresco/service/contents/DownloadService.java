/**
 * 
 */
package com.cisco.alfresco.service.contents;

import java.io.IOException;
import java.net.URLEncoder;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.service.constants.ErrorStatus;

/**
 * @author kaudutta
 *
 */
public class DownloadService extends AbstractWebScript {
	protected ServiceRegistry registry;

	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

	final Logger logger = Logger.getRootLogger();

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res)
			throws IOException {
		String nodeRefString = req.getParameter("nodeRef");
		NodeRef nodeRef = null;
		if (null == nodeRefString || "".equals(nodeRefString.trim())) {
			res.setStatus(ErrorStatus.STATUS_CODE_NULL_NODEREF);
			res.getWriter().write(ErrorStatus.STATUS_CODE_NULL_NODEREF);
			res.getWriter().close();
			return;
		}

		try {
			nodeRef = new NodeRef(nodeRefString);
			if(registry.getFileFolderService().getFileInfo(nodeRef).isFolder()){
				res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
				res.getWriter().write("Content not a file.");
				res.getWriter().close();
				return;				
			}
			res.setHeader("Content-disposition", "attachment; filename="
					+ URLEncoder.encode(registry.getFileFolderService().getFileInfo(nodeRef).getName(),"UTF-8").replaceAll("\\+", "%20"));
			res.setContentType(registry.getContentService()
					.getReader(nodeRef, ContentModel.TYPE_CONTENT)
					.getMimetype());
			registry.getContentService()
					.getReader(nodeRef, ContentModel.TYPE_CONTENT)
					.getContent(res.getOutputStream());
			return;

		} catch (Exception e) {
			res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
			res.getWriter().write("Unable to download the document.");
			res.getWriter().close();
			return;
		}

	}

}
