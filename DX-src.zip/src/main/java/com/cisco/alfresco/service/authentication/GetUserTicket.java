/**
 * 
 */
package com.cisco.alfresco.service.authentication;

import java.io.IOException;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

/**
 * @author kaudutta
 *
 */
public class GetUserTicket extends AbstractWebScript {
	private ServiceRegistry registry;

	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

	@Override
	public void execute(final WebScriptRequest req, final WebScriptResponse res)
			throws IOException {
		final String userName = req.getParameter("user");
		
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
		    @Override
		    public Object doWork() throws Exception {
		    	AuthenticationUtil.setFullyAuthenticatedUser(userName);
		        JSONObject jsonObject=new JSONObject();
		        jsonObject.put("ticket",registry.getAuthenticationService().getCurrentTicket());
		        jsonObject.put("userName",registry.getAuthenticationService().getCurrentUserName());
				res.setContentType("application/json");
				res.getWriter().write(jsonObject.toString());
				res.getWriter().close();

		    	return null;
		    }
		}, userName);
	}
}
