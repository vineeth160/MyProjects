package com.cisco.alfresco.service.util;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NameNotFoundException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

public class LdapUtil {

	public  String getUserDetailsFromLDAP(String userLoginName) {
		//public static void main(String[]args){
		StringBuffer strBuffer = new StringBuffer();
		DirContext myDirContext = null;
		NamingEnumeration<SearchResult> mySearchResults = null;
		try
		{
			String myFilter = "(uid=" + userLoginName + ")";
			Hashtable<String, String> myEnv = new Hashtable<String, String>();
			myEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
			myEnv.put(Context.PROVIDER_URL, "ldap://dsx.cisco.com:389"); // ldap://dsx.cisco.com:389
			//myEnv.put(Context.SECURITY_PRINCIPAL, "utmahesh");
			// myEnv.put(Context.SECURITY_CREDENTIALS,"Mahe`123");
			myDirContext = new InitialDirContext(myEnv);
			SearchControls mySearchControls = new SearchControls();
			mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			mySearchResults = myDirContext.search("ou=ccoentities,o=cco.cisco.com", myFilter, mySearchControls);
			if(mySearchResults == null || !mySearchResults.hasMore()){
				mySearchResults = myDirContext.search("OU=Generics,O=cco.cisco.com",myFilter,
						mySearchControls );
			}
			SearchResult myNextEmployee;
			while (mySearchResults != null && mySearchResults.hasMore())
			{
				myNextEmployee = (SearchResult) mySearchResults.next();
				if (myNextEmployee.getAttributes().get("uid") != null)
				{
					String userId = myNextEmployee.getAttributes().get("uid").get().toString();
					strBuffer.append(userId);
				}
				if (myNextEmployee.getAttributes().get("cn") != null)
				{
					String name = myNextEmployee.getAttributes().get("cn").get().toString();
					strBuffer.append("::" + name + "::");
				}
				if (myNextEmployee.getAttributes().get("company") != null)
				{
					String company = myNextEmployee.getAttributes().get("company").get().toString();
					strBuffer.append(company + "::");
				}
				if (myNextEmployee.getAttributes().get("mail") != null)
				{
					String email = myNextEmployee.getAttributes().get("mail").get().toString();
					strBuffer.append(email + "::");
				}
				if (myNextEmployee.getAttributes().get("employeeType") != null)
				{
					String employeeType = myNextEmployee
							.getAttributes()
							.get("employeeType")
							.get()
							.toString();
					strBuffer.append(employeeType + "::");
				}
				else
				{
					String employeeType = "N/A";
					strBuffer.append(employeeType + "::");
				}
				if (myNextEmployee.getAttributes().get("whenChanged") != null)
				{
					String whenChanged = myNextEmployee
							.getAttributes()
							.get("whenChanged")
							.get()
							.toString();
					strBuffer.append(whenChanged + "::");
				}
				if (myNextEmployee.getAttributes().get("accessLevel") != null)
				{
					String accessLevel = myNextEmployee
							.getAttributes()
							.get("accessLevel")
							.get()
							.toString();
					strBuffer.append(accessLevel);
				}
				else
				{
					String accessLevel = "1";
					strBuffer.append(accessLevel);
				}

			}

		}
		catch (NameNotFoundException ne)
		{
			//ne.printStackTrace();
			return "";
			
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return "";
		}

		finally
		{
			try
			{
				if (mySearchResults != null)
				{
					mySearchResults.close();
				}

				if (myDirContext != null)
				{
					myDirContext.close();
				}
			}
			catch (NamingException ex)
			{
				ex.printStackTrace(); 
			}

		}	
		return strBuffer.toString().split("::")[0].toString();
		//System.out.println(strBuffer.toString().split("::")[0].toString());
		
	}
}
