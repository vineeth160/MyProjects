/**
 * 
 */
package com.cisco.alfresco.service.constants;

/**
 * @author kaudutta
 *
 */
public abstract class ErrorStatus {
	public static int 			STATUS_CODE_INVALID_PATH 			= 521;
	public static final String	STATUS_MSG_INVALID_PATH 			= "Invalid folder Path.";

	public static int 			STATUS_CODE_INVALID_NODEREF 		= 522;
	public static final String	STATUS_MSG_INVALID_NODEREF 			= "Not a valid NodeRef.";
	
	public static int 			STATUS_CODE_INVALID_METADATA 		= 523;
	public static final String	STATUS_MSG_INVALID_METATDATA 		= "Invalid metadata.";
	
	public static int 			STATUS_CODE_INVALID_INPUT	 		= 524;
	public static final String	STATUS_MSG_INVALID_INPUT	 		= "Invalid input format.";
	
	public static int 			STATUS_CODE_INVALID_PERMISSION 		= 525;
	public static final String	STATUS_MSG_INVALID_PERMISSION 		= "You don't have permission to perform this action.";
	
	public static int 			STATUS_CODE_INVALID_AUTHENTICATION 	= 526;
	public static final String	STATUS_MSG_INVALID_AUTHENTICATION 	= "Authentication Failed.";

	public static int 			STATUS_CODE_INVALID_CHECKOUT	 	= 527;
	public static final String	STATUS_MSG_INVALID_CHECKOUT		 	= "Document already checked out.";

	public static int 			STATUS_CODE_INVALID_CANCEL_CHECKOUT	= 528;
	public static final String	STATUS_MSG_INVALID_CANCEL_CHECKOUT	= "Document not checked out.";
	
	public static int 			STATUS_CODE_CONFLICT	 			= 529;
	public static final String	STATUS_MSG_CONFLICT		 			= "Conflict in operation.";
	
	public static int 			STATUS_CODE_FAILURE				 	= 530;
	public static final String	STATUS_MSG_FAILURE		 			= "Operation failed.";

	public static int 			STATUS_CODE_NULL_NODEREF		 	= 531;
	public static final String	STATUS_MSG_NULL_NODEREF	 			= "Noderef cannot be null or blank.";

	public static int 			STATUS_CODE_NOT_EMPTY				= 532;
	public static final String	STATUS_MSG_NOT_EMPTY	 			= "Folder not empty.";
	
	public static final int 	STATUS_CODE_INVALID_CHECKOUT_NODE 	= 536;
	public static final String	STATUS_MSG_INVALID_CHECKOUT_NODE 	= "Cannot perform checkout or checkin on this type of nodeRef.";
	
	public static final int 	STATUS_CODE_INVALID_SET_PERMISSION 	= 533;
	public static final String 	STATUS_MSG_INVALID_SET_PERMISSION 	= "Invalid permission set.";
	
	public static final int 	STATUS_CODE_INVALID_MOVE 			= 538;
	public static final String 	STATUS_MSG_INVALID_MOVE 			= "Content already exists in destination folder with same noderef.";
}
