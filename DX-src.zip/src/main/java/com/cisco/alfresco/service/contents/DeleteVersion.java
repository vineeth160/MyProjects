package com.cisco.alfresco.service.contents;


import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.version.Version;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.service.constants.ErrorStatus;

public class DeleteVersion extends AbstractWebScript {
	protected ServiceRegistry registry;

	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

	final Logger log = Logger.getRootLogger();
	private DateFormat formatter = DateFormat.getDateTimeInstance( DateFormat.FULL, 
            DateFormat.FULL, 
            Locale.US);

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res)
			throws IOException {
	
		String nodeRefString = req.getParameter("nodeRef");
		String strDeleteCurrent = req.getParameter("deleteCurrent");
		String strDoCheckout = req.getParameter("doCheckout");
		log.info(formatter.format(new Date()) + "  :: Delete Version called for versionref:: " + nodeRefString);
		log.error(formatter.format(new Date()) + "  :: Delete Version called for versionref:: " + nodeRefString);
		JSONObject responseObject = new JSONObject();
		try {
			NodeRef versionRef = null;

			if (null == nodeRefString || "".equals(nodeRefString.trim())) {
				log.error(formatter.format(new Date()) + "  :: Delete Version: null or blank versionref:: " + nodeRefString);
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				responseObject.put("error", "Null or blank versionref");
				responseObject.put("isSuccess", false);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}

			if(nodeRefString.indexOf("version") <=-1 ){
				log.error(formatter.format(new Date()) + "  :: Delete Version: not a valid versionref:: " + nodeRefString);
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				responseObject.put("isSuccess", false);
				responseObject.put("error", "Only versionref is allowed for this operation.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			
			try {
				versionRef = new NodeRef(nodeRefString);
				if (!registry.getNodeService().exists(versionRef)){
					log.error(formatter.format(new Date()) + "  :: Delete Version: versionref doesn't exist:: " + nodeRefString);
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
					responseObject.put("isSuccess", false);
					responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
					res.getWriter().write(responseObject.toString());
					res.setContentType("application/json");
					res.getWriter().close();
					return;
				}
			} catch (Exception e) {
				log.error(formatter.format(new Date()) + "  :: Delete Version: invalid versionref:: " + nodeRefString);
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				responseObject.put("isSuccess", false);
				responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}

			NodeRef nodeRef = new NodeRef("workspace://SpacesStore/" + registry.getNodeService().getProperty(versionRef, ContentModel.PROP_NODE_UUID));
			
			if(registry.getCheckOutCheckInService().isCheckedOut(nodeRef)){
				log.error(formatter.format(new Date()) + "  :: Delete Version: The document is checked out:: " + nodeRefString);
				res.setStatus(ErrorStatus.STATUS_CODE_CONFLICT);
				responseObject.put("isSuccess", false);
				responseObject.put("error", "Cannot delete a checked out document.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}

			if (strDeleteCurrent.equalsIgnoreCase("true") && !String.valueOf(registry.getVersionService().getCurrentVersion(nodeRef).getFrozenStateNodeRef()).equals(nodeRefString)){
				log.error(formatter.format(new Date()) + "  :: Delete Version: This is not the current version of the document:: " + nodeRefString);
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				responseObject.put("isSuccess", false);
				responseObject.put("error", "This is not the current version of the document.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}

			boolean isSuccess = delete(nodeRef, strDoCheckout, nodeRefString);
			log.info(formatter.format(new Date()) + "  :: Delete Version: version deleted successfully:: " + nodeRefString);
			if(isSuccess){
				log.info(formatter.format(new Date()) + "  :: Delete Version: version deleted successfully:: " + nodeRefString);
				responseObject.put("isSuccess", true);
				responseObject.put("error", "");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
			responseObject.put("isSuccess", false);
			responseObject.put("error", ErrorStatus.STATUS_MSG_FAILURE);
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();


		} catch (Exception e) {
			e.printStackTrace();
			res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
			try {
				responseObject.put("isSuccess", false);
				responseObject.put("error", ErrorStatus.STATUS_MSG_FAILURE);
			} catch (JSONException e1) {
				e1.printStackTrace();
			}
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			return;

		}

	}
	
	private boolean delete(final NodeRef nodeRef, final String strDoCheckout, final String nodeRefString){
		return AuthenticationUtil.runAsSystem(new AuthenticationUtil.RunAsWork<Boolean>() {
		    @Override
		    public Boolean doWork() throws Exception {
				ArrayList<Version> versions = new ArrayList<Version>(registry.getVersionService().getVersionHistory(nodeRef).getAllVersions());
				Version toDeleteVersion=null;
				Version toRevertVersion=null;
				boolean toRevert = false;
				for(Version version:versions){
					if(toRevert){
						toRevertVersion = version;
						break;
					}
					if(String.valueOf(version.getFrozenStateNodeRef()).equals(nodeRefString)){
						toDeleteVersion= version;
						toRevert=true;
					}
				}			

				if (null==toRevertVersion && null == toDeleteVersion){
					return false;
				}
				
				try {
					registry.getLockService().unlock(nodeRef);
					log.debug("LOCK STATE0:: " + registry.getLockService().getLockState(nodeRef));
					log.debug("LOCK STATUS0:: " + registry.getLockService().getLockStatus(nodeRef));
					log.debug("LOCK TYPE0:: " + registry.getLockService().getLockType(nodeRef));
					registry.getVersionService().revert(nodeRef, toRevertVersion, true);
					registry.getLockService().unlock(nodeRef);
					log.debug("LOCK STATE1:: " + registry.getLockService().getLockState(nodeRef));
					log.debug("LOCK STATUS1:: " + registry.getLockService().getLockStatus(nodeRef));
					log.debug("LOCK TYPE1:: " + registry.getLockService().getLockType(nodeRef));
					registry.getVersionService().deleteVersion(nodeRef, toDeleteVersion);
					registry.getLockService().unlock(nodeRef);
					log.debug("LOCK STATE2:: " + registry.getLockService().getLockState(nodeRef));
					log.debug("LOCK STATUS2:: " + registry.getLockService().getLockStatus(nodeRef));
					log.debug("LOCK TYPE2:: " + registry.getLockService().getLockType(nodeRef));
					if(strDoCheckout.equalsIgnoreCase("true")){
						registry.getCheckOutCheckInService().checkout(nodeRef);
					}
					log.debug(formatter.format(new Date()) + "  :: Delete Version: version deleted successfully:: " + nodeRefString);
					
					return true;
					
				} catch (Exception e) {
					e.printStackTrace();
					return false;
				}
		    }
		});			
	}
}
