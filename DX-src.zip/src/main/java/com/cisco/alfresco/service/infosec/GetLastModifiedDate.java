/**
 * 
 */
package com.cisco.alfresco.service.infosec;

import java.io.IOException;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.service.constants.ErrorStatus;

/**
 * @author kaudutta
 *
 */
public class GetLastModifiedDate extends AbstractWebScript {

	private static Logger logger = Logger.getRootLogger();
	protected ServiceRegistry registry;

	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res)
			throws IOException {
		String strNodeRef = req.getParameter("nodeRef");
		JSONObject responseObject = null;
		try {

			if (null == strNodeRef) {
				responseObject = new JSONObject();
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				responseObject.put("contentModifiedDate", "");
				responseObject.put("metadataModifiedDate", "");
				responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			
			NodeRef nodeRef = new NodeRef(strNodeRef);
			String contentModifiedDate = String.valueOf(registry.getVersionService().getCurrentVersion(nodeRef).getFrozenModifiedDate());
			String metadataModifiedDate = String.valueOf(registry.getFileFolderService().getFileInfo(nodeRef).getModifiedDate());
			responseObject = new JSONObject();
			responseObject.put("contentModifiedDate", contentModifiedDate);
			responseObject.put("metadataModifiedDate", metadataModifiedDate);
			responseObject.put("error", "");
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			return;
		} catch (JSONException e) {
			logger.error(e.fillInStackTrace());
			e.printStackTrace();
		}catch (Exception e) {
			logger.error(e.fillInStackTrace());
			responseObject = new JSONObject();
			res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
			try {
				responseObject.put("contentModifiedDate", "");
				responseObject.put("metadataModifiedDate", "");
				responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
			} catch (JSONException e1) {
				e1.printStackTrace();
			}
			return;
		}

	}

}
