package com.cisco.alfresco.service.contents;

import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.service.constants.ErrorStatus;

public class DeleteNodeRef extends AbstractWebScript {
	protected ServiceRegistry registry;

	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

	final Logger log = Logger.getRootLogger();
	private DateFormat formatter = DateFormat.getDateTimeInstance( DateFormat.FULL, 
            DateFormat.FULL, 
            Locale.US);

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res)
			throws IOException {

		String nodeRefString = req.getParameter("nodeRef");
		log.info(formatter.format(new Date()) + "  :: Delete called for noderef/versionref:: " + nodeRefString);
		JSONObject responseObject = new JSONObject();
		try {
			NodeRef nodeRef = null;

			if (null == nodeRefString || "".equals(nodeRefString.trim())) {
				log.error(formatter.format(new Date()) + "  :: Delete Srevice: null or blank noderef/versionref:: " + nodeRefString);
				res.setStatus(ErrorStatus.STATUS_CODE_NULL_NODEREF);
				responseObject.put("isSuccess", false);
				res.getWriter().write(ErrorStatus.STATUS_MSG_NULL_NODEREF);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}

			try {
				nodeRef = new NodeRef(nodeRefString);
				if (!registry.getNodeService().exists(nodeRef)){
					log.error(formatter.format(new Date()) + "  :: Delete Srevice: noderef/versionref doesn't exist:: " + nodeRefString);
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
					responseObject.put("isSuccess", false);
					responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
					res.getWriter().write(responseObject.toString());
					res.setContentType("application/json");
					res.getWriter().close();
					return;
				}
			} catch (Exception e) {
				log.error(formatter.format(new Date()) + "  :: Delete Srevice: invalid noderef/versionref:: " + nodeRefString);
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				responseObject.put("isSuccess", false);
				responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			if(nodeRefString.indexOf("version")>=0){
				nodeRef = registry.getVersionService().getCurrentVersion(nodeRef).getVersionedNodeRef();
			}
			
			if(registry.getFileFolderService().list(nodeRef).size()>0){
				log.error(formatter.format(new Date()) + "  :: Delete Srevice: folder not empty:: " + nodeRefString);
				res.setStatus(ErrorStatus.STATUS_CODE_NOT_EMPTY);
				responseObject.put("isSuccess", false);
				responseObject.put("error", ErrorStatus.STATUS_MSG_NOT_EMPTY);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			
			registry.getNodeService().deleteNode(nodeRef);
			log.info(formatter.format(new Date()) + "  :: Delete Srevice: deleted noderef/versionref:: " + nodeRef);

			responseObject.put("isSuccess", true);
			responseObject.put("error", "");
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();
		} catch (JSONException e) {
			log.error(formatter.format(new Date()) + "  :: Delete Srevice: JASON Failure noderef/versionref:: " + nodeRefString);
			res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
			try {
				responseObject.put("isSuccess", false);
				responseObject.put("error", ErrorStatus.STATUS_MSG_FAILURE);
			} catch (JSONException e1) {
				e1.printStackTrace();
			}
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			return;
		} catch (Exception e) {
			log.error(formatter.format(new Date()) + "  :: Delete Srevice: Internal Failure noderef/versionref:: " + nodeRefString);
			
			res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
			try {
				responseObject.put("isSuccess", false);
				responseObject.put("error", ErrorStatus.STATUS_MSG_FAILURE);
			} catch (JSONException e1) {
				e1.printStackTrace();
			}
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			e.printStackTrace();
			return;

		}
	}
}
