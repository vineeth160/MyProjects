/**
 * 
 */
package com.cisco.alfresco.service.contents;

import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.dao.ConcurrencyFailureException;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.service.commons.ServiceConstants;
import com.cisco.alfresco.service.constants.ErrorStatus;
import com.cisco.alfresco.service.util.ServiceUtil;

/**
 * @author kaudutta
 *
 */
public class SetPermission extends AbstractWebScript {
	private static Logger log = Logger.getLogger(SetPermission.class);
	protected ServiceRegistry registry;
	private DateFormat formatter = DateFormat.getDateTimeInstance( DateFormat.FULL, 
			DateFormat.FULL, 
			Locale.US);
	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}
	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		JSONArray authorityJsonArray = null;
		JSONObject responseObject = new JSONObject();
		try {
			authorityJsonArray = new JSONArray(req.getParameter("permissions").trim());
		} catch (JSONException e2) {
			try {
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_SET_PERMISSION);
				responseObject.put("message", "");
				responseObject.put("isSuccess", false);
				responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_SET_PERMISSION);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			} catch (JSONException e1) {
				e1.printStackTrace();
				return;
			}
		}
		
		try {
			if (authorityJsonArray.length()>0){
				//Added by utmahesh for DE5149 - Start
				try {
					for(int i = 0 ; i< authorityJsonArray.length(); i++){
						JSONObject authorityJsonObject = (JSONObject) authorityJsonArray.get(i);
						if(authorityJsonObject.getString("nodeRef").trim().equals("") || null == authorityJsonObject.getString("nodeRef")){
							res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
							log.error(formatter.format(new Date()) + "  :: Set Permission error: invalid NodeRef. ");
							responseObject.put("isSuccess", false);
							responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
							res.getWriter().write(responseObject.toString());
							res.setContentType("application/json");
							res.getWriter().close();
							return;
						}
						
						if(!registry.getNodeService().exists(new NodeRef(authorityJsonObject.getString("nodeRef")))){
							log.error(formatter.format(new Date()) + "  :: Set Permission error: invalid NodeRef. ");
							res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
							responseObject.put("isSuccess", false);
							responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
							res.setContentType("application/json");
							res.getWriter().write(responseObject.toString());
							res.getWriter().close();
							return;
						}
					}
				} catch (Exception e) {
					log.error(formatter.format(new Date()) + "  :: Set Permission error: invalid NodeRef. ");
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
					responseObject.put("isSuccess", false);
					responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
					res.setContentType("application/json");
					res.getWriter().write(responseObject.toString());
					res.getWriter().close();
					return;
				}//Added by utmahesh for DE5149 - End
				
				//Added by veerai for US9408 - start
				JSONArray invalidPermissionJson = ServiceUtil.getInvalidPermission(authorityJsonArray, registry);
				if(invalidPermissionJson.length()>0){
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_SET_PERMISSION);
					responseObject.put("message", "");
					responseObject.put("isSuccess", false);
					responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_SET_PERMISSION);
					responseObject.put("invalidData", invalidPermissionJson);
					res.getWriter().write(responseObject.toString());
					res.setContentType("application/json");
					res.getWriter().close();
					return;
				}//Added by veerai for US9408 - end
				
				for(int i = 0 ; i< authorityJsonArray.length(); i++){
					JSONObject authorityJsonObject = (JSONObject) authorityJsonArray.get(i);
					String strNodeRef = authorityJsonObject.getString("nodeRef");
					NodeRef nodeRef = new NodeRef(strNodeRef);
					JSONArray permissionJsonArray = authorityJsonObject.getJSONArray("permissions");
					for(int j = 0 ; j< permissionJsonArray.length(); j++){
						JSONObject permissionJsonObject = (JSONObject) permissionJsonArray.get(j);
						try {
							registry.getPermissionService().setPermission(nodeRef, permissionJsonObject.getString("authority"), ServiceConstants.PERMISSION_MAP.get(permissionJsonObject.getString("permission").toLowerCase()), true);
						} catch (ConcurrencyFailureException e) {
							log.error("ConcurrencyFailureException: retrying after 5 seconds.");
							Thread.sleep(5000);
							registry.getPermissionService().setPermission(nodeRef, permissionJsonObject.getString("authority"), ServiceConstants.PERMISSION_MAP.get(permissionJsonObject.getString("permission").toLowerCase()), true);
						}
					}
				}
				responseObject.put("message", "Permissions has been set successfully.");
				responseObject.put("isSuccess", true);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;

			}
			res.setStatus(ErrorStatus.STATUS_CODE_INVALID_SET_PERMISSION);
			responseObject.put("message", "");
			responseObject.put("isSuccess", false);
			responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_SET_PERMISSION);
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			return;

		} catch (Exception e) {
			log.error("Generic Exception",e);
			try {
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_SET_PERMISSION);
				responseObject.put("message", "");
				responseObject.put("isSuccess", false);
				responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_SET_PERMISSION);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			} catch (JSONException e1) {
				e1.printStackTrace();
				return;
			}
		}

	}
}