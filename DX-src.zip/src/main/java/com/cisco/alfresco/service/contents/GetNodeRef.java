/**
 * 
 */
package com.cisco.alfresco.service.contents;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.alfresco.repo.model.Repository;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileNotFoundException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.AccessStatus;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.util.ISO9075;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.service.constants.ErrorStatus;
import com.cisco.alfresco.service.util.ServiceUtil;

/**
 * @author kaudutta
 *
 */
public class GetNodeRef extends AbstractWebScript {
	// private static Logger log = Logger.getLogger(GetNodeRef.class);
	protected ServiceRegistry registry;
	protected Repository repository;
	
	private static Logger log = Logger.getLogger(GetNodeRef.class);
	private DateFormat formatter = DateFormat.getDateTimeInstance( DateFormat.FULL, 
            DateFormat.FULL, 
            Locale.US);
	private static final String JSON_NODEREF="nodeRef";
	private static final String RESPONSE_TYPE = "application/json";
	private static final String JSON_ERROR="error";

	private static final String RESOLVE_PATH="sites/cm:edcsng/documentLibrary";
	
	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

	public void setRepository(Repository repository) {
		this.repository = repository;
	}
	private static final String PATH = "+PATH:\"/app:company_home/st:sites/cm:edcsng/cm:documentLibrary";

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		String param = req.getParameter("path");
		String id = req.getParameter("id");
		String ciscoDocsId = req.getParameter("ciscoDocsId");
		JSONObject jsonObj = new JSONObject();
		try {

			if (null != id) {
				NodeRef nodeRef = ServiceUtil.getNodeRef(id, registry);
				if (null == nodeRef) {
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_PATH);
					jsonObj.put("nodeRef", "");
					jsonObj.put("error", "Can not find the content.");
					res.setContentType("application/json");
					res.getWriter().write(jsonObj.toString());
					res.getWriter().close();
					return;
				}
				jsonObj.put("nodeRef", nodeRef);
				res.setContentType("application/json");
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
				return;
			}
			if(null!=ciscoDocsId){
				getNodeFromCiscoID(ciscoDocsId.trim(), res);
				return;
			}
			
			if (param == null || param.trim().equals("")) {
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_PATH);
				jsonObj.put("nodeRef", "");
				jsonObj.put("error", ErrorStatus.STATUS_MSG_INVALID_PATH);
				res.setContentType("application/json");
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
				return;

			}
			getNodeFromPath(param.trim(), res);
		} catch (JSONException e) {
			e.printStackTrace();
		} 

	}
		
		
		
		private void getNodeFromPath(String param, WebScriptResponse res) {
			NodeRef nodeRef = getNodeFromResolvePath(param, res);
			if(null == nodeRef) {
				log.error("Falling back to Lucene");
				nodeRef = getNodeFromLucenePath(param, res);
			}
			JSONObject jsonObj = new JSONObject();
			try {
				if(null == nodeRef){
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_PATH);
					jsonObj.put(JSON_NODEREF, "");
					jsonObj.put(JSON_ERROR, ErrorStatus.STATUS_MSG_INVALID_PATH);
					res.setContentType(RESPONSE_TYPE);
					res.getWriter().write(jsonObj.toString());
					res.getWriter().close();
					return;
				}
				
				jsonObj.put(JSON_NODEREF, nodeRef);
				jsonObj.put(JSON_ERROR, "");				
				res.setContentType(RESPONSE_TYPE);
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
				return;
			
			} catch (JSONException | IOException e ) {
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_PATH);
				try {
					jsonObj.put(JSON_NODEREF, "");
					jsonObj.put(JSON_ERROR, ErrorStatus.STATUS_MSG_INVALID_PATH);
					res.setContentType(RESPONSE_TYPE);
					res.getWriter().write(jsonObj.toString());
					res.getWriter().close();
				} catch (JSONException | IOException e1) {
					log.error(formatter.format(new Date()) + "- Error from GetNodeRef(PATH) Error definition:: " + e.fillInStackTrace() +"\n StackTrace as follows: \n");
					log.error(ExceptionUtils.getFullStackTrace(e));
				}
				return;
			}
			
		}	
		
		
		private NodeRef getNodeFromLucenePath(String param, WebScriptResponse res) {
			try {
				if (param == null || "".equals(param.trim())) {
					return null;
				}
				String[] arrPath = param.split(",");
				StringBuilder sb = new StringBuilder();
				sb.append(PATH);
				for (String path : arrPath) {
					if (!"".equals(path.trim())) {
						path = URLDecoder.decode(path, "UTF-8");
						sb.append("/cm:").append(ISO9075.encode(path.trim()));
					}
				}
				sb.append("\"");
				return ServiceUtil.doSearch(sb.toString(), registry);
			} catch (IOException e) {
				log.error(formatter.format(new Date()) + "- Error from GetNodeRef(PATH) Error definition:: "
						+ e.fillInStackTrace() + "\n StackTrace as follows: \n");
				log.error(ExceptionUtils.getFullStackTrace(e));
				return null;
			}
		}
		
		private NodeRef getNodeFromResolvePath(String param, WebScriptResponse res) {
			try {
				if(param==null || "".equals(param.trim())){
					return null;
				}
				String[] arrPath = (param.trim()).split(",");
				StringBuilder sb = new StringBuilder();
				sb.append(RESOLVE_PATH);
				for (String path : arrPath){
					if(!"".equals(path.trim())){
							path=URLDecoder.decode(path, "UTF-8");
						sb.append("/").append(path.trim());
					}
				}
				log.error("TRYING THROUGH FILEFOLDERSERVICE: PATH:: " + sb.toString());
				List<String> pathElements = Arrays.asList(StringUtils.split(sb.toString(), '/'));
				return registry.getFileFolderService().resolveNamePath(repository.getCompanyHome(), pathElements).getNodeRef();
			} catch (UnsupportedEncodingException e) {
				log.error("Unsupported encoding, falling back to lucene!! \n", e);
				return null;
			} catch (FileNotFoundException e) {
				log.error("File Not Found, falling back to lucene!! \n", e);
				return null;
			}
		}
		

	private void getNodeFromCiscoID(String id, WebScriptResponse res) {
		JSONObject jsonObj = new JSONObject();
		try {
			NodeRef nodeRef=ServiceUtil.getNodeRefFromCiscoDocID(id, registry);
			if (!registry.getPermissionService().hasPermission(nodeRef, PermissionService.READ).equals(AccessStatus.ALLOWED)){
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_PERMISSION);
				jsonObj.put(JSON_NODEREF, "");
				jsonObj.put(JSON_ERROR, ErrorStatus.STATUS_MSG_INVALID_PERMISSION);
				res.setContentType(RESPONSE_TYPE);
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
				return;
			}
			log.info(formatter.format(new Date()) + " GetNodeRef ID:: " +id);
			
			log.info(formatter.format(new Date()) + " GetNodeRef ID:: " +id);
			if(null == nodeRef){
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
					jsonObj.put(JSON_NODEREF, "");
				jsonObj.put(JSON_ERROR, "Invalid EDCS ID or document Does Not Exist");
				res.setContentType(RESPONSE_TYPE);
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
				return;
			}

			jsonObj.put(JSON_NODEREF, nodeRef);
			res.setContentType(RESPONSE_TYPE);
			res.getWriter().write(jsonObj.toString());
			res.getWriter().close();
		} catch (JSONException | IOException  e) {
			log.error(formatter.format(new Date()) + "- Error from GetNodeRef(EDCS-ID) Error definition:: " + e.fillInStackTrace() +"\n StackTrace as follows: \n");
			log.error(ExceptionUtils.getFullStackTrace(e));
		} 
	}
	
	
	public static NodeRef doSearch(String query, ServiceRegistry registry) {
		SearchParameters sp = new SearchParameters();
		sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
		sp.setLanguage(SearchService.LANGUAGE_LUCENE);
		sp.setQuery(query);
		ResultSet results = null;
		try {
			results = registry.getSearchService().query(sp);
			// This does lazy eval... should iterate as .length() checks may not
			// be reliable
			for (ResultSetRow row : results) {
				NodeRef currentNodeRef = row.getNodeRef();
				return currentNodeRef;
			}
		} finally {
			if (results != null) {
				results.close();
			}
		}
		return null;
	}
}
