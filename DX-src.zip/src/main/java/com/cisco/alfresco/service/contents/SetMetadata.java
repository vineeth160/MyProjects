/**
 * 
 */
package com.cisco.alfresco.service.contents;

import java.io.IOException;
import java.io.Serializable;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.dictionary.PropertyDefinition;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessStatus;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.service.constants.ErrorStatus;
import com.cisco.alfresco.service.util.ServiceUtil;

/**
 * @author kaudutta
 *
 */
public class SetMetadata extends AbstractWebScript {

	private ServiceRegistry registry;

	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

	private static Map<String, QName> qNameMap = new HashMap<String, QName>();
	private static Logger log = Logger.getLogger(SetMetadata.class);
	private DateFormat formatter = DateFormat.getDateTimeInstance( DateFormat.FULL, 
            DateFormat.FULL, 
            Locale.US);

	static {
		qNameMap.put("title", ContentModel.PROP_TITLE);
		qNameMap.put("description", ContentModel.PROP_DESCRIPTION);
		qNameMap.put("docType", CiscoModelConstants.CISCO_DOC_TYPE_PROP);
		qNameMap.put("securityLevel", CiscoModelConstants.CISCO_SECURITY_PROP);
		qNameMap.put("theatre", CiscoModelConstants.CISCO_THEATRE_PROP);
		qNameMap.put("status", CiscoModelConstants.CISCO_DOC_STATUS);
	}

	@Override
	public void execute(final WebScriptRequest req, final WebScriptResponse res)
			throws IOException {
		JSONObject metadataJsonObject = null;
		final JSONObject responseObject = new JSONObject();
		JSONParser jsonParser = new JSONParser();
		//added by skorutla for DE4535 
		String user =req.getParameter("user");
		if(null== user || !registry.getAuthorityService().authorityExists(user.trim())){
			user = registry.getAuthenticationService().getCurrentUserName();
		}
		if (log.isInfoEnabled()){
			log.info(formatter.format(new Date()) + " :: UpdateProperties Service call : CURRENT USER:: "
					+ user);
		}
		log.error(formatter.format(new Date()) + " :: UpdateProperties Service call : CURRENT USER:: "
				+ user);
		//end by skorutla for DE4535
		try {
			metadataJsonObject = new JSONObject(String.valueOf(jsonParser.parse(req.getParameter("metadata").trim())));
		} catch (JSONException e2) {
			try {
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				log.error(formatter.format(new Date()) + "  :: Set Metadata error: invalid metadata. ");
				responseObject.put("isSuccess", false);
				responseObject.put("error", "Malformed metadata JSON object.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			} catch (JSONException e1) {
				e1.printStackTrace();
				return;
			}
		} catch (ParseException e) {
			try {
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				log.error(formatter.format(new Date()) + "  :: Set Metadata error: invalid metadata. ");
				responseObject.put("isSuccess", false);
				responseObject.put("error", "Metadata Parse Exception.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			} catch (JSONException e1) {
				e1.printStackTrace();
				return;
			}
		}

		try {
			if (metadataJsonObject.length() == 0) {
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				log.error(formatter.format(new Date()) + "  :: Set Metadata error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("isSuccess", false);
				responseObject.put("error", "Metadata cannot be blank.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			
			//Added by veerai for DE3777 -start
			if(metadataJsonObject.has("theatre") && metadataJsonObject.get("theatre") instanceof JSONArray){
				JSONArray theaterMultiValueArray = (JSONArray) metadataJsonObject.get("theatre");
				JSONObject jsonResponseObject = new JSONObject();
				if(theaterMultiValueArray!=null){
				for(int i=0;i<theaterMultiValueArray.length();i++){
					if("N/A".equals(theaterMultiValueArray.getString(i).trim())&&theaterMultiValueArray.length()>1){
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
						jsonResponseObject.put("isSuccess", false);
						jsonResponseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_METATDATA);
						res.getWriter().write(jsonResponseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return;
						}
					}
				}
			}
			//Added by veerai for DE3777 -end

			String nodeRefString;
			nodeRefString = (String) metadataJsonObject.get("nodeRef");
			log.info(formatter.format(new Date()) + "  :: Set Metadata: noderef:: " + nodeRefString);
			if (null == nodeRefString || "".equals(nodeRefString.trim())) {
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				log.error(formatter.format(new Date()) + "  :: Set Metadata: noderef null. ");
				res.setStatus(ErrorStatus.STATUS_CODE_NULL_NODEREF);
				responseObject.put("isSuccess", false);
				responseObject.put("error", "Document Id/ NodeRef cannot be blank.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			NodeRef nodeRef = null;
			nodeRef = new NodeRef(nodeRefString);
			if (!registry.getNodeService().exists(nodeRef)) {
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				log.error(formatter.format(new Date()) + "  :: Set Metadata: noderef does not exist.");
				responseObject.put("isSuccess", false);
				responseObject.put("error", "Invalid Document Id/ NodeRef.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}

			if (!registry.getPermissionService().hasPermission(nodeRef, "Write").equals(AccessStatus.ALLOWED)){
				log.error(formatter.format(new Date()) + "  :: Error while setting metadata ---- Access Denied");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_PERMISSION);
				log.error(formatter.format(new Date()) + "  :: Set Metadata: noderef does not exist.");
				responseObject.put("isSuccess", false);
				responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_PERMISSION);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			
			String aspects= req.getParameter("aspects");
			String operation = req.getParameter("operation");
			
			//Added by veerai for US10103 - start
			JSONObject invalidDataJSON = new JSONObject();
			JSONObject invalidPropertyJSONObject = ServiceUtil.getInvalidMetadataProperties(metadataJsonObject,registry);
			if(invalidPropertyJSONObject.length()>0){
				invalidDataJSON.put("metadata", invalidPropertyJSONObject);	
			}
			if(aspects!=null){
				JSONArray invalidAspectJson = ServiceUtil.getInvalidAspects((aspects.trim()).split(","), registry);
				if(invalidAspectJson.length()>0){
					invalidDataJSON.put("aspects", invalidAspectJson);
				}
			}
			if(invalidDataJSON.length()>0){
				log.error(formatter.format(new Date()) + "  :: invalidData :: " + invalidDataJSON.toString());
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("isSuccess", false);
				responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_METATDATA);
				responseObject.put("invalidData", invalidDataJSON);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;			
			}
			//Added by veerai for US10103 - start
			
			if(aspects!=null){
				setAspects((aspects.trim()).split(","), nodeRef, operation);
			}
			
			if(setMetadata(metadataJsonObject, nodeRef)){
				//added by skorutla for DE4535
				log.error("UpdateProperties service call::metadata set successfully for NoderRef ::"+nodeRef);
				//end by skorutla for DE4535
				responseObject.put("isSuccess", true);
				responseObject.put("error", "");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			
			res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
			responseObject.put("isSuccess", false);
			responseObject.put("error", ErrorStatus.STATUS_MSG_FAILURE);
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			
		} catch (Exception e) {
			//added by skorutla for DE4535		
			log.error(formatter.format(new Date()) + "  *UpdateProperties Service call*: Error from " + this.getClass().getCanonicalName()
					+ ":: \n" + e.fillInStackTrace());
			//end by skorutla for DE4535 
			e.printStackTrace();
			res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
			try {
				responseObject.put("isSuccess", false);
				responseObject.put("error", ErrorStatus.STATUS_MSG_FAILURE);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			} catch (JSONException e1) {
				e1.printStackTrace();
				return;
			}
		}
	}

	
	private boolean setMetadata(JSONObject metadataJsonObject, NodeRef nodeRef) {
		Set<QName> setAspect = registry.getNodeService().getAspects(nodeRef);
		for(QName aspect : setAspect){
			//Modified by rajatag for US9028 -start
			Map<QName, PropertyDefinition> allProps = registry.getDictionaryService().getAspect(aspect).getProperties();
			Set<QName> allKeys = allProps.keySet();
			Iterator<QName> it = allKeys.iterator();
			
			while(it.hasNext())
			{
				QName qname = it.next();
				if(metadataJsonObject.has(qname.getLocalName()))
				{
					PropertyDefinition pd = allProps.get(qname);
					if(pd.isMultiValued())
					{
						try {
							if(metadataJsonObject.get(qname.getLocalName()).getClass().equals(JSONArray.class))
							{
								JSONArray multiValueArray = (JSONArray) metadataJsonObject.get(qname.getLocalName());
								List<String> multivalueList = new ArrayList<String>();
								for(int i=0;i<multiValueArray.length();i++)
								{
									multivalueList.add(multiValueArray.get(i).toString());
								}
								registry.getNodeService().setProperty(nodeRef, qname,(Serializable)multivalueList);
								continue;
							}
						}
						catch(Exception e)
						{
							log.error("UNABLE TO SET property:: " + qname.getLocalName());
							return false;
						}
					}
					try	{
						registry.getNodeService().setProperty(nodeRef, qname, (String) metadataJsonObject.get(qname.getLocalName()));
					}
					catch(Exception e) {
						log.error("UNABLE TO SET property:: "+qname.getLocalName());
						return false;
					}
				}
			}
			//Modified by rajatag for US9028 -end
		}
		return true;
	}
	
	private void setAspects(String[] arrAspects, NodeRef nodeRef, String operation) {
		Set<QName> setAspects = new HashSet<>(registry.getDictionaryService().getAllAspects());
		for (QName aspect : setAspects) {
			for (String aspectName : arrAspects) {
				if (aspect.getLocalName().equals(aspectName))
					try {
						//Added by rajatag for US8275 -start
						if(null!=operation && "delete".equals(operation.trim()))
						{
							registry.getNodeService().removeAspect(nodeRef, aspect);
							continue;
						}
						//Added by rajatag for US8275 -end
						registry.getNodeService().addAspect(nodeRef, aspect, null);
					} catch (Exception e) {
						log.error("UNABLE TO SET ASPECT:: " + aspectName);
					}
			}
		}

	}
}
