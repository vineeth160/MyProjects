package com.cisco.alfresco.service.contents;

import java.io.IOException;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.permissions.AccessDeniedException;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileExistsException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.service.constants.ErrorStatus;
/**
 * 
 * @author prbadam, nathammi - Move document to vera protected folder
 * 
 */
public class MoveFileToFolder extends AbstractWebScript {
	private static final Logger LOG = Logger.getLogger(MoveFileToFolder.class);
	private static final String WORKSPACE_VERSIONSTORE ="workspace://version2Store/";
	private static SimpleDateFormat sdt = new SimpleDateFormat("MM-dd-yyyy_hh-mm-ss-S-a-zzz");
	
	private ServiceRegistry serviceRegistry;
	
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
	private DateFormat formatter = DateFormat.getDateTimeInstance( DateFormat.FULL, 
            DateFormat.FULL, 
            Locale.US);
	
	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		LOG.info(":: MoveFile to VERA execute method started ::  ");
		String inputJSONValue = req.getParameter("input");
		JSONObject reqJsonObject = null;
		JSONObject jsonObj = new JSONObject();
		String fileName =null;
		try {
			reqJsonObject = new JSONObject(inputJSONValue);
			String strfolderNode = reqJsonObject.getString("destFolderNodeRef");
			String strfileNodeRef = reqJsonObject.getString("fileNodeRef");
			LOG.info(formatter.format(new Date()) + "  :: Move file called for destination folder noderef:: " + strfolderNode + " File noderef:: " + strfileNodeRef);
			if((strfolderNode==null || strfolderNode.trim().equals("")) && (strfileNodeRef == null || strfileNodeRef.trim().equals(""))){
				LOG.error(formatter.format(new Date()) + "  :: Move file to vera folder : Invalid file/folder NodeRef");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				jsonObj.put("message", "");
				jsonObj.put("error", "Invalid parent noderef or folder name.");
				res.setContentType("application/json");
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
				return;
			}
			
			NodeRef folderNodeRef=null;
			NodeRef fileNodeRef=null;
			try {
				folderNodeRef= new NodeRef(strfolderNode);
				fileNodeRef= new NodeRef(strfileNodeRef);
				fileName = (String) serviceRegistry.getNodeService().getProperty(fileNodeRef, ContentModel.PROP_NAME);
				NodeRef fileParentNode = serviceRegistry.getNodeService().getPrimaryParent(fileNodeRef).getParentRef();

				if ((!serviceRegistry.getNodeService().exists(folderNodeRef)) && (!serviceRegistry.getNodeService().exists(fileNodeRef))){
					LOG.error(formatter.format(new Date()) + "  :: source file or destination folder does not exist:: " + folderNodeRef);
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
					jsonObj.put("message", "");
					jsonObj.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
					res.setContentType("application/json");
					res.getWriter().write(jsonObj.toString());
					res.getWriter().close();
					return;
				}
				if (fileParentNode!=null && fileParentNode.equals(folderNodeRef)){
					LOG.error(formatter.format(new Date()) + "  :: destination folder already contains source file :: ");
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_MOVE);
					jsonObj.put("message", "");
					jsonObj.put("error", ErrorStatus.STATUS_MSG_INVALID_MOVE);
					res.setContentType("application/json");
					res.getWriter().write(jsonObj.toString());
					res.getWriter().close();
					return;
				}
				
				if ((!serviceRegistry.getDictionaryService()
						.isSubClass(serviceRegistry.getNodeService().getType(folderNodeRef), ContentModel.TYPE_FOLDER))
						|| (!serviceRegistry.getDictionaryService().isSubClass(
								serviceRegistry.getNodeService().getType(fileNodeRef), ContentModel.TYPE_CONTENT))) {
					LOG.error(formatter.format(new Date()) + "  :: valid source and target type not provided:: "
							+ folderNodeRef);
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
					jsonObj.put("message", "");
					jsonObj.put("error", "Provide valid source and target type");
					res.setContentType("application/json");
					res.getWriter().write(jsonObj.toString());
					res.getWriter().close();
					return;
				}
			} catch (Exception e) {
				LOG.error(formatter.format(new Date()) + "  :: Move File to VERA protected Folder: Invalid destination folder noderef:: " + folderNodeRef);
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				jsonObj.put("message", "");
				jsonObj.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
				res.setContentType("application/json");
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
				return;
			}

			
			applyVeraProtectionOnDoc(fileNodeRef,folderNodeRef);
			VersionHistory versionHistory = getServiceRegistry().getVersionService().getVersionHistory(fileNodeRef);
			if (null != versionHistory)
			{
				for (Version versionId : versionHistory.getAllVersions())
				{
					NodeRef versionNodeRefId = new NodeRef(WORKSPACE_VERSIONSTORE+ versionId.getFrozenStateNodeRef().getId());
					applyVeraProtectionOnDoc(versionNodeRefId,folderNodeRef);
				}
			}
			serviceRegistry.getFileFolderService().move(fileNodeRef,folderNodeRef, getUniqueFileName(fileName,folderNodeRef));
			LOG.info(formatter.format(new Date()) + "  :: File moved to VERA protected Folder. NodeeRef= " + fileNodeRef);
			jsonObj.put("message", "File moved successfully to vera folder");
			jsonObj.put("error", "");
			
		} catch(AccessDeniedException e){
			try {
				LOG.error(formatter.format(new Date()) + "  :: File moved to VERA protected Folder failed." );
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_PERMISSION);
				jsonObj.put("message", "");
				jsonObj.put("error", ErrorStatus.STATUS_MSG_INVALID_PERMISSION);
				
				LOG.error("Error from " + this.getClass().getCanonicalName()
						+ ":: \n" + e);
			}catch (JSONException e1) {
				LOG.error("Error from " + this.getClass().getCanonicalName()
						+ ":: \n" + e1);
			}
		}catch (FileExistsException e) {
				LOG.error(formatter.format(new Date()), e);
				res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
				try {
					jsonObj.put("message", "");
					jsonObj.put("error", "file named "+fileName+" already exists under the specified parent location");
					res.setContentType("application/json");
					res.getWriter().write(jsonObj.toString());
					res.getWriter().close();
				} catch (JSONException e1) {
					LOG.error(e1);
				}
				return;
			}
		catch (Exception e) {
			try {
				LOG.error(formatter.format(new Date()) + "  :: File moved to VERA protected Folder failed." );
				res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
				jsonObj.put("message", "");
				jsonObj.put("error", ErrorStatus.STATUS_MSG_FAILURE);
				LOG.error("Error from " + this.getClass().getCanonicalName()
						+ ":: \n", e);
			} catch (JSONException e1) {
				LOG.error("Error from " + this.getClass().getCanonicalName()
						+ ":: \n", e1);
			}
		}
		res.setContentType("application/json");
		res.getWriter().write(jsonObj.toString());
		res.getWriter().close();
	}
	
	private void applyVeraProtectionOnDoc(NodeRef sourceNodeRef, NodeRef targetNodeRef){
		String veraProtectionType = (String)serviceRegistry.getNodeService().getProperty(targetNodeRef, ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
		if(veraProtectionType != null){
			String docSecurityType = (String)serviceRegistry.getNodeService().getProperty(sourceNodeRef, CiscoModelConstants.CISCO_SECURITY_PROP);
			if(veraProtectionType.equals("All Contents") || (veraProtectionType.equals(docSecurityType))){
				Map<QName, Serializable> verDocumentProtectionProps = new HashMap<>(1);
				verDocumentProtectionProps.put(ExternalSharingConstants.PROP_IS_DOCUMENT_VERA_PROTECTED, true);
				serviceRegistry.getNodeService().addAspect(sourceNodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION, verDocumentProtectionProps);
			} 
		}
	}
	/**
     * get unique name for documents
     */
    public String getUniqueFileName(String name , NodeRef parentNodeRef){
    	boolean fileNameExists=true;
    	String filename=name;
    	String tempFileName=name;
    	int dotIndex;
    	while(fileNameExists){
    		NodeRef node =serviceRegistry.getFileFolderService().searchSimple(parentNodeRef, tempFileName);
    		if(node!=null){
    			dotIndex = filename.lastIndexOf(".");
				if (dotIndex == 0) {
					// File didn't have a proper 'name' instead it had just a suffix and started with a ".", create "1.txt"
					tempFileName = sdt.format(new Date()) + filename;
				} else if (dotIndex > 0) {
					// Filename contained ".", create "filename-1.txt"
					tempFileName = filename.substring(0, dotIndex) + "_"	+ sdt.format(new Date()) + filename.substring(dotIndex);
				} else {
					// Filename didn't contain a dot at all, create "filename-1"
					tempFileName = filename + "-" + sdt.format(new Date());
				}
    		}else{
    			fileNameExists=false;
    		}
    	}
    	
    	return tempFileName;
    }

}
