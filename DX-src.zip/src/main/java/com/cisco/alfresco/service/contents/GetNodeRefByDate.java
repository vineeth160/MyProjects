/**
 * 
 */
package com.cisco.alfresco.service.contents;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.ISO9075;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.service.util.ServiceUtil;

/**
 * @author kaudutta
 *
 */
public class GetNodeRefByDate extends AbstractWebScript {

	private static final String RESTRICTED_PATH = "-PATH:\"/app:company_home/app:dictionary//.\"";
	private static final String IGNORED_ASPECT = "AND -TYPE:\"cm:thumbnail\" AND -TYPE:\"cm:failedThumbnail\" AND -TYPE:\"cm:rating\") AND NOT ASPECT:\"sys:hidden\"";
	private static final String PATH = "+PATH:\"/app:company_home/st:sites/cm:edcsng/cm:documentLibrary"+"/";

	private static final String CREATED = "@cm\\:created:";
	private static final String MODIFIED = "@cm\\:modified:";
	private static final Map<QName, String> qNameMap = new HashMap<QName, String>(); 

	private static final String JSON_NODELIST = "nodeList";
	private static final String JSON_ERROR = "error";

	private static final SimpleDateFormat INPUT_FORMAT = new SimpleDateFormat("MM-dd-yyyy");
	private static final SimpleDateFormat FINAL_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
	private static Logger log = Logger.getLogger(CreateNewFolder.class);
	private DateFormat formatter = DateFormat.getDateTimeInstance( DateFormat.FULL, 
            DateFormat.FULL, 
            Locale.US);

	private String strDateFrom= null;
	private String strDateTo=null;
	private String strFolderPath = null;
	private String strSkip= null;
	private String searchType = null;
	private String user = null;
	private String timeRange = null;
	private String edcsId = "";
	private String input = "";
	private String minute = "m";

	private int skip=0;
	private int max=1000;
	private int hours=4;
	private ServiceRegistry registry;

	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

	static{
		qNameMap.put(ContentModel.TYPE_CONTENT, "file");
		qNameMap.put(ContentModel.TYPE_FOLDER, "folder");
		qNameMap.put(ContentModel.TYPE_SYSTEM_FOLDER, "system folder");
		qNameMap.put(ContentModel.TYPE_CMOBJECT, "file");
		qNameMap.put(ContentModel.TYPE_LINK, "link");
		qNameMap.put(CiscoModelConstants.CISCO_MODEL, "file");
	}
	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		res.setContentEncoding("UTF-8");/**Added by veerai for DE3658*/
		strFolderPath = req.getParameter("path");
		strDateFrom = req.getParameter("from");
		strDateTo = req.getParameter("to");
		searchType = req.getParameter("type");
		user = req.getParameter("user");
		timeRange = req.getParameter("timeRange");
		strSkip = req.getParameter("skip");
		input = req.getParameter("nodeRef");
		JSONObject jsonObj;
		try {

			StringBuilder sb = new StringBuilder();
			sb.append(RESTRICTED_PATH).append(" AND ");
			sb.append(PATH);
			if(null != timeRange){
				if (null != strFolderPath && !"".equals(strFolderPath.trim())){
					String [] arrPath = strFolderPath.split(",");
					
					for (String path : arrPath){
						if(!"".equals(path.trim())){
							path=URLDecoder.decode(path, "UTF-8");
							sb.append("/cm:").append(ISO9075.encode(path.trim()));
						}
					}
					sb.append("/");
				}
				sb.append("/."+'"');
				sb.append(" AND ((");
				DateTime dateTime = new DateTime(new Date());
				try {
					if(timeRange.endsWith(minute)){
						timeRange = timeRange.substring(0, timeRange.indexOf(minute));
						hours = Integer.parseInt(timeRange.trim());
						dateTime = dateTime.minusMinutes(30);
					}else{
						hours = Integer.parseInt(timeRange.trim());
						dateTime = dateTime.minusHours(hours);
					}
				} catch (Exception e) {
					dateTime = dateTime.minusMinutes(30);
					log.error("Invalid hour format. Setting 30 minutes");
				}
				strDateFrom = FINAL_FORMAT.format(dateTime.getMillis());
				sb.append(hourRangedSearch(MODIFIED, strDateFrom));
				sb.append(")");
				sb.append(IGNORED_ASPECT);

				log.debug("....................................................................................");
				log.debug("QUERY::: " +sb.toString());
				
				List<NodeRef> nodeList = ServiceUtil.getNodeRefListPagination(sb.toString(), registry, max, skip);
				JSONArray jsonArray = new JSONArray();
				if (null==nodeList){
					jsonObj = new JSONObject();
					jsonObj.put(JSON_NODELIST, jsonArray);
					jsonObj.put(JSON_ERROR, "No document found");
					res.setContentType("application/json");
					res.getWriter().write(jsonObj.toString());
					res.getWriter().close();
					return;
				}
				if(null == input){
					jsonArray = getJsonNodeList(nodeList);

				}else{
					NodeRef sourceNodeRef = null;
					try {
						sourceNodeRef = new NodeRef(input);
					} catch (Exception e) {
						log.error("Get modified documents: invalid source file NodeRef");
					}
					if (null==sourceNodeRef || !registry.getNodeService().exists(sourceNodeRef)){
						jsonObj = new JSONObject();
						jsonObj.put(JSON_NODELIST, jsonArray);
						jsonObj.put(JSON_ERROR, "Input file not found");
						res.setContentType("application/json");
						res.getWriter().write(jsonObj.toString());
						res.getWriter().close();
						return;
					}
					InputStream is = registry.getContentService().getReader(sourceNodeRef,  ContentModel.TYPE_CONTENT).getContentInputStream();
					String idList = IOUtils.toString(is);
					is.close();
					Set<String> idSet = new HashSet<>(Arrays.asList((idList.trim()).split(",")));
					List<NodeRef> finalNodeList = new ArrayList<>();
					for (NodeRef nodeRef : nodeList){
						if(registry.getFileFolderService().getFileInfo(nodeRef).isFolder())	continue;
						if(null == (registry.getNodeService().getProperty(nodeRef, CiscoModelConstants.PROP_ALF_ID))) continue;
						if(idSet.contains(String.valueOf(registry.getNodeService().getProperty(nodeRef, CiscoModelConstants.PROP_ALF_ID)))){
							finalNodeList.add(nodeRef);
						}
					}
					if (finalNodeList.size()==0){
						jsonObj = new JSONObject();
						jsonObj.put(JSON_NODELIST, jsonArray);
						jsonObj.put(JSON_ERROR, "No document found");
						res.setContentType("application/json");
						res.getWriter().write(jsonObj.toString());
						res.getWriter().close();
						return;
					}
					jsonArray = getJsonNodeList(finalNodeList);
				}

				jsonObj = new JSONObject();
				jsonObj.put(JSON_NODELIST, jsonArray);
				jsonObj.put(JSON_ERROR, "");
				res.setContentType("application/json");
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
				return;
			}
			
			searchType = (searchType.trim()).toLowerCase();
			
			if (null != strFolderPath && !"".equals(strFolderPath.trim())){
				String [] arrPath = strFolderPath.split(",");
				
				for (String path : arrPath){
					if(!"".equals(path.trim())){
						path=URLDecoder.decode(path, "UTF-8");
						sb.append("/cm:").append(ISO9075.encode(path.trim()));
					}
				}
				sb.append("/");
			}
			sb.append("/."+'"');
			sb.append(" AND ((");

			switch (searchType) {
			case "created":
				sb.append(createDatedSearch(CREATED, strDateFrom, strDateTo));
				break;

			case "modified":
				sb.append(createDatedSearch(MODIFIED, strDateFrom, strDateTo));
				break;

			default:
				sb.append(createDatedSearch(CREATED, strDateFrom, strDateTo)) .append(" AND ").append(createDatedSearch(MODIFIED, strDateFrom, strDateTo));
				break;
			}
			sb.append(")");
			sb.append(IGNORED_ASPECT);

			log.debug("....................................................................................");
			log.debug("QUERY::: " +sb.toString());
			if (null!= strSkip){
				try {
					skip = Integer.parseInt(strSkip.trim());
				} catch (Exception e) {
					log.error("Invalid skip count :: " + strSkip +":final result:" + skip);
				}
			}
			max = max+skip;
			List<NodeRef> nodeList = ServiceUtil.getNodeRefListPagination(sb.toString(), registry, max, skip);
			
			JSONArray jsonArray = new JSONArray();

			if (null==nodeList){
				jsonObj = new JSONObject();
				jsonObj.put(JSON_NODELIST, jsonArray);
				jsonObj.put(JSON_ERROR, "");
				res.setContentType("application/json");
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
				return;
			}
			if(null== user){
				jsonArray = getJsonNodeList(nodeList);
				jsonObj = new JSONObject();
				jsonObj.put(JSON_NODELIST, jsonArray);
				jsonObj.put(JSON_ERROR, "");
				res.setContentType("application/json");
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
				return;
			}
			jsonArray = getJsonNodeList(nodeList, user);
			jsonObj = new JSONObject();
			jsonObj.put(JSON_NODELIST, jsonArray);
			jsonObj.put(JSON_ERROR, "");
			res.setContentType("application/json");
			res.getWriter().write(jsonObj.toString());
			res.getWriter().close();
			return;
		} catch (JSONException e) {
			log.error(formatter.format(new Date()) + "- Error from getNoderefList:: " + e.fillInStackTrace() +"\n StackTrace as follows: \n");
			log.error(ExceptionUtils.getFullStackTrace(e));
		}	
	}

	private JSONArray getJsonNodeList(List<NodeRef> nodeList, String user) {
		JSONArray jsonArray = new JSONArray();
		for (NodeRef nodeRef : nodeList){
			if (user.equals(registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_CREATOR)) || user.equals(registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_MODIFIER))){
				edcsId = String.valueOf(registry.getNodeService().getProperty(nodeRef, CiscoModelConstants.PROP_ALF_ID));
				JSONObject nodeInfoObj = new JSONObject();
				try {
					nodeInfoObj.put("nodeRef", nodeRef);
					nodeInfoObj.put("edcsID", edcsId);
					nodeInfoObj.put("type", qNameMap.get(registry.getFileFolderService().getFileInfo(nodeRef).getType()));
					nodeInfoObj.put("name", registry.getFileFolderService().getFileInfo(nodeRef).getName());
					if (qNameMap.get(registry.getFileFolderService().getFileInfo(nodeRef).getType()).equals("file")){
						nodeInfoObj.put("fileSize", registry.getContentService().getReader(nodeRef, ContentModel.TYPE_CONTENT).getSize());
					}
					nodeInfoObj.put("created", registry.getFileFolderService().getFileInfo(nodeRef).getCreatedDate());
					nodeInfoObj.put("creator", registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_CREATOR));
					nodeInfoObj.put("lastModified", registry.getFileFolderService().getFileInfo(nodeRef).getModifiedDate());
					nodeInfoObj.put("modifier", registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_MODIFIER));
					jsonArray.put(nodeInfoObj);
					
				} catch (JSONException e) {}
			}
		}
		return jsonArray;
	}

	private JSONArray getJsonNodeList(List<NodeRef> nodeList) {
		JSONArray jsonArray = new JSONArray();
		for (NodeRef nodeRef : nodeList){
			if(registry.getFileFolderService().getFileInfo(nodeRef).isFolder())	continue;
			if(null == (registry.getNodeService().getProperty(nodeRef, CiscoModelConstants.PROP_ALF_ID))) continue;

			edcsId = String.valueOf(registry.getNodeService().getProperty(nodeRef, CiscoModelConstants.PROP_ALF_ID));
			JSONObject nodeInfoObj = new JSONObject();
			try {
				nodeInfoObj.put("nodeRef", nodeRef);
				nodeInfoObj.put("edcsID", edcsId);
				nodeInfoObj.put("type", qNameMap.get(registry.getFileFolderService().getFileInfo(nodeRef).getType()));
				nodeInfoObj.put("name", registry.getFileFolderService().getFileInfo(nodeRef).getName());
				if (qNameMap.get(registry.getFileFolderService().getFileInfo(nodeRef).getType()).equals("file")){
					nodeInfoObj.put("fileSize", registry.getContentService().getReader(nodeRef, ContentModel.TYPE_CONTENT).getSize());
				}
				nodeInfoObj.put("created", registry.getFileFolderService().getFileInfo(nodeRef).getCreatedDate());
				nodeInfoObj.put("creator", registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_CREATOR));
				nodeInfoObj.put("lastModified", registry.getFileFolderService().getFileInfo(nodeRef).getModifiedDate());
				nodeInfoObj.put("modifier", registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_MODIFIER));
				jsonArray.put(nodeInfoObj);
			} catch (JSONException e) {}
		}
		return jsonArray;
	}

	
	
	
	private String createDatedSearch(String type, String strDateFrom, String strDateTo) {
		StringBuilder sb = new StringBuilder();
		try {
			sb.append(type).append("[");
			if(null!= strDateFrom && !"".equals(strDateFrom)){
				sb.append(FINAL_FORMAT.format(INPUT_FORMAT.parse(strDateFrom)));
			}else{
				sb.append("MIN");
			}
			sb.append(" TO ");				
			if(null!= strDateTo && !"".equals(strDateTo)){
				sb.append(FINAL_FORMAT.format(INPUT_FORMAT.parse(strDateTo)));
			}else{
				sb.append("NOW");
			}
			sb.append("]");
			return sb.toString();
		} catch (ParseException e) {
			log.error(formatter.format(new Date()) + "- Error from getNoderefList:: " + e.fillInStackTrace() +"\n StackTrace as follows: \n");
			log.error(ExceptionUtils.getFullStackTrace(e));
			return null;
		}
	}

	private String hourRangedSearch(String type, String strDateFrom) {
		StringBuilder sb = new StringBuilder();
			sb.append(type).append("[");
			if(null!= strDateFrom && !"".equals(strDateFrom)){
				sb.append(strDateFrom);
			}
			sb.append(" TO ").append("NOW").append("]");
			return sb.toString();
	}
}
