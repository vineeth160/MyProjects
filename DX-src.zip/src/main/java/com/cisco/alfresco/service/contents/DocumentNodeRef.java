/** US5224 and US4836 (Alfresco rest services + sample application)
 *
 */
package com.cisco.alfresco.service.contents;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.service.constants.ErrorStatus;

/*****************************************************************************/
/** ClassName     : DownloadDocument
 *  Functionality : This class will fetch noderef and name of document by 3 parameters:-
 1) EDCS ID
 2) Document path
 3) Noderef
 *  
 *  Created Date        CreatedBy         Update Date       UpdatedBy         Update Functionality
 *  22/07/2014          jagautam          14/10/2014        jagautam          Fetch document library noderef if query parameter is blank or null 
 *                                        15/10/2014        jagautam          Fix for US5244.Fetch noderef of specified path if path has only one folder name  
 */
/*****************************************************************************/

public class DocumentNodeRef extends AbstractWebScript {

	private static Logger logger = Logger.getRootLogger();
	protected ServiceRegistry registry;

	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res)
			throws IOException {

		String queryString = null;
		String queryParam = req.getParameter("param");

		List<NodeRef> folderNodeRefList = null;
		StringBuilder sbQuery = new StringBuilder();
		String documentPath = "";

		if (!queryParam.isEmpty() && queryParam != null) {
			// if parameter has EDCS Id
			// Example :- alfresco/service/cisco/getnoderef?param=EDCS-10000012
			if (queryParam.contains("EDCS")) {

				queryString = "@cs\\:alf_id:" + queryParam;
				sbQuery.append(queryString);
				folderNodeRefList = EDCSUtil.getNodeRefList(sbQuery.toString(),
						registry);

			} else if (queryParam.contains("://")) {
				// if parameter has noderef
				// Example :-
				// alfresco/service/cisco/getnoderef?param=workspace://SpacesStore/310ff018-65cc-4cb5-a386-d86a81fe625b
				NodeRef nodeRef = new NodeRef(queryParam);
				folderNodeRefList = new ArrayList<NodeRef>();
				folderNodeRefList.add(nodeRef);

			} else {
				// if parameter has document path
				// Example :-
				// alfresco/service/cisco/getnoderef?param=PartnerLearningSpace/space1/team.txt

				if (queryParam.contains("/") && queryParam.contains(".")) {

					String filename = null;
					String[] path = queryParam.split("/");
					filename = path[path.length - 1];

					for (int doc = 0; doc < path.length - 1; doc++) {
						documentPath += "cm:" + path[doc] + "/";
					}

					documentPath = documentPath.substring(0,
							documentPath.length() - 1);
					sbQuery.append("+PATH:\"/app:company_home/st:sites/cm:nextgen-edcs/cm:documentLibrary/"
							+ documentPath);

					sbQuery.append("//.\"").append(" AND ");

					sbQuery.append("@cm\\:name:" + filename);
					
					logger.info("sbQuery.............."
							+ sbQuery.toString());
					folderNodeRefList = EDCSUtil.getNodeRefList(
							sbQuery.toString(), registry);
				
				} else if (queryParam.contains("/") && !queryParam.contains(".")){
					
					String[] path = queryParam.split("/");
					
					for (int doc = 0; doc < path.length; doc++) {
						documentPath += "cm:" + path[doc] + "/";
					}
					
					
					sbQuery.append("+PATH:\"/app:company_home/st:sites/cm:nextgen-edcs/cm:documentLibrary/"
							+ documentPath);
					sbQuery.append(".\"");
					logger.info("sbQuery.............."
							+ sbQuery.toString());
					folderNodeRefList = EDCSUtil.getNodeRefList(sbQuery.toString(),

					registry);
								
				}else{

					documentPath = queryParam;
					
					if (documentPath.contains(".")) {
						sbQuery.append("+PATH:\"/app:company_home/st:sites/cm:nextgen-edcs/cm:documentLibrary/*");
						sbQuery.append("\"").append(" AND ");
						sbQuery.append("@cm\\:name:" + documentPath);
						logger.info("sbQuery.............."
								+ sbQuery.toString());
						folderNodeRefList = EDCSUtil.getNodeRefList(
								sbQuery.toString(), registry);
					} else {
						sbQuery.append("+PATH:\"/app:company_home/st:sites/cm:nextgen-edcs/cm:documentLibrary/cm:"
								+ documentPath + "/.\"");
						//logger.info("sbQuery.............."
						//		+ sbQuery.toString());
						logger.info("sbQuery.............."
								+ sbQuery.toString());
						folderNodeRefList = EDCSUtil.getNodeRefList(
								sbQuery.toString(), registry);
					}
				}
			}
		} else {

			sbQuery.append("+PATH:\"/app:company_home/st:sites/cm:nextgen-edcs/cm:documentLibrary/");
			sbQuery.append(".\"");
			logger.info("sbQuery.............."
					+ sbQuery.toString());
			folderNodeRefList = EDCSUtil.getNodeRefList(sbQuery.toString(),

			registry);

		}

		try {

			JSONObject jsonObject = new JSONObject();
			
			for (NodeRef nodeRef : folderNodeRefList) {
				jsonObject.put("nodeRef", nodeRef);
				String fileName = registry.getFileFolderService().getFileInfo(nodeRef).getName();
				byte[] nameByte = fileName.getBytes();
				fileName = new String(nameByte, "UTF8");
				logger.error("FILE NAME::: " + fileName);
				jsonObject.put("name", fileName);
			}
			// write noderef and document name in json object
			JSONObject responseObject = new JSONObject();
			responseObject.put("NodeRef", jsonObject);
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.setContentEncoding("UTF-8");
			res.getWriter().close();
		} catch (JSONException jsonException) {
			logger.error("Exception while fetching noderef and document name "
					+ jsonException.fillInStackTrace());
			res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
		} catch (Exception exception) {
			logger.error("Exception while fetching noderef and document name "
					+ exception.fillInStackTrace());
			res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
		}
	}

}
