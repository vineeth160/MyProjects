package com.cisco.alfresco.service.contents;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.rule.Rule;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AccessStatus;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.JSONArray;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.service.commons.ServiceConstants;

import com.cisco.alfresco.service.constants.ErrorStatus;

public class GetMetadata extends AbstractWebScript {
	protected ServiceRegistry registry;
	private static final String STR_NODEREF = "workspace://SpacesStore/";

	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

	final Logger logger = Logger.getRootLogger();
	@Override
	public void execute(WebScriptRequest request, WebScriptResponse response)
			throws IOException {

		final WebScriptRequest req = request;
		final WebScriptResponse res = response;
		
		res.setContentEncoding("UTF-8");
		String nodeRefString = req.getParameter("nodeRef");
		String noVersion = req.getParameter("noVersion");
		String returnType = req.getParameter("returnType");
		Set<String> propertySet = null;
		logger.error("nodeRefString " + nodeRefString);
		logger.error("noVersion " + noVersion);
		logger.error("returnType " + returnType);

		NodeRef nodeRef = null;
		if (null == nodeRefString || "".equals(nodeRefString.trim())) {
			res.setStatus(ErrorStatus.STATUS_CODE_NULL_NODEREF);
			res.getWriter().write("{\"error\":\""+ErrorStatus.STATUS_CODE_NULL_NODEREF+"\"}");
			res.getWriter().close();
			return;
		}

		try {
			nodeRef = new NodeRef(nodeRefString);
			if (!registry.getNodeService().exists(nodeRef)){
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				res.getWriter().write("{\"error\":\""+ErrorStatus.STATUS_MSG_INVALID_NODEREF+"\"}");
				res.getWriter().close();
				return;
			}
			
		} catch (Exception e) {
			res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
			res.getWriter().write("{\"error\":\""+ErrorStatus.STATUS_MSG_INVALID_NODEREF+"\"}");
			res.getWriter().close();
			return;
		}
		
		if (!registry.getPermissionService().hasPermission(nodeRef, PermissionService.READ).equals(AccessStatus.ALLOWED)){
			res.setStatus(ErrorStatus.STATUS_CODE_INVALID_PERMISSION);
			res.getWriter().write("{\"error\":\""+ErrorStatus.STATUS_MSG_INVALID_PERMISSION+"\"}");
			res.getWriter().close();
			return;
		}
		
		geDataInJSON(propertySet, returnType, nodeRef, noVersion, res, request);

	}

	public void geDataInJSON(Set<String> propertySet, String returnType,
			NodeRef nodeRef, String noVersion, WebScriptResponse res, WebScriptRequest request) {
			if (noVersion != null && noVersion.equalsIgnoreCase("true")) {
				getNoVersionDataInJSON(propertySet, noVersion, nodeRef, res, request);
				return;
			}

			switch (returnType) {
			case "versions":
				getOnlyVersionDataInJSON(propertySet, returnType, nodeRef, res);
				break;

			case "metadata":
				getOnlyMetaDataInJSON(propertySet, returnType, nodeRef, res, request);
				break;
			

			default:
				getMetaDataInJSON(propertySet, nodeRef, res, request);
				break;
			}
	}


	public void getOnlyVersionDataInJSON(Set<String> propertySet,
			String returnType, NodeRef nodeRef, WebScriptResponse res) {
		try {
			JSONObject responseObject = new JSONObject();
			responseObject.put("versions", getAllVersionDetails(nodeRef));
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();
		} catch (JSONException jsonException) {
			logger.error("Json Exception " + jsonException.fillInStackTrace());
		} catch (Exception exception) {
			logger.error("Exception " + exception.getStackTrace());

		}
	}


	public void getOnlyMetaDataInJSON(Set<String> propertySet,
			String returnType, NodeRef nodeRef, WebScriptResponse res, WebScriptRequest request) {
		try {
			JSONObject jsonObject = new JSONObject();
			jsonObject = getAllData(propertySet, jsonObject, nodeRef);
			// write all metadata in json object
			//Modified by veerai for DE3905 - start
			jsonObject.remove("name");
			jsonObject.put("name", registry.getFileFolderService().getFileInfo(nodeRef).getName());
			//Modified by veerai for DE3905 - end

			JSONObject responseObject = new JSONObject();
			responseObject.put("metadata", jsonObject);
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();

		} catch (JSONException jsonException) {
			logger.error("Json Exception " + jsonException.fillInStackTrace());
		} catch (Exception exception) {
			logger.error("Exception " + exception.getStackTrace());

		}

	}

	public void getNoVersionDataInJSON(Set<String> propertySet,
			String noVersion, NodeRef nodeRef, WebScriptResponse res, WebScriptRequest request) {
		try {

			String versionLabel = "1.0";
			if (null != registry.getVersionService().getCurrentVersion(nodeRef)){
				versionLabel = registry.getVersionService().getCurrentVersion(nodeRef).getVersionLabel();	
			}
			JSONObject responseObject = new JSONObject();
			if(!registry.getFileFolderService().getFileInfo(nodeRef).isFolder()){
				long fileSize = registry.getFileFolderService().getFileInfo(nodeRef).getContentData().getSize();
				String mimeType = registry.getFileFolderService().getFileInfo(nodeRef).getContentData().getMimetype();
				responseObject.put("size", fileSize);
				responseObject.put("mimeType", mimeType);
				responseObject.put("versionLabel", versionLabel);
			}
			JSONObject jsonObject = new JSONObject();
			jsonObject = getAllData(propertySet, jsonObject, nodeRef);
			// write all metadata in json object
			//Modified by veerai for DE3905 - start
			jsonObject.remove("name");
			jsonObject.put("name", registry.getFileFolderService().getFileInfo(nodeRef).getName());
			//Modified by veerai for DE3905 - end

			responseObject.put("metadata", jsonObject);
			responseObject.put("permissions", getPermissionMap(nodeRef));
			responseObject.put("nodeRef", nodeRef.toString());
			responseObject.put("filename", jsonObject.get("name"));
			responseObject.put("rules", getFolderRules(nodeRef));
			responseObject.put("parentNodeRef", registry.getNodeService().getPrimaryParent(getLatestNodeRef(nodeRef)).getParentRef());
			StringBuffer sbpath=new StringBuffer(registry.getNodeService().getPath(getLatestNodeRef(nodeRef)).toDisplayPath(registry.getNodeService(), registry.getPermissionService()));
			String relativePath=sbpath.substring(sbpath.indexOf("documentLibrary")+"documentLibrary".length(),sbpath.length());
			responseObject.put("parentPath", relativePath);
			
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();

		} catch (JSONException jsonException) {
			logger.error("Json Exception " + jsonException.fillInStackTrace());
		} catch (Exception exception) {
			logger.error("Exception " + exception.getStackTrace());

		}
	}

	// get metadata in json format
	public void getMetaDataInJSON(Set<String> propertySet, NodeRef nodeRef,
			WebScriptResponse res, WebScriptRequest request) {
		try {
			NodeRef currentVersionedNoderef = getLatestNodeRef(nodeRef);
			Version currentVersion = registry.getVersionService().getCurrentVersion(currentVersionedNoderef);
			String versionLabel = "1.0";
			if(currentVersion != null){
				versionLabel = currentVersion.getVersionLabel();
			}
			JSONObject jsonObject = new JSONObject();
			jsonObject = getAllData(propertySet, jsonObject, nodeRef);
			// write all metadata in json object
			//Modified by veerai for DE3905 - start
			jsonObject.remove("name");
			jsonObject.put("name", registry.getFileFolderService().getFileInfo(nodeRef).getName());
			//Modified by veerai for DE3905 - end

			JSONObject responseObject = new JSONObject();
			if(!registry.getFileFolderService().getFileInfo(nodeRef).isFolder()){
				long fileSize = registry.getFileFolderService().getFileInfo(nodeRef).getContentData().getSize();
				String mimeType = registry.getFileFolderService().getFileInfo(nodeRef).getContentData().getMimetype();
				responseObject.put("size", fileSize);
				responseObject.put("mimeType", mimeType);
				responseObject.put("versionLabel", versionLabel);
				responseObject.put("versions", getAllVersionDetails(nodeRef));
			}
			responseObject.put("filename", jsonObject.get("name"));
			responseObject.put("nodeRef", nodeRef.toString());
			responseObject.put("permissions", getPermissionMap(nodeRef));
			if(registry.getFileFolderService().getFileInfo(nodeRef).isFolder())
			responseObject.put("rules", getFolderRules(nodeRef));
			responseObject.put("metadata", jsonObject);
			responseObject.put("parentNodeRef", registry.getNodeService().getPrimaryParent(currentVersionedNoderef).getParentRef());
			StringBuffer sbpath=new StringBuffer(registry.getNodeService().getPath(currentVersionedNoderef).toDisplayPath(registry.getNodeService(), registry.getPermissionService()));
			String relativePath=sbpath.substring(sbpath.indexOf("documentLibrary")+"documentLibrary".length(),sbpath.length());
			responseObject.put("parentPath", relativePath);


			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();

		} catch (JSONException jsonException) {
			logger.error("Json Exception " + jsonException.fillInStackTrace());
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}

	
	private NodeRef getLatestNodeRef(final NodeRef nodeRef) {
		return AuthenticationUtil.runAsSystem(new AuthenticationUtil.RunAsWork<NodeRef>() {
			@Override
			public NodeRef doWork() throws Exception {
				return new NodeRef(STR_NODEREF + registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NODE_UUID));
			}
		});
	}

	private Map<String, String> getPermissionMap(NodeRef nodeRef) {
		Set<AccessPermission> permissionSet = registry.getPermissionService()
				.getAllSetPermissions(nodeRef);
		Map<String, String> permissionMap = new HashMap<String, String>();
		
		for(AccessPermission permission : permissionSet){
			permissionMap.put(permission.getAuthority(), permission.getPermission());
		}
		return permissionMap;
	}
	
	
	private List<? extends String> getAllVersionDetails(NodeRef nodeRefInput) {
		ArrayList<String> versionArray = new ArrayList<String>();
		NodeRef nodeRef = getLatestNodeRef(nodeRefInput);
		if (null == registry.getVersionService().getVersionHistory(nodeRef)){
			return versionArray;
		}
		ArrayList<Version> versionList = (ArrayList<Version>) registry.getVersionService().getVersionHistory(nodeRef).getAllVersions();
		try {
			for(Version version : versionList){
				JSONObject versionObject = new JSONObject();
				String versionLabel = version.getVersionLabel();
				String approvalStatus = (String) version.getVersionProperty("status");
				versionObject.put("comments", (version.getDescription()==null)?"":version.getDescription());
				versionObject.put("label",versionLabel);
				versionObject.put("versionRef", version.getFrozenStateNodeRef());
				versionObject.put("approvalStatus", approvalStatus);
				versionArray.add(versionObject.toString());
			}
		} catch (JSONException jsonException) {
			logger.error("Json Exception " + jsonException.fillInStackTrace());
		} catch (Exception exception) {
			logger.error("Exception " + exception.getStackTrace());
		}
		return versionArray;
	}
	

	private JSONObject getAllData(Set<String> propertySet,
			JSONObject jsonObject, NodeRef nodeRef)
			throws InvalidNodeRefException, JSONException {
		NodeRef currentVersionedNoderef = getLatestNodeRef(nodeRef);
		StringBuffer sbpath=new StringBuffer(registry.getNodeService().getPath(currentVersionedNoderef).toDisplayPath(registry.getNodeService(), registry.getPermissionService()));
		String relativePath=sbpath.substring(sbpath.indexOf("documentLibrary")+"documentLibrary".length(),sbpath.length()) + "/" + registry.getFileFolderService().getFileInfo(currentVersionedNoderef).getName();
		jsonObject.put("path", relativePath);
		Set<QName> qnameSet = registry.getNodeService().getProperties(nodeRef).keySet();
		if (propertySet != null) {
			// It will fetch specific metadata of document
			for (QName qname : qnameSet) {
				if (!propertySet.contains(qname.getLocalName())) {
					continue;
				}
				jsonObject.put(qname.getLocalName(), registry.getNodeService().getProperties(nodeRef).get(qname));
			}
			return jsonObject;
		} 
		// It will fetch all the metadata of document
		for (QName qname : qnameSet) {
			jsonObject.put(qname.getLocalName(), registry.getNodeService().getProperty(nodeRef, qname));
		}
		return jsonObject;		
	}
	
	@SuppressWarnings("unchecked")
	private JSONArray getFolderRules(NodeRef nodeRef) {
		List<Rule> rules = registry.getRuleService().getRules(nodeRef);
		JSONArray rulesinfo = new JSONArray();
		for (Rule rule : rules) {
			LinkedHashMap<String,String> ruleObj=new LinkedHashMap<String, String>();
			ruleObj.put("title", rule.getTitle());
			ruleObj.put("description",rule.getDescription());
			rulesinfo.add(ruleObj);
		  }
		return rulesinfo;
	}    
}
