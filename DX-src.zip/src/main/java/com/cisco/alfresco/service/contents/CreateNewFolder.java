/**
 * 
 */
package com.cisco.alfresco.service.contents;

import java.io.IOException;
import java.io.Serializable;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.permissions.AccessDeniedException;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.dictionary.PropertyDefinition;
import org.alfresco.service.cmr.model.FileExistsException;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.alfresco.service.util.LdapUtil;
import com.cisco.alfresco.service.constants.ErrorStatus;
import com.cisco.alfresco.service.util.ServiceUtil;
import com.cisco.alfresco.service.commons.ServiceConstants;

/**
 * @author kaudutta
 *
 */
public class CreateNewFolder extends AbstractWebScript {
	private ServiceRegistry registry;
	private static Logger log = Logger.getLogger(CreateNewFolder.class);

	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}
	private DateFormat formatter = DateFormat.getDateTimeInstance( DateFormat.FULL, 
			DateFormat.FULL, 
			Locale.US);
	LdapUtil ldapUtil = new LdapUtil();
	//added by skorutla for DE4854
	private static Map<String, String> permissionMap = new HashMap<String, String>();	
	static{
		permissionMap.put("reader",ServiceConstants.READER);
		permissionMap.put("editor",ServiceConstants.EDITOR);
		permissionMap.put("viewer",ServiceConstants.VIEWER);
		permissionMap.put("folder admin",ServiceConstants.FOLDER_ADMIN);
	}
	//end by skorutla for DE4854

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		log.info("enter into execute() >>>> ");
		String strParentNodeRef = req.getParameter("parentNodeRef");
		String folderName = req.getParameter("folderName");
		log.info("folderName>>>"+folderName);
		log.info("folderName>>>"+folderName.toString());
		JSONObject jsonObj = new JSONObject();
		//added by skorutla for US11291
		JSONArray authorityJsonArray = null;
		JSONObject mainObject = null;
		//end by skorutla for US11291


		try {
			log.info(formatter.format(new Date()) + "  :: Create folder called for parent noderef/path:: " + strParentNodeRef + " Folder name:: " + folderName);

			if((strParentNodeRef==null || strParentNodeRef.trim().equals("")) && (folderName == null || folderName.trim().equals(""))){
				log.error(formatter.format(new Date()) + "  :: Create folder: Invalid NodeRef");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				jsonObj.put("message", "");
				jsonObj.put("nodeRef", "");
				jsonObj.put("error", "Invalid parent noderef or folder name.");
				res.setContentType("application/json");
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
				return;

			}

			//Added by harschau for DE-3850
			if(folderName!=null){			
				//folderName = URLDecoder.decode(folderName,"utf-8");
				Set<Character> charSet = toSet(folderName);
				charSet.retainAll(toSet("\\/:*?\"<>|"));
				if(charSet.size()>0){
					log.error(formatter.format(new Date()) + "  :: Create folder: Invalid Folder Name");
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
					jsonObj.put("message", "");
					jsonObj.put("nodeRef", "");
					jsonObj.put("error", "Proposed folder name contains unsupported characters. please consult the services documentation for the list of unsupported characters");
					res.setContentType("application/json");
					res.getWriter().write(jsonObj.toString());
					res.getWriter().close();
					return;
				}
			}//Added by veerai for DE3847 - end

			NodeRef parentRef=null;
			try {
				parentRef= new NodeRef(strParentNodeRef);
				if (!registry.getNodeService().exists(parentRef)){
					log.error(formatter.format(new Date()) + "  :: Create folder: Parent does not exist:: " + parentRef);
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
					jsonObj.put("message", "");
					jsonObj.put("nodeRef", "");
					jsonObj.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
					res.setContentType("application/json");
					res.getWriter().write(jsonObj.toString());
					res.getWriter().close();
					return;
				}

			} catch (Exception e) {
				log.error(formatter.format(new Date()) + "  :: Create folder: Invalid parent noderef:: " + parentRef);
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				jsonObj.put("message", "");
				jsonObj.put("nodeRef", "");
				jsonObj.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
				res.setContentType("application/json");
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
				return;
			}
			//added by skorutla for US11291
			if(null != req.getParameter("permissions") && !("").equals(req.getParameter("permissions").trim())){
				JSONParser jsonParser = new JSONParser();
				mainObject = new JSONObject(String.valueOf(jsonParser.parse(req.getParameter("permissions").trim())));
				authorityJsonArray = mainObject.getJSONArray("authorities");
				if (null != authorityJsonArray) {
					//added by utmahesh for DE4856					
					log.error("setPermissions::::" + authorityJsonArray);
					ArrayList<String>dup=new ArrayList<>();
					Set<String>dups=new HashSet<>();
					//log.error("setPermissions::::" + authorityJsonArray);					
					StringBuilder invalidUser = new StringBuilder();
					StringBuilder invalidUser_ldap = new StringBuilder();
					StringBuilder invalidPermission = new StringBuilder();
					for (int i = 0; i < authorityJsonArray.length(); i++){
						JSONObject permissionJsonObject = authorityJsonArray.getJSONObject(i);
						Object obj = permissionJsonObject.get("authority");
						String ldapUser= new String();
						dup.add(obj.toString().toUpperCase());
						dups.add(obj.toString().toUpperCase());
						
						//added by skorutla for DE4864
						if(permissionJsonObject.isNull("permission") || permissionJsonObject.isNull("authority")||"".equals(permissionJsonObject.get("authority"))||"".equals(permissionJsonObject.get("permission"))){
							JSONArray invalidPropeties = new JSONArray();
							invalidPropeties.put(permissionJsonObject); 
							log.error("Invalid propetry names. Allowed property names:: permission and authority");
							res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
							jsonObj.put("message", "Create folder failed.");
							jsonObj.put("isSuccess", false);
							jsonObj.put("error","Invalid property names.");
							jsonObj.put("invalidProperties", invalidPropeties);
							res.getWriter().write(jsonObj.toString());
							res.setContentType("application/json");
							res.getWriter().close();
							return;		
						}//end by skorutla for DE4864
						//start by utmahesh  US11575 
						log.error("------------"+permissionJsonObject.getString("authority"));	
						ldapUser = ldapUtil.getUserDetailsFromLDAP(permissionJsonObject.getString("authority"));
						log.error(ldapUser);	
						if(!permissionJsonObject.getString("authority").equalsIgnoreCase(ldapUser)){
							invalidUser_ldap.append(permissionJsonObject.getString("authority")).append(",");
						}
						if(invalidUser_ldap.length()>0){
							if(!registry.getAuthorityService().authorityExists(invalidUser_ldap.deleteCharAt(invalidUser_ldap.length()-1).toString()))
							{
								invalidUser.append(permissionJsonObject.getString("authority")).append(",");
							}
						}
						invalidUser_ldap.delete(0, invalidUser_ldap.length());
						//end by utmahesh  US11575
						//added by skorutla for DE4854
						if(permissionMap.get(permissionJsonObject.getString("permission").toLowerCase()) == null){
							invalidPermission.append(permissionJsonObject.getString("permission")).append(",");					
						}//end by skorutla for DE4854
					}
					if(dup.size()>dups.size()) {
						log.error("Create folder failed due to duplicate Authority");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_INPUT);
						jsonObj.put("message", "Create folder failed.");
						jsonObj.put("isSuccess", false);
						jsonObj.put("error","Duplicate Authority not allowed");
						jsonObj.put("invalidData", authorityJsonArray);
						res.getWriter().write(jsonObj.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return;
					}//closed by utmahesh for DE4856
					
					/*JSONArray invalidPermissionJson = ServiceUtil.getCustomInvalidPermission(authorityJsonArray, registry);
					if (invalidPermissionJson.length() > 0) {
						log.error("Create folder failed.");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_SET_PERMISSION);
						jsonObj.put("message", "Create folder failed.");
						jsonObj.put("isSuccess", false);
						jsonObj.put("error",ErrorStatus.STATUS_MSG_INVALID_SET_PERMISSION);
						jsonObj.put("invalidData", invalidPermissionJson);
						res.getWriter().write(jsonObj.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return;
					}  */
					//added by skorutla for DE4854
					if(invalidPermission.length()>0){
						log.error("Create folder failed.");
						invalidPermission.deleteCharAt(invalidPermission.length()-1);
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_SET_PERMISSION);
						jsonObj.put("message", "Create folder failed. Invalid permissions: "+invalidPermission);
						jsonObj.put("isSuccess", false);
						jsonObj.put("error", ErrorStatus.STATUS_MSG_INVALID_SET_PERMISSION);
						res.getWriter().write(jsonObj.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return;
					}//end by skorutla for DE4854
					if(invalidUser.length()>0)
					{
						invalidUser.deleteCharAt(invalidUser.length()-1);
						log.error("Create folder failed.");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_SET_PERMISSION);
						jsonObj.put("message", "Create folder failed. Invalid Users/Groups: "+invalidUser);
						jsonObj.put("isSuccess", false);
						jsonObj.put("error", "Invalid user name.");
						res.getWriter().write(jsonObj.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return;
					}
				}
			}
			//end by skorutla for US11291
			FileInfo folderInfo = registry.getFileFolderService().create(parentRef, folderName, ContentModel.TYPE_FOLDER);
			log.info(formatter.format(new Date()) + "  :: Folder Created. NodeeRef= " + folderInfo.getNodeRef());
			
			String folderDomain = req.getParameter("domain");
			log.info("folderDomain>>>"+folderDomain);
			log.info("folderDomain in str()>>>"+folderDomain.toString());
			setDomain(folderDomain,folderInfo.getNodeRef());
			
			String aspects= req.getParameter("aspects");
			String operation = req.getParameter("operation");
			if(aspects!=null){
				setAspects((aspects.trim()).split(","), folderInfo.getNodeRef(), operation);
			}
			JSONObject metadataJsonObject = null;
			if(null != req.getParameter("metadata") && !("").equals(req.getParameter("metadata").trim())){
				JSONParser jsonParser = new JSONParser();
				metadataJsonObject = new JSONObject(String.valueOf(jsonParser.parse(req.getParameter("metadata").trim())));
			}
			//added by skorutla for DE4857
			if(null != metadataJsonObject && null != mainObject){
				for(int i = 0 ; i< authorityJsonArray.length(); i++){
					JSONObject permissionJsonObject = (JSONObject) authorityJsonArray.get(i);
					String strAuthority = permissionJsonObject.getString("authority");
					log.error("Authority name is :" +strAuthority);
					if(registry.getAuthorityService().authorityExists(strAuthority)) {
						NodeRef authNodeRef = registry.getAuthorityService().getAuthorityNodeRef(strAuthority);
						strAuthority = registry.getPersonService().getPerson(authNodeRef).getUserName();
						log.error("Display name is :" +strAuthority);
					}
					registry.getPermissionService().setPermission(folderInfo.getNodeRef(), strAuthority, ServiceConstants.PERMISSION_MAP.get(permissionJsonObject.getString("permission").toLowerCase()), true);
				}
				if(setMetadata(metadataJsonObject, folderInfo.getNodeRef())){
					jsonObj.put("message", "Successfully created the folder with permissions but was not able to set metadata.");
				}
				jsonObj.put("message", "Successfully created the folder with permissions and metadata.");
			}//end by skorutla for DE4857
			else if(null != metadataJsonObject){
				if(setMetadata(metadataJsonObject, folderInfo.getNodeRef())){
					jsonObj.put("message", "Successfully created the folder but was not able to set metadata.");
				}
				jsonObj.put("message", "Successfully created the folder with metadata.");
			}//added by skorutla for US11291
			else if(null != req.getParameter("permissions") && !("").equals(req.getParameter("permissions").trim())){				
				for(int i = 0 ; i< authorityJsonArray.length(); i++){
					JSONObject permissionJsonObject = (JSONObject) authorityJsonArray.get(i);
					String strAuthority = permissionJsonObject.getString("authority");
					log.error("Authority name is :" +strAuthority);
					if(registry.getAuthorityService().authorityExists(strAuthority)) {
						NodeRef authNodeRef = registry.getAuthorityService().getAuthorityNodeRef(strAuthority);
						strAuthority = registry.getPersonService().getPerson(authNodeRef).getUserName();
						log.error("Display name is :" +strAuthority);
					}
					registry.getPermissionService().setPermission(folderInfo.getNodeRef(), strAuthority, ServiceConstants.PERMISSION_MAP.get(permissionJsonObject.getString("permission").toLowerCase()), true);
				}
				jsonObj.put("message", "Successfully created the folder with permissions.");
			}//end by skorutla for US11291
			else{
				jsonObj.put("message", "Successfully created the folder");
			}
			jsonObj.put("nodeRef", folderInfo.getNodeRef());

		} catch(AccessDeniedException e){
			try {
				log.error(formatter.format(new Date()) + "  :: Create folder failed." );
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_PERMISSION);
				jsonObj.put("message", "");
				jsonObj.put("nodeRef", "");
				jsonObj.put("error", ErrorStatus.STATUS_MSG_INVALID_PERMISSION);

				log.error("Error from " + this.getClass().getCanonicalName()
						+ ":: \n" + e);
			}catch (JSONException e1) {
				log.error("Error from " + this.getClass().getCanonicalName()
						+ ":: \n" + e1);
			}//added by harschau for DE-3851
		}catch (FileExistsException e) {
			log.error(formatter.format(new Date()), e);
			res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
			try {
				jsonObj.put("message", "");
				jsonObj.put("nodeRef", "");
				jsonObj.put("error", "folder named "+folderName+" already exists under the specified parent location");
				res.setContentType("application/json");
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
			} catch (JSONException e1) {
				log.error(e1);
			}
			return;
		}
		catch (Exception e) {
			try {
				log.error(formatter.format(new Date()) + "  :: Create folder failed." );
				log.error("error from json structure");
				res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
				//added by skorutla for DE4866
				jsonObj.put("message", "Create folder failed.");
				jsonObj.put("isSuccess", false);
				jsonObj.put("error","Invalid JSON Structure");
				//end by skorutla for DE4866
				log.error("Error from " + this.getClass().getCanonicalName()
						+ ":: \n", e);
			} catch (JSONException e1) {
				log.error("Error from " + this.getClass().getCanonicalName()
						+ ":: \n", e1);
			}
		}

		res.setContentType("application/json");
		res.getWriter().write(jsonObj.toString());
		res.getWriter().close();
	}
	private Set<Character> toSet(String str) {
		Set<Character> charSet = new HashSet<Character>(str.length());
		for (char c : str.toCharArray())
			charSet.add(Character.valueOf(c));
		return charSet;
	}

	private void setAspects(String[] arrAspects, NodeRef nodeRef, String operation) {
		Set<QName> setAspects = new HashSet<>(registry.getDictionaryService().getAllAspects());
		for (QName aspect : setAspects) {
			for (String aspectName : arrAspects) {
				if (aspect.getLocalName().equals(aspectName))
					try {
						//Added by rajatag for US8275 -start
						if(null!=operation && "delete".equals(operation.trim()))
						{
							registry.getNodeService().removeAspect(nodeRef, aspect);
							continue;
						}
						//Added by rajatag for US8275 -end
						registry.getNodeService().addAspect(nodeRef, aspect, null);
					} catch (Exception e) {
						log.error("UNABLE TO SET ASPECT:: " + aspectName);
					}
			}
		}

	}	

	private boolean setMetadata(JSONObject metadataJsonObject, NodeRef nodeRef) {
		Set<QName> setAspect = registry.getNodeService().getAspects(nodeRef);
		for(QName aspect : setAspect){
			//Modified by rajatag for US9028 -start
			Map<QName, PropertyDefinition> allProps = registry.getDictionaryService().getAspect(aspect).getProperties();
			Set<QName> allKeys = allProps.keySet();
			Iterator<QName> it = allKeys.iterator();

			while(it.hasNext())
			{
				QName qname = it.next();
				if(metadataJsonObject.has(qname.getLocalName()))
				{
					PropertyDefinition pd = allProps.get(qname);
					if(pd.isMultiValued())
					{
						try {
							if(metadataJsonObject.get(qname.getLocalName()).getClass().equals(JSONArray.class))
							{
								JSONArray multiValueArray = (JSONArray) metadataJsonObject.get(qname.getLocalName());
								List<String> multivalueList = new ArrayList<String>();
								for(int i=0;i<multiValueArray.length();i++)
								{
									multivalueList.add(multiValueArray.get(i).toString());
								}
								registry.getNodeService().setProperty(nodeRef, qname,(Serializable)multivalueList);
								continue;
							}
						}
						catch(Exception e)
						{
							log.error("UNABLE TO SET property:: " + qname.getLocalName());
							return false;
						}
					}
					try	{
						registry.getNodeService().setProperty(nodeRef, qname, (String) metadataJsonObject.get(qname.getLocalName()));
					}
					catch(Exception e) {
						log.error("UNABLE TO SET property:: "+qname.getLocalName());
						return false;
					}
				}
			}
			//Modified by rajatag for US9028 -end
		}
		return true;
	}
	private boolean setDomain(String folderDomain,NodeRef folderInfo){
		log.info("enter setDomain()>>>>");
		String[] doaminSplit = folderDomain.split(",");
		List<String> doaminList = new ArrayList<String>();
		Collections.addAll(doaminList, doaminSplit);
		HashSet<String> emailHashList = new HashSet<String>(doaminList);
		String listFolderString = emailHashList.toString().replace("[", "").replace("]", "").replace(", ", ",").trim();
        log.info("folderdetails>>>>"+listFolderString);
		if (listFolderString.startsWith(",")) {
			listFolderString = listFolderString.replaceFirst(",", "");
		}
		if (listFolderString.endsWith(",")) {
			listFolderString = listFolderString.substring(0, listFolderString.length() - 1);
		}

		Map<QName, Serializable> domainProp = new HashMap<QName, Serializable>(1);
		domainProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"),listFolderString);
		registry.getNodeService().addAspect(folderInfo,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domainAspect"), domainProp);
		return true;
	}
}
