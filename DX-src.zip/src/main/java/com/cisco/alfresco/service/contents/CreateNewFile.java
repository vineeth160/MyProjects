/**
 * 
 */
package com.cisco.alfresco.service.contents;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.transaction.RetryingTransactionHelper;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;
import org.springframework.extensions.webscripts.servlet.FormData;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.service.commons.ServiceConstants;
import com.cisco.alfresco.service.constants.ErrorStatus;
import com.cisco.alfresco.service.util.ServiceUtil;
import com.cisco.vera.utils.VeraProtectionUtil;

/**
 * @author kaudutta
 *
 */
public class CreateNewFile extends AbstractWebScript {

	private ServiceRegistry registry;

	protected VeraProtectionUtil veraProtectionUtil;

	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}
	/**
	 * @param veraProtectionUtil VeraProtectionUtil
	 */
	public VeraProtectionUtil getVeraProtectionUtil() {
		return veraProtectionUtil;
	}

	public void setVeraProtectionUtil(VeraProtectionUtil veraProtectionUtil) {
		this.veraProtectionUtil = veraProtectionUtil;
	}
	private static Map<String, QName> qNameMap = new HashMap<String, QName>();
	private static ArrayList<String> docTypeValues = new ArrayList<String>();
	private static ArrayList<String> theatreValues = new ArrayList<String>();
	private static ArrayList<String> secutiryLevelValues = new ArrayList<String>();
	private static ArrayList<String> statusValues = new ArrayList<String>();
	private static Logger log = Logger.getLogger(CreateNewFile.class);
	private DateFormat formatter = DateFormat.getDateTimeInstance( DateFormat.FULL, 
			DateFormat.FULL, 
			Locale.US);
	private static SimpleDateFormat sdt = new SimpleDateFormat(
			"MM-dd-yyyy_hh-mm-ss-S-a-zzz");
	// added by skorutla for DE4266
	static {
		docTypeValues.add(ServiceConstants.Cisco_Corporate_Document);
		docTypeValues.add(ServiceConstants.Cisco_Engineering_Document);
		docTypeValues.add(ServiceConstants.Cisco_Finance_Document);
		docTypeValues.add(ServiceConstants.Cisco_General_Document);
		docTypeValues.add(ServiceConstants.Cisco_HR_Document);
		docTypeValues.add(ServiceConstants.Cisco_IT_Document);
		docTypeValues.add(ServiceConstants.Cisco_Legal_Document);
		docTypeValues.add(ServiceConstants.Cisco_Marketing_Document);
		docTypeValues.add(ServiceConstants.Cisco_Operations_Document);
		docTypeValues.add(ServiceConstants.Cisco_Sales_Document);
		docTypeValues.add(ServiceConstants.Cisco_Services_Document);
		//added by skorutla for DE4915
		theatreValues.add(ServiceConstants.N_A);
		theatreValues.add(ServiceConstants.AMERICAS);
		theatreValues.add(ServiceConstants.APAC_JAPAN_CHINA);
		theatreValues.add(ServiceConstants.EMEA);
		theatreValues.add(ServiceConstants.EMERGING);
		theatreValues.add(ServiceConstants.GLOBAL_ENTERPRISE);
		//end by skorutla for DE4915
		//added by skorutla for DE4916						
		secutiryLevelValues.add(ServiceConstants.CISCO_RESTRICTED);
		secutiryLevelValues.add(ServiceConstants.CISCO_HIGHLY_CONFIDENTIAL);
		secutiryLevelValues.add(ServiceConstants.CISCO_CONFIDENTIAL);
		secutiryLevelValues.add(ServiceConstants.CISCO_PUBLIC);
		//END by skorutla for DE4916
		//added by skorutla for DE4914	
		statusValues.add(ServiceConstants.APPROVAL_N_A);
		statusValues.add(ServiceConstants.DRAFT);
		//end by skorutla for DE4914	
	}
	// end by skorutla for DE4266
	static {
		qNameMap.put("title", ContentModel.PROP_TITLE);
		qNameMap.put("description", ContentModel.PROP_DESCRIPTION);
		qNameMap.put("docType", CiscoModelConstants.CISCO_DOC_TYPE_PROP);
		qNameMap.put("securityLevel", CiscoModelConstants.CISCO_SECURITY_PROP);
		qNameMap.put("theatre", CiscoModelConstants.CISCO_THEATRE_PROP);
		qNameMap.put("status", CiscoModelConstants.CISCO_DOC_STATUS);
	}

	@Override
	public void execute(final WebScriptRequest req, final WebScriptResponse res)
			throws IOException {
		log.info(formatter.format(new Date()) + "  :: Upload : CURRENT USER:: "
				+ registry.getAuthenticationService().getCurrentUserName());

		FormData formData = (FormData) req.parseContent();
		FormData.FormField[] fields = formData.getFields();
		String mimetype = null;
		JSONObject metadataJsonObject = null;
		JSONArray permissionJsonArray = null;
		final JSONObject responseObject = new JSONObject();
		InputStream in = null;
		try {
			metadataJsonObject = new JSONObject(req.getParameter("metadata")
					.trim());
			permissionJsonArray = new JSONArray(req.getParameter("permissions")
					.trim());
		} catch (JSONException e2) {
			try {
				log.error(formatter.format(new Date()) + "  :: Upload error: invalid metadata. ");
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", "Malformed metadata JSON object.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			} catch (JSONException e1) {
				e1.printStackTrace();
				return;
			}
		}

		try {
			if (metadataJsonObject.length() == 0) {
				log.error(formatter.format(new Date()) + "  :: Upload error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", "Metadata cannot be blank.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			// Added by utmahesh for DE4829
			if(metadataJsonObject.has("docType")){
				//added by skorutla for DE4266	
				String docType = (String) metadataJsonObject.get("docType");
				log.info("docType String:::"+docType);
				if (null == docType || "".equals(docType.trim())) {
					log.error(formatter.format(new Date())
							+ "  :: Upload error: invalid metadata. ");
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
					responseObject.put("versionRef", "");
					responseObject.put("versionLabel", "");
					responseObject.put("message", "");
					responseObject.put("edcsId", "");
					responseObject.put("error", "DocType cannot be blank.");
					res.getWriter().write(responseObject.toString());
					res.setContentType("application/json");
					res.getWriter().close();
					return;
				}
				if (!docTypeValues.contains(docType)) {
					log.error("docType:::"+docType);				
					log.error(formatter.format(new Date())
							+ "  :: Upload error: invalid metadata. ");
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
					responseObject.put("versionRef", "");
					responseObject.put("versionLabel", "");
					responseObject.put("edcsId", "");
					responseObject
					.put("docType", docType);

					responseObject.put("message", "");
					responseObject.put("error",
							ErrorStatus.STATUS_MSG_INVALID_METATDATA);
					res.getWriter().write(responseObject.toString());
					res.setContentType("application/json");
					res.getWriter().close();
					return;
				}	
			}else{
				log.error(formatter.format(new Date()) + "  :: Upload error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", "DocType is a Mandatory field");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}// Closed by utmahesh for DE4829
			//end by skorutla for DE4266
			// Added by utmahesh for DE4833
			if(metadataJsonObject.has("securityLevel")){
			//added by skorutla for DE4267
			String securityLevel = (String) metadataJsonObject.get("securityLevel");
			log.error("securityLevel String:::"+securityLevel);
			log.info("securityLevel String:::"+securityLevel);
			if (null == securityLevel || "".equals(securityLevel.trim())) {
				log.error(formatter.format(new Date())
						+ "  :: Upload error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", "SecurityLevel cannot be blank.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			//added by skorutla for DE4916
			if (!secutiryLevelValues.contains(securityLevel)) {
				log.error("securityLevel:::"+securityLevel);				
				log.error(formatter.format(new Date())
						+ "  :: Upload error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("edcsId", "");
				responseObject
						.put("securityLevel", securityLevel);

				responseObject.put("message", "");
				responseObject.put("error",
						ErrorStatus.STATUS_MSG_INVALID_METATDATA);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}//end by skorutla for DE4916
			}else{
				log.error(formatter.format(new Date()) + "  :: Upload error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", "securityLevel is a Mandatory field");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}// Closed by utmahesh for DE4833
			// Added by utmahesh for DE4834
			if(metadataJsonObject.has("theatre")){
			String theaterValueString = (String) metadataJsonObject.get("theatre");
			log.info("theaterValue String:::"+theaterValueString);
			if (null == theaterValueString || "".equals(theaterValueString.trim())) {
				log.error(formatter.format(new Date())
						+ "  :: Upload error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", "Theatre cannot be blank.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			//added by skorutla for DE4915
			if (!theatreValues.contains(theaterValueString)) {
				log.error("theaterValueString:::"+theaterValueString);				
				log.error(formatter.format(new Date())
						+ "  :: Upload error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("edcsId", "");
				responseObject
						.put("theater", theaterValueString);

				responseObject.put("message", "");
				responseObject.put("error",
						ErrorStatus.STATUS_MSG_INVALID_METATDATA);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}//end by skorutla for DE4915
			}else{
				log.error(formatter.format(new Date()) + "  :: Upload error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", "Theatre is a Mandatory field");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}// Closed by utmahesh for DE4834
			// Added by utmahesh for DE4835
			if(metadataJsonObject.has("status")){
			String status = (String) metadataJsonObject.get("status");
			log.info("status String:::"+status);
			if (null == status || "".equals(status.trim())) {
				log.error(formatter.format(new Date())
						+ "  :: Upload error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", "Status cannot be blank.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}//end by skorutla for DE4267
			//added by skorutla for DE4914
			if (!statusValues.contains(status)) {
				log.error("status:::"+status);				
				log.error(formatter.format(new Date())
						+ "  :: Upload error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("edcsId", "");
				responseObject
						.put("status", status);

				responseObject.put("message", "");
				responseObject.put("error",
						ErrorStatus.STATUS_MSG_INVALID_METATDATA);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}//end by skorutla for DE4914
			}else{
				log.error(formatter.format(new Date()) + "  :: Upload error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", "Status is a Mandatory field");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}// Closed by utmahesh for DE4835
			String nodeRefString;
			NodeRef parentRef = null;
			// Added by utmahesh for DE4836
			if(metadataJsonObject.has("parent")){
			nodeRefString = (String) metadataJsonObject.get("parent");
			log.info(formatter.format(new Date()) + "  :: Upload: parent noderef:: " + nodeRefString);
			if (null == nodeRefString || "".equals(nodeRefString.trim())) {
				log.error(formatter.format(new Date()) + "  :: Upload: parent noderef null. ");
				res.setStatus(ErrorStatus.STATUS_CODE_NULL_NODEREF);
				res.getWriter()
				.write("Parent folder noderef must be provided.");
				res.getWriter().close();
				return;
			}
			parentRef = new NodeRef(nodeRefString);
			if (!registry.getNodeService().exists(parentRef)) {
				log.error(formatter.format(new Date()) + "  :: Upload: parent noderef does not exist.");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error",
						"Parent folder noderef doesn't exist.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			}else{
				log.error(formatter.format(new Date()) + "  :: Upload error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", "Parent Folder noderef is a Mandatory field");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}// Closed by utmahesh for DE4836

			for (FormData.FormField field : fields) {
				if (field.getName().equals("file") && field.getIsFile()) {
					mimetype = field.getMimetype();
					String mt = registry.getMimetypeService().guessMimetype(field.getFilename());
					if (mt != null) {
						mimetype = mt;
					}
					in = field.getInputStream();

				}
			}
			// Added by utmahesh for DE4830
			String fileName=null;
			if(metadataJsonObject.has("fileName")){
			fileName = (String) metadataJsonObject.get("fileName");
			if (null == fileName) {
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", "File name cannot be blank.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			//added by skorutla for DE4753
			if(!fileName.contains(".")){
				log.error("fileName:::"+fileName);
				log.error(formatter.format(new Date())+ "  :: Upload error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("edcsId", "");
				responseObject.put("message", "");
				responseObject.put("error", "Extension is mandatory for file name.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return; 
			}//end by skorutla for DE4753
			}
			else{
				log.error(formatter.format(new Date()) + "  :: Upload error: invalid metadata. ");
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", "fileName is a Mandatory field");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}// Closed by utmahesh for DE4830
			// Added by prbadam and nathammi upload for US10829
			NodeRef nodeRef = null;
			String currentLoginUserName = registry.getAuthenticationService().getCurrentUserName();
			boolean isVeraEncryptedDoc=veraProtectionUtil.isVeraEncryptedDoc(getFileContentAsStream(fields));
			log.info(formatter.format(new Date()) + "  :: Upload : isVeraEncryptedDoc:: "
					+ isVeraEncryptedDoc);
			if(isVeraEncryptedDoc){
				if(fileName.substring(fileName.lastIndexOf('.')+1).equals("html")){
					int index = fileName.lastIndexOf(".");
					String originalFileName = fileName.substring(0,(index != -1)? index : fileName.length());
					fileName=originalFileName;
				}
				log.info("originalFileName ::: "+fileName);
				String veraDocId = veraProtectionUtil.getVeraAppDocId(getFileContentAsStream(fields),currentLoginUserName);
				log.info("veraDocId :: "+veraDocId);
				if(!veraProtectionUtil.checkUserAccess(getFileContentAsStream(fields),currentLoginUserName,veraDocId)){
					log.error(formatter.format(new Date()) + "  :: CreateNewFile: You don't have premissions on vara secured document:: ");
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
					responseObject.put("versionRef", "");
					responseObject.put("versionLabel", "");
					responseObject.put("message", "");
					responseObject.put("edcsId", "");
					responseObject.put("error",ErrorStatus.STATUS_MSG_INVALID_PERMISSION);
					res.getWriter().write(responseObject.toString());
					res.setContentType("application/json");
					res.getWriter().close();
					return;
				}
				InputStream unsecureIn = veraProtectionUtil.getVeraFileContentAsStream(getFileContentAsStream(fields),currentLoginUserName,veraDocId);
				nodeRef = uploadFile(registry, fileName, parentRef, metadataJsonObject, unsecureIn, mimetype);
				if((registry.getNodeService().exists(nodeRef))){
					applyVeraProtectionOnDoc(nodeRef);
				}
			} else {
				nodeRef = uploadFile(registry, fileName, parentRef, metadataJsonObject, in, mimetype);
			}
			//Added by veerai for US10103 - start
			JSONObject invalidDataJSON = new JSONObject();
			JSONObject invalidPropertyJSONObject = ServiceUtil.getInvalidMetadataProperties(metadataJsonObject,registry);
			if(invalidPropertyJSONObject.length()>0){
				invalidDataJSON.put("metadata", invalidPropertyJSONObject);	
			}

			if(null!= permissionJsonArray && permissionJsonArray.length()>0){
				JSONArray invalidPermissionJson = ServiceUtil.getCustomInvalidPermission(permissionJsonArray, registry);
				if(invalidPermissionJson.length()>0){
					invalidDataJSON.put("permissions", invalidPermissionJson);	
				}
			}
			if(invalidDataJSON.length()>0){
				log.error(formatter.format(new Date()) + "  :: invalidData :: " + invalidDataJSON.toString());
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("edcsId", "");
				responseObject.put("message", "");
				responseObject.put("invalidData", invalidDataJSON);
				responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_METATDATA);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;		
			}
			//Added by veerai for US10103 - end

			if (null == nodeRef){
				log.error(formatter.format(new Date()) + "  :: Error while uploading ---- UNABLE TO WRITE NODEREF");
				res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", "Content writing failed.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}

			Map<QName, Serializable> propMap = new HashMap<QName, Serializable>();
			propMap.put(qNameMap.get("title"), registry.getNodeService().getProperty(nodeRef, qNameMap.get("title")));
			propMap.put(qNameMap.get("description"), registry.getNodeService().getProperty(nodeRef, qNameMap.get("description")));
			propMap.put(qNameMap.get("docType"), registry.getNodeService().getProperty(nodeRef, qNameMap.get("docType")));
			propMap.put(qNameMap.get("securityLevel"), registry.getNodeService().getProperty(nodeRef, qNameMap.get("securityLevel")));
			propMap.put(qNameMap.get("theatre"), registry.getNodeService().getProperty(nodeRef, qNameMap.get("theatre")));
			propMap.put(qNameMap.get("status"), registry.getNodeService().getProperty(nodeRef, qNameMap.get("status")));
			propMap.put(ContentModel.PROP_CREATOR, registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_CREATOR));
			registry.getVersionService().ensureVersioningEnabled(nodeRef, propMap);
			String versionRef = null;
			if(registry.getVersionService()
					.getVersionHistory(nodeRef)!=null){
				Collection<Version> versionList = registry.getVersionService()
						.getVersionHistory(nodeRef).getAllVersions();
				for (Version version : versionList) {
					versionRef = String.valueOf(version.getFrozenStateNodeRef());
				}
			}
			if(!registry.getNodeService().exists(nodeRef)){
				log.error(formatter.format(new Date()) + "  :: Error while uploading ---- UNABLE TO WRITE NODEREF");
				res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", "Content writing failed.");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}			
			log.info(formatter.format(new Date()) + "  :: Upload successful. new noderef:: " + nodeRef +"  VersionRef:: " + versionRef );

			if (null!= permissionJsonArray && permissionJsonArray.length()>0){
				for(int i = 0 ; i< permissionJsonArray.length(); i++){
					JSONObject permissionJsonObject = (JSONObject) permissionJsonArray.get(i);
					registry.getPermissionService().setPermission(nodeRef, permissionJsonObject.getString("authority"), ServiceConstants.PERMISSION_MAP.get(permissionJsonObject.getString("permission").toLowerCase()), true);
				}
			}

			responseObject.put("nodeRef", String.valueOf(nodeRef));
			responseObject.put("versionRef", versionRef);
			responseObject.put("edcsId", String.valueOf(registry.getNodeService().getProperty(nodeRef, CiscoModelConstants.PROP_ALF_ID)));
			responseObject.put("message", "Successfully uploaded your file.");
			responseObject.put("error", "");

			res.setContentType("application/json");
			res.getWriter().write(responseObject.toString());
			res.getWriter().close();

		} catch (Exception e) {
			log.error(formatter.format(new Date()) + "  *UPLOAD SERVICE*: Error from " + this.getClass().getCanonicalName()
					+ ":: \n" + e.fillInStackTrace());
			e.printStackTrace();
			res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
			try {
				responseObject.put("versionRef", "");
				responseObject.put("versionLabel", "");
				responseObject.put("message", "");
				responseObject.put("edcsId", "");
				responseObject.put("error", ErrorStatus.STATUS_MSG_FAILURE);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			} catch (JSONException e1) {
				e1.printStackTrace();
				return;
			}
		}
	}

	private NodeRef uploadFile(final ServiceRegistry registry,
			final String fileName, final NodeRef parentRef,
			final JSONObject metadataJsonObject, final InputStream in, final String mimetype) {

		return registry.getTransactionService().getRetryingTransactionHelper().doInTransaction(
				new RetryingTransactionHelper.RetryingTransactionCallback<NodeRef>() {
					public NodeRef execute() throws Throwable {
						log.debug("Upload: Executing transaction. File Name: " + fileName);
						NodeRef newNodeRef=null;
						String newFileName = fileName;
						try {
							NodeRef tempNodeRef = registry.getNodeService().getChildByName(parentRef, ContentModel.ASSOC_CONTAINS, fileName);
							if (null != tempNodeRef){
								if(fileName.lastIndexOf(".")>0){
									String extensionString = fileName.substring(fileName.lastIndexOf("."));
									newFileName = fileName.substring(0, fileName.lastIndexOf(".")) + "-" + sdt.format(new Date())  + extensionString;									
								}
								else{
									newFileName = fileName.substring(0, fileName.lastIndexOf(".")) + "-" + sdt.format(new Date());
								}

							}
							log.debug("Final File name:: " + newFileName);
							newNodeRef = (registry.getFileFolderService().create(parentRef,newFileName,ServiceConstants.TYPE_CISCODOCS)).getNodeRef();
							log.debug("NodeRef:: " + newNodeRef);

							ContentWriter writer = registry.getContentService().getWriter(newNodeRef, ContentModel.TYPE_CONTENT, true);
							writer.setMimetype(mimetype);
							writer.putContent(in);
							registry.getNodeService().addAspect(newNodeRef, ServiceConstants.ASPECT_CISCOMETADATA, null);
							registry.getNodeService().setType(newNodeRef, ServiceConstants.TYPE_CISCODOCS);
							registry.getNodeService().addAspect(newNodeRef, ContentModel.ASPECT_AUDITABLE, null);
							registry.getNodeService().addAspect(newNodeRef, ContentModel.ASPECT_REFERENCEABLE, null);
							String title;
							if(metadataJsonObject.has("title")){
								title = metadataJsonObject.getString("title");
							}else{
								title = newFileName;
							}
							registry.getNodeService().setProperty(newNodeRef, qNameMap.get("title"), title);
							if(metadataJsonObject.has("description")){
								registry.getNodeService().setProperty(newNodeRef, qNameMap.get("description"), ((String) metadataJsonObject.get("description")).trim());
							}else{
								registry.getNodeService().setProperty(newNodeRef, qNameMap.get("description"), newFileName);
							}
							registry.getNodeService().setProperty(newNodeRef, qNameMap.get("docType"),(String) metadataJsonObject.get("docType"));
							registry.getNodeService().setProperty(newNodeRef, qNameMap.get("securityLevel"), (String) metadataJsonObject.get("securityLevel"));
							registry.getNodeService().setProperty(newNodeRef, qNameMap.get("theatre"),(String) metadataJsonObject.get("theatre"));
							registry.getNodeService().setProperty(newNodeRef,qNameMap.get("status"), (String) metadataJsonObject.get("status"));
							registry.getNodeService().setProperty(newNodeRef, ContentModel.PROP_CREATOR, registry.getAuthenticationService().getCurrentUserName());
							return newNodeRef;
						} catch (Exception e) {
							log.error("Error while uploading:: \n" + e.fillInStackTrace());
							e.printStackTrace();
							return null;
						}

					}

				}, false, true);
	}

	private InputStream getFileContentAsStream(final FormData.FormField[] fields){
		InputStream instrm = null;
		for (FormData.FormField field : fields) {
			if (field.getName().equals("file") && field.getIsFile()) {
				instrm = field.getInputStream();

			}
		}
		return instrm;
	}

	private void applyVeraProtectionOnDoc(NodeRef sourceNodeRef){
		Map<QName, Serializable> verDocumentProtectionProps = new HashMap<>(1);
		verDocumentProtectionProps.put(ExternalSharingConstants.PROP_IS_DOCUMENT_VERA_PROTECTED, true);
		registry.getNodeService().addAspect(sourceNodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION, verDocumentProtectionProps);
	}
}

