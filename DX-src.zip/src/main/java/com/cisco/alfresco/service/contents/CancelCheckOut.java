package com.cisco.alfresco.service.contents;

import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.service.constants.ErrorStatus;


public class CancelCheckOut extends AbstractWebScript {
	protected ServiceRegistry registry;

	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

	final Logger log = Logger.getRootLogger();
	private DateFormat formatter = DateFormat.getDateTimeInstance( DateFormat.FULL, 
            DateFormat.FULL, 
            Locale.US);

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res)
			throws IOException {
		String nodeRefString = req.getParameter("nodeRef");
		JSONObject responseObject = new JSONObject();
		try {
			NodeRef nodeRef = null;
			boolean isCheckout = false;
			log.info(formatter.format(new Date()) + "  :: Cancle checkout called for noderef/versionref/PATH:: " + nodeRef);

			if (null == nodeRefString || "".equals(nodeRefString.trim())) {
				log.error(formatter.format(new Date()) + "  :: Invalid noderef/versionref/PATH:: " + nodeRef);
				res.setStatus(ErrorStatus.STATUS_CODE_NULL_NODEREF);
				responseObject.put("isSuccess", false);
				responseObject.put("error", ErrorStatus.STATUS_MSG_NULL_NODEREF);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}

			try {
				nodeRef = new NodeRef(nodeRefString);
				if (!registry.getNodeService().exists(nodeRef)){
					log.error(formatter.format(new Date()) + "  :: Invalid noderef/versionref/PATH:: " + nodeRef);
					res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
					responseObject.put("isSuccess", false);
					responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
					res.getWriter().write(responseObject.toString());
					res.setContentType("application/json");
					res.getWriter().close();
					return;
				}

			} catch (Exception e) {
				log.error(formatter.format(new Date()) + "  :: Invalid noderef/versionref/PATH:: " + nodeRef);
				res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
				responseObject.put("isSuccess", false);
				responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
			
			if(nodeRefString.indexOf("version")>=0){
				String CurrentVerionRef = registry.getVersionService().getVersionHistory(nodeRef).getHeadVersion().getFrozenStateNodeRef().toString();
				log.error("Latest VerionRef::"+CurrentVerionRef);
				//added by utmahesh for DE4961
				if(!(CurrentVerionRef).equalsIgnoreCase(nodeRefString)){
					log.error("Old verionRef ::"+nodeRefString);
					log.error(formatter.format(new Date()) + "  :: Check out: invalid versionRef:: " + nodeRefString);
					try {
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_CANCEL_CHECKOUT);
						responseObject.put("isSuccess", false);
						responseObject.put("error","Cancel Checkout should perform on latest versionRef only.");
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return;
					} catch (JSONException e) {
						e.printStackTrace();
					}
					//closed by utmahesh for DE4961
				}
				nodeRef = registry.getVersionService().getCurrentVersion(nodeRef).getVersionedNodeRef();
				log.info(formatter.format(new Date()) + "  :: Cancle checkout-Actual NodeRef:: " + nodeRef);
			}
			String versionRef = registry.getVersionService().getCurrentVersion(nodeRef).getFrozenStateNodeRef().toString();

			isCheckout = registry.getCheckOutCheckInService().isCheckedOut(
						nodeRef);
			log.info(formatter.format(new Date()) + "  :: " + nodeRef + " isCheckedOut? " + isCheckout);
			if (isCheckout) {
				NodeRef workingNodeRef = registry.getCheckOutCheckInService()
						.getWorkingCopy(nodeRef);
				NodeRef nodeRefNew = registry.getCheckOutCheckInService()
						.cancelCheckout(workingNodeRef);
				String versionUUID =  versionRef.substring(versionRef.lastIndexOf("/") +1 );
				String versionStoreStr = registry.getVersionService().getVersionStoreReference()+ "/" + versionUUID;
				registry.getNodeService().removeAspect(new NodeRef(versionStoreStr), ContentModel.ASPECT_CHECKED_OUT);
				registry.getNodeService().removeAspect(new NodeRef(versionStoreStr), ContentModel.ASPECT_LOCKABLE);
				
				responseObject.put("isSuccess", !registry.getCheckOutCheckInService().isCheckedOut(nodeRefNew));
				responseObject.put("error", "");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			} 
			log.error(formatter.format(new Date()) + "  :: CancelCheckout failed!! Noderef=" + nodeRefString);
			res.setStatus(ErrorStatus.STATUS_CODE_INVALID_CANCEL_CHECKOUT);
			responseObject.put("isSuccess", false);
			responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_CANCEL_CHECKOUT);
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			return;
		} catch (JSONException e) {
			log.error(formatter.format(new Date()) + "  :: CancelCheckout failed for jsonParsing!! Noderef=" + nodeRefString);
			res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
			try {
				responseObject.put("isSuccess", false);
				responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_NODEREF);
			} catch (JSONException e1) {
				e1.printStackTrace();
			}
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			return;
		}

	}
}
