package com.cisco.alfresco.auth.ext;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.log4j.Logger;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.springframework.util.StringUtils;

/**
 * 
 * @author nabbeher
 *
 */
public final class EXTEncrypter {
	private static final Logger logger = Logger.getLogger(EXTEncrypter.class);
	/**
	 * 
	 * @param val
	 * @return
	 * @throws UnknownHostException 
	 */
	public static String encrypt(String val) throws UnknownHostException{
		String encryptedValue = null;
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword(InetAddress.getLocalHost().toString());
		logger.info(InetAddress.getLocalHost());
		encryptedValue = encryptor.encrypt(val);
		logger.info("Encryption done and encrypted password is : " + encryptedValue );

		return encryptedValue;
	}
	
	public static String encrypt(String val, String key) throws UnknownHostException{
		String encryptedValue = null;
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword(key);
		encryptedValue = encryptor.encrypt(val);
		logger.info("Encryption done and encrypted password is : " + encryptedValue );

		return encryptedValue;
	}
	
	public static String decrypt(String val) throws UnknownHostException{
		String decryptedPropertyValue = null; 
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		String[] strValArray = StringUtils.split(val, " ");
		encryptor.setPassword(strValArray[0]);
		decryptedPropertyValue = encryptor.decrypt(strValArray[1]);

		logger.info(decryptedPropertyValue); 
		return decryptedPropertyValue;
		}
	
	
	public static String decrypt(String val, String key) throws UnknownHostException{
		String decryptedPropertyValue = null;
		logger.info("String to decrypt :"+val.substring(0,3)+"*****: Key "+key.substring(0,3)+"*******");
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		//String[] strValArray = StringUtils.split(val, " ");
		encryptor.setPassword(key);
		decryptedPropertyValue = encryptor.decrypt(val);
		//logger.info(decryptedPropertyValue); 
		return decryptedPropertyValue;
		}
	
}
