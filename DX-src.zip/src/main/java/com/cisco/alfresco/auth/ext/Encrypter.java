package com.cisco.alfresco.auth.ext;

import java.net.UnknownHostException;

public class Encrypter {
	public static void main(String args[]) throws Exception{
	
	EXTEncrypter entext=new EXTEncrypter();
	/*try {
		if(args.length > 0)
		{*/
			//String encryptVal = entext.encrypt("Alfresco4!T","9AE1378B2718BDEAAEFFA4AD72353");   
			String encryptVal = entext.encrypt("Alfresco2K@");
			System.out.println("Encrytped string:");
			System.out.println(encryptVal);
		/*}else 
			*/System.out.println("Please enster text to encrypt in command line.");
		
	/*} catch (UnknownHostException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/
	}
}
