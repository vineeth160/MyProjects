package com.cisco.alfresco.auth.ext;

import org.apache.commons.httpclient.Cookie;
import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.log4j.Logger;


/**
 * 
 * This class is to validate the given OAM Cookie with SSO. It passes the oam cookie to sso and gets response on whether
 * it is valid or not. On successfull validation, it returns the user name of the cookie.
 * 
 * @author pobabu
 * 
 */
public class OAMValidation
{
    private static final Logger LOGGER = Logger.getLogger(OAMValidation.class);
    private static final String USERID_COOKIE = "USERID_COOKIE";

    /**
     * Main method to call for validation.
     * 
     * @param oamCookie
     * @return
     */
    public String getOAMAuthenticatedUser(String oamCookie, String oamUrl)
    {
        HttpClient client = null;
        GetMethod getMethod = null;
        byte[] responseStream = null;

        try
        {

            LOGGER.info("Checking OAM with SSO URL");

            LOGGER.info("oamCookie:" + oamCookie);
            LOGGER.info("oamUrl:" + oamUrl);
            getMethod = new GetMethod(oamUrl);

            getMethod.setRequestHeader(new Header("Cookie", "ObSSOCookie=" + oamCookie));

            client = new HttpClient();

            int responseCode = client.executeMethod(getMethod);
            LOGGER.info("Response code:" + responseCode);
            responseStream = getMethod.getResponseBody();

            Cookie[] cookies = client.getState().getCookies();

            String resStr = null;
            if (responseStream == null)
            {
                LOGGER.info("Response from " + oamUrl + " is null");
                return null;

            }
            else
            {

                resStr = new String(responseStream);
                LOGGER.info("Response from SSO:" + resStr);

            }

            if (cookies == null || cookies.length == 0)
            {
                LOGGER.info("cookies are null while validating the cookie" + oamCookie);
                return null;
            }
            else if (!resStr.trim().equalsIgnoreCase("OAM Session is valid"))
            {
                LOGGER.info("OAM Cookie is invalid:" + resStr);
                return null;
            }
            else
            {
                for (Cookie c : cookies)
                {
                    if (USERID_COOKIE.equals(c.getName()))
                        return c.getValue();
                }
            }

        }
        catch (Exception e)
        {
            LOGGER.error("Exception " + e);
        }
        finally
        {
            if (getMethod != null)
            {
                try
                {
                    getMethod.releaseConnection();
                }
                catch (Exception e)
                {
                    LOGGER.error("Exception " + e);
                }
            }
            client = null;
        }

        return null;
    }

}
