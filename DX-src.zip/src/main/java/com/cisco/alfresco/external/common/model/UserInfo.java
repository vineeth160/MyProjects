package com.cisco.alfresco.external.common.model;

import com.cisco.alfresco.external.common.util.USERTYPE;


public class UserInfo
{

    private USERTYPE userType;

    private String firstName;
    private String lastName;
    private String email;
    private String company;
    private String userId;
    private boolean hasAccepted;
    private boolean isAdmin;
    private String geoLocationURL;
    private String geoLocation;
    private boolean isUserVeraAdmin;
    private String geoHostName;
    private String hostName;
    
	private String docExchangeJivePage;
	private String docExchangeFAQPage;
    private String gettingStartedGuide;
    private String emailSupport;
    private String remedyCaseURL;
    private String inTouchPage;
    private String liveChatSupport;
    private boolean optOutEmailNotification;
    private boolean isOpsSupportUser = false;
    private boolean dxServerIsRunning;
    private boolean isAccessTokenValid;

	
    
	public boolean isOptOutEmailNotification() {
		return optOutEmailNotification;
	}
	public boolean isAccessTokenValid() {
		return isAccessTokenValid;
	}

	public void setAccessTokenValid(boolean isAccessTokenValid) {
		this.isAccessTokenValid = isAccessTokenValid;
	}
	public boolean isDxServerIsRunning() {
		return dxServerIsRunning;
	}
	public void setDxServerIsRunning(boolean dxServerIsRunning) {
		this.dxServerIsRunning = dxServerIsRunning;
		// TODO Auto-generated method stub
		
	}

	public void setOptOutEmailNotification(boolean optOutEmailNotification) {
		this.optOutEmailNotification = optOutEmailNotification;
	}
    public String getLiveChatSupport() {
		return liveChatSupport;
	}

	public void setLiveChatSupport(String liveChatSupport) {
		this.liveChatSupport = liveChatSupport;
	}

	public String getInTouchPage() {
		return inTouchPage;
	}

	public void setInTouchPage(String inTouchPage) {
		this.inTouchPage = inTouchPage;
	}

	public String getDocExchangeJivePage() {
		return docExchangeJivePage;
	}

	public void setDocExchangeJivePage(String docExchangeJivePage) {
		this.docExchangeJivePage = docExchangeJivePage;
	}

	public String getDocExchangeFAQPage() {
		return docExchangeFAQPage;
	}

	public void setDocExchangeFAQPage(String docExchangeFAQPage) {
		this.docExchangeFAQPage = docExchangeFAQPage;
	}

	public String getGettingStartedGuide() {
		return gettingStartedGuide;
	}

	public void setGettingStartedGuide(String gettingStartedGuide) {
		this.gettingStartedGuide = gettingStartedGuide;
	}

	public String getEmailSupport() {
		return emailSupport;
	}

	public void setEmailSupport(String emailSupport) {
		this.emailSupport = emailSupport;
	}

	public String getRemedyCaseURL() {
		return remedyCaseURL;
	}

	public void setRemedyCaseURL(String remedyCaseURL) {
		this.remedyCaseURL = remedyCaseURL;
	}

	
    
    
	public String getGeoHostName() {
		return geoHostName;
	}

	public void setGeoHostName(String geoHostName) {
		this.geoHostName = geoHostName;
	}

    public String getGeoLocation() {
		return geoLocation;
	}

	public void setGeoLocation(String geoLocation) {
		this.geoLocation = geoLocation;
	}

	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public boolean isHasAccepted()
    {
        return hasAccepted;
    }

    public void setHasAccepted(boolean hasAccepted)
    {
        this.hasAccepted = hasAccepted;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getCompany()
    {
        return company;
    }

    public void setCompany(String company)
    {
        this.company = company;
    }

    public String getUserId()
    {
        return userId;
    }

    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    public USERTYPE getUserType()
    {
        return userType;
    }

    public void setUserType(USERTYPE userType)
    {
        this.userType = userType;
    }
	public String getGeoLocationURL() {
		return geoLocationURL;
	}

	public void setGeoLocationURL(String geoLocationURL) {
		this.geoLocationURL = geoLocationURL;
	}

	public boolean isUserVeraAdmin() {
		return isUserVeraAdmin;
	}

	public void setUserVeraAdmin(boolean isUserVeraAdmin) {
		this.isUserVeraAdmin = isUserVeraAdmin;
	}

	public boolean isOpsSupportUser() {
		return isOpsSupportUser;
	}

	public void setOpsSupportUser(boolean isOpsSupportUser) {
		this.isOpsSupportUser = isOpsSupportUser;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;						
	}
	public String getHostName() {
		return hostName;
	}



	
	
	

}
