package com.cisco.alfresco.external.common.util;

public enum USERTYPE
{
    INTERNAL,
    EXTERNAL,
    GENERIC,
    INVALID_USER
}
