package com.cisco.alfresco.external.common.model;

import java.util.Collections;
import java.util.List;


public class WorkflowHistoryVO
{
    private String fileName;
    private String title;
    private String version;
    private String edcsId;
    private String docStatus;

    public String getDocStatus()
    {
        return docStatus;
    }

    public void setDocStatus(String docStatus)
    {
        this.docStatus = docStatus;
    }

    private String wfCategory;
    // private String wfType;
    private String workflowAction;
    private String wfStatus;

    private String requestDate;
    private String dueDate;
    private String completedDate;

    private String requestorId;
    private String requestorName;
    private String requestorEmail;

    public String getRequestorEmail()
    {
        return requestorEmail;
    }

    public void setRequestorEmail(String requestorEmail)
    {
        this.requestorEmail = requestorEmail;
    }

    // private String approver;
    private String reviewer;
    private String comment;

    private List<ApproverDetail> approvers;

    private String participant; // US 4418 -4 - Saranyan

    /**
     * Constructor
     */
    public WorkflowHistoryVO()
    {
        super();
        this.fileName = "";
        this.title = "";
        this.version = "";
        this.wfCategory = "";
        // this.wfType = "";
        this.workflowAction = "";
        this.wfStatus = "";
        this.requestDate = "";
        this.dueDate = "";
        this.completedDate = "";
        this.requestorId = "";
        this.requestorName = "";
        this.requestorEmail = "";
        this.reviewer = "";
        this.comment = "";
        this.participant = ""; // US 4418 -5 - Saranyan
        this.docStatus = "";
        this.approvers = Collections.EMPTY_LIST;
    }

    /**
     * @return the fileName
     */
    public String getFileName()
    {
        return fileName;
    }

    /**
     * @param fileName
     *            the fileName to set
     */
    public void setFileName(String fileName)
    {
        this.fileName = fileName;
    }

    /**
     * @return the title
     */
    public String getTitle()
    {
        return title;
    }

    /**
     * @param title
     *            the title to set
     */
    public void setTitle(String title)
    {
        this.title = title;
    }

    /**
     * 
     * @return
     */
    public String getVersion()
    {
        return version;
    }

    /**
     * 
     * @param version
     */
    public void setVersion(String version)
    {
        this.version = version;
    }

    /**
     * @return the edcsid
     */
    public String getEdcsId()
    {
        return edcsId;
    }

    /**
     * @param edcsId
     *            the revision to set
     */
    public void setEdcsId(String edcsId)
    {
        this.edcsId = edcsId;
    }

    /**
     * @return the wfCategory
     */
    public String getWfCategory()
    {
        return wfCategory;
    }

    /**
     * @param wfCategory
     *            the wfCategory to set
     */
    public void setWfCategory(String wfCategory)
    {
        this.wfCategory = wfCategory;
    }

    /**
     * @return the wfType
     */
    /*
     * public String getWfType() { return wfType; }
     *//**
     * @param wfType
     *            the wfType to set
     */
    /*
     * public void setWfType(String wfType) { this.wfType = wfType; }
     */
    /**
     * @return the wfActionOutCome
     */
    public String getWorkflowAction()
    {
        return workflowAction;
    }

    /**
     * @param wfActionOutCome
     *            the wfActionOutCome to set
     */
    public void setWorkflowAction(String workflowAction)
    {
        this.workflowAction = workflowAction;
    }

    /**
     * @return the wfStatus
     */
    public String getWfStatus()
    {
        return wfStatus;
    }

    /**
     * @param wfStatus
     *            the wfStatus to set
     */
    public void setWfStatus(String wfStatus)
    {
        this.wfStatus = wfStatus;
    }

    /**
     * @return the dateOfRequest
     */
    public String getRequestDate()
    {
        return requestDate;
    }

    /**
     * @param dateOfRequest
     *            the dateOfRequest to set
     */
    public void setRequestDate(String requestDate)
    {
        this.requestDate = requestDate;
    }

    /**
     * @return the dueDate
     */
    public String getDueDate()
    {
        return dueDate;
    }

    /**
     * @param dueDate
     *            the dueDate to set
     */
    public void setDueDate(String dueDate)
    {
        this.dueDate = dueDate;
    }

    /**
     * @return the completedDate
     */
    public String getCompletedDate()
    {
        return completedDate;
    }

    /**
     * @param completedDate
     *            the completedDate to set
     */
    public void setCompletedDate(String completedDate)
    {
        this.completedDate = completedDate;
    }

    /**
     * 
     * @return
     */
    public List<ApproverDetail> getApprovers()
    {
        return approvers;
    }

    /**
     * 
     * @param approvers
     */
    public void setApprovers(List<ApproverDetail> approvers)
    {
        this.approvers = approvers;
    }

    /**
     * @return the reviewer
     */
    public String getReviewer()
    {
        return reviewer;
    }

    /**
     * @param reviewer
     *            the reviewer to set
     */
    public void setReviewer(String reviewer)
    {
        this.reviewer = reviewer;
    }

    /**
     * @return the comment
     */
    public String getComment()
    {
        return comment;
    }

    /**
     * @param comment
     *            the comment to set
     */
    public void setComment(String comment)
    {
        this.comment = comment;
    }

    // US 4418 -6

    /**
     * @return the participant
     */
    public String getParticipant()
    {
        return participant;
    }

    /**
     * @param reviewer
     *            the reviewer to set
     */
    public void setParticipant(String participant)
    {
        this.participant = participant;
    }

    /**
     * 
     * @return
     */
    public String getRequestorId()
    {
        return requestorId;
    }

    /**
     * 
     * @param requestorId
     */
    public void setRequestorId(String requestorId)
    {
        this.requestorId = requestorId;
    }

    /**
     * 
     * @return
     */
    public String getRequestorName()
    {
        return requestorName;
    }

    /**
     * 
     * @param requestorName
     */
    public void setRequestorName(String requestorName)
    {
        this.requestorName = requestorName;
    }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("WorkflowHistoryVO [fileName=")
                    .append(fileName)
                    .append(", title=")
                    .append(title)
                    .append(", version=")
                    .append(version)
                    .append(", edcsId=")
                    .append(edcsId)
                    .append(", docStatus=")
                    .append(docStatus)
                    .append(", wfCategory=")
                    .append(wfCategory)
                    .append(", workflowAction=")
                    .append(workflowAction)
                    .append(", wfStatus=")
                    .append(wfStatus)
                    .append(", requestDate=")
                    .append(requestDate)
                    .append(", dueDate=")
                    .append(dueDate)
                    .append(", completedDate=")
                    .append(completedDate)
                    .append(", requestorId=")
                    .append(requestorId)
                    .append(", requestorName=")
                    .append(requestorName)
                    .append(", requestorEmail=")
                    .append(requestorEmail)
                    .append(", reviewer=")
                    .append(reviewer)
                    .append(", comment=")
                    .append(comment)
                    .append(", approvers=")
                    .append(approvers)
                    .append(", participant=")
                    .append(participant)
                    .append("]");
        return builder.toString();
    }

}
