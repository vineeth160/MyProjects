package com.cisco.alfresco.external.webscript;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.QName;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.sd.rest.service.MigrationConstants;

public class FolderMoveWS extends AbstractWebScript {

	protected static final Logger log = Logger.getLogger(FolderMoveWS.class);
	private ServiceRegistry serviceRegistry;

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public void execute(WebScriptRequest request, WebScriptResponse response) throws IOException {

		JSONObject jsonObject = null;
		String targetFolderRefString = null, actionNodeRefString = null, isInheritPermissions = null, moveReasonMsg = null;
		String inputJSONValue = readRequestBody(request);
		try {
			 jsonObject = new JSONObject(inputJSONValue);
			 targetFolderRefString = jsonObject.getString("targetNodeRef");
			 actionNodeRefString = jsonObject.getString("actionNodeRef");
			 isInheritPermissions = jsonObject.getString("isInheritPerm");
			 moveReasonMsg = jsonObject.getString("moveComment");
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		log.info("targetFolderRefString------"+targetFolderRefString +" --  actionNodeRefString---"+actionNodeRefString);

		try {

			if (!isValueExist(targetFolderRefString) || !isValueExist(actionNodeRefString)) {
				throw new WebScriptException(
						"Empty noderef in the Request" + targetFolderRefString + actionNodeRefString);
			}

			if (!isValueExist(moveReasonMsg)) {
				throw new WebScriptException("mandatory parameter move reason is eigther null or missing");
			}

			if (!isValueExist(isInheritPermissions)) {
				throw new WebScriptException("mandatory parameter isInheritPerm is eigther null or missing");
			}

			final NodeRef actionFolderRef = new NodeRef(actionNodeRefString);
			final NodeRef targetFolderRef = new NodeRef(targetFolderRefString);
			
			if (!serviceRegistry.getNodeService().exists(actionFolderRef)
					|| !serviceRegistry.getNodeService().exists(targetFolderRef)) {
				throw new WebScriptException("Invalid NodeRef in the Request or node does not exist");
			}

			String currentLoginUser = AuthenticationUtil.getFullyAuthenticatedUser();

			if (!checkPermissionOnNodeRef(currentLoginUser, actionFolderRef)) {
				throw new WebScriptException("you do not have folderadmin permission to move this Folder");
			}

			if (!checkPermissionOnNodeRef(currentLoginUser, targetFolderRef)) {
				throw new WebScriptException("you do not have folderadmin permission on target folder");
			}

			// need to check child already exist or not
			String actionNodeRefName = (String) serviceRegistry.getNodeService().getProperty(actionFolderRef,
					ContentModel.PROP_NAME);
			NodeRef childExistRef = serviceRegistry.getFileFolderService().searchSimple(targetFolderRef,
					actionNodeRefName);

			if (childExistRef != null) {
				throw new WebScriptException(
						"Folder with " + actionNodeRefName + " already exist in the target folder.");
			}

			AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				@Override
				public Object doWork() throws Exception {
					final FileInfo messageFile = serviceRegistry.getFileFolderService().move(actionFolderRef,
							targetFolderRef, null);
					return null;
				}
			}, AuthenticationUtil.getSystemUserName());

			// update the movereason and inherit permission value on moving node.
			serviceRegistry.getPermissionService().setInheritParentPermissions(actionFolderRef,
					Boolean.valueOf(isInheritPermissions));

			// domain update.
			String targetFolderDomainProp = (String) serviceRegistry.getNodeService().getProperty(targetFolderRef,
					MigrationConstants.CISCO_DOMAIN_NAME_PROP);
			
			if (serviceRegistry.getNodeService().hasAspect(actionFolderRef, MigrationConstants.CISCO_DOMAIN_ASPECT)) {
				if (isValueExist(targetFolderDomainProp)) {
					String sourceDomainProperty = (String) serviceRegistry.getNodeService().getProperty(actionFolderRef,
							MigrationConstants.CISCO_DOMAIN_NAME_PROP);
					
					StringBuilder sourceDomainPropertyBuilder = new StringBuilder();
					if (isValueExist(sourceDomainProperty)) {
						String[] targetFolderDomainPropertyArray = targetFolderDomainProp.split(",");
						sourceDomainPropertyBuilder.append(sourceDomainProperty);
						for(int j = 0; j < targetFolderDomainPropertyArray.length; j++)
                        {
						if (!sourceDomainPropertyBuilder.toString()
								.contains(targetFolderDomainPropertyArray[j].trim())) {
							log.info("domain " + targetFolderDomainPropertyArray[j]
									+ " Not Present on souce directory:");
							sourceDomainPropertyBuilder.append("," + targetFolderDomainPropertyArray[j].trim());
						}
                        }
					} else {
						sourceDomainPropertyBuilder.append(targetFolderDomainProp);
					}
					//log.info("sourceDomainPropertyBuilder------------"+sourceDomainPropertyBuilder);
					serviceRegistry.getNodeService().setProperty(actionFolderRef,
							MigrationConstants.CISCO_DOMAIN_NAME_PROP, sourceDomainPropertyBuilder.toString());
				}

			} else {
				Map<QName, Serializable> parentDomainValues = new HashMap<QName, Serializable>();
				parentDomainValues.put(MigrationConstants.CISCO_DOMAIN_NAME_PROP, targetFolderDomainProp);
				serviceRegistry.getNodeService().addAspect(actionFolderRef, MigrationConstants.CISCO_DOMAIN_ASPECT,
						parentDomainValues);
			}
			
			 //adding disableguestUser prop to the node
			Boolean targetDisableguestUserProp =  (Boolean) serviceRegistry.getNodeService().getProperty(targetFolderRef,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}disableguestUser"));
			serviceRegistry.getNodeService().setProperty(actionFolderRef,
					QName.createQName("{http://www.alfresco.org/model/external/content/1.0}disableguestUser"),
					targetDisableguestUserProp);
			
			
			log.info("inhirit parent folder permissions making " + Boolean.valueOf(isInheritPermissions) + " On : "
					+ actionNodeRefName + " ; ");

			JSONObject json = new JSONObject();
			json.put("actionFolderRef", actionFolderRef);
			json.put("targetFolderRef", targetFolderRefString);
			json.put("isError", false);
			json.put("statusMessage", "folder " + actionNodeRefName + " moved sucessfully!!...");

			response.getWriter().write(json.toString());

		} catch (Exception ex) {
			log.error("Error found in FolderMoveWS", ex);
			JSONObject json = new JSONObject();
			try {
				json.put("isError", true);
				json.put("actionFolderRef", targetFolderRefString);
				json.put("targetFolderRef", actionNodeRefString);
				json.put("statusMessage", isValueExist(ex.getMessage()) ? ex.getMessage() : "unknown Server error");
				response.getWriter().write(json.toString());
			} catch (JSONException e) {
				log.error("Error found in JsonSerialization", ex);
				e.printStackTrace();
			}

		}

	}

	private boolean isValueExist(String fieldValue) {
		boolean valueExist = false;
		if (fieldValue != null && fieldValue.trim().length() != 0) {
			valueExist = true;
		}
		return valueExist;
	}

	private boolean checkPermissionOnNodeRef(final String loggedInUser, final NodeRef nodeRef) throws Exception {

		if (loggedInUser.equalsIgnoreCase("admin")) {
			return Boolean.TRUE;
		}

		boolean isUserHavePermission = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {

			@Override
			public Boolean doWork() throws Exception {
				String userRole = ExternalSharingFileFolderUtil.getUserRole(serviceRegistry, loggedInUser, nodeRef);
				log.info("userRole.. : " + userRole);
				if (("Owner").equals(userRole) || userRole.equals(UserRoleConstants.USER_ADMIN_ROLE)) {
					log.info("user.. : " + loggedInUser + " have.. : " + userRole + " On NodeRef... : " + nodeRef);
					return Boolean.TRUE;
				}
				return Boolean.FALSE;
			}
		}, AuthenticationUtil.getSystemUserName());

		return isUserHavePermission;
	}
	
	/**
	 * 
	 * @param req
	 * @return
	 */
	private String readRequestBody(WebScriptRequest req) {
		try {
			return IOUtils.toString(req.getContent().getInputStream(), req
					.getContent().getEncoding());
		} catch (Exception e) {
			try {
				return req.getContent().getContent();
			} catch (IOException e1) {
				log.error("Unable to read JSON request body", e1);
				throw new WebScriptException(
						"Unable to read JSON request body!! Epic fail.");
			}
		}
	}

}
