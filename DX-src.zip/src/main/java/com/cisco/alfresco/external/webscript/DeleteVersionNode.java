package com.cisco.alfresco.external.webscript;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.UserTransaction;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.version.Version2Model;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.rendition.RenditionService;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.thumbnail.ThumbnailService;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.cmr.version.VersionService;
import org.alfresco.service.cmr.workflow.WorkflowInstance;
import org.alfresco.service.cmr.workflow.WorkflowService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.sd.rest.service.MigrationConstants;


public class DeleteVersionNode extends DeclarativeWebScript
{

    private NodeService nodeService;
    private VersionService versionService;
    private NamespaceService namespaceService;
    private BehaviourFilter behaviourFilter;
    private WorkflowService workflowService;
    private ContentService contentService;
    private ThumbnailService thumbnailService;
    private RenditionService renditionService;
    private ServiceRegistry serviceRegistry;

    public RenditionService getRenditionService()
    {
        return renditionService;
    }

    public void setRenditionService(RenditionService renditionService)
    {
        this.renditionService = renditionService;
    }

    private static final Logger LOGGER = Logger.getLogger(DeleteVersionNode.class);

    public ThumbnailService getThumbnailService()
    {
        return thumbnailService;
    }

    public void setThumbnailService(ThumbnailService thumbnailService)
    {
        this.thumbnailService = thumbnailService;
    }

    public void setVersionService(VersionService versionService)
    {
        this.versionService = versionService;
    }

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    public void setNamespaceService(NamespaceService namespaceService)
    {
        this.namespaceService = namespaceService;
    }

    public void setBehaviourFilter(BehaviourFilter behaviourFilter)
    {
        this.behaviourFilter = behaviourFilter;
    }

    public void setWorkflowService(WorkflowService workflowService)
    {
        this.workflowService = workflowService;
    }

    public ContentService getContentService()
    {
        return contentService;
    }

    public void setContentService(ContentService contentService)
    {
        this.contentService = contentService;
    }

    @Override
    public Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
    {
        Map<String, Object> model = new HashMap<String, Object>();
        
        String creator;
        String nodeRefStr = req.getParameter("nodeRef");
        String deleteAll = req.getParameter("all");
        String message = "";
        
        
        if (nodeRefStr != null && !nodeRefStr.isEmpty())
        {
            NodeRef versionNodeRef = new NodeRef(nodeRefStr);
            LOGGER.debug(".........versionNodeRef............" + versionNodeRef);

            if (Version2Model.STORE_ID.equals(versionNodeRef.getStoreRef().getIdentifier())) // "version2Store"
            {
                versionNodeRef = new NodeRef(StoreRef.PROTOCOL_WORKSPACE, Version2Model.STORE_ID,
                        versionNodeRef.getId());
            }

            if (nodeService.exists(versionNodeRef))
            {

                Map<QName, Serializable> versionNodeProps = nodeService.getProperties(versionNodeRef);

                // -----------DE1590 start------------//
                creator = (String) versionNodeProps.get(ContentModel.PROP_CREATOR);

                // if
                // (Version2Model.STORE_ID.equals(versionNodeRef.getStoreRef()
                // .getIdentifier())) { // version2store
                //
                // LOGGER.debug("...............noderef storef identifier........"
                // + versionNodeRef.getStoreRef().getIdentifier());
                //
                // NodeRef frozenNodeRef = (NodeRef) nodeService.getProperty(
                // versionNodeRef,
                // Version2Model.PROP_QNAME_FROZEN_NODE_REF);
                //
                // LOGGER.debug("frozen:" + frozenNodeRef);
                // String versionLabel = (String) nodeService.getProperty(
                // versionNodeRef,
                // Version2Model.PROP_QNAME_VERSION_LABEL);
                //
                // if (versionLabel.equals("1.0")) {
                // creator = (String) nodeService.getProperty(
                // frozenNodeRef, ContentModel.PROP_OWNER);
                // } else {
                // creator = (String) versionNodeProps
                // .get(ContentModel.PROP_CREATOR);
                // }
                // }
                // ------------DE1590 end--------------//

                List<WorkflowInstance> activeWorkflows = workflowService.getWorkflowsForContent(versionNodeRef, true);

                Boolean isExternallyShared = false;
                if (nodeService.hasAspect(versionNodeRef, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT))
                {
                    isExternallyShared = (Boolean) versionNodeProps
                            .get(MigrationConstants.CISCO_EXTERNAL_IS_EXTERNALLY_SHARED_PROP);
                }

                if ((activeWorkflows != null && activeWorkflows.size() > 0)
                        || !AuthenticationUtil.getRunAsUser().equals(creator) || isExternallyShared)
                {

                    message = "You don't have permission to perform this operation";
                    LOGGER.debug(message);
                }
                else
                {
                    if (Version2Model.STORE_ID.equals(versionNodeRef.getStoreRef().getIdentifier())) // "version2Store"
                    {

                        NodeRef frozenNodeRef = (NodeRef) nodeService.getProperty(versionNodeRef,
                            Version2Model.PROP_QNAME_FROZEN_NODE_REF);

                        LOGGER.debug("frozen:" + frozenNodeRef);

                        if (deleteAll != null && !deleteAll.isEmpty() && Boolean.getBoolean(deleteAll))
                        {
                            // Delete the live node.
                            nodeService.deleteNode(frozenNodeRef);

                            message = "Current NodeRef deleted";
                            LOGGER.debug(message);
                        }
                        else
                        {
                            message = deleteVersion(versionNodeRef, frozenNodeRef);
                        }

                    }
                    else if (StoreRef.STORE_REF_WORKSPACE_SPACESSTORE.getIdentifier().equals(
                        versionNodeRef.getStoreRef().getIdentifier())) // "SpacesStore"
                    {

                        // Delete the live node.
                        nodeService.deleteNode(versionNodeRef);

                        message = "Current NodeRef deleted";
                        LOGGER.debug(message);
                    }
                    else
                    {
                        message = "Invalid NodeRef";
                        LOGGER.debug(message);

                    }
                }

            }
            else
            {
                message = "NodeRef does not exist";
                LOGGER.debug(message);
            }

        }
        else
        {
            message = "Invalid Input";
            LOGGER.debug(message);
        }

        model.put("message", message);
        return model;
    }

    private String deleteVersion(NodeRef versionNodeRef, final NodeRef frozenNodeRef)
    {
        LOGGER.debug("user requested version:" + versionNodeRef + ":::frozenNodeRef:" + frozenNodeRef);
        String message = "";

        VersionHistory versionHistory = versionService.getVersionHistory(frozenNodeRef);

        if (versionHistory != null)
        {
            LOGGER.debug("Current number of versions: " + versionHistory.getAllVersions().size());
            LOGGER.debug("least recent/root version: " + versionHistory.getRootVersion().getVersionLabel());
            LOGGER.debug("HEAD version: " + versionHistory.getHeadVersion().getVersionLabel());
            LOGGER.debug("Current version: " + versionService.getCurrentVersion(frozenNodeRef).getVersionLabel());

            String currentVersionLabel = (String) nodeService.getProperty(versionNodeRef,
                Version2Model.PROP_QNAME_VERSION_LABEL);

            if (versionHistory.getHeadVersion().getVersionLabel().equals(currentVersionLabel))
            {
                LOGGER.debug("HEAD version is equal current version");

                if (versionHistory
                        .getHeadVersion()
                            .getVersionLabel()
                            .equals(versionHistory.getRootVersion().getVersionLabel())
                        && versionHistory.getAllVersions().size() == 1)
                {
                    LOGGER.debug("HEAD version is equal Root version so deleting the live node");
                    // DE1590 - Saranyan - Start -2. deleteNode moved inside try
                    // catch
                    try
                    {
                        LOGGER.debug("............inside main try.........");
                        nodeService.deleteNode(frozenNodeRef);

                    }
                    catch (Exception e)
                    {

                        try
                        {
                            LOGGER.debug(".................inside try catch........");
                            AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
                            {
                                @Override
                                public Object doWork() throws Exception
                                {
                                    UserTransaction trx = serviceRegistry
                                            .getTransactionService()
                                                .getNonPropagatingUserTransaction(false);
                                    trx.begin();

                                    String currentUserName = AuthenticationUtil.getFullyAuthenticatedUser();
                                    serviceRegistry.getPermissionService().setPermission(frozenNodeRef,
                                        currentUserName.toString(), PermissionService.DELETE, true);
                                    nodeService.deleteNode(frozenNodeRef);

                                    trx.commit();

                                    LOGGER.debug("............after delete node after commit.....");
                                    return null;
                                }

                            }, "admin");

                        }
                        catch (Exception ex)
                        {
                            LOGGER.debug("###### Exception here ###### " + ex);
                        }

                    }
                    // DE1590 - Saranyan - End -2.
                }
                else
                {
                    /**
                     * HEAD version deletion steps: (if there are more than one version in VersionHistory) 1) Set the
                     * content & properties of PredecessorVersionNode to LiveNode 2) Delete the HEAD versionNode.
                     */
                    Version headVersion = versionHistory.getHeadVersion();
                    Version predecessorVersion = versionHistory.getPredecessor(headVersion);

                    Map<QName, Serializable> frozenNodeRefProp = (Map<QName, Serializable>) nodeService
                            .getProperties(frozenNodeRef);
                    Map<String, Serializable> predecessorVersionNodeRefProp = (Map<String, Serializable>) predecessorVersion
                            .getVersionProperties();

                    LOGGER.debug("------ frozenNodeRefProp  : " + frozenNodeRefProp.toString());

                    LOGGER.debug(" predecessorVersion: " + predecessorVersion.getVersionLabel());
                    LOGGER.debug("------ predecessorVersionNodeRefProp  : " + predecessorVersionNodeRefProp.toString());

                    try
                    {

                        // DE1584 - STARTS - Deepak
                        /**
                         * Disable ASPECT_VERSIONABLE to stop versioning and update the content on LiveNode from
                         * PredecessorVersionNode
                         */
                        LOGGER.debug("------ Disabling Version Behavior ------- ");
                        behaviourFilter.disableBehaviour(frozenNodeRef, ContentModel.ASPECT_VERSIONABLE);
                        behaviourFilter.disableBehaviour(frozenNodeRef, CiscoModelConstants.CISCO_MODEL);
                        

                        LOGGER.info("Deleting HEAD version : " + currentVersionLabel);

                        // Delete the head version
                        versionService.deleteVersion(frozenNodeRef, headVersion);

                        NodeRef predecessorVersionNodeRef = predecessorVersion.getFrozenStateNodeRef();

                        if (Version2Model.STORE_ID.equals(predecessorVersionNodeRef.getStoreRef().getIdentifier()))
                        // "version2Store"
                        {
                            predecessorVersionNodeRef = new NodeRef(StoreRef.PROTOCOL_WORKSPACE,
                                    Version2Model.STORE_ID, predecessorVersionNodeRef.getId());

                            ContentReader contentReader = contentService.getReader(predecessorVersionNodeRef,
                                ContentModel.PROP_CONTENT);
                            ContentWriter contentWriter = contentService.getWriter(frozenNodeRef,
                                ContentModel.PROP_CONTENT, true);
                            if (contentWriter != null)
                            {
                                LOGGER.debug("------ Setting Content from Precedessor ------- ");
                                contentWriter.setMimetype(contentReader.getMimetype());
                                contentWriter.setEncoding("UTF-8");
                                contentWriter.putContent(contentReader.getContentInputStream());
                            }

                        }

                        behaviourFilter.enableBehaviour(frozenNodeRef, ContentModel.ASPECT_VERSIONABLE);
                        
                        
                        LOGGER.debug("------ Enabling Versionable Behavior ------- ");
                        // DE1584 - ENDS - Deepak

                        behaviourFilter.disableBehaviour(frozenNodeRef);

                        // Set the properties of predecessor node (latest HEAD
                        // version node) to live node.
                        for (Map.Entry<QName, Serializable> entry : frozenNodeRefProp.entrySet())
                        {

                            if (!(entry.getKey().toPrefixString(namespaceService).toString().startsWith("sys:"))
                                    && (!(entry.getKey().toPrefixString(namespaceService).toString().trim())
                                            .equalsIgnoreCase("cm:lastThumbnailModification"))
                                    && (!(entry.getKey().toPrefixString(namespaceService).toString().trim())
                                            .equalsIgnoreCase("cm:content")))
                            {
                                LOGGER.debug("------ Setting Property  : "
                                        + entry.getKey().toPrefixString(namespaceService).toString() + " with "
                                        + predecessorVersionNodeRefProp.get(entry.getKey().getLocalName()));

                                nodeService.setProperty(frozenNodeRef, entry.getKey(),
                                    predecessorVersionNodeRefProp.get(entry.getKey().getLocalName()));

                            }
                            else
                            {
                                LOGGER.debug("------ System Property  : " + entry.getKey().toPrefixString());
                            }

                        }

                        // DE1652 -----start----- //
                        String owner = (String) nodeService.getProperty(frozenNodeRef, ContentModel.PROP_OWNER);
                        if (predecessorVersion.getVersionLabel().equals("1.0"))
                        {
                            LOGGER.debug("owner............" + owner);
                            nodeService.setProperty(frozenNodeRef, ContentModel.PROP_CREATOR, owner);
                            nodeService.setProperty(frozenNodeRef, ContentModel.PROP_MODIFIER, owner);
                        }
                        // DE1652 -----end----- //

                        // LOGGER.info("Deleting HEAD version : " +
                        // currentVersionLabel);

                        // Delete the head version
                        // versionService.deleteVersion(frozenNodeRef,
                        // headVersion);

                    }
                    finally
                    {   
                        LOGGER.debug("------ Enabling Node Behavior ------- ");
                        behaviourFilter.enableBehaviour(frozenNodeRef, CiscoModelConstants.CISCO_MODEL);
                        behaviourFilter.enableBehaviour(frozenNodeRef);
                        
                    }

                }

                message = currentVersionLabel + " version deleted";
            }
            else
            {
                LOGGER.debug("Deleting version : " + currentVersionLabel);
                // Delete this version
                versionService.deleteVersion(frozenNodeRef, versionHistory.getVersion(currentVersionLabel));

                message = currentVersionLabel + " version deleted";
            }

        }
        else
        {
            LOGGER.debug("versionHistory does not exist");
            message = "versionHistory does not exist";
        }

        return message;
    }

    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

}
