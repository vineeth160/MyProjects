package com.cisco.alfresco.external.webscript;

import java.io.Serializable;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.workflow.WorkflowModel;
import org.alfresco.service.cmr.audit.AuditQueryParameters;
import org.alfresco.service.cmr.audit.AuditService;
import org.alfresco.service.cmr.audit.AuditService.AuditQueryCallback;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter;
import org.alfresco.service.cmr.repository.datatype.TypeConversionException;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.cmr.workflow.WorkflowInstance;
import org.alfresco.service.cmr.workflow.WorkflowService;
import org.alfresco.service.cmr.workflow.WorkflowTask;
import org.alfresco.service.cmr.workflow.WorkflowTaskQuery;
import org.alfresco.service.cmr.workflow.WorkflowTaskState;
import org.alfresco.service.namespace.QName;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.edcsng.constants.CiscoWorkflowConstants;
import com.cisco.alfresco.ext.workflow.ExternalSharingWorkflowConstants;
import com.cisco.alfresco.external.common.model.ApproverDetail;
import com.cisco.alfresco.external.common.model.WorkflowHistoryVO;


public class WorkflowHistoryWS extends DeclarativeWebScript
{
    private static final Logger LOGGER = Logger.getLogger(WorkflowHistoryWS.class);

    private static final String JSON_KEY_ENTRY_COUNT = "count";
    private static final String JSON_KEY_ENTRIES = "entries";
    private static final String JSON_KEY_ENTRY_ID = "id";
    private static final String JSON_KEY_ENTRY_APPLICATION = "application";
    private static final String JSON_KEY_ENTRY_USER = "user";
    private static final String JSON_KEY_ENTRY_TIME = "time";
    private static final String JSON_KEY_ENTRY_VALUES = "values";

    private static final String DATE_FORMAT = "MM/dd/yyyy HH:mm z";
    private static final String GMT_TIME_ZONE = "GMT";
    

    private WorkflowService workflowService;
    private NodeService nodeService;
    private AuditService auditService;
    private PersonService personService;
    
    

    private WorkflowHistoryCompletionDateDescComparator workflowComparator = new WorkflowHistoryCompletionDateDescComparator();

    @Override
    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
    {

    	// timestamp
    	 Date date= new Date();		 
		 long time = date.getTime();		 
	     Timestamp ts = new Timestamp(time);
		 
        final Map<String, Object> model = new HashMap<String, Object>();
        try
        {
            AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
            {
				@Override
                public Object doWork() throws Exception
                {

                    String nodeRefStr = req.getParameter("nodeId");

                    NodeRef node = new NodeRef(nodeRefStr);

                    if (LOGGER.isDebugEnabled())
                    {
                        LOGGER.debug("request node ref ids : " + node);
                    }

                    LOGGER.info("Current Time Stamp before workflow task : " + ts);
                    List<WorkflowHistoryVO> workflowStatusList = new ArrayList<WorkflowHistoryVO>();

                    List<WorkflowInstance> workflows = new ArrayList<WorkflowInstance>();
                    LOGGER.debug("Current Time Stamp before Completed Workflows : " + ts);
                    LOGGER.info("Current Time Stamp before Completed Workflows : " + ts);
                    // Get all Completed Workflows
                    workflows.addAll(workflowService.getWorkflowsForContent(node, false));
                    LOGGER.debug("Current Time Stamp after Completed Workflows : " + ts);
                    LOGGER.info("Current Time Stamp after Completed Workflows : " + ts);
                    // Get all Active Workflows
                    LOGGER.debug("Current Time Stamp after Completed Workflows : " + ts);
                    LOGGER.info("Current Time Stamp before Active Workflows : " + ts);
                    workflows.addAll(workflowService.getWorkflowsForContent(node, true));
                    LOGGER.debug("Current Time Stamp after Completed Workflows : " + ts);
                    LOGGER.info("Current Time Stamp after Active task : " + ts);

                    if (LOGGER.isDebugEnabled())
                    {
                        LOGGER.debug("workflows: " + workflows);
                    }

                    if (workflows != null && workflows.size() > 0)
                    {
                        // list out all the workflows the document is part of
                        for (WorkflowInstance wi : workflows)
                        {
                            WorkflowTaskQuery tasksQuery = new WorkflowTaskQuery();
                            tasksQuery.setTaskState(null);
                            tasksQuery.setActive(null);
                            tasksQuery.setProcessId(wi.getId());

                            List<WorkflowTask> tasks = workflowService.queryTasks(tasksQuery, false);

                            for (WorkflowTask task : tasks)
                            {
                                WorkflowHistoryVO workflowStatusObj = new WorkflowHistoryVO();

                                /**
                                 * Get Document Information
                                 */
                                workflowStatusObj.setFileName((String) nodeService.getProperty(node,
                                    ContentModel.PROP_NAME));

                                String title = ((String) nodeService.getProperty(node, ContentModel.PROP_TITLE));
                                if (StringUtils.isEmpty(title))
                                {
                                    title = CiscoWorkflowConstants.NOT_APPLICABLE;
                                }
                                workflowStatusObj.setTitle(title);

                                String edcsId = ((String) nodeService
                                        .getProperty(node, CiscoModelConstants.PROP_ALF_ID));

                                if (StringUtils.isEmpty(edcsId))
                                {
                                    edcsId = CiscoWorkflowConstants.NOT_APPLICABLE;
                                }
                                workflowStatusObj.setEdcsId(edcsId);
                                workflowStatusObj.setWfCategory("Document Approval");
                                /**
                                 * Get Task Details from Workflow Instance
                                 */
                                workflowStatusObj.setDueDate(formatDate(wi.getDueDate()));

                                if (wi.getInitiator() != null)
                                {
                                    // Utils.encode(User.getFullName(nodeService, wi.getInitiator()));

                                    Map<QName, Serializable> initiatorProp = nodeService.getProperties(wi
                                            .getInitiator());

                                    String requestorId = (String) initiatorProp.get(ContentModel.PROP_OWNER);
                                    workflowStatusObj.setRequestorId(requestorId);

                                    String requestor = (String) initiatorProp.get(ContentModel.PROP_USERNAME);
                                    workflowStatusObj.setRequestorName(getUserFullName(requestor));

                                    String requestorEmail = (String) initiatorProp.get(ContentModel.PROP_EMAIL);
                                    workflowStatusObj.setRequestorEmail(requestorEmail);

                                }

                                Map<QName, Serializable> taskProp = task.getProperties();
                                LOGGER.debug(" Workflow Task taskProp :-> " + taskProp);
                                LOGGER.info(" Workflow Task taskProp :-> " + taskProp);

                                if (LOGGER.isDebugEnabled())
                                {
                                    LOGGER.debug(" Task Name: " + task.getName());
                                    LOGGER.debug(" Task Desc: " + task.getDescription());
                                    LOGGER.debug(" Task Details: " + task.toString());
                                    LOGGER.debug(" Task Props: " + taskProp.toString());
                                }

                                workflowStatusObj.setWfStatus(task.getState().name());
                                // workflowStatusObj.setWfType(task.getTitle());

                                // workflowStatusObj.setWorkflowAction(NOT_APPLICABLE);

                                ApproverDetail userDetail = new ApproverDetail();
                                List<ApproverDetail> userDetailList = new ArrayList<ApproverDetail>();

                                if (!task.getId().equals(workflowService.getStartTask(wi.getId()).getId()))
                                {
                                    userDetail.setId((String) taskProp.get(ContentModel.PROP_OWNER));
                                    userDetail.setName(getUserFullName((String) taskProp.get(ContentModel.PROP_OWNER)));
                                    userDetail.setEmail(getUserEmailID((String) taskProp.get(ContentModel.PROP_OWNER)));
                                    userDetailList.add(userDetail);

                                    String outcome = (String) taskProp.get(WorkflowModel.PROP_OUTCOME);

                                    boolean isTaskCompleted = WorkflowTaskState.COMPLETED.name().equals(
                                        workflowStatusObj.getWfStatus());

                                    // boolean isTaskInProgress = WorkflowTaskState.IN_PROGRESS
                                    // .name().equals(workflowStatusObj.getWfStatus());

                                    if (isTaskCompleted)
                                    {
                                        String comment = (String) taskProp.get(WorkflowModel.PROP_COMMENT);

                                        if (StringUtils.isEmpty(comment))
                                        {
                                            comment = CiscoWorkflowConstants.NOT_APPLICABLE;
                                        }
                                        workflowStatusObj.setComment(comment);

                                        if (CiscoWorkflowConstants.APPROVE_ACTION.equalsIgnoreCase(outcome))
                                        {
                                            workflowStatusObj
                                                    .setWorkflowAction(CiscoWorkflowConstants.DOCUMENT_RESUBMITTED);
                                        }
                                        else if (CiscoWorkflowConstants.REJECT_ACTION.equalsIgnoreCase(outcome)) // isTaskCompleted
                                                                                                                 // &&
                                        {
                                            // New code 970
                                            workflowStatusObj
                                                    .setWorkflowAction(CiscoWorkflowConstants.DOCUMENT_REJECTED);
                                        }
                                        else if (CiscoWorkflowConstants.ACCEPT_ACTION.equalsIgnoreCase(outcome)) // isTaskCompleted
                                                                                                                 // &&
                                        {
                                            // New code 970
                                            workflowStatusObj
                                                    .setWorkflowAction(CiscoWorkflowConstants.DOCUMENT_APPROVED);
                                        }
                                        else if (CiscoWorkflowConstants.CANCEL_ACTION.equalsIgnoreCase(outcome)) // isTaskCompleted
                                        {
                                            workflowStatusObj
                                                    .setWorkflowAction(CiscoWorkflowConstants.DOCUMENT_CANCELLED);
                                        }
                                        else
                                        {
                                            workflowStatusObj.setWorkflowAction(CiscoWorkflowConstants.DOCUMENT_RETURNED_TO_REQUESTER);
                                            workflowStatusObj.setComment(CiscoWorkflowConstants.NOT_APPLICABLE);
                                        }
                                    }
                                    else
                                    {
                                        workflowStatusObj.setWorkflowAction(CiscoWorkflowConstants.NOT_APPLICABLE);
                                        workflowStatusObj.setComment(CiscoWorkflowConstants.NOT_APPLICABLE);
                                    }

                                }
                                else
                                {
                                    // Start Task Information
                                    List<NodeRef> assignees = new ArrayList<NodeRef>();
                                    assignees.addAll(getUserGroupRefs(taskProp.get(WorkflowModel.ASSOC_ASSIGNEES)));

                                    for (NodeRef assignee : assignees)
                                    {
                                        userDetail = getUserDetail(assignee);
                                        userDetailList.add(userDetail);
                                    }
                                    // Start task will have WORKFLOW_STARTED
                                    workflowStatusObj.setWorkflowAction(CiscoWorkflowConstants.WORKFLOW_STARTED);

                                    String comment = (String) taskProp.get(WorkflowModel.PROP_COMMENT);

                                    if (StringUtils.isEmpty(comment))
                                    {
                                        comment = CiscoWorkflowConstants.NOT_APPLICABLE;
                                    }
                                    workflowStatusObj.setComment(comment);
                                }

                                workflowStatusObj.setApprovers(userDetailList);

                                workflowStatusObj
                                        .setParticipant((String) taskProp.get(ContentModel.PROP_OWNER) != null ? (String) taskProp
                                                .get(ContentModel.PROP_OWNER) : CiscoWorkflowConstants.NOT_APPLICABLE);
                              
                                
                                
                                
                                Date requestDate = ((Date) taskProp.get(WorkflowModel.PROP_START_DATE));
                                
                                
                                /*DateFormat dformatter = new SimpleDateFormat(DATE_FORMAT);
                                Date reqdate = dformatter.parse(requestDate.toString());
                                LOGGER.info("RequestDate>>>"+reqdate);
                                dformatter.setTimeZone(TimeZone.getTimeZone(GMT_TIME_ZONE));
                                String formattedDate = dformatter.format(reqdate);
                                Date date1=new SimpleDateFormat(DATE_FORMAT).parse(formattedDate);
                                LOGGER.info("RequestDate>>>"+requestDate);*/
                                LOGGER.debug("RequestDate>>>"+requestDate);
                                LOGGER.info("RequestDate>>>"+requestDate);
                                
                                
                                
                                workflowStatusObj.setRequestDate(getGMTDateFormat(requestDate));
                                LOGGER.debug("CompDate>>>"+workflowStatusObj);
                                LOGGER.info("CompDate>>>"+workflowStatusObj);

                                Date CompDate = ((Date) taskProp.get(WorkflowModel.PROP_COMPLETION_DATE));
                                LOGGER.debug("CompDate>>>"+CompDate);
                                LOGGER.info("CompDate>>>"+CompDate);
                                //DateFormat dformatter1 = new SimpleDateFormat(DATE_FORMAT);
                                /*Date reqdate1 = dformatter1.parse(CompDate.toString());
                                LOGGER.info("RequestDate>>>"+reqdate1);
                                dformatter1.setTimeZone(TimeZone.getTimeZone(GMT_TIME_ZONE));
                                String formattedDate1 = dformatter.format(reqdate1);
                                Date date2=new SimpleDateFormat(DATE_FORMAT).parse(formattedDate);
                                LOGGER.info("RequestDate>>>"+requestDate);*/

                                workflowStatusObj.setCompletedDate(getGMTDateFormat(requestDate));
                                LOGGER.debug("CompDate>>>"+workflowStatusObj);
                                LOGGER.info("CompDate>>>"+workflowStatusObj);
                                
                                if (workflowStatusObj.getWorkflowAction().equals(CiscoWorkflowConstants.WORKFLOW_STARTED)){
                                	workflowStatusObj.setDocStatus(ExternalSharingWorkflowConstants.SUBMITTED_FOR_APPROVAL);
                                }else if(workflowStatusObj.getWorkflowAction().equals(CiscoWorkflowConstants.DOCUMENT_REJECTED)){
                                	workflowStatusObj.setDocStatus(ExternalSharingWorkflowConstants.REJECTED);
                                } else if(workflowStatusObj.getWorkflowAction().equals(CiscoWorkflowConstants.DOCUMENT_RESUBMITTED)){
                                	workflowStatusObj.setDocStatus(ExternalSharingWorkflowConstants.SUBMITTED_FOR_APPROVAL);
                                }else if(workflowStatusObj.getWorkflowAction().equals(CiscoWorkflowConstants.DOCUMENT_APPROVED)){
                                	workflowStatusObj.setDocStatus(ExternalSharingWorkflowConstants.APPROVED);
                                }else if(workflowStatusObj.getWorkflowAction().equals(CiscoWorkflowConstants.DOCUMENT_CANCELLED)){
                                	workflowStatusObj.setDocStatus(ExternalSharingWorkflowConstants.CANCELLED);
                                }else if( workflowStatusObj.getWorkflowAction().equals(CiscoWorkflowConstants.DOCUMENT_RETURNED_TO_REQUESTER)){
                                	workflowStatusObj.setDocStatus(ExternalSharingWorkflowConstants.REJECTED);
                                }else if(workflowStatusObj.getWorkflowAction().equals(CiscoWorkflowConstants.NOT_APPLICABLE)){
                                	workflowStatusObj.setDocStatus(CiscoWorkflowConstants.NOT_APPLICABLE);
                                }else{
                                	workflowStatusObj.setDocStatus(CiscoWorkflowConstants.NOT_APPLICABLE);
                                }

                                /**
                                 * Get Document Version from Audit Query
                                 */
                               
                                String taskId=task.getId();
                                String workflowInstanceId = wi.getId();
                                workflowInstanceId = workflowInstanceId.substring(workflowInstanceId.indexOf("$") + 1);
										if (workflowStatusObj
												.getWorkflowAction()
												.equals(CiscoWorkflowConstants.DOCUMENT_RESUBMITTED)
												|| workflowStatusObj
														.getWorkflowAction()
														.equals(CiscoWorkflowConstants.DOCUMENT_REJECTED)
												|| workflowStatusObj
														.getWorkflowAction()
														.equals(CiscoWorkflowConstants.DOCUMENT_APPROVED)
												|| workflowStatusObj
														.getWorkflowAction()
														.equals(CiscoWorkflowConstants.DOCUMENT_CANCELLED)
												|| workflowStatusObj
														.getWorkflowAction()
														.equals(CiscoWorkflowConstants.DOCUMENT_RETURNED_TO_REQUESTER)
												|| workflowStatusObj
														.getWorkflowAction()
														.equals(CiscoWorkflowConstants.NOT_APPLICABLE)) {
											String versionLabel = (String) taskProp
													.get(WorkflowModel.PROP_PACKAGE_ACTION_GROUP);
											LOGGER.info("Workflow taskId : "
													+ taskId
													+ " DocumentStatus : "
													+ workflowStatusObj
															.getWorkflowAction()
													+ " VersionLabel : "
													+ versionLabel);
											workflowStatusObj
													.setVersion(versionLabel);
										} else {
											Map<String, Object> auditWorkflowStartMap = getAuditQuery("workflowstart");
											workflowStatusObj
													.setVersion(getDocVersion(
															auditWorkflowStartMap,
															workflowInstanceId));
										}
                                // changes end by dhshaw
                                workflowStatusList.add(workflowStatusObj);
                            }

                        }

                    }

                    /**
                     * sort workflows by completion date in DESC order
                     */
                    Collections.sort(workflowStatusList, workflowComparator);

                    // cancelled workflows -end
                    ObjectMapper mapper = new ObjectMapper();
                    Writer strWriter = new StringWriter();
                    mapper.writeValue(strWriter, workflowStatusList);

                    String jsonString = strWriter.toString();

                    if (LOGGER.isDebugEnabled())
                    {
                        LOGGER.debug("Result JSON : " + jsonString);
                    }
                    model.put("result", jsonString);

                    return null;
                }
            }, "admin");
        }
        catch (InvalidNodeRefException ine)
        {
            LOGGER.error("InvalidNodeRefException : " + ine);
        }
        catch (Exception e)
        {
            LOGGER.error("Exception : " + e);
        }

        return model;
    }

    /**
     * 
     * @param applicationName
     * @return
     */
    private Map<String, Object> getAuditQuery(String applicationName)
    {

        final Map<String, Object> model = new HashMap<String, Object>(7);

        int limit = 0;
        final boolean verbose = true;

        // Execute the query
        AuditQueryParameters params = new AuditQueryParameters();
        params.setApplicationName(applicationName); // "workflowstart"

        final List<Map<String, Object>> entries = new ArrayList<Map<String, Object>>(limit);
        AuditQueryCallback callback = new AuditQueryCallback()
        {
            @Override
            public boolean valuesRequired()
            {
                return verbose;
            }

            @Override
            public boolean handleAuditEntryError(Long entryId, String errorMsg, Throwable error)
            {
                return true;
            }

            @Override
            public boolean handleAuditEntry(Long entryId, String applicationName, String user, long time,
                    Map<String, Serializable> values)
            {

                Map<String, Object> entry = new HashMap<String, Object>(11);
                entry.put(JSON_KEY_ENTRY_ID, entryId);
                entry.put(JSON_KEY_ENTRY_APPLICATION, applicationName);

                if (user != null)
                {
                    entry.put(JSON_KEY_ENTRY_USER, user);
                }
                entry.put(JSON_KEY_ENTRY_TIME, new Date(time));
                LOGGER.info("entry>>>"+entry);

                if (values != null)
                {
                    // Convert values to Strings
                    Map<String, String> valueStrings = new HashMap<String, String>(values.size() * 2);
                    for (Map.Entry<String, Serializable> mapEntry : values.entrySet())
                    {
                        String key = mapEntry.getKey();
                        Serializable value = mapEntry.getValue();
                        try
                        {
                            String valueString = DefaultTypeConverter.INSTANCE.convert(String.class, value);
                            valueStrings.put(key, valueString);
                        }
                        catch (TypeConversionException e)
                        {
                            // Use the toString()
                            valueStrings.put(key, value.toString());
                        }

                    }
                    entry.put(JSON_KEY_ENTRY_VALUES, valueStrings);
                }
                entries.add(entry);

                return true;
            }
        };

        // Make an audit call to applicationName
        auditService.auditQuery(callback, params, limit);

        model.put(JSON_KEY_ENTRY_COUNT, entries.size());
        model.put(JSON_KEY_ENTRIES, entries);

        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("Audit Size : " + entries.size());
        }
        return model;
    }

    @SuppressWarnings("unchecked")
    private String getDocVersion(Map<String, Object> entriesMap, String activityNum)
    {
        if ((Integer) entriesMap.get(JSON_KEY_ENTRY_COUNT) > 0)
        {
            List<Map<String, Object>> entries = (List<Map<String, Object>>) entriesMap.get(JSON_KEY_ENTRIES);

            for (Map<String, Object> entryMap : entries)
            {
                Map<String, String> valuesMap = (Map<String, String>) entryMap.get(JSON_KEY_ENTRY_VALUES);
                if (valuesMap != null && valuesMap.get("/workflowstart/args/parameters/wfTaskId") != null
                        && valuesMap.get("/workflowstart/args/parameters/wfTaskId").equals(activityNum))
                {

                    if (LOGGER.isDebugEnabled())
                    {
                        LOGGER.debug("Audit for  Activiti TaskId: " + activityNum + "\n" + valuesMap.toString());
                    }
                    return (valuesMap.get("/workflowstart/args/parameters/documentVersion") != null ? valuesMap
                            .get("/workflowstart/args/parameters/documentVersion") : null);
                }

            }

        }

        return null;
    }

    /**
     * 
     * @param userNodeRef
     * @return
     */
    private ApproverDetail getUserDetail(NodeRef userNodeRef)
    {
        ApproverDetail userDetail = new ApproverDetail();
        Map<QName, Serializable> userProperties = nodeService.getProperties(userNodeRef);

        String userId = (String) userProperties.get(ContentModel.PROP_USERNAME);
        String email = (String) userProperties.get(ContentModel.PROP_EMAIL);
        String firstName = (String) userProperties.get(ContentModel.PROP_FIRSTNAME);
        String lastName = (String) userProperties.get(ContentModel.PROP_LASTNAME);

        userDetail.setId(userId);
        userDetail.setEmail(email);
        userDetail.setName(firstName + " " + lastName);

        return userDetail;
    }

    /**
     * 
     * @param userID
     * @return
     */
    private String getUserEmailID(String userID)
    {
        String emailId = CiscoWorkflowConstants.NOT_APPLICABLE;

        NodeRef personNode = personService.getPerson(userID, false);

        if (personNode != null)
        {
            emailId = (String) nodeService.getProperty(personNode, ContentModel.PROP_EMAIL);
            emailId = (emailId == null) ? CiscoWorkflowConstants.NOT_APPLICABLE : emailId;
        }
        return emailId;
    }

    /**
     * 
     * @param userID
     * @return
     */
    private String getUserFullName(String userID)
    {
        String fullName = CiscoWorkflowConstants.NOT_APPLICABLE;
        NodeRef personNode = personService.getPerson(userID, false);

        if (personNode == null)
        {
            return fullName;
        }

        Map<QName, Serializable> userProp = nodeService.getProperties(personNode);

        String firstName = ((String) userProp.get(ContentModel.PROP_FIRSTNAME) == null ? StringUtils.EMPTY
                : (String) userProp.get(ContentModel.PROP_FIRSTNAME));

        String lastName = ((String) userProp.get(ContentModel.PROP_LASTNAME) == null ? StringUtils.EMPTY
                : (String) userProp.get(ContentModel.PROP_LASTNAME));

        fullName = new StringBuilder(firstName).append(" ").append(lastName).toString();

        return fullName;
    }

    /**
     * 
     * @param o
     * @return
     */
    private NodeRef getUserGroupRef(Object o)
    {
        NodeRef result = null;
        if (o == null || o instanceof NodeRef)
        {
            result = (NodeRef) o;
        }
        else
        {
            try
            {
                result = personService.getPerson(o.toString());
            }
            catch (Exception e)
            {
                // try
                // {
                // result = authorityService.getAuthorityNodeRef(o.toString());
                // }
                // catch (Exception e1)
                // {
                // // do nothing
                // }
                LOGGER.error("Exception: ", e);
            }

        }

        return result;
    }

    /**
     * 
     * @param o
     * @return
     */
    
    public static String getGMTDateFormat(Date date){
		DateFormat df;
		String formatedDate="";
		try{
		df = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
		df.setTimeZone(TimeZone.getTimeZone("GMT"));
		if(date != null){
		formatedDate=df.format(date);
		}
		}catch(Exception e){
		LOGGER.error("Exception....."+e);
		}
		return formatedDate;
		}
    private Collection<NodeRef> getUserGroupRefs(Object o)
    {
        List<NodeRef> result = new ArrayList<NodeRef>();
        if (o != null && o instanceof Collection)
        {
            for (Iterator<?> it = ((Collection<?>) o).iterator(); it.hasNext();)
            {
                result.add(getUserGroupRef(it.next()));

            }
        }

        return result;
    }

    /**
     * 
     * @param date
     * @return
     */
    private String formatDate(Date date)
    {
        String formattedDate = "";

        if (date != null)
        {
            DateFormat formatter = new SimpleDateFormat(DATE_FORMAT);
            LOGGER.info("DateFormat>>>"+formatter);
            formatter.setTimeZone(TimeZone.getTimeZone(GMT_TIME_ZONE));
            formattedDate = formatter.format(date);
            LOGGER.info("'formattedDate>>>"+formattedDate);
        }

        return formattedDate;
    }

    /**
     * @param workflowService
     *            the workflowService to set
     */
    public void setWorkflowService(WorkflowService workflowService)
    {
        this.workflowService = workflowService;
    }

    /**
     * @param nodeService
     *            the nodeService to set
     */
    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    /**
     * @param auditService
     *            the auditService to set
     */
    public void setAuditService(AuditService auditService)
    {
        this.auditService = auditService;
    }

    /**
     * 
     * @param personService
     */
    public void setPersonService(PersonService personService)
    {
        this.personService = personService;
    }

    /**
     * Comparator to sort Workflow History by CompletionDate in Descending (DESC) order.
     */
    class WorkflowHistoryCompletionDateDescComparator implements Comparator<WorkflowHistoryVO>
    {
        @Override
        public int compare(WorkflowHistoryVO o1, WorkflowHistoryVO o2)
        {
            String date1Str = o1.getCompletedDate();
            LOGGER.info("date1Str>>>"+date1Str);
            String date2Str = o2.getCompletedDate();
            LOGGER.info("date2Str>>>"+date2Str);

            long result = 0;
            try
            {
                DateFormat formatter = new SimpleDateFormat(DATE_FORMAT);
                formatter.setTimeZone(TimeZone.getTimeZone(GMT_TIME_ZONE));

                if (!StringUtils.isEmpty(date1Str) && !StringUtils.isEmpty(date2Str))
                {
                    Date date1 = formatter.parse(date1Str);
                    LOGGER.info("date1>>>"+date1);
                    Date date2 = formatter.parse(date2Str);
                    LOGGER.info("date2>>>"+date2);

                    long time1 = date1 == null ? Long.MAX_VALUE : date1.getTime();
                    long time2 = date2 == null ? Long.MAX_VALUE : date2.getTime();

                    result = time2 - time1;
                }

            }
            catch (ParseException e)
            {
                LOGGER.error("Date ParseException : ", e);
            }

            return (result > 0) ? 1 : (result < 0 ? -1 : 0);
        }

    }
}
