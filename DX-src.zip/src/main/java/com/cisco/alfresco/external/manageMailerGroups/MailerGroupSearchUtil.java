package com.cisco.alfresco.external.manageMailerGroups;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityService;
import org.apache.log4j.Logger;

import com.cisco.alfresco.auth.ext.EXTEncrypter;

public class MailerGroupSearchUtil {
	 private Logger LOGGER = Logger.getLogger(MailerGroupSearchUtil.class);
	public static final String INITCTX = "com.sun.jndi.ldap.LdapCtxFactory";
	private String mailerGroupsLdapHost;// "ldap://ds.cisco.com:389";
	private String mailerGroupsGenericUser;
	private String mailerGroupsGenericPwd;
	private String mailerGroupsGenericKey;
	private String mailerGroupsLdapSearchBase;
	
	private static final String GROUP_IDENTITY ="GROUP_";
	private static String LDAP_AUTHENTICATION_SIMPLE="simple";
	private static String CISCO_DOMAIN="@cisco.com";
	//default search base is Cisco Groups
	//private static String LDAP_MAILER_GROUP_SEARCHBASE="ou=Mailer,ou=Cisco Groups,dc=cisco,dc=com";
	public static final int MAX_QUERY_SIZE = 1500;
	
	/**
	 * A method to search LDAP for groups; returns a group to groupId and group display name details.
	 * 
	 * @param cn - the CN of the group(s) to look for.
	 * @return a Map - the key is the groupId of the group found. the value is display name
	 */
	public Map<String, String> getGroups(String cn) {
		return getGroups(cn, getLdapContext());
	}
	
	/**
	 * A method to search LDAP for groups; returns a group to members mapping.
	 * 
	 * @param cn - the CN of the group(s) to look for.
	 * @return a Map - the key is the displayName of the group found. the value is the list of members' names
	 */
	
	public Map<String, Set<String>> getGroupMembers(String cn) {
		return getGroupMembers(cn, getLdapContext());
	}
	
	/**
	 * A method to search LDAP for groups; returns a group to groupId and group display name details.
	 * 
	 * @param cn - the CN of the group(s) to look for.
	 * @return a Map - the key is the groupId of the group found. the value is display name
	 */
	public String getGroupDetails(String cn) {
		return getGroupDetails(cn, getLdapContext());
	}
	
	/**
	 * A method to search LDAP for groups; returns a group to members mapping. If a group contains more
	 * than 1500 users, that user list will <i>not</i> be returned. Instead, the list will contain a
	 * recommendation to view the user list from within Grouper.
	 * 
	 * @param cn - the CN of the group(s) to look for.
	 * @return a Map - the key is the displayName of the group found. the value is the list of members' names
	 */
	public String getGroupMembersJSON(String cn, AuthorityService authorityService, boolean fullMembers) {
		
		//LOGGER.info("groupType :: "+groupType);
		StringBuilder groupMembersJsonResponse = new StringBuilder();
		LdapContext ldapContext = getLdapContext();
		//String ldapSearchBase = LDAP_GROUPS_SEARCHBASE;//"ou=Cisco Groups,dc=cisco,dc=com";
		try {
			SearchControls mySearchControls = new SearchControls();
			mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
	
			String[] searchReturningAttributes = null;
			
			if( fullMembers ){
				searchReturningAttributes = new String[] { "description", "displayName", "member", "cn","company","mail"};
			} else {
				searchReturningAttributes = new String[] { "description", "displayName", "cn","company","mail"};
			}
					
			mySearchControls.setReturningAttributes(searchReturningAttributes); 
			LOGGER.info("LDAP_SEARCHBASE getGroupMembersJSON :: "+getMailerGroupsLdapSearchBase());
			NamingEnumeration<SearchResult> mySearchResults = ldapContext.search(
					getMailerGroupsLdapSearchBase(), 
					"cn=" + cn, mySearchControls);
			groupMembersJsonResponse.append("[");
			
			if( !mySearchResults.hasMore() )
				groupMembersJsonResponse.append("]");
			
			while (mySearchResults.hasMore()) {
				Attributes attrs = ((SearchResult) mySearchResults.next()).getAttributes();
				
				String groupName = attrs.get("cn").get().toString();
				if( authorityService != null && authorityService.authorityExists(GROUP_IDENTITY + groupName ) ) {
					groupMembersJsonResponse.append("{ \"groupName\":\"").append(groupName).append("\", ");
					String displayName = "";
					if( attrs.get("displayName") != null )
					displayName = attrs.get("displayName").get().toString();
					groupMembersJsonResponse.append("\"displayName\": \"").append(displayName).append("\", ");
					String description = "";
					if( attrs.get("description") != null )
						description = attrs.get("description").get().toString();
					groupMembersJsonResponse.append("\"description\": \"").append(description).append("\", ");
					
					String groupCompanyName = "";
					if( attrs.get("company") != null )
					groupCompanyName = attrs.get("company").get().toString();
					groupMembersJsonResponse.append("\"company\": \"").append(groupCompanyName).append("\", ");
					String groupEmailId = "";
					if( attrs.get("mail") != null )
					groupEmailId = attrs.get("mail").get().toString();
					groupMembersJsonResponse.append("\"email\": \"").append(groupEmailId).append("\", ");
					String groupExistsInRepo = "true";
					groupMembersJsonResponse.append("\"existing\": \"").append(groupExistsInRepo).append("\", ");
					
					Set<String> membersList = authorityService.getContainedAuthorities(null, GROUP_IDENTITY + groupName, true);
					generateMembersListJSON(groupMembersJsonResponse, membersList, groupName);
				} else {
					groupMembersJsonResponse.append("{ \"groupName\":\"").append(groupName).append("\", ");
					String displayName = "";
					if( attrs.get("displayName") != null )
					displayName = attrs.get("displayName").get().toString();
					groupMembersJsonResponse.append("\"displayName\": \"").append(displayName).append("\", ");
					String description = "";
					if( attrs.get("description") != null )
						description = attrs.get("description").get().toString();
					groupMembersJsonResponse.append("\"description\": \"").append(description).append("\", ");
					String groupCompanyName = "";
					if( attrs.get("company") != null )
					groupCompanyName = attrs.get("company").get().toString();
					groupMembersJsonResponse.append("\"company\": \"").append(groupCompanyName).append("\", ");
					String groupEmailId = "";
					if( attrs.get("mail") != null )
					groupEmailId = attrs.get("mail").get().toString();
					groupMembersJsonResponse.append("\"email\": \"").append(groupEmailId).append("\", ");
					String groupExistsInRepo = "false";
					groupMembersJsonResponse.append("\"existing\": \"").append(groupExistsInRepo).append("\", ");
					Set<String> membersList = new HashSet<String>();
					if( fullMembers)
						buildMembersList(cn, ldapContext, membersList, attrs, 0, 10, true);
					
					generateMembersListJSON(groupMembersJsonResponse, membersList, groupName);
				}
				
				if( mySearchResults.hasMore() )
					groupMembersJsonResponse.append("},"); //Close the object, group is done but expecting another
				else
					groupMembersJsonResponse.append("}]"); //Close the object, groups aredone
			}
		} catch (NamingException ne) {
			LOGGER.fatal("Fatal error fetching groups.", ne);
			LOGGER.error("Error in authenticating user: " + ne.toString());
		} catch(Exception e) {
			LOGGER.fatal("Fatal error fetching groups.", e);
		}
		
		return groupMembersJsonResponse.toString();
	}

	public void generateMembersListJSON(StringBuilder response,
			Set<String> membersList, String groupName) {
		response.append("\"members\": \"");
		for( String username : membersList ) {
			response.append(username).append(" ");
		}
		if( membersList.size() > 0 )
			response.setLength(response.length()-1);
		response.append("\"");
	}

	protected Map<String, String> getGroups(String cn, LdapContext ldapContext) {
		Map<String, String> groupDetails = null;
		try {
			SearchControls mySearchControls = new SearchControls();
			mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			String[] searchReturningAttributes = { "displayName", "cn"};
			mySearchControls.setReturningAttributes(searchReturningAttributes); 
			LOGGER.info("LDAP_SEARCHBASE getGroups :: "+getMailerGroupsLdapSearchBase());
			NamingEnumeration<SearchResult> mySearchResults = ldapContext.search(
					getMailerGroupsLdapSearchBase(), 
					"cn=" + cn, mySearchControls);
			groupDetails = new HashMap<String, String>();
			while (mySearchResults.hasMore()) {  
				Attributes searchResultsAttrs = ((SearchResult) mySearchResults.next()).getAttributes();
				Attribute cnResultsAttrs = searchResultsAttrs.get("cn");
				Attribute nameResultsAttrs = searchResultsAttrs.get("displayName");
				if( nameResultsAttrs != null )
					groupDetails.put(cnResultsAttrs.get().toString(), nameResultsAttrs.get().toString());
				else
					groupDetails.put(cnResultsAttrs.get().toString(), cnResultsAttrs.get().toString());
			} 
			ldapContext.close();	
		} catch (NamingException ne) {
			ne.printStackTrace();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return groupDetails;
	}

	/**
	 * A method to search LDAP for groups; returns a group to members mapping.
	 * 
	 * @param cn - the CN of the group(s) to look for.
	 * @param ctx - an LdapContext to use to perform the search
	 * @return a Map - the key is the displayName of the group found. the value is the list of members' names
	 */
	protected Map<String, Set<String>> getGroupMembers(String cn, LdapContext ldapContext) {
		Map<String, Set<String>> groupMembersDetails = null;
		try {
			SearchControls mySearchControls = new SearchControls();
			mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);

			String[] searchReturningAttributes = { "distinguishedName",  
					"description",  
					"displayName",
					"cn",
					"member"};
			mySearchControls.setReturningAttributes(searchReturningAttributes);
			LOGGER.info("LDAP_SEARCHBASE getGroupMembers :: "+getMailerGroupsLdapSearchBase());
			NamingEnumeration<SearchResult> mySearchResults = ldapContext.search(
					getMailerGroupsLdapSearchBase(), 
					"cn=" + cn, mySearchControls);
			groupMembersDetails = new HashMap<String, Set<String>>();
			while (mySearchResults.hasMore()) {
				SearchResult entry = (SearchResult)mySearchResults.next();
				Attributes searchResultsAttrs = entry.getAttributes();
				String displayName = null;
				if( searchResultsAttrs.get("displayName") != null ){
					displayName = searchResultsAttrs.get("displayName").toString();
				}else{
					displayName = cn;
				}
				Set<String> membersList = new HashSet<String>();
				
				buildMembersList(cn, ldapContext, membersList, searchResultsAttrs, 0, MAX_QUERY_SIZE-1, false);
				
				groupMembersDetails.put(displayName, membersList);
			}
		} catch (NamingException ne) {
			ne.printStackTrace();
		} catch(Exception e) {
			e.printStackTrace();
		}
		try {
			ldapContext.close();
		} catch (Exception ignored) {}
		return groupMembersDetails;
	}

	/**
	 * Builds a list of members. If short circuiting the members search is desired, please specify
	 * 
	 * @param cn
	 * @param ctx
	 * @param membersList
	 * @param attrs
	 * @param min
	 * @param max - range definition; can equal -1, meaning we pass min-* for the range and stop querying after
	 * @param shortCircuitLargeList
	 * @throws NamingException
	 */
	protected void buildMembersList(String cn, LdapContext ctx,
			Set<String> membersList, Attributes attrs, int min, int max, boolean shortCircuitLargeList) throws NamingException {
		Attribute members = attrs.get("member");
		Attribute membersPlus = attrs.get("member;range=" + min + "-" + (max == -1 ? "*" : max) );
		String thisCN = attrs.get("cn").get().toString();
		LOGGER.info("LDAP_SEARCHBASE buildMembersList :: "+getMailerGroupsLdapSearchBase());
		if( members == null && membersPlus == null && max != -1 ) {
			//Do one more query to ensure we pick up the last guys in the list.
			SearchControls trimCtrl = new SearchControls();

			String [] trimAttrIDs = { "cn", "member", "member;range=" + min + "-*"};

			trimCtrl.setSearchScope(SearchControls.SUBTREE_SCOPE);
			trimCtrl.setReturningAttributes(trimAttrIDs);
			NamingEnumeration<SearchResult> answer = 
					ctx.search(getMailerGroupsLdapSearchBase(), 
							"cn=" + thisCN, trimCtrl);

			buildMembersList(cn, ctx, membersList, answer.next().getAttributes(), min, -1, shortCircuitLargeList);
		} else if( members != null && members.size() > 0 ) {
			for( int i = 0; i < members.size(); i++ ) {
				String member = members.get(i).toString();
				if( member.contains("OU=Employees,")) {
					int CNidx = member.indexOf("CN=");
					String username = member.substring(CNidx+3, member.indexOf(",", CNidx));
					membersList.add(username);
				}
			}
		} else if( membersPlus != null && membersPlus.size() > 0 ) {
			for( int i = 0; i < membersPlus.size(); i++ ) {
				String member = membersPlus.get(i).toString();
				if( member.contains("OU=Employees")) {
					int CNidx = member.indexOf("CN=");
					String username = member.substring(CNidx+3, member.indexOf(",", CNidx));
					membersList.add(username);
				}
			}

			if( max != -1 ) {
				min = max+1;
				max += MAX_QUERY_SIZE;
				SearchControls trimCtrl = new SearchControls();
				String [] trimAttrIDs = { "cn", "member", "member;range=" + min + "-" + max};
				trimCtrl.setSearchScope(SearchControls.SUBTREE_SCOPE);
				trimCtrl.setReturningAttributes(trimAttrIDs);
				NamingEnumeration<SearchResult> answer = 
						ctx.search(getMailerGroupsLdapSearchBase(), 
								"cn=" + thisCN, trimCtrl);
				buildMembersList(cn, ctx, membersList, answer.next().getAttributes(), min, max, shortCircuitLargeList);
			}
		} else if( min == 0 ) {
			SearchControls trimCtrl = new SearchControls();
			String [] trimAttrIDs = { "cn", "member;range=" + min + "-" + max};
			trimCtrl.setSearchScope(SearchControls.SUBTREE_SCOPE);
			trimCtrl.setReturningAttributes(trimAttrIDs);
			NamingEnumeration<SearchResult> answer = 
					ctx.search(getMailerGroupsLdapSearchBase(), 
							"cn=" + thisCN, trimCtrl);
			
			attrs = answer.next().getAttributes();
			if( attrs.get("member;range=" + min + "-" + max) != null ) {
				if ( !shortCircuitLargeList )
					buildMembersList(cn, ctx, membersList, attrs, min, max, shortCircuitLargeList);
				else {
					membersList.clear();
					membersList.add("This member list is very large; please view in Mailer.");
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	private LdapContext getLdapContext() {
		LdapContext ldapContext = null;
		try {
			@SuppressWarnings("rawtypes")
			Hashtable myEnv = new Hashtable();
			LOGGER.info(":::::: ldapURL :::::::"+getMailerGroupsLdapHost());
			myEnv.put(LdapContext.CONTROL_FACTORIES, "com.sun.jndi.ldap.ControlFactory"); 
			myEnv.put(Context.INITIAL_CONTEXT_FACTORY, INITCTX);
			myEnv.put(Context.PROVIDER_URL, getMailerGroupsLdapHost());
			myEnv.put(Context.SECURITY_AUTHENTICATION, LDAP_AUTHENTICATION_SIMPLE);
			myEnv.put(Context.SECURITY_PRINCIPAL, getMailerGroupsGenericUser());
			myEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(getMailerGroupsGenericPwd(), getMailerGroupsGenericKey()).getBytes("UTF8"));
			ldapContext = new InitialLdapContext(myEnv, null);
		} catch(NamingException nex) {
			LOGGER.fatal("Fatal error initializing LDAP context.", nex);
			nex.printStackTrace();
		} catch (Exception e) {
			LOGGER.fatal("Fatal error initializing LDAP context.", e);
			e.printStackTrace();
		}
		LOGGER.info(":::::: ldapContext :::::::"+ldapContext);
		return ldapContext;
	}
	
	 /**
     * To check user has owner/folderadmin permissions on document/folder
     */
    public boolean getUserHasPermissionFromNode(final NodeRef nodeRef,String loginUserId,final ServiceRegistry serviceRegistry){
		  
		  HashMap<String, String> permissionsInfo = new HashMap<String, String>();
		  boolean haveValidPermission=false;
		  try{
			  final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
			  AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			  @Override
			  public Object doWork() throws Exception {
				  accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef)); // getPermissions(nodeRef);
				  return null;
			  	}
			  }, "admin");

			  if (accessPermission.size() > 0) {
			  for (AccessPermission accessPermissionObj : accessPermission) {
				  permissionsInfo.put(accessPermissionObj.getAuthority(), accessPermissionObj.getPermission().toString());
			  }
			  }
			  if(permissionsInfo.containsKey(loginUserId)){
				  String permissionValue=permissionsInfo.get(loginUserId).toString();
				  if(permissionValue.equals("AdminRole")||permissionValue.equals("OwnerRole")){
					  haveValidPermission=true;
		        	 }else{
		        		 haveValidPermission=false;
				        }
			  }else{
				  haveValidPermission=false;
			  }
		  }catch(Exception exe){
			  exe.getMessage();
			  LOGGER.error("Get Node User Permissions Exception : " + exe.getMessage());
		  }
		  return haveValidPermission;
	  }

    public String getGroupDetails(String cn, LdapContext ldapContext) {
    	StringBuffer groupStrBuffer = new StringBuffer();
		 NamingEnumeration<SearchResult> mySearchResults =null;
		try {
			SearchControls mySearchControls = new SearchControls();
			mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			String[] searchReturningAttributes = { "displayName", "cn","mail"};
			mySearchControls.setReturningAttributes(searchReturningAttributes); 
			LOGGER.info("LDAP_SEARCHBASE getGroups :: "+getMailerGroupsLdapSearchBase());
			mySearchResults = ldapContext.search(
					getMailerGroupsLdapSearchBase(), 
					"cn=" + cn, mySearchControls);
			while (mySearchResults.hasMore()) {  
				Attributes searchResultsAttrs = ((SearchResult) mySearchResults.next()).getAttributes();
				if( searchResultsAttrs.get("cn") != null ){
					String groupId=searchResultsAttrs.get("cn").get().toString();
					groupStrBuffer.append(groupId);
				}
				if( searchResultsAttrs.get("displayName") != null ){
					String groupDisplayName=searchResultsAttrs.get("displayName").get().toString();
					groupStrBuffer.append("::" + groupDisplayName + "::");
				}else{
					String groupDisplayName=searchResultsAttrs.get("cn").get().toString();
					groupStrBuffer.append("::" + groupDisplayName + "::");
				}
				if( searchResultsAttrs.get("mail")!= null ){
					String grouperEmailId=searchResultsAttrs.get("mail").get().toString();
					groupStrBuffer.append(grouperEmailId);
				}else{
					String grouperEmailId=searchResultsAttrs.get("cn").get().toString()+CISCO_DOMAIN;
					groupStrBuffer.append(grouperEmailId);
				}
			} 
			ldapContext.close();	
		}catch(Exception e) {
			try {
       		  if(mySearchResults!=null){
       		    mySearchResults.close();
       		  }
       		ldapContext.close();
       		 }catch (NamingException ex) {				
       			LOGGER.error(ex.getStackTrace());
			} 
			e.printStackTrace();
         return null;
		}
		LOGGER.info("getGroups details :: "+groupStrBuffer);
		return groupStrBuffer.toString();
	}
    
    public String getMailerGroupsLdapHost() {
		return mailerGroupsLdapHost;
	}

	public void setMailerGroupsLdapHost(String mailerGroupsLdapHost) {
		this.mailerGroupsLdapHost = mailerGroupsLdapHost;
	}

	public String getMailerGroupsGenericUser() {
		return mailerGroupsGenericUser;
	}

	public void setMailerGroupsGenericUser(String mailerGroupsGenericUser) {
		this.mailerGroupsGenericUser = mailerGroupsGenericUser;
	}

	public String getMailerGroupsGenericPwd() {
		return mailerGroupsGenericPwd;
	}

	public void setMailerGroupsGenericPwd(String mailerGroupsGenericPwd) {
		this.mailerGroupsGenericPwd = mailerGroupsGenericPwd;
	}

	public String getMailerGroupsGenericKey() {
		return mailerGroupsGenericKey;
	}

	public void setMailerGroupsGenericKey(String mailerGroupsGenericKey) {
		this.mailerGroupsGenericKey = mailerGroupsGenericKey;
	}
	
	public String getMailerGroupsLdapSearchBase() {
			return mailerGroupsLdapSearchBase;
		}

	public void setMailerGroupsLdapSearchBase(String mailerGroupsLdapSearchBase) {
			this.mailerGroupsLdapSearchBase = mailerGroupsLdapSearchBase;
		}
}
