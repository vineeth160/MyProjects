package com.cisco.alfresco.external.rootFolderCreation;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.transaction.RetryingTransactionHelper.RetryingTransactionCallback;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.site.SiteInfo;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.FavoriteUtil;

/**
 * 
 * @author prbadam - US5491 (Root Folder Creation in Doc Exchange)
 * 
 */
public class RootFolderCreation extends DeclarativeWebScript
{
	private static final Logger LOGGER = Logger.getLogger(RootFolderCreation.class);
	String SITE_NAME = "edcsng";
	String USERS = "Users";
    private ServiceRegistry serviceRegistry;
    private PermissionService permissionService;
    private ExternalLDAPUtil ldapUtil;
    public static String USER_ADMIN_ROLE = "Folder Admin";
    private static String preferenceFilter = "org.alfresco.share.folders.favourites";
    private PreferenceService preferenceService;
    private BehaviourFilter policyFilter;
    
    public BehaviourFilter getPolicyFilter() {
  		return policyFilter;
  	}
  	public void setPolicyFilter(BehaviourFilter policyFilter) {
  		this.policyFilter = policyFilter;
  	}
    
  	public void setPreferenceService(PreferenceService preferenceService) {
  		this.preferenceService = preferenceService;
  	}
    
    public ExternalLDAPUtil getLdapUtil() {
		return ldapUtil;
	}

	public void setLdapUtil(ExternalLDAPUtil ldapUtil) {
		this.ldapUtil = ldapUtil;
	}
    
    public PermissionService getPermissionService() {
		return permissionService;
	}

	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}

	public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }
 
    
	public NodeRef getSiteDocLibNodeRef (String siteName){
		LOGGER.info("inside getSiteDocLibNodeRef--------"+siteName);
		SiteInfo siteInfo = serviceRegistry.getSiteService().getSite(siteName);
		LOGGER.info("siteInfo--------"+siteInfo);
		
		//AuthenticationUtil.setFullyAuthenticatedUser("admin");
		NodeRef docLibNodRef = serviceRegistry.getSiteService().getContainer(siteInfo.getShortName(), "documentLibrary");
		LOGGER.info("docLibNodRef--------"+docLibNodRef);
		return docLibNodRef;
	}
	
	public NodeRef createFolder(final NodeRef parentNodeRef, final String folderName,String folderDescription,String domain,String isGusetAccess, String applyVeraProtection, String tags){
		NodeRef folderNodeRef = null;
		try {
		final Map<QName, Serializable> props = new HashMap<QName, Serializable>(1);
		props.put(ContentModel.PROP_NAME, folderName);
		props.put(ContentModel.PROP_TITLE, folderName);
		props.put(ContentModel.PROP_DESCRIPTION, folderDescription);
        //US8499 :prbadam start
		 folderNodeRef = serviceRegistry.getNodeService().createNode(parentNodeRef, ContentModel.ASSOC_CONTAINS,
					QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, folderName), ContentModel.TYPE_FOLDER, props).getChildRef();
         //US8499 :prbadam end
		//Uthra changes start - Tag
  	    if(tags != null && !tags.isEmpty()){
  	    	LOGGER.info("if tag is not empty on Node :: "+folderNodeRef +"  :: " +tags);
  	    	serviceRegistry.getNodeService().addAspect(folderNodeRef, ExternalSharingConstants.CISCO_TAG_ASPECT, null);
  	    	serviceRegistry.getNodeService().setProperty(folderNodeRef, ExternalSharingConstants.CISCO_QNAME_TAG_NAME, tags);
  	    }
  	    //Uthra changes end - Tag
  	    
		 //Vera changes for applying folder protection
		 LOGGER.info("applyVeraProtection value is " + applyVeraProtection + " for folder Name : " + folderName);
		 if(applyVeraProtection != null && applyVeraProtection.matches("Cisco Restricted|All Contents")){
			 Map<QName, Serializable> verFolderProtectionProps = new HashMap<>(6);
				verFolderProtectionProps.put(ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION,applyVeraProtection);
				verFolderProtectionProps.put(ExternalSharingConstants.PROP_IS_VERA_ROOT_FOLDER,true);
				verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ENABLED_DATE,new Date());
				verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ENABLED_BY,AuthenticationUtil.getFullyAuthenticatedUser());
				verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ROOT_FOLDER_NODEREF,folderNodeRef.toString());
				serviceRegistry.getNodeService().addAspect(folderNodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION, verFolderProtectionProps);
		 }
		 //vera changes End
		
		 // adding domainAspect to the node
	    Map<QName, Serializable> domainProp = new HashMap<QName, Serializable>(1);
	    domainProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"),domain);
	    serviceRegistry.getNodeService().addAspect(folderNodeRef,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domainAspect"), domainProp);
	    
	    //adding disableguestUser Aspect to the node
	    Boolean isGusetAccessEnabled = false;
		 if(isGusetAccess!=null && isGusetAccess!="")
			 isGusetAccessEnabled = Boolean.valueOf(isGusetAccess);	 
	    Map<QName, Serializable> disableGuestProp = new HashMap<QName, Serializable>(1);
	    disableGuestProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}disableguestUser"),isGusetAccessEnabled);
	    serviceRegistry.getNodeService().addAspect(folderNodeRef,
	    		QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domainAspect"), disableGuestProp);
	    
	    // setting Inherit permissions false by default
	    permissionService.setInheritParentPermissions(folderNodeRef, false);
		} catch (Exception e) {
    		LOGGER.info("Exception in createFolder mothod-----------"+e);
    		e.printStackTrace();
		}
		return folderNodeRef;
	}
	
	public Map<String, Object> getTargetNode(final String folderName,final String folderDescription,final String domain, final String logginUser,final String isGusetAccess,final String isFavorite, final String applyVeraProtction, final String tags, final String isEditorDeleteFiles)
	{
		LOGGER.info("inside getTargetNode--------");
		Map<String, Object> statusMessage = new HashMap<String, Object>();
		try{
		statusMessage = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Map<String, Object>>() {
				@Override
				public Map<String, Object> doWork() throws Exception {
					
					final Map<String, Object> innerModel = new HashMap<String, Object>();
					
					NodeRef siteNodeRef = getSiteDocLibNodeRef(SITE_NAME);
					
					NodeRef usersFolNodeRef = serviceRegistry.getFileFolderService().searchSimple(siteNodeRef, USERS);
					if (usersFolNodeRef == null) {
						if (LOGGER.isDebugEnabled()) {
							LOGGER.error("Creating users folder under documentLibrary");
						}
						usersFolNodeRef = createFolder(siteNodeRef, USERS,folderDescription,domain,isGusetAccess,null, null);
					}
					LOGGER.error("usersFolNodeRef creation completd :::: "+usersFolNodeRef);
					String year = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
					NodeRef yearNode = null;

					yearNode = serviceRegistry.getNodeService().getChildByName(usersFolNodeRef, ContentModel.ASSOC_CONTAINS, year);
					Map<QName, Serializable> props = new HashMap<QName, Serializable>(1);
					if (yearNode == null) {
						LOGGER.error("Creating year folder under USERS");
						props.put(ContentModel.PROP_NAME, year);
						yearNode = createFolder(usersFolNodeRef, year,folderDescription,domain,isGusetAccess,null, null);
					}
					LOGGER.error("yearNode folder creation completd ::: "+yearNode);
					
					NodeRef userNodeRef = serviceRegistry.getFileFolderService().searchSimple(yearNode, logginUser);
					if (userNodeRef == null) {
						LOGGER.error("Creating loginuser folder under year");
						userNodeRef = createFolder(yearNode, logginUser,folderDescription,domain,isGusetAccess,null, null);
					}
					LOGGER.error("logginUser folder creation completd ::: "+yearNode);
					NodeRef userFolderNode = serviceRegistry.getFileFolderService().searchSimple(userNodeRef, folderName);
					if (userFolderNode == null) {
						LOGGER.info("inside if ::"+userNodeRef);
						//setting Preferences to userFolderNode to show it in Library section. Added in transaction service for concurrency exception.
						 final NodeRef userFolderNodeFinal = userNodeRef;
						 NodeRef finalUserFolderNode = createFolder(userFolderNodeFinal, folderName,folderDescription,domain,isGusetAccess,applyVeraProtction, tags);
			        	 LOGGER.info("finalUserFolderNode-------"+finalUserFolderNode);
			        	 // START: US9855- adding editorDeleteFileAspect to the node
				     	    Map<QName, Serializable> editorDeleteFilesProp = new HashMap<QName, Serializable>(1);
				     	    editorDeleteFilesProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}editorDeleteFiles"),isEditorDeleteFiles);
				     	    serviceRegistry.getNodeService().addAspect(finalUserFolderNode,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}editorDeleteFileAspect"), editorDeleteFilesProp);
				     	    // END: US9855- adding editorDeleteFileAspect to the node
				     	    //START : US8067 - PRBADAM added Ability to mark a folder as favorite while creating a folder.
							FavoriteUtil.addFavorite(serviceRegistry, policyFilter, logginUser, isFavorite, finalUserFolderNode);
							//END : US8067 - PRBADAM added Ability to mark a folder as favorite while creating a folder.
							setRemovePreferences(logginUser,finalUserFolderNode);
						 //setting Folder Admin permissions to finalUserFolderNode
			        	 permissionService.setPermission(finalUserFolderNode, logginUser, "AdminRole", true);
			        	 LOGGER.error("Successfully created folder with Folder Admin permissions for folder node ---"+finalUserFolderNode);
						 innerModel.put("innerStatus", "Root folder created successfully");
						 innerModel.put("nodeId", finalUserFolderNode);
					} else {
						innerModel.put("innerStatus", "Folder already exists");
					LOGGER.info("Folder already exists ::::");
					}
					return innerModel;
				} 
	   	 }, "admin");
		
		} catch (Exception e) {
    		LOGGER.info("Exception in getTargetNode mothod :::: "+e);
    		e.printStackTrace();
		}
		return statusMessage;
	}
	
	/**
	 * To Update the user preferences with the given preference filter 
	 * @param preferences
	 * @param preferenceFilter
	 * @param values
	 * @return preference object
	 */
	private Map<String, Serializable> updatedPreference(Map<String, Serializable> preferences,String preferenceFilter,String values){
		LOGGER.info("Values-----------"+values);
		LOGGER.info("Preference size------"+preferences.size());
		try{
				if(preferences.containsKey(preferenceFilter)){
				String item=(String)preferences.get(preferenceFilter);
				//LOGGER.info("item----------"+item);
				
				String[] itemArray =item.split(",");
				List<String> list = new ArrayList<String>();
				if(itemArray.length > 0){
					Collections.addAll(list, itemArray);
				}
				if(list.contains(values)){
					list.remove(values);
				}else{
					list.add(values);
				}
				//LOGGER.info("list----------:"+list);
				preferences.put(preferenceFilter, StringUtils.join(list, ","));
				} else{
					preferences.put(preferenceFilter, values);
				}
		} catch (Exception e) {
    		LOGGER.info("Exception in updatedPreference mothod-----------"+e);
    		e.printStackTrace();
		}
		return preferences;
	}
	
	private void setRemovePreferences(final String usersList, final NodeRef documentNodeRef){
    	try{
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				Map<String, Serializable> finlaUpdatedPreferences=serviceRegistry.getTransactionService().getRetryingTransactionHelper().doInTransaction(new RetryingTransactionCallback<Map<String, Serializable>>(){
					 public Map<String, Serializable> execute() throws Throwable {
						 Map<String, Serializable> updatedPreferences = null;
						 try {
						 LOGGER.info("inside getRetryingTransactionHelper -------"+documentNodeRef);
						Map<String, Serializable> preferences = preferenceService.getPreferences(usersList,	preferenceFilter);
						LOGGER.info("preferences for perticular user----------"+preferences);
						updatedPreferences = updatedPreference(preferences, preferenceFilter, documentNodeRef.toString());
						LOGGER.info("Preferences to update-------------" + updatedPreferences);
						 }catch(Exception ex) {
							 ex.printStackTrace();
						 }
					return updatedPreferences;
			         }
			         }, false, true); 
				preferenceService.setPreferences(usersList, finlaUpdatedPreferences);
				LOGGER.info("finished setting setPreferences in setRemovePreferences method-----");
				return null;
			}
		}, "admin");
    	} catch (Exception e) {
    		LOGGER.info("Exception in setRemovePreferences mothod-----------"+e);
    		e.printStackTrace();
		}
    }
	
	/**
	 * 
	 * @param req
	 * @return
	 */
	private String readRequestBody(WebScriptRequest req) {
		try {
			return IOUtils.toString(req.getContent().getInputStream(), req
					.getContent().getEncoding());
		} catch (Exception e) {
			try {
				return req.getContent().getContent();
			} catch (IOException e1) {
				LOGGER.error("Unable to read JSON request body", e1);
				throw new WebScriptException(
						"Unable to read JSON request body!! Epic fail.");
			}
		}
	}
  
	  @Override
	    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
	    {
		  	LOGGER.info("--- Started RootFolderCreation----");
		  	Map<String, Object> model = new HashMap<String, Object>();
		  	String logginUser = AuthenticationUtil.getFullyAuthenticatedUser();
		  	LOGGER.info("logginUser---------"+logginUser);
		  	
			String inputJSONValue = readRequestBody(req);
			JSONObject jsonObject = null;
			String folderName=null , folderDescription=null, domain=null, isGusetAccess=null, isFavorite=null, applyVeraProtction=null, tags="", isEditorDeleteFiles=null;
			
			if(isUserInternal(logginUser) || isUserGenerics(logginUser)){
			try {
				jsonObject = new JSONObject(inputJSONValue);
				folderName = jsonObject.getString("name");
				isGusetAccess = jsonObject.getString("disableGuestUsers");
				applyVeraProtction = jsonObject.getString("applyVeraProtection");
				folderDescription = jsonObject.has("description")&&jsonObject.getString("description") !=null ? jsonObject.getString("description") : "";
 				domain = jsonObject.has("domain")&&jsonObject.getString("domain") !=null ? jsonObject.getString("domain") : "";	
				LOGGER.info("folderName---------"+folderName);
				
				isFavorite = jsonObject.getString("favorite");
 				LOGGER.info("isFavorite------"+isFavorite);
 				if(jsonObject.has("tags")){
 				tags = jsonObject.getString("tags");
 				LOGGER.info("tags------"+tags);
 				
 				isEditorDeleteFiles = jsonObject.getString("disableDeleteDocuments");
 				LOGGER.info("isEditorDeleteFiles------"+isEditorDeleteFiles);
 				
 				}
				Map<String, Object> finalStatusMessage = getTargetNode(folderName,folderDescription,domain,logginUser,isGusetAccess,isFavorite,applyVeraProtction,tags,isEditorDeleteFiles);
				
				LOGGER.info("finalStatusMessage---------"+finalStatusMessage);
				
				model.put("message", finalStatusMessage);
				LOGGER.info("--- Finished in RootFolderCreation----");
				
				}// End of try
			 catch (Exception e) {
					e.printStackTrace();
					LOGGER.info("in e---------"+e);
				}
			} // End of checking internal user
			  else
	            {
	                model.put("message", "You are not authorized to perform this operation.");
	            }
			return model;
	    }
	  
	  public boolean isUserInternal(String userid)
	    {
	        LOGGER.info((new StringBuilder("Start checking if internal LDAP users.. ")).append(userid).toString());
	        return ldapUtil.isLdapUserInternal((new StringBuilder(String.valueOf(userid))).toString());
	    }
	  public boolean isUserGenerics(String userid)
	  {
		  LOGGER.info((new StringBuilder("Start checking if Generics LDAP users.. ")).append(userid).toString());
	      return ldapUtil.isLdapUserGeneric((new StringBuilder(String.valueOf(userid))).toString());
	  }
}
