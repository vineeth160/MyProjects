package com.cisco.alfresco.external.webscript;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;

public class CheckVeraProtection extends DeclarativeWebScript
{

	private static final Logger logger = Logger.getLogger(CheckVeraProtection.class);

	private ServiceRegistry serviceRegistry;
	
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status,	Cache cache) {
		logger.error("CheckVeraProtection executeImpl method started::  ");
		String node = req.getParameter("nodeId");
		logger.error("Node :: " +node);
		NodeRef nodeRef = new NodeRef(node);
		if(node.contains("versionStore://version2Store/")){
			nodeRef = liveNode(nodeRef);
		}
		logger.error("NodeRef :: " +nodeRef);
		final Map<String, Object> result = new HashMap<String, Object>();
		try{
			NodeRef parentNodeRef = serviceRegistry.getNodeService().getPrimaryParent(nodeRef).getParentRef();
			logger.error("parentNodeRef :: " +parentNodeRef);
			String nodeRefVeraType = (String)serviceRegistry.getNodeService().getProperty(parentNodeRef, ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
			logger.error("nodeRefVeraType :: " +nodeRefVeraType);
			String nodeRefSecurityType = (String)serviceRegistry.getNodeService().getProperty(nodeRef, CiscoModelConstants.CISCO_SECURITY_PROP);
			logger.error("nodeRefSecurityType :: " +nodeRefSecurityType);
			nodeRefVeraType = (nodeRefVeraType!=null)?nodeRefVeraType:"";
			if(!nodeRefVeraType.isEmpty()){
				logger.error("is empty ....");
				if(("All Contents".equals(nodeRefVeraType) || "Cisco Restricted".equals(nodeRefVeraType) || !"Cisco Restricted".equals(nodeRefSecurityType))){
					result.put("isVera", "true");
					logger.error("vera protected content...");
				}else{
					result.put("isVera", "false");
				}
		}else{
			result.put("isVera", "false");
		}
		}
		catch(Exception e){
		     logger.error("Exception : " +e);	
		}
		return result;

}
	public NodeRef liveNode(NodeRef node) {
		logger.info("node  :: " +node );
		NodeRef nodeRef = null;
		 VersionHistory versionHistory = serviceRegistry.getVersionService().getVersionHistory(node);
	        if (versionHistory != null && versionHistory.getAllVersions().size() > 0)
	        {
	            Collection<Version> versions = versionHistory.getAllVersions();

	            for (Version versionNode : versions)
	            {
	               // Properties from VersioNode
	                 nodeRef = versionNode.getVersionedNodeRef();
	                 logger.info(" nodeRef  :: " +nodeRef);
	                break;
	               
	            }

	        }
			return nodeRef;
	        
		
	}	
}
