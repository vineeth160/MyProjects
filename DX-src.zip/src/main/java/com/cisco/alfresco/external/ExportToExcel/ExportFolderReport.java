package com.cisco.alfresco.external.ExportToExcel;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.Path;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.ISO9075;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.VerticalAlignment;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

public class ExportFolderReport extends AbstractWebScript{
	private static final Logger logger = Logger.getLogger(ExportFolderReport.class);
	private WritableCellFormat timesBoldUnderline;
	private ServiceRegistry serviceRegistry;
	private static Integer MAX_VALUE=64000;
	private static final String DOC_QNAME_PATH ="{http://www.cisco.com/model/content/1.0}";
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	
	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) {
		
		String nodeId = req.getParameter("nodeId");
		String currentUserName = AuthenticationUtil.getFullyAuthenticatedUser();
		logger.info("nodeId :: " +nodeId + "   currentUserName :: " +currentUserName);
		NodeRef nodeRef = new NodeRef(nodeId);
		logger.info("Calling canUserHavePermission method......");
		boolean isFolder = false;
		QName type = serviceRegistry.getNodeService().getType(nodeRef);
		if (type.equals(ContentModel.TYPE_FOLDER))
			isFolder = true;
		boolean hasAccess = canUserHavePermission(nodeRef,currentUserName,serviceRegistry);
		if(hasAccess && isFolder){
			exportReport(nodeRef, currentUserName, res);
		}
		
	}
	
	public void exportReport(final NodeRef nodeRef, String currentUserName, final WebScriptResponse res)
	{
		
		 Path path = serviceRegistry.getNodeService().getPath(nodeRef);
	     String queryPath = "";
	     if (queryPath != null)
	     {
	    	    queryPath = path.toString();
	            logger.info("filePath--------------- " + queryPath);
	            queryPath = queryPath.replaceAll("\\{http://www.alfresco.org/model/application/1.0\\}", "app:");
	            queryPath = queryPath.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "st:");
	            queryPath = queryPath.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}", "cm:");
	     }
	     logger.info("filePath--------------- " + queryPath); 
		 String fileQuery ="PATH:\""+queryPath+"//*\" AND TYPE:\"cs:ciscodoc\" AND -TYPE:\"cm:systemfolder\" AND READER:"+currentUserName; 
		 String folderQuery ="PATH:\""+queryPath+"//*\" AND TYPE:\"cm:folder\" AND -TYPE:\"cm:systemfolder\" AND READER:"+currentUserName;
		 logger.info("query :::::::::: " +folderQuery);
		 List<NodeRef> nodeList = new ArrayList<NodeRef>();
		 List<NodeRef> folderList = new ArrayList<NodeRef>();
		 folderList = getContentList(folderQuery);
		 nodeList = getContentList(fileQuery);
		 if(!folderList.isEmpty())
		     nodeList.addAll(folderList);
		 if(nodeList.size()>0)
		 {
		 WritableWorkbook workbook = null;
         Label lable = null;
         int folderNameColumn = 0;
         int docNameColumn = 1;
         int docVersionColumn = 2;
         int docIdNoColumn = 3;
         int modDateColumn = 4;
         int modByColumn = 5;
         int createdDateColumn = 6;
         int uploadedByColumn = 7;
         int versionCommentsColumn = 8;
         int row = 2;
         //String name = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NAME);
         WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);
         OutputStream os;
		try 
		{
		 os = res.getOutputStream();
	     workbook = Workbook.createWorkbook(os);
         WritableSheet wSheet1 = workbook.createSheet("Export Folder Content To Excel", 0);
         WritableCellFormat cellFormat = new WritableCellFormat(times10ptBoldUnderline);
         cellFormat.setAlignment(Alignment.CENTRE);
         cellFormat.setVerticalAlignment(VerticalAlignment.CENTRE);
         timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
         timesBoldUnderline.setWrap(true);
         wSheet1.insertColumn(folderNameColumn); 
	     lable = new Label(0, 1, "Folder Name",timesBoldUnderline);
	     wSheet1.addCell(lable);
	     wSheet1.insertColumn(docNameColumn); 
	     lable = new Label(1, 1, "Document Name",timesBoldUnderline);
		 wSheet1.addCell(lable);
		 wSheet1.insertColumn(docVersionColumn); 
		 lable = new Label(2, 1, "Document Version",timesBoldUnderline);
		 wSheet1.addCell(lable);
		 wSheet1.insertColumn(docIdNoColumn); 
		 lable = new Label(3, 1, "Doc ID No",timesBoldUnderline);
		 wSheet1.addCell(lable);
		 wSheet1.insertColumn(modDateColumn); 
		 lable = new Label(4, 1, "Modified Date",timesBoldUnderline);
		 wSheet1.addCell(lable);
		 wSheet1.insertColumn(modByColumn); 
		 lable = new Label(5, 1, "Modified By",timesBoldUnderline);
		 wSheet1.addCell(lable);
		 wSheet1.insertColumn(createdDateColumn); 
		 lable = new Label(6, 1, "Uploaded Date",timesBoldUnderline);
		 wSheet1.addCell(lable);
		 wSheet1.insertColumn(uploadedByColumn); 
		 lable = new Label(7, 1, "Uploaded By",timesBoldUnderline);
		 wSheet1.addCell(lable);
		 wSheet1.insertColumn(versionCommentsColumn); 
		 lable = new Label(8, 1, "Version Comments",timesBoldUnderline);
		 wSheet1.addCell(lable);
		 wSheet1. setColumnView(0, 40);
		 wSheet1. setColumnView(1, 25);
		 wSheet1. setColumnView(2, 15);
		 wSheet1. setColumnView(3, 15);
		 wSheet1. setColumnView(4, 25);
		 wSheet1. setColumnView(5, 20);
		 wSheet1. setColumnView(6, 25);
		 wSheet1. setColumnView(7, 20);
		 wSheet1. setColumnView(8, 25);
		 Date currentTime = new Date();
         SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM d yyyy hh:mm:ss a z");
         sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		 logger.info("GMT time : " + sdf.format(currentTime));
		 wSheet1.mergeCells(folderNameColumn, 0, versionCommentsColumn, 0);
         lable = new Label(0, 0, "Report generated by "+currentUserName + " on "+sdf.format(currentTime), timesBoldUnderline);
         wSheet1.addCell(lable);
  		 for(NodeRef node : nodeList){
			 QName type = serviceRegistry.getNodeService().getType(node);
			 Map<QName, Serializable> nodeProp = serviceRegistry.getNodeService().getProperties(node);
			 lable = new Label(modDateColumn, row, getGMTDateFormat((Date)nodeProp.get(ContentModel.PROP_MODIFIED)));
			 wSheet1.addCell(lable);
			 lable = new Label(modByColumn, row, (String) nodeProp.get(ContentModel.PROP_MODIFIER));
			 wSheet1.addCell(lable);
			 lable = new Label(createdDateColumn, row, getGMTDateFormat((Date)nodeProp.get(ContentModel.PROP_CREATED)));
			 wSheet1.addCell(lable);
			 lable = new Label(uploadedByColumn, row, (String) nodeProp.get(ContentModel.PROP_CREATOR));
			 wSheet1.addCell(lable);
				if (type.equals(ContentModel.TYPE_FOLDER))
				{
					Path folderpath = serviceRegistry.getNodeService().getPath(node);
			        String folderPath = "";
			        if (path != null)
			        {
			        	folderPath = folderpath.toString();
			        	folderPath = folderPath.replaceAll("\\{http://www.alfresco.org/model/application/1.0\\}", "");
			        	folderPath = folderPath.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "");
			            folderPath = folderPath.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}", "");
			        }
			        logger.info("folderPath =-::::"+folderPath);  ///Users/2017/dekeswan/Audios
			        folderPath = ISO9075.decode(folderPath).replace("/company_home/sites/edcsng/documentLibrary", "");
			        lable = new Label(folderNameColumn, row, folderPath);
					wSheet1.addCell(lable);
			    }
				else
				{
					Path filepath = serviceRegistry.getNodeService().getPath(node);
			        String filePath = "";
			        if (filepath != null)
			        {
			        	filePath = filepath.toString();
			        	filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/application/1.0\\}", "");
			        	filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "");
			        	filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}", "");
			        }
			        filePath = filePath.replace("/company_home/sites/edcsng/documentLibrary", "");
			        String name = (String) nodeProp.get(ContentModel.PROP_NAME);
			        
			        if (filePath.length() > DOC_QNAME_PATH.length() && filePath.contains(DOC_QNAME_PATH))
			         {
			        	 String filePathWithName = filePath.substring(filePath.lastIndexOf('{')-1,filePath.length());
					        filePath=filePath.replace(filePathWithName, "");
					        filePath = ISO9075.decode(filePath);
					        logger.info("filePath  :::::: " +filePath);
			         }else {
					        filePath = ISO9075.decode(filePath).replace("/"+name, "");
					        logger.info("filePath  ::::::: " +filePath);
			         }
			        
			        lable = new Label(folderNameColumn, row, filePath);
					wSheet1.addCell(lable);
				    lable = new Label(docNameColumn, row, name);
					wSheet1.addCell(lable); 
					String strVersion = (String) nodeProp.get(ContentModel.PROP_VERSION_LABEL);
					//logger.error("strVersion -----  " +strVersion);
			        //double version = Double.parseDouble((strVersion != null ? strVersion : "1.0"));
			       // logger.error("version -----  " +version); 
			        lable = new Label(docVersionColumn, row, strVersion);
					wSheet1.addCell(lable);
					lable = new Label(docIdNoColumn, row, (String) nodeProp.get(ExternalSharingConstants.PROP_EDCS_ID));
					wSheet1.addCell(lable);
					String comment = (String) nodeProp.get(QName.createQName("http://www.cisco.com/model/content/1.0", "comment"));
			        if (comment == null || comment.equalsIgnoreCase("undefined") || comment.equalsIgnoreCase(""))
			        {
			            comment = " ";
			        }
					lable = new Label(versionCommentsColumn, row, comment);
					wSheet1.addCell(lable);
				}
				row++;
		 }
         
         
         
		workbook.write();
        workbook.close();
        res.addHeader("Content-Disposition", "attachment;filename=ExportFolderDetails.xls");
        res.setContentType("application/vnd.ms-excel");
        res.setContentEncoding("UTF-8");
        res.setHeader("Cache-Control", "private, max-age=0");
        logger.info("Excel File Downloaded Successfully...");
		} 
		catch (IOException | WriteException e) {
			e.printStackTrace();
		}
		 }
	}
	
	private boolean canUserHavePermission(NodeRef nodeRef,String currentUserName,ServiceRegistry serviceRegistry) {
		boolean canPermission = false;
		Iterator<AccessPermission> fIterator;
		Set<AccessPermission> accessPermissions =serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
		fIterator = accessPermissions.iterator();
		while (fIterator.hasNext()) {
			AccessPermission accessPermission = (AccessPermission) fIterator.next();
            if (accessPermission.getAuthorityType() == AuthorityType.USER && accessPermission.getPermission().equals("AdminRole")) {
                String autherityUserName = accessPermission.getAuthority();
				if (autherityUserName.equals(currentUserName)) {
					return true;
				}
			}
		}
		return canPermission;
	}
	
	private List<NodeRef> getContentList(String searchQuery){ 
		int skipCount = 0;
		List<NodeRef> nodeRefList = null;
		while(true)
		{
			SearchParameters sp = new SearchParameters();
			sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
			sp.setLanguage(SearchService.LANGUAGE_LUCENE);
			sp.setMaxItems(500);
			sp.setSkipCount(skipCount);
			sp.setQuery(searchQuery);
			ResultSet results = serviceRegistry.getSearchService().query(sp);
			if(skipCount == 0)
				nodeRefList = new ArrayList<NodeRef>();
			if (null == results || results.length() <= 0)
				break;
			for (ResultSetRow row : results) {
				nodeRefList.add(row.getNodeRef());
			}
			//}
			results.close();
			if(skipCount == MAX_VALUE)
				break;
			skipCount += 500;
		}
	return nodeRefList;
	}
	
	 public static String getGMTDateFormat(Date date){
			DateFormat df;
			String formatedDate="";
			try{
			df = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));
			if(date != null){
				formatedDate=df.format(date);
				}
				}catch(Exception e){
					logger.error("Exception....."+e);
				}
			return formatedDate;
		}
	    
	

}
