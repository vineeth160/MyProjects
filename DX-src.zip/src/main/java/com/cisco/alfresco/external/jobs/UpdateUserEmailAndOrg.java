package com.cisco.alfresco.external.jobs;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.PersonService;
import org.apache.log4j.Logger;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;
import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;


public class UpdateUserEmailAndOrg extends QuartzJobBean
{
    private static Logger logger = Logger.getLogger(UpdateUserEmailAndOrg.class);
    private ServiceRegistry serviceRegistry;
    private PersonService personService;
    private NodeService nodeService;   
	private static final String KEY_IS_JOB_ENABLED = "updateUserEmailAndOrgJobEnable";
    private static final String MAX_LIMIT = "searchMaxLimit";
	private boolean isJobEnabled = false;
	int userCount = 0;
    private ExternalLDAPUtil ldapUtil;

    
    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException
    {

    	JobDataMap jobData = context.getJobDetail().getJobDataMap();
	    String isJobEnabledStr = (String) jobData.get(KEY_IS_JOB_ENABLED);
	    final int  MAX_VALUE = Integer.parseInt((String) jobData.get(MAX_LIMIT));
	    if (isJobEnabledStr != null){
		try {
			 isJobEnabled = new Boolean(isJobEnabledStr);
			 logger.info("isenabled " + isJobEnabled);
			}catch (Exception e) {
			  logger.info("Invalid '" + KEY_IS_JOB_ENABLED
						+ "' value, using default: " + isJobEnabled, e);
			}
		}
		if (!isJobEnabled) {
			logger.info("Skipping " + KEY_IS_JOB_ENABLED + " to execute.");
			return;
		}
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				
				//String strPersonQuery = "TYPE:\"cm:person\" AND -@cm\\:email:(*@cisco.com*)";
				List<NodeRef> nodeRefList = EDCSUtil.getNodeRefListForUsers(
						getSearchExUserluceneQry(), serviceRegistry, MAX_VALUE);
				if (nodeRefList != null &&!nodeRefList.isEmpty() && nodeRefList.size() > 0) {
					logger.info("The total number of users to be updated : "
							+ nodeRefList.size());
					for (NodeRef nodeRef : nodeRefList) {
						logger.info("nodeRef::" + nodeRef);                        
						updateAllExternalUser(nodeRef);
					}

					logger.info("The total number of users has been updated : "
							+ userCount);
				}else {
					logger.info("No results found to update ");
				}
				return null;
			}
		}, "admin");
	}

	private void updateAllExternalUser(NodeRef nodeRef) {
		try {
			personService = serviceRegistry.getPersonService();
			nodeService = serviceRegistry.getNodeService();
			String strUserDetails = null;
			 String email = null; 
			 String organization = null;
			String strUnameRepo = (String) nodeService.getProperty(nodeRef, ContentModel.PROP_USERNAME);
			logger.info("strUnameRepo     " + strUnameRepo);
			if (strUnameRepo != null) {
				strUserDetails = ldapUtil.getUserDetailsFromLDAP(strUnameRepo);
			}
			
			if (strUserDetails != null && !"".equalsIgnoreCase(strUserDetails) && !strUserDetails.isEmpty()) {
				setUserInfo(strUserDetails, nodeRef);
				logger.info("strUnameRepo1     " + strUserDetails);
				organization = (strUserDetails.split("::"))[2];
				email = (strUserDetails.split("::"))[3];				
				logger.info("emailId:: "+email+"  organization:: "+organization);
			}
			
			if (email == null || "".equalsIgnoreCase(email)) {
			    strUserDetails = ldapUtil
						.getGenericUserDetailsFromLDAP(strUnameRepo);
				

				if (strUserDetails != null
						&& !"".equalsIgnoreCase(strUserDetails) && !strUserDetails.isEmpty()) {
					setUserInfo(strUserDetails, nodeRef);
					logger.info("GenericUser strUnameRepo2     " + strUserDetails);
					organization = (strUserDetails.split("::"))[2];
					email = (strUserDetails.split("::"))[3];				
					logger.info(" GenericUser emailId:: "+email+"  organization:: "+organization);
				}
			}
			if (email == null || "".equalsIgnoreCase(email)) {
				nodeService.setProperty(nodeRef, ContentModel.PROP_EMAIL,
						strUnameRepo + "@cisco.com");
				if (organization == null)
					nodeService.setProperty(nodeRef,
							ContentModel.PROP_ORGANIZATION, "Not Exist");
				logger.info("User info has been updated for " + strUnameRepo
						+ " has been updated");
				userCount = userCount + 1;
			
			}

		}catch (ParseException e) {
			logger.error("ParseException found in updateAllExternalUser :: "+e.getStackTrace());
			e.printStackTrace();
		}
		catch (Exception e) {
			logger.error("Error found in updateAllExternalUser ");
			logger.error(e.getStackTrace());
			e.printStackTrace();
		}

	}
    
    public void setUserInfo(String strUserDetails,NodeRef nodeRef) throws ParseException{
    	String email = null; 
		String organization = null;
		String strFirstName = "", strLastName = ""; 
		String struserName = null;
		String fullName = null;
		String whenChanged = null;
    	 logger.info(" User Details ::: " + strUserDetails);    	
    	 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss'.0Z'");
         dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
         Timestamp timestamp, currentTime, sevendaysago =null;         
         whenChanged = (strUserDetails.split("::"))[5];
    	if(whenChanged!= null && whenChanged!=""){    		
            Date parsedDate = dateFormat.parse(String.valueOf(whenChanged));            
    		Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
            long Curmilli = cal.getTimeInMillis();
            currentTime = new Timestamp(Curmilli);                           
    		sevendaysago = new Timestamp(Curmilli - ((24*60*60 + 1) * 1000*7));	    		
    		timestamp = new java.sql.Timestamp(parsedDate.getTime());
    		logger.info("Current Time::: "+currentTime +"  Sevendaysago Time::: "+sevendaysago+"  LdapTime:::  "+timestamp); 
    		if(timestamp.after(sevendaysago)&&timestamp.before(currentTime)){
				struserName = (strUserDetails.trim().split("::"))[0];
				fullName = (strUserDetails.split("::"))[1];
				organization = (strUserDetails.split("::"))[2];
				email = (strUserDetails.split("::"))[3];				
				logger.info("struserName:: " + struserName+ "  fullName:: "+fullName+"  email:: "+email+"  organization:: "+organization+"  whenChanged::"+whenChanged);
				if (fullName != null && fullName != "") {
					if (fullName.trim().contains(" ")) {
						strFirstName = (fullName.split(" "))[0];
						strLastName = (fullName.split(" "))[1];
					} else
						strFirstName = fullName;
				} else
					strFirstName = fullName;
		
				boolean isUserExists = personService.personExists(struserName);
				if (isUserExists) {
					if (strFirstName != null || strFirstName != "")
						nodeService.setProperty(nodeRef,
								ContentModel.PROP_FIRSTNAME, strFirstName);
					if (strLastName != null || strLastName != "")
						nodeService.setProperty(nodeRef,
								ContentModel.PROP_LASTNAME, strLastName);
					if (email != null)
						nodeService.setProperty(nodeRef,
								ContentModel.PROP_EMAIL, email);
					if (organization != null)
						nodeService.setProperty(nodeRef,
								ContentModel.PROP_ORGANIZATION,
								organization);
					logger.info("User info has been updated for "
							+ struserName + " has been updated");
					userCount = userCount+1;
		           
				}
	    	}
    	}
	}
  
    
    public ExternalLDAPUtil getLdapUtil()
    {
        return ldapUtil;
    }

    public void setLdapUtil(ExternalLDAPUtil ldapUtil)
    {
        this.ldapUtil = ldapUtil;
    }
    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }
    private String searchExUserluceneQry; 
    /**
	 * @return the searchExUserluceneQry
	 */
	public String getSearchExUserluceneQry() {
		return searchExUserluceneQry;
	}

	/**
	 * @param searchExUserluceneQry the searchExUserluceneQry to set
	 */
	public void setSearchExUserluceneQry(String searchExUserluceneQry) {
		this.searchExUserluceneQry = searchExUserluceneQry;
	}

}
