package com.cisco.alfresco.external.domain;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.version.Version2Model;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.ISO9075;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;

public class GCPermissionCheck  extends AbstractWebScript {
	private static final Logger LOGGER = Logger.getLogger(GCPermissionCheck.class);
	private ServiceRegistry serviceRegistry;
	private String ldapHost;
	private NodeService nodeService;
	private AuditComponent auditComponent;
	public NodeService getNodeService() {
		return nodeService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public AuditComponent getAuditComponent() {
		return auditComponent;
	}

	public void setAuditComponent(AuditComponent auditComponent) {
		this.auditComponent = auditComponent;
	}

	public String getLdapHost() {
		return ldapHost;
	}

	public void setLdapHost(String ldapHost) {
		this.ldapHost = ldapHost;
	}


	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	/** CONSTANTS USED */
	// static final String LDAP_HOST = "ldap://dsx.cisco.com:389";
	static final String LDAP_SEARCHBASE = "ou=ccoentities,o=cco.cisco.com";
	// static final String[] LDAP_ATTRIBUTES = {"sn", "accessLevel","uid", "mail", "cn", "givenname","co","company"};
	static final String LDAP_MAIL_ATTRIBUTES = "mail";// "uid";
	static final String LDAP_UID_ATTRIBUTES = "uid";
	static final String LDAP_CN_ATTRIBUTES = "cn";
	static final String LDAP_COMPANY_ATTRIBUTES = "company";
	static final String LDAP_ACCESS_LEVEL_ATTRIBUTE = "accessLevel";
	private static final String LDAP_EMPLOYEE_TYPE_ATTRIBUTES = "employeeType";
	private static final String LDAP_WHEN_CHANGED_ATTRIBUTES = "whenChanged";
	private static final String NA="N/A";

	public void execute(final WebScriptRequest req,final WebScriptResponse res) 
	{
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				JSONObject responseObject = new JSONObject();
				String noderef = req.getParameter("nodeId");
				String userId = req.getParameter("userId"); 
				String isVersioned = req.getParameter("isVersioned");
				String availableInGCS = req.getParameter("availableInGCS"); 
				LOGGER.info("noderef : :" + noderef + "  userId ::  " +userId);
				LOGGER.info("isVersioned : " +isVersioned + "  availableInGCS : " +availableInGCS);

				String nodeId = null;
				if(isVersioned.equalsIgnoreCase("true")){
					nodeId  = "versionStore://version2Store/"+noderef; 
				}else{
					nodeId = "workspace://SpacesStore/"+noderef;
				}

				NodeRef nodeRef = new NodeRef(nodeId);
				if (Version2Model.STORE_ID.equals(nodeRef.getStoreRef().getIdentifier())) // "version2Store"
				{
					NodeRef currentNodeRef = new NodeRef(StoreRef.PROTOCOL_WORKSPACE, Version2Model.STORE_ID, nodeRef.getId());
					NodeRef  frozenNodeRef= (NodeRef) serviceRegistry.getNodeService().getProperty(currentNodeRef, Version2Model.PROP_QNAME_FROZEN_NODE_REF);
					LOGGER.info("frozenNodeRef : " + frozenNodeRef);
					nodeRef = frozenNodeRef;
				}
				LOGGER.info("noderef value :: " +nodeRef);
				if(nodeRef != null && serviceRegistry.getNodeService().exists(nodeRef))
				{
					if(hasAccess(userId, nodeRef))
					{
						LOGGER.info("if has access---");
						if(availableInGCS.equalsIgnoreCase("true")){
							Date currentTime = new Date();
							getDownloadAuditInfo(nodeRef.toString(), userId, currentTime); 
						}
						res.setStatus(200);
						responseObject.put("isSuccess", true);
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();


					}
					else{
						LOGGER.info("User dont have the permission on the noderef");
						res.setStatus(401);
						responseObject.put("isSuccess", false);
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						
					}
				}   else{
					res.setStatus(401);
					responseObject.put("isSuccess", false);
					res.getWriter().write(responseObject.toString());
					res.setContentType("application/json");
					res.getWriter().close();
					LOGGER.info("Invalid NodeRef...Please check the parameters passed.");
					//res.setStatus(401);
				}


				return res;
			}
		},"admin");


	}

	public static Set<AccessPermission> getAllNodeRefPermissions(final ServiceRegistry serviceRegistry, final NodeRef nodeRef){
		final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef));
				return null;
			}
		}, "admin");
		return accessPermission;
	}



	public boolean hasAccess(String currentUser, NodeRef nodeRef)
	{
		if (currentUser.equals("admin"))
		{
			return true;
		}
		Set<AccessPermission> userSet = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
		if (userSet.size() > 0)
		{
			for (AccessPermission accessPermission : userSet)
			{
				String user = accessPermission.getAuthority();
				LOGGER.info("user : " + user);
				//   LOGGER.info("accessPermission.getPermission : " + accessPermission.getPermission());
				// LOGGER.info("accessPermission.getAuthorityType : " + accessPermission.getAuthorityType());
				if (user.equals(currentUser))
				{
					return true;
				}
			}
		}

		return false;
	}

	public String getUserDetailsFromLDAP(String userLoginName)
	{
		StringBuffer strBuffer = new StringBuffer();
		DirContext myDirContext = null;
		NamingEnumeration<SearchResult> mySearchResults = null;
		try
		{
			String myFilter = "(uid=" + userLoginName + ")";
			LOGGER.info("myFilter  ::: " +myFilter);
			Hashtable<String, String> myEnv = new Hashtable<String, String>();
			myEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
			myEnv.put(Context.PROVIDER_URL, getLdapHost()); // ldap://dsx.cisco.com:389
			myDirContext = new InitialDirContext(myEnv);
			SearchControls mySearchControls = new SearchControls();
			mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			mySearchResults = myDirContext.search(LDAP_SEARCHBASE, myFilter,
					mySearchControls);

			SearchResult myNextEmployee;
			while (mySearchResults != null && mySearchResults.hasMore())
			{
				myNextEmployee = (SearchResult) mySearchResults.next();
				if (myNextEmployee.getAttributes().get(LDAP_UID_ATTRIBUTES) != null)
				{
					String userId = myNextEmployee.getAttributes().get(LDAP_UID_ATTRIBUTES).get().toString();
					strBuffer.append(userId);
				}
				if (myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES) != null)
				{
					String name = myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES).get().toString();
					strBuffer.append("::" + name + "::");
				}
				if (myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES) != null)
				{
					String company = myNextEmployee.getAttributes().get(LDAP_COMPANY_ATTRIBUTES).get().toString();
					strBuffer.append(company+"::");
				}
				if (myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES) != null)
				{
					String email = myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES).get().toString();
					strBuffer.append(email+"::");
				}
				if (myNextEmployee.getAttributes().get(LDAP_EMPLOYEE_TYPE_ATTRIBUTES) != null)
				{
					String employeeType = myNextEmployee.getAttributes().get(LDAP_EMPLOYEE_TYPE_ATTRIBUTES).get().toString();
					strBuffer.append(employeeType+"::");
				}else{
					String employeeType =NA;
					strBuffer.append(employeeType+"::");
				}
				if (myNextEmployee.getAttributes().get(LDAP_WHEN_CHANGED_ATTRIBUTES) != null)
				{
					String whenChanged = myNextEmployee.getAttributes().get(LDAP_WHEN_CHANGED_ATTRIBUTES).get().toString();
					strBuffer.append(whenChanged+"::");
				}
				if (myNextEmployee.getAttributes().get(LDAP_ACCESS_LEVEL_ATTRIBUTE) != null)
				{
					String accessLevel = myNextEmployee.getAttributes().get(LDAP_ACCESS_LEVEL_ATTRIBUTE).get().toString();
					strBuffer.append(accessLevel);
				}else{
					String accessLevel ="1";
					strBuffer.append(accessLevel);
				}

			}
			if(mySearchResults!=null){
				mySearchResults.close();
			}
			myDirContext.close();
		}
		catch (Exception e)
		{
			try {
				if(mySearchResults!=null){
					mySearchResults.close();
				}
				myDirContext.close();
			}catch (NamingException ex) {				
				LOGGER.error(ex.getStackTrace());
			} 
			return null;
		}
		return strBuffer.toString();
	}


	public void getDownloadAuditInfo(String nodeRefStr, String downloadedBy, Date currentTime)
	{
		LOGGER.info("-------- Download Document Auditing STARTS ------------");

		Map<String, Serializable> auditEntry = new HashMap<String, Serializable>();
		List<NodeRef> finalList = new ArrayList<NodeRef>();
		boolean folderBool = false;

		try {
		LOGGER.info("nodeRefStr:: "+nodeRefStr);
			NodeRef nodeRef = new NodeRef(nodeRefStr); // Phani

			LOGGER.info("nodeRef:: "+nodeRef);
			String nodePath = nodeService.getPath(nodeRef).toDisplayPath(nodeService, serviceRegistry.getPermissionService());
			String prefixedPath = ISO9075.decode(nodeService.getPath(nodeRef).toPrefixString(serviceRegistry.getNamespaceService()));
			/**
			 * For Verison Nodes, we have to fetch the FrozenNode (Live Node) and get the display path. - STARTS - Deepak -
			 * On July 23, 2014
			 */
			if (Version2Model.STORE_ID.equals(nodeRef.getStoreRef().getIdentifier())) // "version2Store"
			{   
				nodeRef = new NodeRef(StoreRef.PROTOCOL_WORKSPACE, Version2Model.STORE_ID, nodeRef.getId());
				NodeRef  frozenNodeRef= (NodeRef) nodeService.getProperty(nodeRef, Version2Model.PROP_QNAME_FROZEN_NODE_REF);
				//System.out.println("frozenNodeRef : " + frozenNodeRef);
				nodePath = nodeService.getPath(frozenNodeRef).toDisplayPath(nodeService, serviceRegistry.getPermissionService());
				prefixedPath = ISO9075.decode(nodeService.getPath(frozenNodeRef).toPrefixString(serviceRegistry.getNamespaceService()));
				//System.out.println("nodePath : " + nodePath);
			}

			/**
			 * For Verison Nodes, we have to fetch the FrozenNode (Live Node) and get the display path. - STARTS - Deepak -
			 * On July 23, 2014
			 */
			boolean file = serviceRegistry.getDictionaryService().isSubClass(serviceRegistry.getNodeService().getType(nodeRef), ContentModel.TYPE_CONTENT);
			if(file)
			{
				finalList.add(nodeRef);
			} else {
				folderBool = true;
			}
			final List<NodeRef> finalList1 = new ArrayList<NodeRef>();
			final String currentUserName = serviceRegistry.getAuthenticationService().getCurrentUserName();
			if (folderBool) {
				final NodeRef node = nodeRef;

				AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
					@Override
					public Object doWork() throws Exception {

						//List<NodeRef> list = new ArrayList<NodeRef>();
						StringBuffer subFoldersQry 	= new StringBuffer("PATH:\"");
						subFoldersQry.append(nodeService.getPath(node).toPrefixString(serviceRegistry.getNamespaceService())).append("//*\" ");
						LOGGER.info(" Sub Folders Query ::"+subFoldersQry.toString());
						ResultSet subFileFolderList = serviceRegistry.getSearchService().query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_LUCENE, subFoldersQry.toString());
						if(subFileFolderList != null){
							LOGGER.info("subFileFolderList size ::: if not null " );

							for(ResultSetRow row: subFileFolderList ){
								LOGGER.info("row.getNodeRef()  ::: " +row.getNodeRef());
								if(hasAccess(currentUserName,row.getNodeRef())){

									finalList1.add(row.getNodeRef());
								}
							}

							LOGGER.info(" final List size :"+finalList1.size());
							subFileFolderList.close();
						}
						return null;

					}
				},"admin");
			}

			if(finalList1 != null && finalList1.size() >0){
				LOGGER.info("Adding all--------->>>>");
				finalList.addAll(finalList1);
			}

			if (finalList != null && finalList.size() >0) {
				for(NodeRef node:finalList) {
					Map<QName, Serializable> nodeProp = nodeService.getProperties(node);
					String edcsId = (String) nodeProp.get(ExternalSharingConstants.PROP_EDCS_ID);
					if (edcsId != null) {
						auditEntry.put("noderef", nodeRefStr);
						auditEntry.put("docname", (String) nodeProp.get(ContentModel.PROP_NAME));
						auditEntry.put("creator", (String) nodeProp.get(ContentModel.PROP_CREATOR));
						auditEntry.put("modifier", (String) nodeProp.get(ContentModel.PROP_MODIFIER));
						auditEntry.put("path", nodePath);
						auditEntry.put("prefixedPath", prefixedPath);
						auditEntry.put("description", (String) nodeProp.get(ContentModel.PROP_DESCRIPTION));
						auditEntry.put("security", (String) nodeProp.get(CiscoModelConstants.CISCO_SECURITY_PROP));

						// QName edcsIdQName = QName.createQName(CiscoModelConstants.CISCO_MODEL_URI, "alf_id");
						auditEntry.put("edcsid", edcsId);

						//added by mkatnam for download Audit Report and setting download count property
						int downloadCount = 1;
						//DE2024

						auditEntry.put("contentsize",formatFileSize(serviceRegistry.getFileFolderService().getReader(node).getContentData().getSize()));

						if(nodeProp.get(CiscoModelConstants.PROP_CISCO_DOWNLOAD_COUNT) != null){
							downloadCount = (Integer) nodeProp.get(CiscoModelConstants.PROP_CISCO_DOWNLOAD_COUNT);
						}
						auditEntry.put("downloadcount", String.valueOf(downloadCount));

						//end mkatnam
						auditComponent.recordAuditValues("/download-report/document", auditEntry);

						LOGGER.info(" AuditEntry :" + auditEntry);
					}
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}

		LOGGER.info("---------- Download Document Auditing ENDS -----------");

	}
	public static String formatFileSize(long size) {
		String hrSize = null;

		double b = size;
		double k = size/1024.0;
		double m = ((size/1024.0)/1024.0);
		double g = (((size/1024.0)/1024.0)/1024.0);
		double t = ((((size/1024.0)/1024.0)/1024.0)/1024.0);

		DecimalFormat dec = new DecimalFormat("0.00");

		if ( t>1 ) {
			hrSize = dec.format(t).concat(" TB");
		} else if ( g>1 ) {
			hrSize = dec.format(g).concat(" GB");
		} else if ( m>1 ) {
			hrSize = dec.format(m).concat(" MB");
		} else if ( k>1 ) {
			hrSize = dec.format(k).concat(" KB");
		} else {
			hrSize = dec.format(b).concat(" Bytes");
		}
		return hrSize;
	}




}


