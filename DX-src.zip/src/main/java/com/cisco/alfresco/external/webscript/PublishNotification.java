package com.cisco.alfresco.external.webscript;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.TemplateService;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.edcsng.util.MailUtil;


public class PublishNotification extends AbstractWebScript //implements ExternalChannelConstants
{
    private static final Logger LOG = Logger.getLogger(PublishNotification.class);
    private ServiceRegistry serviceRegistry = null;
    private TemplateService templateService;
    private String mailServer;

    /**
     * 
     * @author dhshaw
     * 
     */
    @Override
    public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException
    {
        try
        {

            NodeService nodeService = serviceRegistry.getNodeService();

            LOG.info("PublishNotification method starts....");
            org.springframework.extensions.surf.util.Content content = req.getContent();
            org.json.JSONObject json;
            json = new org.json.JSONObject(content.getContent());
            String nodeRef = json.getString("nodeRef");
            LOG.info("nodeRef::" + nodeRef);
            String finalUsers = json.getString("finalUsers");
            String[] toMany = finalUsers.split(",");
            // finalUsers = finalUsers.replaceAll(",", ";");
            LOG.info("finalUsers::" + finalUsers);
            // String publisher = json.getString("publisher");
            String publisher = AuthenticationUtil.getFullyAuthenticatedUser();
            LOG.info("publisher::" + publisher);

            String template = "/alfresco/extension/templates/email/publishNotification.ftl";
            Map<String, Object> model = new HashMap<String, Object>();
            templateService = serviceRegistry.getTemplateService();
            NodeRef publisherNode = serviceRegistry.getPersonService().getPerson(publisher);
            LOG.info("publisherNode::" + publisherNode);
            String publisherFirstName = (String) nodeService.getProperty(publisherNode, ContentModel.PROP_FIRSTNAME);
            LOG.info("publisherFirstName::" + publisherFirstName);
            String publisherLastName = (String) nodeService.getProperty(publisherNode, ContentModel.PROP_LASTNAME);
            LOG.info("publisherLastName::" + publisherLastName);
            String publisherMailId = (String) nodeService.getProperty(publisherNode, ContentModel.PROP_EMAIL);
            String creator = (String) nodeService.getProperty(new NodeRef(nodeRef), ContentModel.PROP_CREATOR);
            String docName = (String) nodeService.getProperty(new NodeRef(nodeRef), ContentModel.PROP_NAME);
            String version = (String) nodeService.getProperty(new NodeRef(nodeRef), ContentModel.PROP_VERSION_LABEL);
            String cc = null;
            if (!creator.equals(publisher))
            {
                cc = creator + "@cisco.com";
            }
            else

                model.put("publisher", publisherFirstName + " " + publisherLastName);
            model.put("docName", docName);
            model.put("version", version);
            String htmlBody = templateService.processTemplate(template, model);
            String subject = publisherFirstName + " " + publisherLastName + " published a document on Cisco Share";
            MailUtil.sendMail(mailServer, publisherMailId, toMany, cc, subject, htmlBody, null);
        }
        catch (Exception e)
        {
            LOG.error("Exception :" + e);
            e.printStackTrace();
        }
    }

    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    public void setMailServer(String mailServer)
    {
        this.mailServer = mailServer;
    }

    public String getMailServer()
    {
        return mailServer;
    }

}
