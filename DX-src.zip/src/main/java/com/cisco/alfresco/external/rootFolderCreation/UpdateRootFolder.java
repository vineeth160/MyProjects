package com.cisco.alfresco.external.rootFolderCreation;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;

/**
 * 
 * @author prbadam - US5491 and DE4624 (Root Folder Creation in Doc Exchange)
 * 
 */
public class UpdateRootFolder extends DeclarativeWebScript
{
	private static final Logger LOGGER = Logger.getLogger(UpdateRootFolder.class);
    private ExternalLDAPUtil ldapUtil;
    private static String preferenceFilter = "org.alfresco.share.folders.favourites";
    private PreferenceService preferenceService;
    private ServiceRegistry serviceRegistry;
    
    
  	public void setPreferenceService(PreferenceService preferenceService) {
  		this.preferenceService = preferenceService;
  	}
    
    public ExternalLDAPUtil getLdapUtil() {
		return ldapUtil;
	}

	public void setLdapUtil(ExternalLDAPUtil ldapUtil) {
		this.ldapUtil = ldapUtil;
	}
	
	public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }
	/**
	 * To Update the user preferences with the given preference filter 
	 * @param preferences
	 * @param preferenceFilter
	 * @param values
	 * @return preference object
	 */
	private Map<String, Serializable> updatedPreference(Map<String, Serializable> preferences,String preferenceFilter,String values){
		LOGGER.info("updatedPreference Values ::: "+values);
		LOGGER.info("updatedPreference Preference size :::: "+preferences.size());
		Set<String> userPreferencesFoldersSet = new HashSet<String>();
		 List<String> userPreferencesFoldersList = new ArrayList<String>();
		try{
				if(preferences.containsKey(preferenceFilter)){
				String item=(String)preferences.get(preferenceFilter);
				//LOGGER.info("item----------"+item);
				
				String[] itemArray =item.split(",");
				List<String> list = new ArrayList<String>();
				if(itemArray.length > 0){
					Collections.addAll(list, itemArray);
				}
				if(list.size()>0) {
					userPreferencesFoldersSet.addAll(list);
				}
				if(!userPreferencesFoldersSet.isEmpty()) {
				 for (String folderId : userPreferencesFoldersSet){
						 userPreferencesFoldersList.add(folderId);
			        }
				}
				if(userPreferencesFoldersList.contains(values)){
					userPreferencesFoldersList.remove(values);
				}else{
					userPreferencesFoldersList.add(values);
				}
				//LOGGER.info("userPreferencesFoldersList----------:"+userPreferencesFoldersList);
				preferences.put(preferenceFilter, StringUtils.join(userPreferencesFoldersList, ","));
				} else{
					preferences.put(preferenceFilter, values);
				}
		} catch (Exception e) {
    		LOGGER.error("Exception in updatedPreference mothod---:::: "+e);
    		e.printStackTrace();
		}
		return preferences;
	}
	
	private Map<String, Object> setRemovePreferences(final String usersList, final NodeRef folderNodeRef){
		Map<String, Object> statusMessage = new HashMap<String, Object>();
    	try{
    		statusMessage = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Map<String, Object>>() {
			@Override
			public Map<String, Object> doWork() throws Exception {
				final Map<String, Object> innerModel = new HashMap<String, Object>();
				LOGGER.info("inside getRetryingTransactionHelper :::: "+folderNodeRef);
				Map<String, Serializable> preferences = preferenceService.getPreferences(usersList,	preferenceFilter);
				LOGGER.info("preferences for perticular user :::: "+preferences);
				 Map<String, Serializable> updatedPreferences = updatedPreference(preferences, preferenceFilter, folderNodeRef.toString());
				LOGGER.info("Preferences to update :::: " + updatedPreferences);
				preferenceService.setPreferences(usersList, updatedPreferences);
				innerModel.put("innerStatus", "Root folder updated successfully");
				 innerModel.put("nodeId", folderNodeRef);
				LOGGER.info("finished setting setPreferences in setRemovePreferences method-----");
				return innerModel;
			}
		}, "admin");
    	} catch (Exception e) {
    		LOGGER.error("Exception in setRemovePreferences mothod-----------"+e);
    		e.printStackTrace();
		}
		return statusMessage;
    }
	
	/**
	 * This method creates association for the library folders
	 *  
	 */
	 private void addUserPreferencesProps(String logginUser, NodeRef finalUserFolderNode) {
				LOGGER.info("inside addUserPreferencesProps-------");
				// final String CISCO_MODEL_URI = "http://www.cisco.com/model/content/1.0";
				final NodeRef personNodereff = serviceRegistry.getPersonService().getPerson(logginUser);
				LOGGER.info("Person nodereff   ::" + personNodereff);
				try {
					serviceRegistry.getNodeService().addAspect(finalUserFolderNode,
							CiscoModelConstants.CISCO_DX_FOLDER_ASPECT, null);
					serviceRegistry.getNodeService().addChild(personNodereff, finalUserFolderNode,
							CiscoModelConstants.CISCO_DX_FOLDER_ASSOCIATION,
							QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, finalUserFolderNode.getId()));
				} catch (Exception e) {
					LOGGER.error("Exception in addUserPreferencesProps----" + e);
					e.printStackTrace();
				}
				LOGGER.info("assoc added successfully---");
			}
	
	/**
	 * 
	 * @param req
	 * @return
	 */
	private String readRequestBody(WebScriptRequest req) {
		try {
			return IOUtils.toString(req.getContent().getInputStream(), req
					.getContent().getEncoding());
		} catch (Exception e) {
			try {
				return req.getContent().getContent();
			} catch (IOException e1) {
				LOGGER.error("Unable to read JSON request body", e1);
				throw new WebScriptException(
						"Unable to read JSON request body!! Epic fail.");
			}
		}
	}
  
	  @Override
	    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
	    {
		  	LOGGER.info("--- Started UpdateRootFolder----");
		  	Map<String, Object> model = new HashMap<String, Object>();
		  	String logginUser = AuthenticationUtil.getFullyAuthenticatedUser();
		  	LOGGER.info("logginUser::::::::"+logginUser);
			String inputJSONValue = readRequestBody(req);
			JSONObject jsonObject = null;
			String folderNodId=null;
			if(isUserInternal(logginUser) || isUserGenerics(logginUser)){
			try {
				jsonObject = new JSONObject(inputJSONValue);
				folderNodId = jsonObject.getString("nodeId");
				NodeRef rootFolderNodeRefId = new NodeRef(folderNodId);
 				if(serviceRegistry.getNodeService().exists(rootFolderNodeRefId)) {
				Map<String, Object> finalStatusMessage = setRemovePreferences(logginUser,rootFolderNodeRefId);
				//Fix for library performance issue adding custom aspect 
				addUserPreferencesProps(logginUser,rootFolderNodeRefId);
				LOGGER.info("finalStatusMessage---------"+finalStatusMessage);
				model.put("message", finalStatusMessage);
				LOGGER.info("--- Finished in Update RootFolder----");
 				}else {
 					model.put("message", "Folder does not exists to update user preferences");
 				}
				}// End of try
			 catch (Exception e) {
					e.printStackTrace();
					LOGGER.error("in e---------"+e);
				}
			} // End of checking internal user
			  else
	            {
	                model.put("message", "You are not authorized to perform this operation.");
	            }
			return model;
	    }
	  
	  public boolean isUserInternal(String userid)
	    {
	        LOGGER.info((new StringBuilder("Start checking if internal LDAP users.. ")).append(userid).toString());
	        return ldapUtil.isLdapUserInternal((new StringBuilder(String.valueOf(userid))).toString());
	    }
	  public boolean isUserGenerics(String userid)
	  {
		  LOGGER.info((new StringBuilder("Start checking if Generics LDAP users.. ")).append(userid).toString());
	      return ldapUtil.isLdapUserGeneric((new StringBuilder(String.valueOf(userid))).toString());
	  }
}
