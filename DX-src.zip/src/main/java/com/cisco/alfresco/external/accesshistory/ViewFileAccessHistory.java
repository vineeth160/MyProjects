/**
 * Class is used to get all Audit info based on path ( path will get from Given NodeRef)
 * 
 * @author mkatnam
 *
 */
package com.cisco.alfresco.external.accesshistory;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.cmr.audit.AuditQueryParameters;
import org.alfresco.service.cmr.audit.AuditService;
import org.alfresco.service.cmr.audit.AuditService.AuditQueryCallback;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter;
import org.alfresco.service.cmr.repository.datatype.TypeConversionException;
import org.alfresco.service.cmr.security.PersonService;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.external.accesshistory.utils.AccessHistoryUtil;


public class ViewFileAccessHistory  extends DeclarativeWebScript{
	
	private static final Logger _logger  = Logger.getLogger(ViewFileAccessHistory.class);

	private AuditService auditService;
	private NodeService nodeService;
	private PersonService personService;
	
	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}

	public void setAuditService(AuditService auditService) {
		this.auditService = auditService;
	}


	/* (non-Javadoc)
	 * @see org.springframework.extensions.webscripts.DeclarativeWebScript#executeImpl(org.springframework.extensions.webscripts.WebScriptRequest, org.springframework.extensions.webscripts.Status, org.springframework.extensions.webscripts.Cache)
	 */
	@Override
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
	{
		_logger.info(" Execution started in viewFileAccessHistory method");
		
		final List<Map<String, Object>> entries 	=  new ArrayList<Map<String, Object>>();
		Map<String, Object> model 					= new HashMap<String, Object>();
		
		String fileNode 		= req.getParameter("nodeId");
		NodeRef nodeRef 		= new NodeRef(fileNode);
		String node = nodeRef.getId();
		
		final String edcsId = (String) nodeService.getProperty(nodeRef, CiscoModelConstants.PROP_ALF_ID);
		
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception{
				// method call to get download audit info
				getAuditInfoQuery(AccessHistoryUtil.AUDIT_DOWNLOAD_APP_NAME,AccessHistoryUtil.AUDIT_DOWNLOAD_DOC_EDCSID, edcsId, entries);
				// method call to get preview-report app audit info
				getAuditInfoQuery(AccessHistoryUtil.AUDIT_PREVIEW_APP_NAME,AccessHistoryUtil.AUDIT_PREVIEW_DOC_EDCSID,edcsId, entries);
				
				_logger.info("entries Size:" + entries.size());

				return null;
			}

		}, "admin");
		
		// prepare All audit data into model object
		try 
		{
			Map<Long, List<String>> finalMap = AccessHistoryUtil.getAuditData(entries, nodeService, personService,node);
			model.put("auditData",finalMap);
		}
		catch (Exception e) {
			_logger.error(" exception occured while getting file access history ");
			e.printStackTrace();
			
		}
		
		return model;
	}
	
	
	/** get Audit info for given edcsid
	 * @param appName
	 * @param searchkey
	 * @param edcsId
	 * @param entries 
	 */
	private void getAuditInfoQuery(final String appName, String searchkey, final String edcsId, final List<Map<String, Object>> entries) {

		int limit					 	= 0;
        final boolean verbose			= false;
        
        
        // Execute the query
        AuditQueryParameters params 	= new AuditQueryParameters();
        params.setApplicationName(appName);
        params.addSearchKey(searchkey, edcsId);

        AuditQueryCallback callback = new AuditQueryCallback()
        {
            @Override
            public boolean valuesRequired()
            {
                return verbose;
            }

            @Override
            public boolean handleAuditEntryError(Long entryId, String errorMsg, Throwable error)
            {
                return true;
            }

            @Override
            public boolean handleAuditEntry(Long entryId, String applicationName, String user, long time,
                    Map<String, Serializable> values)
            {
                Map<String, Object> entry = new HashMap<String, Object>(11);
                entry.put(AccessHistoryUtil.JSON_KEY_ENTRY_ID, entryId);
                entry.put(AccessHistoryUtil.JSON_KEY_ENTRY_APPLICATION, applicationName);
                if (user != null)
                {
                    entry.put(AccessHistoryUtil.JSON_KEY_ENTRY_USER, user);
                }
                entry.put(AccessHistoryUtil.JSON_KEY_ENTRY_TIME, new Date(time));

                if (values != null)
                {
                    // Convert values to Strings
                    Map<String, String> valueStrings = new HashMap<String, String>(values.size() * 2);
                    for (Map.Entry<String, Serializable> mapEntry : values.entrySet())
                    {
                        String key = mapEntry.getKey();
                        Serializable value = mapEntry.getValue();
                        try
                        {
                            String valueString = DefaultTypeConverter.INSTANCE.convert(String.class, value);
                            valueStrings.put(key, valueString);
                        }
                        catch (TypeConversionException e)
                        {
                            // Use the toString()
                            valueStrings.put(key, value.toString());
                        }
                    }
                    entry.put(AccessHistoryUtil.JSON_KEY_ENTRY_VALUES, valueStrings);
                }
                entries.add(entry);

                return true;
            }
        };

        // Make an audit call to applicationName
        auditService.auditQuery(callback, params, limit);
		
	}
	

}
