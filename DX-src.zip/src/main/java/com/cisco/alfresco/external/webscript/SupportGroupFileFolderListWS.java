/**
 * 
 */
package com.cisco.alfresco.external.webscript;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.Format;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.docex.service.DocexFileFolderService;
import com.cisco.docex.transferobjects.outbound.SupportGroupFileFolderOutbound;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

/**
 * @author parreddy
 *
 */
public class SupportGroupFileFolderListWS extends AbstractWebScript {

	private static final Logger LOGGER = Logger.getLogger(SupportGroupFileFolderListWS.class);

	DocexFileFolderService docExFileFolderService;
	private ServiceRegistry serviceRegistry;
	private Properties globalProperties;

	@Override
	public void execute(WebScriptRequest webReq, WebScriptResponse webRes) throws IOException {
		String authenticatedUserName = AuthenticationUtil.getFullyAuthenticatedUser();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("pageNo", webReq.getParameter("pageNo"));
		paramMap.put("sortBy", webReq.getParameter("sortBy"));
		paramMap.put("sortOrder", webReq.getParameter("sortOrder"));
		paramMap.put("geoHostName", webReq.getParameter("geoHostName"));
		paramMap.put("pageSize", webReq.getParameter("pageSize"));
		paramMap.put("id", webReq.getParameter("nodeRef"));
		
		if(!isSupportGroupUser(authenticatedUserName)) {
			webRes.setStatus(401);
			//throw new AuthenticationException("you do not have permissions to access the resources.");
			throw new WebScriptException(Status.STATUS_UNAUTHORIZED, "you do not have permissions to access the resources.");
		}
		SupportGroupFileFolderOutbound response = docExFileFolderService
				.getSupportGroupFileFolders(authenticatedUserName, paramMap);
		webRes.setContentType(Format.JSON.mimetype());
		webRes.getWriter().write(getJsonString(response));

	}

	public void setDocExFileFolderService(DocexFileFolderService docExFileFolderService) {
		this.docExFileFolderService = docExFileFolderService;
	}

	public boolean isSupportGroupUser(String currentUserName) {
		boolean isUserExistinGroup = false;
		Set<String> userAuthorities = serviceRegistry.getAuthorityService().getAuthorities();
		String supportGroupName = globalProperties.getProperty("docex.supportgroup.name");
		if(supportGroupName != null && userAuthorities.contains(supportGroupName)) {
			isUserExistinGroup = true;
		}
		return isUserExistinGroup;
	}
	
	public static String getJsonString(SupportGroupFileFolderOutbound response) {
		String json = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			Map<String, Object> result = new HashMap<String, Object>(1);
			result.put("result", response);
			json = mapper.writeValueAsString(result);
		} catch (JsonGenerationException e) {
			LOGGER.error(" ERROR While Converting Response object to json: ", e);
		} catch (JsonMappingException e) {
			LOGGER.error(" ERROR While Converting Response object to json:", e);
		} catch (IOException e) {
			LOGGER.error(" ERROR While Converting Response object to json:", e);
		} catch (Exception e) {
			LOGGER.error(" ERROR While Converting Response object to json:", e);
		}
		return json;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public void setGlobalProperties(Properties globalProperties) {
		this.globalProperties = globalProperties;
	}

}
