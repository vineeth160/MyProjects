package com.cisco.alfresco.external.webscript;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.version.Version2Model;
import org.alfresco.repo.web.scripts.download.DownloadPost;

import java.io.IOException;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.transaction.UserTransaction;

import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.content.MimetypeMap;
import org.alfresco.repo.jscript.ScriptNode;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileFolderService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.ISO9075;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
//import com.cisco.edcsng.audit.download.DownloadContentGet;
/**
 * Web script for creating a new download.
 *
 * @author Saranyan VL
 */

public class CiscoDownloadPost extends DownloadPost
{
	
	private static final Logger LOGGER = Logger.getLogger(CiscoDownloadPost.class);
	private static final String GROUP_IDENTITY ="GROUP_";
	private static final String GROUP_EVERYONE="GROUP_EVERYONE";
	private ServiceRegistry registry;
	public ServiceRegistry getRegistry() {
		return registry;
	}
	private NodeService nodeService;
	private PermissionService permissionService;
	private FileFolderService fileFolderService;
	private SearchService searchService;
	private NamespaceService namespaceService;
	private BehaviourFilter behaviourFilter;
	private AuditComponent auditComponent;
	
	public NamespaceService getNamespaceService() {
		return namespaceService;
	}
	public void setNamespaceService(NamespaceService namespaceService) {
		this.namespaceService = namespaceService;
	}
	public SearchService getSearchService() {
		return searchService;
	}
	public void setSearchService(SearchService searchService) {
		this.searchService = searchService;
	}
	public void setAuditComponent(AuditComponent auditComponent)
	    {
	        this.auditComponent = auditComponent;
	    }
	public BehaviourFilter getBehaviourFilter() {
		return behaviourFilter;
	}

	public void setBehaviourFilter(BehaviourFilter behaviourFilter) {
		this.behaviourFilter = behaviourFilter;
	}

	public FileFolderService getFileFolderService() {
		return fileFolderService;
	}

	public void setFileFolderService(FileFolderService fileFolderService) {
		this.fileFolderService = fileFolderService;
	}

	public PermissionService getPermissionService() {
		return permissionService;
	}

	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}

	public NodeService getNodeService() {
		return nodeService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public void setRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

	/*public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}*/

    @Override
    protected Map<String,Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {
        Map<String, String> templateVars = req.getServiceMatch().getTemplateVars();
        if (templateVars == null)
        {
            String error = "No parameters supplied";
            throw new WebScriptException(Status.STATUS_BAD_REQUEST, error);
        }
        
        
        // Parse the JSON, if supplied
        JSONArray json = null;
        String contentType = req.getContentType();
        if (contentType != null && contentType.indexOf(';') != -1)
        {
           contentType = contentType.substring(0, contentType.indexOf(';'));
        }
        
      
        List<NodeRef> nodes = new LinkedList<NodeRef>();
        if (MimetypeMap.MIMETYPE_JSON.equals(contentType))
        {
           JSONParser parser = new JSONParser();
           try
           {
        	   
        	   JSONObject obj2 = (JSONObject)parser.parse(req.getContent().getContent());
        	   JSONArray nodeRefJsonArrays = (JSONArray)obj2.get("nodeRefs");
        	  String noderefStrings= nodeRefJsonArrays.toString();
        	  
        	  String[] nodeRefArrays= noderefStrings.split(",");
        	   for (int i = 0 ; i < nodeRefArrays.length ; i++)
               {
        		  String nodeRefString= nodeRefArrays[i].replace("[", "").replace("]", "").replace("\"", "").replace("\\", "");
        		  
        		    
        		//   DownloadContentGet downloadcontent = new DownloadContentGet();
        		  LOGGER.info("nodeRefString-->>" +nodeRefString);
        			String currentUserName = registry.getAuthenticationService().getCurrentUserName();
        			LOGGER.info("username--->>"+currentUserName);
        			Date currentTime = new Date();
        			LOGGER.info("Date-->>" +currentTime);
        			getDownloadAuditInfo(nodeRefString, currentUserName, currentTime);
        			nodes.add(new NodeRef(nodeRefString)); 
            	 
               }






           }
           catch (IOException io)
           {
               throw new WebScriptException(Status.STATUS_INTERNAL_SERVER_ERROR, "Unexpected IOException", io);
           }
           catch (org.json.simple.parser.ParseException je)
           {
               throw new WebScriptException(Status.STATUS_BAD_REQUEST, "Unexpected ParseException", je);
           }
        }
        
        if (nodes.size() <= 0) 
        {
            throw new WebScriptException(Status.STATUS_BAD_REQUEST, "No nodeRefs provided");
        }
        
        NodeRef downloadNode = downloadService.createDownload(nodes.toArray(new NodeRef[nodes.size()]), true);
		ScriptNode scriptNode= new ScriptNode(downloadNode,registry);
		scriptNode.setInheritsPermissions(false);
		scriptNode.setPermission("FullControl", "ROLE_OWNER");
		 
        Map<String, Object> model = new HashMap<String, Object>();
        model.put("downloadNodeRef", downloadNode);

        return model;
    }
    
    
    public boolean hasAccess(final String currentUser, NodeRef nodeRef)
    {
    	boolean currentUserHasGroupMember = false;
    	if (currentUser.equals("admin"))
        {
            return true;
        }
        Set<AccessPermission> userSet = registry.getPermissionService().getAllSetPermissions(nodeRef);
        if (userSet.size() > 0)
        {
			for (AccessPermission accessPermission : userSet) {
            	final String userIdOrMemberOfGroupId = accessPermission.getAuthority();
            	LOGGER.info("user : " + userIdOrMemberOfGroupId);
                //check user is member of group that group has permissions on folder
                if(userIdOrMemberOfGroupId.contains(GROUP_IDENTITY)){
                	if (accessPermission.getPermission() != null
    						&& accessPermission.getPermission().equals("SiteAdmin")
    						|| accessPermission.getPermission().equals("SiteEditor")
    						|| accessPermission.getPermission().equals("SiteReader")
    						|| accessPermission.getPermission().equals("SiteOwner")
    						|| accessPermission.getPermission().equals("SiteManager")
    						|| accessPermission.getPermission().equals("ReadPermissions")
    						|| accessPermission.getPermission().equals("SiteViewer")) {
                		LOGGER.info("inside if authority permissions------" +accessPermission.getPermission());
    				} else{
    					LOGGER.info("groupId : " + userIdOrMemberOfGroupId);
                	currentUserHasGroupMember = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
       				  @Override
       				  public Boolean doWork() throws Exception {
       					boolean currentUserIsGroupMember=false;
   					  if(userIdOrMemberOfGroupId!= null && !userIdOrMemberOfGroupId.equalsIgnoreCase(GROUP_EVERYONE)){
   					currentUserIsGroupMember=registry.getAuthorityService().getAuthoritiesForUser(currentUser).contains(userIdOrMemberOfGroupId);
   					  }
   					 return currentUserIsGroupMember;
     				  }
       				}, "admin");
                	LOGGER.info("currentUserHasGroupMember of accessPermission.getAuthorityType : " + currentUserHasGroupMember);
                }
                }
                if (userIdOrMemberOfGroupId.equals(currentUser) || currentUserHasGroupMember)
                {
                    return true;
                }
            }
        }
        return false;
    }

    public void getDownloadAuditInfo(String nodeRefStr, String downloadedBy, Date currentTime)
    {
        LOGGER.info("-------- Download Document Auditing STARTS ------------");

        Map<String, Serializable> auditEntry = new HashMap<String, Serializable>();
        List<NodeRef> finalList = new ArrayList<NodeRef>();
        boolean folderBool = false;
        
        try {
        // NodeRef nodeRef = new NodeRef("workspace://SpacesStore/" + nodeRefStr);
        NodeRef nodeRef = new NodeRef(nodeRefStr); // Phani


        String nodePath = nodeService.getPath(nodeRef).toDisplayPath(nodeService, permissionService);
        String prefixedPath = ISO9075.decode(nodeService.getPath(nodeRef).toPrefixString(registry.getNamespaceService()));
        /**
         * For Verison Nodes, we have to fetch the FrozenNode (Live Node) and get the display path. - STARTS - Deepak -
         * On July 23, 2014
         */
        if (Version2Model.STORE_ID.equals(nodeRef.getStoreRef().getIdentifier())) // "version2Store"
        {   
            nodeRef = new NodeRef(StoreRef.PROTOCOL_WORKSPACE, Version2Model.STORE_ID, nodeRef.getId());
            NodeRef  frozenNodeRef= (NodeRef) nodeService.getProperty(nodeRef, Version2Model.PROP_QNAME_FROZEN_NODE_REF);
            System.out.println("frozenNodeRef : " + frozenNodeRef);
            nodePath = nodeService.getPath(frozenNodeRef).toDisplayPath(nodeService, permissionService);
            prefixedPath = ISO9075.decode(nodeService.getPath(frozenNodeRef).toPrefixString(registry.getNamespaceService()));
            System.out.println("nodePath : " + nodePath);
        }
        
        /**
         * For Verison Nodes, we have to fetch the FrozenNode (Live Node) and get the display path. - STARTS - Deepak -
         * On July 23, 2014
         */
        boolean file = registry.getDictionaryService().isSubClass(registry.getNodeService().getType(nodeRef), ContentModel.TYPE_CONTENT);
        if(file)
        {
        	finalList.add(nodeRef);
        } else {
        	folderBool = true;
        }
        final List<NodeRef> finalList1 = new ArrayList<NodeRef>();
        final String currentUserName = registry.getAuthenticationService().getCurrentUserName();
        if (folderBool) {
        	final NodeRef node = nodeRef;
        	
        	AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				@Override
				public Object doWork() throws Exception {
					
        	//List<NodeRef> list = new ArrayList<NodeRef>();
        		StringBuffer subFoldersQry 	= new StringBuffer("PATH:\"");
        		subFoldersQry.append(nodeService.getPath(node).toPrefixString(namespaceService)).append("//*\" ");
        		LOGGER.info(" Sub Folders Query ::"+subFoldersQry.toString());
        		ResultSet subFileFolderList = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_LUCENE, subFoldersQry.toString());
        		if(subFileFolderList != null){
        			LOGGER.info("subFileFolderList size ::: if not null " );
        			 
            		for(ResultSetRow row: subFileFolderList ){
            			LOGGER.info("row.getNodeRef()  ::: " +row.getNodeRef());
            			if(hasAccess(currentUserName,row.getNodeRef())){
            			
            			finalList1.add(row.getNodeRef());
            			}
            		}
        	
            		LOGGER.info(" final List size :"+finalList1.size());
            		subFileFolderList.close();
            	}
				return null;
        		
				}
            },"admin");
        }
        
        if(finalList1 != null && finalList1.size() >0){
        	LOGGER.info("Adding all--------->>>>");
        	finalList.addAll(finalList1);
        }
        
        if (finalList != null && finalList.size() >0) {
        	for(NodeRef node:finalList) {
        		Map<QName, Serializable> nodeProp = nodeService.getProperties(node);
        		String edcsId = (String) nodeProp.get(ExternalSharingConstants.PROP_EDCS_ID);
        		if (edcsId != null) {
	        		auditEntry.put("noderef", nodeRefStr);
	                auditEntry.put("docname", (String) nodeProp.get(ContentModel.PROP_NAME));
	                auditEntry.put("creator", (String) nodeProp.get(ContentModel.PROP_CREATOR));
	                auditEntry.put("modifier", (String) nodeProp.get(ContentModel.PROP_MODIFIER));
	                auditEntry.put("path", nodePath);
	                auditEntry.put("prefixedPath", prefixedPath);
	                auditEntry.put("description", (String) nodeProp.get(ContentModel.PROP_DESCRIPTION));
	                auditEntry.put("security", (String) nodeProp.get(CiscoModelConstants.CISCO_SECURITY_PROP));
	
	               // QName edcsIdQName = QName.createQName(CiscoModelConstants.CISCO_MODEL_URI, "alf_id");
	                auditEntry.put("edcsid", edcsId);
	                
	                //added by mkatnam for download Audit Report and setting download count property
	                int downloadCount = 1;
	                //DE2024
	               
	                auditEntry.put("contentsize",formatFileSize(fileFolderService.getReader(node).getContentData().getSize()));
	                 
	                if(nodeProp.get(CiscoModelConstants.PROP_CISCO_DOWNLOAD_COUNT) != null){
	        	        downloadCount = (Integer) nodeProp.get(CiscoModelConstants.PROP_CISCO_DOWNLOAD_COUNT);
	                }
	                auditEntry.put("downloadcount", String.valueOf(downloadCount));
	
	                //end mkatnam
	                auditComponent.recordAuditValues("/download-report/document", auditEntry);
	
	                LOGGER.info(" AuditEntry :" + auditEntry);
        		}
        	}
        }
    } catch(Exception e) {
    	e.printStackTrace();
    }
        
        LOGGER.info("---------- Download Document Auditing ENDS -----------");

    }
    public static String formatFileSize(long size) {
	    String hrSize = null;

	    double b = size;
	    double k = size/1024.0;
	    double m = ((size/1024.0)/1024.0);
	    double g = (((size/1024.0)/1024.0)/1024.0);
	    double t = ((((size/1024.0)/1024.0)/1024.0)/1024.0);

	    DecimalFormat dec = new DecimalFormat("0.00");

	    if ( t>1 ) {
	        hrSize = dec.format(t).concat(" TB");
	    } else if ( g>1 ) {
	        hrSize = dec.format(g).concat(" GB");
	    } else if ( m>1 ) {
	        hrSize = dec.format(m).concat(" MB");
	    } else if ( k>1 ) {
	        hrSize = dec.format(k).concat(" KB");
	    } else {
	        hrSize = dec.format(b).concat(" Bytes");
	    }
	    return hrSize;
	}
    
}