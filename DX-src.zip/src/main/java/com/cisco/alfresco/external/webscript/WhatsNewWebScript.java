package com.cisco.alfresco.external.webscript;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import org.alfresco.error.AlfrescoRuntimeException;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.content.MimetypeMap;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.AssociationRef;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.ContentData;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.LimitBy;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.namespace.InvalidQNameException;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.namespace.RegexQNamePattern;
import org.alfresco.util.ISO9075;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.external.common.model.ExtDocument;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.alfresco.external.domain.CheckDomain;
import com.cisco.alfresco.external.utils.CharUtil;
import com.cisco.alfresco.external.viewfav.Viewfav;


/**
 * This webscript is used to retrieve the list of files for logged in user within the given period of date
 * 
 * @author rajbaska
 * 
 */

public class WhatsNewWebScript extends DeclarativeWebScript
{
    private static final Logger LOGGER = Logger.getLogger(WhatsNewWebScript.class);
    private ServiceRegistry serviceRegistry;
    private String alfrescoURL;
    private String contextName;
    private String luceneQueryString;
    private int pageSize;
    final static String CISCO_MODEL_URI = "http://www.cisco.com/model/content/1.0";

    public void setLuceneQueryString(String luceneQueryString)
    {
        this.luceneQueryString = luceneQueryString;
    }

    public int getPageSize()
    {
        return pageSize;
    }

    public void setPageSize(int pageSize)
    {
        this.pageSize = pageSize;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    public void setAlfrescoURL(String alfrescoURL)
    {
        this.alfrescoURL = alfrescoURL;
    }

    public void setContextName(String contextName)
    {
        this.contextName = contextName;
    }

    private static final int DAYSTOSUBTRACT = 30;
    private static final String DATE_FORMAT = "yyyy-MM-dd";

    @Override
    public Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
    {
        LOGGER.info("Calling WhatsNewWebScript...");
        final Map<String, Object> model = new HashMap<String, Object>();

        try
        {
            // default filter value is set to 30 days
            int days = 30;
            String filter = req.getParameter("filter");
            LOGGER.info("filter:" + filter);
            if (filter != null)
            {
                days = Integer.parseInt(filter);
                LOGGER.info("No of Days:" + days);
            }
            String currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("current user : " + currentUser);
            }
            String currentDate = ExternalSharingFileFolderUtil.getFromCurrentDate();
            String toDate = "";
            String SearchLuceneQuery = "";

            if (days > 0 && days != 30)
            {
                toDate = getToDate(days);
                LOGGER.info("toDate in filter1:" + toDate);
            }
            else
            {
                toDate = getToDate(DAYSTOSUBTRACT);
                LOGGER.info("toDate in filter2:" + toDate);
            }
            LOGGER.info("CurrentDate:" + currentDate);
            LOGGER.info("ToDate:" + toDate);
            SearchLuceneQuery = luceneQueryString;
            SearchLuceneQuery = SearchLuceneQuery.replace("toDate", toDate);
            SearchLuceneQuery = SearchLuceneQuery.replace("currentDate", currentDate);
            SearchLuceneQuery = SearchLuceneQuery.replace("currentUser", currentUser);
            LOGGER.info("SearchLuceneQuery:---------" + SearchLuceneQuery);
            QName PROP_CONTENT_SIZE = QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, "content.size");
            QName PROP_CONTENT_MIMETYPE = QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, "content.mimetype");
            String pageNo = getParameter(req, "pageNo");
            String sortBy = getParameter(req, "sortBy");
            String sortOrder = getParameter(req, "sortOrder");
            String hostname = req.getParameter("geoHostName");
            int pageNum;
            if(!hostname.isEmpty()&& hostname != null){
				hostname = Viewfav.hostValidation(hostname);
				LOGGER.info("hostname ::: "+hostname);
			}
            if (pageNo == null || pageNo == "" || pageNo.isEmpty())
            {
                pageNum = 1;
            }
            else
            {
                pageNum = Integer.parseInt(req.getParameter("pageNo"));
            }
            LOGGER.info("pageNum----------" + pageNum);

            QName field = null;
            if (sortBy == null || sortBy == "" || sortBy.equalsIgnoreCase("modified"))
            {
                field = ContentModel.PROP_MODIFIED; // default
            }
            else if (sortBy.equalsIgnoreCase("name"))
            {
                field = ContentModel.PROP_NAME;
            }
            else if (sortBy.equalsIgnoreCase("edcsId"))
            {
                field = ExternalSharingConstants.PROP_EDCS_ID;
            }
            else if (sortBy.equalsIgnoreCase("expirationDate"))
            {
                field = ExternalSharingConstants.PROP_EXPIRAIONDATE;
            }
            else if (sortBy.equalsIgnoreCase("size"))
            {
                field = PROP_CONTENT_SIZE;
            }
            else if (sortBy.equalsIgnoreCase("type"))
            {
                field = PROP_CONTENT_MIMETYPE;
            }
            LOGGER.info("field----------" + field);

            boolean sortingOrder = true; // default ascending order
            if (sortOrder != null && sortOrder.equalsIgnoreCase("desc"))
            {
                sortingOrder = false; // false = descending
            }
            LOGGER.info("sortingOrder----------" + sortingOrder);

            if (getParameter(req, "pageSize") != null && !getParameter(req, "pageSize").isEmpty())
            {
                pageSize = Integer.parseInt(getParameter(req, "pageSize"));
            }
            LOGGER.info("pageSize----------" + pageSize);

            Map<String, Object> searchListMap = getFileList(pageNum, field, sortingOrder, pageSize, SearchLuceneQuery,
                sortOrder, sortBy, hostname);

            List<ExtDocument> result = (List<ExtDocument>) searchListMap.get("result");
            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("CurrentDate:" + currentDate);
                LOGGER.debug("ToDate:" + toDate);
                LOGGER.debug("searchresult size:" + result.size());
            }

            model.put("result", result);
            model.put("totalItems", (long) searchListMap.get("totalItems"));
            LOGGER.error("finished WhatsNewWebScript SearchLuceneQuery :::: "+(long) searchListMap.get("totalItems"));
        }
        catch (AlfrescoRuntimeException e)
        {
            LOGGER.error("Exception occured:" + e);
        }
        catch (Exception e)
        {
            LOGGER.error("Exception : " + e);
        }
        return model;
    }

    private String getParameter(WebScriptRequest req, String paramName)
    {
        String value = "";
        if (req.getParameter(paramName) != null)
        {
            value = req.getParameter(paramName).trim();
        }
        return value;
    }

    private Map<String, Object> getFileList(final int pageNum, QName field, boolean sortingOrder, final int pageSize,
            String SearchLuceneQuery, final String sortOrder, final String sortBy, final String hostname)
    {
        Map<String, Object> fileListMap = new HashMap<>();
        final List<ExtDocument> listExtDocs = new ArrayList<ExtDocument>();
        final List<NodeRef> nodeRefList;
        final String logginUser = AuthenticationUtil.getFullyAuthenticatedUser();
        try
        {
            final String currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
            nodeRefList = getNodeRefListFromLuceneQuery(SearchLuceneQuery, serviceRegistry, pageNum, field,
                sortingOrder, pageSize, fileListMap);
            QName ASSOC_NAME_MYFAVORITE_ASSOCIATE = QName.createQName(CISCO_MODEL_URI, "myFavorite");
            NodeRef personNodereff = serviceRegistry.getPersonService().getPerson(logginUser);
            final List<NodeRef> customFablist = new ArrayList<NodeRef>();
            List<ChildAssociationRef> childAssocList = serviceRegistry.getNodeService().getChildAssocs(personNodereff,
                ASSOC_NAME_MYFAVORITE_ASSOCIATE, RegexQNamePattern.MATCH_ALL);
            if (childAssocList.size() > 0)
            {
                for (ChildAssociationRef child : childAssocList)
                {
                    NodeRef childNodeRef = child.getChildRef();
                    customFablist.add(childNodeRef);
                }
            }
            if (nodeRefList != null && nodeRefList.size() > 0)
            {
                AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
                {
                    @Override
                    public Object doWork() throws Exception
                    {
                        ExtDocument extDocs = null;
                        Map<QName, Serializable> nodeProp = null;
                        String name = null;
                        String edcsId = null;
                        String title = null;
                        String description = null;
                        String en_name = null;
                        String downloadUrl = null;
                        String strVersion = null;
                        double version = 0;
                        long size = 0;
                        String lockType = null;
                        String UserRole = null;
                        LOGGER.info("sortBy in getFileList----" + sortBy);
                        LOGGER.info("sortOrder in getFileList-----" + sortOrder);
                        // PRBADAM START: setting nodes props based on input from UI
                        final List<ExtDocument> listExtDocsFilterList = new ArrayList<ExtDocument>();
                        for (int i = 0; i < nodeRefList.size(); i++)
                        {
                            ExtDocument extDocsObj = new ExtDocument();
                            extDocsObj.setNodeId(nodeRefList.get(i).toString());
                            if (sortBy.equalsIgnoreCase("modified"))
                            {
                                Date modSort = (Date) serviceRegistry.getNodeService().getProperty(nodeRefList.get(i),
                                    ContentModel.PROP_MODIFIED);
                                extDocsObj.setModifieddate(ExternalSharingFileFolderUtil
                                        .getGMTDateFormat(((Date) modSort)));
                            }
                            else if (sortBy.equalsIgnoreCase("name"))
                            {
                                String nameSort = (String) serviceRegistry.getNodeService().getProperty(
                                    nodeRefList.get(i), ContentModel.PROP_NAME);
                                extDocsObj.setName(ISO9075.decode(CharUtil.replaceEscape(nameSort)));
                            }
                            else if (sortBy.equalsIgnoreCase("expirationDate"))
                            {
                                Date expSort = (Date) serviceRegistry.getNodeService().getProperty(nodeRefList.get(i),
                                    ExternalSharingConstants.PROP_EXPIRAIONDATE);
                                extDocsObj.setExpirationDate(ExternalSharingFileFolderUtil
                                        .getGMTDateFormat(((Date) expSort)));
                            }
                            else if (sortBy.equalsIgnoreCase("size"))
                            {
                                long sizeSort = ((ContentData) serviceRegistry.getNodeService().getProperty(
                                    nodeRefList.get(i), ContentModel.PROP_CONTENT)).getSize();
                                extDocsObj.setSize((int) (sizeSort));
                            }
                            else if (sortBy.equalsIgnoreCase("type"))
                            {
                                String nameProp = (String) serviceRegistry.getNodeService().getProperty(
                                    nodeRefList.get(i), ContentModel.PROP_NAME);
                                nameProp = CharUtil.replaceEscape(nameProp);
                                extDocsObj.setType(nameProp.substring(nameProp.lastIndexOf(".") + 1, nameProp.length()));
                            }
                            else if (sortBy.equalsIgnoreCase("edcsId"))
                            {
                                extDocsObj.setEdcsId((String) serviceRegistry.getNodeService().getProperty(
                                    nodeRefList.get(i), ExternalSharingConstants.PROP_EDCS_ID));
                            }

                            listExtDocsFilterList.add(extDocsObj);
                        }
                        // End of setting nodes props based on input from UI
                        // Sorting started based on filter using comparator
                        if (sortOrder == null || sortOrder == "" || sortOrder.equalsIgnoreCase("asc"))
                        {
                            if (sortBy == null || sortBy == "" || sortBy.equalsIgnoreCase("modified"))
                                Collections.sort(listExtDocsFilterList, Viewfav.moddateComparator);
                            else if (sortBy.equalsIgnoreCase("name"))
                                Collections.sort(listExtDocsFilterList, Viewfav.nameComparator);
                            else if (sortBy.equalsIgnoreCase("expirationDate"))
                                Collections.sort(listExtDocsFilterList, Viewfav.expdateComparator);
                            else if (sortBy.equalsIgnoreCase("size"))
                                Collections.sort(listExtDocsFilterList, Viewfav.sizeComparator);
                            else if (sortBy.equalsIgnoreCase("type"))
                                Collections.sort(listExtDocsFilterList, Viewfav.typeComparator);
                            else if (sortBy.equalsIgnoreCase("edcsId"))
                                Collections.sort(listExtDocsFilterList, Viewfav.edcsIdComparator);
                        }
                        else if (sortOrder != null && sortOrder.equalsIgnoreCase("desc"))
                        {
                            if (sortBy == null || sortBy == "" || sortBy.equalsIgnoreCase("modified"))
                                Collections.sort(listExtDocsFilterList, Viewfav.moddateDescComparator);
                            else if (sortBy.equalsIgnoreCase("name"))
                                Collections.sort(listExtDocsFilterList, Viewfav.nameDescComparator);
                            else if (sortBy.equalsIgnoreCase("expirationDate"))
                                Collections.sort(listExtDocsFilterList, Viewfav.expdateDescComparator);
                            else if (sortBy.equalsIgnoreCase("size"))
                                Collections.sort(listExtDocsFilterList, Viewfav.sizeDescComparator);
                            else if (sortBy.equalsIgnoreCase("type"))
                                Collections.sort(listExtDocsFilterList, Viewfav.typeDescComparator);
                            else if (sortBy.equalsIgnoreCase("edcsId"))
                                Collections.sort(listExtDocsFilterList, Viewfav.edcsIdDescComparator);
                        }

                        List<ExtDocument> sortedFinalSearchList = listExtDocsFilterList;
                        LOGGER.info("Sorted list size is : " + listExtDocsFilterList.size() + " PageSize is : "
                                + pageSize);
                        HashSet<String> finalNodeRefSet = new HashSet<String>();
                        for (ExtDocument extdoc : sortedFinalSearchList)
                        {
                            NodeRef nodeRef = new NodeRef(extdoc.getNodeId());
                            // logger.info("nodeRef Id : " + nodeRef);
                            // prbadam : DE2093
                            if (serviceRegistry.getNodeService().hasAspect(nodeRef, ContentModel.ASPECT_CHECKED_OUT))
                            {
                                // fetching pear-pear association
                                List<AssociationRef> childAssocList = serviceRegistry.getNodeService().getTargetAssocs(
                                    nodeRef, ContentModel.ASSOC_WORKING_COPY_LINK);
                                if (childAssocList != null && !childAssocList.isEmpty())
                                {
                                    if (childAssocList.size() > 0)
                                    {
                                        nodeRef = childAssocList.get(0).getTargetRef();
                                    }
                                }
                            } // end of if checking checked out aspect

                            if (!(finalNodeRefSet.contains(nodeRef.toString())))
                            {
                                finalNodeRefSet.add(nodeRef.toString());
                                extDocs = new ExtDocument();
                                nodeProp = serviceRegistry.getNodeService().getProperties(nodeRef);
                                name = (String) nodeProp.get(ContentModel.PROP_NAME);
                                name = CharUtil.replaceEscape(name);
                                extDocs.setName(ISO9075.decode(name));
                                edcsId = (String) nodeProp.get(ExternalSharingConstants.PROP_EDCS_ID);
                                // logger.info("NodeRef After decode:" + ISO9075.decode(nodeRef.toString()));
                                extDocs.setNodeId(ISO9075.decode(nodeRef.toString()));
                                title = (String) nodeProp.get(ContentModel.PROP_TITLE);
                                title = CharUtil.replaceEscape(title);
                                description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
                                description = CharUtil.replaceEscape(description);
                                extDocs.setTitle(ISO9075.decode(title));
                                extDocs.setDescription(ISO9075.decode(description));
                                extDocs.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
                                extDocs.setCreationdate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
                                        .get(ContentModel.PROP_CREATED))));
                                ContentData content = (ContentData) serviceRegistry.getNodeService().getProperty(
                                    nodeRef, ContentModel.PROP_CONTENT);
                                // Added/modified For GCS- Start
                                String tempMimeType = "";
                                Boolean issynced = false;
                                if (serviceRegistry.getNodeService().hasAspect(nodeRef,
                                    ExternalSharingConstants.CISCO_GLOBAL_CACHING_ASPECT))
                                {
                                    issynced = (Boolean) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_IS_FILE_SYNCHED_PROP);
                                    if (issynced != null && !issynced)
                                    {
                                    	Long tempSize = (Long) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_GCS_TEMP_SIZE);
                                    	size = (tempSize != null) ? tempSize : 0;
                                    	tempMimeType = (String) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_GCS_TEMP_MIMETYPE);
                                     	extDocs.setSize((int) (size));
                                     	LOGGER.info("size not synced :: " +size + "  tempMimeType :: "+tempMimeType);
                                    }
                                    else
                                    {
                                        size = content != null ? content.getSize() : 0;
                                        extDocs.setSize((int) (size));
                                        if (issynced == null)
                                        	issynced = true;
                                    }
                                }

                                else
                                {
                                	issynced = true;
                                    LOGGER.info("issynced :: " + issynced);
                                    size = content != null ? content.getSize() : 0;
                                    extDocs.setSize((int) (size));
                                    LOGGER.info("size :: " + size);
                                }
                                extDocs.setSynced(issynced);
                                if(tempMimeType == null || tempMimeType.isEmpty()){
                                	 if (content != null)
                                     {
                                         extDocs.setMimetype(ISO9075.decode(content.getMimetype()));
                                     }
                                     else
                                     {
                                         extDocs.setMimetype(ISO9075.decode(MimetypeMap.MIMETYPE_BINARY));
                                     }
                                }else{
                                	extDocs.setMimetype(tempMimeType);
                                }
                                // Added/modified for Gcs-End
                                lockType = (String) nodeProp.get(ContentModel.PROP_LOCK_TYPE);
                                extDocs.setLocked(lockType != null ? true : false);
                                // logger.info("From Model:" + extDocs.isLocked());
                                extDocs.setModifieddate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
                                        .get(ContentModel.PROP_MODIFIED))));
                                extDocs.setSecurity((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY));
                                extDocs.setModifier((String) nodeProp.get(ContentModel.PROP_MODIFIER));
                                extDocs.setType(name.substring(name.lastIndexOf(".") + 1, name.length()));
                                // logger.info("Type:" + name.substring(name.lastIndexOf(".") + 1, name.length()));
                                extDocs.setShareUrl((String) nodeProp.get(ContentModel.PROP_NODE_UUID));
                                en_name = ISO9075.encode(name);

                                /**
                                 * Vera protected docs file names allways ends with .html extension to the original
                                 * filename. If the document is protected with vera, then append .html extension to the
                                 * file name
                                 */
                                String applyVeraProtection = ExternalSharingFileFolderUtil
                                        .getFolderVeraProtectionStatus(nodeRef, serviceRegistry);
                                if (applyVeraProtection != null
                                        && ("All Contents".equals(applyVeraProtection) || applyVeraProtection
                                                .equals((String) nodeProp
                                                        .get(ExternalSharingConstants.PROP_EXT_SECURITY))))
                                {
                                    extDocs.setApplyVeraProtection(applyVeraProtection);
                                }
                                else
                                {
                                    extDocs.setApplyVeraProtection("");
                                }
                                // US7371 - End

                                // Uthra GCS - START
                                LOGGER.info("hostname  :: " + hostname);
                                String nodeUploadedGeolocation = null;
                                if (serviceRegistry.getNodeService().hasAspect(nodeRef,
                                    ExternalSharingConstants.CISCO_GLOBAL_CACHING_ASPECT))
                                {
                                	nodeUploadedGeolocation = (String) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_UPLOAD_GELOLOCATION_PROP);
                                    LOGGER.info("nodeUploadedGeolocation :: " + nodeUploadedGeolocation);
                                }
                                if (nodeUploadedGeolocation != null && hostname != null)
                                {
                                    if (issynced != null && !issynced)
                                    {
                                        String redirectUrl = "https://" + nodeUploadedGeolocation;
                                        LOGGER.info("redirectUrl  :: " + redirectUrl); // redirect to the server where
                                                                                       // it was uploaded
                                        if (applyVeraProtection != null
                                                && ("All Contents".equals(applyVeraProtection) || applyVeraProtection
                                                        .equals((String) nodeProp
                                                                .get(ExternalSharingConstants.PROP_EXT_SECURITY))))
                                        {
                                            downloadUrl = alfrescoURL + contextName + "/ext/download/"
                                                    + nodeRef.toString().replace(":/", "") + "/" + en_name
                                                    + ".html?a=true";
                                        }
                                        else
                                        {
                                            downloadUrl = redirectUrl + contextName + "/ext/download/"
                                                    + nodeRef.toString().replace(":/", "") + "/" + en_name + "?a=true";
                                        }
                                        LOGGER.info("downloadurl in redirction  :: " + downloadUrl);

                                    }
                                    else
                                    {
                                        // its synced so sync central repository
                                        if (applyVeraProtection != null
                                                && ("All Contents".equals(applyVeraProtection) || applyVeraProtection
                                                        .equals((String) nodeProp
                                                                .get(ExternalSharingConstants.PROP_EXT_SECURITY))))
                                        {
                                            downloadUrl = alfrescoURL + contextName + "/ext/download/"
                                                    + nodeRef.toString().replace(":/", "") + "/" + en_name
                                                    + ".html?a=true";
                                        }
                                        else
                                        {
                                            downloadUrl = "https://" + hostname + contextName + "/ext/download/"
                                                    + nodeRef.toString().replace(":/", "") + "/" + en_name + "?a=true"; // need
                                                                                                                        // to
                                                                                                                        // check
                                        }
                                        LOGGER.info("downloadurl sync value true so download from local repo :: "
                                                + downloadUrl);

                                    }
                                }
                                else
                                {
                                    if (applyVeraProtection != null
                                            && ("All Contents".equals(applyVeraProtection) || applyVeraProtection
                                                    .equals((String) nodeProp
                                                            .get(ExternalSharingConstants.PROP_EXT_SECURITY))))
                                    {
                                        downloadUrl = alfrescoURL + contextName + "/ext/download/"
                                                + nodeRef.toString().replace(":/", "") + "/" + en_name + ".html?a=true";
                                    }
                                    else
                                    {
                                        downloadUrl = alfrescoURL + contextName + "/ext/download/"
                                                + nodeRef.toString().replace(":/", "") + "/" + en_name + "?a=true";
                                    }
                                    LOGGER.info("downloadurl  :: " + downloadUrl);
                                }

                                // Uthra GCS - END

                                extDocs.setDownloadUrl(downloadUrl);
                                strVersion = (String) nodeProp.get(ContentModel.PROP_VERSION_LABEL);
                                version = Double.parseDouble((strVersion != null ? strVersion : "1.0"));
                                // logger.info("version : " + version);
                                extDocs.setVersion(version);
                                // logger.info("PROP_LOCK_TYPE : " + nodeProp.get(ContentModel.PROP_LOCK_TYPE));
                                // logger.info("PROP_SIZE_CURRENT : " + nodeProp.get(ContentModel.PROP_SIZE_CURRENT));
                                extDocs.setDocStatus((String) nodeProp.get(ExternalSharingConstants.PROP_DOCSTATUS));
                                extDocs.setWorkflowStatus((String) nodeProp
                                        .get(ExternalSharingConstants.PROP_WORKFLOWSTATUS));
                                extDocs.setExpirationDate(ExternalSharingFileFolderUtil
                                        .getGMTDateFormat(((Date) nodeProp
                                                .get(ExternalSharingConstants.PROP_EXPIRAIONDATE))));
                                // To Get Permission
                                UserRole = ExternalSharingFileFolderUtil.getUserRole(serviceRegistry, currentUser,
                                    nodeRef);
                                extDocs.setPermissionLevel(UserRole);
                                extDocs.setEdcsId(edcsId);
                                // Added for US5844 start here
                                try
                                {
                                    extDocs.setModDate((Date) nodeProp.get(ContentModel.PROP_MODIFIED));
                                    // logger.info("####### before set Expiry date "+edcsId+" ######### "
                                    // +nodeProp.get(ExternalSharingConstants.PROP_EXPIRAIONDATE));
                                    if ((Date) nodeProp.get(ExternalSharingConstants.PROP_EXPIRAIONDATE) != null)
                                    {
                                        extDocs.setExpDate((Date) nodeProp
                                                .get(ExternalSharingConstants.PROP_EXPIRAIONDATE));
                                    }
                                    else
                                    {
                                        extDocs.setExpDate(new Date());
                                    }
                                    // logger.info("#######after set Expiry date ");
                                    if (edcsId != null && edcsId.indexOf("-") != -1)
                                    {
                                        int docId = Integer.parseInt(edcsId.substring(edcsId.indexOf("-") + 1));
                                        extDocs.setDocId(docId);
                                    }
                                }
                                catch (Exception exec)
                                {
                                    LOGGER.error("## Exception setModDate " + exec);
                                }
                                // Added for US5844 end
                                /* venkat changes Started */
                                boolean canUserCancelWorkflow = ExternalSharingFileFolderUtil.canUserCancelWorkflow(
                                    serviceRegistry, nodeRef);
                                extDocs.setCanUserCancelWorkflow(canUserCancelWorkflow);

                                // Us6525 : Move Files Changes start
                                boolean isPublishedInternally = false;
                                if (edcsId != null && edcsId.contains("EDCS-"))
                                {
                                    isPublishedInternally = true;
                                }
                                extDocs.setExternalyShared(isPublishedInternally);
                                // extDocs.setFavoriteStatus(customFablist.contains(nodeRef));
                                // Us6525 : Move Files Changes End
                                /* venkat changes End */
                                boolean canUserCancelCheckout = false;
                                String workingCopyOwner = null;
                                boolean isCheckedOut = false;
                                boolean isFavorite = false;
                                NodeRef originalnoderef = null;
                                if (serviceRegistry.getNodeService().hasAspect(nodeRef,
                                    ContentModel.ASPECT_WORKING_COPY))
                                {
                                    isCheckedOut = true;
                                    //workingCopyOwner = serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_WORKING_COPY_OWNER).toString();
                                    workingCopyOwner = (String) nodeProp.get(ContentModel.PROP_WORKING_COPY_OWNER);
                                    originalnoderef = (NodeRef) serviceRegistry.getCheckOutCheckInService().getCheckedOut(nodeRef);

                                }
                                // prbadam : DE3134
                                if ((workingCopyOwner != null && workingCopyOwner.equals(logginUser))
                                        || UpdateExpiringDateForDocuments.getNodeUserPermissions(nodeRef, logginUser))
                                {
                                    canUserCancelCheckout = true;
                                }
                                extDocs.setCheckOutStatus(isCheckedOut);
                                extDocs.setCanCancelCheckOut(canUserCancelCheckout);
                                extDocs.setWorkingCopyOwner(workingCopyOwner);
                              //Tags -  Uthra
                                String tagName = "";
                                if(serviceRegistry.getNodeService().hasAspect(nodeRef,ExternalSharingConstants.CISCO_TAG_ASPECT)){
                                	tagName = (String) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
                           			LOGGER.info("tagName :: " +tagName);
                           		}
                                
                               	 if(originalnoderef != null ){
                               		if(serviceRegistry.getNodeService().hasAspect(originalnoderef,ExternalSharingConstants.CISCO_TAG_ASPECT)){
                                       	tagName = (String) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
                                  			LOGGER.info("tagName for original nodeRef:: " +tagName);
                                  		}
                                 }
                               	extDocs.setTags(tagName);
                              // Tags - Uthra
                                if (originalnoderef != null)
                                {
                                    isFavorite = customFablist.contains(originalnoderef);
                                }
                                else
                                {
                                    isFavorite = customFablist.contains(nodeRef);
                                }
                                extDocs.setFavoriteStatus(isFavorite);

                                // uellappa Start: added for US7824 -"Navigate to Folder" option should be available for
                                // a document under more action.

                                List<ChildAssociationRef> parentRefs = serviceRegistry
                                        .getNodeService()
                                            .getParentAssocs(nodeRef, ContentModel.ASSOC_CONTAINS,
                                                RegexQNamePattern.MATCH_ALL);
                                if (parentRefs != null && parentRefs.size() > 0)
                                {
                                    // logger.info("parentRefs size....:" + parentRefs.size());
                                    if (parentRefs.size() > 0)
                                    {
                                        NodeRef parentNodeRef = parentRefs.get(0).getParentRef();
                                        if (Viewfav.hasPermission(parentNodeRef, logginUser, serviceRegistry))
                                        {
                                            extDocs.setFolderId(parentNodeRef.toString());
                                        }
                                        else
                                        {
                                            extDocs.setFolderId("");
                                        }
                                    }
                                }

                                // uellappa End: added for US7824 -"Navigate to Folder" option should be available for a
                                // document under more action.

                                // START : DE1900 - prbadam added for checking if node having different domains.
                                if (CheckDomain.getDomainStatus(extdoc.getNodeId()).get("status1") == "401")
                                {
                                    LOGGER.info("in if inside 401-------");
                                    extDocs.setDomainMismatch(false);
                                }
                                else
                                {
                                    extDocs.setDomainMismatch(true);
                                }
                                // END : DE1900 - prbadam added for checking if node having different domains.

                                listExtDocs.add(extDocs);
                            } // end of if for noderef null check
                        } // end of for loop

                        finalNodeRefSet = null;
                        return null;
                    }
                }, "admin");
            }
        }
        catch (InvalidQNameException e)
        {
            LOGGER.error(e);
        }
        catch (InvalidNodeRefException e)
        {
            LOGGER.error(e);
        }
        catch (Exception e)
        {
            LOGGER.error(e);
        }

        fileListMap.put("result", listExtDocs);
        return fileListMap;
    }

    // get date format based on number of days
    private String getToDate(int daysToSubtract)
    {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -daysToSubtract);
        SimpleDateFormat formatedDate = new SimpleDateFormat(DATE_FORMAT);
        String toDate = formatedDate.format(c.getTime());
        return toDate.toString();
    }

    private List<NodeRef> getNodeRefListFromLuceneQuery(String query, ServiceRegistry registry, int pageNum,
            QName field, boolean sortingOrder, int pageSize, Map<String, Object> fileListMap)
    {
        List<NodeRef> arrNodeRef = null;
        LOGGER.error("pageSize2 : " + pageSize + " ;pageNum : " + pageNum + " ;field : " + field +" ;softOrder " + sortingOrder + " ;query : " + query);
        String sortingField = "";
        if(field.toString().contains("modified")){
        	sortingField = "@cm:modified";
        } else if(field.toString().contains("name")){
        	sortingField = "@cm:name";
        } else if(field.toString().contains("publishExpirationDate")){
        	sortingField = "@ext:publishExpirationDate";
        } else if(field.toString().contains("alf_id")){
        	sortingField = "@cs:alf_id";
        } else if(field.toString().contains("content.size")){
        	sortingField = "@"+field.toString();
        } else if(field.toString().contains("content.mimetype")){
        	sortingField = "@"+field.toString();
        }
        LOGGER.error("Sorting Field : " + sortingField );
        try
        {
            SearchParameters sp = new SearchParameters();
            sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
            sp.setLanguage(SearchService.LANGUAGE_FTS_ALFRESCO);
            sp.setQuery(query);
            //sp.addSort(field.toString(),sortingOrder);
            //sp.addSort("@cs:alf_id", sortingOrder);
            sp.addSort(sortingField,sortingOrder);
            sp.setMaxItems(pageSize);
            sp.setLimit(pageSize);
            sp.setLimitBy(LimitBy.UNLIMITED);
            sp.setSkipCount((pageNum-1)*pageSize);

            ResultSet results = registry.getSearchService().query(sp);
            LOGGER.error("result set sizes1 : " + results.length() + " ; " + results.getNumberFound());
            fileListMap.put("totalItems", results.getNumberFound());
            arrNodeRef = new ArrayList<NodeRef>();
            if (results != null && results.length() > 0)
            {
                results.setBulkFetch(true);
                arrNodeRef = results.getNodeRefs();
                LOGGER.error("List Size : " + arrNodeRef.size());
                results.close();
            }
            else
            {
                LOGGER.error("No Search Results found");
                return Collections.emptyList();
            }
            LOGGER.info("arrNodeRef before duplicates remove---------" + arrNodeRef.size());
            HashSet<NodeRef> searchNodeRefSet = new HashSet<NodeRef>(arrNodeRef);
            arrNodeRef = new ArrayList<NodeRef>(searchNodeRefSet);
        }
        catch (Exception e)
        {
            LOGGER.error("Exception getNodeRefList : " + e);
        }
        return arrNodeRef;
    }
}