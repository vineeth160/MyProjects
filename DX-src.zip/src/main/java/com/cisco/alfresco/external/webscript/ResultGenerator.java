package com.cisco.alfresco.external.webscript;

// Java program to illustrate 
// for Writing Data in CSV file 
import java.io.*; 
import java.util.*; 
import com.opencsv.CSVWriter; 

public class ResultGenerator { 
	private static final String CSV_FILE_PATH 
		= "C:/Users/vipatnai/Desktop/result.csv"; 
	public static void main(String[] args) 
	{ 
		addDataToCSV(CSV_FILE_PATH); 
	} 
	
	public static void addDataToCSV(String filePath) 
	{ 

		// first create file object for file placed at location 
		// specified by filepath 
		File file = new File(filePath); 

		try { 
			// create FileWriter object with file as parameter 
			FileWriter outputfile = new FileWriter(file); 

			// create CSVWriter with '|' as separator 
			CSVWriter writer = new CSVWriter(outputfile); 

			// create a List which contains String array 
			List<String[]> data = new ArrayList<String[]>(); 
			data.add(new String[] { "Name", "Class", "Marks" }); 
			data.add(new String[] { "Aman", "10", "620" }); 
			data.add(new String[] { "Suraj", "10", "630" }); 
			writer.writeAll(data); 

			// closing writer connection 
			writer.close(); 
		} 
		catch (IOException e) { 
			// TODO Auto-generated catch block 
			e.printStackTrace(); 
		} 
	} 

	} 
 
