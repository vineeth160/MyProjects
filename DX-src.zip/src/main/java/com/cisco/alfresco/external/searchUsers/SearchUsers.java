package com.cisco.alfresco.external.searchUsers;

import java.io.IOException;


import java.io.Serializable;
import java.net.UnknownHostException;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.JSONArray;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;
import com.cisco.alfresco.auth.ext.EXTEncrypter;
import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;


/**
 * 
 * @author prbadam nathammi
 * 
 */
public class SearchUsers extends AbstractWebScript
{
    private static final Logger LOGGER = Logger.getLogger(SearchUsers.class);
    static final String LDAP_SEARCHBASE = "o=cco.cisco.com";
    static final String LDAP_MAIL_ATTRIBUTES = "mail";// "uid";
    static final String LDAP_UID_ATTRIBUTES = "uid";
    static final String LDAP_CN_ATTRIBUTES = "cn";
    static final String LDAP_COMPANY_ATTRIBUTES = "company";
    public static final String INITCTX = "com.sun.jndi.ldap.LdapCtxFactory";
    public static final String INITFACTORY="java.naming.factory.initial";
    static final String LDAP_DISPLAY_NAME_ATTRIBUTES ="displayName";
	private static final String GROUP_IDENTITY ="GROUP_";
	private static String LDAP_AUTHENTICATION_SIMPLE="simple";
	private static String CISCO_DOMAIN="@cisco.com";
	private static String CISCO_DOMAI_ID="cisco.com";
	private static final String CISCO_RESTRICTED="Cisco Restricted";
	static final String GENERICS_LDAP_SEARCHBASE = "OU=Generics,O=cco.cisco.com";
	private String mailerGroupsLdapHost;// "ldap://ds.cisco.com:389";
	private String mailerGroupsGenericUser;
	private String mailerGroupsGenericPwd;
	private String mailerGroupsGenericKey;
	private String mailerGroupsLdapSearchBase;
	private static String genericUser;
    private static String genericPwd;
    private static String genericKey;
	private ServiceRegistry serviceRegistry;
    private static PersonService personService;

    public PersonService getPersonService()
    {
        return personService;
    }

    public void setPersonService(PersonService personService)
    {
        this.personService = personService;
    }

    private PermissionService permissionService;

    public PermissionService getPermissionService()
    {
        return permissionService;
    }

    public void setPermissionService(PermissionService permissionService)
    {
        this.permissionService = permissionService;
    }

    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    private static String ldapHost;// = "ldap://dsx.cisco.com:389";

    public static String getLdapHost()
    {
        return ldapHost;
    }

    public void setLdapHost(String ldapHost)
    {
        this.ldapHost = ldapHost;
    }
    
    public String getMailerGroupsLdapSearchBase() {
		return mailerGroupsLdapSearchBase;
	}

	public void setMailerGroupsLdapSearchBase(String mailerGroupsLdapSearchBase) {
		this.mailerGroupsLdapSearchBase = mailerGroupsLdapSearchBase;
	}
    public String getMailerGroupsLdapHost() {
		return mailerGroupsLdapHost;
	}

	public void setMailerGroupsLdapHost(String mailerGroupsLdapHost) {
		this.mailerGroupsLdapHost = mailerGroupsLdapHost;
	}

	public String getMailerGroupsGenericUser() {
		return mailerGroupsGenericUser;
	}

	public void setMailerGroupsGenericUser(String mailerGroupsGenericUser) {
		this.mailerGroupsGenericUser = mailerGroupsGenericUser;
	}

	public String getMailerGroupsGenericPwd() {
		return mailerGroupsGenericPwd;
	}

	public void setMailerGroupsGenericPwd(String mailerGroupsGenericPwd) {
		this.mailerGroupsGenericPwd = mailerGroupsGenericPwd;
	}

	public String getMailerGroupsGenericKey() {
		return mailerGroupsGenericKey;
	}

	public void setMailerGroupsGenericKey(String mailerGroupsGenericKey) {
		this.mailerGroupsGenericKey = mailerGroupsGenericKey;
	}
    
	 public String getGenericUser()
	    {
	        return genericUser;
	    }

	    public void setGenericUser(String genericUser)
	    {
	        this.genericUser = genericUser;
	    }

	    public String getGenericPwd()
	    {
	        return genericPwd;
	    }

	    public void setGenericPwd(String genericPwd)
	    {
	        this.genericPwd = genericPwd;
	    }

	    public String getGenericKey()
	    {
	        return genericKey;
	    }

	    public void setGenericKey(String genericKey)
	    {
	        this.genericKey = genericKey;
	    }
	    
    /**
     * provides a User Object with LDAP details filled in for the specified user login name
     * 
     * @param aUserLoginName
     *            user Login Name (CEC id) of the user who's LDAP info is desired
     * @return a User Object with the LDAP information filled in for the specified user login name.
     * @throws ASTGException
     *             if unable to provide the LDAP details for the specified user login name
     */

    @SuppressWarnings("unchecked")
	public String doSearchUserNamesFromLDAP(String userLoginName, NodeRef node, String domain,String searchType,boolean isCiscoRestricted)
    {

        String domainFilter = "";
        String jsonString = null;
        JSONArray jsonArray = new JSONArray();
        try
        {
            if (domain != null && !domain.equals(""))
            {
                String[] domainList = domain.split(",");
                for (int p = 0; p < domainList.length && domainList.length > 0; p++)
                {
                    domainFilter = domainFilter + "|(mail=*@" + domainList[p].trim() + "*)";
                }
                LOGGER.error("domainFilter after splitting--------" + domainFilter);
            }else{
            	//Strat-US8122
            	if(isCiscoRestricted){
	            		domainFilter = "|(mail=*@cisco.com*)";
	            	}
            	//End-US8122
	            }
            String myFilter = null;
            if (!domainFilter.equals(""))
            {
                if (userLoginName != null && !userLoginName.equals(""))
                {
                    userLoginName = userLoginName.trim();
                    String delimeter = "@";
                    
                    if (!userLoginName.contains(" "))
                    {
                    	if(userLoginName.contains(delimeter)){
                        	myFilter = "(&(" + domainFilter + ")(|(mail=" + userLoginName + "*)))";
                        
                        }else{
                        myFilter = "(&(" + domainFilter + ")(|(uid=" + userLoginName + "*)|(cn=" + userLoginName
                                + "*)))";
                        LOGGER.error("myFilter without space-------" + myFilter);
                        }
                    }
                    else
                    { // checking if userLoginName contains space
                        String fName = userLoginName.substring(0, userLoginName.indexOf(" "));
                        String lName = userLoginName.substring(userLoginName.indexOf(" "), userLoginName.length());
                        lName = lName.trim();

                        myFilter = "(&(" + domainFilter + ")((|(cn=" + fName + "*))&(sn=" + lName + "*)))";
                        LOGGER.error("myFilter with space----------" + myFilter);
                    } // End of checking if userLoginName contains space
                }
                else
                {
                    myFilter = "(&(" + domainFilter + ")(uid=*))";
                    LOGGER.error("inside else userLoginName is null----------" + myFilter);
                }
            }
            else
            {
                myFilter = "(|(uid=" + userLoginName + "*)|(cn=" + userLoginName + "*))";
                LOGGER.error("inside else domainFilter is null----------" + myFilter);
            }
            LOGGER.error("Final LDAP User search filter----- " + myFilter);

            @SuppressWarnings("rawtypes")
			Hashtable myEnv = new Hashtable();
            myEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
            myEnv.put(Context.PROVIDER_URL, getLdapHost());
            myEnv.put(Context.SECURITY_PRINCIPAL, genericUser);
            myEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(genericPwd, genericKey).getBytes("UTF8"));
            DirContext myDirContext = new InitialDirContext(myEnv);
            SearchControls mySearchControls = new SearchControls();
            mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            LOGGER.error("Connecting & Searching from LDAP...: ");
            NamingEnumeration<SearchResult> mySearchResults = myDirContext.search(LDAP_SEARCHBASE, myFilter,
                mySearchControls);
            if(mySearchResults == null || !mySearchResults.hasMore()){
             	 mySearchResults = myDirContext.search(GENERICS_LDAP_SEARCHBASE,myFilter,
                          mySearchControls );
             }
            LOGGER.error("Iterating LDAP searched resutlset...: ");
            SearchResult myNextEmployee;
            int increment = 0;

            Boolean usrExist = false;
            while (mySearchResults != null && mySearchResults.hasMore())
            {
                myNextEmployee = (SearchResult) mySearchResults.next();
                String userMail = "";
                if (increment <= 25)
                {
                    if (myNextEmployee != null && myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES) != null)
                    {
                        userMail = myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES).get().toString();
                        if (userMail.startsWith("nobody_"))
                        {
                            continue;
                        }
                        increment += 1;
                        String userName = myNextEmployee.getAttributes().get(LDAP_UID_ATTRIBUTES).get().toString();
                        String completeName = myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES).get().toString();
                        String company = myNextEmployee.getAttributes().get(LDAP_COMPANY_ATTRIBUTES).get().toString();

                        LOGGER.debug("userName-------------" + userName);
                        final String userNameVal = userName;
                        usrExist = (Boolean) AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
                        {
                            public Object doWork() throws Exception
                            {
                                return personService.personExists(userNameVal);
                            }
                        }, "admin");

                        String permission = getUserPermission(node, userName,searchType) != null ? getUserPermission(
								node, userName,searchType) : "No";
                        String role = permission;
                        permission = role.split("Role")[0];
                        LOGGER.debug("permission---" + permission);

                        if (company != null && company.equals("0"))
                        {
                            company = "";
                        }
                        if (company != null && company.contains(","))
                        {
                            company = company.replaceAll(",", "");
                        }

                        JSONObject obj = new JSONObject();

                        obj.put("name", completeName);
                        obj.put("company", company);
                        obj.put("email", userMail);
                        obj.put("userId", userName);
                        obj.put("existing", usrExist);
                        obj.put("permission", permission);
                        obj.put("type", searchType);
                        jsonArray.add(obj);
                        LOGGER.debug("json obj ---" + obj);
                    }
                }
                else
                {
                    break;
                }
            }

            jsonString = new JSONObject().put("userList", jsonArray).toString();

            myDirContext.close();
        }
        catch (Exception e)
        {
            try
            {

                if (e.getClass().getSimpleName().equalsIgnoreCase("NameNotFoundException"))
                {
                    JSONObject jsonsObject = new JSONObject();
                    jsonsObject.put("userList", jsonArray);
                    jsonsObject.put("message", "No Match found with Mail, Name and User Id");
                    jsonString = jsonsObject.toString();
                }
                else if (e.getClass().getSimpleName().equalsIgnoreCase("SizeLimitExceededException"))
                {
                    JSONObject jsonsObject = new JSONObject();
                    jsonsObject.put("userList", jsonArray);
                    jsonsObject.put("message", "Search Size Limit Exceeded. Please refine your search criteria.");
                    jsonString = jsonsObject.toString();
                }
                else if (e.getClass().getSimpleName().equalsIgnoreCase("TimeLimitExceededException"))
                {
                    JSONObject jsonsObject = new JSONObject();
                    jsonsObject.put("userList", jsonArray);
                    jsonsObject.put("message", "Search Time Limit Exceeded. Please refine your search criteria.");
                    jsonString = jsonsObject.toString();
                }
                else
                {
                    JSONObject jsonsObject = new JSONObject();
                    jsonsObject.put("userList", jsonArray);
                    jsonsObject.put("message", e.getClass().getSimpleName());
                    jsonString = jsonsObject.toString();
                }

            }
            catch (JSONException e1)
            {
                LOGGER.error(e1);
            }
            LOGGER.error("Exception.." + e);
            return jsonString;
        }
        return jsonString;
    }

    private String getUserPermission(NodeRef documentNodeRef, String currentUserName,String searchType) throws JSONException
    {
        LOGGER.debug(".Checking User Permissions.....: " + currentUserName);

        String permission = null;
        Set<AccessPermission> accessPermissions = permissionService.getAllSetPermissions(documentNodeRef);
        Iterator<AccessPermission> fIterator = accessPermissions.iterator();

        while (fIterator.hasNext())
        {
            AccessPermission accessPermission = (AccessPermission) fIterator.next();

            if (accessPermission.getAuthorityType() == AuthorityType.USER && searchType.equalsIgnoreCase("user")) {
				LOGGER.debug("Authority(User): "
						+ accessPermission.getAuthority() + " Permission: "
						+ accessPermission.getPermission());

				String autherityUserName = accessPermission.getAuthority();
				if (autherityUserName.equals(currentUserName)) {
					LOGGER.debug("Authority(User):: "
							+ accessPermission.getAuthority()
							+ " Permission:: "
							+ accessPermission.getPermission());

					permission = accessPermission.getPermission();
					LOGGER.debug("permission--------" + permission);
				}
			}else if(accessPermission.getAuthorityType() == AuthorityType.GROUP && searchType.equalsIgnoreCase("grouper")){
				LOGGER.debug("Authority(User): "
						+ accessPermission.getAuthority() + " Permission: "
						+ accessPermission.getPermission());

				String autherityUserName = accessPermission.getAuthority();
				if (autherityUserName.equals(currentUserName)) {
					LOGGER.debug("Authority(User):: "
							+ accessPermission.getAuthority()
							+ " Permission:: "
							+ accessPermission.getPermission());

					permission = accessPermission.getPermission();
					LOGGER.debug("permission--------" + permission);
				}
			}
        }
        return permission;
    }

    /**
     * provides a User Object with LDAP details filled in for the specified user login name
     * 
     * @param aUserLoginName
     *            user Login Name (CEC id) of the user who's LDAP info is desired
     * @return a User Object with the LDAP information filled in for the specified user login name.
     * @throws ASTGException
     *             if unable to provide the LDAP details for the specified user login name
     */

    @SuppressWarnings("unchecked")
	public String doAddUserNamesFromLDAP(String userLoginName, NodeRef node, String domain,String searchType,boolean isCiscoRestricted)
    {
        String domainFilter = "";
        String jsonStringAddUser = null;
        JSONObject jsonObject = new JSONObject();
        JSONArray jsonArrayAddUser = new JSONArray();
        String invalidUsers = "";

        if (domain != null && !domain.equals(""))
        {
            String[] domainList = domain.split(",");
            for (int p = 0; p < domainList.length && domainList.length > 0; p++)
            {
                domainFilter = domainFilter + "|(mail=*" + domainList[p].trim() + "*)";
            }
        }else{
    		//Strat-US8122
        	if(isCiscoRestricted){
          		domainFilter = "|(mail=*@cisco.com*)";
          	}
        	//End-US8122
          }
        String[] userList = null;
        if (null != userLoginName)
        {
            userList = userLoginName.split(",");
        }

        for (int i = 0; i < userList.length; i++)
        {
            try
            {
                String myFilter = null;
                if (!domainFilter.equals(""))
                {
                	if(userList[i].contains("@")){
                    	myFilter = "(&(" + domainFilter + ")(|(mail=" + userList[i] + "*)))";
                    	
                    }else
                    myFilter = "(&(" + domainFilter + ")(uid=" + userList[i] + "))";
                }
                else
                {
                	if(userList[i].contains("@")){
                    	myFilter = "(&(mail=" + userList[i] + "))";
                    
                    }else
                    myFilter = "(&(uid=" + userList[i] + "))";
                }
                LOGGER.debug("myFilter:::::::::::::::" + myFilter);
                @SuppressWarnings("rawtypes")
				Hashtable myEnv = new Hashtable();
                myEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
                myEnv.put(Context.PROVIDER_URL, getLdapHost());
                myEnv.put(Context.SECURITY_PRINCIPAL, genericUser);
                myEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(genericPwd, genericKey).getBytes("UTF8"));
                DirContext myDirContext = new InitialDirContext(myEnv);
                SearchControls mySearchControls = new SearchControls();
                mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);

                NamingEnumeration<SearchResult> mySearchResults = myDirContext.search(LDAP_SEARCHBASE, myFilter,
                    mySearchControls);
                if(mySearchResults == null || !mySearchResults.hasMore()){
                 	 mySearchResults = myDirContext.search(GENERICS_LDAP_SEARCHBASE,myFilter,
                              mySearchControls );
                 }
                SearchResult myNextEmployee;
                boolean usrExist = false;

                while (mySearchResults != null && mySearchResults.hasMore())
                {
                    String userMail = "";
                    myNextEmployee = (SearchResult) mySearchResults.next();
                    if (myNextEmployee != null && myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES) != null)
                    {

                        userMail = myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES).get().toString();
                        if (userMail.startsWith("nobody_"))
                        {
                            continue;
                        }
                        String userName = myNextEmployee.getAttributes().get(LDAP_UID_ATTRIBUTES).get().toString();
                        String completeName = myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES).get().toString();
                        String company = myNextEmployee.getAttributes().get(LDAP_COMPANY_ATTRIBUTES).get().toString();

                        final String userNameVal = userName;
                        usrExist = (Boolean) AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
                        {
                            public Object doWork() throws Exception
                            {
                                return personService.personExists(userNameVal);
                            }
                        }, "admin");

                        String permission = getUserPermission(node, userName,searchType) != null ? getUserPermission(
								node, userName,searchType) : "No";
                        String role = permission;
                        permission = role.split("Role")[0];

                        JSONObject obj = new JSONObject();

                        obj.put("name", completeName);
                        obj.put("company", company);
                        obj.put("email", userMail);
                        obj.put("userId", userName);
                        obj.put("existing", usrExist);
                        obj.put("permission", permission);
                        obj.put("type", searchType);
                        jsonArrayAddUser.add(obj);
                        LOGGER.debug("jsonArrayAddUser obj ---" + obj);
                    }
                }

                myDirContext.close();
            }
            catch (Exception e)
            {
                try
                {
                    invalidUsers = invalidUsers + userList[i] + ",";
                    jsonStringAddUser = jsonObject.put("valid", jsonArrayAddUser).toString();
                }
                catch (Exception e1)
                {
                    LOGGER.error(e1);
                }
                LOGGER.error("Exception.." + e);
                LOGGER.debug("Exception--------" + e);
            }
        }
        try
        {
            if (invalidUsers.contains(","))
            {
                invalidUsers = invalidUsers.substring(0, invalidUsers.lastIndexOf(","));
                LOGGER.debug("invalidUsers----------" + invalidUsers);
            }
            jsonStringAddUser = jsonObject.put("valid", jsonArrayAddUser).toString();
            jsonStringAddUser = jsonObject.put("invalid", invalidUsers).toString();
        }
        catch (JSONException e)
        {
            // TODO Auto-generated catch block
            LOGGER.error(e);
        }
        return jsonStringAddUser;
    }

    /**
     * 
     * @param req
     * @return
     */
    private String readRequestBody(WebScriptRequest req)
    {
        try
        {
            return IOUtils.toString(req.getContent().getInputStream(), req.getContent().getEncoding());
        }
        catch (Exception e)
        {
            LOGGER.error(e);
            try
            {
                return req.getContent().getContent();
            }
            catch (IOException e1)
            {
                LOGGER.error("Unable to read JSON request body", e1);
                throw new WebScriptException("Unable to read JSON request body!! Epic fail.");
            }
        }
    }

    @Override
    public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException
    {

        String inputJSONValue = readRequestBody(req);
        JSONObject jsonObject;
        String action = null, searchString = null,searchType=null, nodeId = null;
        String jsonObjStr = null;
        String domain = null;
        NodeRef nodeRef = null;
        boolean isCiscoRestricted = false;
        try
        {
            // for getting description file url (placeholder)
            Map<String, String> templateArgs = req.getServiceMatch().getTemplateVars();
            action = templateArgs.get("action");

            jsonObject = new JSONObject(inputJSONValue);
            searchString = jsonObject.getString("searchValue");
            nodeId = jsonObject.getString("nodeId");
            searchType=jsonObject.getString("searchType");
            nodeRef = new NodeRef(nodeId);

            LOGGER.error("folder nodeRef------" + nodeRef);

            boolean isDoc = serviceRegistry.getDictionaryService().isSubClass(
                serviceRegistry.getNodeService().getType(nodeRef), ContentModel.TYPE_CONTENT);
            LOGGER.error("isDoc-------------" + isDoc);

            QName domainAspect = QName
                    .createQName("http://www.alfresco.org/model/external/content/1.0", "domainAspect");
            QName domainName = QName.createQName("http://www.alfresco.org/model/external/content/1.0", "domain_name");
            boolean hasDomainAspect = serviceRegistry.getNodeService().hasAspect(nodeRef, domainAspect);
            LOGGER.error("domainAspect-------" + domainAspect);
            LOGGER.error("domainName-------" + domainName);
            LOGGER.error("hasAspect-------" + hasDomainAspect);

            Serializable domainNamevalue = serviceRegistry.getNodeService().getProperty(nodeRef, domainName);
            LOGGER.error("domainNamevalue-------" + domainNamevalue);
           
            if (!isDoc)
            {
                LOGGER.error("in if------");
                domain = (String) serviceRegistry.getNodeService().getProperty(nodeRef,
                    QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"));
            }
            else
            {
                LOGGER.error("in else------");
                ChildAssociationRef childAssociationRef = serviceRegistry.getNodeService().getPrimaryParent(nodeRef);
                NodeRef parentNodeRef = childAssociationRef.getParentRef();
                LOGGER.error(" parentNodeRef----------" + parentNodeRef);
                domain = (String) serviceRegistry.getNodeService().getProperty(parentNodeRef,
                    QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"));
              //US8122-start
        		String securityTypeProp = (String) serviceRegistry.getNodeService().getProperty(nodeRef, CiscoModelConstants.CISCO_SECURITY_PROP);
        		LOGGER.error("UserPermission Document Security Type Prop :: " +securityTypeProp);
        		if (securityTypeProp != null && securityTypeProp.equalsIgnoreCase(CISCO_RESTRICTED)){
        			isCiscoRestricted=true;
        		}
        		//US8122-end
            
            }
            // DE1888-kvr
            if (domain != null && !domain.isEmpty() && !domain.contains("cisco.com"))
            {
                domain = domain + ",cisco.com";
            }
            LOGGER.error(" domain -------" + domain);

        }
        catch (JSONException e)
        {
            LOGGER.error(e);
        }
        if(searchType.equalsIgnoreCase("user")){
        if ("search".equalsIgnoreCase(action))
        {
            jsonObjStr = doSearchUserNamesFromLDAP(searchString != null ? searchString.trim() : searchString, nodeRef,
                domain,searchType,isCiscoRestricted);
        }
        else if ("add".equalsIgnoreCase(action))
        {

            jsonObjStr = doAddUserNamesFromLDAP(searchString != null ? searchString.trim() : searchString, nodeRef,
                domain,searchType,isCiscoRestricted);
        }
        }else if(searchType.equalsIgnoreCase("grouper")){
			if (action.equalsIgnoreCase("search")) {
				jsonObjStr = doSearchGroupNamesFromLDAP(searchString != null ? searchString.trim() : searchString, nodeRef,
						domain,searchType);
			} else if (action.equalsIgnoreCase("add")) {
				jsonObjStr = doAddGroupNamesFromLDAP(searchString != null ? searchString.trim() : searchString, nodeRef,
						 domain,searchType);
			}
		}

        LOGGER.debug("jsonObjStr :" + jsonObjStr);
        res.setContentType("application/json");
        res.getWriter().write(jsonObjStr);

    }
    
    /**
  	 * provides a User Object with LDAP details filled in for the specified user
  	 * login name
  	 * **/
      @SuppressWarnings({ "unchecked", "rawtypes" })
	public String doSearchGroupNamesFromLDAP(String grouperName,NodeRef node,
  			 String domain,String searchType) {
  		String domainFilter = "";
  		String jsonString = null;
  		JSONArray jsonArray = new JSONArray();
  		try {
  			 if (domain != null && !domain.equals(""))
  	            {
  				//considering only cisco domain for groups
  				if(domain.contains(CISCO_DOMAI_ID)){
  	  				domainFilter="(mail=" + CISCO_DOMAI_ID + ")";
  	  			}else{
  	  			String[] domainList = domain.split(",");
  	                for (int p = 0; p < domainList.length && domainList.length > 0; p++)
  	                {
  	                    domainFilter = domainFilter + "|(mail=*@" + domainList[p].trim() + "*)";
  	                }
  	  			}
  	              LOGGER.error("search domainFilter after splitting ::: "+domainFilter);
  	            }
  	            String myFilter = null;
  	            if (!domainFilter.equals(""))
  	            {
  	                if (grouperName != null && !grouperName.equals(""))
  	                {
  	                	grouperName = grouperName.trim();
  		                if (!grouperName.contains(" ")) 
  		                {
  		                	if(domain.contains(CISCO_DOMAI_ID)){
  	  		                	myFilter = "(|(&(" + domainFilter + "))(&(cn=" + grouperName+ "*)))";
  	  		                	}else{
  	  		                		myFilter = "(&(" + domainFilter + ")(|(cn="+grouperName+"*)))";
  	  		                	}
  		                	LOGGER.error("search group Filter without space ::: "+myFilter);
  		                } 
  		                else 
  		                {	// checking if grouperName contains space
  		                	String groupDisplayName = grouperName.substring(0, grouperName.indexOf(" "));
  		                	if(domain.contains(CISCO_DOMAI_ID)){
  	  		                	myFilter = "(|(&(" + domainFilter + "))(&(displayName=" + groupDisplayName+ "*)))";
  	  		                	}else{
  	  		                		myFilter = "(&(" + domainFilter + ")((|(cn=" +groupDisplayName + "*))&(displayName="+ groupDisplayName+"*)))";
  	  		                	}
  		                	LOGGER.error("search group with space  ::::  "+myFilter);
  						} // End of checking if grouperName contains space
  	                }
  	                else
  	                {
  	                    myFilter = "(&(" + domainFilter + ")(cn=*))";
  	                  LOGGER.error("inside else grouperName is null  ::::  "+myFilter);
  	                }
  	            }
  	            else
  	            {
  	            	if (!grouperName.contains(" ")) 
	                {
            		 myFilter = "(|(cn="+grouperName+"*)|(displayName="+grouperName+"*))";
	                }else{
	                String formatedGroupName = grouperName.substring(0, grouperName.indexOf(" "));
	                myFilter = "(|(cn="+formatedGroupName+"*)|(displayName="+formatedGroupName+"*))";
	                }
  	            	LOGGER.error("inside else domainFilter is null  ::::  "+myFilter);
  	            }
  	            LOGGER.error("Final LDAP group search filter :::  " + myFilter);
  	          	LOGGER.error(":::ldapURL :::"+getMailerGroupsLdapHost());
  	    		LOGGER.error("Final LDAP group search searchBase ::: " + getMailerGroupsLdapSearchBase());
  			Hashtable myEnv = new Hashtable<String, String>();
  			myEnv.put(INITFACTORY, INITCTX);                                //"com.sun.jndi.ldap.LdapCtxFactory"
  			myEnv.put(Context.PROVIDER_URL, getMailerGroupsLdapHost());    //"ldap://ds.cisco.com:389"
  			myEnv.put(Context.SECURITY_AUTHENTICATION,LDAP_AUTHENTICATION_SIMPLE );
			myEnv.put(Context.SECURITY_PRINCIPAL, getMailerGroupsGenericUser());
			myEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(getMailerGroupsGenericPwd(), getMailerGroupsGenericKey()).getBytes("UTF8"));
  			DirContext myDirContext = new InitialDirContext(myEnv);
  			SearchControls mySearchControls = new SearchControls();
  			mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
  			String[] searchReturningAttributes = null;
  			searchReturningAttributes = new String[] { "description", "displayName", "member", "cn","company","mail"};
  			mySearchControls.setReturningAttributes(searchReturningAttributes);
  			LOGGER.error("Connecting & Searching from LDAP...: ");
  			NamingEnumeration<SearchResult> mySearchResults = null;
			mySearchResults = myDirContext
	  					.search(getMailerGroupsLdapSearchBase(), myFilter, mySearchControls);
  			LOGGER.error("Iterating LDAP searched resutlset...: ");
  			int increment = 0;
  			boolean groupExistInRepo = false;
  			while (mySearchResults != null && mySearchResults.hasMore()) {
  				Attributes attrs = ((SearchResult) mySearchResults.next()).getAttributes();
  				//LOGGER.error("myNextEmployee :::: "+attrs);
  				String grouperMail = "";
  				if (increment <= 25) {
  					if (attrs != null && attrs.size()>0) {
  						increment += 1;
  						String groupName = attrs.get("cn").get().toString();
  						LOGGER.error("groupName ::: " + groupName);
  						if(attrs.get("mail")==null){
  							grouperMail =attrs.get("cn").get().toString()+CISCO_DOMAIN;
  						}else{
  							grouperMail =attrs.get("mail").get().toString();
  						}
  						String displayName ="";
  						if(attrs.get("displayName")==null){
  							displayName =attrs.get("cn").get().toString();
  						}else{
  							displayName = attrs.get("displayName").get().toString();
  						}
  						LOGGER.error("grouperMail ::: " + grouperMail);
  						LOGGER.error("displayName ::: " + displayName);
  						String company = "";
  						if(attrs.get("company") != null ){
  						company = attrs.get("company").get().toString();
  						}
  						LOGGER.error("company--- " + company);
  						groupExistInRepo=serviceRegistry.getAuthorityService().authorityExists(GROUP_IDENTITY + groupName);
  						String permission = getUserPermission(node, GROUP_IDENTITY+groupName,searchType) != null ? getUserPermission(
  								node, GROUP_IDENTITY+groupName,searchType) : "No";
  						String role = permission;
  						permission = role.split("Role")[0];
  						LOGGER.error("permission---" + permission);
  						if (company != null && company.equals("0")) {
  							company = "";
  						}
  						if (company != null && company.contains(",")) {
  							company = company.replaceAll(",", "");
  						}
  						JSONObject obj = new JSONObject();
  						obj.put("name", displayName);
  						obj.put("company", company);
  						obj.put("email", grouperMail);
  						obj.put("userId", GROUP_IDENTITY+groupName);
  						obj.put("existing", groupExistInRepo);
  						obj.put("permission", permission);
  						obj.put("type", searchType);
  						jsonArray.add(obj);
  						LOGGER.error("group search json obj  ::::  " + obj);
  					}
  				} else {
  					break;
  				}
  			}

  			jsonString = new JSONObject().put("userList", jsonArray).toString();

  			myDirContext.close();
  		} catch (Exception e) {
  			try {

  				if (e.getClass().getSimpleName()
  						.equalsIgnoreCase("NameNotFoundException")) {
  					JSONObject jsonsObject = new JSONObject();
  					jsonsObject.put("userList", jsonArray);
  					jsonsObject.put("message",
  							"No Match found with Mail, Name and Group Id");
  					jsonString = jsonsObject.toString();
  				} else if (e.getClass().getSimpleName()
  						.equalsIgnoreCase("SizeLimitExceededException")) {
  					JSONObject jsonsObject = new JSONObject();
  					jsonsObject.put("userList", jsonArray);
  					jsonsObject
  							.put("message",
  									"Search Size Limit Exceeded. Please refine your search criteria.");
  					jsonString = jsonsObject.toString();
  				} else if (e.getClass().getSimpleName()
  						.equalsIgnoreCase("TimeLimitExceededException")) {
  					JSONObject jsonsObject = new JSONObject();
  					jsonsObject.put("userList", jsonArray);
  					jsonsObject
  							.put("message",
  									"Search Time Limit Exceeded. Please refine your search criteria.");
  					jsonString = jsonsObject.toString();
  				} else {
  					JSONObject jsonsObject = new JSONObject();
  					jsonsObject.put("userList", jsonArray);
  					jsonsObject.put("message", e.getClass().getSimpleName());
  					jsonString = jsonsObject.toString();
  				}

  			} catch (JSONException e1) {
  				e1.printStackTrace();
  			}
  			LOGGER.error("group search exception.." + e.getMessage());
  			e.printStackTrace();
  			return jsonString;
  		}
  		LOGGER.error(" group search jsonString ::: "+jsonString.toString());
  		return jsonString;
  	}
      
	
      /**
  	 * provides a group Object with LDAP details filled in for the specified user
  	 * login name
  	 * 
  	 */

  	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String doAddGroupNamesFromLDAP(String grouperName,NodeRef node,
 			 String domain,String searchType) {
  		String domainFilter = "";
  		String jsonStringAddGroup = null;
  		JSONObject jsonObject = new JSONObject();
  		JSONArray jsonArrayAddGroup = new JSONArray();
  		String invalidGroups="";
  		if (domain != null && !domain.equals("")) {
  			//considering only cisco domain for groups
  			if(domain.contains(CISCO_DOMAI_ID)){
	  				domainFilter="(mail=" + CISCO_DOMAI_ID + ")";
	  			}else{
	  				String[] domainList = domain.split(",");
	  	  			for (int p = 0; p < domainList.length && domainList.length > 0; p++) {
	  	  				domainFilter = domainFilter + "|(mail=*" + domainList[p].trim() + "*)";
	  	  			}
	  			}
  		}
  		String[] grouperList = null;
  		if (null != grouperName) {
  			grouperList = grouperName.split(",");
  		}
  		LOGGER.debug("grouperList.length ::::::::::::::: " + grouperList.length);
  		for (int i = 0; i < grouperList.length; i++) {
  			try {
  				String myFilter = null;
  				if (!domainFilter.equals("")) {
  					if(domain.contains(CISCO_DOMAI_ID)){
  	  					myFilter = "(|(&(" + domainFilter + "))(&(cn=" + grouperList[i]
  	  							+ ")))";
  	  					}else{
  	  						myFilter = "(&(" + domainFilter + ")(cn=" + grouperList[i]
  		  							+ "))";
  	  					}
  				} else {
  					myFilter = "(&(cn=" + grouperList[i] + "))";
  				}
  				LOGGER.error("group add search filter ::::::::::::::: " + myFilter);
  				Hashtable myEnv = new Hashtable<String, String>();
  				myEnv.put(INITFACTORY, INITCTX); 				    //"com.sun.jndi.ldap.LdapCtxFactory"
  	  			myEnv.put(Context.PROVIDER_URL, getMailerGroupsLdapHost());       //"ldap://ds.cisco.com:389"
  	  			myEnv.put(Context.SECURITY_AUTHENTICATION,LDAP_AUTHENTICATION_SIMPLE );
  				myEnv.put(Context.SECURITY_PRINCIPAL, getMailerGroupsGenericUser());
  				myEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(getMailerGroupsGenericPwd(), getMailerGroupsGenericKey()).getBytes("UTF8"));
  	  			DirContext myDirContext = new InitialDirContext(myEnv);
  	  			SearchControls mySearchControls = new SearchControls();
  	  			mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
  	  			String[] searchReturningAttributes = null;
  	  			searchReturningAttributes = new String[] { "description", "displayName", "member", "cn","company","mail"};
  	  			mySearchControls.setReturningAttributes(searchReturningAttributes);
  	  			LOGGER.error("Connecting & Searching from LDAP...: ");
  	  			NamingEnumeration<SearchResult> mySearchResults = null;
  				mySearchResults = myDirContext
  		  					.search(getMailerGroupsLdapSearchBase(), myFilter, mySearchControls);
  				LOGGER.error("Iterating LDAP searched resutlset...: ");
  	  	if(!mySearchResults.hasMore()){
  	  		invalidGroups=invalidGroups+grouperList[i]+",";
  	  		}
  				boolean groupExist = false;
  				while (mySearchResults != null && mySearchResults.hasMore()) {
  					String grouperMail = "";
  					Attributes attrs = ((SearchResult) mySearchResults.next()).getAttributes();
  					if(attrs != null && attrs.size()>0){
  						String groupName = attrs.get("cn").get().toString();
  						if(attrs.get("mail")==null){
  							grouperMail =attrs.get("cn").get().toString()+CISCO_DOMAIN;
  						}else{
  							grouperMail =attrs.get("mail").get().toString();
  						}
  						String displayName ="";
  						if(attrs.get("displayName")==null){
  							displayName =attrs.get("cn").get().toString();
  						}else{
  							displayName = attrs.get("displayName").get().toString();
  						}
  						String company = "";
  						if(attrs.get("company") != null ){
  						company = attrs.get("company").get().toString();
  						}
  						groupExist=serviceRegistry.getAuthorityService().authorityExists(GROUP_IDENTITY + groupName);
  						String permission = getUserPermission(node, GROUP_IDENTITY+groupName,searchType) != null ? getUserPermission(
  								node, GROUP_IDENTITY+groupName,searchType) : "No";
  						String role = permission;
  						permission = role.split("Role")[0];
  						JSONObject obj = new JSONObject();
  						obj.put("name", displayName);
  						obj.put("company", company);
  						obj.put("email", grouperMail);
  						obj.put("userId", GROUP_IDENTITY+groupName);
  						obj.put("existing", groupExist);
  						obj.put("permission", permission);
  						obj.put("type", searchType);
  						jsonArrayAddGroup.add(obj);
  						LOGGER.error(" add groups jsonArrayAddUser obj   ::::  " + obj);
  					}else {
  	  					break;
  	  				}
  				}

  				myDirContext.close();
  			} catch (Exception e) {
  				
  				try {
  					invalidGroups=invalidGroups+grouperList[i]+",";
  					jsonStringAddGroup = jsonObject.put("valid",	jsonArrayAddGroup).toString();
  				} catch (Exception e1) {
  					e1.printStackTrace();
  				}
  				LOGGER.error(" add groups exception.." + e);
  				e.printStackTrace();
  			}
  		}
  		try {
  			if(invalidGroups.contains(","))
  			{
  				invalidGroups = invalidGroups.substring(0,invalidGroups.lastIndexOf(","));
  				LOGGER.error("invalidUsers   ::::  "+invalidGroups);
  			}
  			jsonStringAddGroup = jsonObject.put("valid",	jsonArrayAddGroup).toString();
  			jsonStringAddGroup = jsonObject.put("invalid",invalidGroups).toString();
  		} catch (JSONException e) {
  			LOGGER.error(" add groups exception.." + e);
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}
  		return jsonStringAddGroup;
  	}
  	
  	
  	
  	
  	public static void main(String[] args) throws HttpException, IOException {
		doSearchUserNamesFromLDAPTest("ciscoadmin.gen","",false);
	}
		public static String doSearchUserNamesFromLDAPTest(String userLoginName, String domain,boolean isCiscoRestricted)
	    {

	        String domainFilter = "";
	        String jsonString = null;
	        JSONArray jsonArray = new JSONArray();
	        try
	        {
	            if (domain != null && !domain.equals(""))
	            {
	                String[] domainList = domain.split(",");
	                for (int p = 0; p < domainList.length && domainList.length > 0; p++)
	                {
	                    domainFilter = domainFilter + "|(mail=*@" + domainList[p].trim() + "*)";
	                }
	                System.out.println("domainFilter after splitting--------" + domainFilter);
	            }else{
	            	//Strat-US8122
	            	if(isCiscoRestricted){
		            		domainFilter = "|(mail=*@cisco.com*)";
		            	}
	            	//End-US8122
		            }
	            String myFilter = null;
	            if (!domainFilter.equals(""))
	            {
	                if (userLoginName != null && !userLoginName.equals(""))
	                {
	                    userLoginName = userLoginName.trim();
	                    String delimeter = "@";
	                    
	                    if (!userLoginName.contains(" "))
	                    {
	                    	if(userLoginName.contains(delimeter)){
	                        	myFilter = "(&(" + domainFilter + ")(|(mail=" + userLoginName + "*)))";
	                        
	                        }else{
	                        myFilter = "(&(" + domainFilter + ")(|(uid=" + userLoginName + "*)|(cn=" + userLoginName
	                                + "*)))";
	                        System.out.println("myFilter without space-------" + myFilter);
	                        //&(ou=Generics*|ou=ccoentities*)
	                        }
	                    }
	                    else
	                    { // checking if userLoginName contains space
	                        String fName = userLoginName.substring(0, userLoginName.indexOf(" "));
	                        String lName = userLoginName.substring(userLoginName.indexOf(" "), userLoginName.length());
	                        lName = lName.trim();

	                        myFilter = "(&(" + domainFilter + ")((|(cn=" + fName + "*))&(sn=" + lName + "*)))";
	                        System.out.println("myFilter with space----------" + myFilter);
	                    } // End of checking if userLoginName contains space
	                }
	                else
	                {
	                    myFilter = "(&(" + domainFilter + ")(uid=*))";
	                    System.out.println("inside else userLoginName is null----------" + myFilter);
	                }
	            }
	            else
	            {
	                myFilter = "(|(uid=" + userLoginName + "*)|(cn=" + userLoginName + "*))";
	                System.out.println("inside else domainFilter is null----------" + myFilter);
	            }
	            System.out.println("Final LDAP User search filter----- " + myFilter);
	            System.out.println("added");
	            @SuppressWarnings("rawtypes")
				Hashtable myEnv = new Hashtable();
	            myEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
	            myEnv.put(Context.PROVIDER_URL, "ldap://dsx.cisco.com:389");
	            myEnv.put(Context.SECURITY_PRINCIPAL, "ciscoadmin.gen");
	            //myEnv.put(Context.SECURITY_CREDENTIALS, decrypt("1C!sco123#", "9AE1378B2718BDEAAEFFA4AD72353").getBytes("UTF8"));
	            myEnv.put(Context.SECURITY_CREDENTIALS, "1C!sco123#");
	            System.out.println("myenv object::"+myEnv.toString());
	            DirContext myDirContext = new InitialDirContext(myEnv);
	            System.out.println("context:"+myDirContext);
	            SearchControls mySearchControls = new SearchControls();
	            mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
	            System.out.println("Connecting & Searching from LDAP...: ");
	            NamingEnumeration<SearchResult> mySearchResults = myDirContext.search(LDAP_SEARCHBASE, myFilter,
	                mySearchControls);
	            //mySearchResults = myDirContext.search(GENERICS_LDAP_SEARCHBASE,myFilter,
	                          //mySearchControls );
	             
	            System.out.println("Iterating LDAP searched resutlset...: "+mySearchResults);
	            SearchResult myNextEmployee;
	            int increment = 0;

	            Boolean usrExist = false;
	            while (mySearchResults != null && mySearchResults.hasMore())
	            {
	                myNextEmployee = (SearchResult) mySearchResults.next();
	                String userMail = "";
	                if (increment <= 25)
	                {
	                    if (myNextEmployee != null && myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES) != null)
	                    {
	                        userMail = myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES).get().toString();
	                        if (userMail.startsWith("nobody_"))
	                        {
	                            continue;
	                        }
	                        increment += 1;
	                        String userName = myNextEmployee.getAttributes().get(LDAP_UID_ATTRIBUTES).get().toString();
	                        String completeName = myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES).get().toString();
	                        String company = myNextEmployee.getAttributes().get(LDAP_COMPANY_ATTRIBUTES).get().toString();

	                        LOGGER.debug("userName-------------" + userName);
	                        final String userNameVal = userName;
						/*
						 * usrExist = (Boolean) AuthenticationUtil.runAs(new
						 * AuthenticationUtil.RunAsWork<Object>() { public Object doWork() throws
						 * Exception { return personService.personExists(userNameVal); } }, "admin");
						 */

	                       // String permission = getUserPermission(node, userName,searchType) != null ? getUserPermission(
								//	node, userName,searchType) : "No";
	                        //String role = permission;
	                        //permission = role.split("Role")[0];
	                        //LOGGER.debug("permission---" + permission);

	                        if (company != null && company.equals("0"))
	                        {
	                            company = "";
	                        }
	                        if (company != null && company.contains(","))
	                        {
	                            company = company.replaceAll(",", "");
	                        }

	                        JSONObject obj = new JSONObject();

	                        obj.put("name", completeName);
	                        obj.put("company", company);
	                        obj.put("email", userMail);
	                        obj.put("userId", userName);
	                        obj.put("existing", usrExist);
	                        //obj.put("permission", permission);
	                        //obj.put("type", searchType);
	                        jsonArray.add(obj);
	                        System.out.println("json obj ---" + obj);
	                    }
	                }
	                else
	                {
	                    break;
	                }
	            }

	            jsonString = new JSONObject().put("userList", jsonArray).toString();
	            System.out.println("jsn::"+jsonString);

	            myDirContext.close();
		
	        }catch (Exception e){
	        	System.out.println("exception::");
	        	e.printStackTrace();	
	        }
			return jsonString;
	        }
		
		public static String decrypt(String val, String key) throws UnknownHostException{
			String decryptedPropertyValue = null;
			System.out.println("String to decrypt :"+val.substring(0,3)+"*****: Key "+key.substring(0,3)+"*******");
			StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
			//String[] strValArray = StringUtils.split(val, " ");
			encryptor.setPassword(key);
			decryptedPropertyValue = encryptor.decrypt(val);
			//logger.info(decryptedPropertyValue); 
			return decryptedPropertyValue;
			}
	
}
