package com.cisco.alfresco.external.webscript;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.Serializable;
import java.io.StringWriter;
import java.io.Writer;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import org.alfresco.error.AlfrescoRuntimeException;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.InvalidQNameException;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.json.JsonSerializer;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.external.common.model.UserInfo;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.USERTYPE;

/**
 * This webscript is used to retrieve the list of files for logged in user within the given period of date
 * 
 * @author rajbaska nathammi
 * 
 */

public class HasUserAcceptedPolicyWebScript extends DeclarativeWebScript
{
    private static final Logger logger = Logger.getLogger(HasUserAcceptedPolicyWebScript.class);
    private static final String URL_PROTOCOL ="https://";
    private ServiceRegistry serviceRegistry;
    private String veraDocExAdminGroup;
	private String alfrescoURL;
    private ExternalLDAPUtil ldapUtil;
    private String geoServerLocation;
    private String dxJivePage;
    private String dxFAQPage;
    private String gettingStartGuide;
    private String mailSupport;
    private String remediCaseURL;
    private String inTouchPages;
    private String liveChatSupports;
    private String hostName;
    
	
	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	private Properties globalProperties;
    private JSONObject jsonObject;
    
    public void setGlobalProperties(Properties globalProperties) {
		this.globalProperties = globalProperties;
	}

	public String getLiveChatSupports() {
		return liveChatSupports;
	}

	public void setLiveChatSupports(String liveChatSupports) {
		this.liveChatSupports = liveChatSupports;
	}

	public String getInTouchPages() {
		return inTouchPages;
	}

	public void setInTouchPages(String inTouchPages) {
		this.inTouchPages = inTouchPages;
	}

	public String getDxJivePage() {
		return dxJivePage;
	}

	public void setDxJivePage(String dxJivePage) {
		this.dxJivePage = dxJivePage;
	}

	public String getDxFAQPage() {
		return dxFAQPage;
	}

	public void setDxFAQPage(String dxFAQPage) {
		this.dxFAQPage = dxFAQPage;
	}

	public String getGettingStartGuide() {
		return gettingStartGuide;
	}

	public void setGettingStartGuide(String gettingStartGuide) {
		this.gettingStartGuide = gettingStartGuide;
	}

	public String getMailSupport() {
		return mailSupport;
	}

	public void setMailSupport(String mailSupport) {
		this.mailSupport = mailSupport;
	}

	public String getRemediCaseURL() {
		return remediCaseURL;
	}

	public void setRemediCaseURL(String remediCaseURL) {
		this.remediCaseURL = remediCaseURL;
	}

    public String getAlfrescoURL() {
		return alfrescoURL;
	}

	public void setAlfrescoURL(String alfrescoURL) {
		this.alfrescoURL = alfrescoURL;
	}

    
    public String getVeraDocExAdminGroup() {
		return veraDocExAdminGroup;
	}

	public void setVeraDocExAdminGroup(String veraDocExAdminGroup) {
		this.veraDocExAdminGroup = veraDocExAdminGroup;
	}
	

	public ExternalLDAPUtil getLdapUtil() {
		return ldapUtil;
	}

	public void setLdapUtil(ExternalLDAPUtil ldapUtil) {
		this.ldapUtil = ldapUtil;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }
    public String getGeoServerLocation() {
		return geoServerLocation;
	}

	public void setGeoServerLocation(String geoServerLocation) {
		this.geoServerLocation = geoServerLocation;
	}

	@Override
    public Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
    {
        logger.info("Calling HasUserAcceptedPolicyWebScript...");
        final Map<String, Object> model = new HashMap<String, Object>();

        try
        {
        	String isAccessTokenValid = req.getParameter("isAccessTokenValid");
        	logger.info("isAccessTokenValid  ::::::::: "+ isAccessTokenValid);
        	String isGCServerIsRunning = req.getParameter("isGCServerIsRunning");
        	logger.info("isServerIsRunning :::::::::: "+ isGCServerIsRunning);
        	final String ipAddress = req.getParameter("ipAddress");                	
        	//final String ipAddress = "10.65.198.141";
        	logger.info("ipAddress  :: " +req.getParameter("ipAddress"));
	final String region = req.getParameter("region");
        	
        	logger.info("regionn  :: "+ region);
            AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
            {
                @Override
                public Object doWork() throws Exception
                {
                    String currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
                    UserInfo userInfo = hasUserAccepted(currentUser, ipAddress,region,isAccessTokenValid,isGCServerIsRunning);
                    ObjectMapper mapper = new ObjectMapper();
                    Writer strWriter = new StringWriter();
                    mapper.writeValue(strWriter, userInfo);
                    String jsonString = strWriter.toString();
                    logger.info("Result JSON  for hasUserAcceptedPolicy: " + jsonString);
                    model.put("result", jsonString);
                    return null;
                }
            }, "admin");
        }
        catch (AlfrescoRuntimeException e)
        {
            logger.error("Exception occured:" + e.getMessage());
        }
        catch (Exception e)
        {
            logger.error("Exception : " + e);
            e.printStackTrace();
        }

        return model;
    }

	public UserInfo hasUserAccepted(String currentUser, String ipAddressOfUser,String region,String isAccessTokenValid,String isGCServerIsRunning)
    {
        boolean hasAspect = false;
        Map<QName, Serializable> ldapUserProperties = new HashMap<>();
		String ldapUserFirstName = null, ldapUserLastName = null; 
        UserInfo userInfo = new UserInfo();
        boolean hasEmailNotificationAspect=false;
        boolean optOutEmailNotify=false;
        try
        {
            NodeRef personNode = serviceRegistry.getPersonService().getPerson(currentUser);
            boolean hasUserDisabled=serviceRegistry.getNodeService().hasAspect(personNode, ContentModel.ASPECT_PERSON_DISABLED);
            if (personNode != null && !hasUserDisabled)
            {
                QName EX_POLICY_DETAILS_ASPECT = QName.createQName("http://www.cisco.com/model/content/1.0",
                    "policyDetails");
                hasAspect = serviceRegistry.getNodeService().hasAspect(personNode, EX_POLICY_DETAILS_ASPECT);

                NodeService nodeService = serviceRegistry.getNodeService();
                boolean hasAcceptedProperty = false;
                boolean isAdmin = false;

                if (hasAspect)
                {
                    hasAcceptedProperty = (Boolean) nodeService.getProperty(personNode,
                        ExternalSharingConstants.PROP_EXT_POLICY_ACCEPTED);
                }

                // Create the UserInfo object and populate it

                //US8499 :prbadam start
                String ldapUserDetails = null;
                if(currentUser.endsWith(".gen")){
                	logger.info("Generic Userid Calling.....");
                	ldapUserDetails = ldapUtil.getGenericUserDetailsFromLDAP(currentUser);
                } else {
                	logger.info("NormalUser Calling.....");
                	ldapUserDetails = ldapUtil.getUserDetailsFromLDAP(currentUser);
                }
                
                logger.info("ldapUserDetails----"+ldapUserDetails);
                
                String ldapUserId = (ldapUserDetails.split("::"))[0];
                ldapUserProperties.put(ContentModel.PROP_USERNAME, ldapUserId);
                
                String name = (ldapUserDetails.split("::"))[1];
		        //for getting first name and last name separately
                if (name.contains(" "))
		        {
                	ldapUserFirstName = (name.split(" "))[0];
                	ldapUserProperties.put(ContentModel.PROP_FIRSTNAME, ldapUserFirstName);
                	
		            //ldapUserLastName = (name.split(" "))[1];
                	ldapUserLastName=name.replace(ldapUserFirstName, "");
		            ldapUserProperties.put(ContentModel.PROP_LASTNAME, ldapUserLastName);
		        }
		        else{
		        	ldapUserFirstName = name;
		            ldapUserLastName="";
		        }
                               
                String ldapUserCompanyValue = (ldapUserDetails.split("::"))[2];
                ldapUserProperties.put(ContentModel.PROP_ORGANIZATION, ldapUserCompanyValue);
                
                String ldapUserEmailID = (ldapUserDetails.split("::"))[3];
                ldapUserProperties.put(ContentModel.PROP_EMAIL, ldapUserEmailID);
                
                nodeService.addProperties(personNode, ldapUserProperties);
                
            	Serializable userIdValue = nodeService.getProperty(personNode, ContentModel.PROP_USERNAME);
            	Serializable firstNameValue = nodeService.getProperty(personNode, ContentModel.PROP_FIRSTNAME);
                Serializable lastNameValue = nodeService.getProperty(personNode, ContentModel.PROP_LASTNAME);
                Serializable companyValue = nodeService.getProperty(personNode, ContentModel.PROP_ORGANIZATION);
                Serializable emailValue = nodeService.getProperty(personNode, ContentModel.PROP_EMAIL);
                //US9853-start
                hasEmailNotificationAspect = serviceRegistry.getNodeService().hasAspect(personNode, ExternalSharingConstants.ASPECT_OPTINOUT_EMAIL_NOTIFICATION);
                if(hasEmailNotificationAspect){
                	optOutEmailNotify = (Boolean) serviceRegistry.getNodeService().getProperty(personNode, ExternalSharingConstants.PROP_OPTOUT_EMAIL_NOTIFY);
                }
                logger.info("final ldap user values-------"+userIdValue+" :: "+firstNameValue+" :: "+lastNameValue+" :: "+companyValue+" :: "+ emailValue+" :: "+ optOutEmailNotify);
                //US8499 :prbadam end
                
                Set<String> groupSet = serviceRegistry.getAuthorityService().getAuthoritiesForUser(userIdValue.toString());
                isAdmin = groupSet.contains("GROUP_CISCOSHARE_ADMIN");
                Boolean isUserVeraAdmin = false;
                if(veraDocExAdminGroup!= null){
                	isUserVeraAdmin = groupSet.contains("GROUP_"+veraDocExAdminGroup);
                } else {
                	logger.error("veraDocExAdminGroup value found null.Please check the properties file");
                }
                
                //GCS Changes- Start
                
                String geoLocationurl =null , geoLoc = null;
        		List<String> gcsLocDetails = getGeoLocation(ipAddressOfUser,region);
                logger.info("gcsLocDetails.size()  final:: " +gcsLocDetails.size());
                //Below condition for updating the location value from the /setLocation call
                if(gcsLocDetails.size()>0){
                geoLocationurl = gcsLocDetails.get(0);
                logger.info("geoLocationurl : " + geoLocationurl);
                }
                Boolean GCXserverStatusCheck = Boolean.parseBoolean(isGCServerIsRunning);
               // Boolean GCXserverStatusCheck = true;
				logger.info("GCXserverStatusCheck :::: "+GCXserverStatusCheck);
                if(gcsLocDetails!=null  &&  !gcsLocDetails.isEmpty() && GCXserverStatusCheck){                	
                	geoLocationurl = gcsLocDetails.get(0);
                	logger.info("geoLocationurl : " + geoLocationurl);
                    geoLoc = gcsLocDetails.get(1);
                    logger.info("geoLoc : " + geoLoc);
                 }else{                	                  	 
            		geoLoc = "Richardson-US";
                 	geoLocationurl = getGeoLocationURL(geoLoc);
        			logger.info("condition is for ipaddress is not matching with the addresses in json.. and default will be Richardson  ::  " +geoLoc + "  url :: " + geoLocationurl);
            	 }
            
                // GCS changes- end
                
                String userId = (userIdValue == null) ? "" : (String) userIdValue;
                String firstName = (firstNameValue == null) ? "" : (String) firstNameValue;
                String lastName = (lastNameValue == null) ? "" : (String) lastNameValue;
                String company = (companyValue == null) ? "" : (String) companyValue;
                String email = (emailValue == null) ? "" : (String) emailValue;
                String geoLocationURL = (geoLocationurl == null) ? "" : geoLocationurl;
                Properties properties=new Properties();
                // /apps/alfcmadm/alfresco-5.1.1/tomcat/shared/classes/cisco-global.dev.properties
        		properties.load(new FileInputStream("./tomcat/shared/classes/alfresco-global.properties"));
        		jsonObject=new JSONObject();
        		       
        		jsonObject.put("hostName", properties.get("alfresco.host"));
        		logger.info("<<<jsonObject>>>"+jsonObject);
        		
        		
        		String hostName = (String) jsonObject.get("hostName");
        		logger.info("<<<hostName>>>"+hostName);
                String geoLocationName = (geoLoc == null) ? "" : geoLoc;
                // String geoLocationURL ="https://cdx-dev.cisco.com" ;  //https://ciscoshare-sydney-dev.cisco.com
                String geoHostname = null;
                if(geoLocationURL != null && !geoLocationURL.isEmpty() && geoLocationURL != ""){
            	   geoHostname= geoLocationURL.replace(URL_PROTOCOL, "");
            	   logger.info("geoLocationname::  " +geoHostname);  	
                } 
                
                String geoHost = (geoHostname == null) ? "" : geoHostname;
                USERTYPE userType = getUserInfo(personNode);
                userInfo.setFirstName(firstName);
                logger.info(userInfo);
                userInfo.setLastName(lastName);
                logger.info(userInfo);
                userInfo.setEmail(email);
                logger.info(userInfo);
                userInfo.setCompany(company);
                logger.info(userInfo);
                userInfo.setUserId(userId);
                logger.info(userInfo);
                userInfo.setUserType(userType);
                logger.info(userInfo);
                userInfo.setHostName(hostName);
                logger.info(userInfo);
                userInfo.setHasAccepted(hasAcceptedProperty);
                logger.info(userInfo);
                userInfo.setAdmin(isAdmin);
                //userInfo.setGeoLocationURL(geoLocationURL); 
                userInfo.setGeoHostName(geoHost);
                logger.info(userInfo);
                userInfo.setGeoLocation(geoLocationName);
                userInfo.setDxServerIsRunning(GCXserverStatusCheck);               
                //prbadam start: US9741
                userInfo.setDocExchangeJivePage((dxJivePage == null) ? "" : (String) dxJivePage);
                userInfo.setDocExchangeFAQPage((dxFAQPage == null) ? "" : (String) dxFAQPage);
                userInfo.setGettingStartedGuide((gettingStartGuide == null) ? "" : (String) gettingStartGuide);
                userInfo.setEmailSupport((mailSupport == null) ? "" : (String) mailSupport);
                userInfo.setRemedyCaseURL((remediCaseURL == null) ? "" : (String) remediCaseURL);
                userInfo.setInTouchPage((inTouchPages == null) ? "" : (String) inTouchPages);
                userInfo.setLiveChatSupport((liveChatSupports == null) ? "" : (String) liveChatSupports);
                //prbadam end: US9741
                userInfo.setOptOutEmailNotification(optOutEmailNotify);
                if(isUserVeraAdmin != null && isUserVeraAdmin){
                	userInfo.setUserVeraAdmin(true);
                } else {
                	userInfo.setUserVeraAdmin(false);
                }
                boolean isOpsSupportUser = false;
                //Checking is Support User or not.
                isOpsSupportUser = isSupportGroupUser(currentUser);
                logger.info("coming from group ===> " + isOpsSupportUser);
                userInfo.setOpsSupportUser(isOpsSupportUser);
                Boolean isAccessTokenCheck = Boolean.parseBoolean(isAccessTokenValid);
                logger.info("=====isAccessTokenCheck====="+isAccessTokenCheck);
                userInfo.setAccessTokenValid(isAccessTokenCheck);
            }
            else
            {

                logger.info("Person node is not available");
                userInfo.setUserType(USERTYPE.INVALID_USER);

                return userInfo;
            }

        }
        catch (InvalidQNameException e)
        {
            e.printStackTrace();
        }
        catch (InvalidNodeRefException e)
        {
            e.printStackTrace();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return userInfo;
    }
    
    public String getGeoLocationURL(String location){
    	String gcsLocationUrl =null;
    	try {
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(new FileReader(geoServerLocation));
			JSONObject jsonObject = (JSONObject) obj;
			JSONArray regionsArray = (JSONArray) jsonObject.get("regions");
			for(int i=0;i<regionsArray.size();i++){
				//System.out.println("Regions::"+regionsArray.get(i));
				JSONObject regionObject =(JSONObject)regionsArray.get(i);
				String geoLocation = (String) regionObject.get("location"); 
				if(geoLocation.equalsIgnoreCase(location)){
					gcsLocationUrl = (String) regionObject.get("url"); 
					logger.info("gcsLocationUrl::"+gcsLocationUrl);
					break;
				}
			}
			
		} catch (Exception e) {
			logger.info("Exception is ::"+ e.getStackTrace(), e);
		}
		return gcsLocationUrl;
		
	}
    
    
    public List<String> getGeoLocation(String userIP,String region){
    	List<String> gcsLocation =null;
    	gcsLocation = new ArrayList<String>();
    	try {
			if(userIP!=null && userIP != ""){
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(new FileReader(geoServerLocation));
			JSONObject jsonObject = (JSONObject) obj;
			JSONArray regionsArray = (JSONArray) jsonObject.get("regions");
			boolean found = false;
			for(int i=0;i<regionsArray.size();i++){
				JSONObject regionObject =(JSONObject)regionsArray.get(i);
				JSONArray ipRangeArray =(JSONArray) regionObject.get("ipRange");
				for(int j=0;j<ipRangeArray.size();j++){
					JSONObject ipRangeObject =(JSONObject)ipRangeArray.get(j);
					String fromIP = (String) ipRangeObject.get("from");
					String toIP = (String) ipRangeObject.get("to");
					if(isValidRange(fromIP,toIP,userIP)){
						String geoURL = (String) regionObject.get("url"); 
						logger.info("geoURL::"+geoURL);
						gcsLocation.add(geoURL);
						String geoLocation = (String) regionObject.get("location"); 
						logger.info("geoLocation::"+geoLocation);
						gcsLocation.add(geoLocation);
						found=true;
						break;
					}
				}
			}
			if(!found){
				//String gcsServiceUrl = alfrescoURL+"/user/region?ip="+userIP;
			/*	String gcsServiceUrl = alfrescoURL+"/alfext/user/region?ip="+userIP;
			    logger.info("RegionServiceUrl  :: " +gcsServiceUrl);
				final HttpClient client = new HttpClient();
				final GetMethod mGet = new GetMethod(gcsServiceUrl);
				//mPost.setRequestHeader(new Header("Cookie", ssoCookie));
				client.executeMethod(mGet);
				String responseBody = mGet.getResponseBodyAsString();
				String region = null;
				try {
					Object parserObj = parser.parse(responseBody);
					JSONObject jsonObject1 = (JSONObject) parserObj;
		           region = (String) jsonObject1.get("region");
					logger.info("region :: " +region);
				} catch (org.json.simple.parser.ParseException e) {
					e.printStackTrace();
				}*/
				JSONArray publicRegionsArray = (JSONArray) jsonObject.get("publicRegions");
				for(int i=0;i<publicRegionsArray.size();i++){
					JSONObject publicRegionObject =(JSONObject)publicRegionsArray.get(i);
					String contient = (String) publicRegionObject.get("region"); 
					if(contient.equalsIgnoreCase(region)){
						String geoURL = (String) publicRegionObject.get("url"); 
						gcsLocation.add(geoURL);
						String geoLocation = (String) publicRegionObject.get("location"); 
						logger.info("geoLocation::"+geoLocation);
						gcsLocation.add(geoLocation);
						break;
					}

				}
			}
		}
		} catch (Exception e) {
			logger.info("Exception is ::"+ e.getStackTrace(), e);
		}
		//logger.error("gcsLocation.size()-2 :: " +gcsLocation.size());
		return gcsLocation;
		
	}
    
    public static boolean isValidRange(String ipStart, String ipEnd, String ipToCheck) {
		try {
			long ipLo = ipToLong(InetAddress.getByName(ipStart));
			long ipHi = ipToLong(InetAddress.getByName(ipEnd));
			long ipToTest = ipToLong(InetAddress.getByName(ipToCheck));
			return (ipToTest >= ipLo && ipToTest <= ipHi);
		} catch (UnknownHostException e) {
			e.printStackTrace();
			return false;
		}
	}
    
    public static long ipToLong(InetAddress ip) {
		byte[] octets = ip.getAddress();
		long result = 0;
		for (byte octet : octets) {
			result <<= 8;
			result |= octet & 0xff;
		}
		return result;
	}

    private USERTYPE getUserInfo(NodeRef personNodeRef)
    {

        USERTYPE userType = USERTYPE.EXTERNAL;

        if (personNodeRef != null)
        {

            String name = (String) serviceRegistry.getNodeService().getProperty(personNodeRef, ContentModel.PROP_NAME);
            if (name != null && !name.equals(""))
            {
                if (name.endsWith(".gen"))
                {
                    userType = USERTYPE.GENERIC;
                }
            }

            String emailId = (String) serviceRegistry.getNodeService().getProperty(personNodeRef,
                ContentModel.PROP_EMAIL);
            if (emailId != null && !emailId.equals(""))
            {
                if (emailId.endsWith("@cisco.com"))
                {
                    userType = USERTYPE.INTERNAL;
                }
            }
        }

        return userType;
    }
    
    public boolean isSupportGroupUser(String currentUserName) {
		boolean isUserExistinGroup = false;
		Set<String> userAuthorities = serviceRegistry.getAuthorityService().getAuthoritiesForUser(currentUserName);
		String supportGroupName = globalProperties.getProperty("docex.supportgroup.name");
		if(supportGroupName != null && userAuthorities.contains(supportGroupName)) {
			isUserExistinGroup = true;
		}
		return isUserExistinGroup;
	}
}