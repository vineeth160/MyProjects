package com.cisco.alfresco.external.webscript;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.AuthenticationService;
import org.alfresco.service.cmr.security.AuthorityService;
import org.alfresco.service.cmr.security.MutableAuthenticationService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.sd.rest.service.MigrationConstants;


/**
 * 
 * @author dhshaw
 * 
 */

public class CreateExtUserWebScript extends AbstractWebScript
{
    private static Logger LOGER = Logger.getLogger(CreateExtUserWebScript.class);
    private ServiceRegistry serviceRegistry;
    private PersonService personService;
    private AuthenticationService authenticationService;
    private NodeService nodeService;

    private static String zoneId = AuthorityService.ZONE_AUTH_EXT_PREFIX + "ldap";
    
    
    private ExternalLDAPUtil ldapUtil;

    public ExternalLDAPUtil getLdapUtil()
    {
        return ldapUtil;
    }

    public void setLdapUtil(ExternalLDAPUtil ldapUtil)
    {
        this.ldapUtil = ldapUtil;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException
    {
        createUser(req, res);
    }

    public void createUser(WebScriptRequest req, WebScriptResponse res)
    {
        LOGER.info("CreateExtUserWebScript.createUser method start...");
        personService = serviceRegistry.getPersonService();
        nodeService = serviceRegistry.getNodeService();
        authenticationService = serviceRegistry.getAuthenticationService();
        final Set<String> zoneSet = getZones(zoneId);
        
        try
        {
            // NodeRef usersFolderNode = EDCSUtil.doSearch("PATH:\"/sys:system/sys:people\"", serviceRegistry);
            // org.springframework.extensions.surf.util.Content content = req.getContent();
            // JSONObject json;

            JSONParser jsonParser = new JSONParser();
            org.json.simple.JSONObject jsonObject = null;
            jsonObject = (JSONObject) jsonParser.parse(req.getParameter("jsonMetadata"));

            String finalUsers = (String) jsonObject.get("finalUsers");
            LOGER.info("finalUsers =" + finalUsers);
            String[] ids = finalUsers.split(",");
            for (int i = 0; i < ids.length; i++)
            {
                String firstName = "", lastName = "";
                String idAndName = ldapUtil.getUserDetailsFromLDAP(ids[i]);

                LOGER.info("idAndName =" + idAndName);

                String userName = (idAndName.split("::"))[0];

                LOGER.info("userName =" + userName);
                String name = (idAndName.split("::"))[1];

                LOGER.info("name =" + name);

                String organization = (idAndName.split("::"))[2];

                if (name.contains(" "))
                {
                    firstName = (name.split(" "))[0];

                    LOGER.info("firstName =" + firstName);

                    lastName = (name.split(" "))[1];

                    LOGER.info("lastName =" + lastName);
                }
                else
                    firstName = name;

                String email = ldapUtil.getManagerEmailFromLDAP(ids[i]);
                LOGER.info("email ======" + email);

                boolean isUserExists = personService.personExists(userName);
                if (!isUserExists)
                {
                    HashMap<QName, Serializable> properties = new HashMap<QName, Serializable>();
                    properties.put(ContentModel.PROP_USERNAME, userName);
                    // properties.put(ContentModel.PROP_HOMEFOLDER, userNodeRef);
                    properties.put(ContentModel.PROP_FIRSTNAME, firstName);
                    properties.put(ContentModel.PROP_LASTNAME, lastName);
                    properties.put(ContentModel.PROP_EMAIL, email);
                    properties.put(ContentModel.PROP_ORGANIZATION, organization);
                    NodeRef newPerson = this.personService.createPerson(properties, zoneSet);
                    
                    // added by mkatnam for External User Access Level -- Start
                    if(!nodeService.hasAspect(newPerson, MigrationConstants.CISCO_EXTERNAL_USER_ASPECT)){
                    	Map<QName, Serializable> extUserProp = new HashMap<QName, Serializable>();
                    	LOGER.info("::before calling accessLevel::");
                    	int accessLevel = Integer.parseInt(ldapUtil.getUserAccessLevelFromLDAP(ids[i]));
                    	LOGER.info("::after calling accessLevel::>" +accessLevel);
                    	extUserProp.put(MigrationConstants.CISCO_EXTERNAL_USER_ACCESS_PROP, accessLevel);
						nodeService.addAspect(newPerson, MigrationConstants.CISCO_EXTERNAL_USER_ASPECT, extUserProp);
                    }
                    //mkatnam --END
                    
                    // authenticationService.getAuthenticationEnabled("");
                    LOGER.info("newPerson::" + newPerson);
                    // ensure the user can access their own Person object
                    // permissionService.setPermission(newPerson,"GROUP_EVERYONE", permissionService.getAllPermission(),
                    // true);
                    // create the ACEGI Authentication instance for the new user
                    ((MutableAuthenticationService) authenticationService).createAuthentication(userName,
                            userName.toCharArray());
                }
            }
        }
        catch (Exception e)
        {
            LOGER.error("Exception::" + e);
        }
    }

    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }


    private Set<String> getZones(final String zoneId)
    {
        Set<String> zones = new HashSet<String>(5);
        zones.add(AuthorityService.ZONE_APP_DEFAULT);
        zones.add(zoneId);
        return zones;
    }
}