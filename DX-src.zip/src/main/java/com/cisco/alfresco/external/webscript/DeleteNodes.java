package com.cisco.alfresco.external.webscript;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.alfresco.model.ContentModel;
import org.alfresco.query.PagingRequest;
import org.alfresco.query.PagingResults;
import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.CopyService.CopyInfo;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AuthenticationService;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;
import com.cisco.alfresco.edcsng.util.UserPermissionUtil;
import com.cisco.alfresco.ext.workflow.util.WFMailRootscopedObject;
import com.cisco.alfresco.external.common.util.UnPublishUtil;
import com.cisco.sd.rest.service.MigrationConstants;

public class DeleteNodes extends AbstractWebScript
{

	Logger LOGER;
	private ServiceRegistry serviceRegistry;
	private AuthenticationService authenticationService;
	private  String bannerAlfrescoUrl;
	private AuditComponent auditComponent;

	public DeleteNodes()
	{
		LOGER = Logger.getLogger(DeleteNodes.class);
	}

	public ServiceRegistry getServiceRegistry()
	{
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry)
	{
		this.serviceRegistry = serviceRegistry;
	}
	public AuthenticationService authenticationService() {
		return authenticationService;
	}
	public void setAuthenticationService(AuthenticationService authenticationService)
	{
		this.authenticationService = authenticationService;
	}


	public String getBannerAlfrescoUrl() {
		return bannerAlfrescoUrl;
	}

	public void setBannerAlfrescoUrl(String bannerAlfrescoUrl) {
		this.bannerAlfrescoUrl = bannerAlfrescoUrl;
	}

	public AuditComponent getAuditComponent() {
		return auditComponent;
	}

	public void setAuditComponent(AuditComponent auditComponent) {
		this.auditComponent = auditComponent;
	}

	@SuppressWarnings("unchecked")
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException
	{
		JSONObject responseJson = new JSONObject();
		try
		{

			boolean cancelunpublish = true;
			String action = "unpublish";
			Map<String, Serializable> unPublishAuditValues = null;
			final String currentLoginUserName=authenticationService.getCurrentUserName();
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObject = null;
			//JSONObject obj1 = new JSONObject();
			jsonObject = (JSONObject)jsonParser.parse(req.getParameter("jsonMetadata"));
			String externalNodeToDelete = (String)jsonObject.get("externalNodeToDelete");
			String docPublisher = (String)jsonObject.get("docPublisher");
			String typeOfAction = (String)jsonObject.get("typeOfAction");
			LOGER.info("Node to Delete is ="+externalNodeToDelete);
			NodeRef externalNodeReff = new NodeRef(externalNodeToDelete);
			boolean isNodeRefExisted = serviceRegistry.getNodeService().exists(externalNodeReff);
			LOGER.info("is NodeRef "+externalNodeToDelete+" existes :"+isNodeRefExisted);
			if(isNodeRefExisted){
				List<HashMap<String, String>> externalUsersList=UserPermissionUtil.getPermissions(externalNodeReff,serviceRegistry);
				responseJson.put("externalUsers",externalUsersList);
				LOGER.info("typeOfAction : " + typeOfAction + " ;externalUsersList : " + externalUsersList);

				if((typeOfAction!= null && !typeOfAction.isEmpty()) && (typeOfAction.equals("multiUnPublish"))){
					action = typeOfAction;
				}
				//start of code for cancel workflows on node while unpublish
				WFMailRootscopedObject mailRootscopedObject = new WFMailRootscopedObject(serviceRegistry);
				LOGER.info("action is :"+action + " ;current login user name : " +currentLoginUserName );
				mailRootscopedObject.cancelWFandSendMail(externalNodeToDelete, action ,currentLoginUserName,bannerAlfrescoUrl); 
				LOGER.info("send emial logic completed for the node Ref : " + externalNodeReff);
				//end of code for cancel workflows on node while unpublish
				if(serviceRegistry.getNodeService().hasAspect(externalNodeReff, ContentModel.ASPECT_CHECKED_OUT)){

					//start
					SimpleDateFormat dtformat=new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy"); //EEE MMM dd HH:mm:ss Z yyyy
					SimpleDateFormat formatneeded=new SimpleDateFormat("YYYY-MM-dd");
					String expiryDate = serviceRegistry.getNodeService().getProperty(externalNodeReff, MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP).toString();
					Date expirationdate = dtformat.parse(expiryDate);
					String expirydf =formatneeded.format(expirationdate);
					Date date = new Date();
					String currentdate = formatneeded.format(date);
					if(!expirydf.equalsIgnoreCase(currentdate)){
						cancelunpublish=false;
						LOGER.info("Document is Locked...can not unpublish the document...");
						responseJson.put("message","Document is locked can not unpublish the document.");

						LOGER.info("After writing Response....");

					}    else {
						cancelunpublish=true;
						NodeRef workingCopyId =(NodeRef)serviceRegistry.getCheckOutCheckInService().getWorkingCopy(externalNodeReff);
						LOGER.info("workingCopyId ::::::::::::::"+workingCopyId);
						serviceRegistry.getCheckOutCheckInService().cancelCheckout(workingCopyId);

						//serviceRegistry.getCheckOutCheckInService().cancelCheckout(externalNodeReff);
						LOGER.info("after cancel checkout the external noderef");

					}

					//end

				}
				if(cancelunpublish){
					LOGER.info("unpublish --> true");
					ChildAssociationRef childAssociationRef = serviceRegistry.getNodeService().getPrimaryParent(externalNodeReff);
					NodeRef parentNodeRef = childAssociationRef.getParentRef();
					String parentName = (String)serviceRegistry.getNodeService().getProperty(parentNodeRef, ContentModel.PROP_NAME);
					if(!parentName.equals("Templates"))
					{
						//added by mkatnam for unpublish audit info
						unPublishAuditValues = UnPublishUtil.extractUnpublishAuditInfo(externalNodeReff, serviceRegistry,docPublisher);
						LOGER.info("Auditing completed for the node Ref : " + externalNodeReff);
						try{
							//start US8623 UnPublish a copied files from Doc Central to multiple target folders in Doc Exchange
							//in case of republish of published copied documents
                        	PagingRequest pagingRequest = new PagingRequest(1000);
                   		 	PagingResults<CopyInfo> previousCopiesOfPublishNodePage = serviceRegistry.getCopyService().getCopies(externalNodeReff, pagingRequest);
                   		 	List<CopyInfo> pageResultsPublishedNodes = previousCopiesOfPublishNodePage.getPage();
                   		 if (!previousCopiesOfPublishNodePage.getPage().isEmpty() && previousCopiesOfPublishNodePage.getPage().size()>0)
                		 	{
                   			LOGER.info("Updated Found Copy of node: " +externalNodeReff +" in case of auto publish & republish");
                		 		for (CopyInfo copyInfo : pageResultsPublishedNodes)
                		 		{
                		 			//deleting copied documents from target folders
                		 			serviceRegistry.getNodeService().deleteNode(copyInfo.getNodeRef());
                		 			LOGER.info("Copy NodeDeleted successfully from the repository :: " + copyInfo.getNodeRef());
                		 		}
                		 	}
                   		 	//end of US8623 UnPublish a copied files from Doc Central to multiple target folders in Doc Exchange
							serviceRegistry.getNodeService().deleteNode(externalNodeReff);
							LOGER.info("NodeDeleted successfully from the repository : " + externalNodeToDelete);
							if(unPublishAuditValues != null && unPublishAuditValues.size() >0)
								auditComponent.recordAuditValues("/publish-report/document", unPublishAuditValues);
						} catch(Exception e){
							LOGER.error((e != null) ? "Delete Nodes Exception : " + e.getMessage(): "Exception occured in Doc Exchange while deleting..");
							responseJson.put("docExchangeExceptionMsg", (e != null) ? e.getMessage(): "Exception occured in Doc Exchange InvalidNodeRefException block");
							e.printStackTrace();
						}
						if(!serviceRegistry.getNodeService().exists(externalNodeReff)){
							LOGER.info("Node Deleted : " + externalNodeToDelete);
							responseJson.put("message","success");
						}

					}
				}
			} else {
				responseJson.put("message","success");
			}
			// build a JSON string and send it back
			//String jsonString = responseJson.toString();
			//res.getWriter().write(jsonString);
		}
		catch(InvalidNodeRefException e)
		{
			LOGER.error((e != null) ? e.getMessage(): "Exception occured in Doc Exchange InvalidNodeRefException block");
			responseJson.put("docExchangeExceptionMsg", (e != null) ? e.getMessage(): "Exception occured in Doc Exchange InvalidNodeRefException block");
		} catch (java.text.ParseException e) {
			LOGER.error((e != null) ? e.getMessage(): "Exception occured in Doc Exchange java.text.ParseException block");
			responseJson.put("docExchangeExceptionMsg", (e != null) ? e.getMessage(): "Exception occured in Doc Exchange java.text.ParseException block");
		} catch (ParseException e) {
			LOGER.error((e != null) ? e.getMessage(): "Exception occured in Doc Exchange ParseException block");
			responseJson.put("docExchangeExceptionMsg", (e != null) ? e.getMessage(): "Exception occured in Doc Exchange ParseException block");
		} catch (Exception e) {
			LOGER.error((e != null) ? e.getMessage(): "Exception occured in Doc Exchange Exception block");
			responseJson.put("docExchangeExceptionMsg", (e != null) ? e.getMessage(): "Exception occured in Doc Exchange Exception block");
		}
		LOGER.info("Final JSON  Message in delete Nodes is : " + responseJson.toJSONString());
		res.getWriter().write(responseJson.toString());

	}
}