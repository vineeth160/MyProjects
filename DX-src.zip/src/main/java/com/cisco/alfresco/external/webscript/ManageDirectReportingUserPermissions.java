package com.cisco.alfresco.external.webscript;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityService;
import org.alfresco.service.cmr.security.MutableAuthenticationService;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;

public class ManageDirectReportingUserPermissions extends DeclarativeWebScript
{
    private Logger LOGGER = Logger.getLogger(ManageDirectReportingUserPermissions.class);
    private static String zoneId = AuthorityService.ZONE_AUTH_EXT_PREFIX + "ldap";
    private ServiceRegistry serviceRegistry;
    private ExternalLDAPUtil ldapUtil;
    private NodeService nodeService;
    final static QName DOMAIN_QNAME = QName
    		.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name");
    @Override
    protected Map<String, Object> executeImpl(final WebScriptRequest req, Status status, Cache cache)
    {
    	 final Map<String, Object> model = new HashMap<String, Object>();
       try
       {
           Content reqContent = req.getContent();
           if (reqContent == null)
           {
               throw new WebScriptException(Status.STATUS_BAD_REQUEST, "Missing POST request body.");
           }
           JSONObject userPermissionsJson = new JSONObject(reqContent.getContent());
           NodeRef folderNodeRef = new NodeRef(userPermissionsJson.getString("nodeId"));
           String loggedinUserId = AuthenticationUtil.getFullyAuthenticatedUser();
           List<String> existingPermissionsUsersList = null;
           if(LOGGER.isDebugEnabled()){
           LOGGER.debug("ManageDirectReportingUserPermissions loggin User : " + loggedinUserId);
           }
           ArrayList<String> loggedInUserPermission = new ArrayList<String>();
           if (isUserInternal(loggedinUserId))
           {
               if (userPermissionsJson.has("users") && userPermissionsJson.getJSONArray("users").length() >= 0)
               {
            	   existingPermissionsUsersList = new ArrayList<String>();
                   PermissionService permissionService = serviceRegistry.getPermissionService();
                   Set<AccessPermission> accessPermissions = permissionService.getAllSetPermissions(folderNodeRef);
                   Iterator<AccessPermission> fIterator = accessPermissions.iterator();
                   AccessPermission accessPerm = null;
                   while (fIterator.hasNext())
                   {
                       accessPerm = fIterator.next();
                       existingPermissionsUsersList.add(accessPerm.getAuthority());
                       if (loggedinUserId.equalsIgnoreCase(accessPerm.getAuthority()))
                       {
                    	  existingPermissionsUsersList.remove(accessPerm.getAuthority());
                    	  if(LOGGER.isDebugEnabled()){
                       	  LOGGER.debug("ManageDirectReportingUserPermissions- login user ::"+accessPerm.getAuthority()+":: permission "+accessPerm.getPermission());
                    	  }
                       	  loggedInUserPermission.add(accessPerm.getPermission());
                       }
                   }
                   if (isPermissionChangeAllowed(loggedinUserId, loggedInUserPermission))
                   {
                	   JSONArray domainValidatedUsers=new JSONArray();
                	   domainValidatedUsers=userPermissionsJson.getJSONArray("users");
                	   //check domain validation and modify requested users
                	   if(LOGGER.isDebugEnabled()){
                        LOGGER.debug("Users List Befor domain validations ::: "+domainValidatedUsers.toString());
                	   }
                        for (int j = 0; j < domainValidatedUsers.length(); j++)
                        {
                    	if(!checkDomainValidation(domainValidatedUsers.getJSONObject(j).getString("userId"),folderNodeRef)){
                    		//((Map<String, Object>) users).remove(j);
                    		domainValidatedUsers = RemoveJSONArray(domainValidatedUsers,j);
                    	}
                        }
                        if(LOGGER.isDebugEnabled()){
                        LOGGER.debug("Users List After domain validations ::: "+domainValidatedUsers.toString());
                        }
                	   addUserPermissions(folderNodeRef, domainValidatedUsers,
                    		   existingPermissionsUsersList, loggedinUserId);
                       model.put("permissionMessage", "The permissions have been saved successfully");
                   }
                   else
                   {
                       model.put("permissionMessage", "You do not have authority to perform this operation.");
                   }
               }
               else
               {
                   model.put("permissionMessage", "Submitted Json is not in correct format.");
               }
           }
           else
           {
               model.put("permissionMessage", "You are not authorized ldap user to perform this operation.");
           }
       }
       catch (Exception e)
       {
           model.put(
                       "permissionMessage",
                       "The permissions have not been saved. Please try again");
           e.printStackTrace();
       }
       return model;
    }
    
    private List<String> addUserPermissions(final NodeRef folderNodeRef, final JSONArray users,
            final List<String> existingPermissionsUsersList, final String loggedinUserId)
            throws Exception
    {
        QName folderdoctype = serviceRegistry.getNodeService().getType(folderNodeRef);
        final String folderType = folderdoctype.toString().substring(43);
        final List<String> newUpdatedUsers = new ArrayList<String>();
        
        AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
        {
            @Override
            public Object doWork() throws Exception
            {
            	
                boolean userExistInRepo = false;
                if (users.length() == 0) {
                	if (folderType.equalsIgnoreCase("folder") )
                		serviceRegistry.getPermissionService().setPermission(folderNodeRef,loggedinUserId, "AdminRole", true);
                }
                for (int i = 0; i < users.length(); i++)
                {
                	
                	userExistInRepo = serviceRegistry.getPersonService().personExists(users.getJSONObject(i).getString("userId"));
                    if (!userExistInRepo)	
                    {
                        createLDAPUserInRepo(users.getJSONObject(i).getString("userId"));
                    }
                    // Removing ALL existing users & permissions except login user
                    if (!existingPermissionsUsersList.contains(users.getJSONObject(i).getString("userId")))
                    	newUpdatedUsers.add(users.getJSONObject(i).getString("userId"));
                    if (existingPermissionsUsersList.contains(users.getJSONObject(i).getString("userId")))
                        serviceRegistry.getPermissionService().clearPermission(folderNodeRef, users.getJSONObject(i).getString("userId"));
                    // Updating permissions for ALL existing users & permissions except login user
       if(!loggedinUserId.equalsIgnoreCase(users.getJSONObject(i).getString("userId"))){
                    if (users.getJSONObject(i).getString("permissionLevel").equalsIgnoreCase("Folder Admin") && folderType.equalsIgnoreCase("folder"))
                    {
                        serviceRegistry.getPermissionService().setPermission(folderNodeRef,
                            users.getJSONObject(i).getString("userId"), "AdminRole", true);
                    }
                    else
                    {
                        serviceRegistry.getPermissionService().setPermission(folderNodeRef,
                            users.getJSONObject(i).getString("userId"),
                            users.getJSONObject(i).getString("permissionLevel").concat("Role"), true);
                    }
       			  }
                }
                return null;
            }
        }, "admin");
        return newUpdatedUsers;
    }

    public boolean isPermissionChangeAllowed(String userId, ArrayList<String> permission)
    {
        LOGGER.info(new StringBuffer("Checking whether user can change the permision or not. User Id: ")
                .append(userId)
                    .append("Permission :")
                    .append(permission));
   if (permission != null
                && (permission.contains("OwnerRole") || permission.contains("AdminRole") || permission.contains("Folder Admin")))
            return true;
        else
            return false;
    }

    public boolean isUserInternal(String userid)
    {
        LOGGER.info((new StringBuilder("Start checking if internal LDAP users.. ")).append(userid).toString());
        return ldapUtil.isLdapUserInternal((new StringBuilder(String.valueOf(userid))).toString());
    }
   
    public void createLDAPUserInRepo(String userid)
    {
        LOGGER.info("Start creating LDAP users in repository.. " + userid);
        final Set<String> zoneSet = getZones(zoneId);
        String idAndName = ldapUtil.getUserDetailsFromLDAP(userid);
        //idAndName =nathammi::Nagaraju Thammisetty::Cisco Systems, Inc.
        if(LOGGER.isDebugEnabled()){
        LOGGER.debug("ManageDirectReportingUserPermissions idAndName :: " + idAndName);
        }
        final String userName = (idAndName.split("::"))[0];
        String name = (idAndName.split("::"))[1];
        String organization = (idAndName.split("::"))[2];
        String firstName = "", lastName = "";
        if (name.contains(" "))
        {
            firstName = (name.split(" "))[0];
            lastName = (name.split(" "))[1];
        }
        else
            firstName = name;
        String email = (idAndName.split("::"))[3];
        final HashMap<QName, Serializable> properties = new HashMap<QName, Serializable>();
        properties.put(ContentModel.PROP_USERNAME, userName);
        properties.put(ContentModel.PROP_FIRSTNAME, firstName);
        properties.put(ContentModel.PROP_LASTNAME, lastName);
        properties.put(ContentModel.PROP_EMAIL, email);
        properties.put(ContentModel.PROP_ORGANIZATION, organization);
        try
        {
            NodeRef newPerson = serviceRegistry.getPersonService().createPerson(properties, zoneSet);
            LOGGER.info("newPerson =" + newPerson);
            MutableAuthenticationService authService = serviceRegistry.getAuthenticationService();
            authService.createAuthentication(userName, userName.toCharArray());
            authService.setAuthenticationEnabled(userName, true);
        }
        catch (Exception e)
        {
            LOGGER.error("Exception at creating person:: " + e);
            e.printStackTrace();
        }
    }

    public boolean checkDomainValidation(String userId,NodeRef folderNodeRef){
    	String strManagerID = null;
    	boolean checkDomainStatus=false; 
    	final String delimiter = "@";
    	String checkDomainInfo = null;
    	final QName type = nodeService.getType(folderNodeRef);
    	strManagerID = ldapUtil.getManagerEmailFromLDAP(userId);
		String domainName = null;
		if (type.equals(ContentModel.TYPE_FOLDER)) {
			domainName = (String) nodeService.getProperty(folderNodeRef,DOMAIN_QNAME);
			domainName="cisco.com,"+domainName;
			//LOGGER.info("domainName:::::"+domainName);
			String[] domainLabel;
			if (domainName != null && !domainName.equalsIgnoreCase("")) {
			   if (strManagerID != null && strManagerID.length() > 0) {
				   domainLabel = strManagerID.split(delimiter);
						String emailId = domainLabel[1];
						if (domainName.toLowerCase().replaceAll(" ", "").contains(emailId)) {
							checkDomainStatus=true;
							checkDomainInfo="Email and Domain name are same";
							//LOGGER.info("Email and Domain name are same");
						} else {
							checkDomainStatus=false;
							}
				} else {
					checkDomainInfo="EMail was not registered for user";
				}
			} else {
				//allow all domains if domain property value is null
				checkDomainStatus=true;
				checkDomainInfo="Domain Name is Null";
				//LOGGER.info("Domain Name is Null");
			}
		}else{
			checkDomainStatus=true;
		}
		 if(LOGGER.isDebugEnabled()){
		LOGGER.debug("check domain info :  "+checkDomainInfo);
		LOGGER.debug("check domain status for "+userId+" is : "+checkDomainStatus);
		 }
		return checkDomainStatus;
    }
   
    public static JSONArray RemoveJSONArray( JSONArray users,int position) {
    	JSONArray validUsers=new JSONArray();
    	try{
    	for(int i=0;i<users.length();i++){     
    	    if(i!=position)
    	    	validUsers.put(users.get(i));     
    	}
    	}catch (Exception e){e.printStackTrace();}

    	return validUsers;
    	}
    
    
    public ExternalLDAPUtil getLdapUtil()
    {
        return ldapUtil;
    }

    public void setLdapUtil(ExternalLDAPUtil ldapUtil)
    {
        this.ldapUtil = ldapUtil;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    public NodeService getNodeService()
    {
        return nodeService;
    }

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }
    private Set<String> getZones(final String zoneId)
    {
        Set<String> zones = new HashSet<String>(5);
        zones.add(AuthorityService.ZONE_APP_DEFAULT);
        zones.add(zoneId);
        return zones;
    }
}
