package com.cisco.alfresco.external.jobs;

import java.util.Date;

public class UserStatusEntry {

	private String userId;
	private String emailAddress;
	private String userStatus;
	private String emailNotificationStatus;
	private Date dbInsertionDate;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public String getEmailNotificationStatus() {
		return emailNotificationStatus;
	}

	public void setEmailNotificationStatus(String emailNotificationStatus) {
		this.emailNotificationStatus = emailNotificationStatus;
	}

	public Date getDbInsertionDate() {
		return dbInsertionDate;
	}

	public void setDbInsertionDate(Date dbInsertionDate) {
		this.dbInsertionDate = dbInsertionDate;
	}

}
