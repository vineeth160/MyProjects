package com.cisco.alfresco.external.webscript;

import java.io.Serializable;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.error.AlfrescoRuntimeException;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.InvalidQNameException;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.external.common.util.ExternalSharingConstants;


/**
 * This webscript is used to update the user policy status
 * 
 * @author rajbaska
 * 
 */

public class UpdateUserPolicyWebScript extends DeclarativeWebScript
{
    private static final Logger logger = Logger.getLogger(UpdateUserPolicyWebScript.class);

    private ServiceRegistry serviceRegistry;

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    @Override
    public Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
    {
        logger.info("Calling UpdateUserPolicyWebScript...");
        final Map<String, Object> model = new HashMap<String, Object>();

        try
        {
            // Phani JSON parsing start
            Content content = req.getContent();
            String postContentString = content.getContent();
            JSONObject jsonObject = new JSONObject(postContentString);
            final String ispolicyAccepted = jsonObject.get("policydetails").toString();

            // Phani JSON parsing end

            AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
            {
                @Override
                public Object doWork() throws Exception
                {
                    String currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
                    boolean isUserAcceptedPolicy = false;
                    logger.info("current user : " + currentUser);
                    NodeRef personNode = serviceRegistry.getPersonService().getPerson(currentUser);
                    if (personNode != null)
                    {
                        isUserAcceptedPolicy = updatePolicyInfo(currentUser, ispolicyAccepted);
                    }
                    else
                    {
                        logger.info("Person node is not available");
                    }

                    ObjectMapper mapper = new ObjectMapper();
                    Writer strWriter = new StringWriter();
                    mapper.writeValue(strWriter, isUserAcceptedPolicy);
                    // mapper.writeValue(strWriter, userInfo);
                    String jsonString = strWriter.toString();
                    logger.info("Result JSON  for  updated UserInfo: " + jsonString);
                    model.put("result", jsonString);
                    return null;
                }
            }, "admin");
        }
        catch (AlfrescoRuntimeException e)
        {
            logger.error("Exception occured:" + e.getMessage());
        }
        catch (JSONException e)
        {
            logger.error("JSONException: Could not read arguments from request");
        }
        catch (Exception e)
        {
            logger.error("Exception : " + e);
            e.printStackTrace();
        }

        return model;
    }

    private boolean updatePolicyInfo(String currentUser, String ispolicyAccepted)
    {
        boolean PolicyUpdated = false;
        try
        {
            NodeRef personNode = serviceRegistry.getPersonService().getPerson(currentUser);
            logger.info("PersonNode:" + personNode.toString());
            if (personNode != null)
            {
                Map<QName, Serializable> exPersonProps = new HashMap<QName, Serializable>();
                boolean propvalue = ispolicyAccepted.trim().length() > 0 ? Boolean.valueOf(ispolicyAccepted.trim())
                        : false;
                exPersonProps.put(ExternalSharingConstants.PROP_EXT_POLICY_ACCEPTED, Boolean.valueOf(propvalue));
                serviceRegistry.getNodeService().addAspect(personNode,
                    ExternalSharingConstants.EXT_POLICY_DETAILS_ASPECT, exPersonProps);
                logger.info("Policy details added successfully...");
                PolicyUpdated = true;
            }

        }
        catch (InvalidQNameException e)
        {
            e.printStackTrace();
        }
        catch (InvalidNodeRefException e)
        {
            e.printStackTrace();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return PolicyUpdated;
    }

}
