package com.cisco.alfresco.external.jobs;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.ldap.PagedResultsControl;
import javax.naming.ldap.PagedResultsResponseControl;
import org.alfresco.repo.lock.JobLockService;
import org.alfresco.repo.lock.JobLockService.JobLockRefreshCallback;
import org.alfresco.repo.lock.LockAcquisitionException;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.TemplateService;
import org.alfresco.service.cmr.security.AuthorityService;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.transaction.TransactionService;
import org.alfresco.util.VmShutdownListener.VmShutdownException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;
import com.cisco.alfresco.auth.ext.EXTEncrypter;
import com.cisco.alfresco.edcsng.util.MailUtil;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;

public class SyncMailerGroupJob extends QuartzJobBean {

	private static Log logger = LogFactory.getLog(SyncMailerGroupJob.class);
	public static final int MAX_QUERY_SIZE = 1500;
	private static final QName LOCK_QNAME = QName.createQName(NamespaceService.SYSTEM_MODEL_1_0_URI,
			"SyncMailerGroupJob");
	private static final long LOCK_TTL = 30000L;

	// ldap server constants
	public static final String INITCTX = "com.sun.jndi.ldap.LdapCtxFactory";
	private static String LDAP_AUTHENTICATION_SIMPLE = "simple";
	public static final int LDAP_PAGE_SIZE = 1000;
	// Query constants
	public static final String MAILER_SEARCH_DIFF = "(&(objectclass=group)(!(whenChanged<={0})))";
	public static final String MAILER_SEARCH_QUERY = "(objectClass=group)";
	public static String JOBTRACKER_STATUS_NOTIFICATION_TEMPLATE = "/alfresco/extension/templates/email/jobTrackerFailNotification.ftl";
	public static final String LDAP_TIMESTAMP_FORMAT = "yyyyMMddHHmmss'.0Z'";
	private static final String KEY_IS_MAILER_SYNC_JOB_ENABLED = "MailerSyncJobEnabled";
	private static final String GROUP_IDENTITY = "GROUP_";
	private static final String CISCO_MAILID = "@cisco.com";

	private AuthorityService authorityService = null;
	private JobLockService jobLockService = null;
	private TransactionService transactionService = null;
	private String mailerToSync = null;
	private boolean fullSync = false;
	private int lastModifiedHours = 24;

	private int ilCount = 0;
	private ExternalLDAPUtil ldapUtil = null;
	private String mailerGroupsLdapHost;// ="ldap://ds.cisco.com:389";
	private String mailerGroupsGenericUser;
	private String mailerGroupsGenericPwd;
	private String mailerGroupsGenericKey;
	private String mailerGroupsLdapSearchBase;
	String status = "";
	private String mailerFromID;
	private String bannerAlfrescoUrl;
	private String mailServer;
	private String mailerToID;

	

	public String getMailerToID() {
		return mailerToID;
	}

	public void setMailerToID(String mailerToID) {
		this.mailerToID = mailerToID;
	}

	public String getMailerFromID() {
		return mailerFromID;
	}

	public void setMailerFromID(String mailerFromID) {
		this.mailerFromID = mailerFromID;
	}

	public String getBannerAlfrescoUrl() {
		return bannerAlfrescoUrl;
	}

	public void setBannerAlfrescoUrl(String bannerAlfrescoUrl) {
		this.bannerAlfrescoUrl = bannerAlfrescoUrl;
	}

	public String getMailServer() {
		return mailServer;
	}

	public void setMailServer(String mailServer) {
		this.mailServer = mailServer;
	}

	/**
	 * @return the localFactory
	 */
	public SessionFactory getLocalFactory() {
		return localFactory;
	}

	/**
	 * @param localFactory
	 *            the localFactory to set
	 */
	public void setLocalFactory(SessionFactory localFactory) {
		this.localFactory = localFactory;
	}

	private ServiceRegistry serviceRegistry;
	private SessionFactory localFactory;

	public SyncMailerGroupJob() {

	}

	public AuthorityService getAuthorityService() {
		return authorityService;
	}

	public void setAuthorityService(AuthorityService authorityService) {
		this.authorityService = authorityService;
	}

	public JobLockService getJobLockService() {
		return jobLockService;
	}

	public void setJobLockService(JobLockService jobLockService) {
		this.jobLockService = jobLockService;
	}

	public TransactionService getTransactionService() {
		return transactionService;
	}

	public void setTransactionService(TransactionService transactionService) {
		this.transactionService = transactionService;
	}

	public boolean isFullSync() {
		return fullSync;
	}

	public void setFullSync(boolean fullSync) {
		this.fullSync = fullSync;
	}

	public int getLastModifiedHours() {
		return lastModifiedHours;
	}

	public void setLastModifiedHours(int lastModifiedHours) {
		this.lastModifiedHours = lastModifiedHours;
	}

	public String getMailerToSync() {
		return mailerToSync;
	}

	public void setMailerToSync(String mailerToSync) {
		this.mailerToSync = mailerToSync;
	}

	public ExternalLDAPUtil getLdapUtil() {
		return ldapUtil;
	}

	public void setLdapUtil(ExternalLDAPUtil ldapUtil) {
		this.ldapUtil = ldapUtil;
	}

	public String getMailerGroupsLdapHost() {
		return mailerGroupsLdapHost;
	}

	public void setMailerGroupsLdapHost(String mailerGroupsLdapHost) {
		this.mailerGroupsLdapHost = mailerGroupsLdapHost;
	}

	public String getMailerGroupsGenericUser() {
		return mailerGroupsGenericUser;
	}

	public void setMailerGroupsGenericUser(String mailerGroupsGenericUser) {
		this.mailerGroupsGenericUser = mailerGroupsGenericUser;
	}

	public String getMailerGroupsGenericPwd() {
		return mailerGroupsGenericPwd;
	}

	public void setMailerGroupsGenericPwd(String mailerGroupsGenericPwd) {
		this.mailerGroupsGenericPwd = mailerGroupsGenericPwd;
	}

	public String getMailerGroupsGenericKey() {
		return mailerGroupsGenericKey;
	}

	public void setMailerGroupsGenericKey(String mailerGroupsGenericKey) {
		this.mailerGroupsGenericKey = mailerGroupsGenericKey;
	}

	public String getMailerGroupsLdapSearchBase() {
		return mailerGroupsLdapSearchBase;
	}

	public void setMailerGroupsLdapSearchBase(String mailerGroupsLdapSearchBase) {
		this.mailerGroupsLdapSearchBase = mailerGroupsLdapSearchBase;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	@Override
	protected void executeInternal(JobExecutionContext jobContext) throws JobExecutionException {
		String jobName = "SyncMailerGroupJob";
		String endDate = "";
		String startDate = "";
		String getUnixBoxName = "";
		// String status ="";

		boolean isJobEnabled = false;
		JobDataMap jobData = jobContext.getJobDetail().getJobDataMap();
		String isJobEnabledStr = (String) jobData.get(KEY_IS_MAILER_SYNC_JOB_ENABLED);
		if (isJobEnabledStr != null) {
			try {
				isJobEnabled = new Boolean(isJobEnabledStr);
			} catch (Exception e) {
				logger.info("Invalid '" + KEY_IS_MAILER_SYNC_JOB_ENABLED + "' value, using default: " + isJobEnabled,
						e);
			}
		}
		if (!isJobEnabled) {
			// skip Job
			logger.info("Skipping " + KEY_IS_MAILER_SYNC_JOB_ENABLED + " to execute.");
			return;
		}
		getUnixBoxName = getUnixBoxName();
		logger.info("UnixBoxName==" + getUnixBoxName + "jobName==" + jobName + "JobStatus====");
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		startDate = dtf.format(now);
		logger.info("startDate" + startDate);

		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				syncMailerGroups();

				return null;
			}
		}, "admin");
		// updateDB(getUnixBoxName,jobName,startDate,endDate, status);
		// Bypass if the system is in read-only mode
		if (transactionService.isReadOnly()) {

			logger.info("Mailer sync job is bypassed; the system is read-only.");
			return;
		}

		LockCallback lockCallback = new LockCallback();
		String lockToken = null;
		try {
			logger.info("Mailer sync job is started.");
			lockToken = acquireLock(lockCallback);

			logger.info("Mailer sync job is started.");

			if (logger.isDebugEnabled()) {

			}

			lockToken = acquireLock(lockCallback);

			// Run the job
			AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				@Override
				public Object doWork() throws Exception {
					syncMailerGroups();

					return null;
				}
			}, "admin");

			if (logger.isDebugEnabled()) {
				logger.info("Mailer sync job is completed.");
			}

		} catch (LockAcquisitionException e) {
			// Job being done by another process
			if (logger.isDebugEnabled()) {

				logger.info("Mailer sync job is already underway.");
			}
		} catch (VmShutdownException e) {
			// Aborted
			if (logger.isDebugEnabled()) {
				status = "Failed";
				logger.info("Mailer sync job is aborted.");
			}
		} catch (Exception e) {
			logger.info("Error occured" + e.getMessage());
			status = "Failed";
		}

		finally {
			releaseLock(lockCallback, lockToken);

		}
		if (status.isEmpty() && status != null && (!status.equals("Failed") && "".equals(status))) {
			status = "success";
		}
		logger.info("After finally block");
		DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now2 = LocalDateTime.now();
		endDate = dtf2.format(now2);
		logger.info("endDate" + endDate);

		logger.info(jobName + "@@@" + "@@@" + startDate + "@@@" + endDate + "@@@" + status + "@@@@@" + getUnixBoxName);

		updateDB(getUnixBoxName, jobName, startDate, endDate, status);
		/*
		 * if (status != null && !status.isEmpty() && status.equals("Failed")) {
		 * sendEMail(getUnixBoxName, strManagerID, jobName, status); }
		 */

		if (!status.isEmpty() && status != null && status.equals("Failed")) {
			sendEMail(getUnixBoxName, mailerToID, jobName, status);
		}

	}

	/**
	 * this is the entry point for job to start the sync process
	 * 
	 * 
	 */

	private void syncMailerGroups() throws Exception {
		try {
			logger.info("Mailer sync process started. ");
			logger.info("mailerToSync : " + getMailerToSync());
			logger.info("fullSync : " + isFullSync());
			logger.info("lastModifiedHours : " + getLastModifiedHours());
			logger.info("Ldap Search base :: " + getMailerGroupsLdapSearchBase());

			LdapContext ctx = getLdapContext();
			String slSearchFilter = null;
			ilCount = 0;

			if (logger.isDebugEnabled()) {
				logger.debug("LdapContext :::::::: " + ctx);
			}
			if (getMailerToSync() != null && !getMailerToSync().isEmpty() && getMailerToSync() != "") {
				slSearchFilter = "cn=" + getMailerToSync();
				logger.info("Retriving only '" + getMailerToSync() + "' mailer group to sync.");

			} else {

				if (fullSync) {
					slSearchFilter = MAILER_SEARCH_QUERY;
					logger.info("Retriving all the mailer groups to sync.");

				} else {

					SimpleDateFormat timestampFormat = new SimpleDateFormat(LDAP_TIMESTAMP_FORMAT, Locale.UK);
					timestampFormat.setTimeZone(TimeZone.getTimeZone("GMT"));

					Calendar cal = Calendar.getInstance(); // creates calendar
					cal.setTime(new Date()); // sets calendar time/date
					cal.add(Calendar.HOUR_OF_DAY, lastModifiedHours * -1); // subtract that many hours

					String lastModified = timestampFormat.format(cal.getTime());

					slSearchFilter = MAILER_SEARCH_DIFF.replace("{0}", lastModified);

					logger.info(
							"Retriving all the mailer groups that are modified after '" + cal.getTime() + "' to sync");

				}

			}

			logger.info("Search Filter : " + slSearchFilter);

			// getting the list of mailer groups to sync
			Map<String, Set<String>> members = getEligibleGroups(ctx, slSearchFilter);
			if (logger.isDebugEnabled()) {
				logger.debug("Searched members ::::::: " + members.toString());
			}
			// Sync found groups
			syncMailerGroup(members, authorityService);
			logger.info("Successfully updaed groups with members in repository");
			try {
				ctx.close();
			} catch (Exception ignored) {

			}

			logger.info("Total " + ilCount + " groups processed. Found " + members.size()
					+ " groups to sync. Sync Completed.");
		} catch (Exception e) {
			logger.info("Error occured in sync mail job" + e.getMessage());
			status = "Failed";
		}

	}

	/**
	 * get the list of users to sync
	 * 
	 * @param ctx
	 * @param authorityService
	 * @param searchFilter
	 * @return
	 */

	private Map<String, Set<String>> getEligibleGroups(LdapContext ctx, String searchFilter) throws Exception {

		Map<String, Set<String>> ret = new HashMap<String, Set<String>>();

		// Paging
		byte[] cookie = null;
		int total = 0;

		String slCN = null;
		String slMailerGroup = null;

		try {

			SearchControls ctrl = new SearchControls();
			ctrl.setSearchScope(SearchControls.SUBTREE_SCOPE);

			ctx.setRequestControls(new Control[] { new PagedResultsControl(LDAP_PAGE_SIZE, Control.NONCRITICAL) });

			String[] attrIDs = { "distinguishedName", "description", "displayName", "cn", "member" };

			ctrl.setReturningAttributes(attrIDs);

			do {
				NamingEnumeration<SearchResult> results = ctx.search(getMailerGroupsLdapSearchBase(), searchFilter,
						ctrl);
				/* here is the block we gett all the mailers name */
				while (results != null && results.hasMore()) {
					ilCount++;
					SearchResult entry = (SearchResult) results.next();
					Attributes attrs = entry.getAttributes();
					slCN = attrs.get("cn").get().toString();
					slMailerGroup = GROUP_IDENTITY + slCN;
					Set<String> membersList = new HashSet<String>();
					if (authorityService.authorityExists(slMailerGroup)) {
						logger.info("Found matching Mailer DN : " + slMailerGroup);
						logger.info("slMailerGroup Name: " + slMailerGroup);
						try {
							buildMembersList(slCN, ctx, membersList, attrs, 0, MAX_QUERY_SIZE - 1, true);
						} catch (Exception e) {
							logger.error("Error while getting members for " + slCN + " group", e);
						}
						ret.put(slCN, membersList);
					}
				}

				// Examine the paged results control response
				Control[] controls = ctx.getResponseControls();
				if (controls != null) {
					for (int i = 0; i < controls.length; i++) {
						if (controls[i] instanceof PagedResultsResponseControl) {
							PagedResultsResponseControl prrc = (PagedResultsResponseControl) controls[i];
							total = prrc.getResultSize();
							if (total != 0) {
								logger.info("***************** END-OF-PAGE " + "(total : " + total
										+ ") *****************\n");
							} else {
								logger.info("** Group does not exist in the system to syn ** \n");
							}
							cookie = prrc.getCookie();
						}
					}

				} else {
					logger.info("No controls were sent from the server");
				}

				// Re-activate paged results
				ctx.setRequestControls(
						new Control[] { new PagedResultsControl(LDAP_PAGE_SIZE, cookie, Control.CRITICAL) });

			} while (cookie != null);

		} catch (Exception de) {
			logger.error("Error while getting list of mailer group to sync", de);
			status = "Failed";
		}

		logger.info("result object is :::::::" + ret.toString());

		return ret;
	}

	/**
	 * 
	 * @param groupIdToSync
	 * @param ctx
	 */

	private void syncMailerGroup(Map<String, Set<String>> members, AuthorityService authorityService) {
		logger.info("::: Synch Users of group in repository :::::");
		String slMailerGroup = null;
		Set<String> existingUsers = null;
		Set<String> newUsers = null;
		Set<String> deletionUsers = null;
		Set<String> additionUsers = null;
		if (members != null && members.size() != 0) {
			// Process through the entries
			for (Entry<String, Set<String>> curGroup : members.entrySet()) {
				String slGroupName = curGroup.getKey();
				logger.info("Group Name : " + slGroupName);
				slMailerGroup = GROUP_IDENTITY + slGroupName;
				existingUsers = authorityService.getContainedAuthorities(AuthorityType.USER, slMailerGroup, false);
				newUsers = curGroup.getValue();
				if (logger.isDebugEnabled()) {
					logger.debug("Users of group in repository : " + existingUsers);
					logger.debug("Users of group in LDAP : " + newUsers);
				}
				if (existingUsers.equals(newUsers)) {
					logger.info("No new users found in this group : " + slGroupName);
				} else {

					// make a copy first
					deletionUsers = new HashSet<String>(existingUsers);
					additionUsers = new HashSet<String>(newUsers);
					deletionUsers.removeAll(newUsers);
					additionUsers.removeAll(existingUsers);
					if (logger.isDebugEnabled()) {
						logger.debug("The users to be deleted : " + deletionUsers);
						logger.debug("The new uesers to be added : " + additionUsers);
					}
					// Removing users that are not there
					if (deletionUsers.size() > 0) {
						for (String childName : deletionUsers) {
							authorityService.removeAuthority(slMailerGroup, childName);
							logger.info("User '" + childName + "' is deleted from mailer '" + slMailerGroup + "'");
						}

					}

					// Adding useres that are found in this updated one
					if (additionUsers.size() > 0) {
						for (String childName : additionUsers) {
							String userEmail = ldapUtil.getManagerEmailFromLDAP(childName);
							logger.info("user email address::" + userEmail);
							if (userEmail != null && userEmail != "") {
								boolean isCiscoDomainUser = userEmail.contains(CISCO_MAILID);
								logger.info("is user exists in cisco::" + isCiscoDomainUser);
								// Adding only cisco domain users to Groups
								if (isCiscoDomainUser
										&& serviceRegistry.getPersonService().getPerson(childName) != null) {
									authorityService.addAuthority(slMailerGroup, childName);
									logger.info("User '" + childName + "' is added to mailer '" + slMailerGroup + "'");
								} else {
									logger.info("User is not a cisco domain user/not avilable in repository '"
											+ childName + "' is not added to mailer '" + slMailerGroup + "'");
								}
							} else {
								logger.info("Couldn't add inactive user authority to group: " + childName);
							}
						}
					}
					logger.info("Current Users in the repository : "
							+ authorityService.getContainedAuthorities(AuthorityType.USER, slMailerGroup, false));
				}
			}

		} else {
			logger.info("Group does not exist in the system to syn :" + slMailerGroup);
		}
	}

	/**
	 * A method to search LDAP for groups; returns a group to members mapping.
	 * 
	 * @param cn
	 *            - the CN of the group(s) to look for.
	 * @param ctx
	 *            - an LdapContext to use to perform the search
	 * @return a Map - the key is the displayName of the group found. the value is
	 *         the list of members' names
	 */

	protected Map<String, Set<String>> getGroupMembers(AuthorityService authorityService, String searchFilter,
			LdapContext ctx) {

		Map<String, Set<String>> ret = null;
		String slMailerGroup = null;

		try {

			SearchControls ctrl = new SearchControls();
			ctrl.setSearchScope(SearchControls.SUBTREE_SCOPE);

			String[] attrIDs = { "distinguishedName", "description", "displayName", "cn" };
			ctrl.setReturningAttributes(attrIDs);
			NamingEnumeration<SearchResult> answer = ctx.search(getMailerGroupsLdapSearchBase(), searchFilter, ctrl);
			ret = new HashMap<String, Set<String>>();
			while (answer.hasMore()) {

				ilCount++;

				SearchResult entry = (SearchResult) answer.next();

				Attributes attrs = entry.getAttributes();
				if (logger.isDebugEnabled()) {
					logger.debug("Attrs : " + attrs.toString());
				}
				String cn = attrs.get("cn").toString(); // this is coming like cn: cdxqa3
				cn = cn.substring(4);

				logger.info("CN Name: " + cn);

				Set<String> membersList = new HashSet<String>();

				slMailerGroup = GROUP_IDENTITY + cn;
				logger.info("Mailer Group : " + slMailerGroup);

				if (authorityService.authorityExists(slMailerGroup)) {

					logger.info("Found matching Mailer DN : " + slMailerGroup);

					buildMembersList(cn, ctx, membersList, attrs, 0, MAX_QUERY_SIZE - 1, true);

					ret.put(cn, membersList);
				}
			}

		} catch (NamingException ne) {
			logger.error("error while getting mailer group", ne);
		} catch (Exception e) {
			logger.error("error while getting mailer group", e);
		}

		return ret;
	}

	/**
	 * Builds a list of members. If short circuiting the members search is desired,
	 * please specify
	 * 
	 * @param cn
	 * @param ctx
	 * @param membersList
	 * @param attrs
	 * @param min
	 * @param max
	 *            - range definition; can equal -1, meaning we pass min-* for the
	 *            range and stop querying after
	 * @param shortCircuitLargeList
	 * @throws NamingException
	 */
	protected void buildMembersList(String cn, LdapContext ctx, Set<String> membersList, Attributes attrs, int min,
			int max, boolean shortCircuitLargeList) throws NamingException {

		Attribute members = attrs.get("member");
		Attribute membersPlus = attrs.get("member;range=" + min + "-" + (max == -1 ? "*" : max));
		String thisCN = attrs.get("cn").get().toString();

		if (members == null && membersPlus == null && max != -1) {

			// Do one more query to ensure we pick up the last guys in the list.
			SearchControls trimCtrl = new SearchControls();

			String[] trimAttrIDs = { "cn", "member", "member;range=" + min + "-*" };

			trimCtrl.setSearchScope(SearchControls.SUBTREE_SCOPE);
			trimCtrl.setReturningAttributes(trimAttrIDs);

			NamingEnumeration<SearchResult> answer = ctx.search(getMailerGroupsLdapSearchBase(), "cn=" + thisCN,
					trimCtrl);

			buildMembersList(cn, ctx, membersList, answer.next().getAttributes(), min, -1, shortCircuitLargeList);

		} else if (members != null && members.size() > 0) {

			for (int i = 0; i < members.size(); i++) {
				String member = members.get(i).toString();
				if (member.contains("OU=Employees,")) {
					int CNidx = member.indexOf("CN=");
					String username = member.substring(CNidx + 3, member.indexOf(",", CNidx));
					membersList.add(username);
					logger.info("User Name " + username);
				}
			}

		} else if (membersPlus != null && membersPlus.size() > 0) {

			for (int i = 0; i < membersPlus.size(); i++) {
				String member = membersPlus.get(i).toString();
				if (member.contains("OU=Employees")) {
					int CNidx = member.indexOf("CN=");
					String username = member.substring(CNidx + 3, member.indexOf(",", CNidx));
					membersList.add(username);
					logger.info("User Name " + username);
				}
			}

			if (max != -1) {
				min = max + 1;
				max += MAX_QUERY_SIZE;

				SearchControls trimCtrl = new SearchControls();

				String[] trimAttrIDs = { "cn", "member", "member;range=" + min + "-" + max };

				trimCtrl.setSearchScope(SearchControls.SUBTREE_SCOPE);
				trimCtrl.setReturningAttributes(trimAttrIDs);

				NamingEnumeration<SearchResult> answer = ctx.search(getMailerGroupsLdapSearchBase(), "cn=" + thisCN,
						trimCtrl);

				buildMembersList(cn, ctx, membersList, answer.next().getAttributes(), min, max, shortCircuitLargeList);
			}

		} else if (min == 0) {

			SearchControls trimCtrl = new SearchControls();

			String[] trimAttrIDs = { "cn", "member;range=" + min + "-" + max };

			trimCtrl.setSearchScope(SearchControls.SUBTREE_SCOPE);
			trimCtrl.setReturningAttributes(trimAttrIDs);

			NamingEnumeration<SearchResult> answer = ctx.search(getMailerGroupsLdapSearchBase(), "cn=" + thisCN,
					trimCtrl);

			attrs = answer.next().getAttributes();

			if (attrs.get("member;range=" + min + "-" + max) != null) {
				if (!shortCircuitLargeList)
					buildMembersList(cn, ctx, membersList, attrs, min, max, shortCircuitLargeList);
				else {
					membersList.clear();
					membersList.add("This member list is very large; please view in Grouper.");
				}
			}
		}
	}

	/**
	 * getting LDAP Context
	 * 
	 * @return
	 */

	@SuppressWarnings("unchecked")
	private LdapContext getLdapContext() {

		LdapContext ctx = null;
		try {
			logger.info("Ldap Host :: " + getMailerGroupsLdapHost());
			logger.info("Ldap User :: " + getMailerGroupsGenericUser());
			logger.info("Ldap Password :: "
					+ EXTEncrypter.decrypt(getMailerGroupsGenericPwd(), getMailerGroupsGenericKey()).getBytes("UTF8"));
			Hashtable env = new Hashtable<String, String>();
			env.put(LdapContext.CONTROL_FACTORIES, "com.sun.jndi.ldap.ControlFactory");
			env.put(Context.INITIAL_CONTEXT_FACTORY, INITCTX);
			env.put(Context.PROVIDER_URL, getMailerGroupsLdapHost());
			env.put(Context.SECURITY_AUTHENTICATION, LDAP_AUTHENTICATION_SIMPLE);
			env.put(Context.SECURITY_PRINCIPAL, getMailerGroupsGenericUser());
			env.put(Context.SECURITY_CREDENTIALS,
					EXTEncrypter.decrypt(getMailerGroupsGenericPwd(), getMailerGroupsGenericKey()).getBytes("UTF8"));
			ctx = new InitialLdapContext(env, null);
		} catch (NamingException nex) {
			logger.fatal("Fatal error initializing LDAP context.", nex);
			nex.printStackTrace();
		} catch (Exception e) {
			logger.fatal("Fatal error initializing LDAP context.", e);
			e.printStackTrace();
		}
		logger.info("Ldap ctx :: " + ctx);
		return ctx;
	}

	/**
	 * Acquire the job lock
	 * 
	 * @param lockCallback
	 * @return
	 */

	private String acquireLock(JobLockRefreshCallback lockCallback) {
		// Get lock
		String lockToken = jobLockService.getLock(LOCK_QNAME, LOCK_TTL);

		// Register the refresh callback which will keep the lock alive
		jobLockService.refreshLock(lockToken, LOCK_QNAME, LOCK_TTL, lockCallback);

		if (logger.isDebugEnabled()) {
			logger.info("lock acquired: " + LOCK_QNAME + ": " + lockToken);
		}

		return lockToken;
	}

	/**
	 * Release the lock after the job completes
	 * 
	 * @param lockCallback
	 * @param lockToken
	 */

	private void releaseLock(LockCallback lockCallback, String lockToken) {
		if (lockCallback != null) {
			lockCallback.running.set(false);
		}

		if (lockToken != null) {
			jobLockService.releaseLock(lockToken, LOCK_QNAME);
			if (logger.isDebugEnabled()) {
				logger.info("Lock released: " + LOCK_QNAME + ": " + lockToken);
			}
		}
	}

	/**
	 * JobLockCallback
	 *
	 */

	private class LockCallback implements JobLockRefreshCallback {
		final AtomicBoolean running = new AtomicBoolean(true);

		@Override
		public boolean isActive() {
			return running.get();
		}

		@Override
		public void lockReleased() {
			running.set(false);
			if (logger.isDebugEnabled()) {
				logger.info("Lock release notification: " + LOCK_QNAME);
			}
		}
	}

	private String getUnixBoxName() {
		StringBuffer ipAddresses = new StringBuffer();
		InetAddress iAddress;
		try {
			iAddress = InetAddress.getLocalHost();
			String hostName = iAddress.getHostName();
			ipAddresses.append(hostName);
			// String canonicalHostName = iAddress.getCanonicalHostName();
			// ipAddresses.append(canonicalHostName);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ipAddresses.toString();
	}

	public void sendEMail(String hostName, String strManagerID, String jobName, String status) {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("year", new SimpleDateFormat("yyyy").format(new Date()));
		model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
		model.put("hostName", hostName);
		model.put("jobName", jobName);
		model.put("jobstatus", status);
		// NodeRef template =
		// getEmailtemplate(addUserFtlLocationPath,ADD_USER_NOTIFICATION_TEMPLATE);
		TemplateService templateService = serviceRegistry.getTemplateService();
		String strArray[] = strManagerID.split(",");
		String mailSubject = jobName + " Tracking Notification";
		String htmlBody = templateService.processTemplate(JOBTRACKER_STATUS_NOTIFICATION_TEMPLATE, model);

		logger.info("mailServer==" + mailServer + "==mailerFromID==" + mailerFromID + "==strArray==" + strArray
				+ "==mailSubject==" + mailSubject + "==strManagerID==" + strManagerID);
		boolean mailstatus = false;
		try {
			mailstatus = MailUtil.sendMail(mailServer, mailerFromID, strArray, null, mailSubject, htmlBody, null);
			logger.info("Mail Sataus >>>" + mailstatus + "   For user  ::  " + strManagerID);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void updateDB(String getUnixBoxName, String jobName, String startDate, String endDate, String status) {
		logger.info("Entered DB method");
		Session session = null;
		Transaction tx = null;
		JobTracker jobValues = new JobTracker();

		try {
			session = localFactory.openSession();
			tx = session.beginTransaction();
			String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
			String entryId = jobName.toString() + "_" + timeStamp.toString();
			jobValues.setEntryId(entryId.toString());
			jobValues.setBoxName(getUnixBoxName);
			jobValues.setJobName(jobName);
			jobValues.setStartDate(startDate);
			jobValues.setEndDate(endDate);
			jobValues.setStatus(status);
			session.save(jobValues);
			logger.info(jobValues.getBoxName() + "@@@" + jobValues.getJobName() + "@@@" + jobValues.getStartDate()
					+ "@@@" + jobValues.getEndDate() + "@@@" + jobValues.getStatus());

			tx.commit();

			logger.info("==Job Status Data Saved successfully:");

		} catch (Exception e) {
			logger.info("Error occured While updating " + e.getMessage());
			e.printStackTrace();
		}

	}

}