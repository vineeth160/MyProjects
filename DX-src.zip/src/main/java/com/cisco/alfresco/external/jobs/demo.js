<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
    <head>
        <title>Writing Data to CSV</title>
        <script type="text/javascript">
        var csvFilePath = "C:\\Users\\vipatnai\\Desktop\\Data.csv"; // File name

            function addToCSVFile() {
            	var fileName = "demo";
				var description = "testing";
				var document_id = "alfext123";
                var csvData = new Array();  // To collect the names
              //  var csvFilePath = "C:\\Users\\vipatnai\\Desktop\\Data.csv"; // File name

                // Collecting the names
                var nodeData = new Array();
				nodeData[0] = fileName;
				nodeData[1] = description;
				nodeData[2] = document_id;

                var fso = new ActiveXObject('Scripting.FileSystemObject');
                var oStream = fso.OpenTextFile(csvFilePath, 8, true, 0);
                oStream.WriteLine(nodeData.join(','));
                oStream.Close();
                //clearData();
                alert("Data Added Successfully");
            }

           /* function clearData() {
                document.getElementById('firstName').value = "";
                document.getElementById('middleName').value = "";
                document.getElementById('lastName').value = "";
            }*/
        </script>
    </head>
    <body>
        <p>
            <input type="button" id="addButton" value="Add to CSV File" onClick="javascript: addToCSVFile()" />
        </p>
    </body>
</html>