package com.cisco.alfresco.external.common.model;

import java.util.Date;

public class ExtDocument extends Asset {

	String mimetype;
	int size;
	double version;
	boolean isLocked;
	String shareUrl;
	String security;
	String permissionLevel;
	String downloadUrl;
	String docStatus;
	String workflowStatus;
	String edcsId;
	String expirationDate;
	boolean canUserCancelWorkflow;
	String folderId;
	boolean externalyShared;
	boolean canCancelCheckOut;
	String workingCopyOwner; 
	boolean favoriteStatus;
	String relativePath;
	boolean isFolderEmpty;
	boolean domainMismatch;
//Start : mkatnam added for Publish BI Reports
	String applyVeraProtection;
	String tags;
	boolean isSynced;
	
	boolean isEmailExists;
	String domain;
	
	boolean disableDeleteDocuments;
	
	boolean isExpirationDateChanged;
	
	public boolean isExpirationDateChanged() {
		return isExpirationDateChanged;
	}
	public void setExpirationDateChanged(boolean isExpirationDateChanged) {
		this.isExpirationDateChanged = isExpirationDateChanged;
	}
	public boolean isDisableDeleteDocuments() {
		return disableDeleteDocuments;
	}
	public void setDisableDeleteDocuments(boolean disableDeleteDocuments) {
		this.disableDeleteDocuments = disableDeleteDocuments;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public boolean isEmailExists() {
		return isEmailExists;
	}
	public void setEmailExists(boolean isEmailExists) {
		this.isEmailExists = isEmailExists;
	}
	
	public boolean isSynced() {
		return isSynced;
	}
	public void setSynced(boolean isSynced) {
		this.isSynced = isSynced;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public String getApplyVeraProtection() {
		return applyVeraProtection;
	}
	public void setApplyVeraProtection(String applyVeraProtection) {
		this.applyVeraProtection = applyVeraProtection;
	}
	public boolean isDomainMismatch() {
		return domainMismatch;
	}
	public void setDomainMismatch(boolean domainMismatch) {
		this.domainMismatch = domainMismatch;
	}
	public boolean isFolderEmpty() {
		return isFolderEmpty;
	}
	public void setFolderEmpty(boolean isFolderEmpty) {
		this.isFolderEmpty = isFolderEmpty;
	}
	public boolean isFavoriteStatus() {
		return favoriteStatus;
	}
	public void setFavoriteStatus(boolean favoriteStatus) {
		this.favoriteStatus = favoriteStatus;
	}
	public String getRelativePath() {
		return relativePath;
	}
	public void setRelativePath(String relativePath) {
		this.relativePath = relativePath;
	}
	String folderPath;
	String publisher;
	String publishedDate;
	String extPublishedUsers;
	String startDate;
	String endDate;
	String contentSize;
	String downloadedBy;
	String downloadDate;
	String email;
	String userType;
	
	//added for download Report
	int downloadCount;
	String company;
	String firstAndLastName;
	
	//added for user activity report
	String userActivity;
	String remarks;
	String comments;
	boolean checkOutStatus;
	
	Date modDate;
	int docId;
	Date expDate;
	
	boolean createdInDocExchange; 
	
	public boolean isCreatedInDocExchange() {
		return createdInDocExchange;
	}
	public void setCreatedInDocExchange(boolean createdInDocExchange) {
		this.createdInDocExchange = createdInDocExchange;
	}
	public int getDocId() {
		return docId;
	}
	public void setDocId(int docId) {
		this.docId = docId;
	}
	public Date getExpDate() {
		return expDate;
	}
	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}
	public Date getModDate() {
		return modDate;
	}
	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getUserActivity() {
		return userActivity;
	}
	public void setUserActivity(String userActivity) {
		this.userActivity = userActivity;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getFirstAndLastName() {
		return firstAndLastName;
	}
	public void setFirstAndLastName(String firstAndLastName) {
		this.firstAndLastName = firstAndLastName;
	}
	public int getDownloadCount() {
		return downloadCount;
	}
	public void setDownloadCount(int downloadCount) {
		this.downloadCount = downloadCount;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getDownloadedBy() {
		return downloadedBy;
	}
	public void setDownloadedBy(String downloadedBy) {
		this.downloadedBy = downloadedBy;
	}
	public String getDownloadDate() {
		return downloadDate;
	}
	public void setDownloadDate(String downloadDate) {
		this.downloadDate = downloadDate;
	}
	public String getContentSize() {
		return contentSize;
	}
	public void setContentSize(String string) {
		this.contentSize = string;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getFolderPath() {
		return folderPath;
	}
	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getPublishedDate() {
		return publishedDate;
	}
	public void setPublishedDate(String publishedDate) {
		this.publishedDate = publishedDate;
	}
	public String getExtPublishedUsers() {
		return extPublishedUsers;
	}
	public void setExtPublishedUsers(String extPublishedUsers) {
		this.extPublishedUsers = extPublishedUsers;
	}
	// END : mkatnam
	
	public String getMimetype() {
		return mimetype;
	}
	public void setMimetype(String mimetype) {
		this.mimetype = mimetype;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public double getVersion() {
		return version;
	}
	public void setVersion(double version) {
		this.version = version;
	}
	public boolean isLocked() {
		return isLocked;
	}
	public void setLocked(boolean isLocked) {
		this.isLocked = isLocked;
	}
	public String getShareUrl() {
		return shareUrl;
	}
	public void setShareUrl(String shareUrl) {
		this.shareUrl = shareUrl;
	}
	public String getSecurity() {
		return security;
	}
	public void setSecurity(String security) {
		this.security = security;
	}
	public String getPermissionLevel() {
		return permissionLevel;
	}
	public void setPermissionLevel(String permissionLevel) {
		this.permissionLevel = permissionLevel;
	}
	public String getDownloadUrl() {
		return downloadUrl;
	}
	public void setDownloadUrl(String downloadUrl) {
		this.downloadUrl = downloadUrl;
	}
	public String getDocStatus() {
		return docStatus;
	}
	public void setDocStatus(String docStatus) {
		this.docStatus = docStatus;
	}
	public String getWorkflowStatus() {
		return workflowStatus;
	}
	public void setWorkflowStatus(String workflowStatus) {
		this.workflowStatus = workflowStatus;
	}
	public String getEdcsId() {
		return edcsId;
	}
	public void setEdcsId(String edcsId) {
		this.edcsId = edcsId;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	public boolean isCanUserCancelWorkflow() {
		return canUserCancelWorkflow;
	}
	public void setCanUserCancelWorkflow(boolean canUserCancelWorkflow) {
		this.canUserCancelWorkflow = canUserCancelWorkflow;
	}
	public String getFolderId() {
		return folderId;
	}
	public void setFolderId(String folderId) {
		this.folderId = folderId;
	}
	public Boolean getExternalyShared() {
		return externalyShared;
	}
	public void setExternalyShared(Boolean externalyShared) {
		this.externalyShared = externalyShared;
	}
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public boolean isCheckOutStatus() {
		return checkOutStatus;
	}
	public void setCheckOutStatus(boolean checkOutStatus) {
		this.checkOutStatus = checkOutStatus;
	}
	public boolean isCanCancelCheckOut() {
		return canCancelCheckOut;
	}
	public void setCanCancelCheckOut(boolean canCancelCheckOut) {
		this.canCancelCheckOut = canCancelCheckOut;
	}
	public String getWorkingCopyOwner() {
		return workingCopyOwner;
	}
	public void setWorkingCopyOwner(String workingCopyOwner) {
		this.workingCopyOwner = workingCopyOwner;
	}
	

}
