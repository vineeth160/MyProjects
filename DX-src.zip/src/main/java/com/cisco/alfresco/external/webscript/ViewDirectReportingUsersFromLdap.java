package com.cisco.alfresco.external.webscript;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;

public class ViewDirectReportingUsersFromLdap extends DeclarativeWebScript{
	  private Logger LOGGER = Logger.getLogger(ViewDirectReportingUsersFromLdap.class);
	  private static final String DEFAULT_VALUE="Not Available";
	  private static final String DEFAULT_PERMISSIONS="Reader";
	  private static final String NA="N/A";
	  private static final String ACCESS_LEVEL="4";
	  private ServiceRegistry serviceRegistry;
	  private ExternalLDAPUtil ldapUtil;
	  public void setServiceRegistry(ServiceRegistry serviceRegistry)
	  {
	    this.serviceRegistry = serviceRegistry;
	  }
	  public ExternalLDAPUtil getLdapUtil() {
	      return ldapUtil;
	  }
	  public void setLdapUtil(ExternalLDAPUtil ldapUtil) {
	      this.ldapUtil = ldapUtil;
	  }
	  protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {
		  Map<String, Object> model = new HashMap<String, Object>();
		  String nodeRefId =null;
		    List<HashMap<String, String>> userDeatils = new ArrayList<HashMap<String, String>>();
		    String mgrIdParameter = req.getParameter("manager");
		    nodeRefId = req.getParameter("nodeId");
		    String message = "";
		    try{
		    if(isUserInternal(mgrIdParameter)){
		    	userDeatils=getUserDetailsFromLdap(ldapUtil.getManagerReportingUsersFromLDAP(mgrIdParameter),nodeRefId,mgrIdParameter);
		    	//LOGGER.info("ViewDirectReportingUsersFromLdap userDeatils :::::::  "+userDeatils.toString());
		   		  model.put("persons", userDeatils);
		   	    } else {
		   	    	message = "You are not authorized to perform this operation..";
		   	    }
		    if(userDeatils.size()==0){
		    	message = "Manger does not have a direct reporting users";
		    }
		    }catch(Exception e){
		    	LOGGER.error("Exception : " + e.getMessage());
		    }
		    model.put("managerId", mgrIdParameter);
		    model.put("message", message);
		    if(LOGGER.isDebugEnabled()){
	    	LOGGER.debug("ViewDirectReportingUsersFromLdap model ::::::  "+model.toString());
		    }
		return model;
	  }
	  
	  private List<HashMap<String, String>> getUserDetailsFromLdap(List<String> managerReportingUsers,String nodeRefId,String mgrIdParameter) {
		  List<HashMap<String, String>> usersInfoList = new ArrayList<HashMap<String,String>>();
		  HashMap<String, String> permissionsLabelInfo = new HashMap<String, String>();
		  //String firstName = null, lastName = null; 
		  String userName =null;
		  String empType =null;
		  String permissionValue = null;
		  try{
			  LOGGER.info("ViewDirectReportingUsersFromLdap managerReportingUsers size :::::::  "+managerReportingUsers.size());
			 if(managerReportingUsers.size()!=0){
			  permissionsLabelInfo=getNodeUserPermissions(nodeRefId);
			  //LOGGER.info("permissionsLabelInfo ::::: "+permissionsLabelInfo.toString());
			  HashMap<String, String> managerUsersInfo = new HashMap<String, String>();
			  String managerIdAndName = ldapUtil.getUserDetailsFromLDAP(mgrIdParameter);
			  String managerUserId = (managerIdAndName.split("::"))[0];
			  managerUsersInfo.put("userId", managerUserId);
			  String managerName = (managerIdAndName.split("::"))[1];
			  managerUsersInfo.put("name", managerName);
			  String managerCompany = (managerIdAndName.split("::"))[2];
			  managerUsersInfo.put("company", managerCompany);
			  String managerEmail = (managerIdAndName.split("::"))[3];
			  managerUsersInfo.put("email", managerEmail);
			  String managerEmpType = (managerIdAndName.split("::"))[4];
			  if(managerEmpType.equals(NA)){
				  managerUsersInfo.put("employeeType", DEFAULT_VALUE);
			  }else{
				  managerUsersInfo.put("employeeType", managerEmpType);
			  }
			  if(permissionsLabelInfo.containsKey(mgrIdParameter)){
		        	permissionValue=permissionsLabelInfo.get(mgrIdParameter).toString();
		        	if(LOGGER.isDebugEnabled()){
		        	LOGGER.debug("permissionValue ::: "+permissionValue);
		        	}
		        	 if(permissionValue.equals("AdminRole")){
		    		  permissionValue="Folder Admin";
		    	  }
		        }else{
		        	permissionValue=DEFAULT_PERMISSIONS;
		        }
			  managerUsersInfo.put("permissionLevel",permissionValue);
			  usersInfoList.add(managerUsersInfo);
			  
			  
			  
		  for (String ldapUserId : managerReportingUsers)
	        {
			 
			  HashMap<String, String> usersInfo = new HashMap<String, String>();
			  String idAndName = ldapUtil.getUserDetailsFromLDAP(ldapUserId);
			  String empAccessLevel = (idAndName.split("::"))[6];
			  if(LOGGER.isDebugEnabled()){
				  LOGGER.debug("idAndName =" + idAndName);
				  LOGGER.debug("empAccessLevel =" + empAccessLevel);
				//idAndName =nathammi::Nagaraju Thammisetty::Cisco Systems, Inc.
			  }
			  
			  if(empAccessLevel.equalsIgnoreCase(ACCESS_LEVEL)){
		        userName = (idAndName.split("::"))[0];
		        //LOGGER.info("userId :::::::::   = " + userName);
		        usersInfo.put("userId", userName);
		        String name = (idAndName.split("::"))[1];
		        //for getting first name and last name separately
		       /* if (name.contains(" "))
		        {
		            firstName = (name.split(" "))[0];
		            //LOGGER.info("firstName =" + firstName);
		            lastName = (name.split(" "))[1];
		            //LOGGER.info("lname =" + lastName);
		        }
		        else{
		            firstName = name;
		        	lastName="";
		        }
		        usersInfo.put("fname", firstName);
		        usersInfo.put("lname", lastName);*/
		      //end of for getting first name and last name separately
		        usersInfo.put("name", name);
		        String company = (idAndName.split("::"))[2];
		        usersInfo.put("company", company);
		        String email = (idAndName.split("::"))[3];
		        usersInfo.put("email", email);
		        empType = (idAndName.split("::"))[4];
		        if(empType.equals(NA)){
					  usersInfo.put("employeeType", DEFAULT_VALUE);
				  }else{
					  usersInfo.put("employeeType", empType);
				  }
		        if(permissionsLabelInfo.containsKey(ldapUserId)){
		        	permissionValue=permissionsLabelInfo.get(ldapUserId).toString();
		        	//LOGGER.info("permissionValue ::: "+permissionValue);
		        	 if(permissionValue.equals("AdminRole")){
		    		  permissionValue="Folder Admin";
		    	  }
		        	 permissionValue=permissionValue.replace("Role","");
		        }else{
		        	permissionValue=DEFAULT_PERMISSIONS;
		        }
		        usersInfo.put("permissionLevel",permissionValue);
		        if(!usersInfo.get("permissionLevel").equals("Owner")){
		        usersInfoList.add(usersInfo);
	            }
			  }
	        }
			 }
		  }catch(Exception ex){
			  LOGGER.error("getUserDetailsFromLdap Exception : " + ex.getMessage());
		  }
		return usersInfoList;
	  }
	  
	private HashMap<String, String> getNodeUserPermissions(final String nodeRefId){
		  
		  HashMap<String, String> permissionsInfo = new HashMap<String, String>();
		  try{
			  final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
			  AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			  @Override
			  public Object doWork() throws Exception {
				  NodeRef nodeRef = new NodeRef(nodeRefId);
				  accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef));
				  return null;
			  	}
			  }, "admin");

			  if (accessPermission.size() > 0) {
			  for (AccessPermission accessPermissionObj : accessPermission) {
				  permissionsInfo.put(accessPermissionObj.getAuthority(), accessPermissionObj.getPermission().toString());
			  }
			  }   
		  }catch(Exception exe){
			  LOGGER.error("Get Node User Permissions Exception : " + exe.getMessage());
		  }
		  LOGGER.info("permissionsInfo ::::: "+permissionsInfo.toString());
		  return permissionsInfo;
	  }
	  
	  public boolean isUserInternal(String userid)
	  {
		  //LOGGER.info((new StringBuilder("Start checking if internal LDAP users.. ")).append(userid).toString());
	      return ldapUtil.isLdapUserInternal((new StringBuilder(String.valueOf(userid))).toString());
	  }
}
		
