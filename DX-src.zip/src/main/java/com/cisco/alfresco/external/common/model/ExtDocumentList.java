package com.cisco.alfresco.external.common.model;

import java.util.List;


/**
 * 
 * @author nabbeher
 * 
 */
public class ExtDocumentList
{

    private List<ExtDocument> extDocumentlist;

    @Override
    public String toString()
    {
        return "ExtDocumentList [extDocumentlist=" + extDocumentlist + ", getClass()=" + getClass() + ", hashCode()="
                + hashCode() + ", toString()=" + super.toString() + "]";
    }

    public List<ExtDocument> getExtDocumentlist()
    {
        return extDocumentlist;
    }

    public void setExtDocumentlist(List<ExtDocument> extDocumentlist)
    {
        this.extDocumentlist = extDocumentlist;
    }

}
