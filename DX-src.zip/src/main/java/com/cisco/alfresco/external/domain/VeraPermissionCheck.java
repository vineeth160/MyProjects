package com.cisco.alfresco.external.domain;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.version.Version2Model;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.webscript.UserRoleConstants;
import com.cisco.vera.utils.VeraReportsMap;

public class VeraPermissionCheck extends DeclarativeWebScript {
	private static final Logger LOGGER = Logger	.getLogger(VeraPermissionCheck.class);
	private ServiceRegistry serviceRegistry;
	private SessionFactory localFactory;

	public SessionFactory getLocalFactory() {
		return localFactory;
	}

	public void setLocalFactory(SessionFactory localFactory) {
		this.localFactory = localFactory;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	// hibernate session initialization
	Session session = null;

	public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, Cache cache) {
		final Map<String, Object> result = new HashMap<String, Object>();
		try{

			final String ciscoShareAdminUserName = AuthenticationUtil.getFullyAuthenticatedUser();
			LOGGER.info("ciscoShareAdminUserName :::" + ciscoShareAdminUserName);
			AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				@Override
				public Object doWork() throws Exception {
					boolean isAdmin = false;
					Set<String> groupSet = serviceRegistry.getAuthorityService().getAuthoritiesForUser(ciscoShareAdminUserName.toString());
					isAdmin = groupSet.contains("GROUP_VERA_GENERIC_USER");
					LOGGER.info("isAdmin :: " + isAdmin);
					if (isAdmin) {
						String strNoderef = req.getParameter("alfrescoId");
						String docAccessedUserId = req.getParameter("userId");
						LOGGER.info("noderef : :" + strNoderef + "  userId ::  "+ docAccessedUserId);
						if (strNoderef == null || strNoderef.isEmpty()) {
							status.setMessage("noderef is not found in the input request parameter.");
							status.setCode(500);
						}
						if (docAccessedUserId == null || docAccessedUserId.isEmpty()) {
							status.setMessage("userid is not found in the input request parameter.");
							status.setCode(500);
						} 
						NodeRef docNodeRef = new NodeRef(strNoderef);
						// check permissions on version noderef if user downloads non-current
						if (Version2Model.STORE_ID.equals(docNodeRef.getStoreRef().getIdentifier()))
						{
							LOGGER.info("if check  :: "+ Version2Model.STORE_ID + "next part ::  "+ docNodeRef.getStoreRef().getIdentifier());
							NodeRef currentNodeRef = new NodeRef(StoreRef.PROTOCOL_WORKSPACE,Version2Model.STORE_ID, docNodeRef.getId());
							NodeRef frozenNodeRef = (NodeRef) serviceRegistry.getNodeService().getProperty(currentNodeRef,Version2Model.PROP_QNAME_FROZEN_NODE_REF);
							docNodeRef = frozenNodeRef;
						}
						LOGGER.info("Document Noderef value :: " + docNodeRef);
						// domain validation for encrypted document accessed user
						boolean userExistInRepo = serviceRegistry.getPersonService().personExists(docAccessedUserId);
						if (userExistInRepo) {
							if (docNodeRef != null	&& serviceRegistry.getNodeService().exists(docNodeRef)) {
								if (hasAccess(docAccessedUserId, docNodeRef)) {
									String userRole = getUserRole(serviceRegistry, docAccessedUserId,docNodeRef);
									LOGGER.info("userRole :: " + userRole);
									Transaction tx = null;
									if (!userRole.equalsIgnoreCase("viewer")) {
										ChildAssociationRef childAssociationRef = serviceRegistry.getNodeService().getPrimaryParent(docNodeRef);
										NodeRef rootNodeRef = childAssociationRef.getParentRef();
										String strRootFolderNodeRef = (String) serviceRegistry.getNodeService().getProperty(rootNodeRef, ExternalSharingConstants.PROP_VERA_ROOT_FOLDER_NODEREF);
										Session session = localFactory.openSession();
										try {
											tx = session.beginTransaction();
											VeraReportsMap insertRecord = new VeraReportsMap();
											insertRecord.setUserName(docAccessedUserId);
											insertRecord.setDocNoderef(docNodeRef.toString());
											insertRecord.setVeraRootNoderef(strRootFolderNodeRef);
											insertRecord.setLastAccessDate(new Date());
											session.saveOrUpdate(insertRecord);
											LOGGER.info("new user record added----->>> "+docAccessedUserId);
											tx.commit();
										} catch (HibernateException e) {
											if (tx != null)
												tx.rollback();
											e.printStackTrace();
										} finally {
											session.close();
										}

									}

									result.put("id", docNodeRef.toString());
									result.put("userid", docAccessedUserId);
									result.put("role", userRole);
								} else {
									status.setMessage("User dont have the permission on the noderef.");
									status.setCode(400);
								}
							} else {
								status.setMessage("Invalid NodeRef...Please check the parameters passed.");
								status.setCode(400);
							}

						} else {
							status.setMessage("Invalid User id....UserId does not exist.");
							status.setCode(400);
						}
					} else {
						status.setMessage("You are not authorized to call this API.");
						status.setCode(400);
					}
					return result;
				}
			}, "admin");
		}catch(Exception e){
			LOGGER.error("Exception occured in VeraPermissionCheck WS.."+e);
			e.printStackTrace();

		}

		return result;

	}

	//method to return user role on requested document
	public static String getUserRole(ServiceRegistry serviceRegistry,String currentUser, NodeRef nodeRef) throws Exception{
		String userRole = null;
		Set<AccessPermission> userSet = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
		LOGGER.info("userSet : " + userSet);
		if (userSet.size() > 0) {
			int currentRoleIndex = 0;
			int tempRoleIndex = 0;
			String tempUserRole = "";

			for (AccessPermission accessPermission : userSet) {
				String user = accessPermission.getAuthority();

				if (user.equalsIgnoreCase(currentUser)) {
					String role = accessPermission.getPermission();
					userRole = role.split("Role")[0];
					tempRoleIndex = ExternalSharingConstants.UsersRoleHerarcy.get(userRole);
					if (tempRoleIndex > currentRoleIndex) {
						tempUserRole = userRole;
						currentRoleIndex = tempRoleIndex;
					}

				}
			}
			userRole = tempUserRole;
			if (userRole.equalsIgnoreCase("Admin")||userRole.equalsIgnoreCase("Owner")) {
				userRole = UserRoleConstants.USER_ADMIN_ROLE;
			}

		}

		return userRole;
	}
	//check user permission on the requested document 
	public boolean hasAccess(String currentUser, NodeRef nodeRef) throws Exception{
		if (currentUser.equals("admin")) {
			return true;
		}
		Set<AccessPermission> userSet = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
		if (userSet.size() > 0) {
			for (AccessPermission accessPermission : userSet) {
				String user = accessPermission.getAuthority();
				if (user.equalsIgnoreCase(currentUser)) {
					return true;
				}
			}
		}

		return false;
	}
}
