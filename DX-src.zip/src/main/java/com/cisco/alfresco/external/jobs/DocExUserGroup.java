package com.cisco.alfresco.external.jobs;

import java.io.IOException;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.cmr.audit.AuditQueryParameters;
import org.alfresco.service.cmr.audit.AuditService;
import org.alfresco.service.cmr.audit.AuditService.AuditQueryCallback;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.log4j.Logger;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.quartz.JobDataMap;


import com.cisco.alfresco.auth.ext.EXTEncrypter;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;



public class DocExUserGroup extends QuartzJobBean{
	private static final Logger LOGGER = Logger.getLogger(DocExUserGroup.class);
	static String url = "https://ews-rch-core.cisco.com/itsm/mailer/rest/subscribe/doc-exchange-users/";
	private AuditService auditService;
	
	private ExternalLDAPUtil ldapUtil;  
	private static final String KEY_IS_JOB_ENABLED = "DocExUserGroupEnabled";
	private String genericUser;
    private String genericPwd;
    private String genericKey;
       public String getGenericUser() {
		return genericUser;
	}

	public void setGenericUser(String genericUser) {
		this.genericUser = genericUser;
	}

	public String getGenericPwd() {
		return genericPwd;
	}

	public void setGenericPwd(String genericPwd) {
		this.genericPwd = genericPwd;
	}

	public String getGenericKey() {
		return genericKey;
	}

	public void setGenericKey(String genericKey) {
		this.genericKey = genericKey;
	}

	public ExternalLDAPUtil getLdapUtil() {
		return ldapUtil;
	}

	public void setLdapUtil(ExternalLDAPUtil ldapUtil) {
		this.ldapUtil = ldapUtil;
	}

	public AuditService getAuditService() {
   		return auditService;
   	}

   	public void setAuditService(AuditService auditService) {
   		this.auditService = auditService;
   	}   


public void Addusers() {
	
	  
	Calendar cal = Calendar.getInstance();
	cal.add(Calendar.DATE, -10);
	Date result = cal.getTime();
	LOGGER.info("Date result-->>" +result);
	Long fromTime = result.getTime() ;
	LOGGER.info("from time -->>"+fromTime);
	Long toTime = System.currentTimeMillis( );
	LOGGER.info("to time -->>"+toTime);
	final Set<String> userNameList = getUserAccessAuditQuery(fromTime,toTime, auditService);
	
	AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
		@Override
		public Object doWork() throws Exception {
	 if (userNameList != null){
		 //LOGGER.info("user name list----------"+userNameList);
		for (String userName : userNameList) {
			LOGGER.info("Checking for Username.... " + userName);
			
		String strManagerID = ldapUtil.getManagerEmailFromLDAP(userName);
			HttpClient client = new HttpClient();
		       GetMethod getm = new GetMethod(url+strManagerID);
		       try {
		    	   client.getParams().setAuthenticationPreemptive(true); 
		      String password = EXTEncrypter.decrypt(genericPwd, genericKey);
	    	   
	    client.getState().setCredentials(
	         new AuthScope("ews-rch-core.cisco.com", 443),
	         new UsernamePasswordCredentials(genericUser, password));
		   
		             // Execute the method.
		             int statusCode = client.executeMethod(getm);
                     //LOGGER.info("statuscode " +statusCode);
		             if (statusCode != HttpStatus.SC_OK) {
		            	 LOGGER.info("Method failed");
		               System.err.println("Method failed: " + getm.getStatusLine());
		             }
		             
		           } catch (HttpException e) {
		             System.err.println("Fatal protocol violation: " + e.getMessage());
		             e.printStackTrace();
		           } catch (IOException e) {
		             System.err.println("Fatal transport error: " + e.getMessage());
		             e.printStackTrace();
		           } finally {
		             // Release the connection.
		              getm.releaseConnection();
		           }  
			

		}
	}
	return userNameList;
		}
	}, "admin");
	
	
	return;
}



/**
 * @param context
 */
protected void executeInternal(JobExecutionContext context)
		throws JobExecutionException {
	LOGGER.info("Inside the execute internals");
	 boolean isJobEnabled = false;
	JobDataMap jobData = context.getJobDetail().getJobDataMap();
    String isJobEnabledStr = (String) jobData.get(KEY_IS_JOB_ENABLED);

    if (isJobEnabledStr != null)
    {
        try
        {
            isJobEnabled = new Boolean(isJobEnabledStr);
        }
        catch (Exception e)
        {
            LOGGER.error("Invalid '" + KEY_IS_JOB_ENABLED + "' value, using default: " + isJobEnabled, e);
        }
    }

    if (!isJobEnabled)
    {
        // skip Job
        LOGGER.error("Skipping " + KEY_IS_JOB_ENABLED + " to execute.");
        return;
    }
	Addusers();
}

private Set<String> getUserAccessAuditQuery(final Long fromTime, final Long toTime, final AuditService auditService){
	final Set<String> entries 	= new HashSet<String>();
	AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
		@Override
		public Object doWork() throws Exception {
	int limit = 0;
	 
	 final boolean verbose = true;
    // Execute the query
    AuditQueryParameters params = new AuditQueryParameters();
    params.setApplicationName("user-access"); 
    params.setFromTime(fromTime);
    params.setToTime(toTime);
    params.setForward(false);
    AuditQueryCallback callback = new AuditQueryCallback()
    {
    	
        @Override
        public boolean valuesRequired()
        {
            return verbose;
        }

        @Override
        public boolean handleAuditEntryError(Long entryId, String errorMsg, Throwable error)
        {
            return true;
        }

        @Override
        public boolean handleAuditEntry(Long entryId, String applicationName, String user, long time,
                Map<String, Serializable> values)
        {

            if (user != null)
            {
            	entries.add(user);
            }

            return true;
        }
       
    };

    // Make an audit call to applicationName
    auditService.auditQuery(callback, params, limit);
    return entries;


	}
}, "admin");
	return entries;
}
}
