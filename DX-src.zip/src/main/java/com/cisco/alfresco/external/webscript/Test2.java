package com.cisco.alfresco.external.webscript;

public class Test2 extends Test1 {
	
	public void human(String name){
		System.out.println("name of person is >>>"+name);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test2 an = new Test2();
		an.human("Vineeth");
		Test1 am = new Test1();
		am.animal("<<<Deer>>>");

	}

}
