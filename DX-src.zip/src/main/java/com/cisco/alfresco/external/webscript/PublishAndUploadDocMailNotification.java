package com.cisco.alfresco.external.webscript;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.TemplateService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.PersonService;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.edcsng.util.MailUtil;

/**
 * @author nathammi
 *
 */
public class PublishAndUploadDocMailNotification extends DeclarativeWebScript {
	static Logger LOG = Logger.getLogger(PublishAndUploadDocMailNotification.class);
	public static String PUBLISH_UPLOAD_DOCUMENT_NOTIFICATION_TEMPLATE = "/alfresco/extension/templates/email/PublishAndUploadDocumentNotification.ftl";
	private static final String GROUP_EVERYONE="GROUP_EVERYONE";
	private static String restricteSitePerm[] = new String[]{"SiteAdmin","SiteEditor","SiteManager","SiteOwner","SiteViewer","SiteReader"};
	private static List<String> restrictedPerms = Arrays.asList(restricteSitePerm);
	private ServiceRegistry serviceRegistry;
	private NodeService nodeService;
	private PersonService personService;
	//private static String ftlLocationPath;
	private static TemplateService templateService;
	private static String mailServer;
	private static String subjectLine;
	private static String bannerAlfrescoUrl;
	private static String titleURL;
	public static String getMailServer() {
		return mailServer;
	}

	public static void setMailServer(String mailServer) {
		PublishAndUploadDocMailNotification.mailServer = mailServer;
	}

	public static String getSubjectLine() {
		return subjectLine;
	}

	public static void setSubjectLine(String subjectLine) {
		PublishAndUploadDocMailNotification.subjectLine = subjectLine;
	}

	public static String getBannerAlfrescoUrl() {
		return bannerAlfrescoUrl;
	}

	public static void setBannerAlfrescoUrl(String bannerAlfrescoUrl) {
		PublishAndUploadDocMailNotification.bannerAlfrescoUrl = bannerAlfrescoUrl;
	}

	public static String getTitleURL() {
		return titleURL;
	}

	public static void setTitleURL(String titleURL) {
		PublishAndUploadDocMailNotification.titleURL = titleURL;
	}

	public static TemplateService getTemplateService() {
		return templateService;
	}

	public static void setTemplateService(TemplateService templateService) {
		PublishAndUploadDocMailNotification.templateService = templateService;
	}

	/*public static String getFtlLocationPath() {
		return ftlLocationPath;
	}

	public static void setFtlLocationPath(String ftlLocationPath) {
		PublishAndUploadDocMailNotification.ftlLocationPath = ftlLocationPath;
	}
*/
	public NodeService getNodeService() {
		return nodeService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
	
	public PersonService getPersonService() {
		return personService;
	}

	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}
	
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status,	Cache cache) {
		LOG.info("PublishDocumentMailNotification class started......");
		final Map<String, Object> result = new HashMap<String, Object>();
		List<String> finalResponse = new ArrayList<>();
		final Map<String, List<String>> mailingDocDetails = new HashMap<String, List<String>>();
		try {
			String currentUser=null;
			Content content = req.getContent();
			JSONObject inputJson = new JSONObject(content.getContent());
			LOG.info("Input Json is : " + inputJson);
			String publisherId =null;
			if(inputJson.has("publisher")){
				publisherId = inputJson.getString("publisher");
			}
			if(publisherId!=null&&!publisherId.isEmpty()){
        		currentUser =publisherId;
        	}else{
        		 currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
        	}
			JSONArray nodeArray = inputJson.getJSONArray("nodeRefJsonArray");
			for(int i = 0; i<nodeArray.length(); i++)
			{
				JSONObject objectInArray = nodeArray.getJSONObject(i);
				String strNodeId = objectInArray.getString("nodeId");
				getFileFullPermission(strNodeId,mailingDocDetails);
			}
			LOG.info(" final map for user doc details ::::: "+mailingDocDetails);
			
			 for (Map.Entry<String, List<String>> entry : mailingDocDetails.entrySet()) {
				 LOG.info("Key : " + entry.getKey() + " Value : " + entry.getValue());
					String response=sendMailToUsers(entry.getKey(),entry.getValue(),currentUser);
					finalResponse.add(response);
			 } 
			 result.put("mailStatus", finalResponse);
		}catch (Exception e) {
			result.put("mailStatus", "Mails sent failed");
			LOG.error("Exception outer : " + e.getStackTrace(),e);
		}
		
		return result;
	}
	

	/**
	 * @param strNodeId
	 * @param mailingDocDetails
	 */
	private void getFileFullPermission(String strNodeId, Map<String, List<String>> mailingDocDetails){
		
		NodeRef nodeRef = new NodeRef(strNodeId);
		 HashSet<String> userEmailSet = new HashSet<String>();
		Set<AccessPermission> accessPermissions = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);	
		 Iterator<AccessPermission> fIterator = accessPermissions.iterator(); 
		 while (fIterator.hasNext()){
             AccessPermission accessPermission = fIterator.next();
             LOG.info("Authority(User): " + accessPermission.getAuthority()+ " Permission:  " + accessPermission.getPermission());
             if (accessPermission.getAuthorityType() == AuthorityType.USER){
            	 boolean userExistInRepo = serviceRegistry.getPersonService().personExists(accessPermission.getAuthority());
            	 if(userExistInRepo){
      	    	   NodeRef personNodeId = personService.getPerson(accessPermission.getAuthority());  
      	    	   String personEmail = (String)serviceRegistry.getNodeService().getProperties(personNodeId).get(ContentModel.PROP_EMAIL);
      	    	   userEmailSet.add(personEmail);
            	 }
             }
             if (accessPermission.getAuthorityType() == AuthorityType.GROUP){
            	 Set<String> groupUsers = new TreeSet<String>();
            	 if(!accessPermission.getAuthority().equalsIgnoreCase(GROUP_EVERYONE) && !restrictedPerms.contains(accessPermission.getPermission())){
            	   groupUsers=serviceRegistry.getAuthorityService().getContainedAuthorities(AuthorityType.USER, accessPermission.getAuthority(), false);
            	   LOG.info("Authority(Group): " + accessPermission.getAuthority()+ " Permission:  " + accessPermission.getPermission()+ " Members:  " + groupUsers);
            	   for(String userId : groupUsers){
            		   boolean personExistInRepo = serviceRegistry.getPersonService().personExists(userId);
            		   if(personExistInRepo){
            		   NodeRef personNodeId = personService.getPerson(userId);  
        	    	   String personEmail = (String)serviceRegistry.getNodeService().getProperties(personNodeId).get(ContentModel.PROP_EMAIL);
        	    	   userEmailSet.add(personEmail);  
            		   }
            	   }
            	 }   
           }
		   } 
		 LOG.info("total final users count ::::"+userEmailSet.size());
		 for(String email : userEmailSet){
			 if(mailingDocDetails.containsKey(email)){
				List<String> docs= mailingDocDetails.get(email);
				docs.add(strNodeId);
			 }else{
				 List<String> docs = new ArrayList<>();
				 docs.add(strNodeId);
				 mailingDocDetails.put(email, docs);
			 }
			}
	
	}
	
	 /**
	 * @param userEmailId
	 * @param docs
	 * @param currentUser
	 * @return 
	 */
	private String sendMailToUsers(String userEmailId, List<String> docs,String currentUser){
		 	Map<String, Object> mailModel = new HashMap<String, Object>();
		 	Map<String, String> docsDetails=new HashMap<>();
		 	String response="";
			try {
				NodeRef publisherNodeId = personService.getPerson(currentUser);
			 	String from=(String)serviceRegistry.getNodeService().getProperties(publisherNodeId).get(ContentModel.PROP_EMAIL);
				Date currentDate = new Date();
				templateService = serviceRegistry.getTemplateService();
			  //NodeRef template = getEmailtemplate(PUBLISH_UPLOAD_DOCUMENT_NOTIFICATION_TEMPLATE);  
				String year = new SimpleDateFormat("yyyy").format(currentDate);
				String publisherFName = (String)serviceRegistry.getNodeService().getProperty(
						serviceRegistry.getPersonService().getPerson(currentUser),
						ContentModel.PROP_FIRSTNAME);
				String publisherLName = (String)serviceRegistry.getNodeService().getProperty(
						serviceRegistry.getPersonService().getPerson(currentUser),
						ContentModel.PROP_LASTNAME);
				String publisherFullName = publisherFName + " " + publisherLName;
				LOG.info("year :::::::"+year+"::publisherFullName :::::"+publisherFullName+"::from :::::"+from+"::fileURL::::"+titleURL);
				String subject = publisherFullName + " " +subjectLine;
				for (String strNodeRef : docs) {
					NodeRef nodeId=new NodeRef(strNodeRef);
					String docVersion = (String)serviceRegistry.getNodeService().getProperty(nodeId, ContentModel.PROP_VERSION_LABEL);
				 	String docName = (String)serviceRegistry.getNodeService().getProperty(nodeId, ContentModel.PROP_NAME);
				 	docsDetails.put(docName, docVersion);
					LOG.info("docName::::"+docName+"::version::::"+docVersion);
				}
				if(docsDetails != null && docsDetails.size() > 0){
					mailModel.put("docsDetails", docsDetails);
				}
				mailModel.put("publisherName", publisherFullName);
				mailModel.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
				mailModel.put("year", year);
				mailModel.put("titleURL", titleURL);
				String emailBody = templateService.processTemplate(PUBLISH_UPLOAD_DOCUMENT_NOTIFICATION_TEMPLATE, mailModel);
				if(!from.equals(userEmailId)){
				MailUtil.sendMail(mailServer, from, new String[]{userEmailId}, null, subject, emailBody, null);
				response="Mail sent succesfully to "+userEmailId;
				}else{
					response="Mail not required for publisher "+userEmailId;
				}
				
			} catch (Exception e) {
				response="Mails sent failed for "+userEmailId;
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			LOG.info("sendMail called successfully from PublishAndUploadDocNotification :::::::: ");
		 return response;
	 }
	 
	 /**
	     * To Get Email Template Noderef
	     */
	   /* private NodeRef getEmailtemplate(String templateName)
	    {
	        String templateConditionalPath = "PATH:\"" + ftlLocationPath + "//*\" AND "
	                + "TYPE:cm\\:content AND @cm\\:name:\"" + templateName + "\"";
	        LOG.debug("LUCENE QRY: " + templateConditionalPath);
	        ResultSet resultSet = serviceRegistry.getSearchService().query(
	            new StoreRef(StoreRef.PROTOCOL_WORKSPACE, "SpacesStore"), SearchService.LANGUAGE_LUCENE,
	            templateConditionalPath);
	        if (resultSet.length() == 0)
	        {
	        	LOG.error("Template " + templateConditionalPath + " not found.");
	            return null;
	        }
	        NodeRef template = resultSet.getNodeRef(0);
	        LOG.debug("Got the Email Template:" + template.toString());
	        return template;
	        }*/
}
