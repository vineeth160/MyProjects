package com.cisco.alfresco.external.webscript;

import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.alfresco.service.ServiceRegistry;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;

public class GetGeoLocation extends DeclarativeWebScript{
	private static final Logger logger = Logger.getLogger(GetGeoLocation.class);
	private ServiceRegistry serviceRegistry;
	private String geoServerLocation;
    public String getGeoServerLocation() {
		return geoServerLocation;
	}

	public void setGeoServerLocation(String geoServerLocation) {
		this.geoServerLocation = geoServerLocation;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	@Override
    public Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
    {
		Map<String, Object> model=new HashMap<String, Object>();
		JSONParser parser = new JSONParser();
		JSONObject obj = null;
		try {
			obj = (JSONObject)parser.parse(req.getContent().getContent());
		} catch (ParseException pe) {
			throw new WebScriptException(Status.STATUS_BAD_REQUEST, "Unexpected ParseException", pe);
		} catch (IOException io) {
			throw new WebScriptException(Status.STATUS_INTERNAL_SERVER_ERROR, "Unexpected IOException", io);
		}
		String geoLocation = (String)obj.get("geolocation");  //geolocation
		logger.info("geoLocation  :: " +geoLocation);
		String userId = serviceRegistry.getAuthenticationService().getCurrentUserName();
		logger.info("Current Username :::" + userId);
		/*NodeRef personNodereff=serviceRegistry.getPersonService().getPerson(currentUserName);
		logger.error("Person nodereff   ::" +personNodereff);
		if(!serviceRegistry.getNodeService().hasAspect(personNodereff,ExternalSharingConstants.CISCO_GCS_LOCATION_ASPECT)){
 			serviceRegistry.getNodeService().addAspect(personNodereff, ExternalSharingConstants.CISCO_GCS_LOCATION_ASPECT, null); 
		}
 			serviceRegistry.getNodeService().setProperty(personNodereff,ExternalSharingConstants.CISCO_QNAME_GCS_LOCATION_PROP, geoLocation);
 			logger.error("Location updated successfully!!!!");
 			obj.put("message","success");*/
		String geoHost = null;
		String locationUrl= getGeoLocationURL(geoLocation);
        logger.info("locationUrl::  " +locationUrl);  
		if(locationUrl != null && !locationUrl.isEmpty()){
			geoHost= locationUrl.replace("https://", "");
     	   logger.info("geoHost::  " +geoHost);  	
         } 
		model.put("userId",userId); 
		model.put("geoLocationName", geoLocation);
        model.put("geoHost", geoHost);
         
		return model;
 		
 		
		
		
	}
	
	public String getGeoLocationURL(String location){
    	String gcsLocationUrl =null;
    	try {
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(new FileReader(geoServerLocation));
			JSONObject jsonObject = (JSONObject) obj;
			JSONArray regionsArray = (JSONArray) jsonObject.get("regions");
			for(int i=0;i<regionsArray.size();i++){
				//System.out.println("Regions::"+regionsArray.get(i));
				JSONObject regionObject =(JSONObject)regionsArray.get(i);
				String geoLocation = (String) regionObject.get("location"); 
				logger.info("geoLocation::"+geoLocation  + "  location :: " +location);
				if(geoLocation.equalsIgnoreCase(location)){
					gcsLocationUrl = (String) regionObject.get("url"); 
					logger.info("gcsLocationUrl::"+gcsLocationUrl);
					break;
				}
			}
			
		} catch (Exception e) {
			logger.info("Exception is ::"+ e.getStackTrace(), e);
		}
		return gcsLocationUrl;
		
	}

}
