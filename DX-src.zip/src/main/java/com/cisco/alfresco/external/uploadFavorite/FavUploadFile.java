package com.cisco.alfresco.external.uploadFavorite;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.processor.BaseProcessorExtension;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.ContentData;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.namespace.RegexQNamePattern;
import org.alfresco.util.ISO9075;
import org.apache.log4j.Logger;

import com.cisco.alfresco.external.common.model.ExtDocument;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.alfresco.external.utils.CharUtil;
import com.cisco.alfresco.external.viewfav.Viewfav;
import com.cisco.alfresco.external.webscript.UpdateExpiringDateForDocuments;

/**
 * @author dgrandhi
 *
 */
public class FavUploadFile extends BaseProcessorExtension {

	private static final Logger LOG = Logger.getLogger(FavUploadFile.class);
	private static NodeService nodeService;
	private static ServiceRegistry serviceRegistry;
	private static final String SITE_DOCLIB_PATH = "/Company Home/Sites/edcsng/documentLibrary";
	
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	static final String CISCO_MODEL_URI = "http://www.cisco.com/model/content/1.0";
	static final String CISCO_MODEL_URI_CM = "http://www.alfresco.org/model/content/1.0";

	QName ASSOC_NAME_MYFAVORITE_ASSOCIATE = QName.createQName(CISCO_MODEL_URI,"myFavorite");
	QName ASPECT_MYFAVORITEDOCS = QName.createQName(CISCO_MODEL_URI,"FavAspect");

	public NodeService getNodeService() {
		return nodeService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	/**
	 * Method to make as favorite
	 * 
	 * @param personNodereff
	 * @param docNodeRef
	 */
	public void makeNewUploadAsFavorite(NodeRef personNodereff,NodeRef docNodeRef) {
		LOG.debug("User nodeRef: " + personNodereff + " document nodeRef: "+ docNodeRef);

		if (nodeService.hasAspect(personNodereff, ASPECT_MYFAVORITEDOCS) == false) {
			this.nodeService.addAspect(personNodereff, ASPECT_MYFAVORITEDOCS,null);
			nodeService.addChild(personNodereff, docNodeRef,ASSOC_NAME_MYFAVORITE_ASSOCIATE,QName.createQName(CISCO_MODEL_URI_CM, docNodeRef.getId()));
		} else {
			nodeService.addChild(personNodereff, docNodeRef,ASSOC_NAME_MYFAVORITE_ASSOCIATE,QName.createQName(CISCO_MODEL_URI_CM, docNodeRef.getId()));
		}
		LOG.debug("Added to Fav list");
	}

	/**
	 * @param personNodereff
	 * @param docNodeRef
	 */
	public void makeVersionAsFavorite(NodeRef personNodereff, NodeRef docNodeRef) {

		LOG.debug("User nodeRef: " + personNodereff + " document nodeRef: "+ docNodeRef);
		List<ChildAssociationRef> childAssocList = nodeService.getChildAssocs(personNodereff, ASSOC_NAME_MYFAVORITE_ASSOCIATE,RegexQNamePattern.MATCH_ALL);
		List<NodeRef> childNodeRefs = new ArrayList<NodeRef>();
		
		if (childAssocList != null && !childAssocList.isEmpty()) {
			LOG.debug("child list:"+childAssocList.size());
			for (ChildAssociationRef child : childAssocList) {
				NodeRef childNodeRef = child.getChildRef();
				childNodeRefs.add(childNodeRef);
			}
			LOG.debug("childnodeRefs size"+childNodeRefs.size());
			if (!childNodeRefs.isEmpty()) {
				if (!(childNodeRefs.contains(docNodeRef))){
					makeNewUploadAsFavorite(personNodereff, docNodeRef);
					LOG.debug("Version added to Fav list");
				}else{
					LOG.debug("Already it was Favorite");
				}
			}
		}else {
			makeNewUploadAsFavorite(personNodereff, docNodeRef);
			LOG.debug("Version added to Fav list");
		}
	}

	/**
	 * Method to remove as favorite
	 * 
	 * @param personNodereff
	 * @param docNodeRef
	 */
	public void removeAsFavorite(NodeRef personNodereff, NodeRef docNodeRef) {

		LOG.debug("User nodeRef: " + personNodereff + " document nodeRef: "+ docNodeRef);
		List<ChildAssociationRef> childAssocList = nodeService.getChildAssocs(personNodereff, ASSOC_NAME_MYFAVORITE_ASSOCIATE,RegexQNamePattern.MATCH_ALL);
		if (childAssocList.size() > 1) {
			for (ChildAssociationRef child : childAssocList) {
				NodeRef childNodeRef = child.getChildRef();
				if (childNodeRef.equals(docNodeRef)) {
					nodeService.removeChildAssociation(child);
					break;
				}
			}
		} else if (childAssocList.size() == 1) {
			for (ChildAssociationRef child : childAssocList) {
				NodeRef childNodeRef = child.getChildRef();
				if (childNodeRef.equals(docNodeRef)) {
					nodeService.removeChildAssociation(child);
					nodeService.removeAspect(personNodereff,ASPECT_MYFAVORITEDOCS);
					break;
				}
			}
		}
		LOG.info("Removed from Fav list");
	}
	
	//prbadam Start: US8978-Search related changes
	public String getUserRolePermission(String currentUser, NodeRef nodeRef) {
	   String UserRole = ExternalSharingFileFolderUtil.getUserRole(serviceRegistry, currentUser, nodeRef);
	   LOG.info("inside getUserRolePermission- UserRole------"+UserRole);
	   return UserRole;
	}
	
	public String getFolderRelativePath(String folderName, NodeRef nodeRef) {
	 StringBuilder folderPath = new StringBuilder();
	  String folderDisplayPath = serviceRegistry.getNodeService().getPath(nodeRef).toDisplayPath(serviceRegistry.getNodeService(), serviceRegistry.getPermissionService());
     if (folderDisplayPath.length() > SITE_DOCLIB_PATH.length() && folderDisplayPath.contains(SITE_DOCLIB_PATH))
     {
         folderPath.append(folderDisplayPath.split(SITE_DOCLIB_PATH)[1]).append("/").append(folderName);
     }
     else
     {
         folderPath.append("/").append(folderName);
     }
     return folderPath.toString();
	}
	//prbadam End: US8978-Search related changes
	
	
	//prbadam Start: US8971-Search related changes	
	public HashMap<String, Boolean> getNodePropsMap(NodeRef nodeRef) {
		 LOG.info("inside getNodePropsMap--------");
		 HashMap<String, Boolean> hashmap = new HashMap<String, Boolean>();
		 boolean canUserCancelCheckout = false;
         String workingCopyOwner = null;
         boolean isFavorite = false;
         NodeRef originalnoderef = null;
         boolean hasSubFolder = true;
         boolean isCheckedOut = false;
		
		 boolean canUserCancelWorkflow = ExternalSharingFileFolderUtil.canUserCancelWorkflow(serviceRegistry, nodeRef);
         
         final List<NodeRef> customFablist = new ArrayList<NodeRef>();
         final String logginUser = AuthenticationUtil.getFullyAuthenticatedUser();
         NodeRef personNodereff = serviceRegistry.getPersonService().getPerson(logginUser);
         List<ChildAssociationRef> childAssocList = serviceRegistry.getNodeService().getChildAssocs(personNodereff,
             ASSOC_NAME_MYFAVORITE_ASSOCIATE, RegexQNamePattern.MATCH_ALL);
         if (childAssocList.size() > 0)
         {
             for (ChildAssociationRef child : childAssocList)
             {
                 NodeRef childNodeRef = child.getChildRef();
                 customFablist.add(childNodeRef);
             }
         }
             if (serviceRegistry.getNodeService().hasAspect(nodeRef,
                 ContentModel.ASPECT_WORKING_COPY))
             {
            	 isCheckedOut = true;
                 workingCopyOwner = serviceRegistry
                         .getNodeService()
                             .getProperty(nodeRef, ContentModel.PROP_WORKING_COPY_OWNER)
                             .toString();
                 originalnoderef = (NodeRef) serviceRegistry
                         .getCheckOutCheckInService()
                             .getCheckedOut(nodeRef);
             }
             if ((workingCopyOwner != null && workingCopyOwner.equals(logginUser))
                     || UpdateExpiringDateForDocuments.getNodeUserPermissions(nodeRef,logginUser))
             {
                 canUserCancelCheckout = true;
             }
             
             if (originalnoderef != null)
             {
                 isFavorite = customFablist.contains(originalnoderef);
             }
             else
             {
                 isFavorite = customFablist.contains(nodeRef);
             }
             
	             hashmap.put("canUserCancelWorkflow", canUserCancelWorkflow);
	             hashmap.put("canUserCancelCheckout", canUserCancelCheckout);
	             hashmap.put("isFavorite", isFavorite);
	             hashmap.put("hasSubFolder", hasSubFolder);
	             hashmap.put("isCheckedOut", isCheckedOut);
				LOG.info("getUserPropsMap hashmap--------"+hashmap);
		return hashmap;
	}

	// Getting sorted list of data
	public List<ExtDocument> getSortedList(final List<NodeRef> nodeRefList,final String sortBy,final String sortOrder) {
		LOG.info("sortBy in getSortedList----" + sortBy);
		LOG.info("sortOrder in getSortedList-----" + sortOrder);
		LOG.info("nodeRefList size-----" + nodeRefList.size());
		
		final List<ExtDocument> listExtDocsFilterList = new ArrayList<ExtDocument>();
       try{
    	   AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
           {
               @Override
               public Object doWork() throws Exception
               {
    	   
       // PRBADAM START: setting nodes props based on input from UI
       for (int i = 0; i < nodeRefList.size(); i++)
       {
           ExtDocument extDocsObj = new ExtDocument();
           extDocsObj.setNodeId(nodeRefList.get(i).toString());
           boolean isDocument = serviceRegistry.getDictionaryService().isSubClass(serviceRegistry.getNodeService().getType(nodeRefList.get(i)), ContentModel.TYPE_CONTENT);
       	if(isDocument){
            if (sortBy.equalsIgnoreCase("created"))
            {
                Date creSort = (Date) serviceRegistry.getNodeService().getProperty(nodeRefList.get(i),
                    ContentModel.PROP_CREATED);
                extDocsObj.setCreationdate(ExternalSharingFileFolderUtil
                        .getGMTDateFormat(((Date) creSort)));
            }
            else if (sortBy.equalsIgnoreCase("title"))
            {
                String titleSort = (String) serviceRegistry.getNodeService().getProperty(
                    nodeRefList.get(i), ContentModel.PROP_TITLE);
                extDocsObj.setTitle(ISO9075.decode(CharUtil.replaceEscape(titleSort)));
            }
            else if (sortBy.equalsIgnoreCase("size"))
            {
                long sizeSort = ((ContentData) serviceRegistry.getNodeService().getProperty(
                    nodeRefList.get(i), ContentModel.PROP_CONTENT)).getSize();
                extDocsObj.setSize((int) (sizeSort));
            }
            else if (sortBy.equalsIgnoreCase("type"))
            {
                String nameProp = (String) serviceRegistry.getNodeService().getProperty(
                    nodeRefList.get(i), ContentModel.PROP_NAME);
                nameProp = CharUtil.replaceEscape(nameProp);
                extDocsObj.setType(nameProp.substring(nameProp.lastIndexOf(".") + 1, nameProp.length()));
            }
            else if (sortBy.equalsIgnoreCase("edcsId"))
            {
            	String edcsID = (String) serviceRegistry.getNodeService().getProperty(nodeRefList.get(i), ExternalSharingConstants.PROP_EDCS_ID);
            	if(edcsID != null && !edcsID.isEmpty()){
            		extDocsObj.setEdcsId(edcsID);
            	} else {
            		extDocsObj.setEdcsId("-");
            	}
            }
	   	} 
       	else {
	           if (sortBy.equalsIgnoreCase("created"))
	           {
	               Date creSort = (Date) serviceRegistry.getNodeService().getProperty(nodeRefList.get(i),
	                   ContentModel.PROP_CREATED);
	               extDocsObj.setCreationdate(ExternalSharingFileFolderUtil
	                       .getGMTDateFormat(((Date) creSort)));
	           }
	           else if (sortBy.equalsIgnoreCase("title"))
	           {
	               String titleSort = (String) serviceRegistry.getNodeService().getProperty(
	                   nodeRefList.get(i), ContentModel.PROP_TITLE);
	               extDocsObj.setTitle(ISO9075.decode(CharUtil.replaceEscape(titleSort)));
	           }
	           else if (sortBy.equalsIgnoreCase("type"))
	           {
	               String nameProp = (String) serviceRegistry.getNodeService().getProperty(
	                   nodeRefList.get(i), ContentModel.PROP_NAME);
	               nameProp = CharUtil.replaceEscape(nameProp);
	               extDocsObj.setType(nameProp.substring(nameProp.lastIndexOf(".") + 1, nameProp.length()));
	           }
	   	}
           listExtDocsFilterList.add(extDocsObj);
       } // end of for loop
       // End of setting nodes props based on input from UI

       // Sorting started based on filter using comparator
       if (sortOrder == null || sortOrder == "" || sortOrder.equalsIgnoreCase("asc"))
       {
           if (sortBy == null || sortBy == "" || sortBy.equalsIgnoreCase("created"))
               Collections.sort(listExtDocsFilterList, Viewfav.createddateComparator);
           else if (sortBy.equalsIgnoreCase("title"))
               Collections.sort(listExtDocsFilterList, Viewfav.titleComparator);
           else if (sortBy.equalsIgnoreCase("size"))
               Collections.sort(listExtDocsFilterList, Viewfav.sizeComparator);
           else if (sortBy.equalsIgnoreCase("type"))
               Collections.sort(listExtDocsFilterList, Viewfav.typeComparator);
           else if (sortBy.equalsIgnoreCase("edcsId"))
               Collections.sort(listExtDocsFilterList, Viewfav.edcsIdComparator);
       }
       else if (sortOrder != null && sortOrder.equalsIgnoreCase("desc"))
       {
           if (sortBy == null || sortBy == "" || sortBy.equalsIgnoreCase("created"))
               Collections.sort(listExtDocsFilterList, Viewfav.createddateDescComparator);
           else if (sortBy.equalsIgnoreCase("title"))
               Collections.sort(listExtDocsFilterList, Viewfav.titleDescComparator);
           else if (sortBy.equalsIgnoreCase("size"))
               Collections.sort(listExtDocsFilterList, Viewfav.sizeDescComparator);
           else if (sortBy.equalsIgnoreCase("type"))
               Collections.sort(listExtDocsFilterList, Viewfav.typeDescComparator);
           else if (sortBy.equalsIgnoreCase("edcsId"))
               Collections.sort(listExtDocsFilterList, Viewfav.edcsIdDescComparator);
       }
       return null;
               }
           }, "admin");
       
       } catch (Exception e) {
    	   e.printStackTrace();
		 LOG.info("Exception in getSortedList---" + e);
	}
       
       LOG.info("listExtDocsFilterList size----" + listExtDocsFilterList.size());
       return listExtDocsFilterList;
	}
	//prbadam End: US8971-Search related changes
	
	//Uthra start :  GCS Changes
	
	public NodeRef liveNode(NodeRef node) {
		LOG.info("node  :: " +node );
		NodeRef nodeRef = null;
		 VersionHistory versionHistory = serviceRegistry.getVersionService().getVersionHistory(node);
	        if (versionHistory != null && versionHistory.getAllVersions().size() > 0)
	        {
	            Collection<Version> versions = versionHistory.getAllVersions();

	            for (Version versionNode : versions)
	            {
	               // Properties from VersioNode
	                 nodeRef = versionNode.getVersionedNodeRef();
	                LOG.info(" nodeRef  :: " +nodeRef);
	                break;
	               
	            }

	        }
			return nodeRef;
	        
		
	}	
	
	public NodeRef versionNode(NodeRef node,String versionNumber) {
		NodeRef vNodeRef = null;
	        Map<QName, Serializable> nodeProp = nodeService.getProperties(node);
	        VersionHistory versionHistory = serviceRegistry.getVersionService().getVersionHistory(node);
	        
	        if (versionHistory != null && versionHistory.getAllVersions().size() > 0)
	        {
	            Collection<Version> versions = versionHistory.getAllVersions();
                for (Version versionNode : versions)
	            {
	                NodeRef vnodeRef = versionNode.getFrozenStateNodeRef();
	                LOG.info(" vnodeRef  :: " +vnodeRef);
	                String versionLabel = versionNode.getVersionLabel();
	                
	              if(versionLabel.equals(versionNumber)){
	            	 vNodeRef = vnodeRef;
	            	  break;
	            }
                }
	        }
			return vNodeRef;
	}	
	//Uthra end :  GCS Changes
	
	/**
	 * Vera protected docs file names allways ends with .html extension to the original filename.
	 * If the document is protected with vera, then append .html extension to the file name
	 */
	// fetching vera protected value
	public String getVeraProtectionValue(NodeRef nodeRef) {
	String veraProtectionValue;
	Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);
	QName type = nodeService.getType(nodeRef);
	if (type.equals(ContentModel.TYPE_FOLDER))
    {
		veraProtectionValue = (String) nodeProp.get(ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
    } 
	else {
    String applyVeraProtection = ExternalSharingFileFolderUtil.getFolderVeraProtectionStatus(nodeRef, serviceRegistry);
    LOG.info("applyVeraProtection----------" + applyVeraProtection);
	if(applyVeraProtection != null && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))){
    	veraProtectionValue = applyVeraProtection;
    } else {
    	veraProtectionValue = "";
    }
    }
	return veraProtectionValue;
	}
	// fetching vera protected value
	
	//prbadam Start: DE3842
	public static String getNavigateToFolderNode(String logginUser, NodeRef nodeRef) {
	 String folderNode = null;
	 List<ChildAssociationRef> parentRefs = nodeService.getParentAssocs(nodeRef,ContentModel.ASSOC_CONTAINS, RegexQNamePattern.MATCH_ALL);
     if (parentRefs != null && parentRefs.size() > 0)
     {
    	 LOG.info("parentRefs size....:" + parentRefs.size());
         if (parentRefs.size() > 0)
         {
        	 NodeRef folderId = parentRefs.get(0).getParentRef();
        	 LOG.info("folderId----------" + folderId);
        	 
        	if(Viewfav.hasPermission(folderId,logginUser, serviceRegistry))
        	{
        		folderNode = folderId.toString();
        	 }else{
        		 folderNode = "";
        	 }
             }
         }
	return folderNode;
	}
	//prbadam End: DE3842
	
   //DE4447-Start
   public void setPublisherAsAuthenticatedUser(String userName) {
			AuthenticationUtil.setFullyAuthenticatedUser(userName);
			AuthenticationUtil.setRunAsUser(userName);
		}
		
}
