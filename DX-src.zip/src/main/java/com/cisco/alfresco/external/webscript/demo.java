package com.cisco.alfresco.external.webscript;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

public class demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		myObj = { "name":"John", "age":30, "car":null };
		x = myObj.name;
		jsonString.toString();
		System.out.println((jsonString.getClass().getName()));
		
		
		//JSONObject jsonObject = new JSONObject(jsonString);
		//JSONObject object = (JSONObject) JSONValue.parse(jsonString);
		Object name = null;
	//	Object age =object.get(name);
	//	System.out.println(age);
		

	}

}