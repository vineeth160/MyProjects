package com.cisco.alfresco.external.upload.notification;


import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.processor.BaseProcessorExtension;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.TemplateService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.PersonService;
import org.apache.log4j.Logger;

import com.cisco.alfresco.edcsng.util.MailUtil;
import com.cisco.alfresco.edcsng.util.UserPermissionUtil;

public class UploadDocumentNotification extends BaseProcessorExtension{
   
	public static Logger LOG = Logger.getLogger(UploadDocumentNotification.class);
		
	static ServiceRegistry serviceRegistry; 
	private PersonService personService;
	private static String mailServer;
	private String from;
	private static String subjectLine;
	private static String bannerAlfrescoUrl;
	private static String titleURL;
	private static TemplateService templateService;
	public static String UPLOADDOCUMENT_NOTIFICATION_TEMPLATE = "/alfresco/extension/templates/email/UploadDocumentNotification.ftl";
	/*private static String ftlLocationPath;
	public String getFtlLocationPath() {
		return ftlLocationPath;
	}

	public void setFtlLocationPath(String ftlLocationPath) {
		UploadDocumentNotification.ftlLocationPath = ftlLocationPath;
	}
  */
	public String getTitleURL() {
		return titleURL;
	}

	public void setTitleURL(String titleURL) {
		UploadDocumentNotification.titleURL = titleURL;
	}

	public String getBannerAlfrescoUrl() {
		return bannerAlfrescoUrl;
	}

	public void setBannerAlfrescoUrl(String bannerAlfrescoUrl) {
		UploadDocumentNotification.bannerAlfrescoUrl = bannerAlfrescoUrl;
	}

	public String getMailServer() {
		return mailServer;
	}

	public void setMailServer(String mailServer) {
		UploadDocumentNotification.mailServer = mailServer;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getSubjectLine() {
		return subjectLine;
	}

	public void setSubjectLine(String subjectLine) {
		UploadDocumentNotification.subjectLine = subjectLine;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		UploadDocumentNotification.serviceRegistry = serviceRegistry;
	}
    
	public PersonService getPersonService() {
		return personService;
	}

	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}

	
	public void uploadNewDocumentVersionNotif(String strNodeRef,String publisher) throws Exception{
		    LOG.info("Inside uploadDocumentVersionNotif");
		    NodeRef nodeRef = new NodeRef(strNodeRef);
		    LOG.info("nodeRef::::::::::::::"+nodeRef);
		    Set<AccessPermission> accessPermissions = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);	
		    LOG.info("accessPermissions:::::::::::"+accessPermissions);
		    actualFilePermission(accessPermissions,nodeRef,publisher);
         }

	 public void uploadNewDocumentNotify(String nodeRef,String publisher,String fileTitle) throws Exception{
		 LOG.info("Inside uploadNewDocumentNotify");
		 LOG.info("nodeRef----------"+nodeRef);
		 NodeRef nodeReff = new NodeRef(nodeRef);
		 Set<AccessPermission> nodePermissions = new HashSet<AccessPermission>();
	     nodePermissions = serviceRegistry.getPermissionService().getAllSetPermissions(nodeReff);
         LOG.info("nodePermissions-------"+nodePermissions);
		 actualFilePermission(nodePermissions,nodeReff,publisher);
	    }
  
	 private void actualFilePermission(Set<AccessPermission> actualPermissions,NodeRef nodeRef,String publisher) throws Exception {
		 LOG.info("Inside actualFilePermission");
		 String docTitle=null;
		 String docversion=null;
	     PersonService personService = UploadDocumentNotification.serviceRegistry.getPersonService();
		 HashSet<String> InheritedUserSet = new HashSet<String>();
		 Iterator<AccessPermission> fIterator = actualPermissions.iterator(); 
         NodeRef publisherNode = serviceRegistry.getPersonService().getPerson(publisher);
         String publisherMailId = (String) serviceRegistry.getNodeService().getProperty(publisherNode,ContentModel.PROP_EMAIL);
    	 LOG.info("publisherMailId-------"+publisherMailId);
    	 docTitle = (String)serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_TITLE);
		 LOG.info("docTitle outside null check ::::::::::"+docTitle);
		    if(docTitle == null || docTitle.equals("")){
		    	docTitle = (String)serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NAME);
		    	LOG.info("docTitle inside null check ::::::::::"+docTitle);
		    }
		 if((String)serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_VERSION_LABEL) !=null){
		    	docversion=(String)serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_VERSION_LABEL);
	   		}else{
	   			docversion= "1.0";
	   		}
		 while (fIterator.hasNext()){
             AccessPermission accessPermission = fIterator.next();
             if (accessPermission.getAuthorityType() == AuthorityType.USER){
      	    	   NodeRef per = personService.getPerson(accessPermission.getAuthority());  
      	    	   String inheritedUserEmail = (String)UploadDocumentNotification.serviceRegistry.getNodeService().getProperties(per).get(ContentModel.PROP_EMAIL);
      	    	   InheritedUserSet.add(inheritedUserEmail);
             }
		   } 
		 	LOG.info("InheritedUserSet to send mail---------->"+InheritedUserSet);
		  	emailNotify(InheritedUserSet,publisher,publisherMailId,docversion,docTitle);
	}

	 // START US5919: prbadam moved Publish Notification component from Doc Central to Doc Exchange, because for first time inherited users(from Doc Exchange) are not coming in mail.  
	 public static void publishNotificationDetails(NodeRef extNodeRef, ServiceRegistry serviceRegistry) throws Exception {
		 String publishVersion=null;
		 String publishDocTitle=null;
		 	LOG.info("external noderef-----------"+extNodeRef);
		 	Serializable publisher = serviceRegistry.getNodeService().getProperty(extNodeRef, ContentModel.PROP_CREATOR);
		 	publishVersion = (String)serviceRegistry.getNodeService().getProperty(extNodeRef, ContentModel.PROP_VERSION_LABEL);
		 	publishDocTitle = (String)serviceRegistry.getNodeService().getProperty(extNodeRef, ContentModel.PROP_TITLE);
			    if(publishDocTitle == null || publishDocTitle.equals("")){
			    	publishDocTitle = (String)serviceRegistry.getNodeService().getProperty(extNodeRef, ContentModel.PROP_NAME);
			    	LOG.info("publishDocTitle inside null check ::::::::::"+publishDocTitle);
			    }
			LOG.info("publisher-------"+publisher+" publishVersion-------"+publishVersion);
			NodeRef publisherNode = serviceRegistry.getPersonService().getPerson((String) publisher);
		    String publisherMailId = (String) serviceRegistry.getNodeService().getProperty(publisherNode,ContentModel.PROP_EMAIL);
	    	LOG.info("publisherMailId in publishNotificationDetails------"+publisherMailId);
			List<HashMap<String,String>> userPerHashMapList = UserPermissionUtil.getPermissions(extNodeRef,serviceRegistry);
			LOG.info("userPerHashMapList----------" +userPerHashMapList);
		 
			 List<String> emailList = new ArrayList<String>();
			 Iterator<HashMap<String,String>> it =  userPerHashMapList.iterator();
			    while (it.hasNext()) {
			    	HashMap<String,String> emailMap = it.next();
			    	emailList.add(emailMap.get("email"));
			    }
			    HashSet<String> emailHashList = new HashSet<String>(emailList);
			    LOG.info("emailHashList to send mail--------->" +emailHashList);
			    emailNotify(emailHashList,publisher.toString(),publisherMailId,publishVersion,publishDocTitle);
	 }
	 // END US5919: prbadam moved Publish Notification component from Doc Central to Doc Exchange, because for first time inherited users(from Doc Exchange) are not coming in mail.
	 

	 private static  void emailNotify(HashSet<String> docUserEmailIDs,String publisher, String publisherMailId,String version,String docTitle) throws Exception {
		Map<String, Object> model = new HashMap<String, Object>();
		String emailBody = null;
		String from = publisherMailId;
		Date currentDate = new Date();
		templateService = serviceRegistry.getTemplateService();
		//NodeRef template = getEmailtemplate(UPLOADDOCUMENT_NOTIFICATION_TEMPLATE);  
		String year = new SimpleDateFormat("yyyy").format(currentDate);
		String publisherFName = (String)serviceRegistry.getNodeService().getProperty(
				serviceRegistry.getPersonService().getPerson(publisher),
				ContentModel.PROP_FIRSTNAME);
		String publisherLName = (String)serviceRegistry.getNodeService().getProperty(
				serviceRegistry.getPersonService().getPerson(publisher),
				ContentModel.PROP_LASTNAME);
		String publisherFullName = publisherFName + " " + publisherLName;
		LOG.info("year :::::::"+year+"::publisherFullName :::::"+publisherFullName+"::from :::::"+from+"::fileURL::::"+titleURL);
		String subject = publisherFullName + " " +subjectLine;
		LOG.info("docTitle::::"+docTitle+"::version::::"+version);
		model.put("DocumentTitle", docTitle);
		model.put("Version", version);
		model.put("PublisherName", publisherFullName);
		model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
		model.put("year", year);
		model.put("titleURL", titleURL);
		emailBody = templateService.processTemplate(UPLOADDOCUMENT_NOTIFICATION_TEMPLATE, model);
		 // START US5962: Bcc owners of the file when publishing a document instead of keeping them in the to field
		for(String email : docUserEmailIDs){
			MailUtil.sendMail(mailServer, from, new String[]{email}, null, subject, emailBody, null);
		}
		// END US5962: Bcc owners of the file when publishing a document instead of keeping them in the to field
		LOG.info("Mail sent successfully from UploadDocumentNotification.java--------->ok");
	}
	
	 /**
     * To Get Email Template Noderef
     */
   /* private static NodeRef getEmailtemplate(String templateName)
    {
        String templateConditionalPath = "PATH:\"" + ftlLocationPath + "//*\" AND "
                + "TYPE:cm\\:content AND @cm\\:name:\"" + templateName + "\"";
        LOG.debug("LUCENE QRY: " + templateConditionalPath);
        ResultSet resultSet = serviceRegistry.getSearchService().query(
            new StoreRef(StoreRef.PROTOCOL_WORKSPACE, "SpacesStore"), SearchService.LANGUAGE_LUCENE,
            templateConditionalPath);
        if (resultSet.length() == 0)
        {
        	LOG.error("Template " + templateConditionalPath + " not found.");
            return null;
        }
        NodeRef template = resultSet.getNodeRef(0);
        LOG.debug("Got the Email Template:" + template.toString());
        return template;
        }
*/
}
