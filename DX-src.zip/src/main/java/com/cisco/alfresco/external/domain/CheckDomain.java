package com.cisco.alfresco.external.domain;


import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.download.DownloadModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.version.Version2Model;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;

/**Validates user domainname with folder domainname
 * 
 * @author uellappa
 */
public class CheckDomain extends DeclarativeWebScript {
	private static final Logger LOGGER = Logger.getLogger(CheckDomain.class);
	
    private static NodeService nodeService;
	private static ExternalLDAPUtil ldapUtil;
	

    public ExternalLDAPUtil getLdapUtil()
    {
        return ldapUtil;
    }

    public void setLdapUtil(ExternalLDAPUtil ldapUtil)
    {
        this.ldapUtil = ldapUtil;
    }

	public NodeService getNodeService() {
		return nodeService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}
	
	
	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest req,
			Status status, Cache cache) {
		
		Map<String, Object> modelStatus = new HashMap<String, Object>();
		try {
			String currentNodeRef = req.getParameter("currentNodeRef");
			modelStatus = getDomainStatus(currentNodeRef);
			LOGGER.info("model status------" + modelStatus);
	}
		catch (Exception exception) {
			LOGGER.error("############Exception at this point"+exception.getMessage());
			status.setCode(Status.STATUS_INTERNAL_SERVER_ERROR);
			setMessage(String.valueOf(Status.STATUS_INTERNAL_SERVER_ERROR), exception.getMessage(),modelStatus);
		}
			return modelStatus;
	}
	
	public static  Map<String, Object> getDomainStatus(String currentNodeRef){
		
		final Map<String, Object> model = new HashMap<String, Object>();
		final String delimiter = "@";
		final NodeRef currentNodeReff;
		final QName DOMAIN_QNAME = QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name");
		
		if(currentNodeRef != null && nodeService.exists(new NodeRef(currentNodeRef)))
		{
		LOGGER.info("Current node ref :::" + currentNodeRef);
		currentNodeReff = new NodeRef(currentNodeRef);
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				
				final QName type = nodeService.getType(currentNodeReff);
				LOGGER.info(" Type ===>>>"+type);
				if(type.equals(DownloadModel.TYPE_DOWNLOAD)){
					setMessage("200", " Given Node is Download Type",model);
					LOGGER.info("Given Node is Download Type");
				} else {
							String domainName = null;
							if (type.equals(ContentModel.TYPE_FOLDER)) {
								domainName = (String) nodeService.getProperty(currentNodeReff,DOMAIN_QNAME);
							} else {
								LOGGER.info("if check  :: " +Version2Model.STORE_ID  + "next part ::  " +currentNodeReff.getStoreRef().getIdentifier());
								if (Version2Model.STORE_ID.equals(currentNodeReff.getStoreRef().getIdentifier())) // "version2Store"
						        {
								  NodeRef currentNodeRef = new NodeRef(StoreRef.PROTOCOL_WORKSPACE, Version2Model.STORE_ID, currentNodeReff.getId());
							        LOGGER.info("currentNodeRef ------------  " +currentNodeRef);
						            NodeRef  frozenNodeRef= (NodeRef) nodeService.getProperty(currentNodeRef, Version2Model.PROP_QNAME_FROZEN_NODE_REF);
						            LOGGER.info("frozenNodeRef : " + frozenNodeRef);
						            ChildAssociationRef childAssociationRef = nodeService.getPrimaryParent(frozenNodeRef);
									NodeRef parentNodeRef = childAssociationRef.getParentRef();
									LOGGER.info("Parent folder id inside if :::"+ parentNodeRef);
									domainName = (String) nodeService.getProperty(parentNodeRef,DOMAIN_QNAME);
									LOGGER.info("doamin name ele bloack inside if  ::: " +domainName);
						        }
								else{
						            ChildAssociationRef childAssociationRef = nodeService.getPrimaryParent(currentNodeReff);
								NodeRef parentNodeRef = childAssociationRef.getParentRef();
								LOGGER.info("Parent folder id :::"+ parentNodeRef);
								domainName = (String) nodeService.getProperty(parentNodeRef,DOMAIN_QNAME);
								LOGGER.info("domain name ele block  ::: " +domainName);
						        }
							}
							if(domainName != null)
							{
								domainName = domainName.trim();
							}

							LOGGER.info("checking if node is having domain aspect or not");


							String strManagerID = null;
							String[] temp;
							if (domainName != null && domainName.length() > 0 && !domainName.equalsIgnoreCase("")) {
								String[] domains = domainName.split(",");
								
								String currentUserName = AuthenticationUtil.getFullyAuthenticatedUser();
								LOGGER.info("Current Username :::"+ currentUserName);
								strManagerID = ldapUtil.getManagerEmailFromLDAP(currentUserName);
								LOGGER.info("Current user Email Id :::"+ strManagerID);
								if (strManagerID != null && strManagerID.length() > 0) {
									temp = strManagerID .split(delimiter);
									String emailId = temp[1];
									if (emailId.equalsIgnoreCase("cisco.com")) {
										setMessage("200","Cisco Internal user",model);
									} else {
										boolean bMatched = true;
										if(domains.length > 0){
											for(String domain : domains){
												if (domain.toLowerCase().replaceAll(" ", "").equalsIgnoreCase(emailId.toLowerCase())) {
													setMessage("200","Email and Domain name are same",model);
													LOGGER.info("Email and Domain name are same");
													return model;
												} else{
													bMatched = false;
												}
											}
										}else{
											setMessage("200", "Domain Name is Null",model);
											LOGGER.info("Domain Name is Null");
										}
										if(!bMatched){
											setMessage("401","Email and Domain name are not equal",model);
											LOGGER.info("Email and Domain name are not equal");
										}
									}
								} else {
									setMessage("200","EMail was not registered for user",model);
									LOGGER.info("EMail was not registered for user");
								}

							} else {
								setMessage("200", "Domain Name is Null",model);
								LOGGER.info("Domain Name is Null");
							}
		}
		return null;
		}
	}, "admin");
		}else{
			
			CheckDomain.setMessage("404","The file you are trying to access is no longer available, please contact your Cisco representative",model);
			LOGGER.info("The file you are trying to access is no longer available, please contact your Cisco representative");
		
		}
		return model;
	}

	
	/** 
     * @param status
     * @param message
     * @param model
     */
	public static void setMessage(String status, String message,Map<String, Object> model) {
		model.put("status1", status);
		model.put("message",message);
		
	}

}