package com.cisco.alfresco.external.webscript;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.InvalidQNameException;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.ISO9075;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.external.common.model.Folder;
import com.cisco.alfresco.external.common.model.FolderList;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.alfresco.external.utils.CharUtil;


public class PublishTargetFolderList extends DeclarativeWebScript
{
	private static final Logger LOGGER = Logger.getLogger(PublishTargetFolderList.class);
	private NodeService nodeService;
	private ServiceRegistry serviceRegistry;
	private PreferenceService preferenceService;

	public void setPreferenceService(PreferenceService preferenceService)
	{
		this.preferenceService = preferenceService;
	}

	@Override
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
	{
		if (LOGGER.isDebugEnabled())
			LOGGER.debug("------------- PublishTargetFolderList executeImpl ----------");
		final Map<String, Object> model = new HashMap<String, Object>();
		String currentUser=AuthenticationUtil.getFullyAuthenticatedUser();
		String publisherId = req.getParameter("publisherId");
		if (LOGGER.isDebugEnabled())
		LOGGER.debug(" In case of caling PublishTargetFolderList with publisherId ::: "+publisherId);
		if(publisherId!=null && !publisherId.isEmpty()){
			AuthenticationUtil.setRunAsUser(publisherId);
			currentUser =publisherId;
		}
		if (LOGGER.isDebugEnabled())
		LOGGER.debug("FullyAuthenticatedUser:::::: ::: "+AuthenticationUtil.getFullyAuthenticatedUser());
		try
		{
			FolderList searchList = getFolderList(currentUser);
			if (LOGGER.isDebugEnabled())
			{
				LOGGER.debug("Result JSON Size: " + searchList.getFolderList().size());
				LOGGER.debug("Result JSON : " + searchList.toString());
			}
			model.put("result", searchList);
		}
		catch (InvalidNodeRefException ine)
		{
			LOGGER.error("InvalidNodeRefException : " + ine);
		}
		catch (Exception e)
		{
			LOGGER.error("Exception : " + e);
		}

		return model;
	}

	/**
	 * 
	 * @return FolderList
	 */
	private FolderList getFolderList(String currentUser)
	{
		FolderList library = new FolderList();
		try
		{
			if (LOGGER.isDebugEnabled()){
			LOGGER.debug(" In case of caling PublishTargetFolderList with publisherId ::: "+currentUser);
			}
			/**
			 * Get ExternalSharealeAspect Folders
			 */
			List<NodeRef> externalShareableAspectFolderList = getExternalShareableAspectFolderList(currentUser);
			if (LOGGER.isDebugEnabled())
				LOGGER.debug("externalShareableAspectFolderList size : " + externalShareableAspectFolderList.size());

			/**
			 * Get Preference Folders
			 */
			List<NodeRef> preferenceFolderList = getPreferenceFolderList(currentUser);
			if (LOGGER.isDebugEnabled())
				LOGGER.debug("preferenceFolderList size : " + preferenceFolderList.size());

			Set<NodeRef> folderSet = new HashSet<NodeRef>();
			folderSet.addAll(externalShareableAspectFolderList);
			folderSet.addAll(preferenceFolderList);
			List<NodeRef> uniqueFolderList = new ArrayList<NodeRef>(folderSet);
			if (LOGGER.isDebugEnabled())
				LOGGER.debug("uniqueFolderList size : " + uniqueFolderList.size());


			// Populate Folder Library List
			library.setFolderList(populateFolderInfo(currentUser, uniqueFolderList));
			if (LOGGER.isDebugEnabled())
				LOGGER.debug("Successfuly added list to library-------");
		}
		catch (InvalidQNameException e)
		{
			LOGGER.error("Exception :", e);
		}
		catch (InvalidNodeRefException e)
		{
			LOGGER.error("Exception :", e);
		}
		catch (Exception e)
		{
			LOGGER.error("Exception :", e);
		}

		return library;
	}

	/**
	 * 
	 * @param currentUser
	 * @return
	 */
	private List<NodeRef> getExternalShareableAspectFolderList(String currentUser)
	{
		if (LOGGER.isDebugEnabled())
			LOGGER.debug("getExternalShareableAspectFolderList method");
		List<NodeRef> extShareableAspectFolderList = new ArrayList<NodeRef>();

		String searchQuery = "PATH:\"/app:company_home/st:sites/cm:edcsng//*\" AND TYPE:\"cm:folder\" AND ASPECT:\"ext:extShareableAspect\"";
		List<NodeRef> nodeRefList = EDCSUtil.getNodeRefList(searchQuery, serviceRegistry);

		if (LOGGER.isDebugEnabled())
		{
			LOGGER.debug("searchQuery : " + searchQuery);
			LOGGER.debug("Before perm check nodeRefList size: " + nodeRefList.size());
		}

		if (nodeRefList != null && nodeRefList.size() > 0)
		{
			for (NodeRef nodeRef : nodeRefList)
			{
				try
				{
					if (LOGGER.isDebugEnabled())
						LOGGER.debug("hasPermission on NodeRef : " + nodeRef + ", currentUser :" + currentUser);
					boolean hasPermission = ExternalSharingFileFolderUtil.hasAccess(currentUser, nodeRef,
							serviceRegistry);
					if (hasPermission)
					{
						extShareableAspectFolderList.add(nodeRef);
					}
				}
				catch (Exception e)
				{
					LOGGER.error("Exception in getExternalShareableAspectFolderList():" + e);
				}
			}
		}

		return extShareableAspectFolderList;
	}

	/**
	 * 
	 * @param currentUser
	 * @return
	 */
	private List<NodeRef> getPreferenceFolderList(final String currentUser)
	{
		if (LOGGER.isDebugEnabled())
		{
			LOGGER.debug("getPreferenceFolderList method");
		}
		List<NodeRef> preferenceFolderList = new ArrayList<NodeRef>();
		try
		{
			final String preferenceFilter = "org.alfresco.share.folders.favourites";
			final Map<String, Serializable> currentPreferencesFolder = preferenceService.getPreferences(currentUser,
					preferenceFilter);

			if (LOGGER.isDebugEnabled())
			{
				LOGGER.debug("PreferenceFolderList : " + currentPreferencesFolder);
			}

			if (currentPreferencesFolder.containsKey(preferenceFilter))
			{
				preferenceFolderList=AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<List<NodeRef>>()
					{
						@Override
						public List<NodeRef> doWork() throws Exception
						{
							List<NodeRef> prefFolderList = new ArrayList<NodeRef>();
							String item = (String) currentPreferencesFolder.get(preferenceFilter);

							if (item.indexOf(",") != -1 && item.indexOf(",") < 2)
							{
								item = item.substring(1);
							}
							String[] itemArray = item.trim().split(",");
							LOGGER.debug("Before perm check prefFolderList size: " + itemArray.length);
							for (int i = 0; i < itemArray.length; i++)
							{
								final NodeRef nodeRef = new NodeRef(itemArray[i]);
							if (serviceRegistry.getNodeService().exists(nodeRef))
							{
								if (LOGGER.isDebugEnabled())
								{
									LOGGER.debug("hasPermission on NodeRef : " + nodeRef + ", currentUser :"
											+ currentUser);
								}

								final boolean hasFolderPermission = ExternalSharingFileFolderUtil.hasAccess(
										currentUser, nodeRef, serviceRegistry);
								if (hasFolderPermission)
								{
									prefFolderList.add(nodeRef);
								}
							}
							
						}
							return prefFolderList;
						}
							}, "admin");
				//}
			}
		}
		catch (Exception e)
		{
			LOGGER.error("Exception in getPreferenceFolderList : ", e);
		}
		return preferenceFolderList;
	}

	/**
	 * 
	 * @param currentUserName
	 * @param uniqueFolderList
	 * @param myFavoritesFolderList
	 * @return
	 */
	private List<Folder> populateFolderInfo(String currentUserName, List<NodeRef> uniqueFolderList)
	{
		List<Folder> folderList = new ArrayList<Folder>();
		for (NodeRef nodeRef : uniqueFolderList)
		{
			Folder folder = new Folder();
			Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);

			String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
			fileName = CharUtil.replaceEscape(fileName);
			folder.setName(ISO9075.decode(fileName));
			folder.setNodeId(nodeRef.toString());

			String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
			title = CharUtil.replaceEscape(title);
			folder.setTitle(ISO9075.decode(title));

			folder.setType("folder");
			folder.setPermissionLevel(ExternalSharingFileFolderUtil.getUserRole(serviceRegistry, currentUserName,
					nodeRef));

			folderList.add(folder);
		}
		return folderList;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry)
	{
		this.serviceRegistry = serviceRegistry;
	}

	/**
	 * @param nodeService
	 *            the nodeService to set
	 */
	public void setNodeService(NodeService nodeService)
	{
		this.nodeService = nodeService;
	}
	
}
