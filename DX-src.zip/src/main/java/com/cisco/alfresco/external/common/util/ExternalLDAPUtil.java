package com.cisco.alfresco.external.common.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AuthorityService;
import org.alfresco.service.cmr.security.MutableAuthenticationService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;

import com.cisco.alfresco.auth.ext.EXTEncrypter;


/**
 * 
 * @author gpotla nathammi
 * 
 */

public class ExternalLDAPUtil
{

    private static final Logger LOGGER = Logger.getLogger(ExternalLDAPUtil.class);
    private String ldapHost;// ="ldap://dsx.cisco.com:389";
    private String genericUser;
    private String genericPwd;
    private String genericKey;

    private ServiceRegistry serviceRegistry;
    private static String zoneId = AuthorityService.ZONE_AUTH_EXT_PREFIX + "ldap";

    private Set<String> getZones(final String zoneId)
    {
        Set<String> zones = new HashSet<String>(5);
        zones.add(AuthorityService.ZONE_APP_DEFAULT);
        zones.add(zoneId);
        return zones;
    }

    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    public String getGenericUser()
    {
        return genericUser;
    }

    public void setGenericUser(String genericUser)
    {
        this.genericUser = genericUser;
    }

    public String getGenericPwd()
    {
        return genericPwd;
    }

    public void setGenericPwd(String genericPwd)
    {
        this.genericPwd = genericPwd;
    }

    public String getGenericKey()
    {
        return genericKey;
    }

    public void setGenericKey(String genericKey)
    {
        this.genericKey = genericKey;
    }

    public String getLdapHost()
    {
        return ldapHost;
    }

    public void setLdapHost(String ldapHost)
    {
        this.ldapHost = ldapHost;
    }

    /** CONSTANTS USED */
    // static final String LDAP_HOST = "ldap://dsx.cisco.com:389";
    static final String LDAP_SEARCHBASE = "ou=ccoentities,o=cco.cisco.com";
    static final String GENERICS_LDAP_SEARCHBASE = "OU=Generics,O=cco.cisco.com";
    // static final String[] LDAP_ATTRIBUTES = {"sn", "accessLevel","uid", "mail", "cn", "givenname","co","company"};
    static final String LDAP_MAIL_ATTRIBUTES = "mail";// "uid";
    static final String LDAP_UID_ATTRIBUTES = "uid";
    static final String LDAP_CN_ATTRIBUTES = "cn";
    static final String LDAP_COMPANY_ATTRIBUTES = "company";
    static final String LDAP_ACCESS_LEVEL_ATTRIBUTE = "accessLevel";
    private static final String LDAP_SEARCH_ATTRIBUTE_NAME = "directReports";
    private static final String LDAP_USER_SEARCH_FILTER = "uid=";
    private static final String LDAP_EMPLOYEE_TYPE_ATTRIBUTES = "employeeType";
    private static final String LDAP_WHEN_CHANGED_ATTRIBUTES = "whenChanged";
    private static final String NA = "N/A";
    private static final String GENERICS_LDAP_ACCESS_LEVEL="4";
    /**
     * provides a User Object with LDAP details filled in for the specified user login name
     * 
     * @param aUserLoginName
     *            user Login Name (CEC id) of the user who's LDAP info is desired
     * @return a User Object with the LDAP information filled in for the specified user login name.
     * @throws ASTGException
     *             if unable to provide the LDAP details for the specified user login name
     */

    public String getManagerEmailFromLDAP(String userLoginName)
    {
        StringBuffer strBuffer = new StringBuffer();
        DirContext myDirContext = null;
        NamingEnumeration<SearchResult> mySearchResults = null;

        try
        {
            String myFilter = "(uid=" + userLoginName + ")";
            Hashtable myEnv = new Hashtable();
            myEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
            myEnv.put(Context.PROVIDER_URL, getLdapHost()); // ldap://dsx.cisco.com:389
            myEnv.put(Context.SECURITY_PRINCIPAL, genericUser);
            myEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(genericPwd, genericKey).getBytes("UTF8"));
            myDirContext = new InitialDirContext(myEnv);
            SearchControls mySearchControls = new SearchControls();
            mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            mySearchResults = myDirContext.search(LDAP_SEARCHBASE, myFilter, mySearchControls);
            if(mySearchResults == null || !mySearchResults.hasMore()){
              	 mySearchResults = myDirContext.search(GENERICS_LDAP_SEARCHBASE,myFilter,
                           mySearchControls );
              }
            SearchResult myNextEmployee;
            while (mySearchResults != null && mySearchResults.hasMore())
            {
                myNextEmployee = (SearchResult) mySearchResults.next();
                if (myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES) != null)
                {
                    String managerMail = myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES).get().toString();
                    strBuffer.append(managerMail);
                }
            }

        }
        catch (Exception e)
        {
            LOGGER.error(e);
            return null;
        }
        finally
        {
            try
            {
                if (mySearchResults != null)
                {
                    mySearchResults.close();
                }

                if (myDirContext != null)
                {
                    myDirContext.close();
                }
            }
            catch (NamingException ex)
            {
                LOGGER.error(ex);
            }
        }
        return strBuffer.toString();

    }

    /**
     * provides a User Object with LDAP details filled in for the specified user login name
     * 
     * @param aUserLoginName
     *            user Login Name (CEC id) of the user who's LDAP info is desired
     * @return a User Object with the LDAP information filled in for the specified user login name.
     * @throws ASTGException
     *             if unable to provide the LDAP details for the specified user login name
     */

    public String doSearchUserNamesFromLDAP(String userLoginName, String domain)
    {
        StringBuffer strBuffer = new StringBuffer();
        String domainFilter = "";
        DirContext myDirContext = null;
        NamingEnumeration<SearchResult> mySearchResults = null;

        try
        {
            if (domain != null && !domain.equals(""))
            {
                String[] domainList = domain.split(",");
                for (int p = 0; p < domainList.length && domainList.length > 0; p++)
                {
                    domainFilter = domainFilter + "|(mail=*" + domainList[p] + "*)";
                }
            }
            // String myFilter = "(&(mail=*"+domain+"*)(uid=" + userLoginName + "*))";
            String myFilter = null;
            if (!domainFilter.equals(""))
            {
                if (userLoginName != null && !userLoginName.equals(""))
                    myFilter = "(&(" + domainFilter + ")(uid=" + userLoginName + "*))";
                else
                    myFilter = "(&(" + domainFilter + ")(uid=*))";
            }
            else
            {
                myFilter = "(&(uid=" + userLoginName + "*))";
            }
            Hashtable myEnv = new Hashtable();
            myEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
            myEnv.put(Context.PROVIDER_URL, getLdapHost());
            myEnv.put(Context.SECURITY_PRINCIPAL, genericUser);
            myEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(genericPwd, genericKey).getBytes("UTF8"));
            myDirContext = new InitialDirContext(myEnv);
            SearchControls mySearchControls = new SearchControls();
            mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            mySearchResults = myDirContext.search(LDAP_SEARCHBASE, myFilter, mySearchControls);
            if(mySearchResults == null || !mySearchResults.hasMore()){
              	 mySearchResults = myDirContext.search(GENERICS_LDAP_SEARCHBASE,myFilter,
                           mySearchControls );
              }
            SearchResult myNextEmployee;
            int increment = 0;
            while (mySearchResults != null && mySearchResults.hasMore())
            {
                myNextEmployee = (SearchResult) mySearchResults.next();
                increment += 1;
                if (increment <= 25)
                {
                    if (myNextEmployee != null && myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES) != null)
                    {
                        String userName = myNextEmployee.getAttributes().get(LDAP_UID_ATTRIBUTES).get().toString();
                        String userMail = myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES).get().toString();
                        String completeName = myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES).get().toString();
                        String company = myNextEmployee.getAttributes().get(LDAP_COMPANY_ATTRIBUTES).get().toString();
                        if (company != null && company.equals("0"))
                        {
                            company = "";
                        }
                        if (company != null && company.contains(","))
                        {
                            company = company.replaceAll(",", "");
                        }
                        strBuffer
                                .append(userName)
                                    .append("::")
                                    .append(userMail)
                                    .append("::")
                                    .append(completeName)
                                    .append("::")
                                    .append(company)
                                    .append("::")
                                    .append(",");
                    }
                }
            }

        }
        catch (Exception e)
        {
            LOGGER.error(e);
            return null;
        }
        finally
        {
            try
            {
                if (mySearchResults != null)
                {
                    mySearchResults.close();
                }

                if (myDirContext != null)
                {
                    myDirContext.close();
                }
            }
            catch (NamingException ex)
            {
                LOGGER.error(ex);
            }
        }
        return strBuffer.toString();

    }

    public String getUserDetailsFromLDAP(String userLoginName)
    {
        StringBuffer strBuffer = new StringBuffer();
        DirContext myDirContext = null;
        NamingEnumeration<SearchResult> mySearchResults = null;
        try
        {
            String myFilter = "(uid=" + userLoginName + ")";
            Hashtable myEnv = new Hashtable();
            myEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
            myEnv.put(Context.PROVIDER_URL, getLdapHost()); // ldap://dsx.cisco.com:389
            myEnv.put(Context.SECURITY_PRINCIPAL, genericUser);
            myEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(genericPwd, genericKey).getBytes("UTF8"));
            myDirContext = new InitialDirContext(myEnv);
            SearchControls mySearchControls = new SearchControls();
            mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            mySearchResults = myDirContext.search(LDAP_SEARCHBASE, myFilter, mySearchControls);
            if(mySearchResults == null || !mySearchResults.hasMore()){
           	 mySearchResults = myDirContext.search(GENERICS_LDAP_SEARCHBASE,myFilter,
                        mySearchControls );
           }
            SearchResult myNextEmployee;
            while (mySearchResults != null && mySearchResults.hasMore())
            {
                myNextEmployee = (SearchResult) mySearchResults.next();
                if (myNextEmployee.getAttributes().get(LDAP_UID_ATTRIBUTES) != null)
                {
                    String userId = myNextEmployee.getAttributes().get(LDAP_UID_ATTRIBUTES).get().toString();
                    strBuffer.append(userId);
                }
                if (myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES) != null)
                {
                    String name = myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES).get().toString();
                    strBuffer.append("::" + name + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES) != null)
                {
                    String company = myNextEmployee.getAttributes().get(LDAP_COMPANY_ATTRIBUTES).get().toString();
                    strBuffer.append(company + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES) != null)
                {
                    String email = myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES).get().toString();
                    strBuffer.append(email + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_EMPLOYEE_TYPE_ATTRIBUTES) != null)
                {
                    String employeeType = myNextEmployee
                            .getAttributes()
                                .get(LDAP_EMPLOYEE_TYPE_ATTRIBUTES)
                                .get()
                                .toString();
                    strBuffer.append(employeeType + "::");
                }
                else
                {
                    String employeeType = NA;
                    strBuffer.append(employeeType + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_WHEN_CHANGED_ATTRIBUTES) != null)
                {
                    String whenChanged = myNextEmployee
                            .getAttributes()
                                .get(LDAP_WHEN_CHANGED_ATTRIBUTES)
                                .get()
                                .toString();
                    strBuffer.append(whenChanged + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_ACCESS_LEVEL_ATTRIBUTE) != null)
                {
                    String accessLevel = myNextEmployee
                            .getAttributes()
                                .get(LDAP_ACCESS_LEVEL_ATTRIBUTE)
                                .get()
                                .toString();
                    strBuffer.append(accessLevel);
                }
                else
                {
                    String accessLevel = "1";
                    strBuffer.append(accessLevel);
                }

            }

        }
        catch (Exception e)
        {
            LOGGER.error(e);
            return null;
        }
        finally
        {
            try
            {
                if (mySearchResults != null)
                {
                    mySearchResults.close();
                }

                if (myDirContext != null)
                {
                    myDirContext.close();
                }
            }
            catch (NamingException ex)
            {
                LOGGER.error(ex);
            }
        }
        return strBuffer.toString();
    }

    public boolean isLdapUserInternal(String userLoginName)
    {
        LOGGER.info((new StringBuilder(" getManagerEmailFromLDAP() --- "))
                .append(getLdapHost())
                    .append(" userLoginName :: ")
                    .append(userLoginName)
                    .toString());
        StringBuffer strBuffer = new StringBuffer();
        boolean isUserInternal = false;
        DirContext myDirContext = null;
        NamingEnumeration mySearchResults = null;
        try
        {
            String myFilter = (new StringBuilder("(uid=")).append(userLoginName).append(")").toString();
            Hashtable myEnv = new Hashtable();
            myEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
            myEnv.put("java.naming.provider.url", getLdapHost());
            myEnv.put(Context.SECURITY_PRINCIPAL, genericUser);
            myEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(genericPwd, genericKey).getBytes("UTF8"));
            myDirContext = new InitialDirContext(myEnv);
            SearchControls mySearchControls = new SearchControls();
            mySearchControls.setSearchScope(2);
            SearchResult myNextEmployee;
            for (mySearchResults = myDirContext.search("ou=ccoentities,o=cco.cisco.com", myFilter, mySearchControls); mySearchResults != null
                    && mySearchResults.hasMore();)
            // _log.info((new StringBuilder("getAll:::")).append(myNextEmployee.getAttributes().toString()).toString()))
            {
                myNextEmployee = (SearchResult) mySearchResults.next();
                if (myNextEmployee.getAttributes().get("uid") != null)
                {
                    String userId = myNextEmployee.getAttributes().get("uid").get().toString();
                    LOGGER.info(" LDAP found user id is :" + userId);
                }

                if (myNextEmployee.getAttributes().get("accessLevel") != null)
                {
                    String accessLevel = myNextEmployee.getAttributes().get("accessLevel").get().toString();

                    LOGGER.info(" LDAP found users accessLevel is :" + accessLevel);

                    if (accessLevel.equalsIgnoreCase(GENERICS_LDAP_ACCESS_LEVEL))
                        isUserInternal = true;
                    break;
                }
            }

        }
        catch (Exception e)
        {
            LOGGER.error(e);
            return isUserInternal;
        }
        finally
        {
            try
            {
                if (mySearchResults != null)
                {
                    mySearchResults.close();
                }

                if (myDirContext != null)
                {
                    myDirContext.close();
                }
            }
            catch (NamingException ex)
            {
                LOGGER.error(ex);
            }
        }
        LOGGER.info(" LDAP searched users : " + userLoginName + " is internal user :" + isUserInternal);
        return isUserInternal;
    }

    public boolean isLdapUserGeneric(String userLoginName)
    {
        LOGGER.info((new StringBuilder(" getManagerEmailFromLDAP() Generics --- "))
                .append(getLdapHost())
                    .append(" userLoginName :: ")
                    .append(userLoginName)
                    .toString());
        StringBuffer strBuffer = new StringBuffer();
        boolean isUserGeneric = false;
        NamingEnumeration mySearchResults = null;
        DirContext myDirContext = null;
        try
        {
            String myFilter = (new StringBuilder("(uid=")).append(userLoginName).append(")").toString();
            Hashtable myEnv = new Hashtable();
            myEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
            myEnv.put("java.naming.provider.url", getLdapHost());
            myEnv.put(Context.SECURITY_PRINCIPAL, genericUser);
            myEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(genericPwd, genericKey).getBytes("UTF8"));
            myDirContext = new InitialDirContext(myEnv);
            SearchControls mySearchControls = new SearchControls();
            mySearchControls.setSearchScope(2);
            SearchResult myNextEmployee;
            for (mySearchResults = myDirContext.search(GENERICS_LDAP_SEARCHBASE, myFilter, mySearchControls); mySearchResults != null
                    && mySearchResults.hasMore();)
            // _log.info((new StringBuilder("getAll:::")).append(myNextEmployee.getAttributes().toString()).toString()))
            {
                myNextEmployee = (SearchResult) mySearchResults.next();
                if (myNextEmployee.getAttributes().get("uid") != null)
                {
                    String userId = myNextEmployee.getAttributes().get("uid").get().toString();
                    LOGGER.info(" LDAP found Generic user id is :" + userId);
                }
                isUserGeneric = true;
                break;
            }

        }
        catch (Exception e)
        {
            LOGGER.error(e);

            return isUserGeneric;
        }
        finally
        {
            try
            {
                if (mySearchResults != null)
                {
                    mySearchResults.close();
                }

                if (myDirContext != null)
                {
                    myDirContext.close();
                }
            }
            catch (NamingException ex)
            {
                LOGGER.error(ex);
            }
        }
        LOGGER.info(" LDAP searched users : " + userLoginName + " is Generic user :" + isUserGeneric);
        return isUserGeneric;
    }

    // START: mkatnam

    /**
     * getting access level of a given user
     * 
     * @param userLoginName
     * @return
     */
    public String getUserAccessLevelFromLDAP(String userLoginName)
    {
        String accessLevel = null;
        DirContext myDirContext = null;
        SearchControls mySearchControls = null;
        NamingEnumeration<SearchResult> mySearchResults = null;
        try
        {
            String myFilter = "(uid=" + userLoginName + ")";
            Hashtable myEnv = new Hashtable();
            myEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
            myEnv.put(Context.PROVIDER_URL, getLdapHost()); // ldap://dsx.cisco.com:389
            myEnv.put(Context.SECURITY_PRINCIPAL, genericUser);
            myEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(genericPwd, genericKey).getBytes("UTF8"));
            myDirContext = new InitialDirContext(myEnv);
            mySearchControls = new SearchControls();
            String[] attrIDs =
            { "accessLevel" };
            mySearchControls.setReturningAttributes(attrIDs);
            mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            mySearchResults = myDirContext.search(LDAP_SEARCHBASE, myFilter, mySearchControls);
            if(mySearchResults == null || !mySearchResults.hasMore()){
              	 mySearchResults = myDirContext.search(GENERICS_LDAP_SEARCHBASE,myFilter,
                           mySearchControls );
              	if (mySearchResults != null && mySearchResults.hasMore())
                {
             		accessLevel = GENERICS_LDAP_ACCESS_LEVEL;
                }
              }
            SearchResult myNextEmployee;
            while (mySearchResults != null && mySearchResults.hasMore())
            {
                myNextEmployee = (SearchResult) mySearchResults.next();
                if (myNextEmployee.getAttributes().get(LDAP_ACCESS_LEVEL_ATTRIBUTE) != null)
                {
                    accessLevel = myNextEmployee.getAttributes().get(LDAP_ACCESS_LEVEL_ATTRIBUTE).get().toString();
                }
            }

        }
        catch (Exception e)
        {
            LOGGER.error(e);
            return null;
        }
        finally
        {
            try
            {
                if (mySearchResults != null)
                {
                    mySearchResults.close();
                }

                if (myDirContext != null)
                {
                    myDirContext.close();
                }
            }
            catch (NamingException ex)
            {
                LOGGER.error(ex);
            }
        }

        return accessLevel;
    }

    // END: mkatnam

    /**
     * to get manager reporting chain users from the ldap using manager user id
     * 
     * @param userName
     */
    public List<String> getManagerReportingUsersFromLDAP(String userName)
    {
        List<String> reportingUsers = new ArrayList<String>();
        DirContext myDirContext = null;
        SearchControls mySearchControls = null;
        NamingEnumeration<SearchResult> results = null;
        try
        {
            String searchFilter = "(" + LDAP_USER_SEARCH_FILTER + userName + ")";
            Hashtable myEnv = new Hashtable();
            myEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
            myEnv.put(Context.PROVIDER_URL, getLdapHost()); // ldap://dsx.cisco.com:389
            myDirContext = new InitialDirContext(myEnv);
            mySearchControls = new SearchControls();
            mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            results = myDirContext.search(LDAP_SEARCHBASE, searchFilter, mySearchControls);
            // loop through the results in each page
            while (results != null && results.hasMore())
            {
                SearchResult sr = (SearchResult) results.next();
                Attributes attributes = sr.getAttributes();
                if (attributes.get(LDAP_SEARCH_ATTRIBUTE_NAME) != null)
                {
                    // _log.info("Number of directReports users size : "
                    // +attributes.get(LDAP_SEARCH_ATTRIBUTE_NAME).size());
                    for (int i = 0; i < attributes.get(LDAP_SEARCH_ATTRIBUTE_NAME).size(); i++)
                    {
                        String value = (String) attributes.get(LDAP_SEARCH_ATTRIBUTE_NAME).get(i);
                        reportingUsers.add(value.split(",")[0].replaceFirst("uid=", ""));
                    }
                } /*
                   * else { reportingUsers.add(""); }
                   */
            }
            if (LOGGER.isDebugEnabled())
            {
                LOGGER.info(" Reporting Users :: " + reportingUsers.toString());
            }

        }
        catch (Exception e)
        {
            LOGGER.error(e);
            return null;
        }
        finally
        {
            try
            {
                if (results != null)
                {
                    results.close();
                }

                if (myDirContext != null)
                {
                    myDirContext.close();
                }
            }
            catch (NamingException ex)
            {
                LOGGER.error(ex);
            }
        }
        return reportingUsers;
    }

    public String getGenericUserDetailsFromLDAP(String userName)
    {

        StringBuffer strBuffer = new StringBuffer();
        NamingEnumeration mySearchResults = null;
        DirContext myDirContext = null;
        try
        {
            String myFilter = (new StringBuilder("(uid=")).append(userName).append(")").toString();
            Hashtable myEnv = new Hashtable();
            myEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
            myEnv.put("java.naming.provider.url", getLdapHost());
            myEnv.put(Context.SECURITY_PRINCIPAL, genericUser);
            myEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(genericPwd, genericKey).getBytes("UTF8"));
            myDirContext = new InitialDirContext(myEnv);
            SearchControls mySearchControls = new SearchControls();
            mySearchControls.setSearchScope(2);
            SearchResult myNextEmployee;
            for (mySearchResults = myDirContext.search(GENERICS_LDAP_SEARCHBASE, myFilter, mySearchControls); mySearchResults != null
                    && mySearchResults.hasMore();)

            {

                myNextEmployee = (SearchResult) mySearchResults.next();
                if (myNextEmployee.getAttributes().get(LDAP_UID_ATTRIBUTES) != null)
                {
                    String userId = myNextEmployee.getAttributes().get(LDAP_UID_ATTRIBUTES).get().toString();
                    strBuffer.append(userId);
                }
                if (myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES) != null)
                {
                    String name = myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES).get().toString();
                    strBuffer.append("::" + name + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_COMPANY_ATTRIBUTES) != null)
                {
                    String company = myNextEmployee.getAttributes().get(LDAP_COMPANY_ATTRIBUTES).get().toString();
                    strBuffer.append(company + "::");
                }
                else
                {
                    String company = "Cisco Systems, Inc.";
                    strBuffer.append(company + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES) != null)
                {
                    String email = myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES).get().toString();
                    strBuffer.append(email + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_EMPLOYEE_TYPE_ATTRIBUTES) != null)
                {
                    String employeeType = myNextEmployee
                            .getAttributes()
                                .get(LDAP_EMPLOYEE_TYPE_ATTRIBUTES)
                                .get()
                                .toString();
                    strBuffer.append(employeeType + "::");
                }
                else
                {
                    String employeeType = NA;
                    strBuffer.append(employeeType + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_WHEN_CHANGED_ATTRIBUTES) != null)
                {
                    String whenChanged = myNextEmployee
                            .getAttributes()
                                .get(LDAP_WHEN_CHANGED_ATTRIBUTES)
                                .get()
                                .toString();
                    strBuffer.append(whenChanged + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_ACCESS_LEVEL_ATTRIBUTE) != null)
                {
                    String accessLevel = myNextEmployee
                            .getAttributes()
                                .get(LDAP_ACCESS_LEVEL_ATTRIBUTE)
                                .get()
                                .toString();
                    strBuffer.append(accessLevel);
                }
                else
                {
                    String accessLevel = GENERICS_LDAP_ACCESS_LEVEL;
                    strBuffer.append(accessLevel);
                }
            }
        }
        catch (Exception e)
        {
            LOGGER.error(e);
            return null;
        }
        finally
        {
            try
            {
                if (mySearchResults != null)
                {
                    mySearchResults.close();
                }

                if (myDirContext != null)
                {
                    myDirContext.close();
                }
            }
            catch (NamingException ex)
            {
                LOGGER.error(ex);
            }
        }
        return strBuffer.toString();
    }

    public void createLDAPUser(String userid)
    {
        LOGGER.info(".Start creating LDAP users.. " + userid);

        final Set<String> zoneSet = getZones(zoneId);
        String idAndName = getUserDetailsFromLDAP(userid);
        LOGGER.info("idAndName =" + idAndName);
        // idAndName =spathi::Satya Narayana::Cisco Systems, Inc.

        final String userName = (idAndName.split("::"))[0];
        LOGGER.info("userName =" + userName);

        String name = (idAndName.split("::"))[1];
        LOGGER.info("name =" + name);

        String organization = (idAndName.split("::"))[2];

        String firstName = "", lastName = "";
        if (name.contains(" "))
        {

            firstName = (name.split(" "))[0];
            LOGGER.info("firstName =" + firstName);

            lastName = (name.split(" "))[1];
            LOGGER.info("lastName =" + lastName);
        }
        else
            firstName = name;

        String email = (idAndName.split("::"))[3];

        final HashMap<QName, Serializable> properties = new HashMap<QName, Serializable>();
        properties.put(ContentModel.PROP_USERNAME, userName);
        // properties.put(ContentModel.PROP_HOMEFOLDER, userNodeRef);
        properties.put(ContentModel.PROP_FIRSTNAME, firstName);
        properties.put(ContentModel.PROP_LASTNAME, lastName);
        properties.put(ContentModel.PROP_EMAIL, email);
        properties.put(ContentModel.PROP_ORGANIZATION, organization);

        try
        {
            NodeRef newPerson = serviceRegistry.getPersonService().createPerson(properties, zoneSet);
            LOGGER.info("newPerson==" + newPerson);
            MutableAuthenticationService authService = serviceRegistry.getAuthenticationService();
            authService.createAuthentication(userName, userName.toCharArray());
            authService.setAuthenticationEnabled(userName, true);
        }
        catch (Exception e)
        {
            LOGGER.info("Exception at creating person:: " + e);
        }

    }

    // get user details based on mail Id
    public String getUserDetailsFromLDAPemailBased(String email)
    {
        StringBuffer strBuffer = new StringBuffer();
        DirContext myDirContext = null;
        String accessLevel =null;
        NamingEnumeration<SearchResult> mySearchResults = null;
        try
        {
            String myFilter = "(mail=" + email + ")";
            Hashtable myEnv = new Hashtable();
            myEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
            myEnv.put(Context.PROVIDER_URL, getLdapHost()); // ldap://dsx.cisco.com:389
            myEnv.put(Context.SECURITY_PRINCIPAL, genericUser);
            myEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(genericPwd, genericKey).getBytes("UTF8"));
            myDirContext = new InitialDirContext(myEnv);
            SearchControls mySearchControls = new SearchControls();
            mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            mySearchResults = myDirContext.search(LDAP_SEARCHBASE, myFilter, mySearchControls);
            if(mySearchResults == null || !mySearchResults.hasMore()){
              	 mySearchResults = myDirContext.search(GENERICS_LDAP_SEARCHBASE,myFilter,
                           mySearchControls );
              	if (mySearchResults != null && mySearchResults.hasMore())
                {
             		accessLevel = GENERICS_LDAP_ACCESS_LEVEL;
                }
              }
            SearchResult myNextEmployee;
            while (mySearchResults != null && mySearchResults.hasMore())
            {
                myNextEmployee = (SearchResult) mySearchResults.next();
                if (myNextEmployee.getAttributes().get(LDAP_UID_ATTRIBUTES) != null)
                {
                    String userId = myNextEmployee.getAttributes().get(LDAP_UID_ATTRIBUTES).get().toString();
                    strBuffer.append(userId);
                }
                if (myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES) != null)
                {
                    String name = myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES).get().toString();
                    strBuffer.append("::" + name + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_CN_ATTRIBUTES) != null)
                {
                    String company = myNextEmployee.getAttributes().get(LDAP_COMPANY_ATTRIBUTES).get().toString();
                    strBuffer.append(company + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES) != null)
                {
                    String emailid = myNextEmployee.getAttributes().get(LDAP_MAIL_ATTRIBUTES).get().toString();
                    strBuffer.append(email + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_EMPLOYEE_TYPE_ATTRIBUTES) != null)
                {
                    String employeeType = myNextEmployee
                            .getAttributes()
                                .get(LDAP_EMPLOYEE_TYPE_ATTRIBUTES)
                                .get()
                                .toString();
                    strBuffer.append(employeeType + "::");
                }
                else
                {
                    String employeeType = NA;
                    strBuffer.append(employeeType + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_WHEN_CHANGED_ATTRIBUTES) != null)
                {
                    String whenChanged = myNextEmployee
                            .getAttributes()
                                .get(LDAP_WHEN_CHANGED_ATTRIBUTES)
                                .get()
                                .toString();
                    strBuffer.append(whenChanged + "::");
                }
                if (myNextEmployee.getAttributes().get(LDAP_ACCESS_LEVEL_ATTRIBUTE) != null)
                {
                    accessLevel = myNextEmployee
                            .getAttributes()
                                .get(LDAP_ACCESS_LEVEL_ATTRIBUTE)
                                .get()
                                .toString();
                    strBuffer.append(accessLevel);
                }
                else
                {
                    accessLevel = "1";
                    strBuffer.append(accessLevel);
                }

            }
        }
        catch (Exception e)
        {
            LOGGER.error(e);
            return null;
        }
        finally
        {
            try
            {
                if (mySearchResults != null)
                {
                    mySearchResults.close();
                }

                if (myDirContext != null)
                {
                    myDirContext.close();
                }
            }
            catch (NamingException ex)
            {
                LOGGER.error(ex);
            }
        }
        return strBuffer.toString();
    }

}
