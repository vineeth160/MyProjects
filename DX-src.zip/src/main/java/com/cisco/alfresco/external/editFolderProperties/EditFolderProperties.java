package com.cisco.alfresco.external.editFolderProperties;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Pattern;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.action.Action;
import org.alfresco.service.cmr.action.ActionService;
import org.alfresco.service.cmr.model.FileExistsException;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.model.FileNotFoundException;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.alfresco.external.common.util.FavoriteUtil;
import com.cisco.alfresco.external.domain.CheckDomain;
import com.cisco.docex.exceptions.ErrorObject;
import com.cisco.docex.exceptions.ValidationException;
import com.cisco.sd.rest.service.MigrationConstants;

/**
 * 
 * @author prbadam - US5415 (Folder creation, View, Edit and Delete operations)
 * 
 */
public class EditFolderProperties extends DeclarativeWebScript
{
    private static final Logger LOGGER = Logger.getLogger(EditFolderProperties.class);
    private ServiceRegistry serviceRegistry = null;
    private PermissionService permissionService =null;
    public static String USER_ADMIN_ROLE = "Folder Admin";
    private AuditComponent auditComponent;
    private ExternalLDAPUtil ldapUtil;
    private BehaviourFilter policyFilter;
    private String veraDocExAdminGroup;
    private Properties globalProperties;
    private static final Pattern pattern = Pattern.compile("[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
    
    public void setGlobalProperties(Properties globalProperties) {
		this.globalProperties = globalProperties;
	}
	public BehaviourFilter getPolicyFilter() {
  		return policyFilter;
  	}
  	public void setPolicyFilter(BehaviourFilter policyFilter) {
  		this.policyFilter = policyFilter;
  	}
  	
    public PermissionService getPermissionService() {
		return permissionService;
	}

	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}

    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }
 
	
	public AuditComponent getAuditComponent() {
		return auditComponent;
	}

	public void setAuditComponent(AuditComponent auditComponent) {
		this.auditComponent = auditComponent;
	}

	public ExternalLDAPUtil getLdapUtil()
    {
        return ldapUtil;
    }
    public void setLdapUtil(ExternalLDAPUtil ldapUtil)
    {
        this.ldapUtil = ldapUtil;
    }
        
	public String getVeraDocExAdminGroup() {
		return veraDocExAdminGroup;
	}
	public void setVeraDocExAdminGroup(String veraDocExAdminGroup) {
		this.veraDocExAdminGroup = veraDocExAdminGroup;
	}
	// Creating folder 
	public Map<String, Object> onCreateFolderMethod(String nodeId,String folderName, String folderDescription,String domain, String inheritPermission, String isGusetAccess,String isFavorite,String currentLoginUserName, String applyVeraProtection, String tags, String isEditorDeleteFiles) {		
		
		LOGGER.info("in onCreateFolderMethod---------");
		Map<String, Object> model = new HashMap<String, Object>();
		Map<QName, Serializable> folderProperties;
		
		NodeRef parentNodeRef = new NodeRef(nodeId);
		folderProperties = new HashMap<QName, Serializable>(3);
	    folderProperties.put(ContentModel.PROP_NAME, folderName);
	    folderProperties.put(ContentModel.PROP_DESCRIPTION, folderDescription);
	    folderProperties.put(ContentModel.PROP_TITLE, folderName);
	    LOGGER.info("folderProperties---------"+folderProperties);
		
	    QName folderNameValue = QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, folderName);
	    ChildAssociationRef folderNodeRef = serviceRegistry.getNodeService().createNode(parentNodeRef,ContentModel.ASSOC_CONTAINS, folderNameValue, ContentModel.TYPE_FOLDER,folderProperties);
	    LOGGER.info("folderNodeRef-- child-------"+folderNodeRef.getChildRef());
	    
	    // START: US9855- adding editorDeleteFileAspect to the node
	    Map<QName, Serializable> editorDeleteFilesProp = new HashMap<QName, Serializable>(1);
	    editorDeleteFilesProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}editorDeleteFiles"),isEditorDeleteFiles);
	    serviceRegistry.getNodeService().addAspect(folderNodeRef.getChildRef(),QName.createQName("{http://www.alfresco.org/model/external/content/1.0}editorDeleteFileAspect"), editorDeleteFilesProp);
	    // END: US9855- adding editorDeleteFileAspect to the node
	    
	    //START : US8067 - PRBADAM added Ability to mark a folder as favorite while creating a folder.
	    FavoriteUtil.addFavorite(serviceRegistry, policyFilter, currentLoginUserName, isFavorite, folderNodeRef.getChildRef());
	    //END : US8067 - PRBADAM added Ability to mark a folder as favorite while creating a folder.
	
	    
	    // adding domainAspect to the node
	    Map<QName, Serializable> domainProp = new HashMap<QName, Serializable>(1);
	    domainProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"),domain);
	    serviceRegistry.getNodeService().addAspect(folderNodeRef.getChildRef(),QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domainAspect"), domainProp);
	    
	    /**
	     * This will enable the vera protection on the folder based on the users choice.
	     * If already parent folder protected with vera, then same option will inherit to child folder also(i.e newly created folder)
	     * If parent is not protected, then newly created folder will be protected with vera as per users choice.
	     */
	    if(applyVeraProtection != null && applyVeraProtection.matches("Cisco Restricted|All Contents")){
	    	if(serviceRegistry.getNodeService().hasAspect(parentNodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION)){
	    		String parentFolderVeraProtectionValue = (String) serviceRegistry.getNodeService().getProperty(parentNodeRef, ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
	    		String veraEnabledBy = (String) serviceRegistry.getNodeService().getProperty(parentNodeRef, ExternalSharingConstants.PROP_VERA_ENABLED_BY);
	    		String veraRootFolderNodeRef = (String) serviceRegistry.getNodeService().getProperty(parentNodeRef, ExternalSharingConstants.PROP_VERA_ROOT_FOLDER_NODEREF);

	    		applyVeraProtectionAspect(folderNodeRef.getChildRef(), parentFolderVeraProtectionValue, false, veraEnabledBy, veraRootFolderNodeRef);
	    	} else {
	    		applyVeraProtectionAspect(folderNodeRef.getChildRef(), applyVeraProtection, true, currentLoginUserName, folderNodeRef.getChildRef().toString());
	    	}

	    } else {
	    	LOGGER.error("(Create Folder())-- users applyVeraProtection value either null or somedifferent value : " + applyVeraProtection);
	    }
	    //vera changes End
	    
	    //Uthra changes start - Tag
	    if(!tags.isEmpty()){
	    	serviceRegistry.getNodeService().addAspect(folderNodeRef.getChildRef(), ExternalSharingConstants.CISCO_TAG_ASPECT, null);
	    	serviceRegistry.getNodeService().setProperty(folderNodeRef.getChildRef(), ExternalSharingConstants.CISCO_QNAME_TAG_NAME, tags);
	    			//getProperty(folderNodeRef.getChildRef(), ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
       
	    }
	    //Uthra changes end - Tag
	    
	    //adding disableguestUser Aspect to the node
	    Boolean isGusetAccessEnabled = false;
		 if(isGusetAccess!=null && isGusetAccess!="")
			 isGusetAccessEnabled = Boolean.valueOf(isGusetAccess);	 
	    Map<QName, Serializable> disableGuestProp = new HashMap<QName, Serializable>(1);
	    disableGuestProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}disableguestUser"),isGusetAccessEnabled);
	    //disableGuestProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}isFolderVeraProtected"),Boolean.valueOf(isFolderVeraProtected));
	    serviceRegistry.getNodeService().addAspect(folderNodeRef.getChildRef(),
	    		QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domainAspect"), disableGuestProp);
	    String currentUserName = serviceRegistry.getAuthenticationService().getCurrentUserName();
	    if(inheritPermission.equals("false"))
	    {
	    	permissionService.setInheritParentPermissions(folderNodeRef.getChildRef(), false);
	    	//START:  for setting current login user as owner in permissions
		    LOGGER.info("currentUserName---------"+currentUserName);
		    serviceRegistry.getPermissionService().setPermission(folderNodeRef.getChildRef(), currentUserName, "AdminRole", true);
		    //END:  for setting current login user as owner in permissions
	    } 
	    //added by mkatnam for domain audit
	    if(domain != null && domain.length() >0){
	    	 LOGGER.info(" Domain Added is calling... ");
	    	 domain = domain.replaceAll(",", ";");
			recordAuditInfo(folderNodeRef.getChildRef(),folderName,null,domain,currentUserName,"Domain Added");
	    }
		model.put("folderNodeRef", "Folder created successfully");
		model.put("nodeId", folderNodeRef.getChildRef());
		return model;
	}

	
	  public static Set<AccessPermission> getAllNodeRefPermissions(final ServiceRegistry serviceRegistry, final NodeRef nodeRef){
	    	final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
		   	 AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
					@Override
					public Object doWork() throws Exception {
						accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef));
						return null;
					}
		   	 }, "admin");
	    	return accessPermission;
	    }
	
	
	// View folder properties
	public Map<String, Object> onViewFolderMethod(String nodeId,final String currentLoginUserName) {
		
		LOGGER.info("in onViewFolderMethod---------");
		final Map<String, Object> model = new HashMap<String, Object>();
		final NodeRef newFolderNodeRef = new NodeRef(nodeId);
		LOGGER.info("newFolderNodeRef------"+newFolderNodeRef);
 		model.put("viewNode", newFolderNodeRef);
 		
 		String userPermissionRole = ExternalSharingFileFolderUtil.getUserRole(serviceRegistry,currentLoginUserName,newFolderNodeRef);
		LOGGER.info("userPermissionRole----------"+userPermissionRole);
		model.put("userPermission", userPermissionRole);
		
		NodeRef currentLoginUserNodeRef = serviceRegistry.getPersonService().getPerson(currentLoginUserName);
		Map<QName, Serializable> userProperties = serviceRegistry.getNodeService().getProperties(currentLoginUserNodeRef);
		LOGGER.info("userProperties--------"+userProperties);
		String emailValue = (String) userProperties.get(ContentModel.PROP_EMAIL);
		LOGGER.info("emailValue--------"+emailValue);
		if(emailValue.endsWith("cisco.com")){
			model.put("isEmailExists", "true");
		}
		
		/**
		 * this method will check the current logged in user into vera admins group.
		 * Only users part of this group can enable and disable the vera protection on folders.
		 * And also this method will retrieve the parent folder vera protection status.
		 */
		Boolean isUserVeraAdmin = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
			@Override
			public Boolean doWork() throws Exception {
				Set<String> groupSet = serviceRegistry.getAuthorityService().getAuthoritiesForUser(currentLoginUserName);
				NodeRef ParentNodeRef = serviceRegistry.getNodeService().getPrimaryParent(newFolderNodeRef).getParentRef();
				String inhiritedVeraProtection = (String)serviceRegistry.getNodeService().getProperty(ParentNodeRef, ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
				model.put("inhiritedVeraProtection",inhiritedVeraProtection);
				
				if(veraDocExAdminGroup!= null){
                	return groupSet.contains("GROUP_"+veraDocExAdminGroup);
                } else {
                	LOGGER.error("veraDocExAdminGroup value found null.Please check the properties file");
                	return false;
                }
			}
		}, "admin");
		model.put("isUserVeraAdmin",isUserVeraAdmin);
		
		String created = ExternalSharingFileFolderUtil.getGMTDateFormat((Date) serviceRegistry.getNodeService().getProperty(newFolderNodeRef, ContentModel.PROP_CREATED));
        String modified = ExternalSharingFileFolderUtil.getGMTDateFormat((Date) serviceRegistry.getNodeService().getProperty(newFolderNodeRef, ContentModel.PROP_MODIFIED));
        
        model.put("created", created);
        model.put("modified", modified);
        
        // START : UTHRA added for checking if node having different domains.
        if(CheckDomain.getDomainStatus(newFolderNodeRef.toString()).get("status1") == "401"){
       	 LOGGER.info(" if inside 401-------");
       	model.put("isDomainValid", "false");
        } else {
        	model.put("isDomainValid", "true");
        }
	     // END : UTHRA added for checking if node having different domains.
        
      //Tags -  Uthra
        String tagName = "";
        if(serviceRegistry.getNodeService().hasAspect(newFolderNodeRef,ExternalSharingConstants.CISCO_TAG_ASPECT)){
        	tagName = (String) serviceRegistry.getNodeService().getProperty(newFolderNodeRef, ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
   			LOGGER.info("tagName :: " +tagName);
   		}
        
        model.put("tags", tagName);
      // Tags - Uthra

        
      //START : US8067 - PRBADAM added Ability to mark a folder as favorite while creating a folder.  
      boolean isFavoriteStatus = FavoriteUtil.favoriteStstus(serviceRegistry, currentLoginUserName, newFolderNodeRef);
      LOGGER.info("isFavoriteStatus--------"+isFavoriteStatus);
      model.put("isfavorite", isFavoriteStatus); 
      //END : US8067 - PRBADAM added Ability to mark a folder as favorite while creating a folder.
      
      //prbadam Start: Added for US5491 - Root Folder Creation in Doc Exchange
      //US8595 - Published folders should not be editable in Doc exchange
      if(serviceRegistry.getNodeService().hasAspect(newFolderNodeRef, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT)){
			model.put("isCreatedInDocExchange", false); 
		} else{
			model.put("isCreatedInDocExchange", true); 
		}
	//prbadam End: Added for US5491 - Root Folder Creation in Doc Exchange
    //US8595 - Published folders should not be editable in Doc exchange
      
      return model;
	}
	
	private void applyVeraProtectionAspect(NodeRef folderNodeRef, String folderVeraProtectionValue, boolean isVeraRootFolder, String veraEnabledBy, String veraRootFolderNodeRef){
		Map<QName, Serializable> verFolderProtectionProps = new HashMap<>(6);
		verFolderProtectionProps.put(ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION,folderVeraProtectionValue);
		verFolderProtectionProps.put(ExternalSharingConstants.PROP_IS_VERA_ROOT_FOLDER,isVeraRootFolder);
		verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ENABLED_DATE,new Date());
		verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ENABLED_BY,veraEnabledBy);
		verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ROOT_FOLDER_NODEREF,veraRootFolderNodeRef);
		serviceRegistry.getNodeService().addAspect(folderNodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION, verFolderProtectionProps);
	}

	/**
	 * 
	 * @param folderNodeRef
	 * @param currentLoginUserName
	 * @param veraProtectionStatus
	 * 
	 * This method will enable/disable the vera protection on the action initiated folder and all its subfolders, documents under this folder 
     * Same rule will be cascading to the all subfolders and documents
     * 
	 * This action will trigger asynchronously 
     * 
	 */
	private void enableOrDisableVeraProtection(NodeRef folderNodeRef, String currentLoginUserName, String veraProtectionStatus){
		ActionService actionService = serviceRegistry.getActionService();
		Action veraProtectionAction = actionService.createAction("applyVeraProtectionAction");
		veraProtectionAction.setParameterValue("folderNodeRef", (Serializable)folderNodeRef);
		veraProtectionAction.setParameterValue("veraProtectionStatus", veraProtectionStatus);
		veraProtectionAction.setParameterValue("veraEnabledBy", currentLoginUserName);
		veraProtectionAction.setExecuteAsynchronously(true);
		actionService.executeAction(veraProtectionAction, null);

	}
	
	// Edit folder properties
	public Map<String, Object> oneditFolderMethod(String nodeId,String folderName,String folderDescription,String folderDomain, String isGusetAccess,String isFavorite,String currentLoginUserName, String applyVeraProtectionValue, String tags, String isEditorDeleteFiles) {

		LOGGER.info("in oneditFolderMethod---------");
		Map<String, Object> model = new HashMap<String, Object>();
		String oldDomain = null;
		NodeRef folderNodeRef = new NodeRef(nodeId);
		//added by mkatnam
		oldDomain = (String)serviceRegistry.getNodeService().getProperty(folderNodeRef,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"));
		
		Map<QName, Serializable> propMap = new HashMap<QName, Serializable>();
		propMap.put(ContentModel.PROP_NAME, folderName);
		propMap.put(ContentModel.PROP_DESCRIPTION, folderDescription);
	propMap.put(ContentModel.PROP_TITLE, folderName);
		
		try {
			serviceRegistry.getFileFolderService().rename(folderNodeRef, folderName);
		} catch (FileExistsException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
			//START: removing duplicates from folderDomain
			String[] doaminSplit = folderDomain.split(",");
			List<String> doaminList = new ArrayList<String>();
			Collections.addAll(doaminList, doaminSplit);
			//US13401 and TA17657 changes starts here
		     	for(int j=0; j<doaminList.size();j++){
		     		if(!doaminList.get(j).isEmpty() && doaminList.get(j)!=null) {
		   	           if (!pattern.matcher(doaminList.get(j)).matches()) {
				        	   LOGGER.info("provide valid input for domain :: "+doaminList.get(j));
   				               	ErrorObject eob = new ErrorObject();
   								eob.setField("domain");
   								eob.setError("Submitted domain is not in correct format("+doaminList.get(j)+"),The domains have not been saved. Please try again");
   								throw new ValidationException(eob);
   				           }
		     		}
		     		}
     	       //TA17657 ends here
			HashSet<String> emailHashList = new HashSet<String>(doaminList);
			String listFolderString = emailHashList.toString().replace("[", "").replace("]", "").replace(", ", ",");
			  
	           if (listFolderString.startsWith(",")) {
	        	   listFolderString = listFolderString.replaceFirst(",", "");
		        	}
	           if (listFolderString.endsWith(",")) {
	        	   listFolderString = listFolderString.substring(0, listFolderString.length() - 1);
		        	}
	           LOGGER.info("listFolderString-------"+listFolderString);
	         //END: removing duplicates from folderDomain
		
		propMap.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"), listFolderString);
		 //adding disableguestUser Aspect to the node
		Boolean isGusetAccessEnabled = false;
		 if(isGusetAccess!=null && isGusetAccess!="")
			 isGusetAccessEnabled = Boolean.valueOf(isGusetAccess);	  
		propMap.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}disableguestUser"), isGusetAccessEnabled);	

		//START : US8067 - PRBADAM added Ability to mark a folder as favorite while creating a folder.
		FavoriteUtil.editFavorite(serviceRegistry, policyFilter, currentLoginUserName, isFavorite, folderNodeRef);
		//END : US8067 - PRBADAM added Ability to mark a folder as favorite while creating a folder.
		
		serviceRegistry.getNodeService().addProperties(folderNodeRef, propMap);

		/**
		 * first condition, will eanble the vera protection on current folder and its all subfolders as choosen by user
		 * second condiiton will disable the vera protection on current folder and its all subfolders.
		 * If the folder contain andy Cisco Restricted docs, User is not allowed to disable to vera protection.
		 */
		if(applyVeraProtectionValue != null && applyVeraProtectionValue.matches("Cisco Restricted|All Contents")){
			String existingProtectionValue = (String)serviceRegistry.getNodeService().getProperty(folderNodeRef, ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
			if(existingProtectionValue == null || !existingProtectionValue.equals(applyVeraProtectionValue)){
				enableOrDisableVeraProtection(folderNodeRef, currentLoginUserName, applyVeraProtectionValue);
			}
			
		} else if(applyVeraProtectionValue != null && ((applyVeraProtectionValue.isEmpty() || "disable".equals(applyVeraProtectionValue)) && serviceRegistry.getNodeService().hasAspect(folderNodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION))) {
			//Check for Cisco Restricted Docs
			String folderQnamePath = serviceRegistry.getNodeService().getPath(folderNodeRef).toPrefixString(serviceRegistry.getNamespaceService());
			final String query = "PATH:\""+folderQnamePath+"//*\" AND TYPE:\"cs:ciscodoc\" AND (ASPECT:\"cs:ciscoMetaData\" AND @cs\\:security:\"Cisco Restricted\")";
			LOGGER.info("qNamePath : " + folderQnamePath + " Query is : " + query);
			
			List<NodeRef> nodeRefList = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<List<NodeRef>>() {
				@Override
				public List<NodeRef> doWork() throws Exception {
					return EDCSUtil.getNodeRefList(query, serviceRegistry);
				}
			}, "admin");
			
			if(nodeRefList == null || nodeRefList.isEmpty()){
				enableOrDisableVeraProtection(folderNodeRef, null, applyVeraProtectionValue);
			} else {
				model.put("isRestrictContentExist", true);
				LOGGER.error("Cisco Restricted Data Found you can not disable vera... ");
			}
		} else {
	    	LOGGER.error("(Edit Folder())-- applyVeraProtection value either null or somedifferent value : " + applyVeraProtectionValue);
	    }
		//vera changes End
	    
		
		//Uthra changes start - Tag
		
		 if(serviceRegistry.getNodeService().hasAspect(folderNodeRef,ExternalSharingConstants.CISCO_TAG_ASPECT)){
        	 serviceRegistry.getNodeService().setProperty(folderNodeRef, ExternalSharingConstants.CISCO_QNAME_TAG_NAME, tags);
    		}
	    if(!serviceRegistry.getNodeService().hasAspect(folderNodeRef,ExternalSharingConstants.CISCO_TAG_ASPECT) && !tags.isEmpty()){
	    	serviceRegistry.getNodeService().addAspect(folderNodeRef, ExternalSharingConstants.CISCO_TAG_ASPECT, null);
	    	serviceRegistry.getNodeService().setProperty(folderNodeRef, ExternalSharingConstants.CISCO_QNAME_TAG_NAME, tags);
	    			//getProperty(folderNodeRef.getChildRef(), ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
       }
	    //Uthra changes end - Tag
	    
	    // PRBADAM START: US9855
	    LOGGER.info("isEditorDeleteFiles---------" + isEditorDeleteFiles);
	    if(serviceRegistry.getNodeService().hasAspect(folderNodeRef,QName.createQName("http://www.alfresco.org/model/external/content/1.0","editorDeleteFileAspect"))){
        	serviceRegistry.getNodeService().setProperty(folderNodeRef, QName.createQName("http://www.alfresco.org/model/external/content/1.0","editorDeleteFiles"), isEditorDeleteFiles);
		} else {
			 	Map<QName, Serializable> editorDeleteFilesProp = new HashMap<QName, Serializable>(1);
			    editorDeleteFilesProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}editorDeleteFiles"),isEditorDeleteFiles);
			    serviceRegistry.getNodeService().addAspect(folderNodeRef,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}editorDeleteFileAspect"), editorDeleteFilesProp);
		}
	    // PRBADAM END: US9855
	    
		LOGGER.info("folderProps--edit----" + propMap);
		@SuppressWarnings("deprecation")
		List<FileInfo> deepFolderNodeRefs = serviceRegistry.getFileFolderService().listDeepFolders(folderNodeRef, null);
		LOGGER.info("deepFolderNodeRefs---------"+deepFolderNodeRefs);

		
		try{
		// START: DE2112 - Domain changes are not getting cascaded to its sub folder. - prbadam
		
		
		if(deepFolderNodeRefs.size() > 0){
	       for (FileInfo childAssoc : deepFolderNodeRefs) {
	           
	    	 final NodeRef  childNodeRef = childAssoc.getNodeRef();
	           LOGGER.info("childNodeRef---------"+childNodeRef);
	            
	           String childDomain = (String)serviceRegistry.getNodeService().getProperty(childNodeRef, QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"));
	           LOGGER.info("childDomain---------"+childDomain);
	           
	           
	           if(childDomain !=null){
	        	   LOGGER.info("in if childDomain---------");
	           List<String> deepFolderDomain = getFolderDomain(oldDomain,childDomain,folderDomain);
	           // Removing duplicates
	           HashSet<String> domainHashList = new HashSet<String>(deepFolderDomain);
	           LOGGER.info("after removing duplicates domainHashList---------"+domainHashList);
	           String listString = domainHashList.toString().replace("[", "").replace("]", "").replace(", ", ",");
	           if (listString.startsWith(",")) {
	        	   listString = listString.replaceFirst(",", "");
		        	}
	           if (listString.endsWith(",")) {
					listString = listString.substring(0, listString.length() - 1);
		        	}
			LOGGER.info("Final domains listString-------"+listString);
			
			final String listStringFinal = listString;
			
			AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
		             {
		             @Override
		             public Object doWork() throws Exception
		             {
		 
		            	 serviceRegistry.getNodeService().setProperty(childNodeRef, QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"), listStringFinal);

					return null;
		            }
		            }, "admin");
			
	       }
	           else{
	        	   LOGGER.info("in else childDomain---------");
	        		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
				             {
				             @Override
				             public Object doWork() throws Exception
				             {
				            		// adding domainAspect to the childDomainProp node if domain aspect is not there for older folders
									Map<QName, Serializable> childDomainProp = new HashMap<QName, Serializable>(1);
									childDomainProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"),"");

									serviceRegistry.getNodeService().addAspect(childNodeRef,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domainAspect"),childDomainProp);

							return null;
				            }
				            }, "admin");
	           }
	       }
		} 
		} catch(Exception e){
			e.printStackTrace();
			  LOGGER.info("in exception childDomain---------"+e);
		}
		// END: DE2112 - Domain changes are not getting cascaded to its sub folder. - prbadam
		
		//added by mkatnam for domain audit
		String creator = (String) serviceRegistry.getNodeService().getProperty(folderNodeRef, ContentModel.PROP_CREATOR);
		if(folderDomain != null && folderDomain.length() > 0){
			if(!folderDomain.equalsIgnoreCase(oldDomain)){
				LOGGER.info(" Domain Modified is calling....");
				folderDomain = folderDomain.replaceAll(",", ";");
				if (oldDomain != null && !oldDomain.trim().equals(""))
					oldDomain = oldDomain.replaceAll(",", ";");
				recordAuditInfo(folderNodeRef,folderName,oldDomain,folderDomain,creator,"Domain Modified");
			}
		}else{
			if(oldDomain != null && (folderDomain == null || folderDomain.equalsIgnoreCase(""))){
				LOGGER.info(" Domain Removed is calling....");
				oldDomain = oldDomain.replaceAll(",", ";");
				recordAuditInfo(folderNodeRef,folderName,oldDomain,folderDomain,creator,"Domain Removed");
			}
			
		}
		//end -mkatnam
		
		      //Domain Management START - US9112 
				if(folderDomain != null && folderDomain.length() > 0){
					if(!folderDomain.equalsIgnoreCase(oldDomain)){
						LOGGER.info("Calling ProcessUserDomains thread...");
						ProcessUserDomains processUserDomains = new ProcessUserDomains(folderNodeRef,folderDomain,deepFolderNodeRefs,serviceRegistry,ldapUtil);
		                new Thread(processUserDomains).start();
						
					}
					}
				//Domain Management END - US9112 
		
		model.put("editFolderNode", "Folder properties modified successfully");
		return model;
	}
	
	// START: DE2112 - Domain changes are not getting cascaded to its sub folder. - prbadam
	public List<String> getFolderDomain(String parent, String child, String newParent) {
	
	LOGGER.info("oldparent-----"+parent +", child------"+child +", newParent-----"+newParent);
	String[] parentSplit = parent.split(",");
	String[] childSplit = child.split(",");
	String[] newParentSplit = newParent.split(",");

	List<String> parentList = new ArrayList<String>();
	Collections.addAll(parentList, parentSplit);

	List<String> childList = new ArrayList<String>();
	Collections.addAll(childList, childSplit);

	List<String> newParentList = new ArrayList<String>();
	Collections.addAll(newParentList, newParentSplit);
	
	for (int i = 0; i < parentList.size(); i++) {

		boolean cList = childList.contains(parentList.get(i));
		if (cList) {
			childList.remove(parentList.get(i));
		}
	}
	childList.addAll(newParentList);
	LOGGER.info("Final values in getFolderDomain method------" + childList);
	return childList;
	}
	// END: DE2112 - Domain changes are not getting cascaded to its sub folder. - prbadam
	
	public void recordAuditInfo(NodeRef folderNodeRef, String folderName, String oldDomain, String folderDomain, String currentUserName, String event) {
		String modifier = AuthenticationUtil.getFullyAuthenticatedUser();
		Map<String, Serializable> auditEntry = new HashMap<String, Serializable>();
		auditEntry.put("foldername",folderName);
		auditEntry.put("noderef", folderNodeRef);
		auditEntry.put("creator", currentUserName );
		auditEntry.put("modifier", modifier);
		String nodePath = serviceRegistry.getNodeService().getPath(folderNodeRef).toDisplayPath(serviceRegistry.getNodeService(), permissionService);
		auditEntry.put("path",nodePath);
		auditEntry.put("folderprefixpath", serviceRegistry.getNodeService().getPath(folderNodeRef).toPrefixString(serviceRegistry.getNamespaceService()));
		auditEntry.put("olddomain", oldDomain);
		auditEntry.put("newdomain",folderDomain );
		auditEntry.put("event", event);
		
		auditComponent.recordAuditValues("/folder-domain/folder", auditEntry);
		
	}

	// Delete folder
	public Map<String, Object> ondeleteFolderMethod(String nodeId) {
		
		LOGGER.info("in ondeleteFolderMethod---------");
		Map<String, Object> model = new HashMap<String, Object>();
		NodeRef folderNodeRef = new NodeRef(nodeId);
		LOGGER.info("folderNodeRef--delete----"+folderNodeRef);
		
		List<ChildAssociationRef> folderChildren = serviceRegistry.getNodeService().getChildAssocs(folderNodeRef);
		LOGGER.info("folderChildren---------"+folderChildren.size());
		
		if(folderNodeRef !=null && folderChildren.size() == 0){
			serviceRegistry.getNodeService().deleteNode(folderNodeRef);
			model.put("deleteFolderNode", "Folder deleted successfully");
		} else {
			model.put("deleteFolderNode", "Delete children(s) before deleting actual folder");
		}
		return model;
	}
	
	/**
	 * 
	 * @param req
	 * @return
	 */
	private String readRequestBody(WebScriptRequest req) {
		try {
			return IOUtils.toString(req.getContent().getInputStream(), req
					.getContent().getEncoding());
		} catch (Exception e) {
			try {
				return req.getContent().getContent();
			} catch (IOException e1) {
				LOGGER.error("Unable to read JSON request body", e1);
				throw new WebScriptException(
						"Unable to read JSON request body!! Epic fail.");
			}
		}
	}
  
	  @Override
	    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
	    {
		  	Map<String, Object> model = new HashMap<String, Object>();
			String inputJSONValue = readRequestBody(req);
			JSONObject jsonObject = null;
			String action = null, folderName = null, folderDescription=null, isFavorite=null, isEditorDeleteFiles=null;
			String inheritPermission=null, folderDomain=null,domain=null, isGusetAccess=null;
			String applyVeraProtection = null;
			Map<String, Object> folderDetails=null;
			String nodeId = null;
			boolean opsRequest = false;
			Map<String, String> templateArgs = req.getServiceMatch().getTemplateVars();
			action = templateArgs.get("action");
			opsRequest = Boolean.parseBoolean(req.getParameter("isOpsRequest"));
			try {
				LOGGER.info("in try---------");
				  Map<String,String> permList = new HashMap<String,String>();
				if (!action.equalsIgnoreCase("view")) {
					jsonObject = new JSONObject(inputJSONValue);
					nodeId = jsonObject.getString("nodeId");
					} else {
					//for view action
					nodeId = req.getParameter("nodeId");
					
					String currentLoginUserName = AuthenticationUtil.getFullyAuthenticatedUser();
					//for support page result.
						if(action.equalsIgnoreCase("view") && opsRequest && isSupportGroupUser(currentLoginUserName)) {
							AuthenticationUtil.setAdminUserAsFullyAuthenticatedUser();
							try {
							folderDetails = onViewFolderMethod(nodeId,AuthenticationUtil.getRunAsUser());
							}catch(Exception ex) {
								LOGGER.error("Exception found while retrieve details for support page..." , ex);
								folderDetails =  new HashMap<>();
							}
							return folderDetails;
						}
					}
				  LOGGER.info("action---------"+action);
				  String currentLoginUserName = serviceRegistry.getAuthenticationService().getCurrentUserName();
				  LOGGER.info("currentLoginUserName---------"+currentLoginUserName);
				  
				  Set<AccessPermission> folderAccessPermissions = permissionService.getAllSetPermissions(new NodeRef(nodeId));
			      LOGGER.info("folderAccessPermissions -------------"+folderAccessPermissions);
			      
			      Iterator<AccessPermission> fIterator = folderAccessPermissions.iterator();
			        while (fIterator.hasNext())
			        {
			        	LOGGER.info("in while-----");
			            AccessPermission accessPermission = (AccessPermission) fIterator.next();
			            LOGGER.info("accessPermission------"+accessPermission);
			            if (accessPermission.getAuthorityType() == AuthorityType.USER)
			            {
			                if (LOGGER.isDebugEnabled())
			                {
			                    LOGGER.debug("Authority(User): " + accessPermission.getAuthority() + " Permission:  "
			                            + accessPermission.getPermission());
			                }
			                String autherityUserName = accessPermission.getAuthority();
			                LOGGER.info("autherityUserName------"+autherityUserName);
			                String autherityUserPermission = accessPermission.getPermission();
			                LOGGER.info("autherityUserPermission------"+autherityUserPermission);
			                
			                if(autherityUserPermission.equals("AdminRole")){
			                permList.put(autherityUserName, autherityUserPermission);
			                }
			            }// End of if
			            }// End of while
			            LOGGER.info("permList------"+permList);
			               // Start : only Folder admin can perform following operations
			            if (permList.containsKey(currentLoginUserName) &&  permList.containsValue("AdminRole")) //AdminRole = Area Admin/Folder Admin
			                {
			                LOGGER.info("valid user--------------"+currentLoginUserName);
			 			if (action.equalsIgnoreCase("create")) {
			 				// Here nodeId means parent noderef
			 				String tags = "";
			 				if(jsonObject.has("tags")){
			 				tags = jsonObject.getString("tags");
			 				}
			 				isFavorite = jsonObject.getString("favorite");
			 				LOGGER.info("isFavorite------"+isFavorite);
			 				
			 				isEditorDeleteFiles = jsonObject.getString("disableDeleteDocuments");
			 				LOGGER.info("isEditorDeleteFiles------"+isEditorDeleteFiles);
			 				
			 				folderName = jsonObject.getString("name");
			 				isGusetAccess = jsonObject.getString("disableGuestUsers");
			 				folderDescription = jsonObject.has("description")&&jsonObject.getString("description") !=null ? jsonObject.getString("description") : "";
			 				String dom= jsonObject.getString("domain").trim();
			 				domain = jsonObject.has("domain")&&jsonObject.getString("domain") !=null ? jsonObject.getString("domain") : "";
			 				domain=domain.replaceAll("\\s", "");
			 				
			 				LOGGER.info("<<<trimming domain spaces>>>>");
			 				LOGGER.info("trimming spaces for domain::::"+domain);
			 				inheritPermission = jsonObject.getString("syncFolderPermission");
			 				//Retrieve the Vera protection status for folder from request object and pass the same to Create folder method
			 				if(jsonObject.has("applyVeraProtection")){
			 					applyVeraProtection = jsonObject.getString("applyVeraProtection");
			 				} else {
			 					LOGGER.error("\"Create folder : \"apply Vera protection value not found in the input json obj : "  +jsonObject);
			 				}
			 				
			 				folderDetails = onCreateFolderMethod(nodeId,folderName,folderDescription,domain,inheritPermission, isGusetAccess,isFavorite,currentLoginUserName, applyVeraProtection,tags,isEditorDeleteFiles);
			 			}
			 			else if (action.equalsIgnoreCase("edit")) {
			 				String tags = "";
			 				if(jsonObject.has("tags")){
			 					tags = jsonObject.getString("tags");
			 				}
			 				isFavorite = jsonObject.getString("favorite");
			 				LOGGER.info("isFavorite--in edit----"+isFavorite);
			 				if(!isFavorite.equalsIgnoreCase("true") && !isFavorite.equalsIgnoreCase("false")) {
			 					ErrorObject eob = new ErrorObject();
			 					eob.setField("favorite");
			 					eob.setError("provide valid input for favorite");
			 					throw new ValidationException(eob);
			 				}
			 				 folderName = jsonObject.getString("name");
			 				 folderDescription = jsonObject.getString("description");
			 				folderDomain = jsonObject.getString("domain");
			 				isGusetAccess = jsonObject.getString("disableGuestUsers");
			 				
			 				if(!isGusetAccess.equalsIgnoreCase("true") && !isGusetAccess.equalsIgnoreCase("false")  ) {
			 					ErrorObject eob = new ErrorObject();
			 					eob.setField("disableGuestUsers");
			 					eob.setError("provide valid input for disableGuestUsers");
			 					throw new ValidationException(eob);
			 				}
			 				
			 				isEditorDeleteFiles = jsonObject.getString("disableDeleteDocuments");
			 				
			 				if(!isEditorDeleteFiles.equalsIgnoreCase("true") && !isEditorDeleteFiles.equalsIgnoreCase("false")  ) {
			 					ErrorObject eob = new ErrorObject();
			 					eob.setField("disableDeleteDocuments");
			 					eob.setError("provide valid input for disableDeleteDocuments");
			 					throw new ValidationException(eob);
			 				}
			 				
			 				//Retrieve the Vera protection status for folder from request object and pass the same to edit folder method
			 				if(jsonObject.has("applyVeraProtection")){
			 					applyVeraProtection = jsonObject.getString("applyVeraProtection");
			 				} else {
			 					LOGGER.error("\"Edit folder : \"apply Vera protection value not found in the input json obj : "  +jsonObject);
			 				}
			 				folderDetails = oneditFolderMethod(nodeId,folderName,folderDescription,folderDomain, isGusetAccess,isFavorite,currentLoginUserName, applyVeraProtection, tags, isEditorDeleteFiles);
			 				}
			 			 else if (action.equalsIgnoreCase("delete")) {
			 				 folderDetails = ondeleteFolderMethod(nodeId);
			 				}
			 			  else if (action.equalsIgnoreCase("view")) {
			 				 LOGGER.info("in if view --------------");
				 				 folderDetails = onViewFolderMethod(nodeId,currentLoginUserName);
				 			}	
			                } // End : only Folder admin can perform following operations

			            // view should be visible to all users
		            if (action.equalsIgnoreCase("view")) {
		            	LOGGER.info("outside while view --------------");
		            	folderDetails = onViewFolderMethod(nodeId,currentLoginUserName);
		            }	
				}// End of try
			catch(ValidationException ve) {
				LOGGER.error("Validation Exception" , ve);
				ErrorObject eob = ((ValidationException) ve).getErrorObj();
				model.put("folderNodeRef", eob.getError());
				return model;
			}
			 catch (Exception e) {
					e.printStackTrace();
					if(e.getClass().getSimpleName().equalsIgnoreCase("DuplicateChildNodeNameException"))
					{
						model.put("folderNodeRef", "Duplicate child name not allowed");
						return model;
					} else if(e.getClass().getSimpleName().equalsIgnoreCase("AccessDeniedException")){
						model.put("folderNodeRef", "User doesn't have appropriate permissions(Folder admin able to perform)");
						return model;
					}
					LOGGER.info("in e---------"+e);
				}
			LOGGER.info("folderDetails-----"+folderDetails);
			return folderDetails;
	    }
	  
	  public boolean isSupportGroupUser(String currentUserName) {
			boolean isUserExistinGroup = false;
			Set<String> userAuthorities = serviceRegistry.getAuthorityService().getAuthorities();
			String supportGroupName = globalProperties.getProperty("docex.supportgroup.name");
			if(supportGroupName != null && userAuthorities.contains(supportGroupName)) {
				isUserExistinGroup = true;
			}
			return isUserExistinGroup;
		}
}