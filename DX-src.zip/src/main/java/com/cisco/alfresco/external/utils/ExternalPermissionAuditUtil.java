package com.cisco.alfresco.external.utils;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.cmr.model.FileFolderService;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.ISO9075;
import org.apache.log4j.Logger;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;

/**
 * @author parreddy
 *
 */
public class ExternalPermissionAuditUtil {

	private Logger logger = Logger.getLogger(ExternalPermissionAuditUtil.class);
	private AuditComponent auditComponent;
	private NamespaceService namespaceService;
	private NodeService nodeService;
	private FileFolderService fileFolderService;
	private PermissionService permissionService;
	private PersonService personService;
	
	/**
	 * 
	 * @param node
	 * @param permissionChange
	 * @param permissionAction
	 */
	public void createPermissionAudit(NodeRef auditNodeRef, String permissionChange, String permissionAction) {
		try {

			Map<String, Serializable> resultAudit = getPermissionAuditInfoMap(auditNodeRef, permissionChange,
					permissionAction);

			if (resultAudit != null && resultAudit.size() > 0) {
				auditComponent.recordAuditValues("/permission-report/transaction", resultAudit);
			}
			// Need to do for all inherited child documents also.
			List<FileInfo> childDocumentsList = fileFolderService.listFiles(auditNodeRef);
			if (childDocumentsList != null && !childDocumentsList.isEmpty()) {
				for (FileInfo fileInfo : childDocumentsList) {
					Map<String, Serializable> childResultAudit = getPermissionAuditInfoMap(fileInfo.getNodeRef(),
							permissionChange, permissionAction);
					if (childResultAudit != null && !childResultAudit.isEmpty()) {
						auditComponent.recordAuditValues("/permission-report/transaction", childResultAudit);
					}
				} // end of for
			} // end of if

		} catch (Exception e) {
			logger.error("Exception in createPermissionAudit Audit Info " + e.getMessage());
			logger.error("Details  :::::: " + e.getCause());
		}
	}

	/**
	 * 
	 * @param node
	 * @param permissionChange
	 * @param permissionAction
	 * @return
	 */
	public Map<String, Serializable> insertAuditData(NodeRef node, String permissionChange, String permissionAction) {
		logger.debug("Audit data ====> " + node.getId() + " permissionChange ====> " + permissionChange);
		Map<String, Serializable> auditedValues = new HashMap<String, Serializable>();

		Map<String, Serializable> resultAudit = getPermissionAuditInfoMap(node, permissionChange, permissionAction);

		logger.debug(" Audit Result Map ====> " + resultAudit.toString());

		if (resultAudit != null && resultAudit.size() > 0) {
			auditedValues = auditComponent.recordAuditValues("/permission-report/transaction", resultAudit);

		}

		logger.debug("Audited Values ====> " + auditedValues);
		return auditedValues;
	}

	/**
	 * 
	 * @param nodeRef
	 * @param permissionChange
	 * @param action
	 * @return
	 */
	private Map<String, Serializable> getPermissionAuditInfoMap(NodeRef nodeRef, String permissionChange,
			String action) {

		Map<String, Serializable> auditValues = null;
		String prefixPath = null;
		String modifier = null;
		String path = null;
		try {
			Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);
			auditValues = new HashMap<String, Serializable>();
			prefixPath = ISO9075.decode(nodeService.getPath(nodeRef).toPrefixString(namespaceService));
			path = nodeService.getPath(nodeRef).toDisplayPath(nodeService, permissionService);
						
			modifier = AuthenticationUtil.getFullyAuthenticatedUser();
			String company = "";
			if(modifier != null && personService.personExists(modifier)) {
				NodeRef currentLoginUser = personService.getPerson(modifier);
				company = (String) nodeService.getProperty(currentLoginUser, ContentModel.PROP_ORGANIZATION);
			}
			
			auditValues.put("prefixedPath", prefixPath);
			auditValues.put("path", path);
			auditValues.put("noderef", nodeRef);
			auditValues.put("docname", nodeProp.get(ContentModel.PROP_NAME));
			auditValues.put("edcsid", nodeProp.get(CiscoModelConstants.PROP_ALF_ID));
			auditValues.put("security", nodeProp.get(CiscoModelConstants.CISCO_SECURITY_PROP));
			auditValues.put("description", nodeProp.get(ContentModel.PROP_DESCRIPTION));
			auditValues.put("modifier", modifier);
			auditValues.put("company", company == null ? "" : company);
			
			if (action != null && action.trim().length() > 0) {
				auditValues.put("action", action);
			}
			auditValues.put("change_in_permission", permissionChange);

		} catch (Exception e) {
			logger.error("Exception in Permission Audit Info " + e.getMessage());
			logger.error("Details  :::::: " + e);
		}
		return auditValues;

	}

	public void setAuditComponent(AuditComponent auditComponent) {
		this.auditComponent = auditComponent;
	}

	public void setNamespaceService(NamespaceService namespaceService) {
		this.namespaceService = namespaceService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public void setFileFolderService(FileFolderService fileFolderService) {
		this.fileFolderService = fileFolderService;
	}

	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}

	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}

	
}
