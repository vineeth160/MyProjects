package com.cisco.alfresco.external.common.util;

/*
 * Author : mkatnam
 */
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileFolderService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.external.utils.CharUtil;
import com.cisco.sd.rest.service.MigrationConstants;

public class UnPublishUtil {
	
	private static final Logger LOG = Logger.getLogger(UnPublishUtil.class);
	final static SimpleDateFormat format = new SimpleDateFormat("EEE dd MMM yyyy HH:mm:ss z");
	private PersonService personService;
	
	/** Record UnPublish Audit info
     * @param nodeRef
     * @return
     */
    public static Map<String, Serializable> extractUnpublishAuditInfo(NodeRef nodeRef, ServiceRegistry serviceRegistry , String currentLogedInUser) {
    	Map<String, Serializable> auditValues = new HashMap<String, Serializable>();
    	
    	NodeService nodeService = serviceRegistry.getNodeService();
   	    PermissionService permissionService = serviceRegistry.getPermissionService();
    	FileFolderService fileFolderService = serviceRegistry.getFileFolderService();
    	PersonService personService = serviceRegistry.getPersonService();
   	 
    	Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);
    	 try
         {
    	 String prefixPath = nodeService.getPath(nodeRef).toPrefixString(serviceRegistry.getNamespaceService());
    	 auditValues.put("docname", nodeProp.get(ContentModel.PROP_NAME));
         auditValues.put("creator", nodeProp.get(ContentModel.PROP_CREATOR));
         auditValues.put("unpublisher", AuthenticationUtil.getFullyAuthenticatedUser());
         auditValues.put("path", nodeService.getPath(nodeRef).toDisplayPath(nodeService,permissionService));
         auditValues.put("edcsid", nodeProp.get(CiscoModelConstants.PROP_ALF_ID));
         auditValues.put("security", nodeProp.get(CiscoModelConstants.CISCO_SECURITY_PROP));
         auditValues.put("modified", nodeProp.get(ContentModel.PROP_MODIFIED));
         auditValues.put("workflowStatus", nodeProp.get(CiscoModelConstants.CISCO_WORKFLOW_STATUS_PROP));
         auditValues.put("status", nodeProp.get(CiscoModelConstants.PROP_DOC_STATUS));
         auditValues.put("description", nodeProp.get(ContentModel.PROP_DESCRIPTION));
         auditValues.put("event", "UNPUBLISH");
         auditValues.put("noderef", nodeRef);
         auditValues.put("prefixPath", prefixPath);
         auditValues.put("publisher", currentLogedInUser);
         
         String userEmail = "";
         String company = "";
		 if (currentLogedInUser != null && personService.personExists(currentLogedInUser)) {
				NodeRef currentLoginUserRef = personService.getPerson(currentLogedInUser);
				userEmail = (String) nodeService.getProperty(currentLoginUserRef, ContentModel.PROP_EMAIL);
				company = (String) nodeService.getProperty(currentLoginUserRef, ContentModel.PROP_ORGANIZATION);
		}
         auditValues.put("email", userEmail);
         auditValues.put("company", company);
         
         if(nodeProp.get(MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP) != null){
        	 auditValues.put("publishExpirationDate", nodeProp.get(MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP).toString());
         }
         auditValues.put("unpublishedDate", format.format(Calendar.getInstance().getTime()));
         if(fileFolderService.getReader(nodeRef)!=null){
        	 auditValues.put("contentSize", CharUtil.formatFileSize(fileFolderService.getReader(nodeRef).getContentData().getSize()));
         }else{
        	 auditValues.put("contentSize", CharUtil.formatFileSize(0));
         }
         }catch (Exception e)
         {
         	LOG.error("Exception....  ::::  : " + e.getMessage());
         	e.printStackTrace();
         }
         LOG.info(" Audit Values ::" + auditValues.toString());
    	
          return auditValues;
	}
    
    /** record Audit info
     * @param auditValues
     * @param auditComponent
     */
    public static void recordUnpublishAuditInfo(Map<String, Serializable> auditValues, AuditComponent auditComponent, String path){
    	auditComponent.recordAuditValues(path, auditValues);
    }

	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}
    
    
}
