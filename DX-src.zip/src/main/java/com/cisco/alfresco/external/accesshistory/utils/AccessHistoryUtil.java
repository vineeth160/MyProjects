package com.cisco.alfresco.external.accesshistory.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;

import org.alfresco.model.ContentModel;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.PersonService;
import org.apache.log4j.Logger;

public class AccessHistoryUtil {
	private static final Logger _logger = Logger.getLogger(AccessHistoryUtil.class);

	public static final String JSON_KEY_ENTRY_ID 				= "id";
	public static final String JSON_KEY_ENTRY_APPLICATION 		= "application";
	public static final String JSON_KEY_ENTRY_USER 				= "user";
	public static final String JSON_KEY_ENTRY_TIME 				= "time";
	public static final String JSON_KEY_ENTRY_VALUES			= "values";
	public static final String AUDIT_PREVIEW_APP_NAME 			= "preview-report";
	public static final String AUDIT_DOWNLOAD_APP_NAME 			= "download-report";
	public static final String AUDIT_DOWNLOAD_DOC_EDCSID 		="/download-report/document/edcsid";
	public static final String AUDIT_PREVIEW_DOC_EDCSID 		= "/preview-report/document/edcsid";
	public static final String DATE_FORMAT 						= "MM/dd/yyyy HH:mm";
	public static final String DOWNLOAD_ACTION 					= "DOWNLOAD";
	public static final String PREVIEW_ACTION 					= "PREVIEW";
	
	
	
	 /** consolidated audit info from all the actions.
	 * @param personService 
	 * @param nodeService 
	 * @param node 
		 * @param entriesMap
		 * @throws Exception 
		 */
		public static Map<Long, List<String>> getAuditData(List<Map<String, Object>> entries, NodeService nodeService, PersonService personService, String node) throws Exception {
			// TODO Auto-generated method stub
			 List<String> entriesList	 	= null;
			 Date date 						= null;
			 String action 					= null;
			 String company 				= "";
			 StringBuffer sb 				= null;
			 SimpleDateFormat formatter 	= new SimpleDateFormat(DATE_FORMAT);
			 formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
			
			 try{
				 Map<Long, List<String>> finalMap = new TreeMap<Long, List<String>>();
				 for (Map<String, Object> entryMap : entries)
		         {
					 Long entryId 			= (Long) entryMap.get(JSON_KEY_ENTRY_ID);
					 String userId  		= (String) entryMap.get(JSON_KEY_ENTRY_USER);
					 String appName			= (String) entryMap.get(JSON_KEY_ENTRY_APPLICATION);
					 String time 			= entryMap.get(JSON_KEY_ENTRY_TIME).toString();
					 company 				= "";
					 date 					= new Date(time);
					 String accessedDate 	= formatter.format(date)+" GMT";
					 
					 if(!userId.equalsIgnoreCase("admin") && !userId.equalsIgnoreCase("ciscoadmin.gen") && !userId.equalsIgnoreCase("docexbi.gen")){
					 
						 if(personService.personExists(userId))
						 {
							NodeRef person =  personService.getPerson(userId);
							sb = new StringBuffer();
							sb.append((String) nodeService.getProperty(person, ContentModel.PROP_FIRSTNAME)).append(" ").append((String) nodeService.getProperty(person, ContentModel.PROP_LASTNAME));
							company = (String) nodeService.getProperty(person, ContentModel.PROP_ORGANIZATION);
							if(company == null){
								company = "";
							}
						 }
						 
						 if(appName.equals(AUDIT_DOWNLOAD_APP_NAME)){
							 action = DOWNLOAD_ACTION;
						 } else{	
							action = PREVIEW_ACTION;
						 }
						 entriesList = new ArrayList<String>();
						 entriesList.add(action);
						 entriesList.add(node);
						 entriesList.add(company);
						 entriesList.add(accessedDate);
						 entriesList.add(sb.toString());
						 entriesList.add(userId);
						 
						 finalMap.put(entryId, entriesList);
					 }
					
		         }
				 _logger.info(" file Action audit Details :"+finalMap.toString());
				 
				 return finalMap;
				 
		}catch(Exception e){
			_logger.error(" Exception occured while processing the Audit data in getAuditData()"+e.getMessage());
			throw new Exception("Exception occured while processing the Audit data in getAuditData()",e);
		}
	}
}
