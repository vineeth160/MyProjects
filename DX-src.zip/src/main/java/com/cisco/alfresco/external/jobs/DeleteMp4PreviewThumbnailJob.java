package com.cisco.alfresco.external.jobs;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.apache.log4j.Logger;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.cisco.alfresco.external.repo.service.CiscoThumbnailService;


/**
 * 
 * @author dekeswan
 * 
 */
public class DeleteMp4PreviewThumbnailJob extends QuartzJobBean
{
    private static final Logger LOGGER = Logger.getLogger(DeleteMp4PreviewThumbnailJob.class);
    private static final String KEY_IS_JOB_ENABLED = "deleteMp4PreviewThumbnailJobEnabled";
    private boolean isJobEnabled = false;
    private String thumbnailName;
    private CiscoThumbnailService ciscoThumbnailService;

    public void setThumbnailName(String thumbnailName)
    {
        this.thumbnailName = thumbnailName;
    }

    public void setCiscoThumbnailService(CiscoThumbnailService ciscoThumbnailService)
    {
        this.ciscoThumbnailService = ciscoThumbnailService;
    }

    /**
     * @param context
     */
    public void executeInternal(JobExecutionContext context) throws JobExecutionException
    {
        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("Inside executeInternal method");
        }
        JobDataMap jobData = context.getJobDetail().getJobDataMap();
        String isJobEnabledStr = (String) jobData.get(KEY_IS_JOB_ENABLED);

        if (isJobEnabledStr != null)
        {
            try
            {
                isJobEnabled = new Boolean(isJobEnabledStr);
            }
            catch (Exception e)
            {
                LOGGER.error("Invalid '" + KEY_IS_JOB_ENABLED + "' value, using default: " + isJobEnabled, e);
            }
        }

        if (!isJobEnabled)
        {
            LOGGER.error("Skipping " + KEY_IS_JOB_ENABLED + " to execute.");
            return;
        }

        AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
        {
            @Override
            public Object doWork() throws Exception
            {
                ciscoThumbnailService.deleteThumbnails(thumbnailName);
                return null;
            }
        }, AuthenticationUtil.getAdminUserName());
    }

}
