package com.cisco.alfresco.external.selfPemissionUpdate;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;

public class SelfUpdatePermissionService extends DeclarativeWebScript{
	private static final Logger logger = Logger.getLogger(SelfUpdatePermissionService.class);
	private ServiceRegistry serviceRegistry;
    private PreferenceService preferenceService;
    public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}
	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
	
	public void setPreferenceService(PreferenceService preferenceService)
    {
        this.preferenceService = preferenceService;
    }
	
	@Override
	public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, Cache cache)
    {
		final Map<String, Object> model=new HashMap<String, Object>();
        logger.info("SelfUpdatePermissionService triggered.... ");
		String userName = AuthenticationUtil.getFullyAuthenticatedUser();
		String noderef = req.getParameter("nodeRef");
		String action = req.getParameter("action");
		NodeRef personNode = serviceRegistry.getPersonService().getPerson(userName);
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
		logger.info("Action ::: " +action);
		if(action.equalsIgnoreCase("retrieve")){
			String role = getAccessLevel(userName, new NodeRef(noderef));
			logger.info("role:::: " +role);
			String firstName = (String) serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_FIRSTNAME);
            String lastName = (String) serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_LASTNAME);
            String emailId = (String) serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_EMAIL);
            logger.info("firstName :: " +firstName+ "  :: lastName ::: "+lastName+ " : ::: emailId :::: " +emailId);
            int admincount = 0 ; String isDisable = "false";
            if(role.equalsIgnoreCase("AdminRole") && !role.isEmpty())
            {
            	admincount = 1;
            	Set<AccessPermission> userSet = serviceRegistry.getPermissionService().getAllSetPermissions(new NodeRef(noderef));
            	if (userSet.size() > 0)
        		{
        			for (AccessPermission accessPermission : userSet)
        			{
        				if(accessPermission.getPermission().equals("AdminRole") && !accessPermission.getAuthority().equals(userName))
        				admincount++;
        			}
                }
            }
			logger.error("admin count ::: " +admincount);	
            if(!role.isEmpty()){
            	String[] userRole = role.split("Role");
            	role = userRole[0];
            	if(role.equalsIgnoreCase("admin"))
            		role = "Folder Admin";
            }
            if(admincount == 1){
            	isDisable = "true";
            }
            logger.error(isDisable);
			model.put("userAccessLevel", role);
			model.put("firstName", firstName);
			model.put("lastName", lastName);
			model.put("emailId", emailId);
			model.put("isDisable", isDisable);
		}
		if(action.equalsIgnoreCase("update")){
		    NodeRef nodeRef = new NodeRef(noderef);
			if(serviceRegistry.getNodeService().exists(nodeRef)){
			    removeAccessLevel(userName, nodeRef);
			}
		}
		 return model;
			}
		},"admin");
		return model;
	}
	
	public void removeAccessLevel(String userName, NodeRef nodeRef)
	{
		Set<AccessPermission> userSet = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
		if (userSet.size() > 0)
		{
			for (AccessPermission accessPermission : userSet)
			{
				String user = accessPermission.getAuthority();
				String role = accessPermission.getPermission();
				logger.info("user ::: " +user + " ::: role :::: " +role);
				if (user.equals(userName) && accessPermission.isSetDirectly())
				{
					serviceRegistry.getPermissionService().clearPermission(nodeRef, userName);
					logger.info("Permission deleted !!!!");
					String preferenceStatus=ExternalSharingFileFolderUtil.updateUserPreferenceFolderList(serviceRegistry, preferenceService, nodeRef.toString(), userName);
					logger.info("Preferences deleted !!!!"+preferenceStatus);
				}
			}
		}
      
	}
	
	public String getAccessLevel(String userName, NodeRef nodeRef)
	{
		String role = "";
		Set<AccessPermission> userSet = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
		logger.info("userset :::: " +userSet.size());
		if (userSet.size() > 0)
		{
			for (AccessPermission accessPermission : userSet)
			{
				String user = accessPermission.getAuthority();
				if (user.equals(userName) && accessPermission.isSetDirectly())
					role = accessPermission.getPermission();
			}
		}
       return role;
	}
	
}
