package com.cisco.alfresco.external.webscript;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.sd.rest.service.MigrationConstants;

public class UpdateExpiringDateForDocuments extends DeclarativeWebScript {

	 private static Logger LOGGER = Logger.getLogger(UpdateExpiringDateForDocuments.class);
	 private NodeService nodeService;
	 private static ServiceRegistry serviceRegistry;
	 private NamespaceService  namespaceService;
	 
@SuppressWarnings("deprecation")
public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache){
		Map<String, Object> model = new HashMap<String, Object>();
		List<NodeRef>fileListQuery = new ArrayList<NodeRef>();
	try {	
		 Content reqContent = req.getContent();
		 Date expirationDate=null;
		 boolean isCheckoutDoc = false;
		 Boolean cascadeFolder = false;
         if (reqContent == null)
         {
             throw new WebScriptException(Status.STATUS_BAD_REQUEST, "Missing POST request body.");
         }
         LOGGER.info("inside update expdates servicesss :::: ");
         JSONObject userRequestJson = new JSONObject(reqContent.getContent());
         NodeRef nodeRefId = new NodeRef(userRequestJson.getString("nodeId"));
         String expDate = userRequestJson.getString("expirationDate");
         LOGGER.info("input expirationDate :::::::: "+expDate);
         String cascadeFolderValue = userRequestJson.getString("cascade");
         cascadeFolder = Boolean.parseBoolean(cascadeFolderValue);
         String loggedinUserId = AuthenticationUtil.getFullyAuthenticatedUser();
         if(serviceRegistry.getAuthorityService().isAdminAuthority(loggedinUserId)||getNodeUserPermissions(nodeRefId,loggedinUserId)){
         if(checkDate(expDate) && checkwithCurrentDate(expDate)){
        	 QName nodeType = nodeService.getType(nodeRefId);
     		if (expDate != null && !expDate.equals("")&& !expDate.equals("null")) {
     			expirationDate = new Date(expDate);
     		}
     		LOGGER.info("expirationDate :::::::: "+expirationDate);
        	 if(nodeType.equals(ContentModel.TYPE_FOLDER)){
        		 LOGGER.info("::::: inside update expdates folder condition ::::");
        		 fileListQuery = getDeepDocsFromFloder(nodeRefId,cascadeFolder);
        		 LOGGER.info("::::: fileListQuery docs size ::::"+fileListQuery.size());
        		 if(fileListQuery.size()>0){
        		 for (NodeRef docNodeId : fileListQuery) {
        			 if(getNodeUserPermissions(docNodeId,loggedinUserId)){
        			 isCheckoutDoc = serviceRegistry.getCheckOutCheckInService().isCheckedOut(
        					 docNodeId);
        			 LOGGER.info("before checkout:::::: " + docNodeId + " ::::: isCheckedOut? ::: " + isCheckoutDoc);
     			if (isCheckoutDoc) {
     				NodeRef workingCopyNodeRef = serviceRegistry.getCheckOutCheckInService()
     						.getWorkingCopy(docNodeId);
     				NodeRef newNodeRefId = serviceRegistry.getCheckOutCheckInService()
     						.cancelCheckout(workingCopyNodeRef);
     				isCheckoutDoc = serviceRegistry.getCheckOutCheckInService().isCheckedOut(
     						newNodeRefId);
     				 LOGGER.info("after checkout:::::: " + newNodeRefId + " ::: isCheckedOut? :: " + isCheckoutDoc);
     				 //US10596 - start
     				 if(serviceRegistry.getNodeService().getProperty(docNodeId, MigrationConstants.IS_EXP_DATE_CHANGED_PROP)!=null) {
     				boolean isExpirationDateChanged = (boolean) serviceRegistry.getNodeService().getProperty(newNodeRefId, MigrationConstants.IS_EXP_DATE_CHANGED_PROP);
     				if(!isExpirationDateChanged) {
     				 isExpDateChangeAllowed(expirationDate,newNodeRefId);
     				 nodeService.setProperty(newNodeRefId, MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP, expirationDate);
     				}
     				 }else {
      					LOGGER.info("else IS_EXP_DATE_CHANGED_PROP is null:::::::: ");
      					if(nodeService.hasAspect(docNodeId, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT)) {
      						serviceRegistry.getNodeService().setProperty(docNodeId, MigrationConstants.IS_EXP_DATE_CHANGED_PROP,false);
          					boolean isExpirationDateChanged = (boolean) serviceRegistry.getNodeService().getProperty(docNodeId, MigrationConstants.IS_EXP_DATE_CHANGED_PROP);
             				if(!isExpirationDateChanged) {
                 				 isExpDateChangeAllowed(expirationDate,docNodeId);
                 				 nodeService.setProperty(docNodeId, MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP, expirationDate);
                 				} 
      						}
     				 }
     			}else{
     				 //US10596 - start
     				 if(serviceRegistry.getNodeService().getProperty(docNodeId, MigrationConstants.IS_EXP_DATE_CHANGED_PROP)!=null) {
     					boolean isExpirationDateChanged = (boolean) serviceRegistry.getNodeService().getProperty(docNodeId, MigrationConstants.IS_EXP_DATE_CHANGED_PROP);
        				LOGGER.info("isExpirationDateChanged :::::::: "+isExpirationDateChanged);
         				if(!isExpirationDateChanged) {
         				 isExpDateChangeAllowed(expirationDate,docNodeId);
         				 nodeService.setProperty(docNodeId, MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP, expirationDate);
         				} 
     				 }else {
     					LOGGER.info("else IS_EXP_DATE_CHANGED_PROP is null:::::::: ");
     					if(nodeService.hasAspect(docNodeId, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT)) {
     						serviceRegistry.getNodeService().setProperty(docNodeId, MigrationConstants.IS_EXP_DATE_CHANGED_PROP,false);
         					boolean isExpirationDateChanged = (boolean) serviceRegistry.getNodeService().getProperty(docNodeId, MigrationConstants.IS_EXP_DATE_CHANGED_PROP);
            				if(!isExpirationDateChanged) {
                				 isExpDateChangeAllowed(expirationDate,docNodeId);
                				 nodeService.setProperty(docNodeId, MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP, expirationDate);
                				} 
     					}
     				 }
     				
     			}
        		 }else{
        			 model.put("statusMessage", "You are not authorized to perform this operation.");
        		 }
        		 }
        	 }else{
        		 model.put("statusMessage", "There are no documents are avilable to update expiry date");
        	 }
        		 model.put("statusMessage", "Expiry date have been updated successfully");
        	 }else{
        		 LOGGER.info("before input expirationDate :::::::: "+expirationDate);
        		 //US10596 - start
        		 if(serviceRegistry.getNodeService().getProperty(nodeRefId, MigrationConstants.IS_EXP_DATE_CHANGED_PROP)!=null) {
        		 boolean isExpirationDateChanged = (boolean) serviceRegistry.getNodeService().getProperty(nodeRefId, MigrationConstants.IS_EXP_DATE_CHANGED_PROP);
	  				if(!isExpirationDateChanged) {
	  				 isExpDateChangeAllowed(expirationDate,nodeRefId);
	        		 nodeService.setProperty(nodeRefId, MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP, expirationDate);
	  				}
        		 }else {
  					LOGGER.info("else IS_EXP_DATE_CHANGED_PROP is null:::::::: ");
  					if(nodeService.hasAspect(nodeRefId, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT)) {
  						serviceRegistry.getNodeService().setProperty(nodeRefId, MigrationConstants.IS_EXP_DATE_CHANGED_PROP,false);
      					boolean isExpirationDateChanged = (boolean) serviceRegistry.getNodeService().getProperty(nodeRefId, MigrationConstants.IS_EXP_DATE_CHANGED_PROP);
         				if(!isExpirationDateChanged) {
             				 isExpDateChangeAllowed(expirationDate,nodeRefId);
             				 nodeService.setProperty(nodeRefId, MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP, expirationDate);
             				} 
  					}
  				 
        		 }
        		 model.put("statusMessage", "Expiry date have been updated successfully");
        	 }
         }else{
        	 model.put("statusMessage", "Expiry date is more than 3 years so you do not have authority to perform this operation.");
         }
         }else{
        	 model.put("statusMessage", "You are not authorized to perform this operation.");
         }
	
	}catch (Exception e){
		LOGGER.info("in exception :::: "+e.getMessage());
		e.printStackTrace();
	}
	return model;
    }
	
	//check date 
	@SuppressWarnings("deprecation")
	private boolean checkDate(String inputDate)
	{
		int daysToSubtract=1095;
		boolean isValidDate=false;
		try {
	    Calendar c = Calendar.getInstance();
	    c.add(Calendar.DATE, daysToSubtract);
	    Date fromDate=c.getTime();
		Date expDate=new Date(inputDate);
	    if(expDate.before(fromDate)){
	    	isValidDate=true;
	    }else{
	    	isValidDate=false;
	    }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOGGER.info("::isValidDate::"+isValidDate);
		return isValidDate;
	}
	
	@SuppressWarnings("deprecation")
	private boolean checkwithCurrentDate(String inputDate)
	{
		boolean afterCurrentDate=false;
		try {
	    Date expDate=new Date(inputDate);
	    Date currentDate = new Date();
	    if(expDate.after(currentDate) || (expDate.equals(currentDate))){
	    	LOGGER.info("The date is future day");
	        afterCurrentDate=true;
	    } else {
	    	LOGGER.info("The date is older than current day");
	        afterCurrentDate=false;
	    }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOGGER.info("::afterCurrentDate ::"+afterCurrentDate);
		return afterCurrentDate;
	}
	//get documents from folder
		private  List<NodeRef> getDeepDocsFromFloder(NodeRef nodeRefId,boolean cascadeFolder)
		{
			List<NodeRef>fileList = new ArrayList<NodeRef>();
			try{
				String folderQnamepath = nodeService.getPath(nodeRefId).toPrefixString(namespaceService);
				StringBuilder luceneQuery = new StringBuilder();
				//luceneQuery.append("PATH:\""+folderQnamepath+"//*\" AND TYPE:\"cs:ciscodoc\" AND NOT ASPECT:\"cm:checkedOut\" AND NOT ASPECT:\"cm:workingcopy\"");
				if(cascadeFolder){
				luceneQuery.append("PATH:\""+folderQnamepath+"//*\" AND TYPE:\"cs:ciscodoc\" AND NOT ASPECT:\"cm:workingcopy\"");
				}else{
					luceneQuery.append("PATH:\""+folderQnamepath+"/*\" AND TYPE:\"cs:ciscodoc\" AND NOT ASPECT:\"cm:workingcopy\"");
				}
				LOGGER.info("Final lucene Query is : " + luceneQuery.toString());
				List<NodeRef> childDocList = EDCSUtil.getNodeRefList(luceneQuery.toString(), serviceRegistry);
				if(childDocList != null && !childDocList.isEmpty()){
					for(NodeRef childDocument : childDocList){
						LOGGER.info("list of child docs are ::::::::: " + childDocument.toString());
						fileList.add(childDocument);
					}
				}
			}catch(Exception ex){
				LOGGER.info("query error :::: "+ex.getMessage());;
			}
				return fileList;
		}
	
		 /**
	     * To Get User permissions for document/folder
	     */
	    public static boolean getNodeUserPermissions(final NodeRef nodeRef,String loginUserId){
	    	 boolean haveValidPermission=false;
	    	 ArrayList<String> permissionsHavingloggedInUser = new ArrayList<String>();
	    	 Set<AccessPermission> accessPermissions = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
	    	 LOGGER.info("Permissions: " + accessPermissions);
             Iterator<AccessPermission> fIterator = accessPermissions.iterator();
             AccessPermission accessPerm = null;
             while (fIterator.hasNext())
             {
                 accessPerm = fIterator.next();
                 if (loginUserId.equalsIgnoreCase(accessPerm.getAuthority()))
                 {
                	 LOGGER.info("In if loop - adding users to the permission ::"+accessPerm.getAuthority()+":");
                    //loggedInUserPermission = accessPerm.getPermission().toString();
                	 permissionsHavingloggedInUser.add(accessPerm.getPermission());
                 }
             }
             LOGGER.info("permissionsHavingloggedInUser: " + permissionsHavingloggedInUser.toString());
	    	 
             if (permissionsHavingloggedInUser != null
                     && (permissionsHavingloggedInUser.contains("AdminRole") || permissionsHavingloggedInUser.contains("Folder Admin")))
            	 haveValidPermission= true;
             else
            	 haveValidPermission= false;
             
             LOGGER.info("UpdateExpiringDateForDocuments haveValidPermission ::::: "+haveValidPermission);
			  return haveValidPermission;
		  }

	private void isExpDateChangeAllowed(Date inputExpirationDate,NodeRef nodeRefId) {
		Date nodeExpirationDate=(Date) serviceRegistry.getNodeService().getProperty(nodeRefId,MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP);	
		if(nodeExpirationDate!=null) {
			if(getZeroTimeDate(inputExpirationDate).equals(getZeroTimeDate(nodeExpirationDate))){	
				serviceRegistry.getNodeService().setProperty(nodeRefId,MigrationConstants.IS_EXP_DATE_CHANGED_PROP,
						false);
			} else {
		serviceRegistry.getNodeService().setProperty(nodeRefId,MigrationConstants.IS_EXP_DATE_CHANGED_PROP,true);
			}
			}else {
				serviceRegistry.getNodeService().setProperty(nodeRefId,MigrationConstants.IS_EXP_DATE_CHANGED_PROP,
						false);
			}
	}

	private static Date getZeroTimeDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		date = calendar.getTime();
		return date;
	}
	
	public NodeService getNodeService()
    {
        return nodeService;
    }

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }
    public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
	public NamespaceService getNamespaceService() {
		return namespaceService;
	}

	public void setNamespaceService(NamespaceService namespaceService) {
		this.namespaceService = namespaceService;
	}


}