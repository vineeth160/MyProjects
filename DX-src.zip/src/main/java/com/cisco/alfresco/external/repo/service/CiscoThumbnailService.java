package com.cisco.alfresco.external.repo.service;

/**
 * 
 * @author dekeswan
 * 
 */
public interface CiscoThumbnailService
{

    /**
     * 
     * @param thumbnailName
     */
    public void deleteThumbnails(final String thumbnailName);

}