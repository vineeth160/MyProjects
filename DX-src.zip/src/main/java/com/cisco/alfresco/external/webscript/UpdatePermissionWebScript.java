package com.cisco.alfresco.external.webscript;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AuthenticationService;
import org.alfresco.service.cmr.security.MutableAuthenticationService;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;


public class UpdatePermissionWebScript extends AbstractWebScript
{
    private static Logger LOGER = Logger.getLogger(UpdatePermissionWebScript.class);
    private ServiceRegistry serviceRegistry;
    private PersonService personService;
    private PermissionService permissionService;
    private AuthenticationService authenticationService;

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException
    {
        update(req, res);
    }

    public void update(WebScriptRequest req, WebScriptResponse res)
    {
        LOGER.info("CreateExtUserWebScript.createUser method start...");
        personService = serviceRegistry.getPersonService();
        permissionService = serviceRegistry.getPermissionService();
        authenticationService = serviceRegistry.getAuthenticationService();
        try
        {
            // NodeRef usersFolderNode = EDCSUtil.doSearch("PATH:\"/sys:system/sys:people\"", serviceRegistry);
            // org.springframework.extensions.surf.util.Content content = req.getContent();
            // JSONObject json;

            JSONParser jsonParser = new JSONParser();
            org.json.simple.JSONObject jsonObject = null;
            jsonObject = (JSONObject) jsonParser.parse(req.getParameter("jsonMetadata"));

            // jsonObject = new JSONObject(content.getContent());
            String userName = (String) jsonObject.get("userName");
            String firstName = (String) jsonObject.get("firstName");
            String lastName = (String) jsonObject.get("lastName");
            String email = (String) jsonObject.get("email");
            String organization = (String) jsonObject.get("organization");
            LOGER.info("userName::" + userName);
            LOGER.info("firstName::" + firstName);
            LOGER.info("lastName::" + lastName);
            LOGER.info("email::" + email);
            LOGER.info("organization::" + organization);

            boolean isUserExists = personService.personExists(userName);
            if (!isUserExists)
            {
                HashMap<QName, Serializable> properties = new HashMap<QName, Serializable>();
                properties.put(ContentModel.PROP_USERNAME, userName);
                // properties.put(ContentModel.PROP_HOMEFOLDER, userNodeRef);
                properties.put(ContentModel.PROP_FIRSTNAME, firstName);
                properties.put(ContentModel.PROP_LASTNAME, lastName);
                properties.put(ContentModel.PROP_EMAIL, email);
                properties.put(ContentModel.PROP_ORGANIZATION, organization);
                NodeRef newPerson = this.personService.createPerson(properties);
                // authenticationService.getAuthenticationEnabled("");
                LOGER.info("newPerson::" + newPerson);
                // ensure the user can access their own Person object
                // permissionService.setPermission(newPerson,"GROUP_EVERYONE", permissionService.getAllPermission(),
                // true);
                // create the ACEGI Authentication instance for the new user
                ((MutableAuthenticationService) authenticationService).createAuthentication(userName,
                    userName.toCharArray());
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }
}
