package com.cisco.alfresco.external.common.model;

import java.util.Date;

/**
 * 
 * @author nabbeher
 * 
 */
public class Folder extends Asset
{

    String relativePath;
    boolean isFolderEmpty;
    String created;
    String modified;
    Date modDate;
    boolean favoriteStatus;
    boolean rootFolder;
    boolean domainMismatch;
    boolean createdInDocExchange; 
    boolean dcFolderExists; 
    public boolean isDcFolderExists() {
		return dcFolderExists;
	}
	public void setDcFolderExists(boolean dcFolderExists) {
		this.dcFolderExists = dcFolderExists;
	}
	String applyVeraProtection;
    String tags;
    
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public boolean isDomainMismatch() {
		return domainMismatch;
	}
	public void setDomainMismatch(boolean domainMismatch) {
		this.domainMismatch = domainMismatch;
	}
	
   	public boolean isCreatedInDocExchange() {
   		return createdInDocExchange;
   	}
   	public void setCreatedInDocExchange(boolean createdInDocExchange) {
   		this.createdInDocExchange = createdInDocExchange;
   	}
    
    public boolean isRootFolder() {
		return rootFolder;
	}

	public void setRootFolder(boolean rootFolder) {
		this.rootFolder = rootFolder;
	}

    public boolean isFavoriteStatus() {
		return favoriteStatus;
	}

	public void setFavoriteStatus(boolean favoriteStatus) {
		this.favoriteStatus = favoriteStatus;
	}

    public Date getModDate() {
		return modDate;
	}

	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}

	public Folder()
    {

    }

    public String getRelativePath()
    {
        return relativePath;
    }

    public void setRelativePath(String relativePath)
    {
        this.relativePath = relativePath;
    }

	public boolean isFolderEmpty() {
		return isFolderEmpty;
	}

	public void setFolderEmpty(boolean isFolderEmpty) {
		this.isFolderEmpty = isFolderEmpty;
	}
	
	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public String getModified() {
		return modified;
	}

	public void setModified(String modified) {
		this.modified = modified;
	}
	public String getApplyVeraProtection() {
		return applyVeraProtection;
	}
	public void setApplyVeraProtection(String applyVeraProtection) {
		this.applyVeraProtection = applyVeraProtection;
	}

}
