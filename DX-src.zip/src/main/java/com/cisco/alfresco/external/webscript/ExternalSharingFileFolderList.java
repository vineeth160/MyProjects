package com.cisco.alfresco.external.webscript;

import java.io.Serializable;
import java.io.StringWriter;
import java.io.Writer;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.alfresco.model.ContentModel;
import org.alfresco.query.PagingRequest;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.ContentData;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.Path;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.namespace.InvalidQNameException;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.namespace.RegexQNamePattern;
import org.alfresco.util.ISO9075;
import org.alfresco.util.Pair;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.external.common.model.ExtDocument;
import com.cisco.alfresco.external.common.model.Folder;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.alfresco.external.domain.CheckDomain;
import com.cisco.alfresco.external.utils.CharUtil;
import com.cisco.alfresco.external.viewfav.Viewfav;
import com.cisco.sd.rest.service.MigrationConstants;

public class ExternalSharingFileFolderList extends DeclarativeWebScript
{
    private static final Logger LOGGER = Logger.getLogger(ExternalSharingFileFolderList.class);
    private NodeService nodeService;
    private ServiceRegistry serviceRegistry;
    private String alfrescoURL;
    private String contextName;
    private int pageSize;
    final static String CISCO_MODEL_URI = "http://www.cisco.com/model/content/1.0";
    QName ASSOC_NAME_MYFAVORITE_ASSOCIATE = QName.createQName(CISCO_MODEL_URI, "myFavorite");
    private static final String GROUP_EVERYONE="GROUP_EVERYONE";
	private static final String GROUP_IDENTITY ="GROUP_";

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

    @Override
    public Map<String, Object> executeImpl(final WebScriptRequest req, Status status, Cache cache)
    {
        LOGGER.info("------------- ExternalSharingFileFolderList executeImpl ----------");
        final Map<String, Object> model = new HashMap<String, Object>();
        boolean isFolderEmpty = false;
        boolean userHasAccess =  false;
        try
        {
            String strNodeRef = req.getParameter("id");
            NodeRef nodeRef = new NodeRef(strNodeRef);            
            String publisherId = req.getParameter("publisherId");
    		LOGGER.info(" In case of caling ExternalSharingFolderList with publisherId ::: "+publisherId);
        	String currentUser=null;
        	if(publisherId!=null && !publisherId.isEmpty()){
        		currentUser =publisherId;
        	}else{
        		 currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
        	}

        	Set<AccessPermission> permSet =	getAllNodeRefPermissions(nodeRef);
        	userHasAccess = hasAccess(currentUser, nodeRef, permSet);
            LOGGER.info("does user has access on either doc or folder " + userHasAccess);
            
            if(userHasAccess){
            	QName PROP_CONTENT_SIZE = QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, "content.size");
            	QName PROP_CONTENT_MIMETYPE = QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, "content.mimetype");
            	String pageNo = getParameter(req,"pageNo");
            	String sortBy = getParameter(req,"sortBy");
            	String sortOrder = getParameter(req,"sortOrder");
            	String hostname = getParameter(req,"geoHostName");
            	if(!hostname.isEmpty()&& hostname != null){
    				hostname = Viewfav.hostValidation(hostname);
    				LOGGER.info("------------------------->>>> : "+hostname);
    			}
				int pageNum;
				if (pageNo == null || pageNo == "" || pageNo.isEmpty()) {
					pageNum = 1;
				} else {
					pageNum = Integer.parseInt(req.getParameter("pageNo"));
				}
				LOGGER.info("pageNum----------" + pageNum);
				
				if(getParameter(req,"pageSize") !=null && !getParameter(req,"pageSize").isEmpty()){
					pageSize = Integer.parseInt(getParameter(req,"pageSize"));
				}
				LOGGER.info("pageSize----------" + pageSize);
		        NodeRef personNodereff=serviceRegistry.getPersonService().getPerson(currentUser);
				QName ASSOC_NAME_MYFAVORITE_ASSOCIATE = QName.createQName(CISCO_MODEL_URI, "myFavorite");
	            List<NodeRef> customFablist = new ArrayList<NodeRef>();
	              List<ChildAssociationRef> childAssocList = nodeService.getChildAssocs(personNodereff,ASSOC_NAME_MYFAVORITE_ASSOCIATE,RegexQNamePattern.MATCH_ALL,false);
	            if(childAssocList.size() >0){
	                for (ChildAssociationRef child : childAssocList){ 
	                NodeRef childNodeRef = child.getChildRef();
	               customFablist.add(childNodeRef);
	                }
	            }
	            
	            //Pagination
				PagingRequest paging = new PagingRequest(0, Integer.MAX_VALUE, null);
				boolean isAscOrder = false;
				if (sortOrder == null || sortOrder == "" || ("asc").equalsIgnoreCase(sortOrder))  {
					isAscOrder = true;
				}
			    // Sorting
			    List<Pair<QName,Boolean>> sort = new ArrayList<Pair<QName,Boolean>>();
				    if (sortBy == null || sortBy == ""
							|| ("modified").equalsIgnoreCase(sortBy)) {
				    	 sort.add(new Pair<QName, Boolean>(ContentModel.PROP_MODIFIED, isAscOrder));
				    }
					else if (("name").equalsIgnoreCase(sortBy)) {
						 sort.add(new Pair<QName, Boolean>(ContentModel.PROP_NAME, isAscOrder));
					}
					else if (("expirationDate").equalsIgnoreCase(sortBy)) {
						 sort.add(new Pair<QName, Boolean>(ExternalSharingConstants.PROP_EXPIRAIONDATE, isAscOrder));
					}
				    
					else if (("size").equalsIgnoreCase(sortBy)) {
						sort.add(new Pair<QName, Boolean>(PROP_CONTENT_SIZE, isAscOrder));
					}
				    
					/*else if (("type").equalsIgnoreCase(sortBy)) {
						sort.add(new Pair<QName, Boolean>(PROP_CONTENT_MIMETYPE, isAscOrder));
					}*/
				 
					else if (("edcsId").equalsIgnoreCase(sortBy)) {
						sort.add(new Pair<QName, Boolean>(ExternalSharingConstants.PROP_EDCS_ID, isAscOrder));
					}
				 
				int totalResults = 0;
                List<FileInfo> folderInfoList = new ArrayList<FileInfo>();
                Set<QName> excludeQname = new HashSet<>(1);
                excludeQname.add(ContentModel.ASPECT_CHECKED_OUT);
                if (("type").equalsIgnoreCase(sortBy)) {
       			 LOGGER.info("-------inside sort by type ---------");
       			 //folderInfoList = serviceRegistry.getFileFolderService().list(nodeRef);
       			 folderInfoList = serviceRegistry.getFileFolderService().list(nodeRef, true, true, excludeQname,  null, paging).getPage();
       			 totalResults = folderInfoList.size();
       			 
       			  if (sortOrder == null || sortOrder == "" || sortOrder.equalsIgnoreCase("asc"))
       				  	Collections.sort(folderInfoList, typeAscComparator);
       			  else 
       			  		Collections.sort(folderInfoList, typeDescComparator);
       			  
				} else {
                		//getting folders list
                		folderInfoList = serviceRegistry.getFileFolderService().list(nodeRef, false, true, excludeQname,  sort, paging).getPage();
                		//getting files list
                		folderInfoList.addAll(serviceRegistry.getFileFolderService().list(nodeRef, true, false, excludeQname,  sort, paging).getPage());
                		totalResults = folderInfoList.size();
				}
                		LOGGER.info("totalResults---> "+totalResults);
                		LOGGER.info("folderInfoList---> "+folderInfoList);
        				// Retrieving per page items only
        				int startRow = 0;
        				int endRow = 0;
        				if(pageNum != 0) {
        					 startRow =  (pageNum-1)*pageSize;
        					 endRow = startRow+pageSize;
        				 }
        				startRow = startRow == 0 ?  startRow : startRow;
        				endRow = endRow > totalResults ? totalResults : endRow-1;
        				@SuppressWarnings("rawtypes")
						List<ArrayList> searchList = new ArrayList<ArrayList>();
        				 searchList = getFileFolderList(folderInfoList,currentUser, isFolderEmpty, customFablist,hostname, startRow, endRow, pageNum);
        				LOGGER.info("searchList  ::"+searchList);
        				
            List<Folder> breadcrumbLst = new ArrayList<Folder>();
            breadcrumbLst = getNodeRefProperties(nodeRef, breadcrumbLst,isFolderEmpty,customFablist,currentUser,permSet);
            List<Folder> breadCrumbNodeLst = getAllParentNodeRef(nodeRef, breadcrumbLst,currentUser);
            Collections.reverse(breadCrumbNodeLst);
            List<Folder> folderInfo = new ArrayList<Folder>();
            folderInfo = getNodeRefProperties(nodeRef, folderInfo,isFolderEmpty,customFablist,currentUser,permSet);
            ObjectMapper mapper = new ObjectMapper();
            Writer strWriter = new StringWriter();
            mapper.writeValue(strWriter, searchList);
            String jsonString = strWriter.toString();
            Writer strWriter1 = new StringWriter();
            ObjectMapper mapper1 = new ObjectMapper();
            mapper1.writeValue(strWriter1, breadCrumbNodeLst);
            Writer strWriter2 = new StringWriter();
            ObjectMapper mapper2 = new ObjectMapper();
            mapper2.writeValue(strWriter2, folderInfo);
            LOGGER.info("Result JSON : " + jsonString);
            
            model.put("result", searchList);
            if(searchList.size() >1) {
            	model.put("result1", searchList.get(0));
            	model.put("result2", searchList.get(1));
            }else {
            	model.put("result1", searchList.get(0));
            }
            model.put("breadcrumb", breadCrumbNodeLst);
            model.put("folderInfo", folderInfo);
            model.put("parentNodeRef", strNodeRef);
            model.put("permissionLevel",getUserRole(currentUser, nodeRef, permSet));
            model.put("totalCount",totalResults);
            model.put("pageNo",pageNum);
            model.put("pageSize",pageSize);
            if (sortOrder == null || sortOrder == "" || sortOrder.isEmpty()) {
            model.put("sortOrder","asc");
            } else {
            	 model.put("sortOrder",sortOrder);
            }
            if (sortBy == null || sortBy == "" || sortBy.isEmpty()) {
            model.put("sortBy","modified");
            }
            else {
           	 model.put("sortBy",sortBy);
           }
            model.put("hasAccess", "YES");
        } else {
        	LOGGER.error("NO ACCESS........");
        	
        }
        }
        catch (InvalidNodeRefException ine)
        {
            LOGGER.error("InvalidNodeRefException : " + ine);
            ine.printStackTrace();
        }
        catch (Exception e)
        {
            LOGGER.error("Exception : " + e);
            e.printStackTrace();
        }
        LOGGER.info("--- Finished in ExternalSharingFileFolderList ---");
        if(!userHasAccess){
        	LOGGER.info("NO ACCESS........");
        	throw new WebScriptException(409, "You are not authorized to access this information");
        }
        return model;
    }
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public List<ArrayList> getFileFolderList(List<FileInfo> fileInfoList,String currentUser, boolean isFolderEmpty, List<NodeRef> customFablist,String hostname, int startRow, int endRow, int pageNum) {
    	
		ArrayList fileFolderList = new ArrayList<ArrayList>();
		ArrayList<ExtDocument> listFolder = new ArrayList<ExtDocument>();
		ArrayList<ExtDocument> listExtDocs = new ArrayList<ExtDocument>();
        try
        {
            LOGGER.info("current user : " + currentUser);
            LOGGER.info("startRow ----------------> "+startRow+" \t endRow ----------------> "+endRow);
       	 if(!fileInfoList.isEmpty()) {
	        	 for (int fldIndex = startRow; (fldIndex < fileInfoList.size() && fldIndex <= endRow); fldIndex++) {
	        		 LOGGER.info("Getting  folderInfoList.get("+fldIndex+") ----------------> ");
	        		 FileInfo fileInfo  = fileInfoList.get(fldIndex);
                NodeRef nodeRef = fileInfo.getNodeRef();
                LOGGER.info("nodeRef : " + nodeRef);
                
                 Set<AccessPermission> childPerSet = getAllNodeRefPermissions(nodeRef);
                boolean hasPermission = hasAccess(currentUser, nodeRef, childPerSet);
                if (fileInfo.getType().equals(ContentModel.TYPE_FOLDER))
                {
                	ExtDocument folder = new ExtDocument();
                    Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);
                    isFolderEmpty = true;
                    String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
                    String newFilename = new String(fileName.getBytes(),"UTF-8");
                   // String newFilename = new String(fileName.getBytes("ISO-8859-1"),"UTF-8");
                    fileName = CharUtil.replaceEscape(newFilename);
                    LOGGER.info("<<<<testing russian name>>>> : " + newFilename);
                    folder.setName(ISO9075.decode(fileName));

                    folder.setNodeId(nodeRef.toString());

                    String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
                    title = CharUtil.replaceEscape(title);
                    folder.setTitle(ISO9075.decode(title));

                    String description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
                    description = CharUtil.replaceEscape(description);
                    folder.setDescription(ISO9075.decode(description));

                    folder.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
                    folder.setCreationdate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
                            .get(ContentModel.PROP_CREATED))));
                    folder.setModifieddate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
                            .get(ContentModel.PROP_MODIFIED))));
                    folder.setType("folder");
                    Path path = nodeService.getPath(nodeRef);
                    String filePath = "";
                    if (path != null)
                    {
                        filePath = path.toString();
                        filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/application/1.0\\}", "");
                        filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "");
                        filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}", "");
                    }
                    folder.setRelativePath(ISO9075.decode(filePath));

                    if(CheckDomain.getDomainStatus(nodeRef.toString()).get("status1") == "401"){
                   	 LOGGER.info("in if inside 401-------");
                   	 folder.setDomainMismatch(false);
                    } else {
                   	 folder.setDomainMismatch(true);
                    }

                    folder.setApplyVeraProtection((String) nodeProp.get(ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION));
                    
                    LOGGER.info("childPerSet---------"+childPerSet);
                    LOGGER.info("currentUser---------"+currentUser);
                    folder.setPermissionLevel(getUserRole(currentUser, nodeRef, childPerSet));
                    folder.setFolderEmpty(isFolderEmpty);
               
            		if(serviceRegistry.getNodeService().hasAspect(nodeRef, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT)){
            			folder.setCreatedInDocExchange(false);
            		} else{
            		folder.setCreatedInDocExchange(true);
            		}
            		
                    String tagName = "";
                    if(nodeService.hasAspect(nodeRef,ExternalSharingConstants.CISCO_TAG_ASPECT)){
                    	tagName = (String) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
               			LOGGER.info("tagName :: " +tagName);
               		}
                    folder.setTags(tagName);
                    folder.setFavoriteStatus(customFablist.contains(nodeRef));
                    if (hasPermission)
                    {
                        listFolder.add(folder);
                    }
                }
                else
                {
                	if(!nodeService.hasAspect(nodeRef, ContentModel.ASPECT_CHECKED_OUT)){
                    ExtDocument extDocs = new ExtDocument();
                    Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);

                    String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
                    String newFilename = new String(fileName.getBytes(),"UTF-8");
                   // String newFilename = new String(fileName.getBytes("ISO-8859-1"),"UTF-8");
                   // fileName = CharUtil.replaceEscape(newFilename);
                    LOGGER.info("<<<<testing russian char encoding>>>> : " + newFilename);
                    extDocs.setName(ISO9075.decode(newFilename));

                    String Name = ISO9075.decode((String) nodeProp.get(ContentModel.PROP_NAME));
                    extDocs.setNodeId(nodeRef.toString());

                    String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
                    title = CharUtil.replaceEscape(title);
                    extDocs.setTitle(ISO9075.decode(title));

                    String description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
                    description = CharUtil.replaceEscape(description);
                    extDocs.setDescription(ISO9075.decode(description));

                    extDocs.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
                    extDocs.setCreationdate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
                            .get(ContentModel.PROP_CREATED))));

                    String strVersion = (String) nodeProp.get(ContentModel.PROP_VERSION_LABEL);
                    double version = Double.parseDouble((strVersion != null ? strVersion : "1.0"));
                    LOGGER.info("version : " + version);
                    extDocs.setVersion(version);
                    Boolean issynced =  false;
                    String tempMimeType = "";
                    LOGGER.info("nodeRef :: " +nodeRef  + "         fileName  :: " +fileName);
                    if(serviceRegistry.getNodeService().hasAspect(nodeRef,ExternalSharingConstants.CISCO_GLOBAL_CACHING_ASPECT)){
                    	
                    	issynced  = (Boolean) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_IS_FILE_SYNCHED_PROP);
                    	if(issynced != null && !issynced){
                    		Long size = (Long) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_GCS_TEMP_SIZE);
                    		tempMimeType = (String) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_GCS_TEMP_MIMETYPE);
                    		extDocs.setSize((int) (size!=null?size:0));
                        	LOGGER.info("size not synced :: " +size +" tempMimeType :: " +tempMimeType);
                        }else{
                        	long size = nodeProp.get(ContentModel.PROP_CONTENT) != null ? ((ContentData) nodeProp.get(ContentModel.PROP_CONTENT)).getSize() : 0;
                                extDocs.setSize((int) (size));
                                if (issynced == null)
                                	issynced = true;
                        }
                     }else{
                    	 issynced = true;
                    LOGGER.info("issynced :: " +issynced);
                	long size = nodeProp.get(ContentModel.PROP_CONTENT) != null ? ((ContentData) nodeProp.get(ContentModel.PROP_CONTENT)).getSize() : 0;
                    extDocs.setSize((int) (size));
                    LOGGER.info("size :: " +size);
                     }
                    extDocs.setSynced(issynced);
                    if(tempMimeType == null || tempMimeType.isEmpty()){
                    	extDocs.setMimetype((ContentData) nodeProp.get(ContentModel.PROP_CONTENT) !=null ? ((ContentData) nodeProp.get(ContentModel.PROP_CONTENT)).getMimetype() : "");
                    }else{
                    	extDocs.setMimetype(tempMimeType);
                    }
                    // Extra Attributes
                    String lockType = (String) nodeProp.get(ContentModel.PROP_LOCK_TYPE);
                    String edcsId = (String) nodeProp.get(ExternalSharingConstants.PROP_EDCS_ID);
                    LOGGER.info("Locktype:" + lockType);
                    extDocs.setLocked(lockType != null ? true : false);
                    LOGGER.info("From Model:" + extDocs.isLocked());
                    extDocs.setModifieddate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
                            .get(ContentModel.PROP_MODIFIED))));
                    extDocs.setSecurity((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY));
                    extDocs.setModifier((String) nodeProp.get(ContentModel.PROP_MODIFIER));
                    extDocs.setType(Name.substring(Name.lastIndexOf(".") + 1, Name.length()));
                    extDocs.setShareUrl((String) nodeProp.get(ContentModel.PROP_NODE_UUID));
                  //  String newFilename1 = new String(fileName.getBytes("ISO-8859-1"),"UTF-8");
                    String en_name = URLEncoder.encode(fileName,"UTF-8").replaceAll("\\+", "%20");
                   // String en_name = ISO9075.encode(fname);                   
                    LOGGER.info("<<<<testing russian name>>>> : " + en_name);
                    NodeRef folderId = nodeService.getPrimaryParent(nodeRef).getParentRef();
                  
                    /**
                     * Vera protected docs file names allways ends with .html extension to the original filename.
                     * If the document is protected with vera, then append .html extension to the file name
                     */
                    String downloadUrl = null;
                    String applyVeraProtection = ExternalSharingFileFolderUtil.getFolderVeraProtectionStatus(nodeRef, serviceRegistry);
                    if(applyVeraProtection != null && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))){
                    	extDocs.setApplyVeraProtection(applyVeraProtection);
                    } else {
                    	extDocs.setApplyVeraProtection("");
                    }
                    
                    LOGGER.info("hostname :: " +hostname);
                    String nodeUploadedGeolocation = null;
                    
                    if(serviceRegistry.getNodeService().hasAspect(nodeRef,ExternalSharingConstants.CISCO_GLOBAL_CACHING_ASPECT)){
                    	nodeUploadedGeolocation = (String) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_UPLOAD_GELOLOCATION_PROP);
              			 LOGGER.info("nodeUploadedGeolocation :: " +nodeUploadedGeolocation);
              			 
              		}
                   if(nodeUploadedGeolocation != null && hostname!=null){
                    	if(issynced != null && !issynced){
                    		String redirectUrl = "https://"+nodeUploadedGeolocation;
                            LOGGER.info("redirectUrl  :: " +redirectUrl); // redirect to the server where it was uploaded
                            if(applyVeraProtection != null && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))){
                            	downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + en_name + ".html?a=true";
                            }else{
                            downloadUrl = redirectUrl + contextName + "/ext/download/"+ nodeRef.toString().replace(":/", "") + "/" + en_name + "?a=true";
                            }LOGGER.info("downloadurl in redirction  :: " +downloadUrl);
                             
                    	}
                    	else{
                    		// its synced so sync central repository
                    		 if(applyVeraProtection != null && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))){
                    			 downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + en_name + ".html?a=true";
                    		 }else{
                    		 downloadUrl = "https://"+hostname + contextName + "/ext/download/"+ nodeRef.toString().replace(":/", "") + "/" + en_name + "?a=true"; // need to check
                    		 }
	                    	 LOGGER.info("downloadurl sync value true so download from central repo :: " +downloadUrl);
	 	                    
                    	}
                     }
                    	else {
                    		 if(applyVeraProtection != null && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))){
                    			 downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + en_name + ".html?a=true";
                    		 }else{
	                    	 downloadUrl = alfrescoURL + contextName + "/ext/download/"+ nodeRef.toString().replace(":/", "") + "/" + en_name + "?a=true";
                    		 }
	                    	 LOGGER.info("downloadurl  :: " +downloadUrl);
	 	                       }
                  
                    LOGGER.info("Download URL:" + downloadUrl);
                    extDocs.setDownloadUrl(downloadUrl);
                    extDocs.setPermissionLevel(getUserRole(currentUser, nodeRef, childPerSet));
                    extDocs.setEdcsId(edcsId);
                    extDocs.setDocStatus((String) nodeProp.get(ExternalSharingConstants.PROP_DOCSTATUS));
                    extDocs.setWorkflowStatus((String) nodeProp.get(ExternalSharingConstants.PROP_WORKFLOWSTATUS));
                    extDocs.setExpirationDate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
                            .get(ExternalSharingConstants.PROP_EXPIRAIONDATE))));
                    
                    boolean canUserCancelWorkflow = ExternalSharingFileFolderUtil.canUserCancelWorkflow(serviceRegistry,nodeRef);
                    extDocs.setCanUserCancelWorkflow(canUserCancelWorkflow);
                    
                    boolean isPublishedInternally = false;
                    if(edcsId!= null && edcsId.contains("EDCS-")){
						isPublishedInternally = true; 
					}
                    extDocs.setExternalyShared(isPublishedInternally);

                    if(CheckDomain.getDomainStatus(nodeRef.toString()).get("status1") == "401"){
                   	 LOGGER.info("in if inside 401-------");
                   	 extDocs.setDomainMismatch(false);
                    } else {
                   	 extDocs.setDomainMismatch(true);
                    }
                    
                    if (hasPermission)
                    {
                        listExtDocs.add(extDocs);
                    }
                    boolean canUserCancelCheckout = false;
                    String workingCopyOwner = null;
                    boolean isCheckedOut = false;
                    boolean isFavorite = false;
                	NodeRef originalnoderef = null;
                	if(serviceRegistry.getNodeService().hasAspect(nodeRef, ContentModel.ASPECT_WORKING_COPY)){
            			isCheckedOut = true;
            			workingCopyOwner = nodeProp.get(ContentModel.PROP_WORKING_COPY_OWNER).toString();
            			originalnoderef =(NodeRef)serviceRegistry.getCheckOutCheckInService().getCheckedOut(nodeRef);
            		}
                	if((workingCopyOwner != null && workingCopyOwner.equals(currentUser)) || serviceRegistry.getPermissionService().hasPermission(nodeRef,"AdminRole").toString().equals("ALLOWED")){
                		canUserCancelCheckout = true;
					}
                	extDocs.setCheckOutStatus(isCheckedOut);
                	extDocs.setCanCancelCheckOut(canUserCancelCheckout);
                	extDocs.setWorkingCopyOwner(workingCopyOwner);
                	extDocs.setFolderId(folderId.toString());
                	if(originalnoderef != null){
	   	            		isFavorite = customFablist.contains(originalnoderef);
	   	            		}else{
	   	            			isFavorite = customFablist.contains(nodeRef);}	
	                	extDocs.setFavoriteStatus(isFavorite);

	                	String tagName = "";
                        if(nodeService.hasAspect(nodeRef,ExternalSharingConstants.CISCO_TAG_ASPECT)){
                        	tagName = nodeProp.get(ExternalSharingConstants.CISCO_QNAME_TAG_NAME).toString();
                   			LOGGER.info("tagName :: " +tagName);
                   		}
                        
                       	 if(originalnoderef != null ){
                       		if(nodeService.hasAspect(originalnoderef,ExternalSharingConstants.CISCO_TAG_ASPECT)){
                       			tagName = (String) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
                          			LOGGER.info("tagName for original nodeRef:: " +tagName);
                          		}
                         }
                       	extDocs.setTags(tagName);
                    }
                }
	        	 }
        }
           fileFolderList.add(listFolder);
            fileFolderList.add(listExtDocs);
            
        }
        catch (InvalidQNameException e)
        {
            e.printStackTrace();
        }
        catch (InvalidNodeRefException e)
        {
            e.printStackTrace();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return fileFolderList;
    }

    private List<Folder> getAllParentNodeRef(final NodeRef sourceNodeRef, final List<Folder> breadcrumbLst,final String currentUser)
    {

        try
        {
            AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
            {
                @Override
                public Object doWork() throws Exception
                {
                    LOGGER.info("current user : " + currentUser);
                    List<ChildAssociationRef> parentRefs = serviceRegistry.getNodeService().getParentAssocs(
                        sourceNodeRef,ContentModel.ASSOC_CONTAINS, RegexQNamePattern.MATCH_ALL);
                    
                    if (parentRefs != null && parentRefs.size() > 0)
                    {
                        LOGGER.info("parentRefs size....:" + parentRefs.size());
                        NodeRef nodeRef = null;
                        if (parentRefs.size() > 0)
                        {
                            nodeRef = parentRefs.get(0).getParentRef();
                            String foldername = (String) serviceRegistry.getNodeService().getProperty(nodeRef,
                                ContentModel.PROP_NAME);
                            if (!foldername.equalsIgnoreCase("documentLibrary"))
                            {
                            	Set<AccessPermission> parentPermSet = getAllNodeRefPermissions(nodeRef);
                                boolean hasPermission = hasAccess(currentUser, nodeRef, parentPermSet);
                                LOGGER.info("HasPermission:" + hasPermission);
                                Folder folder = new Folder();
                                Map<QName, Serializable> nodeProp = serviceRegistry.getNodeService().getProperties(
                                    nodeRef);

                                String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
                                fileName = CharUtil.replaceEscape(fileName);
                                folder.setName(ISO9075.decode(fileName));
                                folder.setNodeId(nodeRef.toString());

                                String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
                                title = CharUtil.replaceEscape(title);
                                folder.setTitle(ISO9075.decode(title));

                                String description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
                                description = CharUtil.replaceEscape(description);
                                folder.setDescription(ISO9075.decode(description));

                                folder.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
                                folder.setCreationdate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
                                        .get(ContentModel.PROP_CREATED))));
                                folder.setModifieddate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
                                        .get(ContentModel.PROP_MODIFIED))));
                                folder.setType("folder");
                                folder.setApplyVeraProtection((String) nodeProp.get(ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION));
                                
                                Path path = serviceRegistry.getNodeService().getPath(nodeRef);
                                String filePath = "";
                                if (path != null)
                                {
                                    filePath = path.toString();
                                    filePath = filePath.replaceAll(
                                        "\\{http://www.alfresco.org/model/application/1.0\\}", "");
                                    filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "");
                                    filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}",
                                        "");
                                }
                                folder.setRelativePath(ISO9075.decode(filePath));
                                
        	                    if(CheckDomain.getDomainStatus(nodeRef.toString()).get("status1") == "401"){
        	                   	 LOGGER.info("in if inside 401-------");
        	                   	 folder.setDomainMismatch(false);
        	                    } else {
        	                   	 folder.setDomainMismatch(true);
        	                    }
                                folder.setFavoriteStatus(false);
                                folder.setPermissionLevel(getUserRole(currentUser, nodeRef, parentPermSet));
                                if (hasPermission)
                                {
                                    breadcrumbLst.add(folder);
                                }
                                getAllParentNodeRef(nodeRef, breadcrumbLst,currentUser);
                            }

                        }

                    }
                    return null;
                }
            }, "admin");
        }
        catch (InvalidNodeRefException ine)
        {
            LOGGER.error("InvalidNodeRefException : " + ine);
            ine.printStackTrace();
        }
        catch (Exception e)
        {
            LOGGER.error("Exception : " + e);
            e.printStackTrace();
        }
        return breadcrumbLst;
    }

    private List<Folder> getNodeRefProperties(NodeRef sourceNodeRef, List<Folder> breadcrumbLst,boolean isFolderEmpty, List<NodeRef> customFablist,String currentUser, Set<AccessPermission> permSet)
    {
        LOGGER.info("current user : " + currentUser);
        
        Folder folder = new Folder();
        Map<QName, Serializable> nodeProp = serviceRegistry.getNodeService().getProperties(sourceNodeRef);

        String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
        fileName = CharUtil.replaceEscape(fileName);        
        isFolderEmpty = true;
        folder.setName(ISO9075.decode(fileName));
        folder.setNodeId(sourceNodeRef.toString());
        String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
        title = CharUtil.replaceEscape(title);
        folder.setTitle(ISO9075.decode(title));
        String description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
        description = CharUtil.replaceEscape(description);
        folder.setDescription(ISO9075.decode(description));
        folder.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
        folder.setCreationdate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
                .get(ContentModel.PROP_CREATED))));
        folder.setModifieddate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
                .get(ContentModel.PROP_MODIFIED))));
        folder.setType("folder");
        Path path = serviceRegistry.getNodeService().getPath(sourceNodeRef);
        String filePath = "";
        if (path != null)
        {
            filePath = path.toString();
            filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/application/1.0\\}", "");
            filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "");
            filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}", "");
        }
        folder.setRelativePath(ISO9075.decode(filePath));

        if(CheckDomain.getDomainStatus(sourceNodeRef.toString()).get("status1") == "401"){
       	 LOGGER.info("in if inside 401-------");
       	 folder.setDomainMismatch(false);
        } else {
       	 folder.setDomainMismatch(true);
        }
        
        if(serviceRegistry.getNodeService().hasAspect(sourceNodeRef, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT)){
			folder.setCreatedInDocExchange(false);
		} else{
		folder.setCreatedInDocExchange(true);
		}
        
        folder.setPermissionLevel(ExternalSharingFileFolderUtil
                .getUserRole(serviceRegistry, currentUser, sourceNodeRef));
        folder.setFolderEmpty(isFolderEmpty);
        
        folder.setApplyVeraProtection((String) nodeProp.get(ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION));
       folder.setFavoriteStatus(customFablist.contains(sourceNodeRef));
       
       Set<AccessPermission> sourcePermSet = getAllNodeRefPermissions(sourceNodeRef);
       boolean hasPermission = hasAccess(currentUser, sourceNodeRef, sourcePermSet);
        LOGGER.info("HasPermission:" + hasPermission);
        if (hasPermission)
        {
            breadcrumbLst.add(folder);
        }
        return breadcrumbLst;
    }

    private String getParameter(WebScriptRequest req, String paramName)
    {
        String value = "";
        if (req.getParameter(paramName) != null)
        {
            value = req.getParameter(paramName).trim();
        }
        return value;
    }

    public Set<AccessPermission> getAllNodeRefPermissions(final NodeRef nodeRef){
    	final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
	   	 AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				@Override
				public Object doWork() throws Exception {
					accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef));
					return null;
				}
	   	 }, AuthenticationUtil.getAdminUserName());
    	return accessPermission;
    }

  
   /**
     * To get loggedUser Permission Role
     */
    @SuppressWarnings("unused")
	public String getUserRole(String currentUser, NodeRef nodeRef, Set<AccessPermission> userSet)
    {
        String userRole = "";
        LOGGER.info("userSet : " + userSet);
        if (userSet.size() > 0)
        {
        	int currentRoleIndex=0;
        	int tempRoleIndex=0;
        	String tempUserRole="";
            for (AccessPermission accessPermission : userSet)
            {  
            	if (accessPermission.getAuthorityType() == AuthorityType.USER)
            	{
                String user = accessPermission.getAuthority();
                LOGGER.info("user : " + user);
                //LOGGER.info("accessPermission.getPermission : " + accessPermission.getPermission());
                //LOGGER.info("accessPermission.getAuthorityType : " + accessPermission.getAuthorityType());
                String authorityType=accessPermission.getAuthorityType().toString();
                if (user.equals(currentUser))
                {
                    String role = accessPermission.getPermission();
                    userRole = role.split("Role")[0];
                    LOGGER.info((new StringBuilder("userRole: ")).append(userRole).toString());
                    if(ExternalSharingConstants.UsersRoleHerarcy.containsKey(userRole))
                    {
                    	LOGGER.info("...............contains user role.........");
                    	tempRoleIndex =  ExternalSharingConstants.UsersRoleHerarcy.get(userRole).intValue();
                    	LOGGER.info((new StringBuilder("tempRoleIndex: ")).append(tempRoleIndex).toString());
                    
                    } else {
	                    tempRoleIndex = -1;
	                    LOGGER.info((new StringBuilder("tempRoleIndex: ")).append(tempRoleIndex).toString());
                    }
                    if (tempRoleIndex >currentRoleIndex)
                    {
                    tempUserRole = userRole;
                    currentRoleIndex = tempRoleIndex;
                    }
 
                }
            }
            }
            String groupMemberRole=getGroupMemberUserRole(currentUser, nodeRef,userSet);
            if(groupMemberRole!=null && groupMemberRole!=""){
            	 int currentGroupOrUserRoleIndex=0;
             	int tempGroupOrUserRoleIndex=0;
             	String tempGroupOrUserRole="";
             	List<String> userOrGroupIdRole=new ArrayList<String>();
             	userOrGroupIdRole.add(userRole);
             	userOrGroupIdRole.add(groupMemberRole);
             	for (String permissionRole : userOrGroupIdRole) {
             	 if(ExternalSharingConstants.UsersRoleHerarcy.containsKey(permissionRole))
                 {
             		LOGGER.info(" :: Has group role ::");
                 	tempGroupOrUserRoleIndex =  ExternalSharingConstants.UsersRoleHerarcy.get(permissionRole).intValue();
                 
                 } else {
                	 tempGroupOrUserRoleIndex = -1;
	                    LOGGER.info((new StringBuilder("tempRoleIndex: ")).append(tempGroupOrUserRoleIndex).toString());
                 }
                 if (tempGroupOrUserRoleIndex >currentGroupOrUserRoleIndex)
                 {
                	 tempGroupOrUserRole = permissionRole;
                 currentGroupOrUserRoleIndex = tempGroupOrUserRoleIndex;
                 }
             	}
             	userRole = tempGroupOrUserRole;
            }else{
            	userRole = tempUserRole;
            }
            if(userRole.equalsIgnoreCase("Admin"))
            {
            	userRole = UserRoleConstants.USER_ADMIN_ROLE;
            }
        }
        return userRole;
    }

    
    /**
     * To get GroupMember of loggedUser Permission Role
     * @param userSet 
     */
    public String getGroupMemberUserRole(final String currentUser, NodeRef nodeRef, Set<AccessPermission> userSet)
    {
        String userInGroupRole = "";
        boolean userIsInGroup = false;
        LOGGER.info("userSet : " + userSet);
        if (userSet.size() > 0)
        {
        	int currentRoleIndex=0;
        	int tempRoleIndex=0;
        	String tempUserRole="";
        	LOGGER.info(" Current User ===> " + currentUser + " Runas User ===> " + AuthenticationUtil.getRunAsUser());
            for (AccessPermission accessPermission : userSet)
            {  
            	if (accessPermission.getAuthorityType() == AuthorityType.GROUP)
            	{
                 	if (accessPermission.getPermission() != null
     						&& accessPermission.getPermission().equals("SiteAdmin")
     						|| accessPermission.getPermission().equals("SiteEditor")
     						|| accessPermission.getPermission().equals("SiteReader")
     						|| accessPermission.getPermission().equals("SiteOwner")
     						|| accessPermission.getPermission().equals("SiteManager")
     						|| accessPermission.getPermission().equals("ReadPermissions")
     						|| accessPermission.getPermission().equals("SiteViewer")) {
                 		 LOGGER.info("Inside if ootb authority permissions :::: " +accessPermission.getPermission());
     				} else{
     					final String groupId = accessPermission.getAuthority();
            	userIsInGroup = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
     				  @Override
     				  public Boolean doWork() throws Exception {
     					 boolean currentUserIsGroupMember=false;
    					  if(groupId!= null && !groupId.equalsIgnoreCase(GROUP_EVERYONE)){
    					final Set<String> userAuthorities = serviceRegistry.getAuthorityService().getAuthoritiesForUser(currentUser);
    					currentUserIsGroupMember=userAuthorities.contains(groupId);
    					  }
    					 return currentUserIsGroupMember;
    				  	}
     				  }, AuthenticationUtil.getAdminUserName());
            	if(userIsInGroup){
                    String role = accessPermission.getPermission();
                    userInGroupRole = role.split("Role")[0];
                    LOGGER.info((new StringBuilder("userRole: ")).append(userInGroupRole).toString());
                    if(ExternalSharingConstants.UsersRoleHerarcy.containsKey(userInGroupRole))
                    {
                    	tempRoleIndex =  ExternalSharingConstants.UsersRoleHerarcy.get(userInGroupRole).intValue();
                    	LOGGER.info((new StringBuilder("tempRoleIndex: ")).append(tempRoleIndex).toString());
                    } else {
	                    tempRoleIndex = -1;
	                    LOGGER.info((new StringBuilder("tempRoleIndex: ")).append(tempRoleIndex).toString());
                    }
                    if (tempRoleIndex >currentRoleIndex)
                    {
                    tempUserRole = userInGroupRole;
                    currentRoleIndex = tempRoleIndex;
                    }
            	}
                }
            }
            }
            userInGroupRole = tempUserRole;
        }
        return userInGroupRole;
    }
    
    /**
     * To check current login user has authority to access folder
     * @param userSet 
     */
    public boolean hasAccess(final String currentUser, final NodeRef nodeRef, Set<AccessPermission> userSet)
    {
    	boolean currentUserHasGroupMember = false;
        if (currentUser.equals("admin"))
        {
            return true;
        }

        if (userSet.size() > 0)
        {
            for (AccessPermission accessPermission : userSet)
            {
            	final String userIdOrMemberOfGroupId = accessPermission.getAuthority();
            //    LOGGER.info("user : " + userIdOrMemberOfGroupId);
                //check user is member of group that group has permissions on folder
                if(userIdOrMemberOfGroupId.contains(GROUP_IDENTITY)){
                	if (accessPermission.getPermission() != null
    						&& accessPermission.getPermission().equals("SiteAdmin")
    						|| accessPermission.getPermission().equals("SiteEditor")
    						|| accessPermission.getPermission().equals("SiteReader")
    						|| accessPermission.getPermission().equals("SiteOwner")
    						|| accessPermission.getPermission().equals("SiteManager")
    						|| accessPermission.getPermission().equals("ReadPermissions")
    						|| accessPermission.getPermission().equals("SiteViewer")) {
                		// LOGGER.info("inside if authority permissions------" +accessPermission.getPermission());
    				} else{
                	LOGGER.info("groupId : " + userIdOrMemberOfGroupId);
                	currentUserHasGroupMember = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
       				  @Override
       				  public Boolean doWork() throws Exception {
       					boolean currentUserIsGroupMember=false;
   					  if(userIdOrMemberOfGroupId!= null && !userIdOrMemberOfGroupId.equalsIgnoreCase(GROUP_EVERYONE)){
   					currentUserIsGroupMember=serviceRegistry.getAuthorityService().getAuthoritiesForUser(currentUser).contains(userIdOrMemberOfGroupId);
   					  }
   					 return currentUserIsGroupMember;
       				  }
       				  }, "admin");
                	 LOGGER.info("currentUserHasGroupMember of accessPermission.getAuthorityType : " + currentUserHasGroupMember);
                }
                }
                if (userIdOrMemberOfGroupId.equals(currentUser) || currentUserHasGroupMember)
                {
                    return true;
                }
            }
        }
        return false;
    }
    
    public Comparator<FileInfo> typeAscComparator = new Comparator<FileInfo>() {
	    @Override
	    public int compare(FileInfo o1, FileInfo o2)
	    {
			return o1.getName().substring(o1.getName().lastIndexOf(".") + 1, o1.getName().length())
					.compareTo(o2.getName().substring(o2.getName().lastIndexOf(".") + 1, o2.getName().length())); // ascending order
	    }
	};
	
	public Comparator<FileInfo> typeDescComparator = new Comparator<FileInfo>() {
	    @Override
	    public int compare(FileInfo o1, FileInfo o2)
	    {
			return o2.getName().substring(o2.getName().lastIndexOf(".") + 1, o2.getName().length())
					.compareTo(o1.getName().substring(o1.getName().lastIndexOf(".") + 1, o1.getName().length())); // descending order
	    }
	};
    
    
    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    /**
     * @param nodeService
     *            the nodeService to set
     */
    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    public void setAlfrescoURL(String alfrescoURL)
    {
        this.alfrescoURL = alfrescoURL;
    }

    public void setContextName(String contextName)
    {
        this.contextName = contextName;
    }
    
}