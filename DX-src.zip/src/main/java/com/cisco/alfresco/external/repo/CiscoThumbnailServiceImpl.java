package com.cisco.alfresco.external.repo;

import java.util.ArrayList;
import java.util.List;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.apache.log4j.Logger;

import com.cisco.alfresco.external.repo.service.CiscoThumbnailService;


/**
 * 
 * @author dekeswan
 * 
 */
public class CiscoThumbnailServiceImpl implements CiscoThumbnailService
{
    private static final Logger LOGGER = Logger.getLogger(CiscoThumbnailServiceImpl.class);
    private SearchService searchService;
    private NodeService nodeService;

    public void setSearchService(SearchService searchService)
    {
        this.searchService = searchService;
    }

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    /**
     * 
     * @param thumbnailName
     */
    @Override
    public void deleteThumbnails(final String thumbnailName)
    {

        AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Void>()
        {
            @Override
            public Void doWork() throws Exception
            {
                if (LOGGER.isDebugEnabled())
                {
                    LOGGER.debug(" deleteThumbnails method");
                }
                List<NodeRef> thumbnailNodeRefs = getThumbnailNodeRefs(thumbnailName);

                if (thumbnailNodeRefs != null && thumbnailNodeRefs.size() > 0)
                {
                    for (NodeRef thumbnailNodeRef : thumbnailNodeRefs)
                    {
                        LOGGER.debug("Deleting thumbnailNodeRef : " + thumbnailNodeRef);
                        if (nodeService.exists(thumbnailNodeRef))
                        {
                            nodeService.deleteNode(thumbnailNodeRef);
                        }

                    }
                }
                return null;
            }
        }, AuthenticationUtil.getAdminUserName());
    }

    /**
     * 
     * @param thumbnailName
     * @return
     */
    private List<NodeRef> getThumbnailNodeRefs(String thumbnailName)
    {
        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug(" getThumbnailNodeRefs method");
        }
        String query = "select cmis:objectId from cm:thumbnail where cmis:name='" + thumbnailName + "'";
        List<NodeRef> thumbnailNodeRefs = new ArrayList<NodeRef>();
        ResultSet resultSet = null;
        try
        {
            SearchParameters sp = new SearchParameters();
            sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
            sp.setLanguage(SearchService.LANGUAGE_CMIS_ALFRESCO);
            sp.setQuery(query);
            resultSet = searchService.query(sp);
            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug(" query :" + query);
            }
            if (resultSet != null && resultSet.length() > 0)
            {
                thumbnailNodeRefs.addAll(resultSet.getNodeRefs());
                if (LOGGER.isDebugEnabled())
                {
                    LOGGER.debug(" ThumbnailNodeRefs found");
                    LOGGER.debug(" ThumbnailNodes results size  : " + thumbnailNodeRefs.size());
                }
            }
            else
            {
                if (LOGGER.isDebugEnabled())
                {
                    LOGGER.debug(" No ThumbnailNodeRefs found");
                }
            }

        }
        catch (Exception e)
        {
            LOGGER.error("Exception getThumbnailNodeRefs : " + e.getMessage());
        }
        finally
        {
            if (resultSet != null)
            {
                resultSet.close();
            }
        }

        return thumbnailNodeRefs;

    }

}