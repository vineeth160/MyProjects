package com.cisco.alfresco.external.webscript;

public class Test1 {
	
	//private String name;

	public void animal(String name){
		//this.name =name;
		System.out.println("Animal name"+name);
		
	}
	
	
	public static void main(String args[]){
		
	System.out.println("Hello world!!!");
	Test1 an = new Test1();
	an.animal("<<<<Tiger>>>");
	System.out.println("Hello world!!!");

}
}

