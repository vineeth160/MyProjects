package com.cisco.alfresco.external.webscript;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

/**
 * 
 * @author vepagada
 *
 */

public class CheckOutAndCancelCheckOutWebScript extends DeclarativeWebScript {
	private static final Logger LOG = Logger.getLogger(CheckOutAndCancelCheckOutWebScript.class);
	private ServiceRegistry serviceRegistry;
	private static final String CHECK_OUT="checkout";
	private static final String CANCEL_CHECK_OUT="cancelcheckout";
	
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	@SuppressWarnings("unused")
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status,	Cache cache) {
		Map<String,Object> model = new HashMap<String, Object>();
		LOG.info("CheckOutAndCancelCheckOutWebScript Started....");
		ResourceBundle propertiesFile = getResources();
		try{
			JSONObject json = new JSONObject(req.getContent().getContent());
			if(!json.has("nodeId")){
				status.setMessage(propertiesFile.getString("message.noderef.missing"));
				status.setCode(Status.STATUS_BAD_REQUEST);
			}else if(!json.has("actionMode")){
				status.setMessage(propertiesFile.getString("message.mode.missing"));
				status.setCode(Status.STATUS_BAD_REQUEST);
			} else if(!json.getString("actionMode").equals(CHECK_OUT) && !json.getString("actionMode").equals(CANCEL_CHECK_OUT)){
				status.setMessage(propertiesFile.getString("message.mode.badmodeparameter"));
				status.setCode(Status.STATUS_BAD_REQUEST);
			}else{
				final NodeRef contentNode = new NodeRef(json.getString("nodeId").toString());
				LOG.info("contentNode : " + contentNode);
				String logginUser = AuthenticationUtil.getFullyAuthenticatedUser();
				LOG.info("userName : " + logginUser);
				final String actionMode = json.getString("actionMode");
				NodeRef checkedOutNodeRef = null;
				String adminPermission = serviceRegistry.getPermissionService().hasPermission(contentNode,"AdminRole").toString();
				String editorPermission = serviceRegistry.getPermissionService().hasPermission(contentNode,"EditorRole").toString();
				//boolean hasPermission = hasPermission(contentNode, logginUser);
				
				String workingCopyOwner = null;
				if(serviceRegistry.getNodeService().hasAspect(contentNode, ContentModel.ASPECT_WORKING_COPY)){
					workingCopyOwner = serviceRegistry.getNodeService().getProperty(contentNode, ContentModel.PROP_WORKING_COPY_OWNER).toString();
				}
				
				String nodeName = serviceRegistry.getNodeService().getProperty(contentNode, ContentModel.PROP_NAME).toString();
				
				LOG.info("contentNode1 : " + contentNode + " ;userName : " + logginUser + " ;actionMode : " + actionMode + " ;adminPermission : " + adminPermission + " ;editorPermission : " + editorPermission + " ;workingCopyOwner : " + workingCopyOwner);
				
				//if(hasPermission){
				//if(serviceRegistry.getPermissionService().hasPermission(contentNode,"AdminRole").toString().equals("ALLOWED") || serviceRegistry.getPermissionService().hasPermission(contentNode,"EditorRole").toString().equals("ALLOWED")){
					//nodeName = serviceRegistry.getNodeService().getProperty(contentNode, ContentModel.PROP_NAME).toString();
					if(actionMode.equalsIgnoreCase(CHECK_OUT)){
						if(serviceRegistry.getPermissionService().hasPermission(contentNode,"AdminRole").toString().equals("ALLOWED") || serviceRegistry.getPermissionService().hasPermission(contentNode,"EditorRole").toString().equals("ALLOWED")){
							checkedOutNodeRef = serviceRegistry.getCheckOutCheckInService().checkout(contentNode);
							status.setMessage(MessageFormat.format(propertiesFile.getString("message.success"), nodeName,actionMode ));
						} else{
							status.setMessage("Editor and above roles can perform this action");
						}
					}else{
						//NodeRef workingCopyNodeRef = serviceRegistry.getCheckOutCheckInService().getWorkingCopy(contentNode);
						if((workingCopyOwner != null && workingCopyOwner.equals(logginUser)) || serviceRegistry.getPermissionService().hasPermission(contentNode,"AdminRole").toString().equals("ALLOWED")){
							LOG.info("Before calling cancel checkout..");
							serviceRegistry.getCheckOutCheckInService().cancelCheckout(contentNode);
							status.setMessage(MessageFormat.format(propertiesFile.getString("message.success"), nodeName,actionMode ));
						} else{
							status.setMessage("Editor and above roles can perform this action");
						}
					}
				//}
				status.setCode(Status.STATUS_OK);
				//status.setMessage(MessageFormat.format(propertiesFile.getString("message.success"), nodeName,actionMode ));
				model.put("nodeRef", contentNode.toString());
				model.put("userName", logginUser);
			}
			
		}catch(Exception e){
			status.setCode(Status.STATUS_INTERNAL_SERVER_ERROR);
			status.setMessage(e.getMessage());
			e.printStackTrace();
			LOG.error(e.getStackTrace(),e);
		}
		return model;
	}
	
	/*private boolean hasPermission(final NodeRef docNodeRef, String logginUser) {

		if (logginUser.equals("admin")) {
			return true;
		}

		final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(docNodeRef));
				return null;
			}
		}, "admin");

		if (accessPermission.size() > 0) {
			for (AccessPermission accessPermissionObj : accessPermission) {
				String user = accessPermissionObj.getAuthority();
				LOG.info("user : " + user + " ;Permission : " + accessPermissionObj.getPermission() + " ;AuthorityType : " + accessPermissionObj.getAuthorityType());
				//ToDo : need to write one more level validation that only editor and above level should allow to checkout the doc
				if (user.equals(logginUser)) {
					return true;
				}
			}
		}

		return false;
	}*/
}
