package com.cisco.alfresco.external.webscript;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.ContentData;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.Path;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.namespace.InvalidQNameException;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.ISO9075;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.external.common.model.ExtDocument;
import com.cisco.alfresco.external.common.model.ExtDocumentList;
import com.cisco.alfresco.external.common.model.FileFolderList;
import com.cisco.alfresco.external.common.model.Folder;
import com.cisco.alfresco.external.common.model.FolderList;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.alfresco.external.utils.CharUtil;

public class OpenFolderFromFileUrl extends DeclarativeWebScript
{

	    private Logger logs = Logger.getLogger(OpenFolderFromFileUrl.class);
	    private ServiceRegistry serviceRegistry;
	    private NodeService nodeService;
	    private String alfrescoURL;
	    private String contextName; 
	    private static final String GROUP_IDENTITY ="GROUP_";
	    private static final String GROUP_EVERYONE="GROUP_EVERYONE";
	    public NodeService getNodeService() {
			return nodeService;
		}

		public String getAlfrescoURL() {
			return alfrescoURL;
		}

		public void setAlfrescoURL(String alfrescoURL) {
			this.alfrescoURL = alfrescoURL;
		}

		public String getContextName() {
			return contextName;
		}

		public void setContextName(String contextName) {
			this.contextName = contextName;
		}

		public void setNodeService(NodeService nodeService) {
			this.nodeService = nodeService;
		}

		public ServiceRegistry getServiceRegistry() {
			return serviceRegistry;
		}

		public void setServiceRegistry(ServiceRegistry serviceRegistry) {
			this.serviceRegistry = serviceRegistry;
		}

		 
		@Override
	    protected Map<String, Object> executeImpl(final WebScriptRequest req, Status status, Cache cache)
	    {
			
			final Map<String, Object> model = new HashMap<String, Object>(); 
			
			try{
	    	
	    	String nodeRef= req.getParameter("nodeRef");
	    	logs.info("nodeRef: " + nodeRef);
	    	
	    	NodeRef documentNodeRef= new NodeRef(nodeRef);
	    	logs.info("documentNodeRef: " + documentNodeRef); 
	            
	    	   String logginUser = AuthenticationUtil.getFullyAuthenticatedUser();
	    	   logs.info("logginUser-------------"+logginUser);  
	    	   
	    	   boolean userHasPermission = hasAccess(logginUser, documentNodeRef);		                    
               logs.info("userHasPermission.........."+userHasPermission);
               
	    	   if(userHasPermission){  
		                	   
		                	ChildAssociationRef childAssociationRef = nodeService.getPrimaryParent(documentNodeRef);		       				
		       				NodeRef parentNodeRef = childAssociationRef.getParentRef();
		       				logs.info("parentNodeRef-------------" + parentNodeRef);
		                	   
		                	   FileFolderList searchList = getFileFolderList(parentNodeRef, logginUser);		                	    
		                       List<Folder> breadcrumbLst = new ArrayList<Folder>();
		                       breadcrumbLst = getNodeRefProperties(parentNodeRef, breadcrumbLst);		                        
		                       List<Folder> breadCrumbNodeLst = getAllParentNodeRef(parentNodeRef, breadcrumbLst);
		                       Collections.reverse(breadCrumbNodeLst);		                        
		                       List<Folder> folderInfo = new ArrayList<Folder>();
		                       folderInfo = getNodeRefProperties(parentNodeRef, folderInfo);		                        
		                       model.put("result", searchList);
		                       model.put("breadcrumb", breadCrumbNodeLst);	
		                       model.put("folderInfo", folderInfo);
		                       model.put("parentNodeRef", parentNodeRef.toString());
		                       model.put("permissionLevel",
		                           ExternalSharingFileFolderUtil.getUserRole(serviceRegistry, logginUser, parentNodeRef)); 
		                      logs.info("model........."+model.toString()); 
		                   
		                         model.put("hasAccess", "YES");			                         
		                   } else {	           	   
		                   	    model.put("hasAccess", "NO");
		                   }	               
	                	
			} catch (Exception e){
				logs.info("e-------------"+e);
				e.printStackTrace();				 
			} 
			return model;  
	     } 

	public boolean hasAccess(final String currentUser,	final NodeRef documentNodeRef) {
		boolean currentUserHasGroupMember = false;
		Set<AccessPermission> userSet = new HashSet<AccessPermission>();
		userSet=AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Set<AccessPermission>>() {
			@Override
			public Set<AccessPermission> doWork() throws Exception {
				Set<AccessPermission> userSetPermissions = new HashSet<AccessPermission>();
				ChildAssociationRef childAssociationRef = nodeService.getPrimaryParent(documentNodeRef);
				logs.info("childAssociationRef-------------"+ childAssociationRef);
				NodeRef parentNodeRef = childAssociationRef.getParentRef();
				logs.info("parentNodeRef-------------" + parentNodeRef);

				userSetPermissions.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(parentNodeRef));
				return userSetPermissions;
			}
		}, "admin");
		if (userSet.size() > 0) {
			for (AccessPermission accessPermission : userSet) {
            	final String userIdOrMemberOfGroupId = accessPermission.getAuthority();
            	logs.info("user : " + userIdOrMemberOfGroupId);
                //check user is member of group that group has permissions on folder
                if(userIdOrMemberOfGroupId.contains(GROUP_IDENTITY)){
                	if (accessPermission.getPermission() != null
    						&& accessPermission.getPermission().equals("SiteAdmin")
    						|| accessPermission.getPermission().equals("SiteEditor")
    						|| accessPermission.getPermission().equals("SiteReader")
    						|| accessPermission.getPermission().equals("SiteOwner")
    						|| accessPermission.getPermission().equals("SiteManager")
    						|| accessPermission.getPermission().equals("ReadPermissions")
    						|| accessPermission.getPermission().equals("SiteViewer")) {
                		logs.info("inside if authority permissions------" +accessPermission.getPermission());
    				} else{
    					logs.info("groupId : " + userIdOrMemberOfGroupId);
                	currentUserHasGroupMember = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
       				  @Override
       				  public Boolean doWork() throws Exception {
		       					boolean currentUserIsGroupMember=false;
		   					  if(userIdOrMemberOfGroupId!= null && !userIdOrMemberOfGroupId.equalsIgnoreCase(GROUP_EVERYONE)){
		   						  currentUserIsGroupMember=serviceRegistry.getAuthorityService().getAuthoritiesForUser(currentUser).contains(userIdOrMemberOfGroupId);
		   					  }
		   					 return currentUserIsGroupMember;
       				  	}
       				  }, "admin");
                	logs.info("currentUserHasGroupMember of accessPermission.getAuthorityType : " + currentUserHasGroupMember);
                }
                }
                if (userIdOrMemberOfGroupId.equals(currentUser) || currentUserHasGroupMember)
                {
                    return true;
                }
            }
		}
		return false;
	}
		 
		 public FileFolderList getFileFolderList(NodeRef parentNodeRef, String currentUser)
		    {
		        FileFolderList fileFolderList = new FileFolderList();
		        List<Folder> listFolder = new ArrayList<Folder>();
		        List<ExtDocument> listExtDocs = new ArrayList<ExtDocument>();
		        FolderList folderListVO = new FolderList();
		        ExtDocumentList docListVO = new ExtDocumentList();
		        boolean isFolderEmpty = true;
		        try
		        {
		        	logs.info("parentNodeRef : " + parentNodeRef);
		             
		            List<FileInfo> fileInfoList = serviceRegistry.getFileFolderService().list(parentNodeRef);
		            
		            for (FileInfo fileInfo : fileInfoList)
		            {
		                NodeRef nodeRef = fileInfo.getNodeRef();
		                logs.info("nodeRef : " + nodeRef);
		                 
		                boolean hasPermission = hasAccess(currentUser, nodeRef);
		                if (fileInfo.getType().equals(ContentModel.TYPE_FOLDER))
		                {
		                    Folder folder = new Folder();
		                    
		                    Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef); 
							 
		                    String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
		                    fileName = CharUtil.replaceEscape(fileName);
		                    folder.setName(ISO9075.decode(fileName));

		                    folder.setNodeId(nodeRef.toString());

		                    String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
		                    title = CharUtil.replaceEscape(title);
		                    folder.setTitle(ISO9075.decode(title));

		                    String description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
		                    description = CharUtil.replaceEscape(description);
		                    folder.setDescription(ISO9075.decode(description));

		                    folder.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
		                    folder.setCreationdate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
		                            .get(ContentModel.PROP_CREATED))));
		                    folder.setModifieddate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
		                            .get(ContentModel.PROP_MODIFIED))));
		                    folder.setType("folder");
		                    Path path = nodeService.getPath(nodeRef);
		                    String filePath = "";
		                    if (path != null)
		                    {
		                        filePath = path.toString();
		                        filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/application/1.0\\}", "");
		                        filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "");
		                        filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}", "");
		                    }
		                    folder.setRelativePath(ISO9075.decode(filePath));
		                    folder.setPermissionLevel(ExternalSharingFileFolderUtil.getUserRole(serviceRegistry, currentUser,
		                        nodeRef));
		                    folder.setFolderEmpty(isFolderEmpty);
		                   // if (hasPermission)
		                   // {
		                        listFolder.add(folder);
		                   // }
		                }
		                else
		                {
		                    ExtDocument extDocs = new ExtDocument();
		                    Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);

		                    String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
		                    fileName = CharUtil.replaceEscape(fileName);
		                    extDocs.setName(ISO9075.decode(fileName));

		                    String Name = ISO9075.decode((String) nodeProp.get(ContentModel.PROP_NAME));
		                    extDocs.setNodeId(nodeRef.toString());

		                    String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
		                    title = CharUtil.replaceEscape(title);
		                    extDocs.setTitle(ISO9075.decode(title));

		                    String description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
		                    description = CharUtil.replaceEscape(description);
		                    extDocs.setDescription(ISO9075.decode(description));

		                    extDocs.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
		                    extDocs.setCreationdate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
		                            .get(ContentModel.PROP_CREATED))));
		                    logs
		                            .info("MIME TYPE : "
		                                    + ((ContentData) nodeService.getProperty(nodeRef, ContentModel.PROP_CONTENT))
		                                            .getMimetype());
		                    extDocs.setMimetype(((ContentData) nodeService.getProperty(nodeRef, ContentModel.PROP_CONTENT))
		                            .getMimetype());

		                    String strVersion = (String) nodeProp.get(ContentModel.PROP_VERSION_LABEL);
		                    double version = Double.parseDouble((strVersion != null ? strVersion : "1.0"));
		                    logs.info("version : " + version);
		                    extDocs.setVersion(version);
		                    long size = ((ContentData) serviceRegistry.getNodeService().getProperty(nodeRef,
		                        ContentModel.PROP_CONTENT)).getSize();
		                    extDocs.setSize((int) (size));
		                     
		                    String lockType = (String) nodeProp.get(ContentModel.PROP_LOCK_TYPE);
		                    String edcsId = (String) nodeProp.get(ExternalSharingConstants.PROP_EDCS_ID);
		                     
		                    logs.info("Locktype:" + lockType);
		                    logs.info("modifieddate:" + nodeProp.get(ContentModel.PROP_MODIFIED));
		                    logs.info("modifier:" + nodeProp.get(ContentModel.PROP_MODIFIER));
		                    logs.info("security:" + nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY));
		                    extDocs.setLocked(lockType != null ? true : false);
		                    logs.info("From Model:" + extDocs.isLocked());
		                    extDocs.setModifieddate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
		                            .get(ContentModel.PROP_MODIFIED))));
		                    extDocs.setSecurity((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY));
		                    extDocs.setModifier((String) nodeProp.get(ContentModel.PROP_MODIFIER));
		                    extDocs.setType(Name.substring(Name.lastIndexOf(".") + 1, Name.length()));
		                    logs.info("Type:" + Name.substring(Name.lastIndexOf(".") + 1, Name.length()));
		                    extDocs.setShareUrl((String) nodeProp.get(ContentModel.PROP_NODE_UUID));
		                    String en_name = ISO9075.encode(fileName);
		                    String downloadUrl = alfrescoURL + contextName + "/ext/download/"
		                            + nodeRef.toString().replace(":/", "") + "/" + en_name + "?a=true";
		                    logs.info("Download URL:" + downloadUrl);
		                    extDocs.setDownloadUrl(downloadUrl);
		                    extDocs.setPermissionLevel(ExternalSharingFileFolderUtil.getUserRole(serviceRegistry, currentUser,
		                        nodeRef));
		                    extDocs.setEdcsId(edcsId);
		                    extDocs.setDocStatus((String) nodeProp.get(ExternalSharingConstants.PROP_DOCSTATUS));
		                    extDocs.setWorkflowStatus((String) nodeProp.get(ExternalSharingConstants.PROP_WORKFLOWSTATUS));
		                    extDocs.setExpirationDate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
		                            .get(ExternalSharingConstants.PROP_EXPIRAIONDATE))));
		                     
		                    logs.info("PROP_LOCK_TYPE : " + nodeProp.get(ContentModel.PROP_LOCK_TYPE));
		                     
		                    logs.info("PROP_SIZE_CURRENT : " + nodeProp.get(ContentModel.PROP_SIZE_CURRENT));
		                     
		                    boolean canUserCancelWorkflow = ExternalSharingFileFolderUtil.canUserCancelWorkflow(serviceRegistry,nodeRef);
		                    extDocs.setCanUserCancelWorkflow(canUserCancelWorkflow); 
		                    
		                    //if (hasPermission)
		                    //{
		                        listExtDocs.add(extDocs);
		                   // }
		                }
		            }
		            folderListVO.setFolderList(listFolder);
		            docListVO.setExtDocumentlist(listExtDocs);
		            fileFolderList.setFolderlist(folderListVO);
		            fileFolderList.setDoclist(docListVO);
		        }
		        catch (InvalidQNameException e)
		        {
		            e.printStackTrace();
		        }
		        catch (InvalidNodeRefException e)
		        {
		            e.printStackTrace();
		        }
		        catch (Exception e)
		        {
		            e.printStackTrace();
		        }
		        return fileFolderList;
		    }
		 
		 private List<Folder> getAllParentNodeRef(final NodeRef sourceNodeRef, final List<Folder> breadcrumbLst)
		    {

		        try
		        {
		            AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
		            {
		                @Override
		                public Object doWork() throws Exception
		                {
		                    String currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
		                    logs.info("current user : " + currentUser);
		                    List<ChildAssociationRef> parentRefs = serviceRegistry.getNodeService().getParentAssocs(
		                        sourceNodeRef);
		                    if (parentRefs != null && parentRefs.size() > 0)
		                    {
		                    	logs.info("parentRefs size....:" + parentRefs.size());
		                        NodeRef nodeRef = null;
		                        if (parentRefs.size() > 0)
		                        {
		                            nodeRef = parentRefs.get(0).getParentRef();
		                            String foldername = (String) serviceRegistry.getNodeService().getProperty(nodeRef,
		                                ContentModel.PROP_NAME);
		                            if (!foldername.equalsIgnoreCase("documentLibrary"))
		                            {
		                            	logs
		                                        .info("Parent NodeRef:"
		                                                + serviceRegistry.getNodeService().getProperty(nodeRef,
		                                                    ContentModel.PROP_NAME));
		                                boolean hasPermission = hasAccess(currentUser, nodeRef);
		                                logs.info("HasPermission:" + hasPermission);
		                                Folder folder = new Folder();
		                                Map<QName, Serializable> nodeProp = serviceRegistry.getNodeService().getProperties(
		                                    nodeRef);

		                                String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
		                                fileName = CharUtil.replaceEscape(fileName);
		                                folder.setName(ISO9075.decode(fileName));
		                                folder.setNodeId(nodeRef.toString());

		                                String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
		                                title = CharUtil.replaceEscape(title);
		                                folder.setTitle(ISO9075.decode(title));

		                                String description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
		                                description = CharUtil.replaceEscape(description);
		                                folder.setDescription(ISO9075.decode(description));

		                                folder.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
		                                folder.setCreationdate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
		                                        .get(ContentModel.PROP_CREATED))));
		                                folder.setModifieddate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
		                                        .get(ContentModel.PROP_MODIFIED))));
		                                folder.setType("folder");
		                                Path path = serviceRegistry.getNodeService().getPath(nodeRef);
		                                String filePath = "";
		                                if (path != null)
		                                {
		                                    filePath = path.toString();
		                                    filePath = filePath.replaceAll(
		                                        "\\{http://www.alfresco.org/model/application/1.0\\}", "");
		                                    filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "");
		                                    filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}",
		                                        "");
		                                }
		                                folder.setRelativePath(ISO9075.decode(filePath));
		                                folder.setPermissionLevel(ExternalSharingFileFolderUtil.getUserRole(serviceRegistry,
		                                    currentUser, nodeRef));
		                                if (hasPermission)
		                                {
		                                    breadcrumbLst.add(folder);
		                                }
		                                ;
		                                getAllParentNodeRef(nodeRef, breadcrumbLst);
		                            }

		                        }

		                    }
		                    return null;
		                }
		            }, "admin");
		        }
		        catch (InvalidNodeRefException ine)
		        {
		        	logs.error("InvalidNodeRefException : " + ine);
		            ine.printStackTrace();
		        }
		        catch (Exception e)
		        {
		        	logs.error("Exception : " + e);
		            e.printStackTrace();
		        }
		        return breadcrumbLst;
		    }

		    private List<Folder> getNodeRefProperties(NodeRef sourceNodeRef, List<Folder> breadcrumbLst)
		    {
		    	boolean isFolderEmpty = true;
		        String currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
		        logs.info("current user : " + currentUser);
		        Folder folder = new Folder();
		        Map<QName, Serializable> nodeProp = serviceRegistry.getNodeService().getProperties(sourceNodeRef);

		        String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
		        fileName = CharUtil.replaceEscape(fileName);   
		     		/*List<FileInfo> folderInfo = serviceRegistry.getFileFolderService()
		     				.list(sourceNodeRef);

		     		logs.info("folderInfo  isEmpty................."
		     				+ folderInfo.isEmpty());
		     		String userRole = ExternalSharingFileFolderUtil.getUserRole(
		     				serviceRegistry, currentUser, sourceNodeRef);

		     		if (folderInfo.isEmpty() && userRole.equalsIgnoreCase("Folder Admin")) {
		     			isFolderEmpty = true;
		     		} else
		     			isFolderEmpty = false;*/ 
		     		
		        folder.setName(ISO9075.decode(fileName));

		        folder.setNodeId(sourceNodeRef.toString());

		        String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
		        title = CharUtil.replaceEscape(title);
		        folder.setTitle(ISO9075.decode(title));

		        String description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
		        description = CharUtil.replaceEscape(description);
		        folder.setDescription(ISO9075.decode(description));

		        folder.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
		        folder.setCreationdate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
		                .get(ContentModel.PROP_CREATED))));
		        folder.setModifieddate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
		                .get(ContentModel.PROP_MODIFIED))));
		        folder.setType("folder");
		        Path path = serviceRegistry.getNodeService().getPath(sourceNodeRef);
		        String filePath = "";
		        if (path != null)
		        {
		            filePath = path.toString();
		            filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/application/1.0\\}", "");
		            filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "");
		            filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}", "");
		        }
		        folder.setRelativePath(ISO9075.decode(filePath));
		        folder.setPermissionLevel(ExternalSharingFileFolderUtil
		                .getUserRole(serviceRegistry, currentUser, sourceNodeRef));
		        folder.setFolderEmpty(isFolderEmpty);
		        
		        boolean hasPermission = hasAccess(currentUser, sourceNodeRef);
		        logs.info("HasPermission:" + hasPermission);
		        //if (hasPermission)
		       // {
		            breadcrumbLst.add(folder);
		        //}
		        ;

		        return breadcrumbLst;
		    }
	          
  }	    
