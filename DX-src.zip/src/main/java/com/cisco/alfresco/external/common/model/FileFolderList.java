package com.cisco.alfresco.external.common.model;

public class FileFolderList
{

    private FolderList folderlist;

    private ExtDocumentList doclist;

    public FolderList getFolderlist()
    {
        return folderlist;
    }

    public void setFolderlist(FolderList folderlist)
    {
        this.folderlist = folderlist;
    }

    public ExtDocumentList getDoclist()
    {
        return doclist;
    }

    public void setDoclist(ExtDocumentList doclist)
    {
        this.doclist = doclist;
    }

}
