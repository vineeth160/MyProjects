package com.cisco.alfresco.external.webscript;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentIOException;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.edcsng.util.EDCSUtil;


public class NotificationProperties extends DeclarativeWebScript
{

    private ServiceRegistry serviceRegistry;
    private ContentService contentService;
    private NodeService nodeService;
    private String content, folderPath;
    Map<String, Object> model;
    ObjectMapper mapper;
    Writer strWriter;
    NodeRef noderef;
    Map<QName, Serializable> nodeProp;

    private static final Logger LOGGER = Logger.getLogger(NotificationProperties.class);

    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    public ContentService getContentService()
    {
        return contentService;
    }

    public void setContentService(ContentService contentService)
    {
        this.contentService = contentService;
    }

    public NodeService getNodeService()
    {
        return nodeService;
    }

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    public String getFolderPath()
    {
        return folderPath;
    }

    public void setFolderPath(String folderPath)
    {
        this.folderPath = folderPath;
    }

    @Override
    public Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
    {

        model = new HashMap<String, Object>();
        LOGGER.info("Inside Execute Impl........");

        try
        {
            AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
            {
                @Override
                public Object doWork() throws Exception
                {

                    Properties props = new Properties();
                    LOGGER.info("after props");
                    try
                    {

                        // getting the document noderef list from the folder path

                        List<NodeRef> nodeRef = EDCSUtil.getNodeRefList(folderPath, serviceRegistry);

                        for (int i = 0; i < nodeRef.size(); i++)
                        {
                            nodeProp = nodeService.getProperties(nodeRef.get(i));
                            String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
                            if (fileName.equals("notification.properties"))
                            {
                                noderef = new NodeRef(nodeRef.get(i).toString());
                            }
                            break;
                        }

                        LOGGER.info("noderef : :" + nodeRef);
                        LOGGER.info("file noderef : :" + noderef);
                        contentService = serviceRegistry.getContentService();

                        // reading the notifications file data

                        ContentReader reader = contentService.getReader(noderef, ContentModel.PROP_CONTENT);
                        if (reader != null && reader.exists())
                        {
                            try
                            {
                                content = reader.getContentString();
                                InputStream stream = new ByteArrayInputStream(content.getBytes());

                                Collection<Object> a = new ArrayList<Object>();

                                props.load(stream);
                                LOGGER.info("After loading properties file");

                                a = props.values();
                                ArrayList<Object> c = new ArrayList<Object>(a);
                                Collections.reverse(c);

                                LOGGER.info("collection: :" + c);

                                // reading the object values in json
                                // format

                                mapper = new ObjectMapper();
                                strWriter = new StringWriter();
                                mapper.writeValue(strWriter, c);
                                String jsonString = strWriter.toString();
                                LOGGER.info("Result JSON : " + jsonString);

                                model.put("noteList", c);
                            }
                            catch (ContentIOException e)
                            {
                                LOGGER.info("Exception: : :" + e);
                            }
                        }

                        LOGGER.info("Content as a string  :  " + content);

                    }
                    catch (Exception e)
                    {
                        LOGGER.info("Exception: :" + e);
                    }

                    return null;
                }
            }, "admin");
        }
        catch (Exception e)
        {
            LOGGER.info("exception:::" + e);
        }

        return model;
    }

}
