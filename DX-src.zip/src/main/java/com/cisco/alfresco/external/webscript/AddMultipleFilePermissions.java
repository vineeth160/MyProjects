package com.cisco.alfresco.external.webscript;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.TempFileProvider;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.servlet.FormData;

import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;


public class AddMultipleFilePermissions extends DeclarativeWebScript
{
    private static final Logger LOGGER = Logger.getLogger(AddMultipleFilePermissions.class);
    private ExternalLDAPUtil ldapUtil;
    private ServiceRegistry serviceRegistry;
    final static QName DOMAIN_QNAME = QName
            .createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name");
    private String mailServer;
    private String mailerFromID;
    private String bannerAlfrescoUrl;
   // private String addUserFtlLocationPath;
    //public static String ADD_USER_NOTIFICATION_TEMPLATE = "PermissionUpdatedNotification.ftl";
    private PreferenceService preferenceService;
    private String titleURL;
    private String contextName;

    public void setContextName(String contextName)
    {
        this.contextName = contextName;
    }

    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    public ExternalLDAPUtil getLdapUtil()
    {
        return ldapUtil;
    }

    public void setLdapUtil(ExternalLDAPUtil ldapUtil)
    {
        this.ldapUtil = ldapUtil;
    }

    public void setPreferenceService(PreferenceService preferenceService)
    {
        this.preferenceService = preferenceService;
    }

  /*  public String getAddUserFtlLocationPath()
    {
        return addUserFtlLocationPath;
    }

    public void setAddUserFtlLocationPath(String addUserFtlLocationPath)
    {
        this.addUserFtlLocationPath = addUserFtlLocationPath;
    }
*/
    public String getBannerAlfrescoUrl()
    {
        return bannerAlfrescoUrl;
    }

    public void setBannerAlfrescoUrl(String bannerAlfrescoUrl)
    {
        this.bannerAlfrescoUrl = bannerAlfrescoUrl;
    }

    public String getTitleURL()
    {
        return titleURL;
    }

    public void setTitleURL(String titleURL)
    {
        this.titleURL = titleURL;
    }

    public String getMailerFromID()
    {
        return mailerFromID;
    }

    public void setMailerFromID(String mailerFromID)
    {
        this.mailerFromID = mailerFromID;
    }

    public String getMailServer()
    {
        return mailServer;
    }

    public void setMailServer(String mailServer)
    {
        this.mailServer = mailServer;
    }

    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
    {
        String strManagerID = null;
        String noderef, currentUserName;

        // Map<QName, Serializable> nodeProp;
        Map<String, Object> model = new HashMap<String, Object>();
        try
        {
            LOGGER.info("Starting Time :: " + System.currentTimeMillis());
            String filePath = "";
            currentUserName = AuthenticationUtil.getFullyAuthenticatedUser();
            LOGGER.info("Current Username :::" + currentUserName);
            noderef = req.getParameter("nodeId");
            NodeRef nodeRef = new NodeRef(noderef);
            if (canUserHavePermission(nodeRef, serviceRegistry))
            {
                strManagerID = ldapUtil.getManagerEmailFromLDAP(currentUserName);
                if (strManagerID != null && strManagerID.length() > 0)
                {
                    if (strManagerID.contains("cisco.com"))
                    {
                        FileInputStream fs = null;
                        InputStream is = null;
                        LOGGER.info("model.size---" + model.size());
                        try
                        {
                            FormData form = (FormData) req.parseContent();
                            // checking whether uploaded form is empty or not
                            if (form == null || !form.getIsMultiPart())
                            {
                                LOGGER.info("##########if form is null");
                                model.put("status", "401");
                                model.put("message", "please select the xls file");
                                return model;
                            }

                            for (FormData.FormField field : form.getFields())
                            {
                                if (field.getIsFile())
                                {
                                    is = field.getInputStream();
                                    String fileName = currentUserName + generateRandomString();
                                    try
                                    {
                                        Format formatter = new SimpleDateFormat("yyyyMMddhhmmss");
                                        Date date = new Date();
                                        filePath = TempFileProvider.getTempDir().getPath() + "/" + currentUserName
                                                + "_" + formatter.format(date) + ".xls";
                                    }
                                    catch (Exception exx)
                                    {
                                        LOGGER.error(exx);
                                    }
                                    File file = TempFileProvider.createTempFile(fileName, ".xls");
                                    OutputStream os = new FileOutputStream(file);
                                    os.write(getBytes(is));
                                    os.flush();
                                    os.close();
                                    fs = new FileInputStream(file.getPath());
                                    break;
                                }
                            }

                            Workbook wb = Workbook.getWorkbook(fs);
                            // TO get the access to the sheet
                            Sheet sh = wb.getSheet("Sheet1");

                            if (!(sh.getRows() < 4))
                            {
                                model.put("status", "200");
                                model.put("message",
                                    "We are processing your request.... we will notify the status through email soon");
                                LOGGER
                                        .info("We are processing your request.... we will notify the status through email soon");
                                ProcessUserPermissions processUserPermissionsObj = new ProcessUserPermissions(wb,
                                        filePath, currentUserName, nodeRef, strManagerID, serviceRegistry,
                                        preferenceService, ldapUtil, mailServer, mailerFromID, bannerAlfrescoUrl,
                                        titleURL, contextName);
                                new Thread(processUserPermissionsObj).start();
                            }
                            else
                            {
                                model.put("status", "401");
                                model.put("message", "Empty Excel sheet");
                            }
                        }
                        catch (Exception ee)
                        {
                            LOGGER.error(ee);
                        }
                        finally
                        {
                            try
                            {

                                if (fs != null)
                                {
                                    fs.close();
                                }

                            }
                            catch (IOException e)
                            {
                                LOGGER.error(e);
                            }

                        }

                    }
                    else
                    {
                        model.put("status", "401");
                        model.put("message", "Logged in user must be internal user");
                    }
                }
                else
                {
                    model.put("status", "401");
                    model.put("message", "Current user email id is null");
                }
            }
            else
            {
                model.put("status", "401");
                model.put("message", "Logged in must be folder admin");
            }
            return model;

        }
        catch (Exception e)
        {

            LOGGER.error(e);
        }

        return model;
    }

    public void setMessage(String status, String message, Map<String, Object> model)
    {
        model.put("status", status);
        model.put("message", message);

    }

    public static byte[] getBytes(InputStream is) throws IOException
    {

        int len;
        int size = 1024;
        byte[] buf;

        if (is instanceof ByteArrayInputStream)
        {
            size = is.available();
            buf = new byte[size];
            len = is.read(buf, 0, size);
        }
        else
        {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            buf = new byte[size];
            while ((len = is.read(buf, 0, size)) != -1)
                bos.write(buf, 0, len);
            buf = bos.toByteArray();
        }
        return buf;
    }

    private static final String CHAR_LIST = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";

    private static final int RANDOM_STRING_LENGTH = 10;

    /**
     * This method generates random string
     * 
     * @return
     */

    public String generateRandomString()
    {

        StringBuffer randStr = new StringBuffer();

        for (int i = 0; i < RANDOM_STRING_LENGTH; i++)
        {

            int number = getRandomNumber();

            char ch = CHAR_LIST.charAt(number);

            randStr.append(ch);

        }

        return randStr.toString();

    }

    /**
     * This method generates random number
     * 
     * @return int
     */
    private int getRandomNumber()
    {

        int randomInt = 0;

        Random randomGenerator = new Random();

        randomInt = randomGenerator.nextInt(CHAR_LIST.length());

        if (randomInt - 1 == -1)
        {

            return randomInt;

        }
        else
        {

            return randomInt - 1;

        }

    }

    /**
     * This method will check whether the user is having FolderAdmin permission(AdminRole) on the folder or file
     * 
     */
    private boolean canUserHavePermission(NodeRef nodeRef, ServiceRegistry serviceRegistry)
    {
        boolean canPermission = false;
        Iterator<AccessPermission> fIterator;
        final QName type = serviceRegistry.getNodeService().getType(nodeRef);
        String currentUserName = serviceRegistry.getAuthenticationService().getCurrentUserName();

        if (type.equals(ContentModel.TYPE_FOLDER))
        {
            Set<AccessPermission> accessPermissions = serviceRegistry.getPermissionService().getAllSetPermissions(
                nodeRef);
            fIterator = accessPermissions.iterator();
        }
        else
        {
            ChildAssociationRef childAssociationRef = serviceRegistry.getNodeService().getPrimaryParent(nodeRef);
            NodeRef parentNoderef = childAssociationRef.getParentRef();

            Set<AccessPermission> accessPermissions = serviceRegistry.getPermissionService().getAllSetPermissions(
                parentNoderef);
            fIterator = accessPermissions.iterator();

        }

        // AdminRole
        while (fIterator.hasNext())
        {
            AccessPermission accessPermission = (AccessPermission) fIterator.next();

            if (accessPermission.getAuthorityType() == AuthorityType.USER)
            {

                String autherityUserName = accessPermission.getAuthority();
                String autherityUserPermission = accessPermission.getPermission();
                if (autherityUserName.equals(currentUserName) && autherityUserPermission.equals("AdminRole"))
                {
                    return true;
                }
            }
        }
        LOGGER.info("canPermission-----" + canPermission);
        return canPermission;
    }

}