package com.cisco.alfresco.external.getExpiringDocumentsDetails;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

public class GetExpiringDocumentsDetails extends DeclarativeWebScript {
	
	public static Logger _logger = Logger.getLogger(GetExpiringDocumentsDetails.class);
	private ServiceRegistry serviceRegistry;
	private NodeService nodeService;
	private String formatString;
	
	public String getFormatString() {
		return formatString;
	}

	public void setFormatString(String formatString) {
		this.formatString = formatString;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
  
	  @Override
	    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
	    {
		  	String document = null;
			String documentName = null;
			String creationDate = null;
			ResultSet results = null;
			NodeRef currentNodeRef = null;
			DocsPropertyBean bo = null;
			String ownr = null;
			String expiryDate = null;
		    String version = null;
		    String edcsId = null;
		    String securityClassification = null;
			Map<String, Object> model = null;
			String email =null;
		  
			SearchService searchService = serviceRegistry.getSearchService();
			SearchParameters sp = new SearchParameters();
			sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
			sp.setLanguage(SearchService.LANGUAGE_LUCENE);
			String strDays = req.getParameter("days");
			_logger.info("strDays-------------"+strDays);
			
			int days = Integer.parseInt(strDays);
			String tempDate = (String) doConvertDateFormat(days);
			_logger.info("tempDate::::::"+tempDate);
			String ftsQuery;
			ftsQuery = "PATH:\"/app:company_home/st:sites/cm:edcsng/cm:documentLibrary//*\" AND TYPE:\"cs:ciscodoc\" AND @ext\\:publishExpirationDate:[%publishExpirationDate%]";
			_logger.info("ftsQuery:::::::::::before replace:::"+ftsQuery);
			
			ftsQuery = ftsQuery.replace("[%publishExpirationDate%]", tempDate);
			_logger.info("ftsQuery:::" + ftsQuery);
			sp.setQuery(ftsQuery);
			SimpleDateFormat sd = null;
			sd = new SimpleDateFormat(formatString);
			nodeService = serviceRegistry.getNodeService();
			results = searchService.query(sp);
			_logger.info("results:::::::::::::::" + results.length());
			if (results != null) {
				_logger.info("Inside the if condition");
				List<DocsPropertyBean> userRecBoList = new ArrayList<DocsPropertyBean>();
				for (ResultSetRow row : results) {
					_logger.info("inside for");
					currentNodeRef = row.getNodeRef();
					_logger.info("currentNodeRef ::::" + currentNodeRef);
					document = (String) nodeService.getProperty(currentNodeRef,
							ContentModel.PROP_TITLE);
					 documentName= (String)nodeService
					.getProperty(currentNodeRef, ContentModel.PROP_NAME);
					 if((String)serviceRegistry.getNodeService().getProperty(currentNodeRef, ContentModel.PROP_VERSION_LABEL) !=null){
						 version=(String)serviceRegistry.getNodeService().getProperty(currentNodeRef, ContentModel.PROP_VERSION_LABEL);
				   		}else{
				   			version= "1.0";
				   		}
					 _logger.info("version ::"+version);
					 VersionHistory vers =  serviceRegistry.getVersionService().getVersionHistory(currentNodeRef);
					 Version version1;
					 String currentVersion;
					 if(vers!= null){
						  version1 = serviceRegistry.getVersionService().getCurrentVersion(currentNodeRef);
						  _logger.info("version1 ::::::"+version1.getVersionLabel());
						   currentVersion =version1.getVersionLabel();
						   _logger.info("currentVersion:::::"+currentVersion);
					 }else{
						currentVersion = "1.0";
					 }
					 QName EDCSID = QName.createQName("http://www.cisco.com/model/content/1.0","alf_id"); 
					 edcsId = (String) nodeService.getProperty(currentNodeRef,EDCSID); 
					_logger.info("document ::::::::::::::" + document);
					
					ownr = (String) nodeService.getProperty(currentNodeRef,
							ContentModel.PROP_CREATOR);
					NodeRef user = serviceRegistry.getPersonService().getPerson(
							ownr);
					email = (String) nodeService.getProperty(user,
							ContentModel.PROP_EMAIL);
					_logger.info("ownr ::::::::::::::" + ownr);
					
					if(email.contains("@cisco.com")){
						QName SECURITY = QName
								.createQName(
										"http://www.cisco.com/model/content/1.0",
										"security");
								securityClassification = (String) nodeService
								.getProperty(currentNodeRef,
										SECURITY);
					}
					Date createDate = (Date) nodeService.getProperty(
							currentNodeRef, ContentModel.PROP_CREATED);
					creationDate = sd.format(createDate);
					QName expDate = QName.createQName(
							"http://www.alfresco.org/model/external/content/1.0",
							"publishExpirationDate");
					Date expDateVal = (Date) nodeService.getProperty(
							currentNodeRef, expDate);
					_logger.info("expDateVal :::::" + expDateVal);
					expiryDate = sd.format(expDateVal);
					_logger.info("expiryDate ::::::::::" + expiryDate);
					String siteName = serviceRegistry.getSiteService()
							.getSite(currentNodeRef).getShortName();
					_logger.info("siteName::::::::" + siteName);
					
				    bo = new DocsPropertyBean();
				    if(document == null || document.equals("")){
                  	_logger.info("document::::"+documentName);
                  	bo.setFileName(documentName);
                  }else{
                  	_logger.info("inside else :::"+document);
                  	bo.setFileName(document);
                  }
					bo.setDocumentName(documentName);
					bo.setVersion(currentVersion);
					bo.setEDCSID(edcsId);
					bo.setSecurityValue(securityClassification);
					bo.setOwnerId(ownr);
					bo.setCreationDate(creationDate);
					bo.setExpiryDate(expiryDate);
					userRecBoList.add(bo);
				}
				_logger.info("userRecBoList----"+ userRecBoList);
				try {
					  model = getDocProps(userRecBoList);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					_logger.info("e-----------" + e);
					e.printStackTrace();
				}
			}
			return model;
	    }
	
		private Map<String, Object> getDocProps(List<DocsPropertyBean> bo) throws Exception {
			_logger.info("inside getDocProps");
			Map<String, Object> model = new HashMap<String, Object>();
			List<Map<String,String>> docs = new ArrayList<Map<String,String>>();
			String email =null;

			Collections.sort(bo, new Comparator<DocsPropertyBean>() {
				public int compare(DocsPropertyBean o1, DocsPropertyBean o2) {
					DocsPropertyBean nodeRef1 = (DocsPropertyBean) o1;
					DocsPropertyBean nodeRef2 = (DocsPropertyBean) o2;
					return nodeRef1.getOwnerId().compareTo(nodeRef2.getOwnerId());
				}
			});
			_logger.info("List" + bo);
			_logger.info("List" + bo.size());
			DocsPropertyBean tempBO = null;
			Map<String, List<DocsPropertyBean>> ownerFileListMap = new Hashtable<String, List<DocsPropertyBean>>();
			_logger.info("" + ownerFileListMap);
			List<DocsPropertyBean> documentList = null;
			_logger.info("before for loop");
		    for (DocsPropertyBean dBo : bo) {
				_logger.info("inside for loop" + dBo.getOwnerId());
				if (tempBO == null
						|| (!tempBO.getOwnerId().equals(dBo.getOwnerId()))) {
						
					documentList = new ArrayList<DocsPropertyBean>();
				
					ownerFileListMap.put(dBo.getOwnerId(), documentList);
				}
				documentList.add(dBo);
	       		tempBO = dBo;
			 }
			    _logger.info("after for loop");
				Set<String> ownerKeySet = ownerFileListMap.keySet();
				Iterator<String> ownerKeySetIterator = ownerKeySet.iterator();
				while (ownerKeySetIterator.hasNext()) {
				_logger.info("inside while loop");
				String ownerKeyString = ownerKeySetIterator.next();
				List<DocsPropertyBean> DocsPropertyBeanList = ownerFileListMap
						.get(ownerKeyString);
				_logger.info("DocsPropertyBeanList.size();"
						+ DocsPropertyBeanList.size());
				NodeRef user = serviceRegistry.getPersonService().getPerson(
						ownerKeyString);
				String address = (String) nodeService.getProperty(user,
						ContentModel.PROP_EMAIL);
				_logger.info("email id" + address);
				String tomany[] = new String[1];
				tomany[0]= address;
				int size = DocsPropertyBeanList.size();
				_logger.info("size" + size);
				
				email = (String) nodeService.getProperty(user,
						ContentModel.PROP_EMAIL);
				_logger.info("email" + email);
				
			   if(DocsPropertyBeanList!=null){
				   for (DocsPropertyBean docsBO : DocsPropertyBeanList) {
			             
					   Map<String, String> docDetails = new HashMap<String, String>();
					   docDetails.put("DocName", docsBO.getDocumentName());
					   docDetails.put("owner", docsBO.getOwnerId());
					   docDetails.put("DocTitle", docsBO.getFileName());
					   docDetails.put("version", docsBO.getVersion());
					   docDetails.put("edcsIdd", docsBO.getEDCSID());
					   if(email.contains("@cisco.com")){
						   docDetails.put("SecurityValue", docsBO.getSecurityValue());
					   } else{
						   docDetails.put("SecurityValue", "NA");
					   }
					   docDetails.put("cDate", docsBO.getCreationDate());
					   docDetails.put("eDate", docsBO.getExpiryDate());
					   docs.add(docDetails);   
				}
			}
			}  
				model.put("docs", docs);
				_logger.info("in getDocProps docs-----------"+docs);
				return model;
		}

		public static String doConvertDateFormat(int days) {
			_logger.info("days:::::::::::::::::"+days);
			Date date = new Date(System.currentTimeMillis() + days * 24L * 3600	* 1000);
		     StringBuilder actualDateObj = null;
		        StringBuilder dtFormat = new StringBuilder();
		        dtFormat.append(DefaultTypeConverter.INSTANCE.convert(String.class,
		                date));
		        String dtFrmtObj = dtFormat.toString();
		        int firstTindex = dtFormat.indexOf("T");
		        actualDateObj = new StringBuilder();
		        actualDateObj.append("[");
		        actualDateObj.append(dtFrmtObj.substring(0, firstTindex+1));
		        actualDateObj.append("00:00:00 TO ");
		        actualDateObj.append(dtFrmtObj.substring(0, firstTindex));
		        actualDateObj.append("T23:59:59");
		        actualDateObj.append("]");
		        _logger.info("actualDateObj------>"+actualDateObj.toString());
		        return actualDateObj.toString();
		}
	}
