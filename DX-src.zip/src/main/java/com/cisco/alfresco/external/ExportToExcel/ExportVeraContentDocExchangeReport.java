package com.cisco.alfresco.external.ExportToExcel;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.Path;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.repository.TemplateService;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.ISO9075;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.edcsng.util.MailUtil;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.utils.CharUtil;
import com.cisco.alfresco.service.commons.ServiceConstants;
import com.cisco.edcsng.audit.bireports.utils.BIReportConstants;
import com.csvreader.CsvWriter;
import jxl.CellView;
import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.Colour;
import jxl.format.VerticalAlignment;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import net.sf.acegisecurity.Authentication;

/**
 * Export of Vera Folder/subfolder/properties/permission
 *
 */
public class ExportVeraContentDocExchangeReport extends DeclarativeWebScript implements BIReportConstants{
	private static final Logger logger = Logger.getLogger(ExportVeraContentDocExchangeReport.class);
	private static String DOCEX_REPORT_TEMPLATE = "/alfresco/extension/templates/email/DocExchangeReportNotification.ftl";
	private static String PATH_FOLDERS_QUERY ="PATH:\"/app:company_home/st:sites/cm:edcsng/cm:documentLibrary//*\" AND TYPE:\"cm:folder\" AND -TYPE:\"cm:systemfolder\" AND ASPECT:\"ext:veraProtectionAspect\" AND (@ext\\:applyVeraProtection:\"All Contents\" OR @ext\\:applyVeraProtection:\"Cisco Restricted\")";
	private static String PATH_DOCS_QUERY ="PATH:\"/app:company_home/st:sites/cm:edcsng/cm:documentLibrary//*\" AND TYPE:\"cs:ciscodoc\" AND -TYPE:\"cm:systemfolder\" AND ASPECT:\"ext:veraProtectionAspect\" AND @ext\\:isDocVeraProtected:\"true\"";
	private static Integer MAX_VALUE=3;
	String SITE_NAME = "edcsng";
	String USERS = "Users";
	private ServiceRegistry serviceRegistry;
	private PreferenceService preferenceService;
    private static ExternalLDAPUtil ldapUtil;
    private String mailServer;
    private String mailerFromID;
    private String bannerAlfrescoUrl;
    private String titleURL;
    private String contextName;
    private String filePath;
    private String docexReportMaxValue;
    private String docexSupportUrl;
    public String getDocexSupportUrl() {
		return docexSupportUrl;
	}
	public void setDocexSupportUrl(String docexSupportUrl) {
		this.docexSupportUrl = docexSupportUrl;
	}
	public String getDocexReportMaxValue() {
		return docexReportMaxValue;
	}
	public void setDocexReportMaxValue(String docexReportMaxValue) {
		this.docexReportMaxValue = docexReportMaxValue;
	}
    public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getMailServer() {
		return mailServer;
	}
	public void setMailServer(String mailServer) {
		this.mailServer = mailServer;
	}
	public String getMailerFromID() {
		return mailerFromID;
	}
	public void setMailerFromID(String mailerFromID) {
		this.mailerFromID = mailerFromID;
	}
	public String getBannerAlfrescoUrl() {
		return bannerAlfrescoUrl;
	}
	public void setBannerAlfrescoUrl(String bannerAlfrescoUrl) {
		this.bannerAlfrescoUrl = bannerAlfrescoUrl;
	}
	public String getTitleURL() {
		return titleURL;
	}
	public void setTitleURL(String titleURL) {
		this.titleURL = titleURL;
	}
	public String getContextName() {
		return contextName;
	}
	public void setContextName(String contextName) {
		this.contextName = contextName;
	}
    public ExternalLDAPUtil getLdapUtil()
    {
        return ldapUtil;
    }
    @SuppressWarnings("static-access")
	public void setLdapUtil(ExternalLDAPUtil ldapUtil)
    {
        this.ldapUtil = ldapUtil;
    }
	public PreferenceService getPreferenceService() {
		return preferenceService;
	}
	public void setPreferenceService(PreferenceService preferenceService) {
		this.preferenceService = preferenceService;
	}
    public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}
    public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
    
	@Override
    public Map<String, Object> executeImpl( WebScriptRequest req,  Status status,  Cache cache)
    {
		Map<String, Object> model=new HashMap<String, Object>();
		logger.error("ExportDocExchangeReportToExcel START... ");
		String currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
		logger.error("strEmailID>>>"+currentUser);
		String strEmailID = ldapUtil.getManagerEmailFromLDAP(currentUser);
		logger.error("strEmailID>>>"+strEmailID);
		String searchFoldersQuery =null;
		String searchQuery = null;
		String startDate = req.getParameter("startDate");
		String endDate = req.getParameter("endDate");
		if((startDate!=null && startDate.length() > 0)  && (endDate!=null && endDate.length() >0)) {
			searchFoldersQuery = PATH_FOLDERS_QUERY+" AND @cm\\:created:[\""+startDate+"\" TO \""+endDate+"\"]";
			searchQuery = PATH_DOCS_QUERY+" AND @cm\\:created:[\""+startDate+"\" TO \""+endDate+"\"]";
		}else {
			searchFoldersQuery = PATH_FOLDERS_QUERY;
			searchQuery = PATH_DOCS_QUERY;
		}
		
		if(userAccess(currentUser, strEmailID)){
			
			List<NodeRef> folderList = new ArrayList<NodeRef>();
			//String searchFoldersQuery = PATH_FOLDERS_QUERY;
			folderList = getContentList(searchFoldersQuery);
			logger.error("folderList>>>"+folderList);
			List<NodeRef> fileList = new ArrayList<NodeRef>();
			
			
			fileList=getContentList(searchQuery);
			int contentSize = folderList.size()+fileList.size();
			logger.error("final file folder size :::: " +contentSize);
			logger.error("final folder size :::: " +folderList.size());
			String path ;
		    if(contentSize >MAX_VALUE){
		    	
		    		logger.error("Inside CSV generation....");
			    	path = getContentListInCSV(folderList,fileList,currentUser);
			    	sendEMail(strEmailID, path, currentUser);
			    	File file = new File(path);
					logger.error("File location is : " + filePath.toString() + "  isFileExists : " + file.exists() + " :::isFile :  " + file.isFile());
					if(file.exists() && file.isFile()){
						file.delete();
					}
		    	
		    }else{
		    	logger.error("Inside XLS generation.....");
		        path = getContentListInXLS(folderList,fileList, currentUser);
		        sendEMail(strEmailID, path, currentUser);
		        File file = new File(path);
				logger.error("File location is : " + filePath.toString() + "  isFileExists : " + file.exists() + " :::isFile :  " + file.isFile());
				if(file.exists() && file.isFile()){
					file.delete();
				}
		    }
			model.put("message", "Your doc exchange content vera report will be shared via email after it is complete..");
			
			
		}else{
			logger.error("You don't have permission to generate the report.");
			model.put("message", "You dont have permission");
	     }
		return model;
    }
	
    /**
     * @param folderList
     * @param currentUser
     * @return
     */
    public String getContentListInCSV(final List<NodeRef> folderList,final List<NodeRef> filesList, final String currentUser)
	    {
    	 StringBuffer path = new StringBuffer();
		 path.append(filePath).append("/docexveracontentreport.csv");
		 FileWriter fileWriter = null;
		 try {
			fileWriter = new FileWriter(path.toString(),true);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		 CsvWriter csvWriter = new CsvWriter(fileWriter, ',');
		 logger.error("getContentList Method Start...." + folderList.size());
							try{
								List<String[]> rows = new LinkedList<String[]>();
								rows.add(new String[]{"DocExchange Content Report"});
								rows.add(new String[]{"Name", "Title", "Doc ID", "Security Type", "Relative Path", "Owner Role", "Folder Admin", "Editor Role", "Reader Role", "Viewer Role", "NodeRef","Vera Protection Enabled by","LastAccessed Date"});
								if(folderList!=null && folderList.size()>0){
			     					for (final NodeRef nodeRef : folderList){
			     						if(!filesList.isEmpty() && filesList!=null) {
				     						filesList.clear();
			     						}
			     						addrowToCSV(rows, nodeRef, currentUser);
			     				}
			     					for (final NodeRef nodeRef : filesList){
			     						if(!filesList.isEmpty() && filesList!=null) {
			     						filesList.clear();
			     						}
			     						addrowToCSV(rows, nodeRef, currentUser);
			     					}
			     				}else{
				                   logger.error("No Data Found");
				                }
								for(String[] row : rows){
			                    	csvWriter.writeRecord(row);
			                    }
								csvWriter.close();
			                    logger.error("Doc Exchange Vera Content Report Downloaded Successfully...");
		                     } catch (Exception e)
	                         {
	                             logger.error("Exception : " + e);
	                             e.printStackTrace();
	                         }
							return path.toString();	
		 }
			
	/**
	 * @param rows
	 * @param noderef
	 * @param currentUser
	 */
	public void addrowToCSV(List<String[]> rows, NodeRef noderef, String currentUser)
	{
		try {
        	Map<QName, Serializable> nodeProp = serviceRegistry.getNodeService().getProperties(noderef);
        	List<String> ownerList = new ArrayList<String>();
        	List<String> adminList = new ArrayList<String>();
        	List<String> editorList = new ArrayList<String>();
        	List<String> readerList = new ArrayList<String>();
        	List<String> viewerList = new ArrayList<String>();
        	Hashtable<String, String> userDefaultPermission = new Hashtable<String, String>();
        	String ownerResult, adminResult, editorResult, readerResult, viewerResult = "";
			userDefaultPermission = getAllNodeSetPermissions(noderef);
			if(!userDefaultPermission.isEmpty()){
			Set<String> keys = userDefaultPermission.keySet();
	          for(String key: keys){
	            String role = userDefaultPermission.get(key);
	            if(role.equalsIgnoreCase("OwnerRole"))
	            	ownerList.add(key);
	            else if(role.equalsIgnoreCase("AdminRole"))
	            	adminList.add(key);
	            else if(role.equalsIgnoreCase("EditorRole"))
	            	editorList.add(key);
	            else if(role.equalsIgnoreCase("ReaderRole"))
	            	readerList.add(key);
	            else if(role.equalsIgnoreCase("ViewerRole"))
	            	viewerList.add(key);
	           }
		    }
		String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
        fileName = CharUtil.replaceEscape(fileName);
        String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
        title = CharUtil.replaceEscape(title);
        String docId = (String) nodeProp.get(ExternalSharingConstants.PROP_EDCS_ID);
        String security =  (String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY);
        String veraEnabledBy =  (String) nodeProp.get(ExternalSharingConstants.PROP_VERA_ENABLED_BY);
        String veraEnabledDate="";
		
		if(nodeProp.containsKey(ExternalSharingConstants.PROP_VERA_ENABLED_DATE)){
			logger.error(nodeProp.get(ExternalSharingConstants.PROP_VERA_ENABLED_DATE));
			veraEnabledDate = formatter2.format(nodeProp.get(ExternalSharingConstants.PROP_VERA_ENABLED_DATE));
			
		}
		if(ownerList.isEmpty())
			ownerResult = "";
		else
			ownerResult = String.join(";",ownerList);
        
        if(adminList.isEmpty())
        	adminResult = "";
        else
        	adminResult = String.join(";",adminList);
        
        if(editorList.isEmpty())
        	editorResult = "";
        else
        	editorResult = String.join(";",editorList);
        
        if(readerList.isEmpty())
        	readerResult = "";
        else
        	readerResult = String.join(";",readerList);
        
        if(viewerList.isEmpty())
        	viewerResult = "";
        else
        	viewerResult = String.join(";",viewerList);
        
        String relativePath=getNodeRelativePath(noderef);
        rows.add(new String[]{ISO9075.decode(fileName), ISO9075.decode(title), docId, security, relativePath, ownerResult, adminResult, editorResult, readerResult, viewerResult, noderef.toString(), veraEnabledBy, veraEnabledDate});
        } catch (Exception e) {
			e.printStackTrace();
		}
	}
        
	/**
	 * @param folderList
	 * @param currentUser
	 * @return
	 */
	public String getContentListInXLS(final List<NodeRef> folderList,final List<NodeRef> fileList, final String currentUser)
	    {
		 StringBuffer path = new StringBuffer();
		 path.append(filePath).append("/docexveracontentreport.xls");
		 File fileXLS = new File(path.toString());
							try{
								
			                	 WritableWorkbook workbook = null;
				                 int row = 3;
				                 WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);
		                         workbook = Workbook.createWorkbook(fileXLS);
		                         WritableSheet workSheet=createExcelWorksheet(workbook,currentUser);
		                         if((folderList!=null && folderList.size()>0) || (fileList!=null && fileList.size()>0)){
				     					for (final NodeRef nodeRef : folderList){
				     						addrowToXLS(workSheet, row, nodeRef, currentUser,false);
				     						row++;
				     						}
				     					for (final NodeRef filenodeRef : fileList){
				     						addrowToXLS(workSheet, row, filenodeRef, currentUser,false);
				     						row++;
				     					}
				     				 } else{
					                     WritableCellFormat cellFormat = new WritableCellFormat(times10ptBoldUnderline);
					                     cellFormat.setAlignment(Alignment.CENTRE);
					                     cellFormat.setVerticalAlignment(VerticalAlignment.CENTRE);
					                     cellFormat.setBackground(Colour.GREY_25_PERCENT);
					                     Label lable = new Label(0, 0, "No Data Found", cellFormat);
					                     workSheet.addCell(lable);
					                     workSheet.mergeCells(0, 0, 10, 0); 
				     				 }
			     				workbook.write();
		                        workbook.close();
		                        logger.error("Doc Exchange Vera Content Report Downloaded Successfully...");
		                    }catch (Exception e){
	                             logger.error("Exception : " + e);
	                             e.printStackTrace();
	                        }
							return fileXLS.getAbsolutePath();	
	}
	    
	/**
	 * @param workBook
	 * @param currentUser
	 * @return
	 */
	private  WritableSheet createExcelWorksheet(WritableWorkbook workBook,String currentUser) {
			 Label lable = null;
			 WritableSheet wSheet1 =null;
			 WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);
			 WritableCellFormat cellFormat = new WritableCellFormat(times10ptBoldUnderline);
	         try {
				cellFormat.setAlignment(Alignment.CENTRE);
				cellFormat.setVerticalAlignment(VerticalAlignment.CENTRE);
		         cellFormat.setBackground(Colour.GREY_25_PERCENT);
		         WritableCellFormat timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
		         timesBoldUnderline.setWrap(true);
				 wSheet1 = workBook.createSheet("DocExchange Vera Content Report",0);
				 wSheet1.insertColumn(0); 
				 lable = new Label(0, 2, "Name",timesBoldUnderline);
				 wSheet1.addCell(lable);
				 wSheet1.insertColumn(1); 
				 lable = new Label(1, 2, "Title",timesBoldUnderline);
				 wSheet1.addCell(lable);
				 wSheet1.insertColumn(2); 
				 lable = new Label(2, 2, "Doc ID",timesBoldUnderline);
				 wSheet1.addCell(lable);
				 wSheet1.insertColumn(3); 
				 lable = new Label(3, 2, "Security Type",timesBoldUnderline);
				 wSheet1.addCell(lable);
				 wSheet1.insertColumn(4); 
				 lable = new Label(4, 2, "Relative Path",timesBoldUnderline);
				 wSheet1.addCell(lable);
				 wSheet1.insertColumn(5); 
				 lable = new Label(5, 2, "Owner Role",timesBoldUnderline);
				 wSheet1.addCell(lable);
				 wSheet1.insertColumn(6); 
				 lable = new Label(6, 2, "Folder Admin",timesBoldUnderline);
				 wSheet1.addCell(lable);
				 wSheet1.insertColumn(7); 
				 lable = new Label(7, 2, "Editor Role",timesBoldUnderline);
				 wSheet1.addCell(lable);
				 wSheet1.insertColumn(8); 
				 lable = new Label(8, 2, "Reader Role",timesBoldUnderline);
				 wSheet1.addCell(lable);
				 wSheet1.insertColumn(9); 
				 lable = new Label(9, 2, "Viewer Role",timesBoldUnderline);
				 wSheet1.addCell(lable);
				 wSheet1.insertColumn(10); 
				 lable = new Label(10, 2, "NodeRef",timesBoldUnderline);
				 wSheet1.addCell(lable);
				 //
				 lable = new Label(11, 2, "Vera Protection Enabled by",timesBoldUnderline);
				 wSheet1.addCell(lable);
				 lable = new Label(12, 2, "LastAccessed Date",timesBoldUnderline);
				 wSheet1.addCell(lable);
				 //
				 CellView columnPathView = new CellView();
				 columnPathView.setAutosize(true); 
				 wSheet1. setColumnView(0, 20);
				 wSheet1. setColumnView(1, 20);
				 wSheet1. setColumnView(2, 20);
				 wSheet1. setColumnView(3, 20);
				 wSheet1. setColumnView(4, columnPathView);
				 wSheet1. setColumnView(5, 20);
				 wSheet1. setColumnView(6, 20);
				 wSheet1. setColumnView(7, 20);
				 wSheet1. setColumnView(8, 20);
				 wSheet1. setColumnView(9, 20);
				 wSheet1. setColumnView(10, 25);
				 //
				 wSheet1. setColumnView(11, 25);
				 wSheet1. setColumnView(12, 20);
				 //
				 wSheet1.mergeCells(0, 0, 12, 0);
		         lable = new Label(0, 0, "DocExchange Vera Content Report", cellFormat);
		         wSheet1.addCell(lable);
		         wSheet1.mergeCells(0, 1, 12, 1);
	         } catch (Exception e) {
				e.printStackTrace();
			}
	         return wSheet1;
	}
	    
	public void addrowToXLS(WritableSheet wSheet1, int row, NodeRef noderef, String currentUser, boolean isRoot)
		{	logger.error("add row::"+noderef);
			Label lable=null;
			int nameColumn = 0;
			int titleColumn = 1;
			int docIdColumn = 2;
	        int securityColumn = 3;
	        int pathColumn = 4;
	        int ownerColumn = 5;
	        int adminColumn = 6;
	        int editorColumn = 7;
	        int readerColumn = 8;
	        int viewerColumn = 9;
	        int nodeRefColumn = 10;
	        //
	        int veraprotectionColumn = 11;
	        int lastaccessedColumn = 12;
	        //
	        
	        List<String> ownerList = new ArrayList<String>();
        	List<String> adminList = new ArrayList<String>();
        	List<String> editorList = new ArrayList<String>();
        	List<String> readerList = new ArrayList<String>();
        	List<String> viewerList = new ArrayList<String>();
        	Hashtable<String, String> userDefaultPermission = new Hashtable<String, String>();
	        try {
	        	Map<QName, Serializable> nodeProp = serviceRegistry.getNodeService().getProperties(noderef);
	        	final QName type = serviceRegistry.getNodeService().getType(noderef);
	        	WritableCellFormat format;
	        	WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);
	        	WritableFont times10ptBoldUnderline1 = new WritableFont(WritableFont.TIMES, 10, WritableFont.NO_BOLD, false);
	        	if(isRoot){
	        		format = new WritableCellFormat(times10ptBoldUnderline);
	                format.setBackground(Colour.AQUA);
	                format.setWrap(true);	
	        	}else{
	        		format = new WritableCellFormat(times10ptBoldUnderline1);
	        		format.setWrap(true);
	        	}
	        	userDefaultPermission=getAllNodeSetPermissions(noderef);
				if(!userDefaultPermission.isEmpty()){
				Set<String> keys = userDefaultPermission.keySet();
		        for(String key: keys){
		            String role = userDefaultPermission.get(key);
		            if(role.equalsIgnoreCase("OwnerRole"))
		            	ownerList.add(key);
		            else if(role.equalsIgnoreCase("AdminRole"))
		            	adminList.add(key);
		            else if(role.equalsIgnoreCase("EditorRole"))
		            	editorList.add(key);
		            else if(role.equalsIgnoreCase("ReaderRole"))
		            	readerList.add(key);
		            else if(role.equalsIgnoreCase("ViewerRole"))
		            	viewerList.add(key);
		        }
				}
			String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
	        fileName = CharUtil.replaceEscape(fileName);
	        lable = new Label(nameColumn, row, ISO9075.decode(fileName), format);
			wSheet1.addCell(lable);
			lable = new Label(nodeRefColumn, row, noderef.toString(), format);
			wSheet1.addCell(lable);
			String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
	        title = CharUtil.replaceEscape(title);
	        lable = new Label(titleColumn, row, ISO9075.decode(title), format);
			wSheet1.addCell(lable);
			lable = new Label(docIdColumn, row, (String) nodeProp.get(ExternalSharingConstants.PROP_EDCS_ID), format);
			wSheet1.addCell(lable);
			lable = new Label(securityColumn, row, (String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY), format);
			wSheet1.addCell(lable);
			//
			lable = new Label(veraprotectionColumn, row, (String) nodeProp.get(ExternalSharingConstants.PROP_VERA_ENABLED_BY), format);
			wSheet1.addCell(lable);
			if(nodeProp.containsKey(ExternalSharingConstants.PROP_VERA_ENABLED_DATE)){
				logger.error(nodeProp.get(ExternalSharingConstants.PROP_VERA_ENABLED_DATE));
				lable = new Label(lastaccessedColumn, row, formatter2.format(nodeProp.get(ExternalSharingConstants.PROP_VERA_ENABLED_DATE)), format);
				wSheet1.addCell(lable);
			}
			//
			if(ownerList.isEmpty())
				lable = new Label(ownerColumn, row, "", format);
			else
	            lable = new Label(ownerColumn, row, ownerList.toString(), format);
	        wSheet1.addCell(lable);
	        
	        if(adminList.isEmpty())
	        	lable = new Label(adminColumn, row, "", format);
	        else
	            lable = new Label(adminColumn, row, adminList.toString(), format);
	        wSheet1.addCell(lable);
	        
	        if(editorList.isEmpty())
	        	lable = new Label(editorColumn, row, "", format);
	        else
	            lable = new Label(editorColumn, row, editorList.toString(), format);
	        wSheet1.addCell(lable);
	        
	        if(readerList.isEmpty())
	        	lable = new Label(readerColumn, row, "", format);
	        else
	            lable = new Label(readerColumn, row, readerList.toString(), format);
	        wSheet1.addCell(lable);
	        
	        if(viewerList.isEmpty())
	        	lable = new Label(viewerColumn, row, "", format);
	        else
	            lable = new Label(viewerColumn, row, viewerList.toString(), format);
	        wSheet1.addCell(lable);
	        String relativePath=getNodeRelativePath(noderef);
	        lable = new Label(pathColumn, row, relativePath, format);
	        wSheet1.addCell(lable);
	        } catch (RowsExceededException e) {
				e.printStackTrace();
			} catch (WriteException e) {
				e.printStackTrace();
			}
	}

	public boolean userAccess(String currentUserName, String strEnailID)
	{
		boolean isValidUser = false;
		String delimiter = "@";
		if (strEnailID != null && strEnailID.length() > 0) {
			String[] temp = strEnailID .split(delimiter);
			String emailId = temp[1];
			logger.error("emailid>>>"+emailId);
			if (emailId.equalsIgnoreCase("cisco.com")) {
				isValidUser = true;
			}
			logger.error("isValidUser>>>"+isValidUser);
		}
		return isValidUser;
	}
	
	/**
	 * @param searchQuery
	 * @return
	 */
	private List<NodeRef> getContentList(String searchQuery){ 
		int skipCount = 0;
		List<NodeRef> nodeRefList = null;
		int maxValue=Integer.parseInt(docexReportMaxValue);
		while(true)
		{
			SearchParameters sp = new SearchParameters();
			sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
			sp.setLanguage(SearchService.LANGUAGE_LUCENE);
			sp.setMaxItems(500);
			sp.setSkipCount(skipCount);
			sp.setQuery(searchQuery);
			ResultSet results = serviceRegistry.getSearchService().query(sp);
			if(skipCount == 0)
				nodeRefList = new ArrayList<NodeRef>();
			if (null == results || results.length() <= 0)
				break;
			for (ResultSetRow row : results) {
				nodeRefList.add(row.getNodeRef());
			}
			//}
			results.close();
			if(skipCount == maxValue)
				break;
			skipCount += 500;
		}
	return nodeRefList;
	}
	
	/**
	 * @param noderef
	 * @return
	 */
	public Hashtable<String, String> getAllNodeSetPermissions(NodeRef noderef) {
		Iterator<AccessPermission> fIterator=null;
		Hashtable<String, String> userDefaultPermissions = null;
		Set<AccessPermission> accessPermissions = serviceRegistry.getPermissionService().getAllSetPermissions(noderef);
		fIterator = accessPermissions.iterator();
		userDefaultPermissions = new Hashtable<String, String>();
		while (fIterator.hasNext()) {
			AccessPermission accessPermission = (AccessPermission) fIterator.next();
			if (accessPermission.getAuthorityType() == AuthorityType.USER) {
				String autherityUserName = accessPermission.getAuthority();
				String autherityUserPermission = accessPermission.getPermission();
				userDefaultPermissions.put(autherityUserName, autherityUserPermission);
            }
		}
		return userDefaultPermissions;	
	}
	 
	
	/**
	 * @param noderef
	 * @return
	 */
	public String getNodeRelativePath(NodeRef noderef) {
		String filePaths = "";
		Path path = serviceRegistry.getNodeService().getPath(noderef);
        if (path != null)
        {
        	filePaths = path.toString();
            filePaths = filePaths.replaceAll("\\{http://www.alfresco.org/model/application/1.0\\}", "");
            filePaths = filePaths.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "");
            filePaths = filePaths.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}", "");
        }
        filePaths = ISO9075.decode(filePaths);
        String finalFilePath="";
        finalFilePath=filePaths.replaceAll("\\{http://www.cisco.com/model/content/1.0\\}", "");
        String relativePath = finalFilePath.replaceAll("/company_home/sites/edcsng/documentLibrary/", "");
		return relativePath;
	}
	
	 /**
	 * @param strEmailID
	 * @param filePathString
	 * @param currentUser
	 */
	public void sendEMail(String strEmailID, String filePathString, String currentUser) {
	    	InputStream in =null;
	    	NodeRef newNodeRef = null;
	    	String downloadUrl = null;
			Map<String, Object> model = new HashMap<String, Object>();
			boolean mailstatus = false;
			try {
				TemplateService templateService = serviceRegistry.getTemplateService();
				model.put("year", new SimpleDateFormat("yyyy").format(new Date()));
				model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
				String strArray[] = strEmailID.split(",");
				if(filePathString!=null && !filePathString.isEmpty()) {
				File fileObject= new File(filePathString);
				String fileName = filePathString.substring(filePathString.lastIndexOf("/"));
				String extension = fileName.substring(fileName.indexOf("."));
				if(fileObject.exists()) { 
			         double bytes = fileObject.length();
			         in = new BufferedInputStream(new FileInputStream(fileObject));
			         logger.error("Report size in bytes:: " + bytes+" file extension:: "+extension+" file name:: "+fileName);
			         fileName=fileName.replace("/", "");
			         NodeRef usersHomeFolderNodeRef = getUserHomeFolder(currentUser);
			         logger.error("noderef of saved::"+usersHomeFolderNodeRef);
			         if(usersHomeFolderNodeRef!=null) {
							newNodeRef = (serviceRegistry.getFileFolderService().create(usersHomeFolderNodeRef,getUniqueFileName(fileName,usersHomeFolderNodeRef),ServiceConstants.TYPE_CISCODOCS)).getNodeRef();
							ContentWriter writer = serviceRegistry.getContentService().getWriter(newNodeRef, ContentModel.TYPE_CONTENT, true);
							if(extension.equals(".csv")) {
							writer.setMimetype("text/csv");
							}else {
								writer.setMimetype("application/vnd.ms-excel");
							}
							writer.putContent(in);
							serviceRegistry.getNodeService().addAspect(newNodeRef, ServiceConstants.ASPECT_CISCOMETADATA, null);
							serviceRegistry.getNodeService().setType(newNodeRef, ServiceConstants.TYPE_CISCODOCS);
							serviceRegistry.getNodeService().addAspect(newNodeRef, ContentModel.ASPECT_AUDITABLE, null);
							serviceRegistry.getNodeService().addAspect(newNodeRef, ContentModel.ASPECT_REFERENCEABLE, null);
							//setting Folder Admin permissions to report file 
							serviceRegistry.getPermissionService().setPermission(newNodeRef, currentUser, "AdminRole", true);
							serviceRegistry.getPermissionService().setInheritParentPermissions(newNodeRef, false);
						boolean isDocument = serviceRegistry.getDictionaryService().isSubClass(serviceRegistry.getNodeService().getType(newNodeRef), ContentModel.TYPE_CONTENT);
						logger.error("isDocument :::: "+isDocument);
						if(isDocument) {
						
						String DocName = (String) serviceRegistry.getNodeService().getProperty(newNodeRef, ContentModel.PROP_NAME);
				         downloadUrl=titleURL+"/alfext/ext/download/workspace/SpacesStore/"+newNodeRef.getId()+"/"+URLEncoder.encode(DocName,"UTF-8").replaceAll("\\+", "%20")+"?a=true";
				         logger.error("Node id Document::::::: "+newNodeRef.toString() + " ;url : " + downloadUrl);
		        		  String  downloadConstantMsg ="<span style='color:#6683BF;text-decoration: none;'><a href="+downloadUrl+">Click here</a></span> to DOWNLOAD the file to your desktop";
		        		  logger.error(" Document download url ::::::: "+downloadConstantMsg);
							model.put("navigatePemissionMsg", downloadConstantMsg);
							String mailSubject = "DocExchange vera content report";
							String htmlBody = templateService.processTemplate(DOCEX_REPORT_TEMPLATE, model);  
							mailstatus = MailUtil.sendMail(mailServer,mailerFromID, strArray, null, mailSubject,htmlBody, null);
							logger.error("Single Mail Sataus ::: " + mailstatus  +  "   For user  ::  " +strEmailID);
						}
						}
			}else {
				logger.error(":::: UserHome is not exists to create report ::::  ");
			}
				in.close();
				}else {
						String  downloadConstantMsg ="<span style='color:#6683BF;text-decoration: none;'></span> Your report exceeds max limit of 64k rows, <a href="+docexSupportUrl+">Click here</a> to reach out to support team to generate complete report.";
						logger.error(" Document download url ::::::: "+downloadConstantMsg);
						model.put("navigatePemissionMsg", downloadConstantMsg);
						String mailSubject = "DocExchange vera content report";
						String htmlBody = templateService.processTemplate(DOCEX_REPORT_TEMPLATE, model);  
						mailstatus = MailUtil.sendMail(mailServer,mailerFromID, strArray, null, mailSubject,htmlBody, null);
						logger.error("Max Limit Mail Sataus ::: " + mailstatus  +  "   For user  ::  " +strEmailID);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally {
				if (in != null) {
					try {
						in.close();
					} catch (IOException e) {
						logger.error("IOException: "+ExceptionUtils.getFullStackTrace(e), e);
					}
				}
			}
		}
	    /**
	     * get user home folder from repository
	     */
		public NodeRef getUserHomeFolder(final String currentUser) {
			NodeRef folderNodeRef = null;
			String searchQuery = "PATH:\"/app:company_home/app:user_homes/cm:" + currentUser + "\"";
			logger.error("searchQuery   ::: " + searchQuery);
			folderNodeRef = EDCSUtil.doSearch(searchQuery, serviceRegistry);
			//logger.error("getUserHomeFolder   ::: " + folderNodeRef);
			return folderNodeRef;
		}
	    /**
	     * get unique name for report generation
	     */
	    public String getUniqueFileName(String name , NodeRef parentNodeRef){
	    	boolean fileNameExists=true;
	    	String filename=name;
	    	String tempFileName=name;
	    	int dotIndex,counter=1;
	    	while(fileNameExists){
	    		NodeRef node =serviceRegistry.getFileFolderService().searchSimple(parentNodeRef, tempFileName);
	    		if(node!=null){
	    			dotIndex = filename.lastIndexOf(".");
					if (dotIndex == 0) {
						// File didn't have a proper 'name' instead it had just a suffix and started with a ".", create "1.txt"
						tempFileName = counter + filename;
					} else if (dotIndex > 0) {
						// Filename contained ".", create "filename-1.txt"
						tempFileName = filename.substring(0, dotIndex) + "_"	+ counter + filename.substring(dotIndex);
					} else {
						// Filename didn't contain a dot at all, create "filename-1"
						tempFileName = filename + "-" + counter;
					}
	    			counter++;
	    		}else{
	    			fileNameExists=false;
	    		}
	    	}
	    	//logger.error("final tempFileName :: " + tempFileName);
	    	return tempFileName;
	    }
}
