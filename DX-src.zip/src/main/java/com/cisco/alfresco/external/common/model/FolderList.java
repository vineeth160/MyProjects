package com.cisco.alfresco.external.common.model;

import java.util.List;


/**
 * 
 * @author nabbeher
 * 
 */
public class FolderList
{

    private List<Folder> folderList;

    public List<Folder> getFolderList()
    {
        return folderList;
    }

    public void setFolderList(List<Folder> folderList)
    {
        this.folderList = folderList;
    }

}
