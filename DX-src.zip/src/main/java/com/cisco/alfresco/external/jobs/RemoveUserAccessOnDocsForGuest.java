package com.cisco.alfresco.external.jobs;

import java.io.Serializable;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.transaction.RetryingTransactionHelper.RetryingTransactionCallback;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.TemplateService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.transaction.TransactionService;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;
import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.edcsng.util.MailUtil;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;

/**
 * 
 * @author murakuma -
 * 
 */
public class RemoveUserAccessOnDocsForGuest extends QuartzJobBean {
	private static final Logger LOGGER = Logger.getLogger(RemoveUserAccessOnDocsForGuest.class);
	private ServiceRegistry serviceRegistry;
	private ExternalLDAPUtil ldapUtil;
	public static String JOBTRACKER_STATUS_NOTIFICATION_TEMPLATE = "/alfresco/extension/templates/email/jobTrackerFailNotification.ftl";
	private String searchQuery = "PATH:\"/app:company_home/st:sites/cm:edcsng/cm:documentLibrary//*\" AND TYPE:\"cm:folder\" AND @ext\\:disableguestUser:true";
	private static final String KEY_IS_JOB_ENABLED = "ciscoRemoveUserAccessJobEnabled";
	private boolean isJobEnabled = false;
	private static final int DAYSTOSUBTRACT = 8;
	private TransactionService transactionService;
	String status = "";
	private String mailerFromID;
	private String mailServer;
	private SessionFactory localFactory;
	private String bannerAlfrescoUrl;
	private String mailerToID;

	public String getMailerToID() {
		return mailerToID;
	}

	public void setMailerToID(String mailerToID) {
		this.mailerToID = mailerToID;
	}


	public String getMailerFromID() {
		return mailerFromID;
	}

	public void setMailerFromID(String mailerFromID) {
		this.mailerFromID = mailerFromID;
	}

	public String getMailServer() {
		return mailServer;
	}

	public void setMailServer(String mailServer) {
		this.mailServer = mailServer;
	}

	public SessionFactory getLocalFactory() {
		return localFactory;
	}

	public void setLocalFactory(SessionFactory localFactory) {
		this.localFactory = localFactory;
	}

	public String getBannerAlfrescoUrl() {
		return bannerAlfrescoUrl;
	}

	public void setBannerAlfrescoUrl(String bannerAlfrescoUrl) {
		this.bannerAlfrescoUrl = bannerAlfrescoUrl;
	}

	/**
	 * @return the transactionService
	 */
	public TransactionService getTransactionService() {
		return transactionService;
	}

	/**
	 * @param transactionService
	 *            the transactionService to set
	 */
	public void setTransactionService(TransactionService transactionService) {
		this.transactionService = transactionService;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public String getSearchQuery() {
		return searchQuery;
	}

	public void setSearchQuery(String searchQuery) {
		this.searchQuery = searchQuery;
	}

	public ExternalLDAPUtil getLdapUtil() {
		return ldapUtil;
	}

	public void setLdapUtil(ExternalLDAPUtil ldapUtil) {
		this.ldapUtil = ldapUtil;
	}

	/**
	 * 
	 */
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("=======RemoveUserAccessOnDocsForGuest Job Started======");
		String jobName = "RemoveUserAccessOnDocsForGuest";
		String endDate = "";
		String startDate = "";
		JobDataMap jobData = context.getJobDetail().getJobDataMap();
		String isJobEnabledStr = (String) jobData.get(KEY_IS_JOB_ENABLED);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime dateTime = LocalDateTime.now();
		startDate = dtf.format(dateTime);
		LOGGER.info("startDate" + startDate);
		String unixBoxName = getUnixBoxName();
		LOGGER.info("UnixBoxName==" + unixBoxName + "jobName==" + jobName);
		if (isJobEnabledStr != null) {
			try {
				isJobEnabled = new Boolean(isJobEnabledStr);
			} catch (Exception e) {
				LOGGER.error("Invalid '" + KEY_IS_JOB_ENABLED + "' value, using default: " + isJobEnabled, e);
			}
		}

		if (!isJobEnabled) {
			// skip Job
			LOGGER.error("Skipping " + KEY_IS_JOB_ENABLED + " to execute.");
			return;
		}
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {

				try {

					String currentDate = getFromCurrentDate();
					String toDate = getToDate(DAYSTOSUBTRACT);
					searchQuery = searchQuery + " AND @cm\\:modified:[\"" + toDate + "\" TO \"" + currentDate + "\"]";
					LOGGER.info("searchQuery: " + searchQuery);
					List<NodeRef> searchNodeList = EDCSUtil.getNodeRefList(searchQuery, serviceRegistry);
					if (searchNodeList != null) {
						for (NodeRef parentNodeRef : searchNodeList) {
							List<FileInfo> fileInfoList = serviceRegistry.getFileFolderService().list(parentNodeRef);
							if (fileInfoList.size() > 0) {
								for (FileInfo fileInfo : fileInfoList) {
									if (!fileInfo.getType().equals(ContentModel.TYPE_FOLDER)) {
										NodeRef docNodeRef = fileInfo.getNodeRef();
										Map<QName, Serializable> nodeProp = serviceRegistry.getNodeService()
												.getProperties(docNodeRef);
										// System.out.println("nodeProp "+nodeProp);
										String security = fileInfo.getProperties()
												.get(ExternalSharingConstants.PROP_EXT_SECURITY) != null
														? (String) fileInfo.getProperties()
																.get(ExternalSharingConstants.PROP_EXT_SECURITY)
														: "";
										// LOGGER.info("security:" +
										// nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY));
										if (!"Cisco Public".equalsIgnoreCase(security))
											removePermissionForGuestUser(docNodeRef);
									}
								}
							}
							removePermissionForGuestUser(parentNodeRef);
						}
					}

				} catch (Exception e) {
					status = "Failed";
					LOGGER.error("Exception ::::  : " + e.getMessage());
				}
				return null;
			}
		}, "admin");
		if (status.isEmpty() && status != null && (!status.equals("Failed") && "".equals(status))) {
			status = "Success";
		}

		DateTimeFormatter dtformater = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime ldTime = LocalDateTime.now();
		endDate = dtformater.format(ldTime);
		LOGGER.info("endDate" + endDate);
		LOGGER.info(jobName + "@@@" + "@@@" + startDate + "@@@" + endDate + "@@@" + status + "@@@@@" + unixBoxName);

		updateDB(unixBoxName, jobName, startDate, endDate, status);
		LOGGER.info("==>mailerToID<===" + mailerToID);
		if (!status.isEmpty() && status != null && status.equals("Failed")) {
			sendEMail(unixBoxName, mailerToID, jobName, status);
		}

	}

	/**
	 * 
	 * @param nodeRef
	 */
	public void removePermissionForGuestUser(final NodeRef nodeRef) {

		LOGGER.error("entring removepermissionforguestuser method>>>>>");
		Set<AccessPermission> accessPermissions = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
		Iterator<AccessPermission> fIterator = accessPermissions.iterator();
		AccessPermission accessPermission = null;
		Boolean isDisableguestUser = false;

		while (fIterator.hasNext()) {
			accessPermission = fIterator.next();
			// LOGGER.info("User Name ::" + accessPermission.getAuthority()+ ":");
			if (accessPermission.getAuthorityType() == AuthorityType.USER) {
				final String userName = accessPermission.getAuthority();
				final String userPermission = accessPermission.getPermission();
				final String accessLevel = ldapUtil.getUserAccessLevelFromLDAP(userName);
				LOGGER.info("Authority(User): " + userName + " Permission:  " + userPermission + "  nodeRef: " + nodeRef
						+ " accessLevel: " + accessLevel);

				// prbadam Start: DE3278
				boolean isDoc = serviceRegistry.getDictionaryService()
						.isSubClass(serviceRegistry.getNodeService().getType(nodeRef), ContentModel.TYPE_CONTENT);
				LOGGER.error("isDoc-------------" + isDoc);
				LOGGER.info("isDoc-------------" + isDoc);
				if (isDoc) {
					ChildAssociationRef childAssociationRef = serviceRegistry.getNodeService()
							.getPrimaryParent(nodeRef);
					NodeRef parentNodeRef = childAssociationRef.getParentRef();
					LOGGER.error("parentNodeRef----------" + parentNodeRef);
					LOGGER.info("parentNodeRef----------" + parentNodeRef);
					isDisableguestUser = (Boolean) serviceRegistry.getNodeService().getProperty(parentNodeRef,
							QName.createQName("{http://www.alfresco.org/model/external/content/1.0}disableguestUser"));
				} else {
					isDisableguestUser = (Boolean) serviceRegistry.getNodeService().getProperty(nodeRef,
							QName.createQName("{http://www.alfresco.org/model/external/content/1.0}disableguestUser"));
				}
				LOGGER.error("isDisableguestUser------" + isDisableguestUser);
				LOGGER.info("isDisableguestUser------" + isDisableguestUser);

				if ("1".equals(accessLevel) && isDisableguestUser) {
					this.transactionService.getRetryingTransactionHelper()
							.doInTransaction(new RetryingTransactionCallback<Void>() {
								@Override
								public Void execute() throws Throwable {
									boolean inheritPermission = serviceRegistry.getPermissionService()
											.getInheritParentPermissions(nodeRef);
									serviceRegistry.getPermissionService().setInheritParentPermissions(nodeRef, false);
									serviceRegistry.getPermissionService().deletePermission(nodeRef, userName,
											userPermission);

									serviceRegistry.getPermissionService().setInheritParentPermissions(nodeRef,
											inheritPermission);
									LOGGER.error("Permission has been removed for the Guest User :" + userName
											+ " with AccessLevel: " + accessLevel);

									LOGGER.info(" Permission has been removed for the Guest User :" + userName
											+ " with AccessLevel: " + accessLevel);

									return null;
								}
							}, false, true);
				}

			}

		}
	}
	private String getUnixBoxName() {
		StringBuffer ipAddresses = new StringBuffer();
		InetAddress iAddress;
		try {
			iAddress = InetAddress.getLocalHost();
			String hostName = iAddress.getHostName();
			ipAddresses.append(hostName);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ipAddresses.toString();
	}

	public void sendEMail(String hostName, String mailerToID, String jobName, String status) {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("year", new SimpleDateFormat("yyyy").format(new Date()));
		model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
		model.put("hostName", hostName);
		model.put("jobName", jobName);
		model.put("jobstatus", status);
		// NodeRef template =
		// getEmailtemplate(addUserFtlLocationPath,ADD_USER_NOTIFICATION_TEMPLATE);
		TemplateService templateService = serviceRegistry.getTemplateService();
		String strArray[] = mailerToID.split(",");
		String mailSubject = jobName + " Scheduled Job Tracking Fail notification";
		String htmlBody = templateService.processTemplate(JOBTRACKER_STATUS_NOTIFICATION_TEMPLATE, model);

		LOGGER.info("mailServer==" + mailServer + "==mailerFromID==" + mailerFromID + "==strArray==" + strArray
				+ "==mailSubject==" + mailSubject + "==mailerToID==" + mailerToID);
		boolean mailstatus = false;
		try {
			mailstatus = MailUtil.sendMail(mailServer, mailerFromID, strArray, null, mailSubject, htmlBody, null);
			LOGGER.info("Mail Sataus >>>" + mailstatus + "   For user  ::  " + mailerToID);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void updateDB(String getUnixBoxName, String jobName, String startDate, String endDate, String status) {
		LOGGER.info("Entered DB method");
		Session session = null;
		Transaction tx = null;
		JobTracker jobValues = new JobTracker();

		try {
			session = localFactory.openSession();
			tx = session.beginTransaction();
			String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
			String entryId = jobName.toString() + "_" + timeStamp.toString();
			jobValues.setEntryId(entryId.toString());
			jobValues.setBoxName(getUnixBoxName);
			jobValues.setJobName(jobName);
			jobValues.setStartDate(startDate);
			jobValues.setEndDate(endDate);
			jobValues.setStatus(status);
			session.save(jobValues);
			LOGGER.info(jobValues.getBoxName() + "@@@" + jobValues.getJobName() + "@@@" + jobValues.getStartDate()
					+ "@@@" + jobValues.getEndDate() + "@@@" + jobValues.getStatus());

			tx.commit();
			LOGGER.info("==Job Status Data Saved successfully:");
		} catch (Exception e) {
			LOGGER.info("Error occured While updating " + e.getMessage());
			e.printStackTrace();
		}
	}

	private String getFromCurrentDate() {
		Calendar c = Calendar.getInstance();
		StringBuffer currentDate = new StringBuffer();
		currentDate.append(c.get(Calendar.YEAR));
		currentDate.append("-");
		currentDate.append(c.get(Calendar.MONTH) + 1);
		currentDate.append("-");
		currentDate.append(c.get(Calendar.DATE));
		return currentDate.toString();
	}

	private String getToDate(int noOfDaysToSubtract) {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, -noOfDaysToSubtract);
		StringBuffer toDate = new StringBuffer();
		toDate.append(c.get(Calendar.YEAR));
		toDate.append("-");
		toDate.append(c.get(Calendar.MONTH) + 1);
		toDate.append("-");
		toDate.append(c.get(Calendar.DATE));
		return toDate.toString();
	}

}
