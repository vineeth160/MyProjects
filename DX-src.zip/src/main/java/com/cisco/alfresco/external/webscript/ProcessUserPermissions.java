package com.cisco.alfresco.external.webscript;

import java.io.File;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.transaction.RetryingTransactionHelper.RetryingTransactionCallback;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.TemplateService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.edcsng.util.MailUtil;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
public class ProcessUserPermissions extends Thread{
	
	public static String ADD_USER_NOTIFICATION_TEMPLATE = "/alfresco/extension/templates/email/PermissionUpdatedNotification.ftl";
	private static String preferenceFilter = "org.alfresco.share.folders.favourites";
	final static QName DOMAIN_QNAME = QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name");
	private WritableCellFormat timesBoldUnderline;
	private static final Logger LOGGER = Logger.getLogger(ProcessUserPermissions.class);
	public static String PREFERENCE_REMOVE_ACTION_YES="yes";
	public static String PREFERENCE_REMOVE_ACTION_NO="no";
    private Workbook wb;
	private String filePath;
	private String currentUserName;
	private NodeRef nodeRef;
	private String strManagerID;
	private ServiceRegistry serviceRegistry;
	private PreferenceService preferenceService;
	private ExternalLDAPUtil ldapUtil;
	//private String addUserFtlLocationPath;
	private String mailServer;
	private String mailerFromID;
	private String bannerAlfrescoUrl;
	private String titleURL;
	private String contextName;
	public ProcessUserPermissions(final Workbook wb,final String filePath,final String currentUserName,final NodeRef nodeRef,final String strManagerID,final ServiceRegistry serviceRegistry,final PreferenceService preferenceService,final ExternalLDAPUtil ldapUtil,
			final String mailServer,final String mailerFromID,final String bannerAlfrescoUrl,final String titleURL,final String contextName){
		//final String addUserFtlLocationPath,
		this.wb = wb;
		this.filePath=filePath;
		this.currentUserName = currentUserName;
		this.nodeRef = nodeRef;
		this.strManagerID = strManagerID;
		this.serviceRegistry=serviceRegistry;
		this.preferenceService= preferenceService;
		this.ldapUtil= ldapUtil;
		this.mailServer=mailServer;
		this.mailerFromID=mailerFromID;
		this.bannerAlfrescoUrl=bannerAlfrescoUrl;
		//this.addUserFtlLocationPath=addUserFtlLocationPath;
		this.titleURL=titleURL;
		this.contextName=contextName;
	
	}
    
	@Override
	public void run() {
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
		WritableWorkbook workbookw = null;
		try {
			
		LOGGER.info("inside run method");
		LOGGER.info("username  :: " +currentUserName + "  manager id ::  " +strManagerID);
		workbookw = Workbook.createWorkbook(new File(filePath), wb);
		WritableSheet sheet = workbookw.getSheet("Sheet1");
		Sheet sh = wb.getSheet("Sheet1");
		LOGGER.info("nodeRef :: " +nodeRef);
		Map<QName, Serializable> nodeProp = serviceRegistry.getNodeService().getProperties(nodeRef);
		String name = (String) nodeProp.get(ContentModel.PROP_NAME);
	    readExcel(sh, nodeRef,sheet, workbookw);
	    
	    String nodeId = nodeRef.getId();
	     final QName type = serviceRegistry.getNodeService().getType(nodeRef);
		  String permissionUrl=null;
			if (type.equals(ContentModel.TYPE_FOLDER))
          {
				permissionUrl=titleURL+contextName+"/ui/#/folder/permissions/"+nodeId;	
          }
			else{
				 permissionUrl=titleURL+contextName+"/ui/#/file/permissions/"+nodeId;
			}
		  LOGGER.info("permissionUrl :: " +permissionUrl);
		  String  navigatePemissionMsg ="<span style='color:#6683BF;text-decoration: none;'><a href="+permissionUrl+">Click here</a></span> to go to updated permissions page.";
		  sendEMail(name,strManagerID,filePath,navigatePemissionMsg);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
			}
		}, "admin");
	}
	
	//Reading Uploaded Bulk import template from server temp location and reading each userid and updating user permissions accordingly and updating each user status to the same template 
	
	public synchronized void readExcel(Sheet sh, final NodeRef nodeRef, WritableSheet sheet, WritableWorkbook workbookw) {
		ArrayList<String> userid;
		ArrayList<String> userrole;
		String userRole = null;
		String userId = null;
		try {
			
			int totalNoOfRows = sh.getRows();
			if (nodeRef != null) {
                // Getting all the the direct permissions on the noderef. 
				Iterator<AccessPermission> fIterator;
				Set<AccessPermission> accessPermissions1 = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
				Hashtable<String, String> userDefaultPermission = new Hashtable<String, String>();
				fIterator = accessPermissions1.iterator();
				while (fIterator.hasNext()) {
					AccessPermission accessPermission = (AccessPermission) fIterator.next();
					if (accessPermission.getAuthorityType() == AuthorityType.USER && accessPermission.isSetDirectly()) {
						String autherityUserName = accessPermission.getAuthority();
						String autherityUserPermission = accessPermission.getPermission();
						userDefaultPermission.put(autherityUserName, autherityUserPermission);

					}
				}
				LOGGER.info("userDefaultPermission  :::  " + userDefaultPermission);
				
                Label lable = null;
				int insertColumn = 4;
				int firstnamecol = 2;
				int lastnamecol = 3;
				int commentcol = 5;
				//font changes create a bold font
				WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 11, WritableFont.BOLD, false);
				timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
				// Lets automatically wrap the cells
			    timesBoldUnderline.setWrap(true);
				sheet.insertColumn(firstnamecol);
				lable = new Label(firstnamecol, 2, "FirstName",timesBoldUnderline);
				sheet.addCell(lable);
				sheet.insertColumn(lastnamecol);
				lable = new Label(lastnamecol, 2, "LastName",timesBoldUnderline);
				sheet.addCell(lable);
				sheet.insertColumn(insertColumn);
				lable = new Label(insertColumn, 2, "Status",timesBoldUnderline);
				sheet.addCell(lable);
				sheet.insertColumn(commentcol);
				lable = new Label(commentcol, 2, "Comments",timesBoldUnderline);
				sheet.addCell(lable);
				//Looping each row
				for (int row = 3; row < totalNoOfRows; row++) {
					int col = 0; 
					boolean status = true;
					LOGGER.info(" Starting with status TRUE  :: " +status );
					if (col == 0) {
						String strFirstName = "", strLastName = "";
						String accesslevel = null, ManagerID = null,strUserDetails = null;
						userid = new ArrayList<String>();
						//checking whether user is passing email id or user id
						Cell colvalue = sh.getCell(0, 2);
						LOGGER.info("colvalue.getconts()  :::  " +colvalue.getContents());
						String usernameformid = null;
						if(colvalue.getContents().replaceAll(" ", "").equalsIgnoreCase("emailid")){
							Cell emailidvalue = sh.getCell(col, row);
							
							    String  emailId = emailidvalue.getContents().replaceAll(" ", "");
							    lable = new Label(0, row, emailId);
								sheet.addCell(lable);
								String emailDetails = ldapUtil.getUserDetailsFromLDAPemailBased(emailId);
								LOGGER.info("emailDetails ::: " +emailDetails);
								if(emailDetails != null && emailDetails != "" && !emailDetails.isEmpty()){
									usernameformid  = (emailDetails.split("::"))[0];
								userid.add(usernameformid);							
								}else{
									status=false;
									LOGGER.info("Invalid email id  :: " +status);
									
								}
						}else{
						Cell useridvalue = sh.getCell(col, row);
						userid.add(useridvalue.getContents());
						}
						if(status){
						for (int i = 0; i < userid.size(); i++) {
							
							userId = userid.get(i).replaceAll(" ", "");
							if(colvalue.getContents().replaceAll(" ", "").equalsIgnoreCase("userid")){
								lable = new Label(0, row, userId);
								sheet.addCell(lable);
									}
							try {
                                 //Starting user id validations
								if (userId != null && userId != "" && !userId.isEmpty()) {
									boolean internaluser = ldapUtil.isLdapUserInternal(userId);
									boolean isUserExists =false;
                                    strUserDetails = ldapUtil.getUserDetailsFromLDAP(userId);
									LOGGER.info("struserDetails ="+ strUserDetails);
									if (strUserDetails != null && strUserDetails != "" && !strUserDetails.isEmpty()) {
										userId=(strUserDetails.split("::"))[0];
										LOGGER.info("userId details from ldap :::::::::: " +userId);
										isUserExists = serviceRegistry.getPersonService().personExists(userId);
										if (userId.equalsIgnoreCase(currentUserName)) {
											status=false;
											LOGGER.info("Folder must have one folder admin  :: " +status);
											
										}
										String fullName = (strUserDetails.split("::"))[1];
										ManagerID = (strUserDetails.split("::"))[3];
										accesslevel = (strUserDetails.split("::"))[6];
										if (fullName != null && fullName != "") {
											if (fullName.trim().contains(" ")) {
												strFirstName = (fullName.split(" "))[0];
												strLastName = (fullName.split(" "))[1];
												
											} else {
												strFirstName = fullName;
											}

										} else
											strFirstName = fullName;
									}
									boolean usrExist = false;
									// if user is not there in alfresco repo we have create based on LDAP Details
									if (strUserDetails != null && !strUserDetails.isEmpty() && !isUserExists) {
										final String username = userId;
										LOGGER.info("username details from ldap :::::::::: " +username);
										AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
													@Override
													public Object doWork() throws Exception {
                       
														ldapUtil.createLDAPUser(username);
														return username;
													}
												}, "admin");

									}

									usrExist = serviceRegistry.getPersonService().personExists(userId); 
									if (internaluser) {
										LOGGER.info("valid internal user");

									} else if (strUserDetails != null && strUserDetails != "" && usrExist) {
										LOGGER.info("valid user");

									}

									else {
										status=false;
										LOGGER.info("Invalid user :: " +status);
									//	model.put("message", "Invalid user");

									}
									final String delimiter = "@";
									final QName type = serviceRegistry.getNodeService().getType(nodeRef);
									String domainName = null;
									if (type.equals(ContentModel.TYPE_FOLDER)) {
										domainName = (String) serviceRegistry.getNodeService().getProperty(nodeRef,DOMAIN_QNAME);
									} else {
										ChildAssociationRef childAssociationRef = serviceRegistry.getNodeService().getPrimaryParent(nodeRef);
										NodeRef parentNodeRef = childAssociationRef.getParentRef();
										domainName = (String) serviceRegistry.getNodeService().getProperty(parentNodeRef,DOMAIN_QNAME);
									}
									String[] temp;

									if (ManagerID != null && accesslevel.equals("4")) {
										LOGGER.info("Cisco internal user");
									}

									else if (ManagerID != null && ManagerID.length() > 0) {
										
										if (domainName != null && !domainName.equalsIgnoreCase("")) {
											temp = ManagerID.split(delimiter);
											String emailId = temp[1];
											if (domainName.toLowerCase().replaceAll(" ", "").contains(emailId)) {
												LOGGER.info("Email and Domain name are same");
											} else {
												status=false;
												LOGGER.info("Email and Domain name are not equal  :: " +status);
												
											}

										} else {
											LOGGER.info("Domain Name is Null");
										}
									} else {
										LOGGER.info("EMail was not registered for user");
									}
								} else {
									status=false;
									LOGGER.info("userid is null  :: " +status);
									
								}
								
							}

							catch (Exception ww) {
								ww.printStackTrace();
							}
						}
						col = 1;
						userrole = new ArrayList<String>();
						Cell userrolevalue = sh.getCell(col, row);
						userrole.add(userrolevalue.getContents());
						for (int s = 0; s < userrole.size(); s++) {
							userRole = userrole.get(s).replaceAll(" ", "");
							//Starting user role validation
							if (userRole.equalsIgnoreCase("viewer")) {
								userRole = "ViewerRole";

							} else if (userRole.equalsIgnoreCase("reader")) {
								userRole = "ReaderRole";

							} else if (userRole.equalsIgnoreCase("editor")) {
								userRole = "EditorRole";

							} else if (userRole.replace(" ", "").equalsIgnoreCase(("folder admin").replace(" ", ""))) {
								status=false;
								LOGGER.info("Not able to add Admin(folder admin) Role :: " +status);
								
							} else if (userRole.equalsIgnoreCase("Owner")) {
								status=false;
								LOGGER.info("Not able to add Owner Role :: " +status);
								
							} else if (userRole != null && userRole != "") {
								status=false;
								LOGGER.info("Invalid user role :: " +status);
								
							}

						}

						try {
							//Checking whether user is having owner role or user is already having same role on noderef
							if (!userDefaultPermission.isEmpty()) {
                               if (userDefaultPermission.containsKey(userId)) {
                            	   if (userDefaultPermission.get(userId).contentEquals("OwnerRole")) {
                            		   status=false;
										LOGGER.info("You Dont have permission to edit ownerRole :: "+status);
										
									} else if (userDefaultPermission.get(userId).contentEquals(userRole)) {
										status=false;
										LOGGER.info("#############Nothing to update..... Inside - Permissions Updated successfully  :: "+status);
										
									}

								}
							}
                            //adding firstname & lastname of the user in firstnamecol & lastnamecol
							if (userId != null && userId != "") {
								
								lable = new Label(firstnamecol, row,strFirstName);
								sheet.addCell(lable);
								lable = new Label(lastnamecol, row, strLastName);
								sheet.addCell(lable);
							} else {
								lable = new Label(firstnamecol, row, "NA");
								sheet.addCell(lable);
								lable = new Label(lastnamecol, row, "NA");
								sheet.addCell(lable);
							}

							
							LOGGER.info("Before setting permissions status ::  " +status);
							if(status){
								LOGGER.info("true status means model 0");
							    final String userID = userId;
								final String userROLE = userRole;
								boolean isDoc = serviceRegistry.getDictionaryService().isSubClass(serviceRegistry.getNodeService().getType(nodeRef),ContentModel.TYPE_CONTENT);
								LOGGER.info("isDoc-------------" + isDoc);
								
								serviceRegistry.getTransactionService().getRetryingTransactionHelper().doInTransaction(new RetryingTransactionCallback<Void>(){
									public Void execute() throws Throwable { 
										LOGGER.info("clearPermission for user Id -------------" + userID);
										serviceRegistry.getPermissionService().clearPermission(nodeRef,userID);
										serviceRegistry.getPermissionService().clearPermission(nodeRef,userID.toLowerCase());
										//Fix for library performance issue adding custom aspect
				            			  addUserPreferencesProps(userID,nodeRef,PREFERENCE_REMOVE_ACTION_YES);
							         return null;
							         }
							         }, false, true);
								
								//if user role is null set default role as Reader role	
								if (userRole == null || userRole == "") {
									
									serviceRegistry.getTransactionService().getRetryingTransactionHelper().doInTransaction(new RetryingTransactionCallback<Void>(){
										public Void execute() throws Throwable { 
											serviceRegistry.getPermissionService().setPermission(nodeRef,userID,"ReaderRole", true);
									return null;
										}
							         }, false, true);
									
									LOGGER.info("############# Inside - Permissions Updated successfully");
									lable = new Label(insertColumn, row,"Added"); 
									sheet.addCell(lable);
									lable = new Label(commentcol, row,"No Role specified..So, ReaderRole added to this user");
									sheet.addCell(lable);
									} 
								else if (userRole != null) {
									
									serviceRegistry.getTransactionService().getRetryingTransactionHelper().doInTransaction(new RetryingTransactionCallback<Void>(){
										public Void execute() throws Throwable { 
											serviceRegistry.getPermissionService().setPermission(nodeRef,userID,userROLE, true);
									LOGGER.info("############# Inside - Permissions Updated successfully");
									return null;
										}
							         }, false, true);
									
									lable = new Label(insertColumn, row,"Added");
									sheet.addCell(lable);
									lable = new Label(commentcol, row,"User id "+userID+" was successfully added with the requested role");
									sheet.addCell(lable);
									}
								if (!isDoc) {
									setRemovePreferences(userId, nodeRef,currentUserName);
									//Fix for library performance issue adding custom aspect 
									addUserPreferencesProps(userId,nodeRef,PREFERENCE_REMOVE_ACTION_NO);
								}
								
								
							} else {
								lable = new Label(insertColumn, row,"Not Added");
								sheet.addCell(lable);
								lable = new Label(commentcol,row,"No action Performed..Please check the fields you entered or Already user has same permission or Invalid user id please check user id");
								sheet.addCell(lable);
							}
						}
					
						catch (Exception ex1) {
							ex1.printStackTrace();
						}
						LOGGER.info("Permissions Updated successfully");
					}
					 else {
							lable = new Label(insertColumn, row,"Not Added");
							sheet.addCell(lable);
							lable = new Label(commentcol,row,"No action Performed..Please check the fields you entered or Already user has same permission or Invalid user id please check user id");
							sheet.addCell(lable);
						}
					}

				}

				workbookw.write();
				workbookw.close();
				LOGGER.info("Permissions Updated successfully");
				
			}
		} catch (Exception xx) {
			xx.printStackTrace();
		}
		
	}

	public  void sendEMail(String name,String strManagerID, String filePath,String navigatePemissionMsg) {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("year", new SimpleDateFormat("yyyy").format(new Date()));
		model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
		model.put("name", name);
		model.put("navigatePemissionMsg", navigatePemissionMsg);
		TemplateService templateService = serviceRegistry.getTemplateService();
		String strArray[] = strManagerID.split(",");
		String mailSubject = "Your request for bulk addition of users to ("+ name + ") is now complete";
		String htmlBody = templateService.processTemplate(ADD_USER_NOTIFICATION_TEMPLATE, model);
		boolean mailstatus = false;
		try {
			mailstatus = MailUtil.sendMail(mailServer,mailerFromID, strArray, null, mailSubject,htmlBody, filePath);
			LOGGER.info("Mail Sataus >>>" + mailstatus  +  "   For user  ::  " +strManagerID);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This method sets the preference value for the user
	 *  
	 */
	private void setRemovePreferences(String usersList,NodeRef documentNodeRef, String username) {
		Map<String, Serializable> preferences = null;
		Map<String, Serializable> updatedPreferences = null;
		AuthenticationUtil.setFullyAuthenticatedUser("admin");
		try {
			preferences = preferenceService.getPreferences(usersList,preferenceFilter);
			updatedPreferences = updatedPreference(preferences,preferenceFilter, documentNodeRef.toString(),usersList);
			preferenceService.setPreferences(usersList, updatedPreferences);
			LOGGER.info("finished setRemovePreferences method-----------");
			//AuthenticationUtil.setFullyAuthenticatedUser(username);
		} catch (Exception e) {

			e.printStackTrace();
			
		}
		finally{
			if(AuthenticationUtil.getFullyAuthenticatedUser().equals("admin")){
			AuthenticationUtil.setFullyAuthenticatedUser(username);
			}
		}
		
	}

	/**
	 * This method gets all the preferences for the user
	 *  
	 */
	private Map<String, Serializable> updatedPreference(Map<String, Serializable> preferences, String preferenceFilter,String values,String usersId) {
		Set<String> userPreferencesFoldersSet = new HashSet<String>();
		 List<String> userPreferencesFoldersList = new ArrayList<String>();
		 try {
		if (preferences.containsKey(preferenceFilter)) {
			String item = (String) preferences.get(preferenceFilter);
			
			String[] itemArray = item.split(",");
			List<String> list = new ArrayList<String>();
			if (itemArray.length > 0) {
				Collections.addAll(list, itemArray);
			}
			if(list.size()>0) {
				userPreferencesFoldersSet.addAll(list);
			}
			if(!userPreferencesFoldersSet.isEmpty()) {
			 for (String folderId : userPreferencesFoldersSet){
					 userPreferencesFoldersList.add(folderId);
		        }
			}
			boolean hasUserAccessOnParent=ExternalSharingFileFolderUtil.canUserHavePermissionOnParentFolder(values,serviceRegistry,usersId);
			LOGGER.info("if current login user dont have access on parent folder :::: "+hasUserAccessOnParent);
			if (userPreferencesFoldersList.contains(values)) {
				LOGGER.info("alfready folder is there in library section ");
			} else if(hasUserAccessOnParent) {
				userPreferencesFoldersList.add(values);
			}
			preferences.put(preferenceFilter, StringUtils.join(userPreferencesFoldersList, ","));
		} else {
			preferences.put(preferenceFilter, values);
		}
		 }catch(Exception exe){
			 exe.printStackTrace();
		 }
		return preferences;
	}
	
	/**
	 * This method creates association for the library folders
	 *  
	 */
	
	private void addUserPreferencesProps(String logginUser, NodeRef finalUserFolderNode,String isRemoveAccess) {
    	LOGGER.info("inside addUserPreferencesProps-------");
    	AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {

				final NodeRef personNodereff=serviceRegistry.getPersonService().getPerson(logginUser);
				LOGGER.info("Person nodereff   ::" +personNodereff);
			    		try{
			    			boolean hasAspect = serviceRegistry.getNodeService().hasAspect(finalUserFolderNode, CiscoModelConstants.CISCO_DX_FOLDER_ASPECT);
			    			
			    			if(isRemoveAccess.equals(PREFERENCE_REMOVE_ACTION_YES)){
								LOGGER.info("updated preferences node value is ::: "+personNodereff);
								LOGGER.info("remove preferences is ::: "+PREFERENCE_REMOVE_ACTION_YES+" ::node value is:: "+finalUserFolderNode+" ::for user id :: "+logginUser);
								serviceRegistry.getNodeService().removeChild(personNodereff, finalUserFolderNode);
								LOGGER.info("assoc removed successfully---");
			    			}else{
			    				if(hasAspect) {
				    				serviceRegistry.getNodeService().addChild(personNodereff, finalUserFolderNode,
											CiscoModelConstants.CISCO_DX_FOLDER_ASSOCIATION,
											QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, finalUserFolderNode.getId()));
				    				LOGGER.info("assoc added successfully---");
				    			}else {
				    				serviceRegistry.getNodeService().addAspect(finalUserFolderNode, CiscoModelConstants.CISCO_DX_FOLDER_ASPECT,
											null);
									serviceRegistry.getNodeService().addChild(personNodereff, finalUserFolderNode,
											CiscoModelConstants.CISCO_DX_FOLDER_ASSOCIATION,
											QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, finalUserFolderNode.getId()));
									LOGGER.info("assoc added successfully---");
				    			}
							}
			    		
			    		} catch (Exception e) {
		   	        		LOGGER.error("Exception in addUserPreferencesProps----"+e);
		   	        		e.printStackTrace();
						}
				
				return null;
			}
		}, "admin");
	}
	
}


