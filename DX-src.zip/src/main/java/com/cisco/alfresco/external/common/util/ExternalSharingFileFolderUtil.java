package com.cisco.alfresco.external.common.util;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.ContentData;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.Path;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.workflow.WorkflowInstance;
import org.alfresco.service.cmr.workflow.WorkflowTask;
import org.alfresco.service.cmr.workflow.WorkflowTaskQuery;
import org.alfresco.service.namespace.InvalidQNameException;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.ISO9075;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import com.cisco.alfresco.external.common.model.ExtDocument;
import com.cisco.alfresco.external.common.model.Folder;
import com.cisco.alfresco.external.common.model.FolderList;
import com.cisco.alfresco.external.webscript.UserRoleConstants;

public class ExternalSharingFileFolderUtil
{
    private static final Logger LOGGER = Logger.getLogger(ExternalSharingFileFolderUtil.class);
    private static final int DAYSTOSUBTRACT = 30;
    private static final String TASK_IN_PROGRESS = "IN_PROGRESS";
    private static final String GROUP_IDENTITY ="GROUP_";
    private static final String GROUP_EVERYONE="GROUP_EVERYONE";
    private static Integer MAX_VALUE=64000;
    private static Integer MAX_SKIP_VALUE=500;
    /**
     * Constructor
     */
    private ExternalSharingFileFolderUtil()
    {

    }

    /**
     * To get the list of document
     * 
     * @param serviceRegistry
     * @param nodeRefList
     * @param checkPermission
     * @return List of ExtDocumetb
     */
    public List<ExtDocument> getDocumentList(ServiceRegistry serviceRegistry, List<NodeRef> nodeRefList,
            boolean checkPermission)
    {
        NodeService nodeService = serviceRegistry.getNodeService();
        List<ExtDocument> documentlist = new ArrayList<ExtDocument>();
        if (nodeRefList != null && nodeRefList.size() > 0)
        {
            for (NodeRef nodeRef : nodeRefList)
            {
                Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);

            }
        }
        return documentlist;

    }

    /**
     * To get list of folders
     * 
     * @param serviceRegistry
     * @param nodeRefList
     * @param checkPermission
     * @return list of folders
     */
    public static FolderList getFolderList(ServiceRegistry serviceRegistry, List<NodeRef> nodeRefList,
            boolean checkPermission)
    {
        FolderList library = new FolderList();
        List<Folder> list = new ArrayList<Folder>();
        try
        {
            LOGGER.info("nodeRefList : " + nodeRefList);
            if (nodeRefList != null && nodeRefList.size() > 0)
            {
                for (NodeRef nodeRef : nodeRefList)
                {
                    LOGGER.info("nodeRef : " + nodeRef);
                    boolean hasAccess = (String.valueOf(serviceRegistry.getPermissionService().hasPermission(nodeRef,
                        PermissionService.READ)).equals("ALLOWED"));
                    LOGGER.info("hasAccess : " + hasAccess);
                    String loggedUser = getLoggedUser();
                    boolean hasPermission = hasAccess(loggedUser, nodeRef, serviceRegistry);
                    Folder folder = getFolderProperties(serviceRegistry, nodeRef);
                    if (hasPermission)
                    {
                        list.add(folder);
                    }
                }
                library.setFolderList(list);
            }
        }
        catch (InvalidQNameException e)
        {
            e.printStackTrace();
        }
        catch (InvalidNodeRefException e)
        {
            e.printStackTrace();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return library;
    }

    /**
     * To get Folder Object with properites
     * 
     * @param serviceRegistry
     * @param nodeRef
     * @return FolderVO
     */
    public static Folder getFolderProperties(ServiceRegistry serviceRegistry, NodeRef nodeRef)
    {
        Folder folder = new Folder();
        NodeService nodeService = serviceRegistry.getNodeService();
        Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);
        folder.setName(ISO9075.decode((String) getProperty(nodeProp, ContentModel.PROP_NAME)));
        folder.setNodeId(nodeRef.toString());
        folder.setTitle(ISO9075.decode((String) getProperty(nodeProp, ContentModel.PROP_TITLE)));
        folder.setDescription(ISO9075.decode((String) getProperty(nodeProp, ContentModel.PROP_DESCRIPTION)));
        folder.setOwner((String) getProperty(nodeProp, ContentModel.PROP_CREATOR));
        folder.setCreationdate(getGMTDateFormat((Date)getProperty(nodeProp,ContentModel.PROP_CREATED)));
		folder.setModifieddate(getGMTDateFormat((Date)getProperty(nodeProp,ContentModel.PROP_MODIFIED)));
		folder.setType(ExternalSharingConstants.FOLDER);
        Path path = nodeService.getPath(nodeRef);
        String filePath = "";
        if (path != null)
        {
            filePath = path.toString();
            filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/application/1.0\\}", "");
            filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "");
            filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}", "");
        }
        folder.setRelativePath(ISO9075.decode(filePath));
        return folder;
    }
 
    public static ExtDocument getDocumentProperties(ServiceRegistry serviceRegistry, NodeRef nodeRef)
    {
        ExtDocument extDocs = new ExtDocument();
        NodeService nodeService = serviceRegistry.getNodeService();
        Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);
        extDocs.setName(ISO9075.decode((String) nodeProp.get(ContentModel.PROP_NAME)));
        String Name = ISO9075.decode((String) nodeProp.get(ContentModel.PROP_NAME));
        extDocs.setNodeId(nodeRef.toString());
        extDocs.setTitle(ISO9075.decode((String) nodeProp.get(ContentModel.PROP_TITLE)));
        extDocs.setDescription(ISO9075.decode((String) nodeProp.get(ContentModel.PROP_DESCRIPTION)));
        extDocs.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
        extDocs.setCreationdate(getGMTDateFormat((Date)nodeProp.get(ContentModel.PROP_CREATED)));
        LOGGER.info("MIME TYPE : "
                + ((ContentData) nodeService.getProperty(nodeRef, ContentModel.PROP_CONTENT)).getMimetype());
        extDocs.setMimetype(((ContentData) nodeService.getProperty(nodeRef, ContentModel.PROP_CONTENT)).getMimetype());
        String strVersion = (String) nodeProp.get(ContentModel.PROP_VERSION_LABEL);
        double version = Double.parseDouble((strVersion != null ? strVersion : "1.0"));
        LOGGER.info("version : " + version);
        extDocs.setVersion(version);
        long size = ((ContentData) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_CONTENT))
                .getSize();
        extDocs.setSize((int) (size));
        String lockType = (String) nodeProp.get(ContentModel.PROP_LOCK_TYPE);
        QName EXT_POLICY_DETAILS_ASPECT = QName.createQName("http://www.cisco.com/model/content/1.0", "security");
        LOGGER.info("Locktype:" + lockType);
        LOGGER.info("modifieddate:" + nodeProp.get(ContentModel.PROP_MODIFIED));
        LOGGER.info("modifier:" + nodeProp.get(ContentModel.PROP_MODIFIER));
        LOGGER.info("security:" + nodeProp.get(EXT_POLICY_DETAILS_ASPECT));
        extDocs.setLocked(lockType != null ? true : false);
        LOGGER.info("From Model:" + extDocs.isLocked());
        extDocs.setModifieddate(getGMTDateFormat((Date)nodeProp.get(ContentModel.PROP_MODIFIED)));
        extDocs.setSecurity((String) nodeProp.get(EXT_POLICY_DETAILS_ASPECT));
        extDocs.setModifier((String) nodeProp.get(ContentModel.PROP_MODIFIER));
        extDocs.setType(Name.substring(Name.lastIndexOf(".") + 1, Name.length()));
        LOGGER.info("Type:" + Name.substring(Name.lastIndexOf(".") + 1, Name.length()));
        extDocs.setShareUrl((String) nodeProp.get(ContentModel.PROP_NODE_UUID));
        return extDocs;
    }

    /**
     * To get property value of given property of a node
     * 
     * @param nodeProp
     * @param qName
     * @return
     */
    private static Serializable getProperty(Map<QName, Serializable> nodeProp, QName qName)
    {
        Serializable property = nodeProp.get(qName);
        return property;
    }

    /**
     * To check the user have "USER" permission on the node
     * 
     * @param currentUser
     * @param nodeRef
     * @param serviceRegistry
     * @return
     */
    public static boolean hasAccess(final String currentUser, NodeRef nodeRef, final ServiceRegistry serviceRegistry)
    {
    	boolean currentUserHasGroupMember = false;
        if (currentUser.equals(ExternalSharingConstants.USER_ADMIN))
        {
            return true;
        }
        Set<AccessPermission> userSet = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
        LOGGER.info("UserSet:" + userSet.toString());
        LOGGER.info("UserSet size:" + userSet.size());
        if (userSet.size() > 0)
        {
            for (AccessPermission accessPermission : userSet)
            {
                final String userIdOrGroupId = accessPermission.getAuthority();
                LOGGER.info("user : " + userIdOrGroupId);
                //LOGGER.info("accessPermission.getPermission : " + accessPermission.getPermission());
                //LOGGER.info("accessPermission.getAuthorityType : " + accessPermission.getAuthorityType());
                //check user is member of group that group has permissions on folder
                if(userIdOrGroupId.contains(GROUP_IDENTITY)){
                	if (accessPermission.getPermission() != null
    						&& accessPermission.getPermission().equals("SiteAdmin")
    						|| accessPermission.getPermission().equals("SiteEditor")
    						|| accessPermission.getPermission().equals("SiteReader")
    						|| accessPermission.getPermission().equals("SiteOwner")
    						|| accessPermission.getPermission().equals("SiteManager")
    						|| accessPermission.getPermission().equals("ReadPermissions")
    						|| accessPermission.getPermission().equals("SiteViewer")) {
                		 LOGGER.info("inside if authority permissions------" +accessPermission.getPermission());
    				} else{
                	LOGGER.info("groupId : " + userIdOrGroupId);
                	currentUserHasGroupMember = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
       				  @Override
       				  public Boolean doWork() throws Exception {
       					boolean currentUserIsGroupMember=false;
   					  if(userIdOrGroupId!= null && !userIdOrGroupId.equalsIgnoreCase(GROUP_EVERYONE)){
   						  currentUserIsGroupMember=serviceRegistry.getAuthorityService().getAuthoritiesForUser(currentUser).contains(userIdOrGroupId);
   					  }
   					  	  return currentUserIsGroupMember;
       				  	}
       				  }, "admin");
                	 LOGGER.info("currentUserHasGroupMember of accessPermission.getAuthorityType : " + currentUserHasGroupMember);
                }
                }
                if (userIdOrGroupId.equals(currentUser) || currentUserHasGroupMember)
                {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * To get loggedUser
     * 
     * @return string user name
     */
    public static String getLoggedUser()
    {
        String currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
        LOGGER.info("current user : " + currentUser);
        return currentUser;
    }
    
    public static Set<AccessPermission> getAllNodeRefPermissions(final ServiceRegistry serviceRegistry, final NodeRef nodeRef){
    	final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
	   	 AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				@Override
				public Object doWork() throws Exception {
					accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef));
					return null;
				}
	   	 }, "admin");
    	return accessPermission;
    }

    /**
     * To get loggedUser Permission Role
     */
    @SuppressWarnings("unused")
	public static String getUserRole(ServiceRegistry serviceRegistry, String currentUser, NodeRef nodeRef)
    {
        String userRole = "";
        Set<AccessPermission> userSet = getAllNodeRefPermissions(serviceRegistry, nodeRef);
        LOGGER.info("userSet : " + userSet);
        if (userSet.size() > 0)
        {
        	int currentRoleIndex=0;
        	int tempRoleIndex=0;
        	String tempUserRole="";
            for (AccessPermission accessPermission : userSet)
            {  
            	if (accessPermission.getAuthorityType() == AuthorityType.USER)
            	{
                String user = accessPermission.getAuthority();
                LOGGER.info("user : " + user);
                //LOGGER.info("accessPermission.getPermission : " + accessPermission.getPermission());
                //LOGGER.info("accessPermission.getAuthorityType : " + accessPermission.getAuthorityType());
                String authorityType=accessPermission.getAuthorityType().toString();
                if (user.equals(currentUser))
                {
                    String role = accessPermission.getPermission();
                    userRole = role.split("Role")[0];
                    LOGGER.info((new StringBuilder("userRole: ")).append(userRole).toString());
                    if(ExternalSharingConstants.UsersRoleHerarcy.containsKey(userRole))
                    {
                    	LOGGER.info("...............contains user role.........");
                    	tempRoleIndex =  ExternalSharingConstants.UsersRoleHerarcy.get(userRole).intValue();
                    	LOGGER.info((new StringBuilder("tempRoleIndex: ")).append(tempRoleIndex).toString());
                    
                    } else {
	                    tempRoleIndex = -1;
	                    LOGGER.info((new StringBuilder("tempRoleIndex: ")).append(tempRoleIndex).toString());
                    }
                    if (tempRoleIndex >currentRoleIndex)
                    {
                    tempUserRole = userRole;
                    currentRoleIndex = tempRoleIndex;
                    }
 
                }
            }
            }
            String groupMemberRole=getGroupMemberUserRole(serviceRegistry, currentUser, nodeRef);
            if(groupMemberRole!=null && groupMemberRole!=""){
            	 int currentGroupOrUserRoleIndex=0;
             	int tempGroupOrUserRoleIndex=0;
             	String tempGroupOrUserRole="";
             	List<String> userOrGroupIdRole=new ArrayList<String>();
             	userOrGroupIdRole.add(userRole);
             	userOrGroupIdRole.add(groupMemberRole);
             	for (String permissionRole : userOrGroupIdRole) {
             	 if(ExternalSharingConstants.UsersRoleHerarcy.containsKey(permissionRole))
                 {
             		LOGGER.info(" :: Has group role ::");
                 	tempGroupOrUserRoleIndex =  ExternalSharingConstants.UsersRoleHerarcy.get(permissionRole).intValue();
                 
                 } else {
                	 tempGroupOrUserRoleIndex = -1;
	                    LOGGER.info((new StringBuilder("tempRoleIndex: ")).append(tempGroupOrUserRoleIndex).toString());
                 }
                 if (tempGroupOrUserRoleIndex >currentGroupOrUserRoleIndex)
                 {
                	 tempGroupOrUserRole = permissionRole;
                 currentGroupOrUserRoleIndex = tempGroupOrUserRoleIndex;
                 }
             	}
             	userRole = tempGroupOrUserRole;
            }else{
            	userRole = tempUserRole;
            }
            if(userRole.equalsIgnoreCase("Admin"))
            {
            	userRole = UserRoleConstants.USER_ADMIN_ROLE;
            }
        }
        return userRole;
    }

    /**
     * To get GroupMember of loggedUser Permission Role
     */
    public static String getGroupMemberUserRole(final ServiceRegistry serviceRegistry, final String currentUser, NodeRef nodeRef)
    {
        String userInGroupRole = "";
        boolean userIsInGroup = false;
        Set<AccessPermission> userSet = getAllNodeRefPermissions(serviceRegistry, nodeRef);
        LOGGER.info("userSet : " + userSet);
        if (userSet.size() > 0)
        {
        	int currentRoleIndex=0;
        	int tempRoleIndex=0;
        	String tempUserRole="";
            for (AccessPermission accessPermission : userSet)
            {  
            	if (accessPermission.getAuthorityType() == AuthorityType.GROUP)
            	{
                 	if (accessPermission.getPermission() != null
     						&& accessPermission.getPermission().equals("SiteAdmin")
     						|| accessPermission.getPermission().equals("SiteEditor")
     						|| accessPermission.getPermission().equals("SiteReader")
     						|| accessPermission.getPermission().equals("SiteOwner")
     						|| accessPermission.getPermission().equals("SiteManager")
     						|| accessPermission.getPermission().equals("ReadPermissions")
     						|| accessPermission.getPermission().equals("SiteViewer")) {
                 		 LOGGER.info("Inside if ootb authority permissions :::: " +accessPermission.getPermission());
     				} else{
     					final String groupId = accessPermission.getAuthority();
            	userIsInGroup = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
     				  @Override
     				  public Boolean doWork() throws Exception {
     					 boolean currentUserIsGroupMember=false;
    					  if(groupId!= null && !groupId.equalsIgnoreCase(GROUP_EVERYONE)){
    					currentUserIsGroupMember=serviceRegistry.getAuthorityService().getAuthoritiesForUser(currentUser).contains(groupId);
    					  }
    					 return currentUserIsGroupMember;
    				  	}
     				  }, "admin");
            	if(userIsInGroup){
                    String role = accessPermission.getPermission();
                    userInGroupRole = role.split("Role")[0];
                    LOGGER.info((new StringBuilder("userRole: ")).append(userInGroupRole).toString());
                    if(ExternalSharingConstants.UsersRoleHerarcy.containsKey(userInGroupRole))
                    {
                    	tempRoleIndex =  ExternalSharingConstants.UsersRoleHerarcy.get(userInGroupRole).intValue();
                    	LOGGER.info((new StringBuilder("tempRoleIndex: ")).append(tempRoleIndex).toString());
                    } else {
	                    tempRoleIndex = -1;
	                    LOGGER.info((new StringBuilder("tempRoleIndex: ")).append(tempRoleIndex).toString());
                    }
                    if (tempRoleIndex >currentRoleIndex)
                    {
                    tempUserRole = userInGroupRole;
                    currentRoleIndex = tempRoleIndex;
                    }
            	}
                }
            }
            }
            userInGroupRole = tempUserRole;
        }
        return userInGroupRole;
    }
    public static String getFromCurrentDate()
    {
        Calendar c = Calendar.getInstance();
        StringBuffer currentDate = new StringBuffer();
        currentDate.append(c.get(Calendar.YEAR));
        currentDate.append("-");
        currentDate.append(c.get(Calendar.MONTH) + 1);
        currentDate.append("-");
        currentDate.append(c.get(Calendar.DATE));
        return currentDate.toString();
    }

    public static String getToDate(int daysToSubtract)
    {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -daysToSubtract);
        StringBuffer toDate = new StringBuffer();
        toDate.append(c.get(Calendar.YEAR));
        toDate.append("-");
        toDate.append(c.get(Calendar.MONTH) + 1);
        toDate.append("-");
        toDate.append(c.get(Calendar.DATE));

        return toDate.toString();
    }

    public static String getGMTDateFormat(Date date){
		DateFormat df;
		String formatedDate="";
		try{
		df = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
		df.setTimeZone(TimeZone.getTimeZone("GMT"));
		if(date != null){
			formatedDate=df.format(date);
			}
			}catch(Exception e){
				LOGGER.error("Exception....."+e);
			}
		return formatedDate;
	}
    
    /*venkata changes Started*/
    public static boolean canUserCancelWorkflow(ServiceRegistry serviceRegistry, NodeRef nodeRef){
    	String instanceId = null;
        boolean isUserIsInitiator = false;
        boolean canUserHavePermission = false;
        boolean canUserHaveInprogressWorkflowTask = false;
        boolean canUserCancelWorkflow =false;
        List<WorkflowInstance> workflows = new ArrayList<WorkflowInstance>();
        // Get all Active Workflows
        workflows.addAll(serviceRegistry.getWorkflowService().getWorkflowsForContent(nodeRef, true));
        if (workflows != null && workflows.size() > 0){
        	for (WorkflowInstance wi : workflows){
        		instanceId = wi.getId();
        		  //nathammi changes Started
        		  WorkflowTaskQuery tasksQuery = new WorkflowTaskQuery();
                  tasksQuery.setTaskState(null);
                  tasksQuery.setActive(null);
                  tasksQuery.setProcessId(wi.getId());
                  List<WorkflowTask> tasks = serviceRegistry.getWorkflowService().queryTasks(tasksQuery, false);
                  for (WorkflowTask taskObject : tasks)
                  {
                	  String taskStatus = taskObject.getState().toString();
                	  if(taskStatus.equals(TASK_IN_PROGRESS)&&!taskObject.getId().equals(serviceRegistry.getWorkflowService().getStartTask(wi.getId()).getId())){
                		  canUserHaveInprogressWorkflowTask=true;
                	  }
                  }
        	}
        	 if(instanceId != null){
             	isUserIsInitiator = isUserIsInitiator(instanceId, serviceRegistry);
             }
        }
        canUserHavePermission = canUserHavePermission(nodeRef, serviceRegistry);
        if(isUserIsInitiator || (canUserHavePermission && canUserHaveInprogressWorkflowTask)){
        	canUserCancelWorkflow = true;
        }
        LOGGER.info("isUserIsInitiator : " + isUserIsInitiator + " ,canUserHavePermission : " + canUserHavePermission +" ,canUserHaveInprogressWorkflowTask : " + canUserHaveInprogressWorkflowTask+ " ,canUserCancelWorkflow : " + canUserCancelWorkflow);
    	return canUserCancelWorkflow;
    }
    
    
    public static boolean isUserIsInitiator(String instanceId, ServiceRegistry serviceRegistry)
    {
        boolean canCancel = false;
        LOGGER.info("Condition Check for User is Admin or Workflow initiator :");
        // get the initiator
        WorkflowInstance wi = serviceRegistry.getWorkflowService().getWorkflowById(instanceId);
        LOGGER.info("WorkflowInstance Ids are :" + wi);

        String currentUserName = serviceRegistry.getAuthenticationService().getCurrentUserName();
        LOGGER.info("Current login UserName : " + currentUserName);
        // Admin can always cancel workflows, regardless of the initiator
        if (serviceRegistry.getAuthorityService().isAdminAuthority(currentUserName))
        {
            canCancel = true;
        }
        else
        {
            NodeRef initiator = wi.getInitiator();
            // determine if the current user is the initiator of the workflow
            if (initiator != null)
            {
                // get the username of the initiator
                String userName = (String) serviceRegistry.getNodeService().getProperty(initiator, ContentModel.PROP_USERNAME);
                LOGGER.info("Username of the Initiator : " + userName);
                // if the current user started the workflow allow the cancel
                // action
                if (currentUserName.equals(userName))
                {
                    canCancel = true;
                }
            }
        }
        return canCancel;
    }
    
    public static String getFolderVeraProtectionStatus(final NodeRef docNodeRef, final ServiceRegistry serviceRegistry){
    	return AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<String>() {
        	@Override
        	public String doWork() throws Exception {
        		NodeRef folderId = serviceRegistry.getNodeService().getPrimaryParent(docNodeRef).getParentRef();
        		return (String) serviceRegistry.getNodeService().getProperty(folderId, ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
        	}
        }, "admin");
    }

	public static boolean canUserHavePermission(NodeRef node, ServiceRegistry serviceRegistry) {
		boolean canPermission = false;
		LOGGER.info("Condition Check for User is folderAdmin :");
		ChildAssociationRef childAssociationRef = serviceRegistry.getNodeService().getPrimaryParent(node);
		NodeRef parentNoderef = childAssociationRef.getParentRef();
		LOGGER.info("Parent nodeRef of document is :" + parentNoderef);
		Set<AccessPermission> accessPermissions = getAllNodeRefPermissions(serviceRegistry, parentNoderef);
		LOGGER.info("accessPermissions : " + accessPermissions);
		
		Iterator<AccessPermission> fIterator = accessPermissions.iterator();

		String currentUserName = serviceRegistry.getAuthenticationService().getCurrentUserName();
		LOGGER.info("Current login UserName : " + currentUserName);
		// AdminRole
		while (fIterator.hasNext()) {
			AccessPermission accessPermission = (AccessPermission) fIterator.next();

			if (accessPermission.getAuthorityType() == AuthorityType.USER) {
				LOGGER.info("Authority(User): "	+ accessPermission.getAuthority() + " Permission:  "+ accessPermission.getPermission());

				String autherityUserName = accessPermission.getAuthority();
				String autherityUserPermission = accessPermission.getPermission();
				if (autherityUserName.equals(currentUserName)&& autherityUserPermission.equals("AdminRole")) {

					LOGGER.info("Condition Authority(User): "+ accessPermission.getAuthority()+ " Permission:  "+ accessPermission.getPermission());
					canPermission = true;

				}
			}
		}

		return canPermission;
	}
    
	/**
   	 * This method checks user permissions for folder preferences entries
   	 *  
   	 */
	 public static boolean canUserHavePermissionOnParentFolder(String nodeId, ServiceRegistry serviceRegistry,String usersId) {
			boolean canUserAccessOnParent = true;
			canUserAccessOnParent=AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
					@Override
					public Boolean doWork() throws Exception {
						boolean canUserAccessOnParent = true;
			NodeRef node=new NodeRef(nodeId);
			LOGGER.info("Condition Check for User has access on parent folder while adding preferences :");
			ChildAssociationRef childAssociationRef = serviceRegistry.getNodeService().getPrimaryParent(node);
			NodeRef parentNoderef = childAssociationRef.getParentRef();
			LOGGER.info("Parent nodeRef of document is :" + parentNoderef);
			Set<AccessPermission> accessPermissions = getAllNodeRefPermissions(serviceRegistry, parentNoderef);
			LOGGER.info("accessPermissions : " + accessPermissions);
			Iterator<AccessPermission> fIterator = accessPermissions.iterator();
			while (fIterator.hasNext()) {
				AccessPermission accessPermission = (AccessPermission) fIterator.next();

				if (accessPermission.getAuthorityType() == AuthorityType.USER) {
					LOGGER.info("Authority(User): "	+ accessPermission.getAuthority() + " Permission:  "+ accessPermission.getPermission());
					String autherityUserName = accessPermission.getAuthority();
					if (autherityUserName.equals(usersId)) {
						LOGGER.info("Condition Authority(User): "+ accessPermission.getAuthority()+ " Permission:  "+ accessPermission.getPermission());
						canUserAccessOnParent = false;
					}
				}
				if(accessPermission.getAuthorityType() == AuthorityType.GROUP) {
					String autherityGroupName = accessPermission.getAuthority();
					if (serviceRegistry.getAuthorityService().getAuthoritiesForUser(usersId).contains(autherityGroupName)) {
						LOGGER.info("Condition Authority(Group): "+ accessPermission.getAuthority()+ " Permission:  "+ accessPermission.getPermission());
						canUserAccessOnParent = false;
					}
					  
	            }
			}
			return canUserAccessOnParent;
					}
		   	 }, "admin");
			return canUserAccessOnParent;
		}
	 
	 	/**
	   	 * This method checks if folder contains any published DC folders
	   	 *  
	   	 */
	 public static boolean hasContainsPublishedFolder(NodeRef nodeRefId,ServiceRegistry serviceRegistry,String currentUserName){ 
			
			boolean hasPublishedFolder=false;
			hasPublishedFolder=AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
				@Override
				public Boolean doWork() throws Exception {
					boolean hasPublishedFolder = false;
					int skipCount = 0;
			 Path path = serviceRegistry.getNodeService().getPath(nodeRefId);
		     String queryPath = "";
		     if (queryPath != null)
		     {
		    	    queryPath = path.toString();
		            queryPath = queryPath.replaceAll("\\{http://www.alfresco.org/model/application/1.0\\}", "app:");
		            queryPath = queryPath.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "st:");
		            queryPath = queryPath.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}", "cm:");
		     }
		     LOGGER.info("filePath--------------- " + queryPath); 
			 String folderQuery ="PATH:\""+queryPath+"//*\" AND TYPE:\"cm:folder\" AND ASPECT:\"ext:extShareableAspect\"";
			 LOGGER.info("query :::::::::: " +folderQuery);
			while(true)
			{
				SearchParameters sp = new SearchParameters();
				sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
				sp.setLanguage(SearchService.LANGUAGE_LUCENE);
				sp.setMaxItems(500);
				sp.setSkipCount(skipCount);
				sp.setQuery(folderQuery);
				ResultSet results = serviceRegistry.getSearchService().query(sp);
				if (null == results || results.length() <= 0) {
					hasPublishedFolder=false;
				}
				if (results!=null && results.length() > 0) {
					hasPublishedFolder=true;
					break;
				}
				results.close();
				if(skipCount == MAX_VALUE) {
					hasPublishedFolder=false;
					break;
				}
				skipCount += MAX_SKIP_VALUE;
			}
			return hasPublishedFolder;
				}
			}, "admin");
		return hasPublishedFolder;
		}
	
	 /**
		 * 
		 * @param currentUser
		 * @return
		 */
		public static String updateUserPreferenceFolderList(final ServiceRegistry serviceRegistry,final PreferenceService preferenceService, final String folderNodeRef,final String currentUser)
		{
			if (LOGGER.isDebugEnabled())
			{
				LOGGER.debug("getPreferenceFolderList method");
			}
			String statusMessage = null;
			try
			{
				final String preferenceFilter = "org.alfresco.share.folders.favourites";
				final Map<String, Serializable> currentPreferencesFolder = preferenceService.getPreferences(currentUser,
						preferenceFilter);

				if (LOGGER.isDebugEnabled())
				{
					LOGGER.debug("PreferenceFolderList : " + currentPreferencesFolder);
				}

				if (currentPreferencesFolder.containsKey(preferenceFilter))
				{
					statusMessage=AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<String>()
						{
							@Override
							public String doWork() throws Exception
							{
								String innerStatus = "update preferences for user initiated";
								List<String> userPreferencesFoldersList = new ArrayList<String>();
								List<String> list = new ArrayList<String>();
								 Set<String> userPreferencesFoldersSet = new HashSet<String>();
								 Map<String, Serializable> updatedPreferences = null;
								String item = (String) currentPreferencesFolder.get(preferenceFilter);

								if (item.indexOf(",") != -1 && item.indexOf(",") < 2)
								{
									item = item.substring(1);
								}
								String[] itemArray = item.trim().split(",");
								LOGGER.info("Before filter check prefFolderList size: " + itemArray.length);
								
								if(itemArray.length > 0){
									Collections.addAll(list, itemArray);
								}
								if(list.size()>0) {
									userPreferencesFoldersSet.addAll(list);
								}
								if(!userPreferencesFoldersSet.isEmpty()) {
								 for (String folderId : userPreferencesFoldersSet){
										 userPreferencesFoldersList.add(folderId);
							        }
								}
								if(userPreferencesFoldersList.contains(folderNodeRef)) {
								userPreferencesFoldersList.remove(folderNodeRef);
								LOGGER.info("Removed child folder from library section "+folderNodeRef);
								List<String> userPreferencesChildFoldersList =getChildsForPreferenceFolderList(serviceRegistry,folderNodeRef,currentUser);
								LOGGER.info("userPreferencesChildFoldersList library section size "+userPreferencesChildFoldersList.size()); 
								if(userPreferencesChildFoldersList!=null && userPreferencesChildFoldersList.size()>0) {
									 userPreferencesFoldersList.addAll(userPreferencesChildFoldersList);
								}
								}else {
									LOGGER.info("Add child folders to library section if removed folder does not pesent in user preferences  "+folderNodeRef);
									List<String> userPreferencesChildFoldersList =getChildsForPreferenceFolderList(serviceRegistry,folderNodeRef,currentUser);
									LOGGER.info("userPreferencesChildFoldersList library section size "+userPreferencesChildFoldersList.size()); 
									if(userPreferencesChildFoldersList!=null && userPreferencesChildFoldersList.size()>0) {
										 userPreferencesFoldersList.addAll(userPreferencesChildFoldersList);
									}
								}
								LOGGER.info("After filter check prefFolderList size: " + userPreferencesFoldersList.size());
								updatedPreferences=new HashMap<String, Serializable>();
								updatedPreferences.put(preferenceFilter, StringUtils.join(userPreferencesFoldersList, ","));
								preferenceService.setPreferences(currentUser, updatedPreferences);
								innerStatus="User preferences are updated succesfully";
								return innerStatus;
									}
								}, "admin");
				}
			}
			catch (Exception e)
			{
				LOGGER.error("Exception in updateUserPreferenceFolderList : ", e);
			}
			return statusMessage;
		}
		
		 /**
		 * @param serviceRegistry
		 * @param folderNodeRef
		 * @param currentUser
		 * @return
		 */
		public static List<String> getChildsForPreferenceFolderList(final ServiceRegistry serviceRegistry, final String folderNodeRef,final String currentUser)
		{
			List<String> userPreferencesFoldersList = new ArrayList<String>();
			userPreferencesFoldersList=AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<List<String>>() {
	        	@Override
	        	public List<String> doWork() throws Exception {
	        		List<String> foldersList = new ArrayList<String>();
	        		NodeRef node=new NodeRef(folderNodeRef);
						List<FileInfo> deepTargetFolderNodeRefs = serviceRegistry.getFileFolderService().listFolders(node);
						// LOGGER.info("deepTargetFolderNodeRefs------------"+deepTargetFolderNodeRefs);
						if(deepTargetFolderNodeRefs.size() > 0){
						       for (FileInfo childAssoc : deepTargetFolderNodeRefs) {
						    	 final NodeRef  childNodeRef = childAssoc.getNodeRef();
						    	// LOGGER.info("childNodeRef---------"+childNodeRef);
						    		if(hasAccess(currentUser, childNodeRef, serviceRegistry)){
						    			LOGGER.info("child folder exists :::: "+childNodeRef.toString());
						    			foldersList.add(childNodeRef.toString());
				            		} 
						       }
						}
						return foldersList;
				}
			}, "admin");
			return userPreferencesFoldersList;
		}
		
		 /**
		 * check weather user is member of group
		 * @param serviceRegistry
		 * @param NodeRefId
		 * @param currentUser
		 * @return
		 */
		public static boolean isMemberofGroup(ServiceRegistry serviceRegistry,String currentUserName,String groupId) {
			boolean isUserExistinGroup = false;
			try {
				AuthenticationUtil.setFullyAuthenticatedUser(currentUserName);
				Set<String> userAuthorities = serviceRegistry.getAuthorityService().getAuthorities();
				if(groupId != null && userAuthorities.contains(groupId)) {
					isUserExistinGroup = true;
				}
			}catch(Exception ex)
			{
				LOGGER.error("Exception while checking the support group user", ex);
			}
			return isUserExistinGroup;
		}
}
