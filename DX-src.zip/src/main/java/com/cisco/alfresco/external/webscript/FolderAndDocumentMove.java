package com.cisco.alfresco.external.webscript;

import static com.cisco.sd.rest.service.MigrationConstants.EMPTY_STRING;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileExistsException;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.sd.rest.service.MigrationConstants;

public class FolderAndDocumentMove extends DeclarativeWebScript
{

	private static final Logger LOG = Logger.getLogger(FolderAndDocumentMove.class);
	
	private ServiceRegistry serviceRegistry;
	private BehaviourFilter policyFilter;
	private String loggedInUser = null;
	private static final String GROUP_IDENTITY ="GROUP_";
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public BehaviourFilter getPolicyFilter() {
		return policyFilter;
	}

	public void setPolicyFilter(BehaviourFilter policyFilter) {
		this.policyFilter = policyFilter;
	}

	public Map<String, Object> executeImpl(WebScriptRequest req, Status status,	Cache cache) {
		LOG.info("FolderOrDocMoveWebScript executeImpl method started::  ");
		final Map<String, Object> result = new HashMap<String, Object>();
		NodeRef targetNodeRef = null;
		String targetFolderDomainProperty = null;
		try{

			if(req.getParameter("jsondata") != null){
				JSONParser jsonParser = new JSONParser();
				org.json.simple.JSONObject jsonObject = null;
				jsonObject = (JSONObject) jsonParser.parse(req.getParameter("jsondata"));

				LOG.info("Json Object is : " + jsonObject);

				if(!jsonObject.containsKey("sourceLocquery")){
					status.setMessage("sourceLocquery is not found in the input json object");
					status.setCode(522);
					result.put("overallSuccess", "false");
				} /*else if(!jsonObject.containsKey("targetLocquery")){
					status.setMessage("targetLocquery is not found in the input json object");
					status.setCode(523);
					result.put("overallSuccess", "false");
				}*/ else if(!jsonObject.containsKey("loggedInUser")){
					status.setMessage("loggedInUser is not found in the input json object");
					status.setCode(524);
					result.put("overallSuccess", "false");
				} else if(!jsonObject.containsKey("targetFolderPath")){
					status.setMessage("targetFolderPath is not found in the input json object");
					status.setCode(525);
					result.put("overallSuccess", "false");
				}  else if(!jsonObject.containsKey("inhiritParentPermissions")){
					status.setMessage("inhiritParentPermissions is not found in the input json object");
					status.setCode(526);
					result.put("overallSuccess", "false");
				}  else if(!jsonObject.containsKey("folderAdminRoles")){
					status.setMessage("folderAdminRoles is not found in the input json object");
					status.setCode(526);
					result.put("overallSuccess", "false");
				}  else if(!jsonObject.containsKey("inheritDomain")){
					status.setMessage("inheritDomain is not found in the input json object");
					status.setCode(526);
					result.put("overallSuccess", "false");
				}  else if(!jsonObject.containsKey("targetFolderDomain")){
					status.setMessage("targetFolderDomain is not found in the input json object");
					status.setCode(526);
					result.put("overallSuccess", "false");
				}  else {
					String sourceFolderAndDocPathDetails = (String) jsonObject.get("sourceLocquery");
					//String targetLocquery = (String) jsonObject.get("targetLocquery");
					loggedInUser = (String) jsonObject.get("loggedInUser");
					String targetFolderPath = (String) jsonObject.get("targetFolderPath");
					String inhiritParentPermissions = (String) jsonObject.get("inhiritParentPermissions");
					String targetFolderAdminRoles = (String) jsonObject.get("folderAdminRoles");
					String inheritDomain = (String) jsonObject.get("inheritDomain");
					String targetFolderDomain = (String) jsonObject.get("targetFolderDomain");

					LOG.info("Request parameters are : sourceLocquery : " + targetFolderAdminRoles + " :: " + sourceFolderAndDocPathDetails + " loggedInUser : " + loggedInUser + " targetFolderPath : " + targetFolderPath);
					List<HashMap<String, String>> docsList = new ArrayList<HashMap<String, String>>();
					
					/**
					 * First check for targetNodeRef location in doc exchange.
					 * if not found, then create target folder structure and move the files or folders
					 * else simply move source folder to existing target folder location.
					 */
					List<String> folderCreationParams =  findTargetFolder(targetFolderPath);
					if(folderCreationParams.size() == 1){
						targetNodeRef = new NodeRef(folderCreationParams.get(0));
						//Getting target folder domain values
						targetFolderDomainProperty = (String) serviceRegistry.getNodeService().getProperty(targetNodeRef, MigrationConstants.CISCO_DOMAIN_NAME_PROP);
						//result.put("targetNodeRef", targetNodeRef.toString());
					}
					
					
					result.put("inhiritParentPermissions", inhiritParentPermissions);

					NodeRef sourceNodeRef = null;
					if(!sourceFolderAndDocPathDetails.isEmpty()){
						String[] sourceFolderAndDocPathDetailsArray = sourceFolderAndDocPathDetails.split(",");
						if(sourceFolderAndDocPathDetailsArray != null && sourceFolderAndDocPathDetailsArray.length > 0){
							
							for(int i=0; i<sourceFolderAndDocPathDetailsArray.length;i++){
								String sourceLocquery = sourceFolderAndDocPathDetailsArray[i].trim();
								if(sourceLocquery != null && !sourceLocquery.isEmpty()){
									if(sourceLocquery.contains("workspace://SpacesStore/")){
										NodeRef docNodeRef = new NodeRef(sourceLocquery);
										if(serviceRegistry.getNodeService().exists(docNodeRef)){
											sourceNodeRef = docNodeRef;
										}
									} else {
										//sourceNodeRef = EDCSUtil.doSearch(sourceLocquery, serviceRegistry);
										
										String[] sourceFolderPathSplit = sourceLocquery.split("/");

										//NodeRef existingFolderRef = null;

										NodeRef parentNodeRef = serviceRegistry.getSiteService().getContainer("edcsng", "documentlibrary");
										LOG.info("documentLibraryNodeRef : " + parentNodeRef);

										for (int j = 0; j < sourceFolderPathSplit.length; j++) {

											if (sourceFolderPathSplit[j] != null && !sourceFolderPathSplit[j].trim().equals(EMPTY_STRING)) {
												sourceNodeRef = serviceRegistry.getFileFolderService().searchSimple(parentNodeRef, sourceFolderPathSplit[j]);
												LOG.info("Folder sourceNodeRef : " + sourceNodeRef);
												if(sourceNodeRef == null){
													break;
												} else {
													parentNodeRef = sourceNodeRef;
												}
											}

										}
										
										
									}


									LOG.info("sourceNodeRef : " + sourceNodeRef);

									HashMap<String, String> documentsMap = new HashMap<String, String>();

									if(sourceNodeRef != null){

										String nodeType = serviceRegistry.getNodeService().getType(sourceNodeRef).getLocalName();

										String name = (String) serviceRegistry.getNodeService().getProperty(sourceNodeRef, ContentModel.PROP_NAME);
										
										String folderOrDocPath = getFolderOrDocPath(sourceNodeRef);
										try{
											
											if(!"folder".equals(nodeType)){
												NodeRef sourceParentNodeRef = serviceRegistry.getNodeService().getPrimaryParent(sourceNodeRef).getParentRef();
												String sourceVeraType = (String)serviceRegistry.getNodeService().getProperty(sourceParentNodeRef, ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
												String targetVeraType = null;
												if(targetNodeRef != null){
													targetVeraType = (String)serviceRegistry.getNodeService().getProperty(targetNodeRef, ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
												}
												String docSecurityType = (String)serviceRegistry.getNodeService().getProperty(sourceNodeRef, CiscoModelConstants.CISCO_SECURITY_PROP);
												sourceVeraType = (sourceVeraType!=null)?sourceVeraType:"";
												targetVeraType = (targetVeraType!=null)?targetVeraType:"";
												/**
												 * If source and destination does not have any vera protection, then simply skip the validation check
												 */
												if(!sourceVeraType.isEmpty() || !targetVeraType.isEmpty()){
													if(("All Contents".equals(sourceVeraType) && !"Cisco Restricted".equals(docSecurityType)) && "Cisco Restricted".equals(targetVeraType)){
														throw new FileExistsException(sourceNodeRef,"You can not move any secured documents to non secured folder as target folder is enabled with IRM for only \"Cisco Restricted\" files ");
													} else if(("Cisco Restricted".equals(sourceVeraType) && "Cisco Restricted".equals(docSecurityType) && targetVeraType.isEmpty()) ){
														throw new FileExistsException(sourceNodeRef,"You can not move any secured \"Cisco Restricted\" documents to non secured folder as target folder is not enabled with IRM ");
													} else if("All Contents".equals(sourceVeraType) && targetVeraType.isEmpty()){
														throw new FileExistsException(sourceNodeRef,"You can not move any secured documents to non secured folder as target folder is not enabled with IRM ");
													} 
												}
											}

											if(targetNodeRef != null){
												applyVeraProtectionOnDoc(sourceNodeRef,targetNodeRef);
											}
											
											/**
											 * if Target folder path is not existed then,
											 * Create folder path higherarchy and move the docs
											 * ex:target Folder path: A/B/C/D; if A/B already existed then creat only /C/D path
											 */
											if(targetNodeRef == null){
												NodeRef parentNodeRef = new NodeRef(folderCreationParams.get(0));
												String folderPath = folderCreationParams.get(1);
												targetNodeRef = createFolderPath(parentNodeRef, folderPath, targetFolderAdminRoles, targetFolderDomain);
												targetFolderDomainProperty = (String) serviceRegistry.getNodeService().getProperty(targetNodeRef, MigrationConstants.CISCO_DOMAIN_NAME_PROP);
												//result.put("targetNodeRef", targetNodeRef.toString());
											}

											serviceRegistry.getFileFolderService().move(sourceNodeRef, targetNodeRef, null);
											
											serviceRegistry.getPermissionService().setInheritParentPermissions(sourceNodeRef, Boolean.valueOf(inhiritParentPermissions));
											LOG.info("inhirit parent folder permissions making "+Boolean.valueOf(inhiritParentPermissions)+ " On : " + name + " ; " + folderOrDocPath);
											
											/**
											 * if node type is folder then add target folder domain aspect values
											 */
											if(nodeType.equals("folder") && inheritDomain.equals("true")){
												if (serviceRegistry.getNodeService().hasAspect(sourceNodeRef, MigrationConstants.CISCO_DOMAIN_ASPECT)) {
													String sourceDomainProperty = (String) serviceRegistry.getNodeService().getProperty(sourceNodeRef, MigrationConstants.CISCO_DOMAIN_NAME_PROP);
													if(targetFolderDomainProperty != null && !targetFolderDomainProperty.isEmpty()){
														if(sourceDomainProperty != null && !sourceDomainProperty.isEmpty()){
															String[] targetFolderDomainPropertyArray = targetFolderDomainProperty.split(",");
															StringBuilder sourceDomainPropertyBuilder = new StringBuilder(sourceDomainProperty);
															for(int j=0;j<targetFolderDomainPropertyArray.length;j++){
																if(!sourceDomainPropertyBuilder.toString().contains(targetFolderDomainPropertyArray[j])){
																	LOG.info("domain " + targetFolderDomainPropertyArray[j] + " Not Present on souce directory:");
																	sourceDomainPropertyBuilder.append(","+targetFolderDomainPropertyArray[j]);
																}
															}
															sourceDomainProperty = sourceDomainPropertyBuilder.toString();
															//sourceDomainProperty = sourceDomainProperty + "," + targetFolderDomainProperty;
														} else {
															sourceDomainProperty = targetFolderDomainProperty;
														}
														
														serviceRegistry.getNodeService().setProperty(sourceNodeRef, MigrationConstants.CISCO_DOMAIN_NAME_PROP, sourceDomainProperty);
													}
												} else {
													Map<QName, Serializable> parentDomainValues = new HashMap<QName, Serializable>();
													parentDomainValues.put(MigrationConstants.CISCO_DOMAIN_NAME_PROP, targetFolderDomainProperty);
													serviceRegistry.getNodeService().addAspect(sourceNodeRef, MigrationConstants.CISCO_DOMAIN_ASPECT, parentDomainValues);
												}
											}
											
											setCreatorAndModifierAsLogedInUser(sourceNodeRef);

											documentsMap.put("fileExist", "false");
											documentsMap.put("sourceNodeRef", sourceNodeRef.toString());
											documentsMap.put("success", "true");
											documentsMap.put("type", nodeType);
											documentsMap.put("name", name);
											documentsMap.put("folderOrDocPath", folderOrDocPath);

										} catch(FileExistsException e){
											LOG.error("Statuscode Check.... " + e.getName());
											documentsMap.put("fileExist", "true");
											documentsMap.put("sourceNodeRef", e.getName());
											documentsMap.put("sourceNodeRef", sourceNodeRef.toString());
											documentsMap.put("success", "false");
											documentsMap.put("type", nodeType);
											documentsMap.put("name", name);
											documentsMap.put("folderOrDocPath", folderOrDocPath);

											result.put("overallSuccess", "false");

										} catch(Exception e){
											status.setMessage(e.getMessage());
											status.setCode(status.getCode());
											LOG.error("Checking.... " +status.getCode() + " ;;; "+ e.getStackTrace(),e);
										}
									} else {
										documentsMap.put("fileExist", "false");
										documentsMap.put("sourceNodeRef", "Source Folder or Document is not found in Doc Exchange");
										documentsMap.put("success", "true");
										documentsMap.put("type", "");
										documentsMap.put("name", "");
										documentsMap.put("folderOrDocPath", "");
									}

									docsList.add(documentsMap);
								}

							}
							
							/**
							 * Setting Creator and Modifier as logged in user on newly created folders
							 */
							setCreatorAndModifierAsLogedInUser(targetNodeRef);
							/*policyFilter.disableBehaviour(targetNodeRef, ContentModel.ASPECT_AUDITABLE);
							Map<QName, Serializable> properties = new HashMap<QName, Serializable>();
							properties.put(ContentModel.PROP_MODIFIER, loggedInUser);
							properties.put(ContentModel.PROP_CREATOR, loggedInUser);
							serviceRegistry.getNodeService().addProperties(targetNodeRef, properties);
							LOG.info(" Folder CREATOR1:: "+serviceRegistry.getNodeService().getProperty(targetNodeRef, ContentModel.PROP_CREATOR));*/
							result.put("targetNodeRef", (targetNodeRef !=null)?targetNodeRef.toString():"");
							result.put("docsList", docsList);
						}
					} 
				}

			} else {
				status.setMessage("Request Parameter jsondata is not found in request object");
				status.setCode(521);
				result.put("overallSuccess", "false");
			}

		}catch(Exception e){
			LOG.error(e.getStackTrace(),e);
			if(e.getMessage() != null && !e.getMessage().isEmpty()){
				status.setMessage(e.getMessage());
			} else {
				status.setMessage("Internal Server occured");
			}
			status.setCode(Status.STATUS_INTERNAL_SERVER_ERROR);
			result.put("overallSuccess", "false");
		} /*finally {
			policyFilter.enableBehaviour(targetNodeRef,ContentModel.ASPECT_AUDITABLE);
			LOG.info(" modifyDefaultProperties - finally enabled.");
		}*/
		LOG.info("Final Result in Doc Central is : "+ " ;;; " + status.getCode() + "  ::: " +status.getCodeName() + " ******  " + result.toString());
		return result;
	}
	
	private void applyVeraProtectionOnDoc(NodeRef sourceNodeRef, NodeRef targetNodeRef){
		String veraProtectionType = (String)serviceRegistry.getNodeService().getProperty(targetNodeRef, ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
		if(veraProtectionType != null){
			String docSecurityType = (String)serviceRegistry.getNodeService().getProperty(sourceNodeRef, CiscoModelConstants.CISCO_SECURITY_PROP);
			if(veraProtectionType.equals("All Contents") || (veraProtectionType.equals(docSecurityType))){
				Map<QName, Serializable> verDocumentProtectionProps = new HashMap<>(1);
				verDocumentProtectionProps.put(ExternalSharingConstants.PROP_IS_DOCUMENT_VERA_PROTECTED, true);
				serviceRegistry.getNodeService().addAspect(sourceNodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION, verDocumentProtectionProps);
			} 
		}
	}

	private List<String> findTargetFolder(String targetFolderPath) throws FileExistsException, InvalidNodeRefException, Exception {

		NodeRef targetNodeRef = null;

		/*targetNodeRef = EDCSUtil.doSearch(targetLocquery, serviceRegistry);
		LOG.info("targetNodeRef : " + targetNodeRef);*/

		//if(targetNodeRef == null){

			String[] targetFolderPathSplit = targetFolderPath.split("/");

			///NodeRef existingFolderRef = null;
			List<String> folderCreationParams = new ArrayList<>();
			NodeRef parentNodeRef = serviceRegistry.getSiteService().getContainer("edcsng", "documentlibrary");
			LOG.info("parentNodeRef : " + parentNodeRef);

			for (int j = 0; j < targetFolderPathSplit.length; j++) {

				if (targetFolderPathSplit[j] != null && !targetFolderPathSplit[j].trim().equals(EMPTY_STRING)) {
					targetNodeRef = serviceRegistry.getFileFolderService().searchSimple(parentNodeRef, targetFolderPathSplit[j]);
					targetFolderPath = targetFolderPath.substring(targetFolderPath.indexOf(targetFolderPathSplit[j]), targetFolderPath.length());
					LOG.info("targetNodeRef : " + targetNodeRef + " ;targetFolderPath : " + targetFolderPath);
					if(targetNodeRef == null){
						//targetFolderPath = targetFolderPath.substring(targetFolderPath.indexOf(targetFolderPathSplit[j]), targetFolderPath.length());
						LOG.info("Folder is going to create to this path : " + targetFolderPath + " :: " + parentNodeRef);
						//targetNodeRef = createFolderPath(parentNodeRef, targetFolderPath, targetFolderAdminRoles, targetFolderDomain);
						folderCreationParams.add(parentNodeRef.toString());
						folderCreationParams.add(targetFolderPath);
						break;
					} else {
						parentNodeRef = targetNodeRef;
					}
				}

			}

		//} 
			/*else {
			serviceRegistry.getPermissionService().setInheritParentPermissions(targetNodeRef, Boolean.valueOf(inhiritParentPermissions));
			LOG.info("inhirit parent folder permissions making "+Boolean.valueOf(inhiritParentPermissions)+ " On : " + targetNodeRef);
		}*/
		
		if(targetNodeRef != null){
			folderCreationParams.add(targetNodeRef.toString());
		}
		return folderCreationParams;
	}

	/**
	 * This method will create the folder structure and return the leaf folder nodeRef
	 * 
	 * @param existingNodeRef
	 * @param folderPath
	 * @return nodeRef (leaf folder node ref)
	 * @throws Exception
	 */
	private NodeRef createFolderPath(final NodeRef existingNodeRef, final String folderPath, String targetFolderAdminRoles, String targetFolderDomain) throws FileExistsException, InvalidNodeRefException, Exception {
		String[] folderNames = folderPath.split("/");
		FileInfo fileinfo = null;
		NodeRef parentNodeRef = existingNodeRef;
		for (int i = 0; i < folderNames.length; i++) {
			if (folderNames[i] != null && !folderNames[i].trim().equals(EMPTY_STRING)) {
				String folderName = folderNames[i];
				fileinfo = serviceRegistry.getFileFolderService().create(parentNodeRef, folderName, ContentModel.TYPE_FOLDER);
				parentNodeRef = fileinfo.getNodeRef();
				LOG.info("Folder " + folderName + " :: " + parentNodeRef + " created...");
				try{ 
					
					
					//setting Folder Admin on newly created last leaf folder
	    			if((i+1) == folderNames.length){
	    				LOG.info("about to set the folderadmins on leaf node + " + parentNodeRef);
	    				//serviceRegistry.getPermissionService().setInheritParentPermissions(parentNodeRef, Boolean.valueOf(inhiritParentPermissions));
	    				setAdminsOnNewlyCreatedLeafFolders(targetFolderAdminRoles, parentNodeRef);
	    				addSharableAspectToLastLeafFolder(parentNodeRef);
	    				addDomainAspectToLastLeafFolder(parentNodeRef, targetFolderDomain);
	    			}

					/**
					 * Setting Creator and Modifier as logged in user on newly created folders
					 */
	    			setCreatorAndModifierAsLogedInUser(parentNodeRef);
					/*policyFilter.disableBehaviour(parentNodeRef, ContentModel.ASPECT_AUDITABLE);
					Map<QName, Serializable> properties = new HashMap<QName, Serializable>();
					properties.put(ContentModel.PROP_MODIFIER, loggedInUser);
					properties.put(ContentModel.PROP_CREATOR, loggedInUser);
					serviceRegistry.getNodeService().addProperties(parentNodeRef, properties);
					LOG.info(" Folder CREATOR:: "+serviceRegistry.getNodeService().getProperty(parentNodeRef, ContentModel.PROP_CREATOR));*/
				}
				finally {
					policyFilter.enableBehaviour(parentNodeRef,ContentModel.ASPECT_AUDITABLE);
					LOG.info(" modifyDefaultProperties - finally enabled.");
				}
			}
		}
		LOG.info("leaf Folder Name is : " + parentNodeRef);
		return parentNodeRef;
	}

	private String getFolderOrDocPath(NodeRef nodeRef) throws Exception {

		String path="";

		String name = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NAME);

		String displayPath = serviceRegistry.getNodeService().getPath(nodeRef).toDisplayPath(serviceRegistry.getNodeService(), serviceRegistry.getPermissionService());
		
		LOG.info("Name is : " + name + " displayPath : " + displayPath);

		if (displayPath.contains("/documentLibrary")) {
			if (displayPath.endsWith("/documentLibrary")) {
				path = name;
			}
			else {
				String[] parts = displayPath.split("/documentLibrary");
				path = parts[1] + "/" + name;
			}
		}
		LOG.info("path is : " + path);
		return path;
	}
	
	private void setAdminsOnNewlyCreatedLeafFolders(String folderAdminUsers, final NodeRef leafFolderNodeRef) throws Exception{
		if(folderAdminUsers != null && !folderAdminUsers.isEmpty()){
			boolean isPermInhirited = serviceRegistry.getPermissionService().getInheritParentPermissions(leafFolderNodeRef);
			if(isPermInhirited){
				serviceRegistry.getPermissionService().setInheritParentPermissions(leafFolderNodeRef, false);
			}
			
			String[] folderAdminUsersArray = folderAdminUsers.split(",");
			final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
			AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				@Override
				public Object doWork() throws Exception {
					accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(leafFolderNodeRef));
					return null;
				}
			}, "admin");
			
			if(isPermInhirited){
				serviceRegistry.getPermissionService().setInheritParentPermissions(leafFolderNodeRef, true);
			}
			
			//Checking whether user already  presented on the parent folder or not?
			for(int k=0; k<folderAdminUsersArray.length;k++){
				if(folderAdminUsersArray[k] != null && !(folderAdminUsersArray[k].isEmpty() || folderAdminUsersArray[k].contains(GROUP_IDENTITY))){
					boolean isUserPresentedOnParent = false;
					
					for (AccessPermission accessPermissionObj : accessPermission) {
						if(accessPermissionObj.getAuthority().equals(folderAdminUsersArray[k]) && accessPermissionObj.getPermission().equals(MigrationConstants.PERM_FOLDER_ADMIN_ROLE)){
							isUserPresentedOnParent = true;
							LOG.info("User "+folderAdminUsersArray[k]+ " alread presented. so, not addig on newly created folder : ");
						}
					}
					if(!isUserPresentedOnParent){
						LOG.info("User "+folderAdminUsersArray[k]+" added on folder  : ");
						serviceRegistry.getPermissionService().setPermission(leafFolderNodeRef, folderAdminUsersArray[k], MigrationConstants.PERM_FOLDER_ADMIN_ROLE, true);
					}
				}
			}

		}
	}
	
	private void setCreatorAndModifierAsLogedInUser(NodeRef nodeRef) throws Exception{
		if(nodeRef != null){
			try{
				policyFilter.disableBehaviour(nodeRef, ContentModel.ASPECT_AUDITABLE);
				
				Map<QName, Serializable> properties = new HashMap<QName, Serializable>();
				properties.put(ContentModel.PROP_MODIFIER, loggedInUser);
				properties.put(ContentModel.PROP_CREATOR, loggedInUser);
				serviceRegistry.getNodeService().addProperties(nodeRef, properties);
				LOG.info(" Folder CREATOR:: "+serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_CREATOR));
			}finally {
				policyFilter.enableBehaviour(nodeRef,ContentModel.ASPECT_AUDITABLE);
				LOG.info(" modifyDefaultProperties - finally enabled.");
			}
		}
	}
	
	private void addSharableAspectToLastLeafFolder(NodeRef leafFolderNodeRef) throws Exception{

		Map<QName, Serializable> shareableAspectValues = new HashMap<QName, Serializable>();
		shareableAspectValues.put(MigrationConstants.CISCO_EXTERNAL_IS_EXTERNALLY_SHARED_PROP, true);

		serviceRegistry.getNodeService().addAspect(leafFolderNodeRef, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT, shareableAspectValues);
		LOG.info("Attaching sharable aspect functionality done...");
	}
	
	private void addDomainAspectToLastLeafFolder(NodeRef leafFolderNodeRef, String targetFolderDomain) throws Exception{

		Map<QName, Serializable> domainAspectValues = new HashMap<QName, Serializable>();
		domainAspectValues.put(MigrationConstants.CISCO_DOMAIN_NAME_PROP, targetFolderDomain);

		serviceRegistry.getNodeService().addAspect(leafFolderNodeRef, MigrationConstants.CISCO_DOMAIN_ASPECT, domainAspectValues);
		LOG.info("domain aspect functionality done...");
	}

}
