package com.cisco.alfresco.external.jobs;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.transaction.RetryingTransactionHelper.RetryingTransactionCallback;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.transaction.TransactionService;
import org.apache.log4j.Logger;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.cisco.alfresco.edcsng.util.SearchUtil;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.sd.rest.service.MigrationConstants;


/**
 * 
 * @author murakuma
 * 
 */
public class AddAspectLDAPUser extends QuartzJobBean
{
    Logger logger = Logger.getLogger(AddAspectLDAPUser.class);

    private ServiceRegistry serviceRegistry;
    private String searchQuery;
    private ExternalLDAPUtil ldapUtil;
    private String username =null;
    private  TransactionService transactionService;
    private static final String KEY_IS_JOB_ENABLED = "ciscoUserAccessJobEnabled";
	private boolean isJobEnabled = false;

    /**
     * @param context
     */
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException
    {
		
		logger.info("inside executeInternal:::");
		logger.error("inside executeInternal:::");
        
		    JobDataMap jobData = context.getJobDetail().getJobDataMap();
	        String isJobEnabledStr = (String) jobData.get(KEY_IS_JOB_ENABLED);

	        if (isJobEnabledStr != null)
	        {
	            try
	            {
	            	logger.info("inside try:::");
	            	isJobEnabled=Boolean.parseBoolean(isJobEnabledStr);
	            }
	            catch (Exception e)
	            {
	                logger.error("Invalid '" + KEY_IS_JOB_ENABLED + "' value, using default: " + isJobEnabled, e);
	            }
	        }

	        if (!isJobEnabled)
	        {
	            // skip Job
	            logger.error("Skipping " + KEY_IS_JOB_ENABLED + " to execute.");
	            return;
	        }
        searchUsers();
    }

    /**
     * 
     * @param nodeService
     */
    public void searchUsers()
    {
    	logger.error("inside searchUsers(");
    	AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
        {
            @SuppressWarnings("unused")
            @Override
            public Object doWork() throws Exception
            {
               
                ResultSet results = null;
                NodeRef currentNodeRef = null;
                Map<QName, Serializable> channelProperties = new HashMap<QName, Serializable>();
                SearchService searchService;
                List<NodeRef> searchNodeList = null;
                
                try
                {
                    String ftsQuery = "";
                    ftsQuery = getSearchQuery();
                    searchNodeList = SearchUtil.getNodeRefList(ftsQuery, serviceRegistry);
                    if (searchNodeList != null)
                    {
                        for (NodeRef nodeRef : searchNodeList)
                        {
                        	
                        	addAspect(nodeRef);
                        	
                        }
                    }
                    else
                    {
                        logger.error("No content Node found with the criteria");
                    }
                }
                catch (Exception e)
                {
                    logger.error("Exception....  ::::  : " + e.getMessage());                    
                }
                return null;
            }
        }, "admin");
    }
    
    public void addAspect(final NodeRef node){
		username = (String)serviceRegistry.getNodeService().getProperty(node, ContentModel.PROP_USERNAME);
		logger.error(" USer Name >>>" +username + "   nodeRef>>"+node); 
		String strAccessLevel = ldapUtil.getUserAccessLevelFromLDAP(username);
		if(strAccessLevel ==null){
			logger.error("System not able to find the Access level for the User \"" +username+ "\" from LDAP server. ");
		}
		else if(!username.equalsIgnoreCase("admin"))
		{
			final int accessLevel = Integer.parseInt(strAccessLevel);	
		    logger.error(" Access Level for user :"+username+" is: "+accessLevel);   	  
	        this.transactionService.getRetryingTransactionHelper().doInTransaction(new RetryingTransactionCallback<Void>()
	                {
	                    @Override
	                    public Void execute() throws Throwable
	                    {
	                    	Map<QName, Serializable> extUserProp = null;
	           	       	
	           	    			        extUserProp = new HashMap<QName, Serializable>();
	           	    	            	extUserProp.put(MigrationConstants.CISCO_EXTERNAL_USER_ACCESS_PROP, accessLevel);		           	    	            	
	           	    	            	serviceRegistry.getNodeService().addAspect(node, MigrationConstants.CISCO_EXTERNAL_USER_ASPECT, extUserProp);	           	    	            	
	           	    					logger.error(" Aspect attached successfully on Person :"+username);	           	    			
	           	    			
	                                return null;
	                    }
	                }, false, true); 
			
		
	  }
    }
    
    public TransactionService getTransactionService() {
		return transactionService;
	}

	public void setTransactionService(TransactionService transactionService) {
		this.transactionService = transactionService;
	}

	public ExternalLDAPUtil getLdapUtil() {
		return ldapUtil;
	}

	public void setLdapUtil(ExternalLDAPUtil ldapUtil) {
		this.ldapUtil = ldapUtil;
	}

	public String getSearchQuery()
    {
        return searchQuery;
    }

    public void setSearchQuery(String searchQuery)
    {
        this.searchQuery = searchQuery;
    }

    /**
     * 
     * @param serviceRegistry
     */
    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }
}