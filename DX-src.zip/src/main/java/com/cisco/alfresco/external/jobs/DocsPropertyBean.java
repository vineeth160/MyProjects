package com.cisco.alfresco.external.jobs;

import java.util.Date;
public class DocsPropertyBean {

	private String document = null;
	private String documentName = null;
	private String version = null;
	private String EDCSID = null;
	private String docType = null;
	private String creator	= null;
	private String edate = null;
	private String expiryDate = null;
	Date expdate;
	private String lastUptDate= null;
	private String securityValue = null;
	private String fileEditURL = null;
	private String lastAccessed = null;
	private String filePath = null;
	private String publisher = null;
    private String publishedDate = null;
    private String externalUsers = null;
    private String EDCSNGPath = null;
       private String strDays = null;
	
    
	public String getStrDays() {
		return strDays;
	}
	public void setStrDays(String strDays) {
		this.strDays = strDays;
	}
	public String getEDCSNGPath() {
		return EDCSNGPath;
	}
	public void setEDCSNGPath(String eDCSNGPath) {
		EDCSNGPath = eDCSNGPath;
	}
	public String getExternalUsers() {
		return externalUsers;
	}
	public void setExternalUsers(String externalUsers) {
		this.externalUsers = externalUsers;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getEDCSID() {
		return EDCSID;
	}
	public void setEDCSID(String eDCSID) {
		EDCSID = eDCSID;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getPublishedDate() {
		return publishedDate;
	}
	public void setPublishedDate(String publishedDate) {
		this.publishedDate = publishedDate;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getLastAccessed() {
		return lastAccessed;
	}
	public void setLastAccessed(String lastAccessed) {
		this.lastAccessed = lastAccessed;
	}
	public String getFileName() {
		return document;
	}
	public void setFileName(String document) {
		this.document = document;
	}

	public String getOwnerId() {
		return creator;
	}
	public void setOwnerId(String creator) {
		this.creator = creator;
	}
	public String getCreationDate(){
		return edate;
	}
	public void setCreationDate(String edate){
		this.edate = edate;
		
	}
	public String getExpiryDate(){
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate){
		this.expiryDate = expiryDate;
		
	}
	public String getFileEditURL() {
		return fileEditURL;
	}
    
	public void setFileEditURL(String fileEditURL) {
		this.fileEditURL = fileEditURL;
	}
	
	public String getSecurityValue() {
		return securityValue;
	}
	public void setSecurityValue(String securityValue) {
		this.securityValue = securityValue;
	}
	
	public String getLastUptDate() {
		return lastUptDate;
	}
	public void setLastUptDate(String lastUptDate) {
		this.lastUptDate = lastUptDate;
	}
	public String toString(){
		return creator + " - " + document;
	}
	
}
