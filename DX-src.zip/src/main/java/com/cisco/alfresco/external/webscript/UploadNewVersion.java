package com.cisco.alfresco.external.webscript;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.processor.BaseProcessorExtension;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.namespace.RegexQNamePattern;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.extensions.surf.util.InputStreamContent;
import org.springframework.extensions.webscripts.servlet.FormData;
import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.vera.sdk.connector.VeraDocxConnector;

public class UploadNewVersion extends BaseProcessorExtension
{

    private NodeService nodeService;
    private BehaviourFilter policyBehaviourFilter;
    private String alfrescoURL;
    private String contextName;
    String downloadURL;
    private ServiceRegistry serviceRegistry;
    private static final Logger LOGGER = Logger.getLogger(UploadNewVersion.class);
    private PreferenceService preferenceService;
    
    public NodeService getNodeService()
    {
        return nodeService;
    }

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    public BehaviourFilter getPolicyBehaviourFilter()
    {
        return policyBehaviourFilter;
    }

    public void setPolicyBehaviourFilter(BehaviourFilter policyBehaviourFilter)
    {
        this.policyBehaviourFilter = policyBehaviourFilter;
    }
    
    public String getAlfrescoURL() {
		return alfrescoURL;
	}

	public void setAlfrescoURL(String alfrescoURL) {
		this.alfrescoURL = alfrescoURL;
	}
	
	public String getContextName() {
		return contextName;
	}

	public void setContextName(String contextName) {
		this.contextName = contextName;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public PreferenceService getPreferenceService() {
		return preferenceService;
	}

	public void setPreferenceService(PreferenceService preferenceService) {
		this.preferenceService = preferenceService;
	}
	
	public String downloadURL(String node,String fileName){
		 NodeRef nodeRef = new NodeRef(node);
			//prbadam Start: US8978-Search related changes
		 /**
         * Vera protected docs file names allways ends with .html extension to the original filename.
         * If the document is protected with vera, then append .html extension to the file name
         */
        String downloadUrl = null;
        String applyVeraProtection = ExternalSharingFileFolderUtil.getFolderVeraProtectionStatus(nodeRef, serviceRegistry);
        if(applyVeraProtection != null && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals((String) nodeService.getProperty(nodeRef, ExternalSharingConstants.PROP_EXT_SECURITY)))){
        	downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + fileName + ".html?a=true";
        } else {
        	downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + fileName + "?a=true";
        }
        LOGGER.info("Download URL:" + downloadUrl);
    	//prbadam End: US8978-Search related changes
		 return downloadUrl;
	}
	
	public InputStreamContent VeraUnsecure(FormData.FormField formField) {
		InputStreamContent isc = null;
		try{

			InputStream unsecureStream = VeraDocxConnector.unsecureInputStream(formField.getContent().getInputStream());
			isc = new InputStreamContent(unsecureStream, "", "UTF-8");
		} catch(Exception e){
			LOGGER.error("exception occured while unsecure the document:" + e);
		}

		return isc;

	}
	
	public boolean checkUserAccess(FormData.FormField formField) throws FileNotFoundException {
		boolean checkUserAccess = false;
		List<String> allowedList= new ArrayList<String>(3);
		allowedList.add("DocExchange-Collaborate");
		allowedList.add("DocExchange-Full Access");

		String userId = serviceRegistry.getAuthenticationService().getCurrentUserName();
		String veraDocId= getVeraDocId(formField);
		LOGGER.info("veraDocId***"+veraDocId + " ;userId : " + userId);

		if(veraDocId != null){
			String policyName=VeraDocxConnector.getDocPolicies(veraDocId, userId);
			LOGGER.info("Vera PolicyName *** "+policyName);

			if(policyName != null && allowedList.contains(policyName)){ 
				checkUserAccess = true;
			} else {
				LOGGER.info("checkUserAccess()::PocicyName "+ policyName);
			}
		} else {
			LOGGER.info("checkUserAccess()::Vera Doc Id is null "+ veraDocId);
		}

		return checkUserAccess;
	}
	public String getVeraDocId(FormData.FormField formField) throws FileNotFoundException {
		
		String veraDocId=VeraDocxConnector.getMetadataForStream(formField.getContent().getInputStream());
		LOGGER.info("veraDocId***"+veraDocId);
		
		if(veraDocId != null){
			return veraDocId;
		} else {
			return null;
		}
		
	}
	
	public boolean isVeraEncryptedDoc(FormData.FormField formField) {
		String veraDocId = null;
		 try{
			 String sCurrentLine;
			 BufferedReader br = new BufferedReader(new InputStreamReader(formField.getInputStream()));
			 while ((sCurrentLine = br.readLine()) != null) {
					String searchString = "docId&quot;:&quot;";
					if(sCurrentLine.contains(searchString)){
						veraDocId = sCurrentLine.substring((sCurrentLine.indexOf(searchString) + searchString.length()), sCurrentLine.indexOf("&quot;,&quot;"));
						LOGGER.info("veraDocId is : "  + veraDocId);
						sCurrentLine = null;
						break;
					}
				}
			 br.close();
			 if(veraDocId != null && !veraDocId.isEmpty()){
				 return true;
			 }
		 } catch(Exception e){
			 LOGGER.error("veraDocId error occured : "  + e);
		 }
		 return false;
	}
	
	public boolean allowAccess(String noderef){
		boolean allowAccess = false;
		LOGGER.info("noderef ::: " +noderef);
		NodeRef node  = new NodeRef(noderef);
		final QName type = serviceRegistry.getNodeService().getType(node);
		if(!type.equals(ContentModel.TYPE_FOLDER)){
			ChildAssociationRef childAssociationRef = serviceRegistry.getNodeService().getPrimaryParent(node);
			node = childAssociationRef.getParentRef();
			if(serviceRegistry.getNodeService().hasAspect(node, ExternalSharingConstants.ASPECT_VERA_PROTECTION)){
				allowAccess = true;
			}
		}
		LOGGER.info("node ::: "+ node);
		if(serviceRegistry.getNodeService().hasAspect(node, ExternalSharingConstants.ASPECT_VERA_PROTECTION) && !allowAccess){
			LOGGER.info("if the folder is vera protected......");
		String userId = serviceRegistry.getAuthenticationService().getCurrentUserName();
		Set<AccessPermission> accessPermissions = serviceRegistry.getPermissionService().getAllSetPermissions(node);
		Iterator<AccessPermission> fIterator = accessPermissions.iterator();
		while (fIterator.hasNext()) {
			AccessPermission accessPermission = (AccessPermission) fIterator.next();
			if (accessPermission.getAuthorityType() == AuthorityType.USER && accessPermission.getAuthority().equalsIgnoreCase(userId) && accessPermission.getPermission().equalsIgnoreCase("EditorRole")) 
				 allowAccess = false;
			else if (accessPermission.getAuthorityType() == AuthorityType.USER && accessPermission.getAuthority().equalsIgnoreCase(userId))
				allowAccess = true;
		}
		}
		LOGGER.info("allowAccess :: " +allowAccess);
		return allowAccess;
	}
	
	public void disableBehaviour(String nodeRefStr, String qNameStr)
    {
        try
        {

            NodeRef nodeRef = new NodeRef(nodeRefStr);
            QName nodeQName = QName.createQName(qNameStr);

            policyBehaviourFilter.disableBehaviour(nodeRef, nodeQName);
        }
        catch (Exception e)
        {
            LOGGER.error("exception" + e);
        }

    }
	
	public String searchDocByName(final String fileName, final String parentFolderNodeRef){

		return AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<String>() {
			@Override
			public String doWork() throws Exception {
				NodeRef docNodeRef = serviceRegistry.getFileFolderService().searchSimple(new NodeRef(parentFolderNodeRef), fileName);
				return docNodeRef != null?docNodeRef.toString():null;
			}
		}, "admin");

	}

    public void enableBehaviour(String nodeRefStr, String qNameStr)
    {
        try
        {

            NodeRef nodeRef = new NodeRef(nodeRefStr);
            QName nodeQName = QName.createQName(qNameStr);
            policyBehaviourFilter.enableBehaviour(nodeRef, nodeQName);
        }
        catch (Exception e)
        {
            LOGGER.error("exception ::" + e);
        }

    }

    
    /**
	 * This method creates association for the library folders for user preferences folders
	 *  
	 */
    public void addDXFolderAspectProps(String repoUser) {
    	
    	 LOGGER.info("inside addDXFolderAspectProps to get user preferences");
    	 List<NodeRef> preferenceFolderList = getPreferenceFolderList(repoUser);
    	 LOGGER.debug("preferenceFolderList size : " + preferenceFolderList.size());

		if (preferenceFolderList != null && preferenceFolderList.size() > 0) {
			for (int i = 0; i < preferenceFolderList.size(); i++) {
				try {
					NodeRef nodeRef = preferenceFolderList.get(i);
					//LOGGER.info("nodeRef-----" + nodeRef);
					addUserPreferencesProps(repoUser, nodeRef);
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
					LOGGER.error("exception in AddDXFolderAspectScript-----" + e);
				}
			} // end of for loop
		}// end of if
	}
    
	/**
	 * This method creates association for the library folders
	 *  
	 */
    private void addUserPreferencesProps(String repoUser, NodeRef finalUserFolderNode) {
		
    	LOGGER.info("::: Inside addUserPreferencesProps ::::");

		final NodeRef personNodereff=serviceRegistry.getPersonService().getPerson(repoUser);
	    		try{
	    			boolean hasDXFolderAspect = nodeService.hasAspect(finalUserFolderNode, CiscoModelConstants.CISCO_DX_FOLDER_ASPECT);
	    	        List<ChildAssociationRef> childDXFolderAssocList = nodeService.getChildAssocs(finalUserFolderNode,CiscoModelConstants.CISCO_DX_FOLDER_ASSOCIATION,RegexQNamePattern.MATCH_ALL);
	    	        LOGGER.info("inside childDXFolderAssocList-------"+ childDXFolderAssocList.size());
	    			if(hasDXFolderAspect){
	    				if(childDXFolderAssocList.size() > 0){
	    	   	        	LOGGER.info("aspect and assoc already exists---");
	    				}else {
	    					serviceRegistry.getNodeService().addChild(personNodereff, finalUserFolderNode, 
	    	   	        			CiscoModelConstants.CISCO_DX_FOLDER_ASSOCIATION, QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, finalUserFolderNode.getId()));
	    	   	        	LOGGER.info("aspect and assoc added successfully---");
	    				}
	    			} else {
		        	serviceRegistry.getNodeService().addAspect(finalUserFolderNode, CiscoModelConstants.CISCO_DX_FOLDER_ASPECT, null);
		        	if(childDXFolderAssocList.size() > 0){
    	   	        	LOGGER.info("aspect and assoc already exists---");
    				}else {
    					serviceRegistry.getNodeService().addChild(personNodereff, finalUserFolderNode, 
    	   	        			CiscoModelConstants.CISCO_DX_FOLDER_ASSOCIATION, QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, finalUserFolderNode.getId()));
    	   	        	LOGGER.info("aspect and assoc added successfully---");
    				}
	    			 }
	    			} catch (Exception e) {
   	        		LOGGER.error("Exception in addUserPreferencesProps----"+e);
   	        		e.printStackTrace();
				}
	}
    
    /**
	 * 
	 * @param currentUser
	 * @return
	 */
	private List<NodeRef> getPreferenceFolderList(final String currentUser)
	{
		if (LOGGER.isDebugEnabled())
		{
			LOGGER.debug("getPreferenceFolderList method");
		}
		List<NodeRef> preferenceFolderList = new ArrayList<NodeRef>();
		try
		{
			final String preferenceFilter = "org.alfresco.share.folders.favourites";
			final Map<String, Serializable> currentPreferencesFolder = preferenceService.getPreferences(currentUser,
					preferenceFilter);

			if (LOGGER.isDebugEnabled())
			{
				LOGGER.debug("PreferenceFolderList : " + currentPreferencesFolder);
			}

			if (currentPreferencesFolder.containsKey(preferenceFilter))
			{
				preferenceFolderList=AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<List<NodeRef>>()
					{
						@Override
						public List<NodeRef> doWork() throws Exception
						{
							List<NodeRef> prefFolderList = new ArrayList<NodeRef>();
							String item = (String) currentPreferencesFolder.get(preferenceFilter);

							if (item.indexOf(",") != -1 && item.indexOf(",") < 2)
							{
								item = item.substring(1);
							}
							String[] itemArray = item.trim().split(",");
							LOGGER.debug("Before perm check prefFolderList size: " + itemArray.length);
							for (int i = 0; i < itemArray.length; i++)
							{
								final NodeRef nodeRef = new NodeRef(itemArray[i]);
							if (serviceRegistry.getNodeService().exists(nodeRef))
							{
								if (LOGGER.isDebugEnabled())
								{
									LOGGER.debug("hasPermission on NodeRef : " + nodeRef + ", currentUser :"
											+ currentUser);
								}

								final boolean hasFolderPermission = ExternalSharingFileFolderUtil.hasAccess(
										currentUser, nodeRef, serviceRegistry);
								if (hasFolderPermission)
								{
									prefFolderList.add(nodeRef);
								}
							}
							
						}
							return prefFolderList;
						}
							}, "admin");
				//}
			}
		}
		catch (Exception e)
		{
			LOGGER.error("Exception in getPreferenceFolderList : ", e);
		}
		return preferenceFolderList;
	}
    
	 public  void setUserPreferences(String currentUser){
			Map<String, Serializable> updatedPreferences = null;
			AuthenticationUtil.setFullyAuthenticatedUser("admin");
			updatedPreferences = setUserPreferenceFolderList(currentUser);
			preferenceService.setPreferences(currentUser, updatedPreferences);
			LOGGER.info("finished setRemovePreferences method-----------");
	    }
	
	/**
	 * 
	 * @param currentUser
	 * @return
	 */
	public Map<String, Serializable> setUserPreferenceFolderList(final String currentUser)
	{

		if (LOGGER.isDebugEnabled())
		{
			LOGGER.debug("getPreferenceFolderList method");
		}
		List<String> preferenceFolderList = new ArrayList<String>();
		Map<String, Serializable> updatedPreferences = null;
		try
		{
			final String preferenceFilter = "org.alfresco.share.folders.favourites";
			final Map<String, Serializable> currentPreferencesFolder = preferenceService.getPreferences(currentUser,
					preferenceFilter);

			if (LOGGER.isDebugEnabled())
			{
				LOGGER.debug("PreferenceFolderList : " + currentPreferencesFolder);
			}

			if (currentPreferencesFolder.containsKey(preferenceFilter))
			{
				preferenceFolderList=AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<List<String>>()
					{
						@Override
						public List<String> doWork() throws Exception
						{
							List<String> userPreferencesFoldersList = new ArrayList<String>();
							List<String> list = new ArrayList<String>();
							 Set<String> userPreferencesFoldersSet = new HashSet<String>();
							String item = (String) currentPreferencesFolder.get(preferenceFilter);

							if (item.indexOf(",") != -1 && item.indexOf(",") < 2)
							{
								item = item.substring(1);
							}
							String[] itemArray = item.trim().split(",");
							LOGGER.debug("Before filter check prefFolderList size: " + itemArray.length);
							
							if(itemArray.length > 0){
								Collections.addAll(list, itemArray);
							}
							if(list.size()>0) {
								userPreferencesFoldersSet.addAll(list);
							}
							if(!userPreferencesFoldersSet.isEmpty()) {
							 for (String folderId : userPreferencesFoldersSet){
								 userPreferencesFoldersList.add(folderId);
						        }
							}
							for (String nodeId:userPreferencesFoldersList)
							{
								final NodeRef nodeRef = new NodeRef(nodeId);
							if (serviceRegistry.getNodeService().exists(nodeRef))
							{
								
								boolean hasUserAccessOnParent=ExternalSharingFileFolderUtil.canUserHavePermissionOnParentFolder(nodeRef.toString(),serviceRegistry,currentUser);
								LOGGER.info("if current login user dont have access on parent folder :::: "+hasUserAccessOnParent);
								final boolean hasFolderPermission = ExternalSharingFileFolderUtil.hasAccess(
										currentUser, nodeRef, serviceRegistry);
								if (hasUserAccessOnParent && hasFolderPermission)
								{
									LOGGER.info("Need to keep folder in library section ");
								}else {
									userPreferencesFoldersList.remove(nodeRef.toString());
									LOGGER.info("Removed child folder from library section "+nodeRef);
								}
							}else {
								userPreferencesFoldersList.remove(nodeRef.toString());
								LOGGER.info("Removed not exists folder from library section "+nodeRef);
							}
							
						}
							LOGGER.debug("After filter check prefFolderList size: " + userPreferencesFoldersList.size());
							return userPreferencesFoldersList;
						}
							}, "admin");
				//}
			}
			updatedPreferences=new HashMap<String, Serializable>();
			updatedPreferences.put(preferenceFilter, StringUtils.join(preferenceFolderList, ","));
		}
		catch (Exception e)
		{
			LOGGER.error("Exception in getPreferenceFolderList : ", e);
		}
		return updatedPreferences;
	}
}
