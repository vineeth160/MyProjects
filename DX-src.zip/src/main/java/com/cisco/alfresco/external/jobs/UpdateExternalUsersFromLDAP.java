package com.cisco.alfresco.external.jobs;

import java.util.ArrayList;
import java.util.List;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.PersonService;
import org.apache.log4j.Logger;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;

public class UpdateExternalUsersFromLDAP extends QuartzJobBean {
	private static Logger LOGER = Logger.getLogger(UpdateExternalUsersFromLDAP.class);
	private ServiceRegistry serviceRegistry;
	private PersonService personService;
	private NodeService nodeService;
	private static final String KEY_IS_JOB_ENABLED = "UpdateExternalUsersFromLDAPJobEnable";
	private boolean isJobEnabled = false;
	private static Integer MAX_VALUE = 4000;

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	private ExternalLDAPUtil ldapUtil;

	public ExternalLDAPUtil getLdapUtil() {
		return ldapUtil;
	}

	public void setLdapUtil(ExternalLDAPUtil ldapUtil) {
		this.ldapUtil = ldapUtil;
	}

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {

		JobDataMap jobData = context.getJobDetail().getJobDataMap();
		String isJobEnabledStr = (String) jobData.get(KEY_IS_JOB_ENABLED);
		if (isJobEnabledStr != null) {
			try {
				isJobEnabled = new Boolean(isJobEnabledStr);
			} catch (Exception e) {
				LOGER.error("Invalid '" + KEY_IS_JOB_ENABLED + "' value, using default: " + isJobEnabled, e);
			}
		}

		if (!isJobEnabled) {
			LOGER.error("Skipping " + KEY_IS_JOB_ENABLED + " to execute.");
			return;
		}
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				// TYPE:"cm:person" AND @cs\:externalUserStatus
				String strPersonQuery = "TYPE:\"cm:person\" AND -@cm\\:email:[*@ *]";// TYPE:"cm:person" AND
																						// -@cm\:email: (*@*)
				LOGER.info("strPersonQuery : " + strPersonQuery);
				List<NodeRef> nodeRefList = getContentList(strPersonQuery);
				LOGER.info("nodeRefList : " + nodeRefList);
				if (nodeRefList != null && nodeRefList.size() > 0) {
					for (NodeRef nodeRef : nodeRefList) {
						LOGER.info("nodeRef::" + nodeRef);
						// Map<QName, Serializable> nodeProp =
						// serviceRegistry.getNodeService().getProperties(nodeRef);

						updateExternalUser(nodeRef);
					}
				}
				return null;
			}
		}, "admin");
	}

	private void updateExternalUser(NodeRef nodeRef) {
		String strFirstName = "", strLastName = "";
		personService = serviceRegistry.getPersonService();
		nodeService = serviceRegistry.getNodeService();
		String strUserDetails = null;
		String email = null;
		// String[] ids = { "cdxextuser1,sarojiit@gmail.com" };
		// for (int i = 0; i < ids.length; i++) {
		try {
			String strUnameRepo = (String) nodeService.getProperty(nodeRef, ContentModel.PROP_USERNAME);// ((String) //
																										// nodeProp.get(ContentModel.PROP_USERNAME));
			String organization = null;
			if (strUnameRepo != null) {
				strUserDetails = ldapUtil.getUserDetailsFromLDAP(strUnameRepo);
				email = ldapUtil.getManagerEmailFromLDAP(strUnameRepo);
				LOGER.info("email::" + email);
			}
			LOGER.info("struserDetails =" + strUserDetails);
			if (email != null && strUserDetails != null && !email.equals("")) {
				String struserName = (strUserDetails.split("::"))[0];
				LOGER.info("userName =" + struserName);
				String fullName = (strUserDetails.split("::"))[1];
				LOGER.info("name =" + fullName);
				organization = (strUserDetails.split("::"))[2];
				if (fullName != null && fullName != "") {
					if (fullName.trim().contains(" ")) {
						strFirstName = (fullName.split(" "))[0];
						LOGER.info("firstName::" + strFirstName);
						strLastName = (fullName.split(" "))[1];
						LOGER.info("lastName::" + strLastName);
					} else {
						strFirstName = fullName;
					}

				} else
					strFirstName = fullName;

				boolean isUserExists = personService.personExists(struserName);

				if (isUserExists) {
					// NodeRef noderef = personService.getPerson(struserName);
					// HashMap<QName, Serializable> userProperties = new HashMap<QName,
					// Serializable>();
					/*
					 * if (strFirstName != null) userProperties.put(ContentModel.PROP_FIRSTNAME,
					 * strFirstName); if (strLastName != null)
					 * userProperties.put(ContentModel.PROP_LASTNAME, strLastName);
					 */
					if (strFirstName != null || strFirstName != "")
						nodeService.setProperty(nodeRef, ContentModel.PROP_FIRSTNAME, strFirstName);
					if (strLastName != null || strLastName != "")
						nodeService.setProperty(nodeRef, ContentModel.PROP_LASTNAME, strLastName);
					if (email != null)
						nodeService.setProperty(nodeRef, ContentModel.PROP_EMAIL, email);
					// userProperties.put(ContentModel.PROP_EMAIL, email);
					if (organization != null)
						nodeService.setProperty(nodeRef, ContentModel.PROP_ORGANIZATION, organization);

					// userProperties.put(ContentModel.PROP_ORGANIZATION, organization);

					// if (nodeRef != null)
					// nodeService.setProperties(nodeRef, userProperties);

					LOGER.info("User info has been updated for " + struserName + " has been updated");
				}

			} else {

				strUserDetails = ldapUtil.getGenericUserDetailsFromLDAP(strUnameRepo);

				if (!"".equalsIgnoreCase(strUserDetails) && strUserDetails != null) {

					String struserName = (strUserDetails.split("::"))[0];
					LOGER.info("userName =" + struserName);
					String fullName = (strUserDetails.split("::"))[1];
					organization = (strUserDetails.split("::"))[2];
					email = (strUserDetails.split("::"))[3];
					LOGER.info("email =" + email);
					LOGER.info("name =" + fullName);
					LOGER.info("company  =" + organization);
					if (fullName != null && fullName != "") {
						fullName = fullName.trim();
						if (fullName.trim().contains(" ")) {
							strFirstName = (fullName.split(" "))[0];
							LOGER.info("firstName::" + strFirstName);
							strLastName = (fullName.split(" "))[1];
							LOGER.info("lastName::" + strLastName);
						} else {
							strFirstName = fullName;

						}
					} else {
						strFirstName = fullName;
					}

					boolean isUserExists = personService.personExists(struserName);
					if (isUserExists) {
						if (strFirstName != null || strFirstName != "")
							nodeService.setProperty(nodeRef, ContentModel.PROP_FIRSTNAME, strFirstName);
						if (strLastName != null || strLastName != "")
							nodeService.setProperty(nodeRef, ContentModel.PROP_LASTNAME, strLastName);
						if (email != null)
							nodeService.setProperty(nodeRef, ContentModel.PROP_EMAIL, email);
						if (organization != null)
							nodeService.setProperty(nodeRef, ContentModel.PROP_ORGANIZATION, organization);
						LOGER.info("User info has been updated for " + struserName + " has been updated");
					}

				} else {
					boolean isInternalUser = ldapUtil.isLdapUserInternal(strUnameRepo);
					if (isInternalUser) {
						email = strUnameRepo + "@cisco.com";
						nodeService.setProperty(nodeRef, ContentModel.PROP_EMAIL, email);
						if (organization == null)
							nodeService.setProperty(nodeRef, ContentModel.PROP_ORGANIZATION, "Cisco Systems, Inc.");
						LOGER.info("User info has been updated for " + strUnameRepo + " has been updated");
					} else {
						nodeService.setProperty(nodeRef, ContentModel.PROP_EMAIL, strUnameRepo + "@cisco.com");
						if (organization == null)
							nodeService.setProperty(nodeRef, ContentModel.PROP_ORGANIZATION, "Not Exist");
						LOGER.info("User info has been updated for " + strUnameRepo + " has been updated");
					}
				}

			}

		}

		catch (Exception e) {
			LOGER.error("Exception::::" + e.getStackTrace());
			e.printStackTrace();
		}
	}
	// }

	private List<NodeRef> getContentList(String searchQuery) {
		int skipCount = 0;
		List<NodeRef> nodeRefList = null;
		while (true) {
			SearchParameters sp = new SearchParameters();
			sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
			sp.setLanguage(SearchService.LANGUAGE_LUCENE);
			sp.setMaxItems(400);
			sp.setSkipCount(skipCount);
			sp.setQuery(searchQuery);
			ResultSet results = serviceRegistry.getSearchService().query(sp);
			if (skipCount == 0)
				nodeRefList = new ArrayList<NodeRef>();
			if (null == results || results.length() <= 0)
				break;
			for (ResultSetRow row : results) {
				nodeRefList.add(row.getNodeRef());
			}
			// }
			results.close();
			if (skipCount == MAX_VALUE)
				break;
			skipCount += 400;
		}
		return nodeRefList;
	}

}