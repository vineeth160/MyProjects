package com.cisco.alfresco.external.common.util;

import java.util.Hashtable;

import org.alfresco.service.namespace.QName;



public class ExternalSharingConstants
{

    public static String USER_ADMIN = "admin";
    public static String FOLDER = "folder";
    public static String FILE = "file";
    public static QName EXT_POLICY_DETAILS_ASPECT = QName.createQName("http://www.cisco.com/model/content/1.0",
        "policyDetails");
    public static QName PROP_EXT_POLICY_ACCEPTED = QName.createQName("http://www.cisco.com/model/content/1.0",
        "isPolicyAccepted");
    public static QName PROP_EXT_SECURITY = QName.createQName("http://www.cisco.com/model/content/1.0", "security");
    public static QName PROP_EDCS_ID = QName.createQName("http://www.cisco.com/model/content/1.0", "alf_id");
    public static QName PROP_WORKFLOWSTATUS = QName.createQName("http://www.cisco.com/model/content/1.0","workflowStatus");
	public static QName PROP_DOCSTATUS = QName.createQName("http://www.cisco.com/model/content/1.0","status");
	public static QName PROP_EXPIRAIONDATE =QName.createQName("http://www.alfresco.org/model/external/content/1.0","publishExpirationDate");
	
	public static QName ASPECT_VERA_PROTECTION = QName.createQName("http://www.alfresco.org/model/external/content/1.0","veraProtectionAspect");
	public static QName PROP_IS_DOCUMENT_VERA_PROTECTED = QName.createQName("http://www.alfresco.org/model/external/content/1.0","isDocVeraProtected");
	public static QName PROP_IS_VERA_ROOT_FOLDER = QName.createQName("http://www.alfresco.org/model/external/content/1.0","isVeraRootFolder");
	public static QName PROP_VERA_ENABLED_BY = QName.createQName("http://www.alfresco.org/model/external/content/1.0","veraEnabledBy");
	public static QName PROP_VERA_ENABLED_DATE = QName.createQName("http://www.alfresco.org/model/external/content/1.0","veraEnabledDate");
	public static QName PROP_VERA_ROOT_FOLDER_NODEREF = QName.createQName("http://www.alfresco.org/model/external/content/1.0","veraRootFolderNodeRef");
	public static QName PROP_APPLY_VERA_PROTECTION = QName.createQName("http://www.alfresco.org/model/external/content/1.0","applyVeraProtection");
	
	
	//added by uellappa for GCS
	 final static String CISCO_EXT_URI = "http://www.alfresco.org/model/external/content/1.0";
	    public final static QName CISCO_GLOBAL_CACHING_ASPECT = QName.createQName(CISCO_EXT_URI, "globalCachingAspect");
	    public final static QName CISCO_QNAME_IS_FILE_SYNCHED_PROP = QName.createQName(CISCO_EXT_URI, "isFileSynched");
	    public final static QName CISCO_QNAME_FILE_SYNC_DATE_PROP = QName.createQName(CISCO_EXT_URI, "fileLastSyncDate");
	    public final static QName CISCO_QNAME_UPLOAD_GELOLOCATION_PROP = QName.createQName(CISCO_EXT_URI, "fileUploadGeoLocation");
	    public final static QName CISCO_QNAME_SYNCHED_USER_PROP = QName.createQName(CISCO_EXT_URI, "fileLastSynchedUser");
	    public final static QName CISCO_GCS_LOCATION_ASPECT = QName.createQName(CISCO_EXT_URI, "gcLocationAspect");
		public final static QName CISCO_QNAME_GCS_LOCATION_PROP = QName.createQName(CISCO_EXT_URI, "userGeoLocation");
		public final static QName CISCO_QNAME_GCS_TEMP_SIZE = QName.createQName(CISCO_EXT_URI, "tempSize");
		public final static QName CISCO_QNAME_GCS_TEMP_MIMETYPE = QName.createQName(CISCO_EXT_URI, "tempFileMimeType");
		
	  	//uellappa end
		
		//added by uellappa for Tag service
		public final static QName CISCO_TAG_ASPECT = QName.createQName(CISCO_EXT_URI, "tagAspect");
		public final static QName CISCO_QNAME_TAG_NAME = QName.createQName(CISCO_EXT_URI, "tagName");
		//uellappa end
	
		//US9853 start
		public final static QName ASPECT_OPTINOUT_EMAIL_NOTIFICATION = QName.createQName("http://www.alfresco.org/model/external/content/1.0", "emailNotification");
		public final static QName PROP_OPTOUT_EMAIL_NOTIFY = QName.createQName("http://www.alfresco.org/model/external/content/1.0", "optOutEmailNotify");
		//US9853 end
		
		//US12981 start
		public final static QName CISCO_DOMAIN_ASPECT = QName.createQName(CISCO_EXT_URI, "domainAspect");
		public final static QName CISCO_EXTERNAL_DOMAIN_PROP = QName.createQName(CISCO_EXT_URI, "domain_name");
		//US12981 end
		
	public static Hashtable<String, Integer> UsersRoleHerarcy = new Hashtable<String, Integer>(9); 
	
	static {
	UsersRoleHerarcy.put("Admin", 8); 
	UsersRoleHerarcy.put("Power",7);
	UsersRoleHerarcy.put("Admin",6);
	UsersRoleHerarcy.put("Owner",5); 
	UsersRoleHerarcy.put("Editor",4); 
	UsersRoleHerarcy.put("Reader",3);
	UsersRoleHerarcy.put("Viewer",2);
	UsersRoleHerarcy.put("User",1);
	}
}