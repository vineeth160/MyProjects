package com.cisco.alfresco.external.jobs;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.transaction.RetryingTransactionHelper.RetryingTransactionCallback;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.TemplateService;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.transaction.TransactionService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;
import com.cisco.alfresco.edcsng.util.MailUtil;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.sd.rest.service.MigrationConstants;

public class ExternalUserUpdateAspect extends AbstractWebScript{
	
	private ExternalLDAPUtil ldapUtil;
	private  TransactionService transactionService;
	private ServiceRegistry serviceRegistry ;
	private String toMail;
	private String mailerFromID;
	private String username =null;
	private String email =null;
	private String ccMail;
	List<String> exceptionUserList;
	private String fileLocation;
	private String ldapUserAccess;
	private String mailServer;
	private String mailSubject;	
	private String bannerAlfrescoUrl;
	String template = "/alfresco/extension/templates/email/applyUserAccessLevelAspectFailedNotification.ftl";
	Map<Integer, Object[]> data = null;
	int count;
    private static final Log logger = LogFactory.getLog(ExternalUserUpdateAspect.class);
    
    
    /**
	 * @return the bannerAlfrescoUrl
	 */
	public String getBannerAlfrescoUrl() {
		return bannerAlfrescoUrl;
	}

	/**
	 * @param bannerAlfrescoUrl the bannerAlfrescoUrl to set
	 */
	public void setBannerAlfrescoUrl(String bannerAlfrescoUrl) {
		this.bannerAlfrescoUrl = bannerAlfrescoUrl;
	}
	
    /**
	 * @return the mailSubject
	 */
	public String getMailSubject() {
		return mailSubject;
	}

	/**
	 * @param mailSubject the mailSubject to set
	 */
	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}
    
    /**
	 * @return the mailServer
	 */
	public String getMailServer() {
		return mailServer;
	}

	/**
	 * @param mailServer the mailServer to set
	 */
	public void setMailServer(String mailServer) {
		this.mailServer = mailServer;
	}
	
	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}
	
	public String getMailerFromID() {
		return mailerFromID;
	}

	public void setMailerFromID(String mailerFromID) {
		this.mailerFromID = mailerFromID;
	}

	public String getToMail() {
		return toMail;
	}

	public void setToMail(String toMail) {
		this.toMail = toMail;
	}

	public String getCcMail() {
		return ccMail;
	}

	public void setCcMail(String ccMail) {
		this.ccMail = ccMail;
	}

	public TransactionService getTransactionService() {
		return transactionService;
	}

	public void setTransactionService(TransactionService transactionService) {
		this.transactionService = transactionService;
	}
	

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public ExternalLDAPUtil getLdapUtil()
    {
        return ldapUtil;
    }

    public void setLdapUtil(ExternalLDAPUtil ldapUtil)
    {
        this.ldapUtil = ldapUtil;
    }

	
	@Override
	public void execute(WebScriptRequest arg0, WebScriptResponse arg1) {
		
		 Set<NodeRef> peopleSet = serviceRegistry.getPersonService().getAllPeople();
		 count = 0;
        //logger.info("Users List "+peopleSet.size());	
		for(final NodeRef node : peopleSet){
			addAspect(node);			
        }
		if(data!=null){			
			
			try {
				
				HSSFWorkbook workBook = new HSSFWorkbook();
				HSSFCellStyle headerStyle = workBook.createCellStyle();
				HSSFFont headerFont = workBook.createFont();
				headerFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerStyle.setFillForegroundColor(HSSFColor.GREY_40_PERCENT.index);
				headerStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
				headerStyle.setFont(headerFont);
				HSSFCell cell =null;
				HSSFSheet sheet = workBook.createSheet("Failed UserAccessLevel Info");
				
				Set<Integer> keyset = data.keySet();
		        int rownum = 0;
		        for (Integer key : keyset) {
		        	//logger.info("key..>>>"+key);
		        	HSSFRow row = sheet.createRow(rownum++);
		            Object [] objArr = data.get(key);
		            int cellnum = 0;
		            for (Object obj : objArr) {
		            	
		            	cell = row.createCell(cellnum++);
		                 if(obj instanceof String)
		                    cell.setCellValue((String)obj);
		                 if(key==0){
		                	 cell.setCellStyle(headerStyle);
		                 }
		            }
		        }
		        File file =  new File(fileLocation);
		        if (file.exists()) {
		        	logger.info("Directory already exists ...");

		        } else {
		        	logger.info("Directory not exists, creating now");

		            boolean success = file.mkdir();
		            if (success) {
		            	logger.info("Successfully created new directory: "+ fileLocation);
		            } else {
		            	logger.info("Failed to create new directory: "+ fileLocation);
		            }
		        }
		        StringBuffer  fileWithLocation  = new StringBuffer();
		        fileWithLocation.append(fileLocation).append("FailedUsers_AddUserAccessLevel_").append(new SimpleDateFormat("yyyyMMddhhmmss").format(new Date())).append(".xls");		        
		        FileOutputStream out = new FileOutputStream(fileWithLocation.toString());
	            workBook.write(out);
	            out.flush();
	            out.close();	            
	            logger.info("Excel written successfully..");
	            String[] toUsers = toMail.split(",");	
	            Map<String, Object> model = new HashMap<String, Object>();
	            model.put("year", new SimpleDateFormat("yyyy").format(new Date()));
	            model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
	            
	            TemplateService templateService = serviceRegistry.getTemplateService();
	            String htmlBody = templateService.processTemplate(template, model);
	            boolean mailstatus =   MailUtil.sendMail(mailServer,mailerFromID, toUsers, ccMail, mailSubject, 
	            		htmlBody,fileWithLocation.toString());
	            logger.info("Mail Sataus:: "+mailstatus);
	            
			} catch (IOException e) {
				logger.error("The Excel generation exception >> "+e.getMessage());
				e.printStackTrace();
			} catch (Exception e) {
				logger.error("The Excel generation exception >> "+e.getMessage());
			}
		}

			
		
   }
		public void addAspect(final NodeRef node){
			try
	        {
				username = (String)serviceRegistry.getNodeService().getProperty(node, ContentModel.PROP_USERNAME);
		        email = (String)serviceRegistry.getNodeService().getProperty(node, ContentModel.PROP_EMAIL);  		        
                ldapUserAccess = ldapUtil.getUserAccessLevelFromLDAP(username);
                if(ldapUserAccess==null && username.contains(".gen")){
	               	String strUserDetails = ldapUtil.getGenericUserDetailsFromLDAP(username);
		            	 if(strUserDetails != null && !"".equalsIgnoreCase(strUserDetails)){
		            	         ldapUserAccess = (strUserDetails.trim().split("::"))[6];
		            	 }
		            	
			    }
                 
				logger.info(" User Name:: "+username+"  Node ref :"+node +"  LDAP USER Access:: "+ldapUserAccess);
				if(ldapUserAccess==null){
				  setFailedUserData();
				}
				else if(!username.equalsIgnoreCase("admin")) {
					final int accessLevel = Integer.parseInt(ldapUserAccess);			
				    //logger.info(" Access Level for user :"+username+" is: "+accessLevel);	   	  
			        this.transactionService.getRetryingTransactionHelper().doInTransaction(new RetryingTransactionCallback<Void>()
			        {
			          @Override
			          public Void execute() throws Throwable
			          {
			             Map<QName, Serializable> extUserProp = null;
			           	       	
			           	 //if(accessLevel !=4){
			           	if(!serviceRegistry.getNodeService().hasAspect(node, MigrationConstants.CISCO_EXTERNAL_USER_ASPECT)){
			           	    					
			           	 extUserProp = new HashMap<QName, Serializable>();
			           	 extUserProp.put(MigrationConstants.CISCO_EXTERNAL_USER_ACCESS_PROP, accessLevel);		           	    	            	
			           	 serviceRegistry.getNodeService().addAspect(node, MigrationConstants.CISCO_EXTERNAL_USER_ASPECT, extUserProp);
			           	 //logger.info(" Aspect attached successfully on Person :"+username); 
			             }
			           	 //}
			                                
			           return null;
			         }
			        }, false, true); 
				}
		    }catch(Exception ex)
          {
			  setFailedUserData();
			  //logger.error("this user name from exception >> "+username+">>>>"+ex.getMessage());
	         
          }

		  }

		public void setFailedUserData(){

			  if(count==0){
				 data = new HashMap<Integer, Object[]>();
			     data.put(count, new Object[] {"User Name", "Email"});
			     count++;
		         data.put(count, new Object[] {username, email});
		         logger.error("Failed on settting User Access Level  for the User ::: "+username+ "  Email::: "+email); 
			  }
			  else{
				  count++;				  
				  data.put(count, new Object[] {username, email});
				  logger.error("Failed on settting User Access Level  for the USer ::: "+username+ "  Email::: "+email);   
				  
			  }
		}

		}
       
