package com.cisco.alfresco.external.webscript;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.PermissionService;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest; 


/**
 * 
 * @author kvr - US5736
 * 
 */
public class GenerateURL extends DeclarativeWebScript
{
    private static final Logger LOGGER = Logger.getLogger(GenerateURL.class);
    private ServiceRegistry serviceRegistry = null;
    private PermissionService permissionService =null; 
    private  String alfrescoURL;
    private  String contextName;
    
    public String getAlfrescoURL() {
		return alfrescoURL;
	}

	public void setAlfrescoURL(String alfrescoURL) {
		this.alfrescoURL = alfrescoURL;
	}

	public String getContextName() {
		return contextName;
	}

	public void setContextName(String contextName) {
		this.contextName = contextName;
	}
    
    public PermissionService getPermissionService() {
		return permissionService;
	}

	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}
    
    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

	public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }
 
	
	
	   @Override
	    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
	    {
		  	Map<String, Object> model = new HashMap();
			
			try {
				
				//DocId based download
				//@cs\:alf_id:"EDCSX-10000104"
				//String docId="EDCSX-10000104";
				
				String docId= req.getParameter("docId");
				LOGGER.info("docId---------"+docId);
			    if(docId!=null && !docId.isEmpty()){	
				
				String nodePath="@cs\\:alf_id:\""+docId+"\"";
				
				  LOGGER.info("nodePath---------"+nodePath);
				  
				 //String alfId=bannerlinktofileurl+"="+docId; 
				 ResultSet resultSet = serviceRegistry.getSearchService().query(
						new StoreRef(StoreRef.PROTOCOL_WORKSPACE, "SpacesStore"), SearchService.LANGUAGE_LUCENE,
						nodePath);

						if (resultSet.length() == 0)
						{
						LOGGER.error("Template " + nodePath + " not found.");
						return null;
						}

						NodeRef templateNode = resultSet.getNodeRef(0); 
						
						LOGGER.info("templateNode---------"+templateNode);
						LOGGER.info("templateNode.getId()---------"+templateNode.getId());
						String fileName = (String) serviceRegistry.getNodeService().getProperty(templateNode, ContentModel.PROP_NAME); 
				        LOGGER.info("fileName---------***********"+fileName);
				        String nodeId = templateNode.getId();
				        LOGGER.info("nodeId---------***********"+nodeId);
				        String url=alfrescoURL+contextName+"/"+"ext"+"/"+"download"+"?"+"docId"+"="+docId;	
				        LOGGER.info("url---------***********"+url);
				
				 model.put("url", url);
				 model.put("nodeId", nodeId);
				 model.put("fileName", fileName);					 
			   }
			   
			  else{
			         
					 model.put("url", null);
					 model.put("nodeId", null);
					 model.put("fileName", null);	
			      }
			 }		
			 catch (Exception e) {
					e.printStackTrace();
					
					LOGGER.info("in e---------"+e);
				}
	
			return model;
	    }

	
}
