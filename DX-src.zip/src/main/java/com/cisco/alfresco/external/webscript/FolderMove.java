package com.cisco.alfresco.external.webscript;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileExistsException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.sd.rest.service.MigrationConstants;

public class FolderMove extends DeclarativeWebScript
{

	private static final Logger LOG = Logger.getLogger(FolderMove.class);

	private ServiceRegistry serviceRegistry;
	
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status,	Cache cache) {
		LOG.info("FolderMove executeImpl method started::  ");
		final Map<String, Object> result = new HashMap<String, Object>();
		try{
			JSONObject json = new JSONObject(req.getContent().getContent());
			List<HashMap<String, String>> successList = new ArrayList<HashMap<String, String>>();
			List<HashMap<String, String>> failureList = new ArrayList<HashMap<String, String>>();
			if(!json.has("fromNodeId")){
				status.setMessage("fromNodeId is not found in the input request parameter");
				status.setCode(522);
				result.put("overallSuccess", "false");
			} else if(!json.has("toNodeId")){
				status.setMessage("toNodeId is not found in the input request parameter");
				status.setCode(523);
				result.put("overallSuccess", "false");
			} else if(!json.has("inheritFolderPermission")){
				status.setMessage("inheritFolderPermission is not found in the input request parameter");
				status.setCode(524);
				result.put("overallSuccess", "false");
			} else if(!json.has("moveComment")){
				status.setMessage("moveComment is not found in the input request parameter");
				status.setCode(525);
				result.put("overallSuccess", "false");

			}  else {

				String strSourceNodeRef = json.getString("fromNodeId");
				String strTargetNodeRef = json.getString("toNodeId");
				String strInhiritparentPerm = json.getString("inheritFolderPermission");
				final String strMoveComments = json.getString("moveComment");

				LOG.info("strSourceNodeRef1 : " + strSourceNodeRef + " ;strTargetNodeRef : " + strTargetNodeRef + " ;strInhiritparentPerm : " + strInhiritparentPerm + " ;strMoveComments : " + strMoveComments);

				String loggedInUser = AuthenticationUtil.getFullyAuthenticatedUser();
				LOG.info("loggedInUser1 : " + loggedInUser);

				final NodeRef targetNodeRef = new NodeRef(strTargetNodeRef);
				boolean targetNodePerm = checkPermissionOnNodeRef(loggedInUser, targetNodeRef);
				LOG.info("targetNodePerm : " + targetNodePerm);
				if(!targetNodePerm){
					status.setMessage("Don't have permission on target folder.");
					status.setCode(526);
					result.put("overallSuccess", "false");
				}

				result.put("targetNodeRef", strTargetNodeRef);
				result.put("inhiritParentPermissions", strInhiritparentPerm);
				result.put("moveComments", strMoveComments);

				String[] sourceNodeRefArray = strSourceNodeRef.split(",");
				
				
				if(targetNodePerm){
					for(int i=0;i<sourceNodeRefArray.length;i++){
						String nodeRef = sourceNodeRefArray[i];
						HashMap<String, String> failureValuesMapObj = new HashMap<String, String>();
						try{
							
							HashMap<String, String> successValuesMapObj = new HashMap<String, String>();
							if(nodeRef != null && !nodeRef.isEmpty() && nodeRef.contains("workspace://SpacesStore/")){
								final NodeRef sourceNodeRef = new NodeRef(nodeRef);
								String name = (String) serviceRegistry.getNodeService().getProperty(sourceNodeRef, ContentModel.PROP_NAME);
								
								failureValuesMapObj.put("name", name);
								failureValuesMapObj.put("nodeId", nodeRef);
								
								if(!serviceRegistry.getNodeService().exists(sourceNodeRef)){
									failureValuesMapObj.put("message", "Source folder or document not exist in the system.");
									failureValuesMapObj.put("fileExist", "false");
									failureList.add(failureValuesMapObj);
									status.setCode(418);
									result.put("overallSuccess", "false");
									continue;
									
								}
								
								if(!checkPermissionOnNodeRef(loggedInUser, sourceNodeRef)){
									failureValuesMapObj.put("message", "Don't have permission on the document/folder.");
									failureList.add(failureValuesMapObj);
									status.setCode(418);
									result.put("overallSuccess", "false");
									continue;
								}
								
								if(serviceRegistry.getNodeService().hasAspect(sourceNodeRef, ContentModel.ASPECT_LOCKABLE)){
									failureValuesMapObj.put("message", "Document is checked out you can not move this document.");
									failureList.add(failureValuesMapObj);
									status.setCode(418);
									result.put("overallSuccess", "false");
									continue;
									
								}
								
								if(serviceRegistry.getNodeService().hasAspect(sourceNodeRef, ContentModel.ASPECT_LOCKABLE)){
									failureValuesMapObj.put("message", "Document is checked out you can not move this document.");
									failureList.add(failureValuesMapObj);
									status.setCode(418);
									result.put("overallSuccess", "false");
									continue;
									
								}
								
								String nodeType = serviceRegistry.getNodeService().getType(sourceNodeRef).getLocalName();
								
								
								String publishedNodes = "";
								if(nodeType.equals("folder")){

									String sourceFolderQnamePath = serviceRegistry.getNodeService().getPath(sourceNodeRef).toPrefixString(serviceRegistry.getNamespaceService());
									String query = "PATH:\""+sourceFolderQnamePath+"//*\" AND TYPE:\"cs:ciscodoc\" AND ASPECT:\"ext:extShareableAspect\" AND (@ext\\:isExternalyShared:\"true\" OR @cs\\:alf_id:\"EDCS-*\")";
									LOG.info("qNamePath : " + sourceFolderQnamePath + " Query is : " + query);

									List<NodeRef> nodeRefList = EDCSUtil.getNodeRefList(query, serviceRegistry);

									LOG.info("nodeRefList : " + nodeRefList);
									if(nodeRefList != null && nodeRefList.size()>0){
										publishedNodes += nodeRefList.toString();
										
									}
								} else {
									if(serviceRegistry.getNodeService().hasAspect(sourceNodeRef, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT)){
										String edcsId = (String) serviceRegistry.getNodeService().getProperty(sourceNodeRef, ExternalSharingConstants.PROP_EDCS_ID);
										LOG.info("edcsId : " + edcsId);
										if(edcsId!= null && edcsId.contains("EDCS-")){
											publishedNodes += name;
										}
									}
								}
								
								if(publishedNodes != null && !publishedNodes.isEmpty()){
									failureValuesMapObj.put("message", "Following nodes Published from Doc Central " + publishedNodes);
									failureList.add(failureValuesMapObj);
									publishedNodes = null;
									continue;
								}
								
								NodeRef sourceParentNodeRef = serviceRegistry.getNodeService().getPrimaryParent(sourceNodeRef).getParentRef();
								String sourceVeraType = (String)serviceRegistry.getNodeService().getProperty(sourceParentNodeRef, ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
								String targetVeraType = (String)serviceRegistry.getNodeService().getProperty(targetNodeRef, ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
								String docSecurityType = (String)serviceRegistry.getNodeService().getProperty(sourceNodeRef, CiscoModelConstants.CISCO_SECURITY_PROP);
								sourceVeraType = (sourceVeraType!=null)?sourceVeraType:"";
								targetVeraType = (targetVeraType!=null)?targetVeraType:"";
								/**
								 * If source and destination does not have any vera protection, then simply skip the validation check
								 */
								if(!sourceVeraType.isEmpty() || !targetVeraType.isEmpty()){
									if(("All Contents".equals(sourceVeraType) && !"Cisco Restricted".equals(docSecurityType)) && "Cisco Restricted".equals(targetVeraType)){
										failureValuesMapObj.put("message", "You can not move any secured documents to non secured folder as target folder is enabled with IRM for only \"Cisco Restricted\" files ");
										failureList.add(failureValuesMapObj);
										status.setCode(417);
										result.put("overallSuccess", "false");
										continue;
									} else if(("Cisco Restricted".equals(sourceVeraType) && "Cisco Restricted".equals(docSecurityType) && targetVeraType.isEmpty()) ){
										failureValuesMapObj.put("message", "You can not move any secured \"Cisco Restricted\" documents to non secured folder as target folder is not enabled with IRM ");
										failureList.add(failureValuesMapObj);
										status.setCode(417);
										result.put("overallSuccess", "false");
										continue;
									} else if("All Contents".equals(sourceVeraType) && targetVeraType.isEmpty()){
										failureValuesMapObj.put("message", "You can not move any secured documents to non secured folder as target folder is not enabled with IRM ");
										failureList.add(failureValuesMapObj);
										status.setCode(417);
										result.put("overallSuccess", "false");
										continue;
									} 
								}
								
								addCommnetAspect(sourceNodeRef, strMoveComments);
								applyVeraProtectionOnDoc(sourceNodeRef,targetNodeRef);
								
								AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
									@Override
									public Object doWork() throws Exception {
										serviceRegistry.getFileFolderService().move(sourceNodeRef, targetNodeRef, null);
										return null;
									}
								}, "admin");
								
								LOG.info("docuemtn move funcionalit done and setting inhiritance " + strInhiritparentPerm + " On Souce");
								serviceRegistry.getPermissionService().setInheritParentPermissions(sourceNodeRef, Boolean.valueOf(strInhiritparentPerm));
								
								successValuesMapObj.put("name", name);
								successValuesMapObj.put("nodeId", sourceNodeRef.toString());
								successValuesMapObj.put("message", "");
								successValuesMapObj.put("fileExist", "false");
								successList.add(successValuesMapObj);
								
						
							}
							
						} catch(FileExistsException FEE){
							status.setCode(409);
							failureValuesMapObj.put("message", "Filename already exist in the destinaion folder");
							failureValuesMapObj.put("fileExist", "true");
							result.put("overallSuccess", "false");
							failureList.add(failureValuesMapObj);
							LOG.info("FileExistsException  :: " +FEE.getMessage());
						} catch(Exception e){
							status.setCode(417);
							status.setMessage(e.getMessage() != null?e.getMessage() : "Exception occured while moving the document");
							result.put("overallSuccess", "false");
							LOG.info("Exception e :: " +e.getMessage());
						}
					}
					result.put("successList", successList);
					result.put("failureList", failureList);
				}
				
			}

		}catch(Exception e){
			if(e.getMessage() != null && !e.getMessage().isEmpty()){
				status.setMessage(e.getMessage());
			} else {
				status.setMessage("Internal Server occured");
			}
			status.setCode(Status.STATUS_INTERNAL_SERVER_ERROR);

			LOG.error("Checking.... " +status.getCode() + " ;;; "+ e.getStackTrace(),e);
		} 

		LOG.info("Final Result in Doc Central is : "+ " ;;; " + status.getCode() + "  ::: " +status.getCodeName() + " ******  " + result.toString());
		return result;
	}

	private void addCommnetAspect(NodeRef currentNodeRef, String moveComment) throws Exception {
		LOG.info(" In MoveComment.addCommnetAspect method for NodeRef -->" + currentNodeRef);
		Map<QName, Serializable> aspectValues = new HashMap<QName, Serializable>();
		aspectValues.put(MigrationConstants.CISCO_QNAME_COMMENT_REASON_PROP, moveComment);
		serviceRegistry.getNodeService().addAspect(currentNodeRef, MigrationConstants.CISCO_MOVECOMMENT_ASPECT, aspectValues);

	}
	
	private void applyVeraProtectionOnDoc(NodeRef sourceNodeRef, NodeRef targetNodeRef){
		String veraProtectionType = (String)serviceRegistry.getNodeService().getProperty(targetNodeRef, ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
		if(veraProtectionType != null){
			String docSecurityType = (String)serviceRegistry.getNodeService().getProperty(sourceNodeRef, CiscoModelConstants.CISCO_SECURITY_PROP);
			if(veraProtectionType.equals("All Contents") || (veraProtectionType.equals(docSecurityType))){
				Map<QName, Serializable> verDocumentProtectionProps = new HashMap<>(1);
				verDocumentProtectionProps.put(ExternalSharingConstants.PROP_IS_DOCUMENT_VERA_PROTECTED, true);
				serviceRegistry.getNodeService().addAspect(sourceNodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION, verDocumentProtectionProps);
			} 
		}
	}
	
	private boolean checkPermissionOnNodeRef(final String loggedInUser, final NodeRef nodeRef) throws Exception{
		
		if(loggedInUser.equalsIgnoreCase("admin")){
			return Boolean.TRUE;
		}

		boolean isUserHavePermission = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
			@Override
			public Boolean doWork() throws Exception {
				String userRole = ExternalSharingFileFolderUtil.getUserRole(serviceRegistry, loggedInUser, nodeRef);
				String nodeType = serviceRegistry.getNodeService().getType(nodeRef).getLocalName();
				LOG.info("userRole.. : "+userRole + " ;nodeType : " + nodeType);
				if(nodeType.equals("folder")){
					if(("Owner").equals(userRole) || userRole.equals(UserRoleConstants.USER_ADMIN_ROLE)){
						LOG.info("user.. : "+loggedInUser+" have.. : " + userRole + " On NodeRef... : " + nodeRef);
						return Boolean.TRUE;
					}
				} else {
					if(("Owner").equals(userRole) || userRole.equals(UserRoleConstants.USER_ADMIN_ROLE) || ("Editor").equals(userRole)){
						LOG.info("user : "+loggedInUser+" have : " + userRole + " On NodeRef : " + nodeRef);
						return Boolean.TRUE;
					}
				}
				return Boolean.FALSE;
			}
		}, "admin");
		
		return isUserHavePermission;
	}
}
