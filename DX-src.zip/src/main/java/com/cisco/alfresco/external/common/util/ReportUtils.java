package com.cisco.alfresco.external.common.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.PermissionService;

import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.model.ContentModel;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.service.commons.ServiceConstants;

import jxl.CellView;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
public class ReportUtils {
	
	private static Log logger = LogFactory.getLog(ReportUtils.class);
	private static ServiceRegistry serviceRegistry = null;
    private static PermissionService permissionService =null;
    private static AuditComponent auditComponent;
    private static String docexReportMaxValue;
    private static Properties globalProperties;
    private static WritableCellFormat times;
	private static WritableCellFormat timesBoldUnderline;
	private static WritableCellFormat timesHeading;
	
    public static NodeRef getReportHomeFolder() {
		NodeRef folderNodeRef = null;		
		String searchQuery = globalProperties.getProperty("reportspath.query");
		logger.info("searchQuery   ::: " + searchQuery);
		folderNodeRef = EDCSUtil.doSearch(searchQuery, serviceRegistry);
		return folderNodeRef;
	}
	
	/**
     * set external sharable aspect to report file
     */
    public static void addSharableAspectToReportFile(NodeRef reportNode,ServiceRegistry serviceRegistry) throws Exception{
    	serviceRegistry.getNodeService().addAspect(reportNode, ServiceConstants.ASPECT_CISCOMETADATA, null);
		serviceRegistry.getNodeService().setType(reportNode, ServiceConstants.TYPE_CISCODOCS);
		serviceRegistry.getNodeService().addAspect(reportNode, ContentModel.ASPECT_AUDITABLE, null);
		serviceRegistry.getNodeService().addAspect(reportNode, ContentModel.ASPECT_REFERENCEABLE, null);
	}
			
		public static String getUniqueFileName(String name , NodeRef parentNodeRef){
	    	boolean fileNameExists=true;
	    	String filename=name;
	    	String tempFileName=name;
	    	int dotIndex,counter=1;
	    	while(fileNameExists){
	    		NodeRef node =serviceRegistry.getFileFolderService().searchSimple(parentNodeRef, tempFileName);
	    		if(node!=null){
	    			dotIndex = filename.lastIndexOf(".");
					if (dotIndex == 0) {
						// File didn't have a proper 'name' instead it had just a suffix and started with a ".", create "1.txt"
						tempFileName = counter + filename;
					} else if (dotIndex > 0) {
						// Filename contained ".", create "filename-1.txt"
						tempFileName = filename.substring(0, dotIndex) + "_"	+ counter + filename.substring(dotIndex);
					} else {
						// Filename didn't contain a dot at all, create "filename-1"
						tempFileName = filename + "-" + counter;
					}
	    			counter++;
	    		}else{
	    			fileNameExists=false;
	    		}
	    	}
	    	//logger.error("final tempFileName :: " + tempFileName);
	    	return tempFileName;
	    }
		
		public List<String> getFolderDomain(String parent, String child, String newParent) {
			
			
			
			logger.info("oldparent-----"+parent +", child------"+child +", newParent-----"+newParent);
			String[] parentSplit = parent.split(",");
			String[] childSplit = child.split(",");
			String[] newParentSplit = newParent.split(",");

			List<String> parentList = new ArrayList<String>();
			Collections.addAll(parentList, parentSplit);

			List<String> childList = new ArrayList<String>();
			Collections.addAll(childList, childSplit);

			List<String> newParentList = new ArrayList<String>();
			Collections.addAll(newParentList, newParentSplit);
			
			for (int i = 0; i < parentList.size(); i++) {

				boolean cList = childList.contains(parentList.get(i));
				if (cList) {
					childList.remove(parentList.get(i));
				}
			}
			childList.addAll(newParentList);
			logger.info("Final values in getFolderDomain method------" + childList);
			return childList;
			}
			
			public static void recordAuditInfo(NodeRef folderNodeRef, String folderName, String oldDomain, String folderDomain, String currentUserName, String event) {
				String modifier = AuthenticationUtil.getFullyAuthenticatedUser();
				Map<String, Serializable> auditEntry = new HashMap<String, Serializable>();
				auditEntry.put("foldername",folderName);
				auditEntry.put("noderef", folderNodeRef);
				auditEntry.put("creator", currentUserName );
				auditEntry.put("modifier", modifier);
				String nodePath = serviceRegistry.getNodeService().getPath(folderNodeRef).toDisplayPath(serviceRegistry.getNodeService(), permissionService);
				auditEntry.put("path",nodePath);
				auditEntry.put("folderprefixpath", serviceRegistry.getNodeService().getPath(folderNodeRef).toPrefixString(serviceRegistry.getNamespaceService()));
				auditEntry.put("olddomain", oldDomain);
				auditEntry.put("newdomain",folderDomain );
				auditEntry.put("event", event);
				auditComponent.recordAuditValues("/folder-domain/folder", auditEntry);
			}
			
			public static List<NodeRef> getContentList(String searchQuery){ 
				int skipCount = 0;
				List<NodeRef> nodeRefList = null;
				int maxValue=Integer.parseInt(docexReportMaxValue);
				while(true)
				{
					SearchParameters sp = new SearchParameters();
					sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
					sp.setLanguage(SearchService.LANGUAGE_LUCENE);
					sp.setMaxItems(500);
					sp.setSkipCount(skipCount);
					sp.setQuery(searchQuery);
					ResultSet results = serviceRegistry.getSearchService().query(sp);
					if(skipCount == 0)
						nodeRefList = new ArrayList<NodeRef>();
					if (null == results || results.length() <= 0)
						break;
					for (ResultSetRow row : results) {
						nodeRefList.add(row.getNodeRef());
					}
					//}
					results.close();
					if(skipCount == maxValue)
						break;
					skipCount += 500;
				}
			return nodeRefList;
			}
			
			/**
			 * @param noderef
			 * @return
			 */

			public static void createLabel(WritableSheet sheet, String label, int col)
					throws WriteException {
				WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
				times = new WritableCellFormat(times10pt);
				times.setWrap(false);
				// Create create a bold font
				WritableFont times10ptBoldUnderline = new WritableFont(
						WritableFont.TIMES, 10, WritableFont.BOLD, false);
				timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
				timesBoldUnderline.setWrap(false);
				CellView cv = new CellView();
				cv.setFormat(times);
				cv.setFormat(timesBoldUnderline);
				// Write a few headers
				addCaption(sheet, col, 1, label);
			}

			public static void addCaption(WritableSheet sheet, int column, int row, String s)
					throws RowsExceededException, WriteException {
				Label label;
				label = new Label(column, row, s, timesBoldUnderline);
				sheet.addCell(label);
			}

			public static void addLabel(WritableSheet sheet, int column, int row, String s)
			throws WriteException, RowsExceededException {
				Label label;
				label = new Label(column, row, s, times);
				sheet.addCell(label);
		    }


			public static void addHeading(WritableSheet sheet, int column, int row, String s)
					throws WriteException, RowsExceededException {
				Label label;
				label = new Label(column, row, s, timesHeading);
				sheet.addCell(label);
			}

}
