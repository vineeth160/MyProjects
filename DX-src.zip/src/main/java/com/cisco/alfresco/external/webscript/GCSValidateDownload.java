package com.cisco.alfresco.external.webscript;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.external.common.util.ExternalSharingConstants;

public class GCSValidateDownload extends DeclarativeWebScript {
	
	private static final Logger logger = Logger.getLogger(GCSValidateDownload.class);
    private ServiceRegistry serviceRegistry;
	
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
	@Override
	public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, Cache cache)
    {
		final Map<String, Object> model=new HashMap<String, Object>();
		 AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
		            {
		                @Override
		                public Object doWork() throws Exception
		                {
		                	
		          		  Date isFileSyncDate = null;
		                    Date gcsDate = null;  // if its null samee has to sync the content from central repository
		                	  String gcsUpdatedDate = null;
		                	  String noderef = req.getParameter("nodeId");
		                	  String userId = req.getParameter("userId");
		                	  String nodeRef = "workspace://SpacesStore/"+noderef;
		                	 logger.info("nodeRef ::: " +nodeRef + "  accessed by :: " + userId);
		                	  NodeRef node = new NodeRef(nodeRef);

		                  	if(node != null && node.toString().contains("workspace://SpacesStore/"))
		                  	{	
		                  		if(serviceRegistry.getNodeService().hasAspect(node,ExternalSharingConstants.CISCO_GLOBAL_CACHING_ASPECT)){
		                 			 isFileSyncDate = (Date) serviceRegistry.getNodeService().getProperty(node, ExternalSharingConstants.CISCO_QNAME_FILE_SYNC_DATE_PROP);
		                 			 logger.info("isFileSyncDate :: " +isFileSyncDate);}
		                 		}
		                  	boolean syncdata = false;
		                  	if(req.getParameter("lastSyncedDate") !=null && !req.getParameter("lastSyncedDate").isEmpty()){
		                  		gcsUpdatedDate = req.getParameter("lastSyncedDate");
		                  		logger.info("gcsUpdatedDate from req   :: " +gcsUpdatedDate);
		                  		SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd kk:mm:ss z yyyy");
		                  		syncdata = true;
		                  		try {
		                  			
		            					gcsDate = sdf.parse(gcsUpdatedDate);
		            					logger.info("gcsDate :: "+gcsDate);
		            					if(isFileSyncDate != null && gcsDate != null ){
		            			        	int comp = 	isFileSyncDate.compareTo(gcsDate);
		            			        	logger.info("date comparition ::; " +comp);
		            			        	SimpleDateFormat formatter = new SimpleDateFormat("EEE MMM dd kk:mm:ss z yyyy");
		            			        	String d1 = formatter.format(isFileSyncDate);
		            			        	String d2 = formatter.format(gcsDate);
		            			        	if(d1.equals(d2)){
		            			                logger.info("inside 200 ----->>>>> ");
		            			                //downloadFromGCS = true;
		            			                status.setCode(200);
		            			              //  res.setStatus(200);
		            			                model.put("msg","200");
		            			        	}else
		            						{   
		            			        		logger.info("inside 409 ----->>>>> isFileSyncDate mismatch");
		            			        		 status.setCode(409);
		            			        		//res.setStatus(409);
		            			        		model.put("msg","409");
		            							}
		            			        	}
		            				} catch (ParseException e) {
		            					e.printStackTrace();
		            				}
		                  	}if(!syncdata){
		                  		logger.info("last sync date is empty or null");
		                  		model.put("msg","409");
		                  	}
		                  	return model;
		                  
		                }
		            }, "admin");
		 logger.info("model -- >>   "+model.get("msg"));
		return model;
	
		
	}



}
