package com.cisco.alfresco.external.viewfav;

import java.io.FileReader;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.ContentData;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.Path;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthenticationService;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.namespace.InvalidQNameException;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.namespace.RegexQNamePattern;
import org.alfresco.util.ISO9075;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.external.common.model.ExtDocument;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.alfresco.external.domain.CheckDomain;
import com.cisco.alfresco.external.utils.CharUtil;
import com.cisco.sd.rest.service.MigrationConstants;

public class Viewfav extends DeclarativeWebScript{
	private static final Logger LOGGER = Logger.getLogger(Viewfav.class);
	private NodeService nodeService;
	private ServiceRegistry serviceRegistry;
	private PermissionService permissionService;
	private PersonService personService;
	private AuthenticationService authenticationService;
    private static String alfrescoURL;
    private String contextName;
    private static String geoServerLocation;
    final static String CISCO_MODEL_URI = "http://www.cisco.com/model/content/1.0"; //getChildAssocs http://www.cisco.com/model/content/1.0
    final static String CISCO_MODEL_URI_CM = "http://www.alfresco.org/model/content/1.0";
    QName ASSOC_NAME_MYFAVORITE_ASSOCIATE = QName.createQName(CISCO_MODEL_URI, "myFavorite");
	private static final int DAYSTOSUBTRACT = 30;
	private static final String GROUP_IDENTITY ="GROUP_";
	private static final String GROUP_EVERYONE="GROUP_EVERYONE";
	static SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm z");  // dd/MM/yyyy HH:mm z
	
    public String getGeoServerLocation() {
		return geoServerLocation;
	}
	public void setGeoServerLocation(String geoServerLocation) {
		this.geoServerLocation = geoServerLocation;
	}
	public PermissionService getPermissionService() {
		return permissionService;
	}
	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}
    public NodeService getNodeService() {
		return nodeService;
	}
	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}
	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
	public AuthenticationService getAuthenticationService() {
		return authenticationService;
	}
	public void setAuthenticationService(AuthenticationService authenticationService) {
		this.authenticationService = authenticationService;
	}
	public PersonService getPersonService() {
		return personService;
	}
	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}
    private PreferenceService preferenceService;
		public PreferenceService getPreferenceService() {
		return preferenceService;
	}
	public void setPreferenceService(PreferenceService preferenceService) {
		this.preferenceService = preferenceService;
	}
    public void setContextName(String contextName)
	    {
	        this.contextName = contextName;
	    }
	public void setAlfrescoURL(String alfrescoURL)
	    {
	        this.alfrescoURL = alfrescoURL;
	    }
	    
	   @SuppressWarnings("unchecked")
		@Override
		    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
		    {
		    Calendar cal = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
			String dateInString =sdf.format(cal.getTime());
			Date startdate;
			Date enddate;
			long dt = 0,dt1=0;
			try {
				startdate = sdf.parse(dateInString);
				dt=startdate.getTime();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			List<NodeRef> nodeRefList =null;
			nodeRefList = new ArrayList<NodeRef>();
			Map<String, Object> model=new HashMap<String, Object>();
			authenticationService = serviceRegistry.getAuthenticationService();
			String currentUserName = authenticationService.getCurrentUserName();
			NodeRef personNodereff=personService.getPerson(currentUserName);
			String pageNo = getParameter(req,"pageNo");
		    String sortBy = getParameter(req,"sortBy");
		    String sortOrder = getParameter(req,"sortOrder");
			String pageSize=getParameter(req,"pageSize");
			String filter = req.getParameter("filter");
			String hostname = req.getParameter("geoHostName");
			if(!hostname.isEmpty()&& hostname != null){
				hostname = hostValidation(hostname);
				LOGGER.info("------------------------->>>> : "+hostname);
			}
			int size,pageNum,days;
			String toDate = "";
			String loggedInUser = AuthenticationUtil.getFullyAuthenticatedUser();
			    List<ChildAssociationRef> childAssocListforviewfav = nodeService.getChildAssocs(personNodereff,ASSOC_NAME_MYFAVORITE_ASSOCIATE,RegexQNamePattern.MATCH_ALL);
				 if(childAssocListforviewfav.size() >0)
			    	{
			    	for (ChildAssociationRef childs : childAssocListforviewfav)
			    	{ 
						NodeRef childNodeRefs = childs.getChildRef();
						if(hasPermission(childNodeRefs,loggedInUser, serviceRegistry)){
						nodeRefList.add(childNodeRefs);
						}
					}
			    	model.put("totalcount", nodeRefList.size());
					LOGGER.info("noderef list size ::: " +nodeRefList.size());
			    	List<ExtDocument> searchList = getFileFolderList(nodeRefList,hostname);
			    	if(filter==null || filter == ""){
			    		days=30;
			    	}else{
		        	days = Integer.parseInt(filter);
		        	}
			    	if(days > 0  && days !=30){
		              	 toDate = getToDate(days);
		              	} else {
		              	toDate = getToDate(DAYSTOSUBTRACT);
		              }
		        	List<ExtDocument> searchfilterList = filterList(searchList,toDate);
		        	List<ExtDocument> folderlist = new ArrayList<ExtDocument>();
			    	List<ExtDocument> filelist = new ArrayList<ExtDocument>();
			    	List<ExtDocument> finallist = new ArrayList<ExtDocument>();
			    	for (ExtDocument obj : searchfilterList) {
			    		if(obj.getType().equalsIgnoreCase("folder")){
			    			folderlist.add(obj);
			    		}else{
			    			filelist.add(obj);
			    		}
			    	}
			    	if(folderlist!=null && !folderlist.isEmpty()){
			    	if(sortOrder == null || sortOrder == "" || sortOrder.equalsIgnoreCase("asc")){
			    		if (sortBy == null || sortBy == "" || sortBy.equalsIgnoreCase("modified"))
			    			Collections.sort(folderlist, moddateComparator);
			    		else if (sortBy.equalsIgnoreCase("name"))
			    			Collections.sort(folderlist,nameComparator );
			    		else if (sortBy.equalsIgnoreCase("expirationDate"))
			    			Collections.sort(folderlist, expdateComparator);
			    		else if (sortBy.equalsIgnoreCase("size"))
			    			Collections.sort(folderlist, sizeComparator);
			    		else if (sortBy.equalsIgnoreCase("type"))
			    			Collections.sort(folderlist, typeComparator);
			    		else if (sortBy.equalsIgnoreCase("edcsId"))
			    			Collections.sort(folderlist, edcsIdComparator);
			    	}else if (sortOrder != null && sortOrder.equalsIgnoreCase("desc")) {
			    		if (sortBy == null || sortBy == "" || sortBy.equalsIgnoreCase("modified"))
			    			Collections.sort(folderlist, moddateDescComparator);
			    		else if (sortBy.equalsIgnoreCase("name"))
			    			Collections.sort(folderlist,nameDescComparator );
			    		else if (sortBy.equalsIgnoreCase("expirationDate"))
			    			Collections.sort(folderlist, expdateDescComparator);
			    		else if (sortBy.equalsIgnoreCase("size"))
			    			Collections.sort(folderlist, sizeDescComparator);
			    		else if (sortBy.equalsIgnoreCase("type"))
			    			Collections.sort(folderlist, typeDescComparator);
			    		else if (sortBy.equalsIgnoreCase("edcsId"))
			    			Collections.sort(folderlist, edcsIdDescComparator);
			    	}
			    	finallist.addAll(folderlist);
			    	}
			    	if(filelist!=null && !filelist.isEmpty()){
			    		if(sortOrder == null || sortOrder == "" || sortOrder.equalsIgnoreCase("asc")){
				    		if (sortBy == null || sortBy == "" || sortBy.equalsIgnoreCase("modified"))
				    			Collections.sort(filelist, moddateComparator);
				    		else if (sortBy.equalsIgnoreCase("name"))
				    			Collections.sort(filelist,nameComparator );
				    		else if (sortBy.equalsIgnoreCase("expirationDate"))
				    			Collections.sort(filelist, expdateComparator);
				    		else if (sortBy.equalsIgnoreCase("size"))
				    			Collections.sort(filelist, sizeComparator);
				    		else if (sortBy.equalsIgnoreCase("type"))
				    			Collections.sort(filelist, typeComparator);
				    		else if (sortBy.equalsIgnoreCase("edcsId"))
				    			Collections.sort(filelist, edcsIdComparator);
				    	}else if (sortOrder != null && sortOrder.equalsIgnoreCase("desc")) {
				    		if (sortBy == null || sortBy == "" || sortBy.equalsIgnoreCase("modified"))
				    			Collections.sort(filelist, moddateDescComparator);
				    		else if (sortBy.equalsIgnoreCase("name"))
				    			Collections.sort(filelist,nameDescComparator );
				    		else if (sortBy.equalsIgnoreCase("expirationDate"))
				    			Collections.sort(filelist, expdateDescComparator);
				    		else if (sortBy.equalsIgnoreCase("size"))
				    			Collections.sort(filelist, sizeDescComparator);
				    		else if (sortBy.equalsIgnoreCase("type"))
				    			Collections.sort(filelist, typeDescComparator);
				    		else if (sortBy.equalsIgnoreCase("edcsId"))
				    			Collections.sort(filelist, edcsIdDescComparator);
				    	}
				    	finallist.addAll(filelist);
				    	}
			    	  if(sortBy==null || sortBy == ""){
					    	 sortBy = "modified";
					    	 model.put("sortBy", sortBy);
					     }else{
					    	 model.put("sortBy", sortBy);
					     }
			    	  if(sortOrder==null || sortOrder == ""){
			    		  sortOrder = "asc";
					    	 model.put("sortOrder", sortOrder);
					     }else{
					    	 model.put("sortOrder", sortOrder);
					     }
			    	if (pageNo == null || pageNo == "" || pageNo.isEmpty()) {
						pageNum = 1;
						 model.put("pageNo", pageNum);
					} else {
						pageNum = Integer.parseInt(req.getParameter("pageNo"));
						model.put("pageNo", pageNum);
					}
			    	if(pageSize == null || pageSize == "" || pageSize.isEmpty()){
			    	    size = 10;
			    	    model.put("pageSize", size);
			    	}else{
			    		size = Integer.parseInt(pageSize);
			    		model.put("pageSize", size);
			    	}
			    	List<ExtDocument> searchList1;
			    	List<List<ExtDocument>> childList = splitListToSubList(finallist,size);
			    	LOGGER.info("childlist size  ::: " +childList.size());
			    	if(childList.size() == 1){
			    		searchList1 = childList.get(0);
			    		 
			    	}else if(childList.size() < 1){
			    		LOGGER.info("There is no preferences (favorite file/folder) for this user");
			    		model.put("docNoderef", "There is no preferences (favorite file/folder) for this user");
			    	}
			    	searchList1 = childList.get(pageNum-1);
			    	model.put("result", searchList1);
			        List<ExtDocument> folderlist1 = new ArrayList<ExtDocument>();
			    	List<ExtDocument> filelist1 = new ArrayList<ExtDocument>();
			    	for (ExtDocument obj : searchList1) {
			    		if(obj.getType().equalsIgnoreCase("folder")){
			    			folderlist1.add(obj);
			    		}else{
			    			filelist1.add(obj);
			    		}
			    	}
			    	String dateString =sdf.format(cal.getTime());
					
						try {
							enddate = sdf.parse(dateString);
							 dt1 = enddate.getTime();
							
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						long diff = ( dt1- dt);
						long diffSeconds = (diff /1000);
					if(!folderlist1.isEmpty()){
			    	model.put("result1", folderlist1);}
			    	if(!filelist1.isEmpty()){
			    	model.put("result2", filelist1);}
			    	return model;
			    	}else{
			    		LOGGER.info("There is no preferences (favorite file/folder) for this user");
			    		model.put("docNoderef", "There is no preferences (favorite file/folder) for this user");
			    	}
				
		return model;
	    }
	    
	    
	    public List<ExtDocument> getFileFolderList(List<NodeRef> nodeRefList, String hostname)
	    {
			List<ExtDocument> fileFolderList = new ArrayList<ExtDocument>();
	        List<ExtDocument> listFolder = new ArrayList<ExtDocument>();
	        List<ExtDocument> listExtDocs = new ArrayList<ExtDocument>();
	        String logginUser = AuthenticationUtil.getFullyAuthenticatedUser();
	        try
	        {
	            LOGGER.info("nodeRefList Size : " + nodeRefList.size());
	            if (nodeRefList != null && nodeRefList.size() > 0)
	            {
	            for (NodeRef nodeRef : nodeRefList)
	            {
	            	boolean isFolderEmpty = true;
	                final QName type = nodeService.getType(nodeRef);
					if (type.equals(ContentModel.TYPE_FOLDER))
	                {
	                	ExtDocument folder = new ExtDocument();
	                    Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);
	                    String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
	                    fileName = CharUtil.replaceEscape(fileName);
	                    folder.setName(ISO9075.decode(fileName));
                        folder.setNodeId(nodeRef.toString());
                        String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
	                    title = CharUtil.replaceEscape(title);
	                    folder.setTitle(ISO9075.decode(title));
                        String description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
	                    description = CharUtil.replaceEscape(description);
	                    folder.setDescription(ISO9075.decode(description));
                        folder.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
	                    folder.setCreationdate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
	                            .get(ContentModel.PROP_CREATED))));
	                    folder.setModifieddate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
	                            .get(ContentModel.PROP_MODIFIED))));
	                    folder.setType("folder");
	                    Path path = nodeService.getPath(nodeRef);
	                    folder.setApplyVeraProtection((String) nodeProp.get(ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION));
	                    String filePath = "";
	                    if (path != null)
	                    {
	                        filePath = path.toString();
	                        filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/application/1.0\\}", "");
	                        filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "");
	                        filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}", "");
	                    }
	                    folder.setRelativePath(ISO9075.decode(filePath));
	                    folder.setPermissionLevel(ExternalSharingFileFolderUtil.getUserRole(serviceRegistry, logginUser,
	                        nodeRef));
	                    folder.setFolderEmpty(isFolderEmpty);
	                    LOGGER.info("folder empty status :: "+isFolderEmpty);
	                    folder.setFavoriteStatus(true);
	                    
	                 // START : DE1900 - prbadam added for checking if node having different domains.
	                    if(CheckDomain.getDomainStatus(nodeRef.toString()).get("status1") == "401"){
	                   	 LOGGER.info("in if inside 401-------");
	                   	 folder.setDomainMismatch(false);
	                    } else {
	                   	 folder.setDomainMismatch(true);
	                    }
	            	     // END : DE1900 - prbadam added for checking if node having different domains.
	                    
	                  //Tags -  Uthra
	                    String tagName = "";
	                    if(nodeService.hasAspect(nodeRef,ExternalSharingConstants.CISCO_TAG_ASPECT)){
	                    	tagName = (String) nodeService.getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
	               			LOGGER.info("tagName :: " +tagName);
	               		}
	                    folder.setTags(tagName);
	                  // Tags - Uthra
	                    
	                    //prbadam Start: Added for US5491 - Root Folder Creation in Doc Exchange
	            		if(serviceRegistry.getNodeService().hasAspect(nodeRef, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT)){
	            			folder.setCreatedInDocExchange(false);
	            		} else{
	            		folder.setCreatedInDocExchange(true);
	            		}
	            		//prbadam End: Added for US5491 - Root Folder Creation in Doc Exchange
	            		
	            		//uellappa Start: added for US7824 -"Navigate to Folder" option should be available for a document under more action.
	            		
	            		   List<ChildAssociationRef> parentRefs = nodeService.getParentAssocs(nodeRef,ContentModel.ASSOC_CONTAINS, RegexQNamePattern.MATCH_ALL);
	                         if (parentRefs != null && parentRefs.size() > 0)
	                         {
	                             LOGGER.info("parentRefs size....:" + parentRefs.size());
	                             if (parentRefs.size() > 0)
	                             {
	                            	 NodeRef folderId = parentRefs.get(0).getParentRef();
	                            	if(hasPermission(folderId,logginUser, serviceRegistry))
	                            	{
	                            	 folder.setFolderId(folderId.toString());
	                            	 }else{
	                            		 folder.setFolderId("");
	                            	 }
	                                 }
	                             }
	                         
	            		//uellappa End: added for US7824 -"Navigate to Folder" option should be available for a document under more action.
	                    
	                    listFolder.add(folder);
	                   }
	                else
	                {
	                	 if(nodeService.hasAspect(nodeRef, ContentModel.ASPECT_CHECKED_OUT)){
	                		 LOGGER.info("nodeRef ::::::::::::::  "+nodeRef);
	                		 NodeRef workingCopyId =(NodeRef)serviceRegistry.getCheckOutCheckInService().getWorkingCopy(nodeRef);
	          				 LOGGER.info("workingCopyId ::::::::::::::"+workingCopyId);
	          				nodeRef = workingCopyId;
	          				LOGGER.info("nodeRef ::::::::::::::  "+nodeRef);
	                	 }
	                    ExtDocument extDocs = new ExtDocument();
	                    Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);
                        String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
	                    fileName = CharUtil.replaceEscape(fileName);
	                    extDocs.setName(ISO9075.decode(fileName));
                        String Name = ISO9075.decode((String) nodeProp.get(ContentModel.PROP_NAME));
	                    extDocs.setNodeId(nodeRef.toString());
                        String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
	                    title = CharUtil.replaceEscape(title);
	                    extDocs.setTitle(ISO9075.decode(title));
                        String description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
	                    description = CharUtil.replaceEscape(description);
	                    extDocs.setDescription(ISO9075.decode(description));
                        extDocs.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
	                    extDocs.setCreationdate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
	                            .get(ContentModel.PROP_CREATED))));
	                    /*extDocs.setMimetype(((ContentData) nodeService.getProperty(nodeRef, ContentModel.PROP_CONTENT))
	                            .getMimetype());*/
                        String strVersion = (String) nodeProp.get(ContentModel.PROP_VERSION_LABEL);
	                    double version = Double.parseDouble((strVersion != null ? strVersion : "1.0"));
	                    extDocs.setVersion(version);
	                    
	                    
	                    //Added/modified For GCS- Start
                        String tempMimeType = "";
                        boolean issyncedprop = false;
                        if(serviceRegistry.getNodeService().hasAspect(nodeRef,ExternalSharingConstants.CISCO_GLOBAL_CACHING_ASPECT)){
                        	String nodeUploadedGeolocation = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_UPLOAD_GELOLOCATION_PROP);
                        	
                        	if(nodeUploadedGeolocation != null){
                        		issyncedprop = (Boolean) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_IS_FILE_SYNCHED_PROP);
                        	if( !issyncedprop){
                         long size = (Long) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_GCS_TEMP_SIZE);
                         	tempMimeType = (String) serviceRegistry.getNodeService().getProperty(nodeRef,ExternalSharingConstants.CISCO_QNAME_GCS_TEMP_MIMETYPE);
                         	extDocs.setSize((int) (size));
                         	LOGGER.info("size not synced :: " +size + "  tempMimeType :: "+tempMimeType);
                         }
                         else{
                        	 long size = ((ContentData) serviceRegistry.getNodeService().getProperty(nodeRef,
                                     ContentModel.PROP_CONTENT)).getSize();
                                 extDocs.setSize((int) (size));
                         }
                        	}else{
                        		issyncedprop = true;
                        		long size = ((ContentData) serviceRegistry.getNodeService().getProperty(nodeRef,
                                        ContentModel.PROP_CONTENT)).getSize();
                                    extDocs.setSize((int) (size));
                        	}
                        }
                        
                    	else{
                    		LOGGER.info("issynced :: " +issyncedprop);
                    		issyncedprop =  true;
                    		long size = ((ContentData) serviceRegistry.getNodeService().getProperty(nodeRef,
                            ContentModel.PROP_CONTENT)).getSize();
                        extDocs.setSize((int) (size));
                        LOGGER.info("size :: " +size);
                        }
                        extDocs.setSynced(issyncedprop);
                        if(tempMimeType.isEmpty() || tempMimeType == null){
                        	extDocs.setMimetype(((ContentData) nodeService.getProperty(nodeRef, ContentModel.PROP_CONTENT)).getMimetype());
                        }else{
                        	extDocs.setMimetype(tempMimeType);
                        }
                        //Added/modified for Gcs-End
	                    
	                    
	                    
	                    
	                   /* long size = ((ContentData) serviceRegistry.getNodeService().getProperty(nodeRef,
	                        ContentModel.PROP_CONTENT)).getSize();
	                    extDocs.setSize((int) (size));*/
	                    String lockType = (String) nodeProp.get(ContentModel.PROP_LOCK_TYPE);
	                    String edcsId = (String) nodeProp.get(ExternalSharingConstants.PROP_EDCS_ID);
	                    extDocs.setLocked(lockType != null ? true : false);
	                    extDocs.setModifieddate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
	                            .get(ContentModel.PROP_MODIFIED))));
	                    extDocs.setSecurity((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY));
	                    extDocs.setModifier((String) nodeProp.get(ContentModel.PROP_MODIFIER));
	                    extDocs.setType(Name.substring(Name.lastIndexOf(".") + 1, Name.length()));
	                    extDocs.setShareUrl((String) nodeProp.get(ContentModel.PROP_NODE_UUID));
	                    String en_name = ISO9075.encode(fileName);
	                    
	                    /**
                         * Vera protected docs file names allways ends with .html extension to the original filename.
                         * If the document is protected with vera, then append .html extension to the file name
                         */
	                    String downloadUrl = null;
						String nodeUploadedGeolocation = null;
	                    //NodeRef parentNodeRef = nodeService.getPrimaryParent(nodeRef).getParentRef();
	                    String applyVeraProtection = ExternalSharingFileFolderUtil.getFolderVeraProtectionStatus(nodeRef, serviceRegistry);
                        if(applyVeraProtection != null && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))){
                        	extDocs.setApplyVeraProtection(applyVeraProtection);
                        	//downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + en_name + ".html?a=true";
                        } else {
                        	extDocs.setApplyVeraProtection("");
                        	//downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + en_name + "?a=true";
                        }
                        
                        //Uthra GCS  - START
	                    
	                    
	                    if(serviceRegistry.getNodeService().hasAspect(nodeRef,ExternalSharingConstants.CISCO_GLOBAL_CACHING_ASPECT)){
	                    	nodeUploadedGeolocation = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_UPLOAD_GELOLOCATION_PROP);
	              			 LOGGER.info("nodeUploadedGeolocation :: " +nodeUploadedGeolocation);  //ciscoshare-sydney-dev.cisco.com
	              		}
	                   if(nodeUploadedGeolocation != null && hostname != null ){
	                    	boolean issynced = (Boolean) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_IS_FILE_SYNCHED_PROP);
	                    	LOGGER.info("issynced :: " +issynced);
	                    	if(!issynced){
	                    		String redirectUrl = "https://"+nodeUploadedGeolocation;
	                            LOGGER.info("redirectUrl  :: " +redirectUrl); // redirect to the server where it was uploaded
	                            if(applyVeraProtection != null && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))){
	                            	downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + en_name + ".html?a=true";
	                            }else{
	                            downloadUrl = redirectUrl + contextName + "/ext/download/"+ nodeRef.toString().replace(":/", "") + "/" + en_name + "?a=true";
	                            }LOGGER.info("downloadurl in redirction  :: " +downloadUrl);
	                             
	                    	}
	                    	else{
	                    		// its synced so sync central repository
	                    		 if(applyVeraProtection != null && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))){
	                    			 downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + en_name + ".html?a=true";
	                    		 }else{
	                    		 downloadUrl = "https://"+hostname + contextName + "/ext/download/"+ nodeRef.toString().replace(":/", "") + "/" + en_name + "?a=true"; // need to check
	                    		 }
		                    	 LOGGER.info("downloadurl sync value true so download from central repo :: " +downloadUrl);
		 	                    
	                    	}
	                     }
	                    	else {
	                    		 if(applyVeraProtection != null && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))){
	                    			 downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + en_name + ".html?a=true";
	                    		 }else{
		                    	 downloadUrl = alfrescoURL + contextName + "/ext/download/"+ nodeRef.toString().replace(":/", "") + "/" + en_name + "?a=true";
	                    		 }
		                    	 LOGGER.info("downloadurl  :: " +downloadUrl);
		 	                       }
	                  
	                    
	                    //Uthra GCS  - END
	                    
	                    
	                  LOGGER.info("downloadUrl :: " +downloadUrl);
	                    extDocs.setDownloadUrl(downloadUrl);
	                    extDocs.setPermissionLevel(ExternalSharingFileFolderUtil.getUserRole(serviceRegistry, logginUser,
	                        nodeRef));
	                    extDocs.setEdcsId(edcsId);
	                    extDocs.setDocStatus((String) nodeProp.get(ExternalSharingConstants.PROP_DOCSTATUS));
	                    extDocs.setWorkflowStatus((String) nodeProp.get(ExternalSharingConstants.PROP_WORKFLOWSTATUS));
	                    extDocs.setExpirationDate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
	                            .get(ExternalSharingConstants.PROP_EXPIRAIONDATE))));
	                    	                    boolean canUserCancelWorkflow = ExternalSharingFileFolderUtil.canUserCancelWorkflow(serviceRegistry,nodeRef);
	                    extDocs.setCanUserCancelWorkflow(canUserCancelWorkflow);
	                    boolean isPublishedInternally = false;
	                    if(edcsId!= null && edcsId.contains("EDCS-")){
							isPublishedInternally = true; 
						}
	                    extDocs.setExternalyShared(isPublishedInternally);
	                  boolean canUserCancelCheckout = false;
	                    String workingCopyOwner = null;
	                    boolean isCheckedOut = false;
                      if(!nodeService.hasAspect(nodeRef, ContentModel.ASPECT_CHECKED_OUT)){
	                	if(serviceRegistry.getNodeService().hasAspect(nodeRef, ContentModel.ASPECT_WORKING_COPY)){
	            			isCheckedOut = true;
	            			workingCopyOwner = serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_WORKING_COPY_OWNER).toString();
	            		}
	                	if((workingCopyOwner != null && workingCopyOwner.equals(logginUser)) || serviceRegistry.getPermissionService().hasPermission(nodeRef,"AdminRole").toString().equals("ALLOWED")){
	                		canUserCancelCheckout = true;
						}
	                	extDocs.setCheckOutStatus(isCheckedOut);
	                	extDocs.setCanCancelCheckOut(canUserCancelCheckout);
	                	extDocs.setWorkingCopyOwner(workingCopyOwner);
						}
	                	extDocs.setFavoriteStatus(true);
	                	
                    //uellappa Start: added for US7824 -"Navigate to Folder" option should be available for a document under more action.
	            		
	            		
	            		 List<ChildAssociationRef> parentRefs = nodeService.getParentAssocs(nodeRef,ContentModel.ASSOC_CONTAINS, RegexQNamePattern.MATCH_ALL);
	                         if (parentRefs != null && parentRefs.size() > 0)
	                         {
	                             LOGGER.info("parentRefs size....:" + parentRefs.size());
	                             if (parentRefs.size() > 0)
	                             {
	                            	 NodeRef folderId = parentRefs.get(0).getParentRef();
	                            	if(hasPermission(folderId,logginUser, serviceRegistry))
	                            	{
	                            	   extDocs.setFolderId(folderId.toString());
	                            	 }else{
	                            		 extDocs.setFolderId("");
	                            	 }
	                                 }
	                             }
	                         
	            		//uellappa End: added for US7824 -"Navigate to Folder" option should be available for a document under more action.
	                    
	                         // START : DE1900 - prbadam added for checking if node having different domains.
	                         if(CheckDomain.getDomainStatus(nodeRef.toString()).get("status1") == "401"){
	                        	 LOGGER.info("in if inside 401-------");
	                        	 extDocs.setDomainMismatch(false);
	                         } else {
	                        	 extDocs.setDomainMismatch(true);
	                         }
	                 	     // END : DE1900 - prbadam added for checking if node having different domains.
	                         
	                         //Tags -  Uthra
	                         String tagName = "";
	                         if(nodeService.hasAspect(nodeRef,ExternalSharingConstants.CISCO_TAG_ASPECT)){
	                         	tagName = (String) nodeService.getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
	                    			LOGGER.info("tagName :: " +tagName);
	                    		}
	                         
	                        	 
	                        	extDocs.setTags(tagName);
	                       // Tags - Uthra
	                         
	                	 listExtDocs.add(extDocs);
	                 
	                }
	            }
	            fileFolderList.addAll(listFolder);
	            fileFolderList.addAll(listExtDocs);
	        }
	        }
	        catch (InvalidQNameException e)
	        {
	            e.printStackTrace();
	        }
	        catch (InvalidNodeRefException e)
	        {
	            e.printStackTrace();
	        }
	        catch (Exception e)
	        {
	            e.printStackTrace();
	        }
	        return fileFolderList;
	    }
	    
	    public static boolean hasPermission(final NodeRef docNodeRef, final String logginUser, final ServiceRegistry serviceRegistry) {
	    	boolean currentUserHasGroupMember = false;
			if (logginUser.equals("admin")) {
				return true;
			}
           Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
           accessPermission=AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Set<AccessPermission>>() {
				Set<AccessPermission> userSetPermissions = new HashSet<AccessPermission>();
				@Override
				public Set<AccessPermission> doWork() throws Exception {
					userSetPermissions.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(docNodeRef));
					return userSetPermissions;
				}
			}, "admin");
			if (accessPermission.size() > 0) {
				for (AccessPermission accessPermissionObj : accessPermission) {
					final String userIdOrMemberOfGroupId = accessPermissionObj.getAuthority();
					LOGGER.info("user : " + userIdOrMemberOfGroupId);
					if(userIdOrMemberOfGroupId.contains(GROUP_IDENTITY)){
	                	if (accessPermissionObj.getPermission() != null
	    						&& accessPermissionObj.getPermission().equals("SiteAdmin")
	    						|| accessPermissionObj.getPermission().equals("SiteEditor")
	    						|| accessPermissionObj.getPermission().equals("SiteReader")
	    						|| accessPermissionObj.getPermission().equals("SiteOwner")
	    						|| accessPermissionObj.getPermission().equals("SiteManager")
	    						|| accessPermissionObj.getPermission().equals("ReadPermissions")
	    						|| accessPermissionObj.getPermission().equals("SiteViewer")) {
	                		//LOGGER.info("inside if authority permissions------" +accessPermission.getPermission());
	    				} else{
	    					//LOGGER.info("groupId : " + userIdOrMemberOfGroupId);
	                	currentUserHasGroupMember = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
	       				  @Override
	       				  public Boolean doWork() throws Exception {
	       					boolean currentUserIsGroupMember=false;
	     					  if(userIdOrMemberOfGroupId!= null && !userIdOrMemberOfGroupId.equalsIgnoreCase(GROUP_EVERYONE)){
	     					currentUserIsGroupMember=serviceRegistry.getAuthorityService().getAuthoritiesForUser(logginUser).contains(userIdOrMemberOfGroupId);
	     					  }
	     					 return currentUserIsGroupMember;
	       				  }
	       				  }, "admin");
	                	LOGGER.info("currentUserHasGroupMember of accessPermission.getAuthorityType : " + currentUserHasGroupMember);
	                }
	                }
					//ToDo : need to write one more level validation that only editor and above level should allow to checkout the doc
					if (userIdOrMemberOfGroupId.equals(logginUser) || currentUserHasGroupMember) {
						return true;
					}
				}
			}

			return false;
		}
	   
	    private String getToDate(int daysToSubtract)
	    {
	        Calendar c = Calendar.getInstance();
	        c.add(Calendar.DATE, -daysToSubtract);
	        SimpleDateFormat formatedDate = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
	        String toDate = formatedDate.format(c.getTime());
	        return toDate.toString();
	    }
		
		public static List splitListToSubList(List<ExtDocument> parentList, int pageSize) {
			List<List<ExtDocument>> childList = new ArrayList<List<ExtDocument>>();
			List<ExtDocument> tempList = new ArrayList<ExtDocument>();
	        int count = 0;
	        if (parentList != null) {
	            for (ExtDocument obj : parentList) {
	                if (count < pageSize) {
	                    count = count + 1;
	                    tempList.add(obj);
	                } else {
	                    childList.add(tempList);
	                    tempList = new ArrayList<ExtDocument>();
	                    tempList.add(obj);
	                    count = 1;
	                }
	 
	            }
	            if (tempList.size() <= pageSize) {
	                childList.add(tempList);
	            }
	        }
	        return childList;
	    }

		
		public static Set<AccessPermission> getAllNodeRefPermissions(final ServiceRegistry serviceRegistry, final NodeRef nodeRef){
	    	final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
		   	 AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
					@Override
					public Object doWork() throws Exception {
						accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef));
						return null;
					}
		   	 }, "admin");
	    	return accessPermission;
	    }
		
		public List<ExtDocument> filterList(List<ExtDocument> parentlist, String todate) 
	    {
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm z");  // dd/MM/yyyy HH:mm z
		List<ExtDocument> filteredList = new ArrayList<ExtDocument>();
		for(int i=0;i<parentlist.size();i++){
			ExtDocument moddate=parentlist.get(i);
			String result = moddate.getModifieddate();
			try {
				Date date1 = formatter.parse(result);
				Date date2 = formatter.parse(todate);
				if(date1.equals(date2) || date1.after(date2)){
					 filteredList.add(moddate);
					 	}
				    else{
				    	LOGGER.info("unable to add to list (filter changes).....");
				    }
			} catch (ParseException e) {
				e.printStackTrace();
			}
		   }
		   return filteredList;
	 }
		  
		
		
		public static Comparator<ExtDocument> moddateDescComparator = new Comparator<ExtDocument>() {
		     @Override
		        public int compare(ExtDocument o1, ExtDocument o2)
		        {
		    	 int result = 0;
				   try {
					   Date sourceDate = formatter.parse(o1.getModifieddate());
						long sourceDate1Long = sourceDate.getTime();
						
						Date targetDate = formatter.parse(o2.getModifieddate());
						long targetDate2Long = targetDate.getTime();
						
						result= Long.compare(targetDate2Long, sourceDate1Long);
					} catch (ParseException e) {
						e.printStackTrace();
					}
					return result;
			    }
	       };
	       
	      		
		    public static Comparator<ExtDocument> moddateComparator = new Comparator<ExtDocument>() {
			    @Override
			    public int compare(ExtDocument o1, ExtDocument o2)
			    {
			    	int result = 0;
					   try {
						   Date sourceDate = formatter.parse(o1.getModifieddate());
							long sourceDate1Long = sourceDate.getTime();
							
							Date targetDate = formatter.parse(o2.getModifieddate());
							long targetDate2Long = targetDate.getTime();
							
							result= Long.compare(sourceDate1Long, targetDate2Long);
						} catch (ParseException e) {
							e.printStackTrace();
						}
						return result;
				    }
			};
			
			public static Comparator<ExtDocument> createddateDescComparator = new Comparator<ExtDocument>() {
			     @Override
			        public int compare(ExtDocument o1, ExtDocument o2)
			        {
			    	 int result = 0;
					   try {
						   Date sourceDate = formatter.parse(o1.getCreationdate());
							long sourceDate1Long = sourceDate.getTime();
							
							Date targetDate = formatter.parse(o2.getCreationdate());
							long targetDate2Long = targetDate.getTime();
							
							result= Long.compare(targetDate2Long, sourceDate1Long);
						} catch (ParseException e) {
							e.printStackTrace();
						}
						return result;
				    }
		       };
		      		
			    public static Comparator<ExtDocument> createddateComparator = new Comparator<ExtDocument>() {
				    @Override
				    public int compare(ExtDocument o1, ExtDocument o2)
				    {
				    	int result = 0;
						   try {
							   Date sourceDate = formatter.parse(o1.getCreationdate());
								long sourceDate1Long = sourceDate.getTime();
								
								Date targetDate = formatter.parse(o2.getCreationdate());
								long targetDate2Long = targetDate.getTime();
								
								result= Long.compare(sourceDate1Long, targetDate2Long);
							} catch (ParseException e) {
								e.printStackTrace();
							}
							return result;
					    }
				};

			public static Comparator<ExtDocument> titleComparator = new Comparator<ExtDocument>() {
				public int compare(ExtDocument o1, ExtDocument o2)
			    {
			    	 String title1 = o1.getTitle();
				     String title2 = o2.getTitle();
				     if ((title1 == null && title2 == null) || (title1 == "" && title2 == "")) {
				            return 0;
				        }
				        if (title1 == null || title1 == "" || title1.isEmpty()) {
				            return -1;
				        }
				        if (title2 == null || title2 =="" || title2.isEmpty()) {
				            return 1;
				        }
				     return title1.toLowerCase().compareTo(title2.toLowerCase());// ascending order  
				 }
				};
			
				public static Comparator<ExtDocument> titleDescComparator = new Comparator<ExtDocument>() {
					public int compare(ExtDocument o1, ExtDocument o2)
				    {
				    	    String title1 = o1.getTitle();
					        String title2 = o2.getTitle();
					        if ((title1 == null && title2 == null) || (title1 == "" && title2 == "")) {
					            return 0;
					        }
					        if (title1 == null || title1 == "" || title1.isEmpty()) {
					            return -1;
					        }
					        if (title2 == null || title2 =="" || title2.isEmpty()) {
					            return 1;
					        }return title2.toLowerCase().compareTo(title1.toLowerCase()); // descending order 
					        }
					};
					
					public static Comparator<ExtDocument> nameComparator = new Comparator<ExtDocument>() {
						public int compare(ExtDocument o1, ExtDocument o2)
					    {
					    	 String name1 = o1.getName();
						     String name2 = o2.getName();
						     if ((name1 == null && name2 == null) || (name1 == "" && name2 == "")) {
						            return 0;
						        }
						        if (name1 == null || name1 == "" || name1.isEmpty()) {
						            return -1;
						        }
						        if (name2 == null || name2 =="" || name2.isEmpty()) {
						            return 1;
						        }
						     return name1.toLowerCase().compareTo(name2.toLowerCase());// ascending order  
						 }
						};
					
						public static Comparator<ExtDocument> nameDescComparator = new Comparator<ExtDocument>() {
							public int compare(ExtDocument o1, ExtDocument o2)
						    {
						    	    String name1 = o1.getName();
							        String name2 = o2.getName();
							        if ((name1 == null && name2 == null) || (name1 == "" && name2 == "")) {
							            return 0;
							        }
							        if (name1 == null || name1 == "" || name1.isEmpty()) {
							            return -1;
							        }
							        if (name2 == null || name2 =="" || name2.isEmpty()) {
							            return 1;
							        }return name2.toLowerCase().compareTo(name1.toLowerCase()); // descending order 
							        }
							};
					
					public static Comparator<ExtDocument> expdateDescComparator = new Comparator<ExtDocument>() {
						public int compare(ExtDocument o1, ExtDocument o2) {
							int result=0;
							String date1 = o1.getExpirationDate();
							String date2 = o2.getExpirationDate();
							 if ((date1 == null && date2 == null) || (date1 == "" && date2 =="")) {
						            return 0;
						        }
						        if (date1 == null || date1 == "" || date1.isEmpty()) {
						            return -1;
						        }
						        if (date2 == null || date2 == "" || date2.isEmpty()) {
						            return 1;
						        }try {
									result= formatter.parse(date2).compareTo(formatter.parse(date1));
								} catch (ParseException e) {
									e.printStackTrace();
								}
								return result; 
						    }
												
						};
						
						public static Comparator<ExtDocument> expdateComparator = new Comparator<ExtDocument>() {
							public int compare(ExtDocument o1, ExtDocument o2) {
								int result=0;
								String date1 = o1.getExpirationDate();
								String date2 = o2.getExpirationDate();
								 if ((date1 == null && date2 == null) || (date1 == "" && date2 =="")) {
							            return 0;
							        }
							        if (date1 == null || date1 == "" || date1.isEmpty()) {
							            return -1;
							        }
							        if (date2 == null || date2 == "" || date2.isEmpty()) {
							            return 1;
							        }try {
										result= formatter.parse(date1).compareTo(formatter.parse(date2));
									} catch (ParseException e) {
										e.printStackTrace();
									}
									return result; 
							    }};
					
	       public static Comparator<ExtDocument> typeComparator = new Comparator<ExtDocument>() {
			    @Override
			    public int compare(ExtDocument o1, ExtDocument o2)
			    {
			            return o1.getType().toLowerCase().compareTo(o2.getType().toLowerCase()); //ascending order
			    }
			};
			
			public static Comparator<ExtDocument> typeDescComparator = new Comparator<ExtDocument>() {
			    @Override
			    public int compare(ExtDocument o1, ExtDocument o2)
			    {
					 	return o2.getType().toLowerCase().compareTo(o1.getType().toLowerCase()); //descending order
			    }
			};
			
			public static Comparator<ExtDocument> sizeComparator = new Comparator<ExtDocument>() {
			    @Override
			    public int compare(ExtDocument o1, ExtDocument o2)
			    {
			    	return (o1.getSize() - o2.getSize());
			    }
			};
			
			public static Comparator<ExtDocument> sizeDescComparator = new Comparator<ExtDocument>() {
				@Override
			    public int compare(ExtDocument o1, ExtDocument o2)
			    {
					return (o2.getSize() - o1.getSize());
			    }
			};
			
			public static Comparator<ExtDocument> edcsIdComparator = new Comparator<ExtDocument>() {
				 public int compare(ExtDocument o1, ExtDocument o2) {
					 String edcsId1 = o1.getEdcsId();
				        String edcsId2 = o2.getEdcsId();
				        if ((edcsId1 == null && edcsId2 == null) || (edcsId1 == "" && edcsId2 == "")) {
				            return 0;
				        }
				        if (edcsId1 == null || edcsId1 == "" || edcsId1.isEmpty()) {
				            return -1;
				        }
				        if (edcsId2 == null || edcsId2 =="" || edcsId2.isEmpty()) {
				            return 1;
				        }return edcsId1.compareTo(edcsId2); // ascending order 
				        }
					};
			
			public static Comparator<ExtDocument> edcsIdDescComparator = new Comparator<ExtDocument>() {
				public int compare(ExtDocument o1, ExtDocument o2) {
			        String edcsId1 = o1.getEdcsId();
			        String edcsId2 = o2.getEdcsId();
			        if ((edcsId1 == null && edcsId2 == null) || (edcsId1 == "" && edcsId2 == "")) {
			            return 0;
			        }
			        if (edcsId1 == null || edcsId1 == "" || edcsId1.isEmpty()) {
			            return -1;
			        }
			        if (edcsId2 == null || edcsId2 =="" || edcsId2.isEmpty()) {
			            return 1;
			        }return edcsId2.compareTo(edcsId1); // descending order 
			        }
			};
			private String getParameter(WebScriptRequest req, String paramName)
		    {
		        String value = "";
		        if (req.getParameter(paramName) != null)
		        {
		            value = req.getParameter(paramName).trim();
		        }
		        return value;
		    }
			
		public static String hostValidation(String hostname){
		    	boolean isHostValid = false;
		    	try {
					JSONParser parser = new JSONParser();
					Object obj = parser.parse(new FileReader(geoServerLocation));
					JSONObject jsonObject = (JSONObject) obj;
				    JSONArray hostArray = (JSONArray) jsonObject.get("Hosts");
				    LOGGER.info("hostArray.size():::::  " +hostArray.size()); 
				        for(int i=0;i<hostArray.size();i++){
							JSONObject hostObject =(JSONObject)hostArray.get(i);
							String host = (String) hostObject.get("hostname");
							LOGGER.info("host ::::::::::: " +host);
							if(host.equalsIgnoreCase(hostname)){
								isHostValid = true;
							}
                        }
				        LOGGER.info("isHostValid   ::: "+isHostValid);
				        if(!isHostValid){
                        	hostname = alfrescoURL.replaceAll("https://", "");
                        }
				        LOGGER.info("final hostname ::: "+hostname);
				} catch (Exception e) {
					LOGGER.error("Exception is ::"+ e.getStackTrace(), e);
				}
				return hostname;
			}
		    
}