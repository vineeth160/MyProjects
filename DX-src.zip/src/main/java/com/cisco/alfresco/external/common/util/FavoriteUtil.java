package com.cisco.alfresco.external.common.util;

import java.util.ArrayList;
import java.util.List;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.namespace.RegexQNamePattern;
import org.apache.log4j.Logger;

/**
 * 
 * @author prbadam - For add,view and delete Favorite 
 * 
 */

public class FavoriteUtil {

	 	private static final Logger LOGGER = Logger.getLogger(FavoriteUtil.class);
	 	final static String CISCO_MODEL_URI = "http://www.cisco.com/model/content/1.0";
	    final static String CISCO_MODEL_URI_CM = "http://www.alfresco.org/model/content/1.0";
	    static QName ASSOC_NAME_MYFAVORITE_ASSOCIATE = QName.createQName(CISCO_MODEL_URI, "myFavorite");
	    static QName ASPECT_MYFAVORITEDOCS = QName.createQName(CISCO_MODEL_URI, "FavAspect"); 

	    // Adding to favorite 
	public static void addFavorite(final ServiceRegistry serviceRegistry,BehaviourFilter policyFilter,String currentLoginUserName,String isFavorite,final NodeRef nodereff){
		
		LOGGER.info("inside FavoriteUtil addFavorite method----");
		final NodeRef personNodereff=serviceRegistry.getPersonService().getPerson(currentLoginUserName);
		LOGGER.info("Person nodereff   ::" +personNodereff);
	    
	    	if(Boolean.TRUE.toString().equals(isFavorite)){
	    		LOGGER.info("inside if---------");
	    		try{
		        	   policyFilter.disableBehaviour(nodereff, ContentModel.ASPECT_AUDITABLE);
	               	if (serviceRegistry.getNodeService().hasAspect(personNodereff, ASPECT_MYFAVORITEDOCS) == false)
	   	              {
	               		serviceRegistry.getNodeService().addAspect(personNodereff, ASPECT_MYFAVORITEDOCS, null);
	 	   	 			serviceRegistry.getNodeService().addChild(personNodereff, nodereff, ASSOC_NAME_MYFAVORITE_ASSOCIATE, QName.createQName(CISCO_MODEL_URI_CM, nodereff.getId()));
	   	              }  
	   	          else{
	   	        	serviceRegistry.getNodeService().addChild(personNodereff, nodereff, ASSOC_NAME_MYFAVORITE_ASSOCIATE, QName.createQName(CISCO_MODEL_URI_CM, nodereff.getId()));
		   	            }
	   	 		
		        	   }finally{
		        		   policyFilter.enableBehaviour(nodereff, ContentModel.ASPECT_AUDITABLE);
		        	   }
	    		LOGGER.info("Favorite added successfully---");
	    }
	}
	
	//Getting favorite status is True or False 
	public static boolean favoriteStstus(ServiceRegistry serviceRegistry,String currentLoginUserName,NodeRef nodereff){
		
		LOGGER.info("inside FavoriteUtil favoriteStstus method----");
		 boolean isFavorite = false;
		 NodeRef personNodereff=serviceRegistry.getPersonService().getPerson(currentLoginUserName);
		 final List<NodeRef> customFablist = new ArrayList<NodeRef>();
         List<ChildAssociationRef> childAssocList = serviceRegistry.getNodeService().getChildAssocs(personNodereff,ASSOC_NAME_MYFAVORITE_ASSOCIATE,RegexQNamePattern.MATCH_ALL);
         if(childAssocList.size() >0){
         	for (ChildAssociationRef child : childAssocList){ 
             NodeRef childNodeRef = child.getChildRef();
             customFablist.add(childNodeRef);
             }
         }
          isFavorite = customFablist.contains(nodereff);
          return isFavorite;
	}
	
	
	// Editing favorite 
	public static void editFavorite(ServiceRegistry serviceRegistry,BehaviourFilter policyFilter,String currentLoginUserName,String isFavorite,NodeRef nodereff){
		
		LOGGER.info("inside FavoriteUtil editFavorite method----"+isFavorite);
		if(isFavorite == "true"){
			LOGGER.info("isFavorite is true----");
			//START : DE3261
			NodeRef personNodereff=serviceRegistry.getPersonService().getPerson(currentLoginUserName);
			LOGGER.info("Person nodereff   ::" +personNodereff);

			List<ChildAssociationRef> childAssocList = serviceRegistry.getNodeService().getChildAssocs(personNodereff, ASSOC_NAME_MYFAVORITE_ASSOCIATE,RegexQNamePattern.MATCH_ALL);
			List<NodeRef> childNodeRefs = new ArrayList<NodeRef>();
			
			if (childAssocList != null && !childAssocList.isEmpty()) {
				LOGGER.debug("child list:"+childAssocList.size());
				for (ChildAssociationRef child : childAssocList) {
					NodeRef childNodeRef = child.getChildRef();
					childNodeRefs.add(childNodeRef);
				}
				LOGGER.debug("childnodeRefs size"+childNodeRefs.size());
				if (!childNodeRefs.isEmpty()) {
					if (!(childNodeRefs.contains(nodereff))){
						addFavorite(serviceRegistry, policyFilter, currentLoginUserName, isFavorite, nodereff);
						LOGGER.debug("folder added to Fav list");
					}else{
						LOGGER.debug("Already it was Favorite");
					}
				}
			}else {
				addFavorite(serviceRegistry, policyFilter, currentLoginUserName, isFavorite, nodereff);
				LOGGER.debug("folder added to Fav list");
			}
			//END : DE3261
			//addFavorite(serviceRegistry, policyFilter, currentLoginUserName, isFavorite, nodereff);
		} else {
			LOGGER.info("isFavorite is false----");
		 NodeRef personNodereff=serviceRegistry.getPersonService().getPerson(currentLoginUserName);
		 List<ChildAssociationRef> childAssocList = serviceRegistry.getNodeService().getChildAssocs(personNodereff,ASSOC_NAME_MYFAVORITE_ASSOCIATE,RegexQNamePattern.MATCH_ALL);

		 try{
		 policyFilter.disableBehaviour(nodereff, ContentModel.ASPECT_AUDITABLE);
      	if(childAssocList.size() >1){
   		for (ChildAssociationRef child : childAssocList){ 
			NodeRef childNodeRef = child.getChildRef();
			if(childNodeRef.equals(nodereff)){
				serviceRegistry.getNodeService().removeChildAssociation(child);
			break;
			}
		}
   	}else if(childAssocList.size()==1){
   		for (ChildAssociationRef child : childAssocList){ 
   			NodeRef childNodeRef = child.getChildRef();
   			if(childNodeRef.equals(nodereff)){
   				serviceRegistry.getNodeService().removeChildAssociation(child);
   				serviceRegistry.getNodeService().removeAspect(personNodereff, ASPECT_MYFAVORITEDOCS);
   			break;
   			}
       	}
   	}
       LOGGER.info("Successfully Removed from Fav list-----");
       }
		 finally{
       policyFilter.enableBehaviour(nodereff, ContentModel.ASPECT_AUDITABLE);
		 }
	}
	}
	
}
