package com.cisco.alfresco.external.ExportToExcel;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.VerticalAlignment;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.auth.ext.EXTEncrypter;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;

public class ExportPermissionsToExcel extends AbstractWebScript{
	private static final Logger LOGGER = Logger.getLogger(ExportPermissionsToExcel.class);
	private ServiceRegistry serviceRegistry;
	private ExternalLDAPUtil ldapUtil;
	private WritableCellFormat timesBoldUnderline;
	static final String LDAP_SEARCHBASE = "ou=ccoentities,o=cco.cisco.com";
    static final String LDAP_MAIL_ATTRIBUTES = "mail";// "uid";
    static final String LDAP_UID_ATTRIBUTES = "uid";
    static final String LDAP_CN_ATTRIBUTES = "cn";
    static final String LDAP_COMPANY_ATTRIBUTES = "company";
    public static final String INITCTX = "com.sun.jndi.ldap.LdapCtxFactory";
    public static final String INITFACTORY="java.naming.factory.initial";
    static final String LDAP_DISPLAY_NAME_ATTRIBUTES ="displayName";
	private static final String GROUP_IDENTITY ="GROUP_";
	private static String LDAP_AUTHENTICATION_SIMPLE="simple";
	private static String CISCO_DOMAIN="@cisco.com";
	private static String CISCO_DOMAI_ID="cisco.com";
	private String mailerGroupsLdapHost;// "ldap://ds.cisco.com:389";
	private String mailerGroupsGenericUser;
	private String mailerGroupsGenericPwd;
	private String mailerGroupsGenericKey;
	private String mailerGroupsLdapSearchBase;
	public String getMailerGroupsLdapSearchBase() {
		return mailerGroupsLdapSearchBase;
	}

	public void setMailerGroupsLdapSearchBase(String mailerGroupsLdapSearchBase) {
		this.mailerGroupsLdapSearchBase = mailerGroupsLdapSearchBase;
	}
    public String getMailerGroupsLdapHost() {
		return mailerGroupsLdapHost;
	}

	public void setMailerGroupsLdapHost(String mailerGroupsLdapHost) {
		this.mailerGroupsLdapHost = mailerGroupsLdapHost;
	}

	public String getMailerGroupsGenericUser() {
		return mailerGroupsGenericUser;
	}

	public void setMailerGroupsGenericUser(String mailerGroupsGenericUser) {
		this.mailerGroupsGenericUser = mailerGroupsGenericUser;
	}

	public String getMailerGroupsGenericPwd() {
		return mailerGroupsGenericPwd;
	}

	public void setMailerGroupsGenericPwd(String mailerGroupsGenericPwd) {
		this.mailerGroupsGenericPwd = mailerGroupsGenericPwd;
	}

	public String getMailerGroupsGenericKey() {
		return mailerGroupsGenericKey;
	}

	public void setMailerGroupsGenericKey(String mailerGroupsGenericKey) {
		this.mailerGroupsGenericKey = mailerGroupsGenericKey;
	}
	public ExternalLDAPUtil getLdapUtil() {
		return ldapUtil;
	}

	public void setLdapUtil(ExternalLDAPUtil ldapUtil) {
		this.ldapUtil = ldapUtil;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res)
	{
		String nodeId = req.getParameter("nodeId");
		String currentUserName = AuthenticationUtil.getFullyAuthenticatedUser();
		LOGGER.info("nodeId :: " +nodeId + "   currentUserName :: " +currentUserName);
		NodeRef nodeRef = new NodeRef(nodeId);
		LOGGER.info("Calling canUserHavePermission method......");
		boolean isAdmin = canUserHavePermission(nodeRef,currentUserName,serviceRegistry);
		//only FolderAdmin can export the permissions to excel file
		if(isAdmin){
			//Hashtable<String, String> userPermissionTable = getUsersPermissionsOnNodeRef(nodeRef);
			exportPermissions(nodeRef,res);
		}
	}
	
	public void exportPermissions(final NodeRef nodeRef,final WebScriptResponse res)
	{
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
				{
					@Override
					public Object doWork() throws Exception
					{
						// creating workbook
		                 WritableWorkbook workbook = null;
		                 Label lable = null;
		                 int userIdColumn = 0;
						 int firstNameColumn = 1;
		                 int lastNameColumn = 2;
		                 int companyColumn = 3;
		                 int emailColumn = 4;
		                 int roleColumn = 5;
		                 int permissionTypeColumn=6;
		                 int row = 3;
		                 String name = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NAME);
                         WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);
                         OutputStream os = res.getOutputStream();
	                     workbook = Workbook.createWorkbook(os);
	                     WritableSheet wSheet1 = workbook.createSheet("Export Permissions To Excel", 0);
	                     WritableCellFormat cellFormat = new WritableCellFormat(times10ptBoldUnderline);
	                     cellFormat.setAlignment(Alignment.CENTRE);
	                     cellFormat.setVerticalAlignment(VerticalAlignment.CENTRE);
	                     timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
	                     timesBoldUnderline.setWrap(true);
	                     wSheet1.insertColumn(userIdColumn); 
	     				 lable = new Label(0, 2, "User ID",timesBoldUnderline);
	     				 wSheet1.addCell(lable);
						 wSheet1.insertColumn(firstNameColumn); 
	     				 lable = new Label(1, 2, "First Name",timesBoldUnderline);
	     				 wSheet1.addCell(lable);
	     				 wSheet1.insertColumn(lastNameColumn); 
	     				 lable = new Label(2, 2, "Last Name",timesBoldUnderline);
	     				 wSheet1.addCell(lable);
	     				 wSheet1.insertColumn(companyColumn); 
	     				 lable = new Label(3, 2, "Company",timesBoldUnderline);
	     				 wSheet1.addCell(lable);
	     				 wSheet1.insertColumn(emailColumn); 
	     				 lable = new Label(4, 2, "Email",timesBoldUnderline);
	     				 wSheet1.addCell(lable);
	     				 wSheet1.insertColumn(roleColumn); 
	     				 lable = new Label(5, 2, "Role",timesBoldUnderline);
	     				 wSheet1.addCell(lable);
	     				 wSheet1.insertColumn(permissionTypeColumn); 
	     				 lable = new Label(6, 2, "Permission Type",timesBoldUnderline);
	     				 wSheet1.addCell(lable);
	     				 wSheet1. setColumnView(0, 35);
						 wSheet1. setColumnView(1, 20);
	     				 wSheet1. setColumnView(2, 20);
	     				 wSheet1. setColumnView(3, 25);
	     				 wSheet1. setColumnView(4, 25);
	     				 wSheet1. setColumnView(5, 15);
	     				 wSheet1. setColumnView(6, 15);
	     				 wSheet1.mergeCells(userIdColumn, 0, permissionTypeColumn, 0);
	                     lable = new Label(0, 0, "Folder/File Name: "+name, timesBoldUnderline);
	                     wSheet1.addCell(lable);
	                     wSheet1.mergeCells(userIdColumn, 1, permissionTypeColumn, 1);
	                     lable = new Label(0, 1, "Permission", cellFormat); //.setAlignment(Alignment.CENTRE)
	                     wSheet1.addCell(lable);
	     				 // Getting all the the direct permissions on the noderef. 
	     				Iterator<AccessPermission> fIterator;
	     				Set<AccessPermission> accessPermissions1 = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
	     				List<String> userLocalPermission = new ArrayList<String>();
	     				fIterator = accessPermissions1.iterator();
	     				
	     				while (fIterator.hasNext()) {
	     					AccessPermission accessPermission = (AccessPermission) fIterator.next();
	     					if (accessPermission.getPermission() != null
	     							&& accessPermission.getPermission().equals("SiteAdmin")
	     							|| accessPermission.getPermission().equals("SiteEditor")
	     							|| accessPermission.getPermission().equals("SiteReader")
	     							|| accessPermission.getPermission().equals("SiteOwner")
	     							|| accessPermission.getPermission().equals("SiteManager")
	     							|| accessPermission.getPermission().equals("SiteViewer")) {
	     						LOGGER.info("inside if authority permissions------" +accessPermission.getPermission());
	     					} 
	     					else
	     					{
	     						if ((accessPermission.getAuthorityType() == AuthorityType.USER || accessPermission.getAuthorityType() == AuthorityType.GROUP) && accessPermission.isSetDirectly()) {
	     						String autherityUserName = accessPermission.getAuthority();
	     						userLocalPermission.add(autherityUserName);
                                LOGGER.info("inside group or user ser directly ...." +autherityUserName);
	     					}
	     					}
	     				}
	     				//for(Map.Entry entry: userPermissionTable.entrySet())
						Iterator<AccessPermission> fIterator1;
	     				Set<AccessPermission> accessPermissionss = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
	     				fIterator1 = accessPermissionss.iterator();
	     				//LOGGER.info("userLocalPermission :: " +userLocalPermission.size()  + "--userLocalPermission :: " +userLocalPermission.toString() );
	     				while (fIterator1.hasNext()) {
	     					String domain = "" , userName = "" , userRole = "";
	     					String email = null;String company = null;String firstName = null;String lastName = null;
	     					boolean docExPermission = true;
	     					AccessPermission accessPermission = (AccessPermission) fIterator1.next();
	     					if (accessPermission.getAuthorityType() == AuthorityType.USER || accessPermission.getAuthorityType() == AuthorityType.GROUP) {
	     						if (accessPermission.getPermission() != null
	     								&& accessPermission.getPermission().equals("SiteAdmin")
	     								|| accessPermission.getPermission().equals("SiteEditor")
	     								|| accessPermission.getPermission().equals("SiteReader")
	     								|| accessPermission.getPermission().equals("SiteOwner")
	     								|| accessPermission.getPermission().equals("SiteManager")
	     								|| accessPermission.getPermission().equals("SiteViewer")) {
	     							docExPermission = false;
	     						}
	     						userName = accessPermission.getAuthority();	
	     						userRole = accessPermission.getPermission();
								userName = userName != null ? userName : "";
	     						userRole = userRole != null ? userRole : "";
	     					}
	     					//LOGGER.info("name ::" +userName + "role :: " +userRole);
	     					if(docExPermission && !userName.isEmpty() && !userRole.isEmpty()){
							if(userName.contains(GROUP_IDENTITY) && !userName.isEmpty() && !userRole.isEmpty()){
							//LOGGER.info("GROUP  :: " +userName);
							boolean isDoc = serviceRegistry.getDictionaryService().isSubClass(serviceRegistry.getNodeService().getType(nodeRef), ContentModel.TYPE_CONTENT);
					        if (!isDoc)
				            {
				                domain = (String) serviceRegistry.getNodeService().getProperty(nodeRef,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"));
				            }
				            else
				            {
				                ChildAssociationRef childAssociationRef = serviceRegistry.getNodeService().getPrimaryParent(nodeRef);
				                NodeRef parentNodeRef = childAssociationRef.getParentRef();
				                domain = (String) serviceRegistry.getNodeService().getProperty(parentNodeRef,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"));
				            }
				            if (domain != null && !domain.isEmpty() && !domain.contains("cisco.com"))
				            {
				                domain = domain + ",cisco.com";
				            }
				            email = getGroupEmailIdFromLDAP(userName,nodeRef,domain,"grouper");
				            LOGGER.info("email :: "+email);
				           // userName= userName.replace("GROUP_", "");
				            if(email == "" && email.isEmpty()){
				            LOGGER.info("if email is empty...."+userName.replace("GROUP_", "")+"@cisco.com");
				            email = userName.replace("GROUP_", "") +"@cisco.com"; 
				            }
				            company="";
				            lable = new Label(userIdColumn, row, userName);
	     					wSheet1.addCell(lable);
	     					}
							if(!userName.contains(GROUP_IDENTITY) && !userName.isEmpty()  && !userRole.isEmpty()){
	     					NodeRef personNode=serviceRegistry.getPersonService().getPerson(userName);
	     					email = (String) serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_EMAIL);
	     					company = (String) serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_ORGANIZATION);
	     					firstName = (String) serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_FIRSTNAME);
	     					lastName = (String) serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_LASTNAME);
	     					lable = new Label(userIdColumn, row, userName);
	     					wSheet1.addCell(lable);
							lable = new Label(firstNameColumn, row, firstName);
	     					wSheet1.addCell(lable);
	     					lable = new Label(lastNameColumn, row, lastName);
	     					wSheet1.addCell(lable);
	     					}
	     					if (userRole.equalsIgnoreCase("ViewerRole")) {
								userRole = "Viewer";
                            } else if (userRole.equalsIgnoreCase("ReaderRole")) {
								userRole = "Reader";
                            } else if (userRole.equalsIgnoreCase("EditorRole")) {
								userRole = "Editor";
                            } else if (userRole.equalsIgnoreCase("OwnerRole")) {
								userRole = "Owner";
                            } else if (userRole.equalsIgnoreCase("AdminRole")) {
								userRole = "Folder Admin";
                            }
	     					if(!userName.isEmpty() && !userRole.isEmpty()){
	     					lable = new Label(companyColumn, row, company);
	     					wSheet1.addCell(lable);
	     					lable = new Label(emailColumn, row, email);
	     					wSheet1.addCell(lable);
	     					lable = new Label(roleColumn, row, userRole);
	     					wSheet1.addCell(lable);
                            if(userLocalPermission.contains(userName) && accessPermission.isSetDirectly()){
                            	lable = new Label(permissionTypeColumn, row, "Local");
    	     					wSheet1.addCell(lable);
    	     					
	     					}else{
	     						lable = new Label(permissionTypeColumn, row, "Inherited");
    	     					wSheet1.addCell(lable);
    	     					LOGGER.info("userName :: " +userName+ "  type :: Inherited   userRole :: " +userRole+ "  email :: " +email+ "  company :: " +company+ "  firstName ::  " +firstName);
	     					}
                            }
	     					row++;
	     					}
	     				}
	     				workbook.write();
                        workbook.close();
                        res.addHeader("Content-Disposition", "attachment;filename=ExportPermissionsToExcel.xls");
                        res.setContentType("application/vnd.ms-excel");
                        res.setContentEncoding("UTF-8");
                        res.setHeader("Cache-Control", "private, max-age=0");
                        LOGGER.info("Excel File Downloaded Successfully...");
                        return null;
						
					}
				},"admin");
	}
	
	/**
	 * This method will return table with UserName as a key and UserRole as a value
	 * 
	 */
	public Hashtable<String, String> getUsersPermissionsOnNodeRef(NodeRef nodeRef)
	{
		Hashtable<String, String> userPermission = new Hashtable<String, String>();
		Iterator<AccessPermission> fIterator;
		Set<AccessPermission> accessPermissions1 = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
		fIterator = accessPermissions1.iterator();
		while (fIterator.hasNext()) {
			AccessPermission accessPermission = (AccessPermission) fIterator.next();
			if (accessPermission.getAuthorityType() == AuthorityType.USER || accessPermission.getAuthorityType() == AuthorityType.GROUP) {
				if (accessPermission.getPermission() != null
						&& accessPermission.getPermission().equals("SiteAdmin")
						|| accessPermission.getPermission().equals("SiteEditor")
						|| accessPermission.getPermission().equals("SiteReader")
						|| accessPermission.getPermission().equals("SiteOwner")
						|| accessPermission.getPermission().equals("SiteManager")
						|| accessPermission.getPermission().equals("SiteViewer")) {
					LOGGER.info("inside if authority permissions------" +accessPermission.getPermission());
				} else{
				String autherityUserName = accessPermission.getAuthority();
				String autherityUserPermission = accessPermission.getPermission();
				userPermission.put(autherityUserName,autherityUserPermission);
			}
			}
		}
		return userPermission;
		
	}
	
	/**
	 * This method will check whether the user is having FolderAdmin permission(AdminRole) on the folder or file
	 * 
	 */
	private boolean canUserHavePermission(NodeRef nodeRef,String currentUserName,ServiceRegistry serviceRegistry) {
		boolean canPermission = false;
		Iterator<AccessPermission> fIterator;
		final QName type = serviceRegistry.getNodeService().getType(nodeRef);
		if (type.equals(ContentModel.TYPE_FOLDER)) {
			Set<AccessPermission> accessPermissions =serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
			fIterator = accessPermissions.iterator();
		} else {
			ChildAssociationRef childAssociationRef = serviceRegistry.getNodeService().getPrimaryParent(nodeRef);
			NodeRef parentNoderef = childAssociationRef.getParentRef();
            Set<AccessPermission> accessPermissions = serviceRegistry.getPermissionService().getAllSetPermissions(parentNoderef);
			fIterator = accessPermissions.iterator();
        }
        while (fIterator.hasNext()) {
			AccessPermission accessPermission = (AccessPermission) fIterator.next();
            if (accessPermission.getAuthorityType() == AuthorityType.USER) {
                String autherityUserName = accessPermission.getAuthority();
				String autherityUserPermission = accessPermission.getPermission();
				if (autherityUserName.equals(currentUserName)&& autherityUserPermission.equals("AdminRole")) {
					return true;
				}
			}
		}
		return canPermission;
	}
	
	
	/**
  	 * provides a User Object with LDAP details filled in for the specified user
  	 * login name
  	 * **/
      @SuppressWarnings("unchecked")
	public String getGroupEmailIdFromLDAP(String grouperName,NodeRef node,String domain,String searchType) {
  		String domainFilter = "";
  		String grouperMail = "";
  		try {
  			LOGGER.info("calling getGroupEmailIdFromLDAP... ");
  			 if (domain != null && !domain.equals(""))
  	            {
  				//considering only cisco domain for groups
  				if(domain.contains(CISCO_DOMAI_ID)){
  	  				domainFilter="(mail=" + CISCO_DOMAI_ID + ")";
  	  			}else{
  	  			String[] domainList = domain.split(",");
  	                for (int p = 0; p < domainList.length && domainList.length > 0; p++)
  	                {
  	                    domainFilter = domainFilter + "|(mail=*@" + domainList[p].trim() + "*)";
  	                }
  	  			}
  	              LOGGER.info("search domainFilter after splitting ::: "+domainFilter);
  	            }
  	            String myFilter = null;
  	            if (!domainFilter.equals(""))
  	            {
  	                if (grouperName != null && !grouperName.equals(""))
  	                {
  	                	grouperName = grouperName.trim();
  		                if (!grouperName.contains(" ")) 
  		                {
  		                	if(domain.contains(CISCO_DOMAI_ID)){
  	  		                	myFilter = "(|(&(" + domainFilter + "))(&(cn=" + grouperName+ "*)))";
  	  		                	}else{
  	  		                		myFilter = "(&(" + domainFilter + ")(|(cn="+grouperName+"*)))";
  	  		                	}
  		                	LOGGER.info("search group Filter without space ::: "+myFilter);
  		                } 
  		                else 
  		                {	// checking if grouperName contains space
  		                	String groupDisplayName = grouperName.substring(0, grouperName.indexOf(" "));
  		                	if(domain.contains(CISCO_DOMAI_ID)){
  	  		                	myFilter = "(|(&(" + domainFilter + "))(&(displayName=" + groupDisplayName+ "*)))";
  	  		                	}else{
  	  		                		myFilter = "(&(" + domainFilter + ")((|(cn=" +groupDisplayName + "*))&(displayName="+ groupDisplayName+"*)))";
  	  		                	}
  		                	LOGGER.info("search group with space  ::::  "+myFilter);
  						} // End of checking if grouperName contains space
  	                }
  	                else
  	                {
  	                    myFilter = "(&(" + domainFilter + ")(cn=*))";
  	                  LOGGER.info("inside else grouperName is null  ::::  "+myFilter);
  	                }
  	            }
  	            else
  	            {
  	            	if (!grouperName.contains(" ")) 
	                {
            		 myFilter = "(|(cn="+grouperName+"*)|(displayName="+grouperName+"*))";
	                }else{
	                String formatedGroupName = grouperName.substring(0, grouperName.indexOf(" "));
	                myFilter = "(|(cn="+formatedGroupName+"*)|(displayName="+formatedGroupName+"*))";
	                }
  	            	LOGGER.info("inside else domainFilter is null  ::::  "+myFilter);
  	            }
  	            LOGGER.info("Final LDAP group search filter :::  " + myFilter);
  	        Hashtable myEnv = new Hashtable<String, String>();
  			myEnv.put(INITFACTORY, INITCTX);                                //"com.sun.jndi.ldap.LdapCtxFactory"
  			myEnv.put(Context.PROVIDER_URL, getMailerGroupsLdapHost());    //"ldap://ds.cisco.com:389"
  			myEnv.put(Context.SECURITY_AUTHENTICATION,LDAP_AUTHENTICATION_SIMPLE );
			myEnv.put(Context.SECURITY_PRINCIPAL, getMailerGroupsGenericUser());
			myEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(getMailerGroupsGenericPwd(), getMailerGroupsGenericKey()).getBytes("UTF8"));
  			DirContext myDirContext = new InitialDirContext(myEnv);
  			SearchControls mySearchControls = new SearchControls();
  			mySearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
  			String[] searchReturningAttributes = null;
  			searchReturningAttributes = new String[] { "description", "displayName", "member", "cn","company","mail"};
  			mySearchControls.setReturningAttributes(searchReturningAttributes);
  			LOGGER.info("Connecting & Searching from LDAP...: ");
  			NamingEnumeration<SearchResult> mySearchResults = null;
			mySearchResults = myDirContext
	  					.search(getMailerGroupsLdapSearchBase(), myFilter, mySearchControls);
  			LOGGER.info("Iterating LDAP searched resutlset...: ");
  			while (mySearchResults != null && mySearchResults.hasMore()) {
			LOGGER.info("if search results not null");
  				Attributes attrs = ((SearchResult) mySearchResults.next()).getAttributes();
  				LOGGER.info("attrs  :: " +attrs.size());
  				if (attrs != null && attrs.size()>0) {
  						String groupName = attrs.get("cn").get().toString();
  						LOGGER.info("groupName ::: " + groupName);
  						if(attrs.get("mail")==null){
  							grouperMail =attrs.get("cn").get().toString()+CISCO_DOMAIN;
  						}else{
  							grouperMail =attrs.get("mail").get().toString();
  						}
  						LOGGER.info("grouperMail ::: " + grouperMail);
  						/*String company = "";
  						if(attrs.get("company") != null ){
  						company = attrs.get("company").get().toString();
  						}
  						LOGGER.info("company--- " + company);
  						if (company != null && company.equals("0")) {
  							company = "";
  						}
  						if (company != null && company.contains(",")) {
  							company = company.replaceAll(",", "");
  						}*/
  						}
  				
  			}

  			myDirContext.close();
  		} catch (Exception e) {
  			LOGGER.error("group search exception.." + e.getMessage());
  			e.printStackTrace();
  			return grouperMail;
  		}
  		return grouperMail;
  	}
      
	

}
