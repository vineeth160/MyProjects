package com.cisco.alfresco.external.common.model;



/**
 * 
 * @author nabbeher
 * 
 */
public class Asset
{

    String name;
    String nodeId;
    String title;
    String description;
    String owner;
    String creationdate;
    String modifieddate;

    String modifier;
    String type;
    String permissionLevel;

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getNodeId()
    {
        return nodeId;
    }

    public void setNodeId(String nodeId)
    {
        this.nodeId = nodeId;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getOwner()
    {
        return owner;
    }

    public void setOwner(String owner)
    {
        this.owner = owner;
    }

    public String getCreationdate()
    {
        return creationdate;
    }

    public void setCreationdate(String creationdate)
    {
        this.creationdate = creationdate;
    }

    public String getModifieddate()
    {
        return modifieddate;
    }

    public void setModifieddate(String modifieddate)
    {
        this.modifieddate = modifieddate;
    }

    public String getModifier()
    {
        return modifier;
    }

    public void setModifier(String modifier)
    {
        this.modifier = modifier;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public String getPermissionLevel()
    {
        return permissionLevel;
    }

    public void setPermissionLevel(String permissionLevel)
    {
        this.permissionLevel = permissionLevel;
    }

}
