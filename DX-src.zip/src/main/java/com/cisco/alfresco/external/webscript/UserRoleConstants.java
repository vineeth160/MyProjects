package com.cisco.alfresco.external.webscript;

public class UserRoleConstants
{

    public static String USER_ADMIN_ROLE = "Folder Admin";
    
}
