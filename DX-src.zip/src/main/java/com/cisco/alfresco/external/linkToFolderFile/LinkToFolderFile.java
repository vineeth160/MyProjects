package com.cisco.alfresco.external.linkToFolderFile;

import java.io.IOException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.TemplateService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.edcsng.util.MailUtil;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.manageMailerGroups.MailerGroupSearchUtil;

/**
 * 
 * @author prbadam - US5736 & US5737.
 * 
 */
public class LinkToFolderFile extends DeclarativeWebScript
{
    private static final Logger LOGGER = Logger.getLogger(LinkToFolderFile.class);
    private ServiceRegistry serviceRegistry = null;
    private String mailServer;
    private TemplateService templateService;
 //   private String ftlLocationPath;
    private ExternalLDAPUtil ldapUtil;
    private String bannerAlfrescoUrl;
	private String titleURL; 
	private static final String GROUP_IDENTITY ="GROUP_";
	private MailerGroupSearchUtil mailerGroupLdapUtil;
	private String[] STRING_ARRAY_MIMETYPE = {"jpeg","jpg","bmp","png","tiff","doc","docx","xls","xlsx","ppt","pptx","txt","html","odt","odp","ods"}; 
	private static final String CISCO_MAILID="@cisco.com"; 
	
    public String getBannerAlfrescoUrl() {
		return bannerAlfrescoUrl;
	}

	public void setBannerAlfrescoUrl(String bannerAlfrescoUrl) {
		this.bannerAlfrescoUrl = bannerAlfrescoUrl;
	}

	public String getTitleURL() {
		return titleURL;
	}

	public void setTitleURL(String titleURL) {
		this.titleURL = titleURL;
	}

	public ExternalLDAPUtil getLdapUtil() {
		return ldapUtil;
	}

	public void setLdapUtil(ExternalLDAPUtil ldapUtil) {
		this.ldapUtil = ldapUtil;
	}

	/*public String getFtlLocationPath() {
		return ftlLocationPath;
	}

	public void setFtlLocationPath(String ftlLocationPath) {
		this.ftlLocationPath = ftlLocationPath;
	}
*/
	public static String LINK_TO_FILE_FOLDER_TEMPLATE = "/alfresco/extension/templates/email/linkToFileFolderNotificationTemplate.ftl";
    
    public String getMailServer() {
		return mailServer;
	}

	public void setMailServer(String mailServer) {
		this.mailServer = mailServer;
	}

	
    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }
    public MailerGroupSearchUtil getMailerGroupLdapUtil() {
		return mailerGroupLdapUtil;
	}

	public void setMailerGroupLdapUtil(MailerGroupSearchUtil mailerGroupLdapUtil) {
		this.mailerGroupLdapUtil = mailerGroupLdapUtil;
	}
	/**
	 * 
	 * @param req
	 * @return
	 */
	private String readRequestBody(WebScriptRequest req) {
		try {
			return IOUtils.toString(req.getContent().getInputStream(), req
					.getContent().getEncoding());
		} catch (Exception e) {
			try {
				return req.getContent().getContent();
			} catch (IOException e1) {
				LOGGER.error("Unable to read JSON request body", e1);
				throw new WebScriptException(
						"Unable to read JSON request body!! Epic fail.");
			}
		}
	}
  
	  @SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
	    {
		  	Map<String, Object> model = new HashMap<String, Object>();
		  	Map<String, Object> viewerModel = new HashMap<String, Object>();
			String inputJSONValue = readRequestBody(req);
			JSONObject jsonObject = null;
			String docComments=null, nodeId=null;
			JSONArray usersList=null;
			ArrayList viewerUsersList=new ArrayList<String>();
			ArrayList readerAboveUsersList=new ArrayList<String>();
			ArrayList folderUsersList=new ArrayList<String>();
			List viewerUsersListEmailIds=new ArrayList<String>();
			List readerAboveUsersListEmailIds=new ArrayList<String>();
			List folderUsersListEmailIds=new ArrayList<String>();
			Set<String> viewerRoleTo = null;
			Set<String> aboveViewerRoleTo = null;
			Set<String> onFolderTo = null;
			HashMap<String, String> permissionsLabelInfo = new HashMap<String, String>();
			try {
				jsonObject = new JSONObject(inputJSONValue);
				nodeId = jsonObject.getString("nodeId");
				docComments = jsonObject.getString("comment");
				usersList = jsonObject.getJSONArray("userIDs");
				NodeRef nodeRef = new NodeRef(nodeId);
				boolean isDocument = serviceRegistry.getDictionaryService().isSubClass(serviceRegistry.getNodeService().getType(nodeRef), ContentModel.TYPE_CONTENT);
	        	LOGGER.info("isDocument-------------"+isDocument);
				LOGGER.info("nodeRef-------"+nodeRef + "-------docComments-------"+docComments+"------usersList-----"+usersList);
				permissionsLabelInfo=getNodeUserPermissions(nodeRef.toString());
				LOGGER.info("usersList length ::: "+usersList.length());
				if(isDocument){
				for(int i=0;i<usersList.length();i++){
				if(permissionsLabelInfo.containsKey(usersList.get(i))){
		        	String permissionValue=permissionsLabelInfo.get(usersList.get(i)).toString();
		        	if(LOGGER.isDebugEnabled()){
		        	LOGGER.debug("permissionValue ::: "+permissionValue);
		        	}
		        	 if(permissionValue.equals("ViewerRole")){
		        		 String username= usersList.get(i).toString();	
		        		 LOGGER.info("username ::: "+username);
		        		 viewerUsersList.add(username);
		        	 }else{
			        	 String otherUsername=usersList.get(i).toString();
			        	 LOGGER.info("otherUsername ::: "+otherUsername);
				        	readerAboveUsersList.add(otherUsername);
				        }
		        }
				}
				LOGGER.info("viewerUsersList-------"+viewerUsersList.toString() +"readerAboveUsersList::::  "+readerAboveUsersList.toString());
				viewerUsersListEmailIds=getUserEmailIds(viewerUsersList);
				readerAboveUsersListEmailIds=getUserEmailIds(readerAboveUsersList);
				}else{
					for(int i=0;i<usersList.length();i++){
						 String username= usersList.get(i).toString();
						 folderUsersList.add(username);
					}
					folderUsersListEmailIds=getUserEmailIds(folderUsersList);
				}
				
				 LOGGER.info("Link to file send mail for viewerUsersListEmailIds :: "+viewerUsersListEmailIds.toString());
				 LOGGER.info("Link to file send mail for readerAboveUsersListEmailIds :: "+readerAboveUsersListEmailIds.toString());
				 LOGGER.info("Link to file send mail for viewerUsersListEmailIds :: "+folderUsersListEmailIds.toString());
				 
				//  NodeRef template = getEmailtemplate(LINK_TO_FILE_FOLDER_TEMPLATE);
				  templateService = serviceRegistry.getTemplateService();
				  String publisher =  AuthenticationUtil.getFullyAuthenticatedUser();
				  LOGGER.info("publisher---------"+publisher);
				  Date currentDate = new Date();
				  String year = new SimpleDateFormat("yyyy").format(currentDate); 
		          NodeRef publisherNode = serviceRegistry.getPersonService().getPerson(publisher);
		          String publisherFirstName = (String) serviceRegistry.getNodeService().getProperty(publisherNode,ContentModel.PROP_FIRSTNAME);
		          String publisherLastName = (String) serviceRegistry.getNodeService().getProperty(publisherNode,ContentModel.PROP_LASTNAME);
		          String creator  = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_CREATOR);
		          String creatorEmailId  = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_EMAIL);
		          String publisherMailId = (String) serviceRegistry.getNodeService().getProperty(publisherNode,ContentModel.PROP_EMAIL);
		          String DocName = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NAME);
		          String subject = publisherFirstName+" "+publisherLastName+" shared a "+DocName+" on Doc Exchange";
		          String cc = null;
		            if(!creator.equals(publisher)){
		                cc = creatorEmailId;
		            }
		        	  if(isDocument){
		        		  String docuuid = nodeRef.getId();
		        		  Boolean isDocVeraProtected = (Boolean)serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.PROP_IS_DOCUMENT_VERA_PROTECTED);
		        		  String security = (String)serviceRegistry.getNodeService().getProperty(nodeRef, CiscoModelConstants.CISCO_SECURITY_PROP);
		        		  String downloadUrl = null;
		        		  if((isDocVeraProtected != null && isDocVeraProtected) || "Cisco Restricted".equals(security)){
		        			  downloadUrl=titleURL+"/alfext/ext/download/workspace/SpacesStore/"+nodeRef.getId()+"/"+URLEncoder.encode(DocName+".html","UTF-8").replaceAll("\\+", "%20")+"?a=true";
		        		  } else {
		        			  downloadUrl=titleURL+"/alfext/ext/download/workspace/SpacesStore/"+nodeRef.getId()+"/"+URLEncoder.encode(DocName,"UTF-8").replaceAll("\\+", "%20")+"?a=true";
		        		  }
		        		  LOGGER.info("Node id Document-------------"+nodeRef.toString() + " ;url : " + downloadUrl);
		        		  String  downloadConstantMsg ="<span style='color:#6683BF;text-decoration: none;'><a href="+downloadUrl+">Click here</a></span> to DOWNLOAD the file to your desktop";
		        		  LOGGER.info(" Document download url -------------"+downloadConstantMsg);
		        		  
		        		String previewUrl = titleURL+"/alfext/ui/c/file/preview/"+docuuid;
		        		String previewConstantMsg = "<span style='color:#6683BF;text-decoration: none;'><a href="+previewUrl+">Click here</a></span> to PREVIEW the file in your browser";		
		        		  // prbadam Start - DE3013
		        		  // getting mime type from file name
		        		  String docType = DocName.substring(DocName.lastIndexOf(".")+1,DocName.length());
		        		  LOGGER.info("docType----"+docType);
		        		  List<String> listArrayType = new ArrayList<String>();
		  				  Collections.addAll(listArrayType, STRING_ARRAY_MIMETYPE);
		        		  if(listArrayType.contains(docType)){
		        			  model.put("downloadURL", downloadConstantMsg);
		        			  model.put("nodeURL", previewConstantMsg);
			        		  viewerModel.put("nodeURL", previewConstantMsg);
		        		  } else {
		        			  model.put("downloadURL", downloadConstantMsg);
		        			  model.put("nodeURL", "");
			        		  viewerModel.put("nodeURL", "");
		        		  }
		        		  // prbadam End - DE3013
		            	  model.put("folderMsg", "");
		            	  viewerModel.put("downloadURL", "");
		            	  viewerModel.put("folderMsg", "");
		                } else{
		                	LOGGER.info("folder noderef-------------"+nodeRef);
		                	 String uuid = nodeRef.getId();
		                	 String  folderConstantMsg =  "Please click <span style='color:#6683BF;'><a href='"+titleURL+"/alfext/ui/c/whatsnew'>here</a></span> to access Doc Exchange.";
		                	 String libraryUrl = titleURL+"/alfext/ui/c/library/"+uuid;
		                	 String libraryContentMsg = "<span style='color:#6683BF;text-decoration: none;'><a href="+libraryUrl+">Click here</a></span> to view this folder";
		                	 model.put("nodeURL", libraryContentMsg);
		                	 model.put("downloadURL", "");
		                	 model.put("folderMsg", folderConstantMsg);
		                }
		            model.put("docName", DocName);
		            viewerModel.put("docName", DocName);
		            if(docComments == null || docComments.isEmpty() || docComments == ""){
					    model.put("docComments", "No Comments");
					    viewerModel.put("docComments", "No Comments");
					} else {
						model.put("docComments", docComments);
						viewerModel.put("docComments", docComments);
					}
		            model.put("publisher", publisherFirstName+" "+publisherLastName);
		            model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
		            model.put("year", year); 
		            viewerModel.put("publisher", publisherFirstName+" "+publisherLastName);
		            viewerModel.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
		            viewerModel.put("year", year); 
		            
		            if(isDocument){
		            String htmlBody = templateService.processTemplate(LINK_TO_FILE_FOLDER_TEMPLATE, model);
		            String htmlBodyViewer = templateService.processTemplate(LINK_TO_FILE_FOLDER_TEMPLATE, viewerModel);
		            //commented to fix for send email to each users individually 
		            //MailUtil.sendMail(mailServer,publisherMailId, vieweToMany,cc, subject, htmlBodyViewer,null);
		            //MailUtil.sendMail(mailServer,publisherMailId, toMany,cc, subject, htmlBody,null);
		            viewerRoleTo = new HashSet<String>(viewerUsersListEmailIds);
					aboveViewerRoleTo = new HashSet<String>(readerAboveUsersListEmailIds);
					 LOGGER.info("Link to file send mail for viewerRoleTo :: "+viewerRoleTo);
					 LOGGER.info("Link to file send mail for aboveViewerRoleTo :: "+aboveViewerRoleTo);
					
					 if(viewerRoleTo.size()>0){
						 for (String viewerRoleToEmailId : viewerRoleTo){
							 MailUtil.sendMail(mailServer,publisherMailId, viewerRoleToEmailId,cc, subject, htmlBodyViewer,null);
					        }
					 }
					 if(aboveViewerRoleTo.size()>0){
						 for (String aboveViewerRoleToEmailId : aboveViewerRoleTo){
							 MailUtil.sendMail(mailServer,publisherMailId, aboveViewerRoleToEmailId,cc, subject, htmlBody,null);
					        }
					 }
		            }else{
		            String htmlBody = templateService.processTemplate(LINK_TO_FILE_FOLDER_TEMPLATE, model);
		            //commented to fix for send email to each users individually 
		            //MailUtil.sendMail(mailServer,publisherMailId, folderToMany,cc, subject, htmlBody,null);
		            onFolderTo = new HashSet<String>(folderUsersListEmailIds);
		            LOGGER.info("Link to file send mail for onFolderTo :: "+onFolderTo);
		            if(onFolderTo.size()>0){
						 for (String onFolderToEmailId : onFolderTo){
							 MailUtil.sendMail(mailServer,publisherMailId, onFolderToEmailId,cc, subject, htmlBody,null);
					        }
					 }
		            }
		            LOGGER.info("Link to file folder Mail sent successfully---------");
		            model.put("finalstatus", "Mail sent successfully.");
			}// End of try
			 catch (Exception e) {
					LOGGER.info("in e---------"+e.getStackTrace());
					model.put("finalstatus", "Error while sending mail.");
				}
			return model ;
	    }
	  
	  /**
	     * To Get Email Template
	     */
	 /*   private NodeRef getEmailtemplate(String templateName)
	    {
	        String templateConditionalPath = "PATH:\"" + ftlLocationPath + "//*\" AND "
	                + "TYPE:cm\\:content AND @cm\\:name:\"" + templateName + "\"";
	        LOGGER.debug("LUCENE QRY: " + templateConditionalPath);
	        ResultSet resultSet = serviceRegistry.getSearchService().query(
	            new StoreRef(StoreRef.PROTOCOL_WORKSPACE, "SpacesStore"), SearchService.LANGUAGE_LUCENE,
	            templateConditionalPath);
	        if (resultSet.length() == 0)
	        {
	        	LOGGER.error("Template " + templateConditionalPath + " not found.");
	            return null;
	        }
	        NodeRef template = resultSet.getNodeRef(0);
	        LOGGER.debug("Got the Email Template:" + template.toString());
	        return template;
	    }
	    */
	    /**
	     * To Get User Email Id's
	     */
	    @SuppressWarnings({ "rawtypes", "unused"})
	    private List<String> getUserEmailIds(ArrayList usersList)
	    {
	    	List<String> emailIds = new ArrayList<String>();
	    	String  userIdOrGroupID = null;
	    	try{
	    	 for (int i = 0 ; i < usersList.size(); i++) {
			        userIdOrGroupID = usersList.get(i).toString();
			        LOGGER.info("userIdOrGroupID---------"+userIdOrGroupID);
			        if(userIdOrGroupID.toString().contains(GROUP_IDENTITY)){
		        		LOGGER.info("== group Id in share link ====" + userIdOrGroupID);
		        		String groupId = userIdOrGroupID.replace(GROUP_IDENTITY, "");
		        		LOGGER.info("== group Id after trim in share link ====" + groupId);
						// DE3303 prbadam start
						Map<String, Set<String>> members = mailerGroupLdapUtil.getGroupMembers(groupId);
						for( Entry<String, Set<String>> curGroup : members.entrySet() ) {
							LOGGER.info("list of the members---"+ curGroup);
							for( String childName : curGroup.getValue() ){
								String userEmail = ldapUtil.getManagerEmailFromLDAP(childName);
								if(userEmail!=null && userEmail!="" && userEmail.contains(CISCO_MAILID)){
									emailIds.add(userEmail);
								}
							}
						}
						// DE3303 prbadam end
		        		/*String groupDetails = mailerGroupLdapUtil.getGroupDetails(groupId);
		        		LOGGER.info("== groupDetails in share link ====" + groupDetails);
		        		String groupEmailId = groupDetails.split("::")[2];
		        		LOGGER.info("== group mailId in share link ====" + groupEmailId);*/
		        		//emailIds.add(groupEmailId);
		        	}else{
			        if(emailIds.isEmpty()){
			        		LOGGER.info("== user Id in sharelink ==" + userIdOrGroupID);
			        	String genUserDetails = ldapUtil.getGenericUserDetailsFromLDAP(userIdOrGroupID);
			        	 emailIds.add(ldapUtil.getManagerEmailFromLDAP(userIdOrGroupID));
	                     LOGGER.info("emailIds--in if----" + emailIds);
	                     if(emailIds == null || emailIds.isEmpty())
	                        {
	                    	 if(genUserDetails != null && !genUserDetails.isEmpty())
					        	{
		                    		LOGGER.info("genUserDetails ====" + genUserDetails);
		                    		String email = (genUserDetails.split("::"))[3];
	                                LOGGER.info("emailId =" + email);
	                                emailIds.add(email);
	                                LOGGER.info("emailIds--in generic if----" + emailIds);
						        }
	                    	 else{
	                    		 //emailIds="";
	                    		 LOGGER.error("user("+userIdOrGroupID+") email id was not there in LDAP..So,just skipped this user");
	                    	 }
	                        }
			       // }
			        	}
                 else{
                     String genUserDetails = ldapUtil.getGenericUserDetailsFromLDAP(userIdOrGroupID);
                 	String emailid = ldapUtil.getManagerEmailFromLDAP(userIdOrGroupID);
                 	LOGGER.info("emailIds--in else----" + emailIds +  " emailid ----->>" +emailid);
	                    if (emailid == null)
	                    {
	                    	if(genUserDetails != null && !genUserDetails.isEmpty()){
	                        	   LOGGER.info("genUserDetails =" + genUserDetails);
		                    		String email = (genUserDetails.split("::"))[3];
	                               LOGGER.info("emailId =" + email);
	                               emailIds.add(email);
	                               LOGGER.info("emailIds--in generic if(else)----" + emailIds);
						        }
	                    	else{
	                    		
		               	    	LOGGER.error("user("+userIdOrGroupID+") email id was not there in LDAP..So,just skipped this user or group");
	                    	}
	                    }else{
	                    	emailIds.add(emailid);
	                    	LOGGER.info("emailIds--in else----" + emailIds);
	                    }
                 }
		    }
	    	 }
	    	}catch(Exception ex){
	    		LOGGER.info("exception is ::::: " + ex.getMessage());
	    		ex.printStackTrace();
	    	}
	    	LOGGER.info(" final user emailIds ::: " + emailIds.toString());
			return emailIds;
	    }
	    
	    
	    
	    /**
	     * To Get User permissions for document/folder
	     */
	    private HashMap<String, String> getNodeUserPermissions(final String nodeRefId){
			  
			  HashMap<String, String> permissionsInfo = new HashMap<String, String>();
			  try{
				  final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
				  AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				  @Override
				  public Object doWork() throws Exception {
					  NodeRef nodeRef = new NodeRef(nodeRefId);
					  accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef));
					  return null;
				  	}
				  }, "admin");

				  if (accessPermission.size() > 0) {
				  for (AccessPermission accessPermissionObj : accessPermission) {
					  permissionsInfo.put(accessPermissionObj.getAuthority(), accessPermissionObj.getPermission().toString());
				  }
				  }   
			  }catch(Exception exe){
				  LOGGER.error("Get Node User Permissions Exception : " + exe.getMessage());
			  }
			  LOGGER.info("permissionsInfo ::::: "+permissionsInfo.toString());
			  return permissionsInfo;
		  }
}
