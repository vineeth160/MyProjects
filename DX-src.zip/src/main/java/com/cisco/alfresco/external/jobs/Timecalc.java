package com.cisco.alfresco.external.jobs;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.sql.Timestamp;

import org.alfresco.repo.workflow.WorkflowModel;

public class Timecalc {

	public static void main(String[] args) throws ParseException {
		
		

		 Date date= new Date();
		 
		 long time = date.getTime();
		// System.out.println("Time in Milliseconds: " + time);
	     Timestamp ts = new Timestamp(time);
		 //System.out.println("Current Time Stamp: " + ts);
		
		/*public static String getGMTDateFormat(Date date){
			DateFormat df;
			String formatedDate="";
			try{
			df = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));
			if(date != null){
			formatedDate=df.format(date);
			}
			}catch(Exception e){
			LOGGER.error("Exception....."+e);
			}
			return formatedDate;
			}*/
		
		//Date requestDate = ((Date) taskProp.get(WorkflowModel.PROP_START_DATE));
		//Date date = new Date();
        DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
        Date reqdate = formatter.parse("03/18/2020 12:45 IST"); //Wed Mar 18 07:15:13 EDT 2020
        System.out.println(reqdate);
        //LOGGER.info("RequestDate>>>"+reqdate);
        formatter.setTimeZone(TimeZone.getTimeZone("EST"));
        String fdate = formatter.format(reqdate);
        System.out.println("shcds"+fdate);
        
         Date now = new Date();
       // Date date1=new SimpleDateFormat("MM/dd/yyyy HH:mm z").parse(now);
        System.out.println(now);
        //Wed Aug 28 19:04:41 IST 2019
       // Date dformatter = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy").parse(now.toString());
        //System.out.println(dformatter);
        //Date reqdate = dformatter.parse(now.toString());
       // System.out.println(reqdate);
       
       // String demo_date1 = "09/16/2019 23:47 EDT ";
        String demo_date1 = "09/17/2019 12:55 EDT ";
        
       Date date1=new SimpleDateFormat("MM/dd/yyyy HH:mm z").parse(demo_date1); 
        
       String demo_date2 = "09/16/2019 21:46 PDT ";
      // String demo_date1 = "09/16/2019 21:55 PDT ";
        
        Date date2=new SimpleDateFormat("MM/dd/yyyy HH:mm z").parse(demo_date2); 
        
        //System.out.println(date1);
        DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
        //df.setTimeZone(TimeZone.getTimeZone("GMT"));
       // System.out.println("Current date and time in GMT: " + df.format(date1));
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        System.out.println("now Current date and time in EDT: " + df.format(date1));


        df.setTimeZone(TimeZone.getTimeZone("GMT"));
       System.out.println("Current date and time in PDT: " + df.format(date2));
        
       /* df.setTimeZone(TimeZone.getTimeZone("PDT"));
        //System.out.println("Current date and time in PST: " + df.format(now));
        
        df.setTimeZone(TimeZone.getTimeZone(""));
        //System.out.println("Current date and time in UST: " + df.format(now));
        
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        System.out.println("Current date and time in GMT: " + df.format(date1));
        

        df.setTimeZone(TimeZone.getTimeZone("EST/EDT"));
        //System.out.println("Current date and time in EST: " + df.format(now));
        
        
        */
        
        
        
        
        
/*		java.text.SimpleDateFormat sourceFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");

	    java.text.SimpleDateFormat gmtFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm z");

	    java.util.Date date1 = sourceFormat.parse("08/22/2019 09:38");

	    TimeZone gmtTime = TimeZone.getTimeZone("GMT");

	    gmtFormat.setTimeZone(gmtTime);

	    System.out.println("Source date: " + date1);

	    System.out.println("gmt:" + gmtFormat.format(date1));	*/
		
		//
		
		/*Date date = new Date();
		
	    DateFormat gmtFormat = new SimpleDateFormat();
	    TimeZone gmtTime = TimeZone.getTimeZone("GMT");
	    gmtFormat.setTimeZone(gmtTime);
	    System.out.println("Current Time: "+date);
	    System.out.println("GMT Time: " + gmtFormat.format(date));*/
		
		//
		
		/*String inputDate = "01-19-2017 06:01 -0600";
	    DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm Z");
	    ZonedDateTime parsedInput = ZonedDateTime.parse(inputDate, inputFormatter);

	    OffsetDateTime gmtTime = parsedInput.toOffsetDateTime().withOffsetSameInstant(ZoneOffset.UTC);
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy hh:mm a Z");
	    String formattedDate = gmtTime.format(formatter);
	    System.out.println(formattedDate); // prints 01-19-2017 12:01 PM +0000
*/	    
		//
		
		/*Date currentTime=new Date(1560643200071L); // accept long value.
		System.out.println(currentTime);
		
		Date loggerTotime=new Date(1566469699450L);
		System.out.println(loggerTotime);*/
		
		/*Calendar cal = Calendar.getInstance();
		System.out.println("inst:"+cal);
		cal.add(Calendar.DATE, -180);
		System.out.println("a"+ cal);
		Date result = cal.getTime();
		
		Date fromTime = new Date(1566400680024L);
		//Long toTime = System.currentTimeMillis();
		Date todayTime=new Date(1566919080025L);
		//System.out.println(todayTime);
		System.out.println("frm time>>>"+fromTime);
		System.out.println("toTime>>>>"+todayTime);*/
		}

	}


