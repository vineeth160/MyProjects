package com.cisco.alfresco.external.jobs;

import java.io.Serializable;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.repository.TemplateService;
import org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter;
import org.alfresco.service.cmr.search.LimitBy;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;
import com.cisco.alfresco.edcsng.util.MailUtil;
import com.cisco.alfresco.ext.workflow.util.WFMailRootscopedObject;
import com.cisco.alfresco.external.common.util.UnPublishUtil;

/**
 * 
 * @author dhshaw
 * 
 **/
public class AutoUnPublish extends QuartzJobBean {
	Logger logger = Logger.getLogger(AutoUnPublish.class);

	private ServiceRegistry serviceRegistry;
	private NodeService nodeService;
	private String searchQuery;
	private String bannerAlfrescoUrl;
	private static String ACTION_NAME = "unpublish";
	private AuditComponent auditComponent;
	private static final String KEY_IS_JOB_ENABLED = "exchangeToolAutoUnPublishJobEnabled";
	public static String JOBTRACKER_STATUS_NOTIFICATION_TEMPLATE = "/alfresco/extension/templates/email/jobTrackerFailNotification.ftl";
	private boolean isJobEnabled = false;
	String status = "";
	private String mailerFromID;
	private String mailServer;
	private String mailerToID;
	private SessionFactory localFactory;

	public String getMailerToID() {
		return mailerToID;
	}

	public void setMailerToID(String mailerToID) {
		this.mailerToID = mailerToID;
	}

	public String getMailerFromID() {
		return mailerFromID;
	}

	public void setMailerFromID(String mailerFromID) {
		this.mailerFromID = mailerFromID;
	}

	public String getMailServer() {
		return mailServer;
	}

	public void setMailServer(String mailServer) {
		this.mailServer = mailServer;
	}

	public SessionFactory getLocalFactory() {
		return localFactory;
	}

	public void setLocalFactory(SessionFactory localFactory) {
		this.localFactory = localFactory;
	}

	public AuditComponent getAuditComponent() {
		return auditComponent;
	}

	public void setAuditComponent(AuditComponent auditComponent) {
		this.auditComponent = auditComponent;
	}

	public String getSearchQuery() {
		return searchQuery;
	}

	public void setSearchQuery(String searchQuery) {
		this.searchQuery = searchQuery;
	}

	/**
	 * 
	 * @param serviceRegistry
	 */
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public String getBannerAlfrescoUrl() {
		return bannerAlfrescoUrl;
	}

	public void setBannerAlfrescoUrl(String bannerAlfrescoUrl) {
		this.bannerAlfrescoUrl = bannerAlfrescoUrl;
	}

	/**
	 * @param context
	 */
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		logger.info("Inside the execute internals");
		String jobName = "AutoUnPublish";
		String endDate = "";
		String startDate = "";
		String getUnixBoxName = "";
		JobDataMap jobData = context.getJobDetail().getJobDataMap();
		String isJobEnabledStr = (String) jobData.get(KEY_IS_JOB_ENABLED);
		if (isJobEnabledStr != null) {
			try {
				isJobEnabled = new Boolean(isJobEnabledStr);
			} catch (Exception e) {
				logger.error("Invalid '" + KEY_IS_JOB_ENABLED + "' value, using default: " + isJobEnabled, e);
			}
		}
		if (!isJobEnabled)

		{
			logger.error("Skipping " + KEY_IS_JOB_ENABLED + " to execute.");
			return;
		}

		getUnixBoxName = getUnixBoxName();
		logger.info("UnixBoxName==" + getUnixBoxName + "jobName==" + jobName);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		startDate = dtf.format(now);
		logger.info("startDate" + startDate);
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@SuppressWarnings("unused")
			@Override
			public Object doWork() throws Exception {
				nodeService = serviceRegistry.getNodeService();
				ResultSet results = null;
				NodeRef currentNodeRef = null;
				Map<QName, Serializable> channelProperties = new HashMap<QName, Serializable>();
				SearchService searchService;
				List<NodeRef> searchNodeList = null;
				final String currentLoginUserName = serviceRegistry.getAuthenticationService().getCurrentUserName();
				Map<String, Serializable> unPublishAuditValues = null;
				try {
					String ftsQuery = "";
					// AND TYPE:"cs:ciscodoc" AND
					// +@ext\:publishExpirationDate:[%publishExpirationDate%]
					ftsQuery = getSearchQuery();
					String tempDate = doConvertDateFormat();
					ftsQuery = ftsQuery.replace("[%publishExpirationDate%]", tempDate);
					logger.info("Query to Execute is: :::" + ftsQuery);
					searchNodeList = getNodeRefList(ftsQuery, serviceRegistry);
					if (searchNodeList != null) {
						for (NodeRef nodeRef : searchNodeList) {
							logger.info("Checking for NodeRef.... " + nodeRef);
							if (serviceRegistry.getNodeService().exists(nodeRef)) {
								logger.info("NodeRef Found");
								// start of code for cancel workflows on node while unpublish
								WFMailRootscopedObject mailRootscopedObject = new WFMailRootscopedObject(
										serviceRegistry);
								// logger.info("AutoUnPublish form docExchange node id from unpublish to util
								// cancel workflow is :"+nodeRef);
								logger.info(
										"AutoUnPublish from docExchange current login user name and node id from unpublish to util cancel workflow :"
												+ currentLoginUserName + " ; " + nodeRef);
								mailRootscopedObject.cancelWFandSendMail(nodeRef.toString(), ACTION_NAME,
										currentLoginUserName, bannerAlfrescoUrl);
								// end of code for cancel workflows on node while unpublish
								unPublishAuditValues = UnPublishUtil.extractUnpublishAuditInfo(nodeRef, serviceRegistry,
										currentLoginUserName);
								QName CHECKEDOUT_ASPECT_QNAME = QName
										.createQName("http://www.alfresco.org/model/content/1.0", "checkedOut");
								boolean hasAspect = serviceRegistry.getNodeService().hasAspect(nodeRef,
										CHECKEDOUT_ASPECT_QNAME);
								logger.info("Checked Out Aspect ::::: ::::" + hasAspect);
								if (hasAspect) {
									NodeRef workingCopyId = (NodeRef) serviceRegistry.getCheckOutCheckInService()
											.getWorkingCopy(nodeRef);
									logger.info("workingCopyId ::::::::::::::" + workingCopyId);
									serviceRegistry.getCheckOutCheckInService().cancelCheckout(workingCopyId);
								}
								try {
									nodeService.deleteNode(nodeRef);
								} catch (Exception e) {
									status = "Failed";
									e.printStackTrace();
									logger.error("Excepiton in AutoExpire class : " + e.getMessage());
								}
								if (unPublishAuditValues != null && unPublishAuditValues.size() > 0)
									auditComponent.recordAuditValues("/publish-report/document", unPublishAuditValues);
							}
						}
					} else {
						logger.info("No files found with the criteria");
					}
				} catch (Exception e) {
					status = "Failed";
					logger.error("Exception....  ::::  : " + e.getMessage());
				}
				return null;
			}
		}, "admin");

		if (status.isEmpty() && status != null && (!status.equals("Failed") && "".equals(status))) {
			status = "Success";
		}
		DateTimeFormatter dtformater = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime ldTime = LocalDateTime.now();
		endDate = dtformater.format(ldTime);
		logger.info("endDate" + endDate);
		logger.info(jobName + "@@@" + "@@@" + startDate + "@@@" + endDate + "@@@" + status + "@@@@@" + getUnixBoxName);

		updateDB(getUnixBoxName, jobName, startDate, endDate, status);
		/*
		 * if (status != null && !status.isEmpty() && status.equals("Failed")) {
		 * sendEMail(getUnixBoxName, strManagerID, jobName, status); }
		 */
		logger.info("==>strManagerID<===" + mailerToID);
		if (!status.isEmpty() && status != null && status.equals("Failed")) {
			sendEMail(getUnixBoxName, mailerToID, jobName, status);
		}

	}

	public String doConvertDateFormat() {
		Date date = new Date(System.currentTimeMillis());
		StringBuilder actualDateObj = null;
		StringBuilder dtFormat = new StringBuilder();
		dtFormat.append(DefaultTypeConverter.INSTANCE.convert(String.class, date));
		String dtFrmtObj = dtFormat.toString();
		int firstTindex = dtFormat.indexOf("T");
		actualDateObj = new StringBuilder();
		actualDateObj.append("[MIN");
		actualDateObj.append(" TO ");
		actualDateObj.append(dtFrmtObj.substring(0, firstTindex));
		actualDateObj.append("T23:59:59");
		actualDateObj.append("]");
		logger.error(actualDateObj.toString());

		return actualDateObj.toString();

	}

	/**
	 * Returns a list of NodeRef object after passing a lucene query in String
	 * format
	 * 
	 * @param query
	 * @param registry
	 * @return
	 */
	public static List<NodeRef> getNodeRefList(String query, ServiceRegistry registry) {
		List<NodeRef> arrNodeRef = null;
		SearchParameters sp = new SearchParameters();
		sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
		sp.setLanguage(SearchService.LANGUAGE_LUCENE);
		sp.setLimit(600);
		sp.setLimitBy(LimitBy.FINAL_SIZE);
		sp.setQuery(query);
		ResultSet results = registry.getSearchService().query(sp);
		if (null == results || results.length() <= 0)
			return null;
		arrNodeRef = new ArrayList<NodeRef>();
		for (ResultSetRow row : results) {
			arrNodeRef.add(row.getNodeRef());
		}
		results.close();
		return arrNodeRef;
	}

	private String getUnixBoxName() {
		StringBuffer ipAddresses = new StringBuffer();
		InetAddress iAddress;
		try {
			iAddress = InetAddress.getLocalHost();
			String hostName = iAddress.getHostName();
			ipAddresses.append(hostName);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ipAddresses.toString();
	}

	public void sendEMail(String hostName, String mailerToID, String jobName, String status) {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("year", new SimpleDateFormat("yyyy").format(new Date()));
		model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
		model.put("hostName", hostName);
		model.put("jobName", jobName);
		model.put("jobstatus", status);
		// NodeRef template =
		// getEmailtemplate(addUserFtlLocationPath,ADD_USER_NOTIFICATION_TEMPLATE);
		TemplateService templateService = serviceRegistry.getTemplateService();
		String strArray[] = mailerToID.split(",");
		String mailSubject = jobName + " Scheduled Job Tracking Fail notification";
		String htmlBody = templateService.processTemplate(JOBTRACKER_STATUS_NOTIFICATION_TEMPLATE, model);

		logger.info("mailServer==" + mailServer + "==mailerFromID==" + mailerFromID + "==strArray==" + strArray
				+ "==mailSubject==" + mailSubject + "==strManagerID==" + mailerToID);
		boolean mailstatus = false;
		try {
			mailstatus = MailUtil.sendMail(mailServer, mailerFromID, strArray, null, mailSubject, htmlBody, null);
			logger.info("Mail Sataus >>>" + mailstatus + "   For user  ::  " + mailerToID);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void updateDB(String getUnixBoxName, String jobName, String startDate, String endDate, String status) {
		logger.info("Entered DB method");
		Session session = null;
		Transaction tx = null;
		JobTracker jobValues = new JobTracker();
		try {
			session = localFactory.openSession();
			tx = session.beginTransaction();
			String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
			String entryId = jobName.toString() + "_" + timeStamp.toString();
			jobValues.setEntryId(entryId.toString());
			jobValues.setBoxName(getUnixBoxName);
			jobValues.setJobName(jobName);
			jobValues.setStartDate(startDate);
			jobValues.setEndDate(endDate);
			jobValues.setStatus(status);
			session.save(jobValues);
			logger.info(jobValues.getBoxName() + "@@@" + jobValues.getJobName() + "@@@" + jobValues.getStartDate()
					+ "@@@" + jobValues.getEndDate() + "@@@" + jobValues.getStatus());

			tx.commit();
			logger.info("==Job Status Data Saved successfully:");
		} catch (Exception e) {
			logger.info("Error occured While updating " + e.getMessage());
			e.printStackTrace();
		}

	}
}