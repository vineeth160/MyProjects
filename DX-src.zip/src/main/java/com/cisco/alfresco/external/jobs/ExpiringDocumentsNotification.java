package com.cisco.alfresco.external.jobs;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import jxl.CellView;
import jxl.Workbook;
import jxl.format.Colour;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableHyperlink;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.repository.TemplateService;
import org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.TempFileProvider;
import org.apache.log4j.Logger;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.cisco.alfresco.edcsng.util.MailUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;

public class ExpiringDocumentsNotification extends QuartzJobBean {
	public static Logger _logger = Logger.getLogger(ExpiringDocumentsNotification.class);

	private ServiceRegistry serviceRegistry;
	private NodeService nodeService;
	private String strDays;
	private String excelPath;
	private String mailServer;
	private String docExDetailsURL;
	private String attachmentName;
	private String sheetName;
	private String ftsQuery;
	private String formatString;
	private String fromEmail;
	private String mailSubject;
	private TemplateService templateService;
	private String bannerAlfrescoUrl;
	//private String ftlLocationPath;
	public static String MULTIPLE_MAIL_TEMPLATE = "/alfresco/extension/templates/email/expiringDocumentsNotificationMultipleMailTemplate.ftl";
	private static final String KEY_IS_JOB_ENABLED = "ExpiringDocumentNotificationJobEnabled";
	private String reportHeading;
	private WritableCellFormat times;
	private WritableCellFormat timesBoldUnderline;
	private WritableCellFormat timesHeading;
	
	public String getMailSubject() {
		return mailSubject;
	}

	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}

	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public String getFormatString() {
		return formatString;
	}

	public void setFormatString(String formatString) {
		this.formatString = formatString;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public String getExcelPath() {
		return excelPath;
	}

	public void setExcelPath(String excelPath) {
		this.excelPath = excelPath;
	}

	public String getMailServer() {
		return mailServer;
	}

	public void setMailServer(String mailServer) {
		this.mailServer = mailServer;
	}

	public String getReportHeading() {
		return reportHeading;
	}

	public void setReportHeading(String reportHeading) {
		this.reportHeading = reportHeading;
	}

	public String getAttachmentName() {
		return attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	public String getFtsQuery() {
		return ftsQuery;
	}

	public void setFtsQuery(String ftsQuery) {
		this.ftsQuery = ftsQuery;
	}

	public String getStrDays() {
		return strDays;
	}

	public void setStrDays(String strDays) {
		this.strDays = strDays;
	}
	
	public String getDocExDetailsURL() {
		return docExDetailsURL;
	}

	public void setDocExDetailsURL(String docExDetailsURL) {
		this.docExDetailsURL = docExDetailsURL;
	}
	
	
	protected void executeInternal(JobExecutionContext context)	throws JobExecutionException {
				_logger.info("executeInternal method start on Doc expiring report...."+strDays);
				boolean isJobEnabled = false;
				final int days;
		  		days = Integer.parseInt(strDays);
		  		_logger.info("days :::::" + days);
		  		JobDataMap jobData = context.getJobDetail().getJobDataMap();
		        String isJobEnabledStr = (String) jobData.get(KEY_IS_JOB_ENABLED);
		        if (isJobEnabledStr != null)
		        {
		            try
		            {
		                isJobEnabled = new Boolean(isJobEnabledStr);
		            }
		            catch (Exception e)
		            {
		                _logger.info("Invalid '" + KEY_IS_JOB_ENABLED + "' value, using default: " + isJobEnabled, e);
		            }
		        }
		        if (!isJobEnabled)
		        {
		            // skip Job
		            _logger.info("Skipping " + KEY_IS_JOB_ENABLED + " to execute.");
		            return;
		        }
	        AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				@Override
				public Object doWork() throws Exception {
		  try{
				String documentTitle = null;
				String documentName = null;
				String creationDate = null;
				ResultSet results = null;
				NodeRef currentNodeRef = null;
				DocsPropertyBean DocumentProperties = null;
				String fileEditURL = null;
				String ownr = null;
				String expiryDate = null;
			    String version = null;
			    String edcsId = null;
			    String securityClassification = null;
			    
			List<DocsPropertyBean> userRecBoList = new ArrayList<DocsPropertyBean>();
			SearchService searchService = serviceRegistry.getSearchService();
			templateService = serviceRegistry.getTemplateService();
			SearchParameters sp = new SearchParameters();
			sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
			sp.setLanguage(SearchService.LANGUAGE_LUCENE);
			String tempDate = (String) doConvertDateFormat(days);
			_logger.info("tempDate::::::"+tempDate);
			ftsQuery = ftsQuery.replace("[%publishExpirationDate%]", tempDate);
			_logger.info("ftsQuery:::" + ftsQuery);
			sp.setQuery(ftsQuery);
			SimpleDateFormat sd = null;
			sd = new SimpleDateFormat(formatString);
			nodeService = serviceRegistry.getNodeService();
			results = searchService.query(sp);
			_logger.info("results:::::::::::::::" + results.length());
			if (results != null) {
				_logger.info("Inside the if condition");
			
				for (ResultSetRow row : results) {
					_logger.info("inside for");
					currentNodeRef = row.getNodeRef();
					_logger.info("currentNodeRef ::::" + currentNodeRef);
					documentTitle = (String) nodeService.getProperty(currentNodeRef,
							ContentModel.PROP_TITLE);
					 documentName= (String)nodeService
					.getProperty(currentNodeRef, ContentModel.PROP_NAME);
					 version = (String)nodeService.getProperty(currentNodeRef, ContentModel.PROP_VERSION_LABEL);
					  if(version ==null || version.equals("")){
						  version="1.0";
				        }
					  _logger.info("version:::"+version);
					 VersionHistory vers =  serviceRegistry.getVersionService().getVersionHistory(currentNodeRef);
					 Version version1;
					 String currentVersion;
					 if(vers!= null){
						  version1 = serviceRegistry.getVersionService().getCurrentVersion(currentNodeRef);
						  _logger.info("version1 ::::::"+version1.getVersionLabel());
						   currentVersion =version1.getVersionLabel();
						   _logger.info("currentVersion:::::"+currentVersion);
					 }else{
						currentVersion = "1.0";
					 }
					 QName EDCSID = QName.createQName("http://www.cisco.com/model/content/1.0","alf_id"); 
					 edcsId = (String) nodeService.getProperty(currentNodeRef,EDCSID); 
					_logger.info("documentTitle ::::::::::::::" + documentTitle);
					QName SECURITY = QName
					.createQName(
							"http://www.cisco.com/model/content/1.0",
							"security");
					securityClassification = (String) nodeService
					.getProperty(currentNodeRef,
							SECURITY);
					ownr = (String) nodeService.getProperty(currentNodeRef,
							ContentModel.PROP_CREATOR);
					_logger.info("ownr ::::::::::::::" + ownr);
					Date createDate = (Date) nodeService.getProperty(
							currentNodeRef, ContentModel.PROP_CREATED);
					creationDate = sd.format(createDate);
					QName expDate = QName.createQName(
							"http://www.alfresco.org/model/external/content/1.0",
							"publishExpirationDate");
					Date expDateVal = (Date) nodeService.getProperty(
							currentNodeRef, expDate);
					_logger.info("expDateVal :::::" + expDateVal);
					expiryDate = sd.format(expDateVal);
					_logger.info("expiryDate ::::::::::" + expiryDate);
					String siteName = serviceRegistry.getSiteService()
							.getSite(currentNodeRef).getShortName();
					_logger.info("siteName::::::::" + siteName);
					/*fileEditURL = docDetailsURL + "/share/page/site/" + siteName
							+ "/document-details?nodeRef=workspace://SpacesStore/"
							+ currentNodeRef.getId();*/
					fileEditURL = docExDetailsURL + "/alfext/ui/c/file/properties/edit/"+ currentNodeRef.getId();
					_logger.info("fileEditURL::::::::" + fileEditURL);
					DocumentProperties = new DocsPropertyBean();
				    if(documentTitle == null || documentTitle.equals("")){
                    	_logger.info("document::::"+documentName);
                    	DocumentProperties.setFileName(documentName);
                    }else{
                    	_logger.info("inside else documentTitle :::"+documentTitle);
                    	DocumentProperties.setFileName(documentTitle);
                    } 
				    DocumentProperties.setDocumentName(documentName);
					DocumentProperties.setVersion(currentVersion);
					DocumentProperties.setEDCSID(edcsId);
					DocumentProperties.setSecurityValue(securityClassification);
					DocumentProperties.setOwnerId(ownr);
					//DocumentProperties.setPublisher(publisher);
					DocumentProperties.setPublisher(ownr);
					DocumentProperties.setCreationDate(creationDate);
					DocumentProperties.setExpiryDate(expiryDate);
					DocumentProperties.setFileEditURL(fileEditURL);
					userRecBoList.add(DocumentProperties);
				}
				emailNotif(userRecBoList);
			}
		} catch (Exception e) {
			_logger.info("Exception ::::" + e);
		}
		return null;
			}
		}, "admin");
	}

	private void emailNotif(List<DocsPropertyBean> docProps) throws Exception {
		try{
		_logger.info("inside email notif");
		int days = 0;
		Map<String, Object> model = new HashMap<String, Object>();
		Date currentDate = new Date();
    	String year = new SimpleDateFormat("yyyy").format(currentDate); 
    	//NodeRef template = getEmailtemplate(MULTIPLE_MAIL_TEMPLATE);
		_logger.info("List" + docProps.size());
		Map<String, List<DocsPropertyBean>> ownerFileListMap = new Hashtable<String, List<DocsPropertyBean>>();
		_logger.info("" + ownerFileListMap);
		List<DocsPropertyBean> documentList = null;
		_logger.info("before for loop");
		for(DocsPropertyBean dBo : docProps){
			String publisher = dBo.getPublisher();
			if(ownerFileListMap.containsKey(publisher)){
				ownerFileListMap.get(publisher).add(dBo);
			} else {
				documentList = new ArrayList<DocsPropertyBean>();
				documentList.add(dBo);
				ownerFileListMap.put(publisher, documentList);
			}
		}
			_logger.info("Final sorting : " + ownerFileListMap);
		    _logger.info("after for loop");
			Set<String> ownerKeySet = ownerFileListMap.keySet();
			Iterator<String> ownerKeySetIterator = ownerKeySet.iterator();
			while (ownerKeySetIterator.hasNext()) {
			_logger.info("inside while loop");
			String ownerKeyString = ownerKeySetIterator.next();
			_logger.info("ownerKeyString ::::::"+ownerKeyString);
			List<DocsPropertyBean> DocsPropertyBeanList = ownerFileListMap.get(ownerKeyString);
			_logger.info("DocsPropertyBeanList inside the while"+DocsPropertyBeanList);
			_logger.info("DocsPropertyBeanList.size();"
					+ DocsPropertyBeanList.size());
			NodeRef user = serviceRegistry.getPersonService().getPerson(
					ownerKeyString);
			String address = (String) nodeService.getProperty(user,
					ContentModel.PROP_EMAIL);
			_logger.info("email id" + address);
			 //US9853-start of Opt in/out Email Notification
            boolean optOutEmailNotification=optOutEmailNotify(user);
            _logger.info("Opt In Email Notifications" + optOutEmailNotification);
			String tomany[] = new String[1];
			tomany[0]= address; //"prbadam@cisco.com";
			 DocsPropertyBean propBO = DocsPropertyBeanList.get(0);
			 _logger.info("DocsPropertyBeanList.get(0):"+DocsPropertyBeanList.get(0));
			 String Owner = propBO.getOwnerId();
			 String publisher = propBO.getPublisher();
			  String cc = Owner+"@cisco.com";
			 _logger.info("cc :: owner "+cc+"publisher"+publisher);
			 _logger.info("tomany[]::"+tomany[0]);
			int size = DocsPropertyBeanList.size();
			_logger.info("size" + size);
			Pattern pattern = Pattern.compile("\\S+?@cisco\\.com");
			Matcher matcher = pattern.matcher(address);
			String multipleMailBody = null;
			
			//temporary set for removing duplicate files
		   Set<String> edcsIdset = new HashSet<String>();
		   if(DocsPropertyBeanList!=null && DocsPropertyBeanList.size() <6){
			   List<Map<String,String>> docs = new ArrayList<Map<String,String>>();
			   for (DocsPropertyBean docsBO : DocsPropertyBeanList) {
				   _logger.info("docsBO.getEDCSID() ::::::::::::::::::)))"+docsBO.getEDCSID());
				   if(!edcsIdset.contains(docsBO.getEDCSID())){
					   edcsIdset.add(docsBO.getEDCSID());
					   Map<String, String> docDetails = new HashMap<String, String>();
					   docDetails.put("DocName", docsBO.getDocumentName());
					   docDetails.put("owner", docsBO.getOwnerId());
					   docDetails.put("DocTitle", docsBO.getFileName());
					   docDetails.put("version", docsBO.getVersion());
					   docDetails.put("edcsIdd", docsBO.getEDCSID());
					   docDetails.put("SecurityValue", docsBO.getSecurityValue());
					   docDetails.put("cDate", docsBO.getCreationDate());
					   docDetails.put("eDate", docsBO.getExpiryDate());
					   docDetails.put("fileUrl", docsBO.getFileEditURL());
					   docs.add(docDetails);
				   }
			}
			  // _logger.info("External Expiring Docs details-------------"+docProps);
			   _logger.info("External Expiring Docs---------"+docs);
			   if(days == 1){
				   model.put("days", strDays + " day");
				   }else{
				   model.put("days", strDays + " days");
				   }
			   model.put("docs", docs);
			   model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
			   model.put("year", year);
			   model.put("contentMsg", "");
			    multipleMailBody = templateService.processTemplate(MULTIPLE_MAIL_TEMPLATE, model);
    		  		if (optOutEmailNotification && strDays.equals("30")) {
    		  			_logger.info("ExpiringDocumentsNotification User is Opt out Email Notifications:::::::::::::"+tomany.toString());
    		  		}else{
    		  			if(matcher.matches()){
    		  			 _logger.info("###@## Before sending mail:"+tomany[0]+""+mailServer+""+fromEmail+""+cc+""+mailSubject);
   						 MailUtil.sendMail(mailServer, fromEmail, tomany,null,
   									mailSubject, multipleMailBody, null);
   						 _logger.info("Mail sent successfully in if from ExpiringDocumentsNotification------");
    		  			}
    		  		}
		}else if(DocsPropertyBeanList!=null){
			 model.put("docs", null);
			 String contentMsg="";
			 if(days == 1){
				   model.put("days", strDays + " day");
				   contentMsg="Content that you have published in the attached report will expire in the next"+ strDays +" day";
				   }else{
				   model.put("days", strDays + " days");
				   contentMsg="Content that you have published in the attached report will expire in the next"+ strDays +" days";
				   }
			 model.put("contentMsg", contentMsg);
			 model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
			 model.put("year", year);
			 multipleMailBody = templateService.processTemplate(MULTIPLE_MAIL_TEMPLATE, model);
			 _logger.info("DocsPropertyBeanList:::::::::::::::"+DocsPropertyBeanList);
    		   String EexcelPath = getExcelReport(DocsPropertyBeanList);
			   _logger.info("EexcelPath" + EexcelPath);
				if (optOutEmailNotification && strDays.equals("30")) {
					_logger.info("ExpiringDocumentsNotification User is Opt out Email Notifications:::::::::::::"+tomany.toString());
				}else{
					if(matcher.matches()){
					_logger.info("inside DocsPropertyBeanList!=null mattches");
					 MailUtil.sendMail(mailServer, fromEmail, tomany,null,
								mailSubject, multipleMailBody, EexcelPath);
					 _logger.info("Mail sent successfully in else from ExpiringDocumentsNotification------");
					}
				}
		   }
		}
			/*
			 * Deleting excel sheet from the tomcat's temp location.
			 */
			StringBuffer filePaths = new StringBuffer();
			filePaths.append(TempFileProvider.getTempDir(excelPath)).append(attachmentName);
			File xlsFile = new File(filePaths.toString());
			 _logger.info("File location is : " + filePaths.toString() + "  isFileExists : " + xlsFile.exists() + " :::isFile :  " + xlsFile.isFile());
			if(xlsFile.exists() && xlsFile.isFile()){
				xlsFile.delete();
			}
		}catch(Exception e){
			e.printStackTrace();
			_logger.error("exception--------"+e);
		}
	}

	 /**
     * To Get Email Template
     */
 /*   private NodeRef getEmailtemplate(String templateName)
    {
        String templateConditionalPath = "PATH:\"" + ftlLocationPath + "//*\" AND "
                + "TYPE:cm\\:content AND @cm\\:name:\"" + templateName + "\"";
        _logger.info("LUCENE QRY: " + templateConditionalPath);
        ResultSet resultSet = serviceRegistry.getSearchService().query(
            new StoreRef(StoreRef.PROTOCOL_WORKSPACE, "SpacesStore"), SearchService.LANGUAGE_LUCENE,
            templateConditionalPath);
        if (resultSet.length() == 0)
        {
        	_logger.info("Template " + templateConditionalPath + " not found.");
            return null;
        }
        NodeRef template = resultSet.getNodeRef(0);
        _logger.info("Got the Email Template:" + template.toString());
        return template;
    }
	*/
	private String getExcelReport(List<DocsPropertyBean> bo) {
		 _logger.info("inside getExcelReport:::"+bo);
		 File fileXLS =null;
		try {
			 StringBuffer filePath = new StringBuffer();
				filePath.append(TempFileProvider.getTempDir(excelPath)).append(attachmentName);
				 _logger.info("filePath ExcelReport:::"+filePath.toString());
				fileXLS = new File(filePath.toString());
				WritableWorkbook workbook = null;
				WritableFont times10ptBoldUnderline = new WritableFont(
						WritableFont.TIMES, 10, WritableFont.BOLD, false);
				
			workbook = Workbook.createWorkbook(fileXLS);
			// creating sheets in the workbook
			WritableSheet wSheet1 = workbook.createSheet(sheetName, 0);
			wSheet1.setColumnView(0, 20);
			wSheet1.setColumnView(1, 20);
			wSheet1.setRowView(0, 800);
			timesHeading = new WritableCellFormat(times10ptBoldUnderline);
			// do not automatically wrap the cells
			timesHeading.setWrap(true);
			addHeading(wSheet1, 0, 0, reportHeading);
			wSheet1.mergeCells(0, 0, 13, 0);

			String col2Name = "Filename";
			createLabel(wSheet1, col2Name, 0);
			
			String col1Name = "File Title";
			createLabel(wSheet1, col1Name, 1);
			
			String col3Name = "Version";
			createLabel(wSheet1, col3Name, 2);
			
			String col4Name = "EDCS ID";
			createLabel(wSheet1, col4Name, 3);
			
			String col5Name = "Data Classification";
			createLabel(wSheet1, col5Name, 4);
			
			String col6Name = "Creator";
			createLabel(wSheet1, col6Name, 5);
			
			String col7Name = "Creation Date";
			createLabel(wSheet1, col7Name, 6);
			
			String col8Name = "Expiration Date";
			createLabel(wSheet1, col8Name, 7);
			
			Set<String> edcsIdsetExcel = new HashSet<String>();
			int rowNumber = 2;
			for (DocsPropertyBean recordKey : bo) {
				if (recordKey != null) {
					 if(!edcsIdsetExcel.contains(recordKey.getEDCSID())){
						 edcsIdsetExcel.add(recordKey.getEDCSID());
					addHyperlink(wSheet1, 0, rowNumber, recordKey.getDocumentName(),recordKey.getFileEditURL()); 
					addLabel(wSheet1, 1, rowNumber, recordKey.getFileName());
					addLabel(wSheet1, 2, rowNumber, recordKey.getVersion());
					addLabel(wSheet1, 3, rowNumber, recordKey.getEDCSID());
					addLabel(wSheet1, 4, rowNumber, recordKey.getSecurityValue());
					addLabel(wSheet1, 5, rowNumber, recordKey.getOwnerId());
					addLabel(wSheet1, 6, rowNumber, recordKey.getCreationDate());
					addLabel(wSheet1, 7, rowNumber, recordKey.getExpiryDate());
					rowNumber++;
					 }
			}
			}
			workbook.write();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return fileXLS.getAbsolutePath();
	}

	public void createLabel(WritableSheet sheet, String label, int col)
			throws WriteException {
		WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
		times = new WritableCellFormat(times10pt);
		times.setWrap(false);
		// Create create a bold font
		WritableFont times10ptBoldUnderline = new WritableFont(
				WritableFont.TIMES, 10, WritableFont.BOLD, false);
		timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
		timesBoldUnderline.setWrap(false);
		CellView cv = new CellView();
		cv.setFormat(times);
		cv.setFormat(timesBoldUnderline);
		// Write a few headers
		addCaption(sheet, col, 1, label);
	}

	public void addCaption(WritableSheet sheet, int column, int row, String s)
			throws RowsExceededException, WriteException {
		Label label;
		label = new Label(column, row, s, timesBoldUnderline);
		sheet.addCell(label);
	}

	public void addLabel(WritableSheet sheet, int column, int row, String s)
			throws WriteException, RowsExceededException {
		Label label;
		label = new Label(column, row, s, times);
		sheet.addCell(label);
	}

	public void addHeading(WritableSheet sheet, int column, int row, String s)
			throws WriteException, RowsExceededException {
		Label label;
		label = new Label(column, row, s, timesHeading);
		sheet.addCell(label);
	}
	
	public void addHyperlink(WritableSheet sheet, int column, int row, String fileName,String url)
			throws WriteException, RowsExceededException {
		try {
			 WritableHyperlink link = new WritableHyperlink(column,row, new URL(url));
			sheet.addHyperlink(link);
			WritableFont redFont = new WritableFont(WritableFont.ARIAL);
		    redFont.setColour(Colour.BLUE);
		    WritableCellFormat cellFormat = new WritableCellFormat(redFont);
		    Label label = new Label(column, row, fileName, cellFormat);
		    sheet.addCell(label);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	public static String doConvertDateFormat(int days) {
			Date date = new Date(System.currentTimeMillis() + days * 24L * 3600	* 1000);
			StringBuilder actualDateObj = null;
	        StringBuilder dtFormat = new StringBuilder();
	        dtFormat.append(DefaultTypeConverter.INSTANCE.convert(String.class,
	                date));
	        String dtFrmtObj = dtFormat.toString();
	        int firstTindex = dtFormat.indexOf("T");
	        actualDateObj = new StringBuilder();
	        actualDateObj.append("[");
	        actualDateObj.append(dtFrmtObj.substring(0, firstTindex+1));
	        actualDateObj.append("00:00:00 TO ");
	        actualDateObj.append(dtFrmtObj.substring(0, firstTindex));
	        actualDateObj.append("T23:59:59");
	        actualDateObj.append("]");
	        _logger.info("actualDateObj------>"+actualDateObj.toString());
	        return actualDateObj.toString();
	}
	//US9853-start of Opt in/out Email Notification
		private boolean optOutEmailNotify(NodeRef personNode){
			 boolean optOutEmailNotify=false;
			 boolean hasEmailNotificationAspect =false;
			 hasEmailNotificationAspect = serviceRegistry.getNodeService().hasAspect(personNode, ExternalSharingConstants.ASPECT_OPTINOUT_EMAIL_NOTIFICATION);
		          if(hasEmailNotificationAspect){
		        	  optOutEmailNotify = (Boolean) serviceRegistry.getNodeService().getProperty(personNode, ExternalSharingConstants.PROP_OPTOUT_EMAIL_NOTIFY);
		          }
			 
			return optOutEmailNotify;
		}
		//US9853-end of Opt in/out Email Notification

	public String getBannerAlfrescoUrl() {
		return bannerAlfrescoUrl;
	}

	public void setBannerAlfrescoUrl(String bannerAlfrescoUrl) {
		this.bannerAlfrescoUrl = bannerAlfrescoUrl;
	}

	/*public String getFtlLocationPath() {
		return ftlLocationPath;
	}

	public void setFtlLocationPath(String ftlLocationPath) {
		this.ftlLocationPath = ftlLocationPath;
	}*/
}