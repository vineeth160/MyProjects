package com.cisco.alfresco.external.jobs;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import jxl.CellView;
import jxl.Workbook;
import jxl.format.Colour;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableHyperlink;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.audit.AuditService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.namespace.QName;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.mybatis.spring.MyBatisSystemException;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.cisco.alfresco.edcsng.util.MailUtil;
import com.cisco.alfresco.external.common.model.UserActionsEntity;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.edcsng.audit.bireports.utils.BIReportsAuditMap;
import com.cisco.edcsng.audit.bireports.utils.GenericQueryUtil;




public class PublishNotificationMailsJob extends QuartzJobBean{
	private static final Logger logger = Logger.getLogger(PublishNotificationMailsJob.class);


	private AuditService auditService;
	private ServiceRegistry serviceRegistry;
	//private SessionFactory sessionFactory;

	private SqlSessionFactory localFactory;
	private String reportHeading;
	private WritableCellFormat times;
	private WritableCellFormat timesBoldUnderline;
	private WritableCellFormat timesHeading;
	private String days;
	private String excelPath;
	private String attachmentName;
	private String sheetName;
	private String subjectLine;
	private String bannerAlfrescoUrl;
	private String fromEmail;
	private String mailServer;
	private String folderURL;
	private SqlSession session = null;

	private static final String KEY_IS_JOB_ENABLED = "enableWeeklyPublishMailNotifJob";
	private boolean isJobEnabled = false;

	public static String CONSOLIDATED_MAIL_TEMPLATE = "/alfresco/extension/templates/email/ConsolidatedPublishMailTemplate.ftl";

	protected  void executeInternal(JobExecutionContext context) {
		logger.info("PublishNotificationMailsWebScript Started....");
		
		 JobDataMap jobData = context.getJobDetail().getJobDataMap();
	        String isJobEnabledStr = (String) jobData.get(KEY_IS_JOB_ENABLED);
	        if (isJobEnabledStr != null)
	         {
	            try
	            {
	                isJobEnabled = new Boolean(isJobEnabledStr);
	            }
	            catch (Exception e)
	            {
	                logger.error("Invalid '" + KEY_IS_JOB_ENABLED + "' value, using default: " + isJobEnabled, e);
               }
	        }
	        if (!isJobEnabled)
            {
	            logger.info("Skipping " + KEY_IS_JOB_ENABLED + " to execute.");
	            return;
	        }
		
		
		try{

			AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				@SuppressWarnings("unchecked")
				@Override
				public Object doWork() throws Exception 
				{
					//List<BIReportsAuditMap> query=null;
					String notificationMailBody= null;
					Map<String, Object> model = new HashMap<String, Object>();
					String mailSubject = null;
					List<BIReportsAuditMap> selectQuery	= null;
					//Query selectQuery = null;
					Date endDate = new Date();
					Date startDate = new Date(System.currentTimeMillis() - (Integer.parseInt(days)) * 24L * 3600 * 1000);
					logger.info("startDate :::::"+startDate + "End date is : " + endDate);
					SimpleDateFormat sd = null;
					sd = new SimpleDateFormat("MM/dd/YYYY");
					String AuditStartDate = sd.format(startDate);
					String AuditEndDate = sd.format(endDate);
					String year = new SimpleDateFormat("yyyy").format(endDate); 
					
				

					logger.info("After converting dateformat is AuditStartDate ::::: "+AuditStartDate + "  AuditEndDate : " + AuditEndDate);

					/*Session session = null;
					session = (Session) GenericQueryUtil.openSession(sessionFactory,session);
					//session = sessionFactory.openSession();
					String query = "from BIReportsAuditMap bm where action IN ('CREATE', 'CHECK IN','PUBLISH') and auditTime between  TO_DATE('"+AuditStartDate+" 00:00:00', 'MM/DD/YYYY HH24:MI:SS')  AND TO_DATE('"+AuditEndDate+" 23:59:59', 'MM/DD/YYYY HH24:MI:SS') ";
					logger.info("Final Query is : " + query);
					selectQuery = session.createQuery(query);
				
					*/
					List<BIReportsAuditMap> auditResultList	= null;
					try {
				    session=getSqlSession();
					Map<String,String> map = new HashMap<String, String>();
					map.put("AuditStartDate", AuditStartDate);
					map.put("AuditEndDate", AuditEndDate);
					selectQuery = session.selectList("select", map);
					return selectQuery;
					//query = sqlSession.selectList("select",map);
					
					
					}catch (MyBatisSystemException e) {
						logger.error("Error while executing seq select query--  " + e);
					}
					/**
					 * This query will fetch all CREATE AND CHECK IN documents with in the specified date range from custom created audit table.
					 */
					
					 auditResultList = (List<BIReportsAuditMap>) selectQuery;
					//GenericQueryUtil.closeSession(session);
					Map<String, List<UserActionsEntity>> usersAndCorrespondingActionsMap = null;
					if(auditResultList!= null){
						logger.info("Records Size : " + auditResultList.size());
						
						/**
						 * This map will hold all the users and their corresponding documents
						 */
						usersAndCorrespondingActionsMap = new HashMap<String, List<UserActionsEntity>>();
						for(BIReportsAuditMap reportsBO:auditResultList){
							if(reportsBO.getNoderef() != null && !reportsBO.getNoderef().isEmpty()){
								NodeRef nodeRef = new NodeRef(reportsBO.getNoderef());
								
								String userId = reportsBO.getUserId();
								if((serviceRegistry.getNodeService().exists(nodeRef)) && (userId!= null && !userId.trim().equalsIgnoreCase("ciscoadmin.gen"))){
								
								//if(serviceRegistry.getNodeService().exists(nodeRef)){
									
									/**
									 * consider only documents ignore folder types
									 */
									if(!(serviceRegistry.getNodeService().getType(nodeRef).equals(ContentModel.TYPE_FOLDER))){
										Set<AccessPermission> accessPermission = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
										String documentPath = reportsBO.getFolderPath();
										
										/**
										 * substring the document path by excluding the path : Company Home/Sites/edcsng/documentLibrary/
										 */
										String actualDocumentPath ="Company Home/Sites/edcsng/documentLibrary/";
										documentPath = documentPath.substring(actualDocumentPath.length(),documentPath.length());
										
										//Forming entity Object with all the required properties.
										UserActionsEntity userActions = new UserActionsEntity();

										String edcsId = reportsBO.getEdcsId();
										if(edcsId == null || edcsId.equals("")){
											userActions.setEDCSID("NA");
										}else{
											userActions.setEDCSID(edcsId);
										}

										Map<QName, Serializable> nodeProp = serviceRegistry.getNodeService().getProperties(nodeRef);

								         /*String creator = (String) nodeProp.get(ContentModel.PROP_CREATOR);
								         if (creator == null)
								        	 creator = "";*/

								         String fileTitle = (String) nodeProp.get(ContentModel.PROP_TITLE);
								         if (fileTitle == null)
								        	 fileTitle = "";
								         
								         NodeRef parentNodeRef = serviceRegistry.getNodeService().getPrimaryParent(nodeRef).getParentRef();

										userActions.setPublisher(reportsBO.getUserId());
										userActions.setUpdatedDate(getGmtDateFormat(reportsBO.getAuditTime()));
										userActions.setFileName(reportsBO.getFileName());
										userActions.setDocPath(documentPath);
										userActions.setFileTitle(fileTitle);
										userActions.setParentNodeRef(parentNodeRef);

										//boolean isCreatorAddedToMap = false;
										Set<String> uniqueUsersSet = new HashSet<String>();
										logger.info("documentPath : " + documentPath + "  FileName is : " + reportsBO.getFileName() + " Premissions size in doc is : " + accessPermission.size() + " audit time:");
										if (accessPermission.size() > 0) {
											for (AccessPermission accessPermissionObj : accessPermission) {
												
												if (accessPermissionObj.getAuthorityType() == AuthorityType.USER) {
													/**
													 * same user contain different permission the same document. Ex:vepagada(editor), vepagada(FolderAdmin).
													 * Make sure that documents only once add to the user. same document should not repeat to the same user.
													 */
													if (!uniqueUsersSet
															.contains(accessPermissionObj
																	.getAuthority())) {

														/**
														 * usersAndCorrespondingActionsMap contains key as user name and value as his documents.
														 * If the map contains the user, then we are adding the document to his list
														 * if the map does not contain the user then adding the new key value pair in the map as key as user name and value as docuemnt.
														 */
														if (usersAndCorrespondingActionsMap
																.containsKey(accessPermissionObj
																		.getAuthority())) {
															usersAndCorrespondingActionsMap
																	.get(accessPermissionObj
																			.getAuthority())
																	.add(userActions);
														} else {
															List<UserActionsEntity> userActionsList = new ArrayList<UserActionsEntity>();
															userActionsList
																	.add(userActions);
															usersAndCorrespondingActionsMap
																	.put(accessPermissionObj
																			.getAuthority(),
																			userActionsList);

														}

														/*if(accessPermissionObj.getAuthority().equals(creator)){
															logger.info("Creatpr : " + creator + " is not added for the doc : " + reportsBO.getFileName());
															isCreatorAddedToMap = true;
														}*/

														uniqueUsersSet
																.add(accessPermissionObj
																		.getAuthority());
													}
												}
											}
										}
										
										/**
										 * Publisher also should get emails.
										 * We are saving publisher as creator in document metadata proeprties.
										 */
										/*if(!isCreatorAddedToMap){
											logger.info("Creatpr : " + creator + " is going to add to the document : " + reportsBO.getFileName());
											if(usersAndCorrespondingActionsMap.containsKey(creator)){
												usersAndCorrespondingActionsMap.get(creator).add(userActions);
											} else {
												List<UserActionsEntity> userActionsList = new ArrayList<UserActionsEntity>();
												userActionsList.add(userActions);
												usersAndCorrespondingActionsMap.put(creator, userActionsList);
											}
										}*/
									}
								}
								
							}
						}
							
					}


					if(usersAndCorrespondingActionsMap != null){
						String excelReport = null;
						String personEmailId =null;
						String firstName = null;
						String fullName = null;
						String lastName = null;
						for(Map.Entry<String, List<UserActionsEntity>> usersAndActionsEntry : usersAndCorrespondingActionsMap.entrySet()){
							try {
								
								logger.info("mail sending to the user : " + usersAndActionsEntry.getKey());
								String mailReciever = usersAndActionsEntry.getKey();
								
								NodeRef personId = null;
							    personId = serviceRegistry.getPersonService().getPerson(mailReciever);
								logger.info("personId :::"+personId);
								
								if(personId!=null && !personId.equals("")){
									personEmailId = (String)serviceRegistry.getNodeService().getProperty(personId, ContentModel.PROP_EMAIL);
								    firstName = (String)serviceRegistry.getNodeService().getProperty(personId, ContentModel.PROP_FIRSTNAME);
									lastName = (String)serviceRegistry.getNodeService().getProperty(personId, ContentModel.PROP_LASTNAME);
									fullName = firstName+" "+lastName;
									logger.info("Person details... personEmailId : " + personEmailId + "  fullName :: " + fullName);
									
									/*--- badam start---*/
									String tomany[] = null;
									String secEmailId = getSecondaryEmail(personId);
									logger.info("secEmailId---------"+ secEmailId);
									if (secEmailId != null && secEmailId != "" && !personEmailId.equals(secEmailId)) {
										tomany = new String[2];
										tomany[0] = personEmailId;
										tomany[1] = secEmailId;
										logger.info("inside secondary emaild---------");
									} else {
											tomany = new String[1];
											tomany[0] = personEmailId;
											logger.info("secondary emaild is not found---------");
											}
											/*--- badam end---*/
											
									String docExURL = bannerAlfrescoUrl+"/alfext/ui/#/whatsnew";
									List<UserActionsEntity> userActinsList = usersAndActionsEntry.getValue();
										excelReport = getUploadedDocsReport(userActinsList,AuditEndDate,mailReciever);
										mailSubject = subjectLine+"("+AuditEndDate+")";
										model.put("fullName", fullName);
										model.put("WeekEnding", AuditEndDate);
										model.put("currentYear", year);
										model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
										model.put("hyperlinkURL", docExURL);
										notificationMailBody = serviceRegistry.getTemplateService().processTemplate(CONSOLIDATED_MAIL_TEMPLATE, model);
		                                logger.info("before the mailutil if condition******"+tomany+"subject:::: "+mailSubject+personEmailId+"excelReport:::"+excelReport);
		                                //US9853-start of Opt in/out Email Notification
		                                boolean optOutEmailNotification=optOutEmailNotify(personId);
		                                if(optOutEmailNotification){ 
		                                	logger.info("PublishNotificationMailsJob User is Opt out Email Notifications:::::::::::::"+personEmailId);
										}else{
											if(personEmailId!=null && !personEmailId.equals("")&& !(personEmailId.equals("0"))){
												MailUtil.sendMail(mailServer, fromEmail, tomany, null, mailSubject, notificationMailBody, excelReport);
												logger.info("Mail Sent successfully to ::::: "+personEmailId);
												logger.info("--- Mail Sent successfully from PublishNotificationMailsJob ---");
						  	        	}
								}
								}
								
							
							} catch (Exception e) {
								logger.error(e.getStackTrace(),e);
							}
						}
						
						/*
						 * Deleting excel sheet from the tomcat's temp location.
						 */
						StringBuffer filePath = new StringBuffer();
						filePath.append(excelPath).append(attachmentName);
						File xlsFile = new File(filePath.toString());
						logger.info("File location is : " + filePath.toString() + "  isFileExists : " + xlsFile.exists() + " :::isFile :  " + xlsFile.isFile());
						if(xlsFile.exists() && xlsFile.isFile()){
							xlsFile.delete();
						}
					}


					return null;

				}
			}, "admin");


		}catch(Exception e){
			logger.error(e.getStackTrace(),e);
		}

	}
	
	private String getGmtDateFormat(Date sourceDate) throws ParseException{
		logger.info("sourceDate : " + sourceDate);
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss z");
		
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		String gmtFormat = dateFormat.format(sourceDate);
		logger.info("gmtFormat is : " + gmtFormat);
		return gmtFormat;
	}


	public String getUploadedDocsReport(List<UserActionsEntity> uploadedDocuments,String AuditEndDate, String mailReceiver) throws IOException {
		logger.info("**************** Inside getUploadedDocsReport  **********************");

		
		NodeRef personId = null;
	    personId = serviceRegistry.getPersonService().getPerson(mailReceiver);
	    String personEmailId = (String)serviceRegistry.getNodeService().getProperty(personId, ContentModel.PROP_EMAIL);
		
		StringBuffer filePath = new StringBuffer();
		String excelReportHeading = reportHeading + " (" + AuditEndDate + ")";
		filePath.append(excelPath).append(attachmentName);
		File fileXLS = new File(filePath.toString());
		WritableWorkbook workbook = null;

		WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);

		try {
			workbook = Workbook.createWorkbook(fileXLS);
			// creating sheets in the workbook
			WritableSheet wSheet1 = workbook.createSheet(sheetName, 0);
			wSheet1.setColumnView(0, 20);
			wSheet1.setColumnView(1, 20);
			wSheet1.setRowView(0, 800);
			timesHeading = new WritableCellFormat(times10ptBoldUnderline);
			// do not automatically wrap the cells
			timesHeading.setWrap(true);
			addHeading(wSheet1, 0, 0, excelReportHeading);
			wSheet1.mergeCells(0, 0, 13, 0);
			
			String col1Name = "File Name";
			createLabel(wSheet1, col1Name, 0);

			String col2Name = "File Title";
			createLabel(wSheet1, col2Name, 1);

			String col3Name = "EDCS ID";
			createLabel(wSheet1, col3Name, 2);

			String col4Name = "Publisher";
			createLabel(wSheet1, col4Name, 3);

			String col5Name = "Published Date";
			createLabel(wSheet1, col5Name, 4);

			String col6Name = "External FolderPath";
			createLabel(wSheet1, col6Name, 5);
			
			String col7Name = "Folder URL";
			createLabel(wSheet1, col7Name, 6);

			String folderPathURL = null;
			 Label label = null;
			 WritableCellFormat  cellFormat = null;
			int rowNumber = 2;
			boolean isUseraccesible = false;
			for (UserActionsEntity recordKey : uploadedDocuments) {
				if (recordKey != null) {
					if(recordKey.getPublisher()!=null  && !recordKey.getPublisher().trim().equalsIgnoreCase("ciscoadmin.gen")){
					addLabel(wSheet1, 0, rowNumber, recordKey.getFileName());
					addLabel(wSheet1, 1, rowNumber, recordKey.getFileTitle());
					addLabel(wSheet1, 2, rowNumber, recordKey.getEDCSID());
					addLabel(wSheet1, 3, rowNumber, recordKey.getPublisher());
					addLabel(wSheet1, 4, rowNumber, recordKey.getUpdatedDate());
					
					
					/**
					 * if the user has access on document's parent folder then provide hyper link to folder path
					 * else simply showing folder path.
					 */
					folderPathURL= folderURL+recordKey.getParentNodeRef().getId();
					Set<AccessPermission> parentNodeaccessPermission = serviceRegistry.getPermissionService().getAllSetPermissions(recordKey.getParentNodeRef());
					if(parentNodeaccessPermission != null && parentNodeaccessPermission.size() > 0){
						for (AccessPermission accessPermissionObj : parentNodeaccessPermission) {
							if(accessPermissionObj.getAuthority().equals(mailReceiver)){
								//logger.info("user name:::: "+accessPermissionObj.getAuthority());
								isUseraccesible = true;
								break;

							}
						}
					}
					//logger.info("isUseraccesible:::: "+isUseraccesible);
					if(isUseraccesible){
						URL folderUrl = new URL(folderPathURL);
						WritableHyperlink wh = new WritableHyperlink(5, rowNumber, folderUrl);
						wSheet1.addHyperlink(wh);
						WritableFont   blueFont = new WritableFont(WritableFont.ARIAL);
						blueFont.setColour(Colour.BLUE);
						cellFormat = new WritableCellFormat(blueFont);
						if(personEmailId.contains("@cisco.com")){
						label = new Label(5 ,rowNumber,recordKey.getDocPath(),cellFormat);
						}else{
							String documentPath = recordKey.getDocPath();
							 documentPath = documentPath.substring(documentPath.lastIndexOf("/"));
							label = new Label(5 ,rowNumber,documentPath,cellFormat);
						}
						wSheet1.addCell(label);
					}else{
						String actualFolderPath = recordKey.getDocPath();
						int finalPath = actualFolderPath.lastIndexOf("/", actualFolderPath.length());
						String documentPath =  actualFolderPath.substring(finalPath);
						addLabel(wSheet1, 5, rowNumber,documentPath);
					}

					addLabel(wSheet1, 6, rowNumber,folderPathURL);
					rowNumber++;
				}
				}
				
				
			}
			workbook.write();
			workbook.close();
		} catch (Exception e) {
			logger.error(e.getStackTrace(),e);

		}
		return fileXLS.getAbsolutePath();

	}
	public void createLabel(WritableSheet sheet, String label, int col)
			throws WriteException {
		WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
		times = new WritableCellFormat(times10pt);
		times.setWrap(false);
		// Create create a bold font
		WritableFont times10ptBoldUnderline = new WritableFont(
				WritableFont.TIMES, 10, WritableFont.BOLD, false);
		timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
		timesBoldUnderline.setWrap(false);
		CellView cv = new CellView();
		cv.setFormat(times);
		cv.setFormat(timesBoldUnderline);
		// Write a few headers
		addCaption(sheet, col, 1, label);
	}

	public void addCaption(WritableSheet sheet, int column, int row, String s)
			throws RowsExceededException, WriteException {
		Label label;
		label = new Label(column, row, s, timesBoldUnderline);
		sheet.addCell(label);
	}

	public void addLabel(WritableSheet sheet, int column, int row, String s)
	throws WriteException, RowsExceededException {
		Label label;
		label = new Label(column, row, s, times);
		sheet.addCell(label);
    }


	public void addHeading(WritableSheet sheet, int column, int row, String s)
			throws WriteException, RowsExceededException {
		Label label;
		label = new Label(column, row, s, timesHeading);
		sheet.addCell(label);
	}



/*START US5888: prbadam added for Ability to update person details by adding Secondary Mail ID*/
public String getSecondaryEmail(NodeRef personNode) throws Exception{
	logger.info("in side getSecondaryEmail-------");
	String secondaryEmailId=null;
	QName mailAspect = QName.createQName("http://www.alfresco.org/model/external/content/1.0", "mailAspect");
	QName secondaryMailName = QName.createQName("http://www.alfresco.org/model/external/content/1.0", "secondaryMail");
	boolean hasMailAspect = serviceRegistry.getNodeService().hasAspect(personNode, mailAspect);
	logger.info("hasMailAspect-------"+hasMailAspect);
	Serializable secondaryMailvalue = serviceRegistry.getNodeService().getProperty(personNode, secondaryMailName);
	if(hasMailAspect && secondaryMailvalue !=null && !secondaryMailvalue.toString().trim().equals("")){
		secondaryEmailId = (String) serviceRegistry.getNodeService().getProperty(personNode, QName.createQName("{http://www.alfresco.org/model/external/content/1.0}secondaryMail"));
	} 
	return secondaryEmailId;
}
/*END US5888: prbadam added for Ability to update person details by adding Secondary Mail ID*/

	//US9853-start of Opt in/out Email Notification
	private boolean optOutEmailNotify(NodeRef personNode){
		 boolean optOutEmailNotify=false;
		 boolean hasEmailNotificationAspect =false;
		 hasEmailNotificationAspect = serviceRegistry.getNodeService().hasAspect(personNode, ExternalSharingConstants.ASPECT_OPTINOUT_EMAIL_NOTIFICATION);
	          if(hasEmailNotificationAspect){
	        	  optOutEmailNotify = (Boolean) serviceRegistry.getNodeService().getProperty(personNode, ExternalSharingConstants.PROP_OPTOUT_EMAIL_NOTIFY);
	          }
		 
		return optOutEmailNotify;
	}
	//US9853-end of Opt in/out Email Notification


	public AuditService getAuditService() {
		return auditService;
	}



	public void setAuditService(AuditService auditService) {
		this.auditService = auditService;
	}



	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}



	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}


	public String getReportHeading() {
		return reportHeading;
	}



	public void setReportHeading(String reportHeading) {
		this.reportHeading = reportHeading;
	}



	public String getDays() {
		return days;
	}



	public void setDays(String days) {
		this.days = days;
	}



	public String getExcelPath() {
		return excelPath;
	}



	public void setExcelPath(String excelPath) {
		this.excelPath = excelPath;
	}



	public String getAttachmentName() {
		return attachmentName;
	}



	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}



	public String getSheetName() {
		return sheetName;
	}



	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}



//	public SessionFactory getSessionFactory() {
//		return sessionFactory;
//	}
//
//
//
//	public void setSessionFactory(SessionFactory sessionFactory) {
//		this.sessionFactory = sessionFactory;
//	}
//
	
	public SqlSessionFactory getLocalFactory() {
		return localFactory;
	}

	public void setLocalFactory(SqlSessionFactory localFactory) {
		this.localFactory = localFactory;
	}

	public String getSubjectLine() {
		return subjectLine;
	}


	public void setSubjectLine(String subjectLine) {
		this.subjectLine = subjectLine;
	}


	public String getBannerAlfrescoUrl() {
		return bannerAlfrescoUrl;
	}


	public void setBannerAlfrescoUrl(String bannerAlfrescoUrl) {
		this.bannerAlfrescoUrl = bannerAlfrescoUrl;
	}


	public String getFromEmail() {
		return fromEmail;
	}


	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}


	public String getMailServer() {
		return mailServer;
	}


	public void setMailServer(String mailServer) {
		this.mailServer = mailServer;
	}

	public String getFolderURL() {
		return folderURL;
	}

	public void setFolderURL(String folderURL) {
		this.folderURL = folderURL;
	}
	private SqlSession getSqlSession(){
		  Reader reader;
		  SqlSession dbSession = null;
		try {
			reader = Resources.getResourceAsReader("sql-processNodes-config.xml");
			localFactory = new SqlSessionFactoryBuilder().build(reader);
			dbSession = localFactory.openSession(); 
			logger.info("session>>>>>>"+session);
		} catch (Exception e) {
			logger.error("Error getting db session ",e);
		}
			return dbSession;
	  }


}
