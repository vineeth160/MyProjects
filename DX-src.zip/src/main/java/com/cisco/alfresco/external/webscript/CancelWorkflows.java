package com.cisco.alfresco.external.webscript;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.workflow.WorkflowModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthenticationService;
import org.alfresco.service.cmr.security.AuthorityService;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.workflow.WorkflowInstance;
import org.alfresco.service.cmr.workflow.WorkflowService;
import org.alfresco.service.cmr.workflow.WorkflowTask;
import org.alfresco.service.cmr.workflow.WorkflowTaskQuery;
import org.alfresco.service.namespace.QName;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.ext.workflow.CustomMailAction;


/**
 * Cancel workflows on a document based on conditions current user is initiator will be canceled by this code. Current
 * user is admin will be canceled by this code. current user is folder admin will be canceled by this code.
 * 
 * @author nathammi
 * 
 */
public class CancelWorkflows extends DeclarativeWebScript
{
    private static final Logger LOGGER = Logger.getLogger(CancelWorkflows.class);

    private WorkflowService workflowService;
    private NodeService nodeService;
    private AuthenticationService authenticationService;
    private AuthorityService authorityService;
    private PermissionService permissionService;
    private ServiceRegistry serviceRegistry;
    private  String bannerAlfrescoUrl;
    private String titleURL; 

    public String getBannerAlfrescoUrl() {
		return bannerAlfrescoUrl;
	}

	public void setBannerAlfrescoUrl(String bannerAlfrescoUrl) {
		this.bannerAlfrescoUrl = bannerAlfrescoUrl;
	}
	public String getTitleURL() {
		return titleURL;
	}

	public void setTitleURL(String titleURL) {
		this.titleURL = titleURL;
	}

	private static String REVIEW_CANCEL_TEMPLATE = "review$cancel";
    // private String templateName=REVIEW_CANCEL_TEMPLATE;
    private String TASK_IN_PROGRESS = "IN_PROGRESS";

    // private List<String> mailCc;
    private String ftlLocationPath;

    /**
     * this line of code will take the parameter of the WebscriptRequest and WebScriptResponse from the UI and process
     * the workflow cancelation.
     */
    @Override
    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
    {
        final Map<String, Object> model = new HashMap<String, Object>();
        List<String> mailCc = new ArrayList<String>();
        String inputJSONValue = readRequestBody(req);

        workflowService = serviceRegistry.getWorkflowService();
        nodeService = serviceRegistry.getNodeService();
        authenticationService = serviceRegistry.getAuthenticationService();
        authorityService = serviceRegistry.getAuthorityService();
        permissionService=serviceRegistry.getPermissionService();

        try
        {
            String userName = null;
            JSONObject jsonObject = new JSONObject(inputJSONValue);
            String nodeRefStr = jsonObject.getString("nodeId");
            String cancelComment = jsonObject.has("comment") ? jsonObject.getString("comment") : "";

            NodeRef node = new NodeRef(nodeRefStr);

            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("Request nodeRef id :" + node);
            }

            List<WorkflowInstance> workflows = new ArrayList<WorkflowInstance>();

            // Get all Active Workflows
            workflows.addAll(workflowService.getWorkflowsForContent(node, true));

            if (workflows != null && workflows.size() > 0)
            {
                if (LOGGER.isDebugEnabled())
                {
                    LOGGER.debug("Number of Workflows : " + workflows.size());
                }

                // list out the workflows the document is part of
                for (WorkflowInstance wi : workflows)
                {
                    WorkflowTaskQuery tasksQuery = new WorkflowTaskQuery();
                    tasksQuery.setTaskState(null);
                    tasksQuery.setActive(null);
                    tasksQuery.setProcessId(wi.getId());

                    List<WorkflowTask> tasks = workflowService.queryTasks(tasksQuery, false);
                    for (WorkflowTask taskObject : tasks)
                    {
                        if (!taskObject.getId().equals(workflowService.getStartTask(wi.getId()).getId()))
                        {
                            Map<QName, Serializable> taskProp = taskObject.getProperties();
                            String taskAssigneeEmail = getEmail((String) taskProp.get(ContentModel.PROP_OWNER));
                            mailCc.add(taskAssigneeEmail);

                            if (wi.getInitiator() != null)
                            {
                                userName = (String) nodeService.getProperty(wi.getInitiator(),
                                    ContentModel.PROP_USERNAME);

                            }

                            try
                            {
                                String taskStatus = taskObject.getState().toString();
                                if (taskStatus.equals(TASK_IN_PROGRESS))
                                {
                                    String currentUser = authenticationService.getCurrentUserName();
                                    if (userName.equals(currentUser) || authorityService.isAdminAuthority(currentUser))
                                    {
                                         cancelWorkflow(node, taskObject, currentUser, cancelComment);
                                    }
                                    else if (canUserHavePermission(node))
                                    {
                                        cancelWorkflow(node, taskObject, currentUser, cancelComment);
                                    }

                                    model.put("result", "The workflow canceled successfully");
                                }
                            }
                            catch (Exception e)
                            {
                                LOGGER.error("Exception : " + e);
                                model.put("result", "Failed to cancel workflow");
                            }
                        }
                    }
                }

                // for send mail
                sendMailNotification(node, REVIEW_CANCEL_TEMPLATE, userName, mailCc);

            }
            else
            {
                if (LOGGER.isDebugEnabled())
                {
                    LOGGER.debug("There is no workflow instances to cancel.");
                }
                model.put("result", "There is no workflow instances to cancel ");

            }

        }
        catch (InvalidNodeRefException ine)
        {
            LOGGER.error("InvalidNodeRefException : " + ine);
            model.put("result", "Operation Failed");
        }
        catch (Exception e)
        {
            LOGGER.error("Exception : " + e);
            model.put("result", "Operation Failed");
        }

        if (model.get("result") == null)
        {
            model.put("result", "You are not authorized to perform this operation");
        }
        return model;

    }

    /**
     * 
     * @param docNodeRef
     * @param task
     * @param currentUser
     * @param cancelComment
     * @return
     */
    private void cancelWorkflow(NodeRef docNodeRef, WorkflowTask task, String currentUser,
            String cancelComment)
    {
              
        propertyUpdates(docNodeRef);
        Map<QName, Serializable> parameters = task.getProperties();
    
        if (StringUtils.isEmpty(cancelComment))
        {
            parameters.put(WorkflowModel.PROP_COMMENT, "Document Cancelled by " + currentUser);
        }
        else
        {
            parameters.put(WorkflowModel.PROP_COMMENT, cancelComment);
        }
        parameters.put(WorkflowModel.PROP_PACKAGE_ACTION_GROUP, getVersionNum(docNodeRef));
        parameters.put(WorkflowModel.PROP_OUTCOME, "cancel");
        workflowService.updateTask(task.getId(), parameters, null, null);
        workflowService.endTask(task.getId(), "cancel");
    
    }

    /**
     * 
     * @param nodeRef
     */
    private void propertyUpdates(NodeRef nodeRef)
    {
        nodeService.setProperty(nodeRef, CiscoModelConstants.PROP_DOC_STATUS, "Draft");
        nodeService.setProperty(nodeRef, CiscoModelConstants.CISCO_WORKFLOW_STATUS_PROP, "Cancelled");
    }

    /**
     * 
     * @param node
     * @return
     */
    private boolean canUserHavePermission(NodeRef node)
    {
        boolean canPermission = false;
        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("Condition Check for User is folderAdmin :");
        }

        ChildAssociationRef childAssociationRef = nodeService.getPrimaryParent(node);
        NodeRef parentNoderef = childAssociationRef.getParentRef();

        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("Parent nodeRef of document is :" + parentNoderef);
        }

        Set<AccessPermission> accessPermissions = permissionService.getAllSetPermissions(parentNoderef);
        Iterator<AccessPermission> fIterator = accessPermissions.iterator();

        String currentUserName = authenticationService.getCurrentUserName();

        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("Current login UserName : " + currentUserName);
        }

        // AdminRole
        while (fIterator.hasNext())
        {
            AccessPermission accessPermission = (AccessPermission) fIterator.next();

            if (accessPermission.getAuthorityType() == AuthorityType.USER)
            {
                if (LOGGER.isDebugEnabled())
                {
                    LOGGER.debug("Authority(User): " + accessPermission.getAuthority() + " Permission:  "
                            + accessPermission.getPermission());
                }

                String autherityUserName = accessPermission.getAuthority();
                String autherityUserPermission = accessPermission.getPermission();
                if (autherityUserName.equals(currentUserName) && autherityUserPermission.equals("AdminRole"))
                {

                    if (LOGGER.isDebugEnabled())
                    {
                        LOGGER.debug("Condition Authority(User): " + accessPermission.getAuthority() + " Permission:  "
                                + accessPermission.getPermission());
                    }
                    canPermission = true;

                }
            }
        }

        return canPermission;
    }

    /**
     * 
     * @param req
     * @return
     */
    private String readRequestBody(WebScriptRequest req)
    {
        try
        {
            return IOUtils.toString(req.getContent().getInputStream(), req.getContent().getEncoding());
        }
        catch (Exception e)
        {
            try
            {
                return req.getContent().getContent();
            }
            catch (IOException e1)
            {
                LOGGER.error("Unable to read JSON request body", e1);
                throw new WebScriptException("Unable to read JSON request body!! Epic fail.");
            }
        }
    }

    /**
     * To Send Email Notifications
     */
    private void sendMailNotification(NodeRef nodeRef, String templateName, String userName, List<String> mailCc)
    {
        NodeRef emailTemplateRef = null;
        String documentName = null;
        String documentVersionLabel = null;
        String mailFrom = null;
        String mailTo = null;
        String subject = null;
        Date currentDate = new Date();
    	String year = new SimpleDateFormat("yyyy").format(currentDate); 
        try
        {
            documentName = getFileName(nodeRef);
            documentVersionLabel = getVersionNum(nodeRef);
            NodeRef currentUserNode = serviceRegistry.getPersonService().getPerson(userName);
            String currentUserFullName = ((String)serviceRegistry.getNodeService().getProperty(currentUserNode , ContentModel.PROP_FIRSTNAME)==null?"":(String)serviceRegistry.getNodeService().getProperty(currentUserNode, ContentModel.PROP_FIRSTNAME)) +" "+
            ((String)serviceRegistry.getNodeService().getProperty(currentUserNode, ContentModel.PROP_FIRSTNAME)==null?"":(String)serviceRegistry.getNodeService().getProperty(currentUserNode, ContentModel.PROP_LASTNAME)); 
            LOGGER.debug("currentUserFullName-----------" + currentUserFullName);
            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("Document Name for Send mail Notification : " + documentName);
                LOGGER.debug("Document Version Label for Send mail Notification : " + documentVersionLabel);
            }

            emailTemplateRef = getEmailtemplate(templateName);
            Map<String, Serializable> emailTemplateArgs = new HashMap<String, Serializable>();
            emailTemplateArgs.put("docName", documentName);
            emailTemplateArgs.put("currentUserFullName", currentUserFullName);
            emailTemplateArgs.put("version", documentVersionLabel);
            emailTemplateArgs.put("titleURL", titleURL); 
            emailTemplateArgs.put("year", year); 
            emailTemplateArgs.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
            mailFrom = getEmail(userName);
            mailTo = getEmail(userName);

            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("ExtApproval Mail From  : " + mailFrom);
                LOGGER.debug("ExtApproval Mail To  : " + mailTo);
                LOGGER.debug("mailcc Before : " + mailCc.toString());
            }

            // for removing email duplicates from list
            for (int i = 1; i < mailCc.size(); i++)
            {
                String a1 = mailCc.get(i);
                String a2 = mailCc.get(i - 1);
                if (a1.equals(a2))
                {
                    mailCc.remove(a1);
                }
            }
            if (mailCc.contains(mailFrom))
            {
                mailCc.remove(mailFrom);
            }

            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("mailcc After : " + mailCc.toString());
            }

            CustomMailAction mailAction = new CustomMailAction();
            subject =  currentUserFullName + " cancelled workflow for "+ documentName;
            		
            mailAction.sendMails(serviceRegistry, emailTemplateArgs, emailTemplateRef, subject, mailFrom, mailTo,
                mailCc, bannerAlfrescoUrl);
            mailCc.clear();
            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("Mail sent Successfully for Cancel Workflow :");
            }
        }
        catch (Exception e)
        {
            LOGGER.error("Exception in sendMailNotification method ", e);
        }
    }

    /**
     * @param userName
     * @return Get email of person
     */
    private String getEmail(String userName)
    {
        NodeRef personNodeRef = serviceRegistry.getPersonService().getPerson(userName, false);
        return (String) serviceRegistry.getNodeService().getProperty(personNodeRef, ContentModel.PROP_EMAIL);
    }

    private String getFileName(NodeRef nodeRef)
    {
        return (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_TITLE);
    }

    private String getVersionNum(NodeRef nodeRef)
    {
        if ((String) nodeService.getProperty(nodeRef, ContentModel.PROP_VERSION_LABEL) != null){
            return  (String) nodeService.getProperty(nodeRef, ContentModel.PROP_VERSION_LABEL);
        }else{
            return "1.0";
        }
    }

    /**
     * To Get Email Template
     */
    private NodeRef getEmailtemplate(String templateName)
    {
        String templateConditionalPath = "PATH:\"" + ftlLocationPath + "//*\" AND "
                + "TYPE:cm\\:content AND @cm\\:title:\"" + templateName + "\"";

        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("LUCENE QRY: " + templateConditionalPath);
        }

        ResultSet resultSet = serviceRegistry.getSearchService().query(
            new StoreRef(StoreRef.PROTOCOL_WORKSPACE, "SpacesStore"), SearchService.LANGUAGE_LUCENE,
            templateConditionalPath);

        if (resultSet.length() == 0)
        {
            LOGGER.error("Template " + templateConditionalPath + " not found.");
            return null;
        }

        NodeRef template = resultSet.getNodeRef(0);

        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("Got the Email Template:" + template.toString());
        }

        return template;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    public String getFtlLocationPath()
    {
        return ftlLocationPath;
    }

    public void setFtlLocationPath(String ftlLocationPath)
    {
        this.ftlLocationPath = ftlLocationPath;
    }
}
