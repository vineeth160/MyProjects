package com.cisco.alfresco.external.jobs;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.audit.AuditQueryParameters;
import org.alfresco.service.cmr.audit.AuditService;
import org.alfresco.service.cmr.audit.AuditService.AuditQueryCallback;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.repository.TemplateService;
import org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter;
import org.alfresco.service.cmr.repository.datatype.TypeConversionException;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.TempFileProvider;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.edcsng.util.MailUtil;
import com.cisco.alfresco.service.commons.ServiceConstants;
import com.cisco.edcsng.audit.bireports.utils.BIReportConstants;
import com.cisco.sd.rest.service.MigrationConstants;

public class UserAccessJobExecuter extends QuartzJobBean implements BIReportConstants {
	private static Log _logger = LogFactory.getLog(UserAccessJobExecuter.class);
	private ServiceRegistry serviceRegistry;
	private AuditService auditService;
	private static final String COMMA_DELIMITER = ",";
	private static final String NEW_LINE_SEPARATOR = "\n";
	private static final String FILE_HEADER = "USER,EMAIL_ID,EMAIL_NOIFICATION,USER_STATUS";
	private Properties globalProperties;
	private String mailerFromID;
	private String mailServer;
	private int maxCount;
	private int batchSize;
	private String excelPath;
	private String titleURL;
	private String attachmentName;
	private String attachment;	
	public String getAttachment() {
		return attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}
	
	public static String INACTIVE_USERS_REPORT_MAIL_DOWNLOAD_LINK_NOTIFICATION_TEMPLATE="/alfresco/extension/templates/email/inactiveUserMailDownloadlinkNotifications.ftl";
	
	private String bannerAlfrescoUrl;
	private String docexSupportUrl;
	private SessionFactory localFactory;		
	private String GET_EXTERNALUSERS_LUCENE = "TYPE:\"cm:person\" AND -@cm\\:email:*@cisco.com* AND NOT ASPECT:\"cm:personDisabled\"";
	private String mailerToID;
	public String getTitleURL() {
		return titleURL;
	}

	public void setTitleURL(String titleURL) {
		this.titleURL = titleURL;
	}

	public String getAttachmentName() {
		return attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	public String getMailerToID() {
		return mailerToID;
	}

	public void setMailerToID(String mailerToID) {
		this.mailerToID = mailerToID;
	}

	public String getAttachmentSize() {
		return attachmentSize;
	}

	public void setAttachmentSize(String attachmentSize) {
		this.attachmentSize = attachmentSize;
	}

	private String attachmentSize;
	public static String USERACCESS_STATUS_NOTIFICATION_TEMPLATE = "/alfresco/extension/templates/email/disableUserAccessUpdateNotification.ftl";
	private static final String KEY_IS_USER_ACCESS_JOB_ENABLED = "UserAccessJobEnabled";

	public int getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}

	public SessionFactory getLocalFactory() {
		return localFactory;
	}

	public void setLocalFactory(SessionFactory localFactory) {
		this.localFactory = localFactory;
	}

	public int getMaxCount() {
		return maxCount;
	}

	public void setMaxCount(int maxCount) {
		this.maxCount = maxCount;
	}

	public String getMailerFromID() {
		return mailerFromID;
	}

	public void setMailerFromID(String mailerFromID) {
		this.mailerFromID = mailerFromID;
	}

	public String getMailServer() {
		return mailServer;
	}

	public void setMailServer(String mailServer) {
		this.mailServer = mailServer;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public AuditService getAuditService() {
		return auditService;
	}

	public void setAuditService(AuditService auditService) {
		this.auditService = auditService;
	}

	public Properties getGlobalProperties() {
		return globalProperties;
	}

	public void setGlobalProperties(Properties globalProperties) {
		this.globalProperties = globalProperties;
	}

	public String getBannerAlfrescoUrl() {
		return bannerAlfrescoUrl;
	}

	public void setBannerAlfrescoUrl(String bannerAlfrescoUrl) {
		this.bannerAlfrescoUrl = bannerAlfrescoUrl;
	}

	public String getDocexSupportUrl() {
		return docexSupportUrl;
	}

	public void setDocexSupportUrl(String docexSupportUrl) {
		this.docexSupportUrl = docexSupportUrl;
	}

	@Override
	protected void executeInternal(JobExecutionContext executionContext) throws JobExecutionException {
		_logger.error("Start UserAccessJob Execution......");
		boolean isJobEnabled = false;
		JobDataMap jobData = executionContext.getJobDetail().getJobDataMap();
		String isJobEnabledStr = (String) jobData.get(KEY_IS_USER_ACCESS_JOB_ENABLED);
		if (isJobEnabledStr != null) {
			try {
				isJobEnabled = new Boolean(isJobEnabledStr);
			} catch (Exception e) {
				_logger.error("Invalid '" + KEY_IS_USER_ACCESS_JOB_ENABLED + "' value, using default: " + isJobEnabled,
						e);
			}
		}
		if (!isJobEnabled) {
			// skip Job
			_logger.error("Skipping " + KEY_IS_USER_ACCESS_JOB_ENABLED + " to execute.");
			return;
		}
		try {
			AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				@Override
				public Object doWork() throws Exception {
					processUserAccessAuditData();
					disableUsersAccessForBeforeMonth();
					disableInActiveUsersAccess();
					deleteActiveUsersDataInDB();
					return null;
				}

			}, "admin");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private List<Map<String, Object>> getUserAccessAuditQuery(Long fromTime, Long toTime, String user, String searchKey,
			final List<Map<String, Object>> entries) {
		try {
			int limit = 0;
			String queryLimit = globalProperties.getProperty("audit.results.limit");			
			_logger.info(" queryLimit =====" + queryLimit.toString() + "User ===" + user + " fromTime=" + fromTime
					+ "toTime===" + toTime + "searchKey==" + searchKey);
			if (queryLimit != null) {
				limit = Integer.parseInt(queryLimit);
			}
			final boolean verbose = true;
			_logger.info(" getUserAuditQuery started");
			// Execute the query
			AuditQueryParameters params = new AuditQueryParameters();
			params.setApplicationName(USER_ACCESS_APP_NAME);						
			params.setFromTime(fromTime);
			params.setToTime(toTime);
			params.setForward(false);
			if (user != null) {
				params.addSearchKey(searchKey, user);
			}

			_logger.info("params==" + params.toString() + "AppName" + params.getApplicationName() + "User"
					+ params.getUser() + "FromTime" + params.getFromTime() + "ToTime" + params.getToTime() + "ID"
					+ params.getToId());
			AuditQueryCallback callback = new AuditQueryCallback() {

				@Override
				public boolean valuesRequired() {
					return verbose;
				}

				@Override
				public boolean handleAuditEntryError(Long entryId, String errorMsg, Throwable error) {
					return true;
				}

				@Override
				public boolean handleAuditEntry(Long entryId, String applicationName, String user, long time,
						Map<String, Serializable> values) {
					_logger.info(" Handle query started");

					Map<String, Object> entry = new HashMap<String, Object>(11);
					entry.put(JSON_KEY_ENTRY_ID, entryId);
					entry.put(JSON_KEY_ENTRY_APPLICATION, applicationName);

					if (user != null) {
						entry.put(JSON_KEY_ENTRY_USER, user);
					}
					entry.put(JSON_KEY_ENTRY_TIME, new Date(time));

					if (values != null) {
						// Convert values to Strings
						Map<String, String> valueStrings = new HashMap<String, String>(values.size() * 2);
						for (Map.Entry<String, Serializable> mapEntry : values.entrySet()) {
							String key = mapEntry.getKey();
							Serializable value = mapEntry.getValue();
							try {
								String valueString = DefaultTypeConverter.INSTANCE.convert(String.class, value);
								valueStrings.put(key, valueString);
							} catch (TypeConversionException e) {
								// Use the toString()
								valueStrings.put(key, value.toString());
							}
						}
						entry.put(JSON_KEY_ENTRY_VALUES, valueStrings);						
					}
					entries.add(entry);
					_logger.info("<<==entries==>>"+ entries);					
					entry = null;
					return true;
				}

			};

			// Make an audit call to applicationName
			auditService.auditQuery(callback, params, limit);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return entries;

	}

	public boolean sendEMail(String strManagerID, String jobName, String fullName) {
		Map<String, Object> model = new HashMap<String, Object>();
		Date endDate = new Date();
		String year = new SimpleDateFormat("yyyy").format(endDate);
		String docExURL = bannerAlfrescoUrl + "/alfext/ui/#/whatsnew";
		model.put("jobName", jobName);
		model.put("fullName", fullName);
		model.put("currentYear", year);
		model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
		model.put("docexhyperlinkURL", docExURL);
		model.put("supporthyperlinkURL", docexSupportUrl);
		TemplateService templateService = serviceRegistry.getTemplateService();
		String strArray[] = strManagerID.split(",");
		String mailSubject = "Disable User Access Notification";
		String htmlBody = templateService.processTemplate(USERACCESS_STATUS_NOTIFICATION_TEMPLATE, model);

		boolean mailstatus = false;
		try {
			mailstatus = MailUtil.sendMail(mailServer, mailerFromID, strArray, null, mailSubject, htmlBody, null);
			_logger.info("Mail Sataus >>>" + mailstatus + "   For user  ::  " + strManagerID);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mailstatus;
	}

	private void processUserAccessAuditData() {

		Calendar cal = Calendar.getInstance();		
		cal.add(Calendar.DATE, -180);
		Date result = cal.getTime();		
		Long fromTime = result.getTime();
		Long toTime = System.currentTimeMillis();		
		String externalMails = null;
		String userName = null;
		String status = null;
		String emailStatus = null;
		String jobName = "UserAccessJobExecuter";
		boolean mailStatus = false;
		List<Map<String, Object>> entries = null;

		try {
			_logger.info("GET_EXTERNALUSERS_LUCENE : " + GET_EXTERNALUSERS_LUCENE);
			List<NodeRef> nodeRefList = getUsersList(GET_EXTERNALUSERS_LUCENE);
			//_logger.info("nodeRefList : " + nodeRefList);
			List<List<NodeRef>> batchesList = creatingBatches(nodeRefList, batchSize);
			//_logger.info("batchesList=== : " + batchesList + "==batchSize==" + batchSize);
			for (List<NodeRef> list : batchesList) {
				for (NodeRef nodeRef : list) {
					userName = (String) serviceRegistry.getNodeService().getProperty(nodeRef,
							ContentModel.PROP_USERNAME);
					//_logger.info("<<username>>:-"+ userName);
					entries = new ArrayList<Map<String, Object>>();
					getUserAccessAuditQuery(fromTime, toTime, userName, SEARCH_KEY_ACCESS_USER, entries);
					//_logger.info("entries Size:::::" + entries.size());
					boolean UserIdCheck = isUserIdExists(userName);
					_logger.info("==UserIdCheck==" + UserIdCheck);
					if (UserIdCheck) {
						if (UserIdCheck && entries != null && entries.size() > 0) {
							_logger.info("== entries.size() > 0");
							_logger.info("==userName==="+ userName);
							updateUserAuditData(userName);
							entries.clear();
							continue;
						} else {
							_logger.info("Skipping:::::" + userName);							
							continue;
						}

					} else {
						entries.clear();
					}

					if (entries != null && entries.size() == 0) {
						externalMails = (String) serviceRegistry.getNodeService().getProperty(nodeRef,
								ContentModel.PROP_EMAIL);
						//_logger.info("==externalMails==" + externalMails);
						String firstName = (String) serviceRegistry.getNodeService().getProperty(nodeRef,
								ContentModel.PROP_FIRSTNAME);
						String lastName = (String) serviceRegistry.getNodeService().getProperty(nodeRef,
								ContentModel.PROP_LASTNAME);
						String fullName = firstName + " " + lastName;
						mailStatus = sendEMail(externalMails, jobName, fullName);
						//_logger.info("==mailStatus==" + mailStatus);
						if (mailStatus && entries.size() == 0) {
							//_logger.info("==mailStatus== && entries.size() == 0");
							status = "InActive";
							emailStatus = String.valueOf(mailStatus);
							createUserData(userName, externalMails, status, emailStatus);
						} else if (!mailStatus && entries.size() == 0) {

							//_logger.info("==!mailStatus== && entries.size()== 0");
							status = "InActive";
							emailStatus = String.valueOf(mailStatus);
							createUserData(userName, externalMails, status, emailStatus);

						}

					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private List<NodeRef> getUsersList(String searchQuery) {
		int skipCount = 0;
		List<NodeRef> nodeRefList = null;
		while (true) {
			SearchParameters sp = new SearchParameters();
			sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
			sp.setLanguage(SearchService.LANGUAGE_LUCENE);
			sp.setMaxItems(50);
			sp.setSkipCount(skipCount);
			sp.setQuery(searchQuery);
			ResultSet results = serviceRegistry.getSearchService().query(sp);
			if(skipCount == 0)
				nodeRefList = new ArrayList<NodeRef>();
			if (null == results || results.length() <= 0)
				break;
			if(results != null && results.length() > 0) {
			for (ResultSetRow row : results) {
				nodeRefList.add(row.getNodeRef());
			}
			 results.close();
			}else {
				_logger.info("No Search Results found");
				break;
			}
			skipCount += 50;
		}
		return nodeRefList;
	}

	@SuppressWarnings("unchecked")
	private boolean isUserIdExists(String userId) {
		_logger.info("+++ entered into isUserIDExists method +++ ");
		boolean userExists = false;
		Session session = null;
		try {
			session = localFactory.openSession();
			String hql = "FROM UserStatusEntry E WHERE E.userId = :userid AND E.userStatus=:userstatus";
			_logger.info("===hql====" + hql);
			Query query = session.createQuery(hql);
			query.setParameter("userid", userId);
			query.setParameter("userstatus", "InActive");
			List<UserStatusEntry> results = query.list();
			_logger.info("===isUserIdExists=results===" + results);
			if (results != null && results.size() > 0) {
				userExists = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userExists;

	}

	@SuppressWarnings("unchecked")
	private void disableInActiveUsersAccess() {
		_logger.info("Entered into disableUsersAccess method");
		Session session = null;
		try {
			session = localFactory.openSession();
			String hql = " FROM UserStatusEntry E WHERE E.userStatus = :userstatus AND E.emailNotificationStatus=:emailnotificationstatus";
			_logger.info("===hql====" + hql);
			Query query = session.createQuery(hql);
			query.setParameter("userstatus", "InActive");
			query.setParameter("emailnotificationstatus", "false");
			List<UserStatusEntry> results = query.list();
			List<List<UserStatusEntry>> node = creatingBatches(results, batchSize);
			_logger.info("===node====" + node + "==batchSize==" + batchSize);
			for (List<UserStatusEntry> list : node) {
				for (UserStatusEntry UserStatusEntry : list) {
					String user = UserStatusEntry.getUserId();
					_logger.info("===user====" + user);
					boolean personExists = serviceRegistry.getPersonService().personExists(user);
					_logger.info("===personExists====" + personExists);
					if (personExists) {
						NodeRef personRef = serviceRegistry.getPersonService().getPersonOrNull(user);
						checkIfPersonShouldBeDisabledAndSetAspect(personRef, user);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	private void disableUsersAccessForBeforeMonth() {
		_logger.error("Entered into disableUsersAccessForeforeMonth method");
		Session session;
		
		try {
			
			session = localFactory.openSession();
			String hql = "select * from user_status_entry where DB_INSERTION_DATE <=";
			Calendar cal = Calendar.getInstance();
			DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
			cal.add(Calendar.DATE, -1);
			hql = hql + "'" + dateFormat.format(cal.getTime())
					+ "' and USER_STATUS='InActive' and EMAIL_NOTIFICATION_STATUS='true'";
			_logger.info("hql====" + hql);
			SQLQuery query = session.createSQLQuery(hql);

			List<Object[]> results = query.list();
			_logger.info("==disableUsersAccessForBeforeMonth==results===" + results + "===maxCount==" + maxCount);
			List<List<Object[]>> node = creatingBatches(results, batchSize);
			for (List<Object[]> list : node) {
				for (Object[] UserStatus : list) {
					//inactive users query parameters					
					 String user = UserStatus[0].toString();					
					 String emailId = UserStatus[1].toString();					
					 String emailStatus = UserStatus[2].toString();
					 String userStatus = UserStatus[3].toString();
					
					//_logger.info("inactive users:-"+ user+"email_data:-"+ emailId+"emailStatus:-"+ emailStatus+"userStatus:-"+ userStatus);																				
					StringBuffer filePaths = new StringBuffer();
					filePaths.append(TempFileProvider.getTempDir(excelPath))
							.append(attachment);
					File file = new File(filePaths.toString());
					
					exportToCSV(user,emailId,emailStatus,userStatus, file);
					_logger.info("exported successfully");
					//RemoveUserAccessJob.class.getMethods();
					//RemoveUserAccessJob res = new RemoveUserAccessJob();
					sendMailAttachment(mailServer,mailerFromID,mailerToID);
					_logger.info("mail sent successfully");
										
					boolean personExists = serviceRegistry.getPersonService().personExists(user);
					
					
					_logger.info("===personExists====" + personExists + "===User==" + user);
					if (personExists) {
						NodeRef personRef = serviceRegistry.getPersonService().getPersonOrNull(user);
						checkIfPersonShouldBeDisabledAndSetAspect(personRef, user);
					}
					
				}				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public NodeRef getUserHomeFolder() {
		NodeRef folderNodeRef = null;		
		String searchQuery = globalProperties.getProperty("reportspath.query");
		_logger.info("searchQuery   ::: " + searchQuery);
		folderNodeRef = EDCSUtil.doSearch(searchQuery, serviceRegistry);
		//logger.error("getUserHomeFolder   ::: " + folderNodeRef);
		return folderNodeRef;
	}
	public String getUniqueFileName(String name , NodeRef parentNodeRef){
		boolean fileNameExists=true;
		String filename=name;
		String tempFileName=name;
		int dotIndex,counter=1;
		while(fileNameExists){
			NodeRef node =serviceRegistry.getFileFolderService().searchSimple(parentNodeRef, tempFileName);
			if(node!=null){
				dotIndex = filename.lastIndexOf(".");
				if (dotIndex == 0) {
					// File didn't have a proper 'name' instead it had just a suffix and started with a ".", create "1.txt"
					tempFileName = counter + filename;
				} else if (dotIndex > 0) {
					// Filename contained ".", create "filename-1.txt"
					tempFileName = filename.substring(0, dotIndex) + "_"	+ counter + filename.substring(dotIndex);
				} else {
					// Filename didn't contain a dot at all, create "filename-1"
					tempFileName = filename + "-" + counter;
				}
				counter++;
			}else{
				fileNameExists=false;
			}
		}
		//logger.error("final tempFileName :: " + tempFileName);
		return tempFileName;
	}
private void addSharableAspectToLastLeafFolder(NodeRef leafFolderNodeRef) throws Exception{
		
		_logger.info("Enter into addSharableAspectToLastLeafFolder");
		Calendar deletionDate = Calendar.getInstance();
		deletionDate.add(Calendar.MONTH, 1);		
		Map<QName, Serializable> shareableAspectValues = new HashMap<QName, Serializable>();
		shareableAspectValues.put(MigrationConstants.CISCO_EXTERNAL_IS_EXTERNALLY_SHARED_PROP, false);
		Date publishExpirationDate=deletionDate.getTime();
		_logger.info("publishExpirationDate :::" + publishExpirationDate);		
		shareableAspectValues.put(MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP,publishExpirationDate);
		serviceRegistry.getNodeService().addAspect(leafFolderNodeRef, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT, shareableAspectValues);
		
		_logger.info("Attaching sharable aspect functionality done...");
	}
	
public boolean sendMailAttachment(String mailServer, String from, String to) throws Exception {
		
		String  downloadConstantMsg=null;
		String downloadUrl = null;
		InputStream in =null;
		Date endDate = new Date();
		String year = new SimpleDateFormat("yyyy").format(endDate);
		Map<String, Object> model = new HashMap<String, Object>();
		TemplateService templateService = serviceRegistry.getTemplateService();
		String mailSubject = "DocExchange Inactive Users Report";
	    model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
		model.put("currentYear", year);
		
		
		boolean mailstatus = false;
		try {
			StringBuffer filePaths = new StringBuffer();
			
			filePaths.append(TempFileProvider.getTempDir(excelPath)).append(attachmentName);
            File file = new File(filePaths.toString());
			_logger.info("file ------------>" + file.getAbsolutePath());
			long sizeInBytes = file.length();
			_logger.info("sizeInBytes->"+sizeInBytes);
			String fileName = filePaths.substring(filePaths.lastIndexOf("/"));
			fileName=fileName.replace("/", "");
			_logger.info("fileName---->"+fileName);
			
			String extension = fileName.substring(fileName.indexOf("."));
			_logger.info("extension---->"+extension);
			
			long sizeInKb = sizeInBytes / 1024 ;
			_logger.info("sizeInKb----->"+sizeInKb); 
			
			//long newsize=Long.parseLong(attachmentSize);

			
				_logger.info("Enter into if block");
				in = new BufferedInputStream(new FileInputStream(file));
				
				NodeRef usersHomeFolderNodeRef = getUserHomeFolder();
				_logger.info("usersHomeFolderNodeRef---->"+usersHomeFolderNodeRef);
				NodeRef fileNode = null;
				if(usersHomeFolderNodeRef!=null) {
					 _logger.info("Enter into usersHomeFolderNodeRef---------");
					 List<FileInfo> FileList = serviceRegistry.getFileFolderService()
							 .listFiles(usersHomeFolderNodeRef);
					
					 
					 for (FileInfo fileInfo : FileList) {
						 NodeRef node = fileInfo.getNodeRef();				
						 String repoFileName = (String) serviceRegistry.getNodeService().getProperty(node,
						 ContentModel.PROP_NAME);
						
						 if (repoFileName.equalsIgnoreCase(fileName)) {
							 fileNode = node;
							 serviceRegistry.getPermissionService().setPermission(fileNode, "GROUP_CISCOSHARE_SUPPORT","ReaderRole", true);
							 _logger.info("fileNode" +fileNode);

						 }
						 }
					 if(fileNode == null) {
					 _logger.info("inside the loop");
					 fileNode=	(serviceRegistry.getFileFolderService().create(usersHomeFolderNodeRef,getUniqueFileName(fileName,usersHomeFolderNodeRef),ServiceConstants.TYPE_CISCODOCS)).getNodeRef();
					_logger.info("newNodeRef---->"+fileNode);					
					 }
						ContentWriter writer = serviceRegistry.getContentService().getWriter(fileNode,ContentModel.TYPE_CONTENT, true);
						
					 if(extension.equals(".csv")) {
							_logger.info("Enter into extension.equals if block");
						writer.setMimetype("text/csv");
						}else {
							_logger.info("Enter into extension.equals else block");
							writer.setMimetype("application/vnd.ms-excel");
						}
					 
						writer.putContent(in);
					 
						
					boolean isDocument = serviceRegistry.getDictionaryService().isSubClass(serviceRegistry.getNodeService().getType(fileNode), ContentModel.TYPE_CONTENT);
					_logger.info("isDocument :::: "+isDocument);
					if(isDocument) {
					_logger.info("isDocument in if block----------");										
					addSharableAspectToLastLeafFolder(fileNode);
					//adding permissions to support group		 
					//serviceRegistry.getPermissionService().setPermission(fileNode, "GROUP_CISCOSHARE_SUPPORT","ReaderRole", true);
					downloadUrl=titleURL+"/alfext/ext/download/workspace/SpacesStore/"+fileNode.getId()+"/"+URLEncoder.encode(fileName,"UTF-8").replaceAll("\\+", "%20")+"?a=true";
			         _logger.info("downloadUrl::::::: " + downloadUrl);
	        		 downloadConstantMsg ="<span style='color:#6683BF;text-decoration: none;'><a href="+downloadUrl+">Click here</a></span> to DOWNLOAD the file to your desktop";
	        		  _logger.info(" Document download url ::::::: "+downloadConstantMsg);
	        		  model.put("navigatePemissionMsg", downloadConstantMsg);
	        		  String htmlBody = templateService.processTemplate(INACTIVE_USERS_REPORT_MAIL_DOWNLOAD_LINK_NOTIFICATION_TEMPLATE, model);
					mailstatus = MailUtil.sendMail(mailServer,mailerFromID, mailerToID, null, mailSubject,htmlBody,null);
						_logger.error("Single Mail Sataus ::: " + mailstatus);
					}
					}
				
			
			return true;
			
		} catch (Exception e) {
			_logger.error("EmailUtil Exception.." + e);
			return false;
		}
		
	}
		
	

	private void createUserData(String userId, String emailId, String status, String emailNotification) {
		_logger.info("Entered into createUserData method");
		Session session = null;
		Transaction tx = null;
		UserStatusEntry disableEntry = new UserStatusEntry();

		try {
			session = localFactory.openSession();
			tx = session.beginTransaction();
			Date today = new Date();
			if (userId != null && !userId.isEmpty()) {
				disableEntry.setUserId(userId);
			}
			if (emailId != null && !emailId.isEmpty()) {
				disableEntry.setEmailAddress(emailId);
			}
			if (status != null && !status.isEmpty()) {
				disableEntry.setUserStatus(status);
			}
			if (emailNotification != null && !emailNotification.isEmpty()) {
				disableEntry.setEmailNotificationStatus(emailNotification);
			}
			if (today != null) {
				disableEntry.setDbInsertionDate(today);
			}
			session.saveOrUpdate(disableEntry);
			_logger.info(disableEntry.getUserId() + "=========" + disableEntry.getEmailAddress() + "======"
					+ disableEntry.getUserStatus() + "=========" + disableEntry.getEmailNotificationStatus()
					+ "===========" + disableEntry.getDbInsertionDate());

			tx.commit();

			_logger.info("==User Audit Data Saved successfully:");
			session.close();
		} catch (Exception e) {
			tx.rollback();
			_logger.info("Error occured While updating " + e.getMessage());
			e.printStackTrace();

		}

	}

	private void checkIfPersonShouldBeDisabledAndSetAspect(NodeRef person, String userName) {
		if (!serviceRegistry.getNodeService().hasAspect(person, ContentModel.ASPECT_PERSON_DISABLED)) {
			_logger.info("==Noderef==" + person + "==ASPECT_PERSON_DISABLED=="
					+ serviceRegistry.getNodeService().hasAspect(person, ContentModel.ASPECT_PERSON_DISABLED));
			serviceRegistry.getNodeService().addAspect(person, ContentModel.ASPECT_PERSON_DISABLED, null);
			serviceRegistry.getAuthenticationService().setAuthenticationEnabled(userName, false);
			_logger.info("User disabled successfully ");
		}

	}

	private void updateUserAuditData(String user) {
		_logger.info("Entered into updateUserAuditData method");
		Session session = null;
		Transaction tx = null;
		try {
			session = localFactory.openSession();
			tx = session.beginTransaction();
			String hql = "update UserStatusEntry E set E.userStatus=? where E.userId=?";
			_logger.info("==hql====:" + hql);
			Query qry = session.createQuery(hql);
			qry.setParameter(0, "Active");
			qry.setParameter(1, user);
			int res = qry.executeUpdate();
			tx.commit();
			_logger.info("==res====:" + res);
			_logger.error("==User Audit Data Updated successfully:");
		} catch (Exception e) {
			tx.rollback();
			_logger.error("Error occured While updating " + e.getMessage());
			e.printStackTrace();
		}
	}

	private void deleteActiveUserAuditDataInDB(String user) {
		_logger.info("Entered into deleteActiveUserAuditDataInDB method");
		Session session = null;
		Transaction tx = null;
		try {
			session = localFactory.openSession();
			tx = session.beginTransaction();
			String hql = "delete from UserStatusEntry E where E.userStatus=? AND E.userId=?";
			_logger.info("==hql====:" + hql);
			Query qry = session.createQuery(hql);
			qry.setParameter(0, "Active");
			qry.setParameter(1, user);
			int res = qry.executeUpdate();
			tx.commit();
			_logger.info("==res====:" + res);
			_logger.info("==User deleted successfully:");
		} catch (Exception e) {
			tx.rollback();
			_logger.info("Error occured While updating " + e.getMessage());
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	private void deleteActiveUsersDataInDB() {
		_logger.info("Entered into deleteActiveUsersDataInDB method");
		Session session = null;
		try {
			session = localFactory.openSession();
			String hql = "select * from user_status_entry where USER_STATUS='Active'";
			_logger.info("hql====" + hql);
			SQLQuery query = session.createSQLQuery(hql);
			List<Object[]> results = query.list();
			List<List<Object[]>> node = creatingBatches(results, batchSize);
			_logger.info("===node====" + node + "==batchSize==" + batchSize);
			for (List<Object[]> list : node) {
				for (Object[] UserStatus : list) {
					String user = UserStatus[0].toString();
					_logger.info(" User=====" + user);
					deleteActiveUserAuditDataInDB(user);

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private <T> List<List<T>> creatingBatches(List<T> input, int batchSize) {

		int inputSize = input.size();
		_logger.info("==inputSize====:" + inputSize);
		int chunkCount = (int) Math.ceil(inputSize / (double) batchSize);
		_logger.info("==chunkCount====:" + chunkCount);
		Map<Integer, List<T>> map = new HashMap<>(chunkCount);
		List<List<T>> batches = new ArrayList<>(chunkCount);

		for (int i = 0; i < inputSize; i++) {

			map.computeIfAbsent(i / batchSize, (ignore) -> {

				List<T> batch = new ArrayList<>();
				batches.add(batch);
				return batch;

			}).add(input.get(i));
		}
		_logger.info("==batches====:" + batches);
		return batches;
	}

	private void exportToCSV(String user,String emailId,String emailStatus,String userStatus, File file) throws IOException {
		_logger.info("Enter into exportCSV----------");
		_logger.info("file ------------>" + file.getAbsolutePath());
		PrintWriter pw = null;
		try {

			boolean fileExists = file.exists();			
			if (fileExists) {
				
				FileWriter fstream = new FileWriter(file.getAbsolutePath(), true);
				BufferedWriter fbw = new BufferedWriter(fstream);
				String data = user + COMMA_DELIMITER + emailId + COMMA_DELIMITER + emailStatus + COMMA_DELIMITER + userStatus;
				_logger.info("data---->" + data);
				fbw.write(data);
				fbw.newLine();
				fbw.close();
			} else {				
				pw = new PrintWriter(file);

				StringBuilder builder = new StringBuilder();
				// No need give the headers Like: id, Name on builder.append
				builder.append(FILE_HEADER + NEW_LINE_SEPARATOR);

				String data = user + COMMA_DELIMITER + emailId + COMMA_DELIMITER + emailStatus + COMMA_DELIMITER + userStatus ;

				builder.append(data);
				// LOGGER.info("builder.append(data)------->"+builder.append(data));
				builder.append(NEW_LINE_SEPARATOR);
				pw.write(builder.toString());

				pw.close();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public String getExcelPath() {
		return excelPath;
	}

	public void setExcelPath(String excelPath) {
		this.excelPath = excelPath;
	}
	
	
}

