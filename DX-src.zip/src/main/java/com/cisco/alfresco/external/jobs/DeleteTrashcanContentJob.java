package com.cisco.alfresco.external.jobs;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.apache.log4j.Logger;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * Trashcan content is not getting cleaned
 *
 */
public class DeleteTrashcanContentJob extends QuartzJobBean {

	private static final Logger logger = Logger.getLogger(DeleteTrashcanContentJob.class);
	private ServiceRegistry serviceRegistry;
	private static final String KEY_IS_JOB_ENABLED = "deleteTrashcanNodesJobEnable";
	private boolean isJobEnabled = false;
	private static final String DATE_FORMAT = "yyyy-MM-dd";
	private static String PATH_QUERY ="PATH:\"/sys:archivedItem\" AND ((TYPE:\"cs:ciscodoc\") OR (TYPE:\"cm:folder\")) AND ASPECT:\"sys:archived\" AND @sys\\:archivedDate:[MIN TO \"toDate\"]";
	private static final int DAYSTOSUBTRACT = 30;
	private String deleteTrashcanNodesMaxValue;
	public String getDeleteTrashcanNodesMaxValue() {
		return deleteTrashcanNodesMaxValue;
	}

	public void setDeleteTrashcanNodesMaxValue(String deleteTrashcanNodesMaxValue) {
		this.deleteTrashcanNodesMaxValue = deleteTrashcanNodesMaxValue;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		logger.info("DeleteTrashcanContentJob Start :::");
		 JobDataMap jobData = context.getJobDetail().getJobDataMap();
	        String isJobEnabledStr = (String) jobData.get(KEY_IS_JOB_ENABLED);
	      if (isJobEnabledStr != null)
         {
	            try
                {
	            	isJobEnabled=Boolean.parseBoolean(isJobEnabledStr);
	            }
	            catch (Exception e)
	            {
	                logger.error("Invalid '" + KEY_IS_JOB_ENABLED + "' value, using default: " + isJobEnabled, e);
              }
           }

	        if (!isJobEnabled)
	        {
	            logger.error("Skipping " + KEY_IS_JOB_ENABLED + " to execute.");
	            return;
	        }
		
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
        {
            public Object doWork() throws Exception
            {
            	List<NodeRef> nodeRefList =null;
            	String searchQuery=PATH_QUERY;
            	searchQuery = searchQuery.replace("toDate", getToDate(DAYSTOSUBTRACT));
		nodeRefList = getTrashContentList(searchQuery);
		logger.error("DeleteTrashcanContentJob size ::::: " +nodeRefList.size());
		if(nodeRefList!=null && !nodeRefList.isEmpty()){
			for(NodeRef node : nodeRefList){
				if(serviceRegistry.getNodeService().exists(node)) {
					serviceRegistry.getNodeService().deleteNode(node);
					logger.error("Removed from Trashcan NodeId:::::  " +node);
				}
			}
		}else {
			logger.error("No Items found in trashcan to remove");
		}
		return null;
            }
        }, "admin");
		
	}
	
	/**
	 * @param searchQuery
	 * @return
	 */
	private List<NodeRef> getTrashContentList(String searchQuery){ 
		logger.error("searchQuery   ::: "+ searchQuery);
		int maxValue=Integer.parseInt(deleteTrashcanNodesMaxValue);
			int skipCount = 0;
			List<NodeRef> nodeRefList = null;
			while(true)
			{
			   SearchParameters sp = new SearchParameters();
			   sp.addStore(StoreRef.STORE_REF_ARCHIVE_SPACESSTORE);
			   sp.setLanguage(SearchService.LANGUAGE_LUCENE);
			   sp.setMaxItems(100);
			   sp.setSkipCount(skipCount);
			   sp.setQuery(searchQuery);
			   ResultSet results = serviceRegistry.getSearchService().query(sp);
			   if(skipCount == 0)
			      nodeRefList = new ArrayList<NodeRef>();
			   if (null == results || results.length() <= 0)
			      break;
			   for (ResultSetRow row : results) {
			      nodeRefList.add(row.getNodeRef());
			   }
    		   results.close();
			   if(skipCount == maxValue)
			      break;
			   skipCount += 100;
			}
			return nodeRefList;
	}
	
    /**
     * get date format based on number of days
     * @param daysToSubtract
     * @return
     */
    private String getToDate(int daysToSubtract)
    {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -daysToSubtract);
        SimpleDateFormat formatedDate = new SimpleDateFormat(DATE_FORMAT);
        String toDate = formatedDate.format(c.getTime());
        return toDate.toString();
    }
}