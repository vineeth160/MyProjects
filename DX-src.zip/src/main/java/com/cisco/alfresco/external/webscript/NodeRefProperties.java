package com.cisco.alfresco.external.webscript;

import java.io.IOException;
import java.io.Serializable;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import java.util.Iterator;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.ContentData;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AccessStatus;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.cmr.version.VersionService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.namespace.RegexQNamePattern;
import org.alfresco.util.ISO9075;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.alfresco.service.cmr.security.AuthorityType;

import com.cisco.alfresco.external.common.model.ExtDocument;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.alfresco.external.domain.CheckDomain;
import com.cisco.alfresco.external.uploadFavorite.FavUploadFile;
import com.cisco.alfresco.external.utils.CharUtil;
import com.cisco.alfresco.external.viewfav.Viewfav;
import com.cisco.sd.rest.service.MigrationConstants;


public class NodeRefProperties extends DeclarativeWebScript
{

    private static final Logger LOGGER = Logger.getLogger(NodeRefProperties.class);
    private static final QName ASSOC_NAME_MYFAVORITE_ASSOCIATE = QName.createQName(
        "http://www.cisco.com/model/content/1.0", "myFavorite");
    private ServiceRegistry serviceRegistry;
    private NodeService nodeService;
    private NamespaceService namespaceService;
    private VersionService versionService;
    private String alfrescoURL, alfextHost, alfextPort, contextName;
    private static final String GROUP_IDENTITY ="GROUP_";
    private static final String GROUP_EVERYONE="GROUP_EVERYONE";
    private PermissionService permissionService = null;
    private Properties globalProperties;

    public PermissionService getPermissionService()
    {
        return permissionService;
    }

    public void setPermissionService(PermissionService permissionService)
    {
        this.permissionService = permissionService;
    }

    public String getAlfrescoURL()
    {
        return alfrescoURL;
    }

    public void setAlfrescoURL(String alfrescoURL)
    {
        this.alfrescoURL = alfrescoURL;
    }

    public String getAlfextHost()
    {
        return alfextHost;
    }

    public void setAlfextHost(String alfextHost)
    {
        this.alfextHost = alfextHost;
    }

    public String getAlfextPort()
    {
        return alfextPort;
    }

    public void setAlfextPort(String alfextPort)
    {
        this.alfextPort = alfextPort;
    }

    public String getContextName()
    {
        return contextName;
    }

    public void setContextName(String contextName)
    {
        this.contextName = contextName;
    }

    @Override
    public Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
    {
        LOGGER.info("Inside Execute Impl........");
        LOGGER.info("alfextHost" + alfextHost);
        LOGGER.info("alfextPort :" + alfextPort);
        LOGGER.info("contextName: :" + contextName);
        LOGGER.info("nodeService: : " + nodeService);

        final String noderef = req.getParameter("id");
        final NodeRef nodeRef = new NodeRef(noderef);
        LOGGER.info("nodereff  : :" + nodeRef);
        String allversion = req.getParameter("allversions");
        Map<String, Object> model = new HashMap<String, Object>();
        String hostname = req.getParameter("geoHostName");
        LOGGER.info("hostname   : :" + hostname);
        if(!hostname.isEmpty()&& hostname != null){
			hostname = Viewfav.hostValidation(hostname);
			LOGGER.info("------------------------->>>> : "+hostname);
		}
        final StringBuilder access = new StringBuilder();
        
      //for support page US11203
        boolean opsRequest = Boolean.parseBoolean(req.getParameter("isOpsRequest"));
        String currentLoginUserName = AuthenticationUtil.getFullyAuthenticatedUser();
        if(opsRequest && isSupportGroupUser(currentLoginUserName)) {
			AuthenticationUtil.setAdminUserAsFullyAuthenticatedUser();
		}
        
        
        AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
        {

            @Override
            public Object doWork() throws Exception
            {

                String currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
                LOGGER.info("current user......" + currentUser);

                boolean hasAccess = hasAccess(currentUser, nodeRef, serviceRegistry);
                LOGGER.info("hasAccess..........." + hasAccess);
                access.append(hasAccess);
                LOGGER.info("access..........." + access);
                return null;
            }
        }, "admin");

        LOGGER.info("outside authentication util...........");

        // DE2328 STARTS
        if (!AccessStatus.ALLOWED.equals(permissionService.hasPermission(nodeRef, "Preview")))
        {
            model.put("failure", true);
            return model;
        }
        // DE2328 ENDS

        if (access.toString() != null && access.toString().equals("true"))
        {
            LOGGER.info("inside if...........");
            model = populateNodeRefProperties(nodeRef, allversion,hostname);
        }
        else
        {
            model.put("failure", true);
        }
        return model;

    }

    private Map<String, Object> populateNodeRefProperties(NodeRef nodeRef, String allVersion,String hostname)
    {
        Map<String, Object> model = new HashMap<String, Object>();

        List<ExtDocument> documentList = new ArrayList<ExtDocument>();

        if (Boolean.TRUE.toString().equals(allVersion))
        {
            // VersionNode Response
            model.put("allVersion", true);
            documentList = populateAllVersionNodeRefProperties(nodeRef,hostname);
        }
        else
        { // LiveNode Response
            model.put("allVersion", false);
            documentList = populateLiveNodeRefProperties(nodeRef,hostname);
        }

        try
        {
            ObjectMapper mapper = new ObjectMapper();
            StringWriter responseWriter = new StringWriter();
            mapper.writeValue(responseWriter, documentList);
            String responseJSON = responseWriter.toString();
            LOGGER.info("Result JSON : " + responseJSON);

            model.put("docLst", documentList);

        }
        catch (JsonGenerationException e)
        {

            LOGGER.error("Exception..........." + e);
            //e.printStackTrace();
        }
        catch (JsonMappingException e)
        {

            LOGGER.error("Exception..........." + e);
            //e.printStackTrace();
        }
        catch (IOException e)
        {
            LOGGER.error("Exception..........." + e);
            //e.printStackTrace();
        }

        return model;
    }

    private List<ExtDocument> populateAllVersionNodeRefProperties(NodeRef nodeRef,String hostname)
    {
        List<ExtDocument> documentList = new ArrayList<ExtDocument>();
        ExtDocument document = null;
        DateFormat df;
        df = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);

        VersionHistory versionHistory = versionService.getVersionHistory(nodeRef);
        LOGGER.info("version history..........." + versionHistory);
        // Version Node Props
        if (versionHistory != null && versionHistory.getAllVersions().size() > 0)
        {
            Collection<Version> versions = versionHistory.getAllVersions();

            for (Version versionNode : versions)
            {
                document = new ExtDocument();

                // Common Props of a Node
                populateCommonProperties(nodeProp, document, nodeRef);

                // Properties from VersioNode
                NodeRef vnodeRef = versionNode.getFrozenStateNodeRef();
                document.setNodeId(vnodeRef.toString());
                LOGGER.info("version noderef........" + vnodeRef);
                String versionLabel = versionNode.getVersionLabel();
                document.setVersion(Double.parseDouble(versionNode.getVersionLabel()));
                LOGGER.info("versionLabel:" + versionNode.getVersionLabel());

                // Version Specific Properties
                Map<String, Serializable> versionNodeRefProps = versionNode.getVersionProperties();
                Map<QName, Serializable> versionNodeProps = nodeService.getProperties(vnodeRef);
                LOGGER.info("versionNodeRefProps............." + versionNodeRefProps);
                // document.setOwner((String) versionNodeRefProps.get(ContentModel.PROP_CREATOR.getLocalName()));
                // document.setModifier((String) versionNodeRefProps.get(ContentModel.PROP_MODIFIER.getLocalName()));
                document.setCreationdate(df.format((Date) versionNodeProps.get(ContentModel.PROP_CREATED)));
                document.setModifieddate(df.format((Date) versionNodeProps.get(ContentModel.PROP_MODIFIED)));

                String vfilename = (String) versionNodeRefProps.get(ContentModel.PROP_NAME);

              //  ContentData vcontentData = (ContentData) versionNodeRefProps.get(ContentModel.PROP_CONTENT
              //          .getLocalName());
               // document.setSize((int) vcontentData.getSize());
                try
                {
                   // LOGGER.info("###########Correct mime type  " + vcontentData.getMimetype());
                   // document.setMimetype(vcontentData.getMimetype());

                    vfilename = (String) versionNodeRefProps.get("name");
                    vfilename = CharUtil.replaceEscape(vfilename);
                    LOGGER.info("###########Correct file name  vfilename after replaceEscape" + vfilename);
                    document.setName(vfilename);
                    document.setType(vfilename.substring(vfilename.lastIndexOf(".") + 1, vfilename.length()));
                    LOGGER.info("###########Correct type"
                            + vfilename.substring(vfilename.lastIndexOf(".") + 1, vfilename.length()));

                }
                catch (Exception exception)
                {
                    LOGGER.error("############Exception at this point", exception);
                }
                String enVfilename = ISO9075.encode(vfilename);

                /**
                 * Vera protected docs file names allways ends with .html extension to the original filename.
                 * If the document is protected with vera, then append .html extension to the file name
                 */
                String downloadUrl = null;
                String applyVeraProtection = ExternalSharingFileFolderUtil.getFolderVeraProtectionStatus(nodeRef, serviceRegistry);
                Boolean isDocVeraProtected = (Boolean) versionNodeRefProps.get("isDocVeraProtected");
                String security = (String) versionNodeProps.get(ExternalSharingConstants.PROP_EXT_SECURITY);
                if((applyVeraProtection != null && security != null) && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals(security))){
                	document.setApplyVeraProtection(applyVeraProtection);
                	//downloadUrl = alfrescoURL + contextName + "/ext/download/" + vnodeRef.toString().replace(":/", "") + "/" + enVfilename + ".html?a=true";
                } else {
                	document.setApplyVeraProtection("");
                	//downloadUrl = alfrescoURL + contextName + "/ext/download/" + vnodeRef.toString().replace(":/", "") + "/" + enVfilename + "?a=true";
                }
                
                
              //Added/modified For GCS- Start
                String tempMimeType = "";
                boolean issyncedprop = false;
                String nodeUploadedGeolocation = null;
                if(serviceRegistry.getNodeService().hasAspect(vnodeRef,ExternalSharingConstants.CISCO_GLOBAL_CACHING_ASPECT)){
                	nodeUploadedGeolocation = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_UPLOAD_GELOLOCATION_PROP);
         			 if(nodeUploadedGeolocation != null){
                	issyncedprop = (Boolean) serviceRegistry.getNodeService().getProperty(vnodeRef, ExternalSharingConstants.CISCO_QNAME_IS_FILE_SYNCHED_PROP);
                 if(!issyncedprop){
                 long size = (Long) serviceRegistry.getNodeService().getProperty(vnodeRef, ExternalSharingConstants.CISCO_QNAME_GCS_TEMP_SIZE);
                 	tempMimeType = (String) serviceRegistry.getNodeService().getProperty(vnodeRef,ExternalSharingConstants.CISCO_QNAME_GCS_TEMP_MIMETYPE);
                 	document.setSize((int) (size));
                 	LOGGER.info("size not synced :: " +size + "  tempMimeType :: "+tempMimeType);
                 }
                 else{
                	 long size = ((ContentData) serviceRegistry.getNodeService().getProperty(vnodeRef,
                             ContentModel.PROP_CONTENT)).getSize();
                	 document.setSize((int) (size));
                 }
                }else{
                	issyncedprop = true;
                	long size = ((ContentData) serviceRegistry.getNodeService().getProperty(vnodeRef,
                            ContentModel.PROP_CONTENT)).getSize();
               	 document.setSize((int) (size));
                }
            }
            	else{
            		LOGGER.info("issynced :: " +issyncedprop);
            		issyncedprop =  true;
            		long size = ((ContentData) serviceRegistry.getNodeService().getProperty(vnodeRef,
                    ContentModel.PROP_CONTENT)).getSize();
            		document.setSize((int) (size));
                LOGGER.info("size :: " +size);
                }
                document.setSynced(issyncedprop);
                if(tempMimeType.isEmpty() || tempMimeType == null){
                	document.setMimetype(((ContentData) nodeService.getProperty(vnodeRef, ContentModel.PROP_CONTENT)).getMimetype());
                }else{
                	document.setMimetype(tempMimeType);
                }
                //Added/modified for Gcs-End
                
                
                
                //UTHRA START _GCS
                
               
                
                if(serviceRegistry.getNodeService().hasAspect(nodeRef,ExternalSharingConstants.CISCO_GLOBAL_CACHING_ASPECT)){
                	nodeUploadedGeolocation = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_UPLOAD_GELOLOCATION_PROP);
          			 LOGGER.info("nodeUploadedGeolocation :: " +nodeUploadedGeolocation);
          		}
               if(nodeUploadedGeolocation != null && hostname != null){
                	boolean issynced = (Boolean) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_IS_FILE_SYNCHED_PROP);
                	if(!issynced){
                		String redirectUrl = "https://"+nodeUploadedGeolocation;
                		LOGGER.info("redirectUrl  :: " +redirectUrl); // redirect to the server where it was uploaded
                		if((isDocVeraProtected != null && isDocVeraProtected) || (security != null && security.equals("Cisco Restricted"))){
                		downloadUrl = alfrescoURL + contextName + "/ext/download/" + vnodeRef.toString().replace(":/", "") + "/" + enVfilename + ".html?a=true";
                        }else{
                        downloadUrl = redirectUrl + contextName + "/ext/download/"+ vnodeRef.toString().replace(":/", "") + "/" + enVfilename + "?a=true";
                        }
                	}
                	else{
                		LOGGER.info("file synced so download from local repo ");
                		// its synced so sync central repository
                		if((isDocVeraProtected != null && isDocVeraProtected) || (security != null && security.equals("Cisco Restricted"))){ 
                		downloadUrl = alfrescoURL + contextName + "/ext/download/" + vnodeRef.toString().replace(":/", "") + "/" + enVfilename + ".html?a=true";
                		 }else{
                		 downloadUrl = "https://"+hostname + contextName + "/ext/download/"+ vnodeRef.toString().replace(":/", "") + "/" + enVfilename + "?a=true"; // need to check
                		 }
                    	 LOGGER.info("downloadurl sync value true so download from local repo :: " +downloadUrl);
 	                    
                	}
                 }
                	else {
                		if((isDocVeraProtected != null && isDocVeraProtected) || (security != null && security.equals("Cisco Restricted"))){ 
                		downloadUrl = alfrescoURL + contextName + "/ext/download/" + vnodeRef.toString().replace(":/", "") + "/" + enVfilename + ".html?a=true";
                		 }else{
                    	 downloadUrl = alfrescoURL + contextName + "/ext/download/"+ vnodeRef.toString().replace(":/", "") + "/" + enVfilename + "?a=true";
                		 }
                    	  }
              
                
                //Uthra GCS  - END
                
                
                
                LOGGER.info("Download URL:" + downloadUrl);
                //US7371 -- end
                document.setDownloadUrl(downloadUrl);
                QName extShareableAspect = QName
                        .createQName("{http://www.alfresco.org/model/external/content/1.0}extShareableAspect");
                boolean externalyShared = false;
                if (nodeService.hasAspect(vnodeRef, extShareableAspect))
                {

                    LOGGER.info("...............externally Shared aspect present........");
                    externalyShared = (Boolean) versionNodeProps.get(QName.createQName(
                        "http://www.alfresco.org/model/external/content/1.0", "isExternalyShared"));
                }

                document.setExternalyShared(externalyShared);
                String logginUser = AuthenticationUtil.getFullyAuthenticatedUser();
                NodeRef personNodereff = serviceRegistry.getPersonService().getPerson(logginUser);
 	            NodeRef originalnoderef = null;
                if (!nodeService.hasAspect(nodeRef, ContentModel.ASPECT_CHECKED_OUT))
                {
                    boolean canUserCancelCheckout = false;
                    String workingCopyOwner = null;
                    boolean isCheckedOut = false;
                    if (serviceRegistry.getNodeService().hasAspect(nodeRef, ContentModel.ASPECT_WORKING_COPY))
                    {
                        isCheckedOut = true;
                        workingCopyOwner = serviceRegistry
                                .getNodeService()
                                    .getProperty(nodeRef, ContentModel.PROP_WORKING_COPY_OWNER)
                                    .toString();
				    	originalnoderef =(NodeRef)serviceRegistry.getCheckOutCheckInService().getCheckedOut(nodeRef);
                    }
                    if ((workingCopyOwner != null && workingCopyOwner.equals(logginUser))
                            || serviceRegistry
                                    .getPermissionService()
                                        .hasPermission(nodeRef, "AdminRole")
                                        .toString()
                                        .equals("ALLOWED"))
                    {
                        canUserCancelCheckout = true;
                    }
                    document.setCheckOutStatus(isCheckedOut);
                    document.setCanCancelCheckOut(canUserCancelCheckout);
                    document.setWorkingCopyOwner(workingCopyOwner);
                }

                if (externalyShared)
                {
                    document.setOwner((String) versionNodeRefProps.get(ContentModel.PROP_CREATOR.getLocalName()));
                    document.setModifier((String) versionNodeRefProps.get(ContentModel.PROP_MODIFIER.getLocalName()));
                }
                else if (versionLabel.equals("1.0"))
                {
                    document.setOwner((String) versionNodeProps.get(ContentModel.PROP_CREATOR));
                    document.setModifier((String) versionNodeProps.get(ContentModel.PROP_MODIFIER));
                }

                else
                {
                    document.setOwner((String) versionNodeRefProps.get(ContentModel.PROP_CREATOR.getLocalName()));
                    document.setModifier((String) versionNodeRefProps.get(ContentModel.PROP_MODIFIER.getLocalName()));

                }
                LOGGER.info("version creator........ : : " + document.getOwner());
                LOGGER.info("version modifier........ : : " + document.getModifier());
                String comment = (String) versionNodeProps.get(QName.createQName(
                    "http://www.cisco.com/model/content/1.0", "comment"));
                if (comment == null || comment.equalsIgnoreCase("undefined") || comment.equalsIgnoreCase(""))
                {
                    comment = " ";
                }
                document.setComments(comment);
                LOGGER.info("comment.........." + comment);
                
                
        	    // PRBADAM START: US9855 for editor restriction 
                List<ChildAssociationRef> parentFolderRefs = nodeService.getParentAssocs(nodeRef,ContentModel.ASSOC_CONTAINS, RegexQNamePattern.MATCH_ALL);
                if (parentFolderRefs != null && parentFolderRefs.size() > 0)
                {
                    if (parentFolderRefs.size() > 0)
                    {
                   	 final NodeRef parentFolderId = parentFolderRefs.get(0).getParentRef();
                   	 LOGGER.info("parentFolderId----------" + parentFolderId);
                 	  Boolean isEditorDeleteFiles = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
    					@Override
    					public Boolean doWork() throws Exception {
    						boolean isEditorDeleteFile = false;
    						if(serviceRegistry.getNodeService().hasAspect(parentFolderId,QName.createQName("http://www.alfresco.org/model/external/content/1.0","editorDeleteFileAspect"))){
    	                    	 isEditorDeleteFile = (boolean) serviceRegistry.getNodeService().getProperty(parentFolderId, QName.createQName("http://www.alfresco.org/model/external/content/1.0", "editorDeleteFiles"));
    						}
							return isEditorDeleteFile;
    					}
    		   	 }, "admin");
                   	  
                    	LOGGER.info("isEditorDeleteFiles----------" + isEditorDeleteFiles);
                    	if(isEditorDeleteFiles){
                    		LOGGER.info("doc node ----------"+nodeRef +"logginUser-------"+logginUser);
                    		Map<String,String> permList = getNodePermissionList(nodeRef);

                    			if (permList.get(logginUser).equals("AdminRole")) 
		  			                {          			            	
		  			            	document.setDisableDeleteDocuments(false); // enable delete button
		  			                } 
		                    		 else {
                  			        document.setDisableDeleteDocuments(true); // disable delete button
          			                }
               		} // end of isEditorDeleteFiles if 
                    	 else {
           			        LOGGER.info("in else option false ------");
           			        document.setDisableDeleteDocuments(false); // enable delete button
   			                }
                    }
                    } // end of parent folder null check
        	    // END: US9855 for editor restriction 
                

                // prbadam start: US8894-Allow to enter title while uploading a new version
                String versionTitle = (String) versionNodeProps.get(ContentModel.PROP_TITLE);
                    if (versionTitle == null || versionTitle.equalsIgnoreCase("undefined") || versionTitle.equalsIgnoreCase(""))
                    {
                    	versionTitle = " ";
                    }
                    document.setTitle(versionTitle);
                    LOGGER.info("versionTitle.........." +versionTitle);
              // prbadam end: US8894-Allow to enter title while uploading a new version
                
                document.setWorkflowStatus((String) versionNodeProps.get(QName.createQName(
                    "http://www.cisco.com/model/content/1.0", "workflowStatus")));
                document.setDocStatus((String) versionNodeProps.get(QName.createQName(
                    "http://www.cisco.com/model/content/1.0", "status")));
                boolean isfavorite = false;
                final List<NodeRef> customFablist = new ArrayList<NodeRef>();
                List<ChildAssociationRef> childAssocList = nodeService.getChildAssocs(personNodereff,
                    ASSOC_NAME_MYFAVORITE_ASSOCIATE, RegexQNamePattern.MATCH_ALL);
                if (childAssocList.size() > 0)
                {
                    for (ChildAssociationRef child : childAssocList)
                    {
                        NodeRef childNodeRef = child.getChildRef();
                        customFablist.add(childNodeRef);
				     }
                }
                
              //Tags -  Uthra
                String tagName = "";
                if(nodeService.hasAspect(nodeRef,ExternalSharingConstants.CISCO_TAG_ASPECT)){
                	tagName = (String) nodeService.getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
           			LOGGER.info("tagName :: " +tagName);
           		}
                
   	        	 if(originalnoderef != null ){
   	        		if(nodeService.hasAspect(originalnoderef,ExternalSharingConstants.CISCO_TAG_ASPECT)){
   	                	tagName = (String) nodeService.getProperty(originalnoderef, ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
   	           			LOGGER.info("tagName for original nodeRef:: " +tagName);
   	           		}
                 }
   	        	 document.setTags(tagName);
              // Tags - Uthra
               	
                
           if(originalnoderef != null){
	        	 isfavorite = customFablist.contains(originalnoderef);
	        		}else{
	        			isfavorite = customFablist.contains(nodeRef);}	
                document.setFavoriteStatus(isfavorite);
                
                // START : DE1900 - prbadam added for checking if node having different domains.
                if(CheckDomain.getDomainStatus(nodeRef.toString()).get("status1") == "401"){
                	LOGGER.info("in if inside 401-------");
                	document.setDomainMismatch(false);
                } else {
                	document.setDomainMismatch(true);
                }
        	     // END : DE1900 - prbadam added for checking if node having different domains.
                
                documentList.add(document);

            }

        }
        else
        {
            // Live Node Props
            documentList = populateLiveNodeRefProperties(nodeRef,hostname);
        }

        return documentList;

    }

    private List<ExtDocument> populateLiveNodeRefProperties(final NodeRef nodeRef,String hostname)
    {
        LOGGER.info("inside populate live node props.............");
        List<ExtDocument> documentList = new ArrayList<ExtDocument>();
        Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);
        DateFormat df;
        df = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
        ExtDocument document = new ExtDocument();

        // Common Props of a Node
        populateCommonProperties(nodeProp, document, nodeRef);

        // Live Node Specific Props
        document.setNodeId(nodeRef.toString());
        String strVersion = (String) nodeProp.get(ContentModel.PROP_VERSION_LABEL);
        double version = Double.parseDouble((strVersion != null ? strVersion : "1.0"));
        document.setVersion(version);

        document.setName(fileName);
        document.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
        document.setModifier((String) nodeProp.get(ContentModel.PROP_MODIFIER));
        document.setCreationdate(df.format((Date) nodeProp.get(ContentModel.PROP_CREATED)));
        document.setModifieddate(df.format((Date) nodeProp.get(ContentModel.PROP_MODIFIED)));
        document.setType(fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length()));
        
        
        /*ContentData contentData = (ContentData) nodeProp.get(ContentModel.PROP_CONTENT);
        document.setMimetype(contentData.getMimetype());
        document.setSize((int) contentData.getSize());
        */
        
        
        
      //Added/modified For GCS- Start
        String tempMimeType = "";
        boolean issyncedprop = false;
        String nodeUploadedGeolocation = null;
        if(serviceRegistry.getNodeService().hasAspect(nodeRef,ExternalSharingConstants.CISCO_GLOBAL_CACHING_ASPECT)){
        	nodeUploadedGeolocation = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_UPLOAD_GELOLOCATION_PROP);
 			 if(nodeUploadedGeolocation != null){
        	issyncedprop = (Boolean) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_IS_FILE_SYNCHED_PROP);
         if(!issyncedprop){
         long size = (Long) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_GCS_TEMP_SIZE);
         	tempMimeType = (String) serviceRegistry.getNodeService().getProperty(nodeRef,ExternalSharingConstants.CISCO_QNAME_GCS_TEMP_MIMETYPE);
         	document.setSize((int) (size));
         	LOGGER.info("size not synced :: " +size + "  tempMimeType :: "+tempMimeType);
         }
         else{
        	 long size = ((ContentData) serviceRegistry.getNodeService().getProperty(nodeRef,
                     ContentModel.PROP_CONTENT)).getSize();
        	 document.setSize((int) (size));
         }
 			 }else{
 				issyncedprop =  true;
 				long size = ((ContentData) serviceRegistry.getNodeService().getProperty(nodeRef,
 	                     ContentModel.PROP_CONTENT)).getSize();
 	        	 document.setSize((int) (size)); 
 			 }
        }
        
    	else{
    		LOGGER.info("issynced :: " +issyncedprop);
    		issyncedprop =  true;
    		long size = ((ContentData) serviceRegistry.getNodeService().getProperty(nodeRef,
            ContentModel.PROP_CONTENT)).getSize();
    		document.setSize((int) (size));
        LOGGER.info("size :: " +size);
        }
        document.setSynced(issyncedprop);
        if(tempMimeType.isEmpty() || tempMimeType == null){
        	document.setMimetype(((ContentData) nodeService.getProperty(nodeRef, ContentModel.PROP_CONTENT)).getMimetype());
        }else{
        	document.setMimetype(tempMimeType);
        }
        //Added/modified for Gcs-End
        
        
        

        LOGGER.info("File Type:" + fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length()));
        String comment = (String) nodeProp.get(QName.createQName("http://www.cisco.com/model/content/1.0", "comment"));
        if (comment == null || comment.equalsIgnoreCase("undefined") || comment.equalsIgnoreCase(""))
        {
            comment = " ";
        }

        document.setComments(comment);
        LOGGER.info("comment.............." + comment);
        
        // prbadam start: US8894-Allow to enter title while uploading a new version
        String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
            if (title == null || title.equalsIgnoreCase("undefined") || title.equalsIgnoreCase(""))
            {
            	title = "";
            }
            document.setTitle(title);
            LOGGER.info("title.........." +title);
        // prbadam end: US8894-Allow to enter title while uploading a new version
            
            // prbadam start: added for retrieving domain prop
            String currentLoginUserName = serviceRegistry.getAuthenticationService().getCurrentUserName();
            NodeRef currentLoginUserNodeRef = serviceRegistry.getPersonService().getPerson(currentLoginUserName);
    		Map<QName, Serializable> userProperties = serviceRegistry.getNodeService().getProperties(currentLoginUserNodeRef);
    		String emailValue = (String) userProperties.get(ContentModel.PROP_EMAIL);
    		LOGGER.info("emailValue--------"+emailValue);
    		if(emailValue.endsWith("cisco.com")){
    			document.setEmailExists(true);
    		}
    		  
    		String domain = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<String>() {
				  @Override
				  public String doWork() throws Exception {
    		 NodeRef ParentNodeRef = serviceRegistry.getNodeService().getPrimaryParent(nodeRef).getParentRef();
    		String domainVal = (String)serviceRegistry.getNodeService().getProperty(ParentNodeRef, QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"));
			return domainVal;    			
			
				  }
    		},"admin");
    		 document.setDomain(domain);
    		 LOGGER.info("domain--------"+domain);
             // prbadam end: added for retrieving domain prop
    		 
        String edcsId = (String) nodeProp.get(ExternalSharingConstants.PROP_EDCS_ID);
        document.setEdcsId(edcsId);
        document.setWorkflowStatus((String) nodeProp.get(QName.createQName("http://www.cisco.com/model/content/1.0",
            "workflowStatus")));
        document.setDocStatus((String) nodeProp.get(QName.createQName("http://www.cisco.com/model/content/1.0",
            "status")));

        String en_filename = ISO9075.encode(fileName);
        /**
         * Vera protected docs file names allways ends with .html extension to the original filename.
         * If the document is protected with vera, then append .html extension to the file name
         */
        String downloadUrl = null;
        String applyVeraProtection = ExternalSharingFileFolderUtil.getFolderVeraProtectionStatus(nodeRef, serviceRegistry);
        if(applyVeraProtection != null && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))){
        	document.setApplyVeraProtection(applyVeraProtection);
        	//downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + en_filename + ".html?a=true";
        } else {
        	document.setApplyVeraProtection("");
        	//downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + en_filename + "?a=true";
        }
        
        //UTHRA START _GCS
        
       if(serviceRegistry.getNodeService().hasAspect(nodeRef,ExternalSharingConstants.CISCO_GLOBAL_CACHING_ASPECT)){
        	nodeUploadedGeolocation = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_UPLOAD_GELOLOCATION_PROP);
  			 LOGGER.info("nodeUploadedGeolocation :: " +nodeUploadedGeolocation);
  		}
       if(nodeUploadedGeolocation != null && hostname != null){
        	boolean issynced = (Boolean) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_IS_FILE_SYNCHED_PROP);
        	if(!issynced){
        		
        		String redirectUrl = "https://"+nodeUploadedGeolocation;
                LOGGER.info("redirectUrl  :: " +redirectUrl); // redirect to the server where it was uploaded
                if(applyVeraProtection != null && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))){
                	downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + en_filename + ".html?a=true";
                }else{
                downloadUrl = redirectUrl + contextName + "/ext/download/"+ nodeRef.toString().replace(":/", "") + "/" + en_filename + "?a=true";
                }LOGGER.info("downloadurl in redirction  :: " +downloadUrl);
                 
        	}
        	else{
        		// its synced so sync central repository
        		 if(applyVeraProtection != null && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))){
        			 downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + en_filename + ".html?a=true";
        		 }else{
        		 downloadUrl = "https://"+hostname + contextName + "/ext/download/"+ nodeRef.toString().replace(":/", "") + "/" + en_filename + "?a=true"; // need to check
        		 }
            	 LOGGER.info("downloadurl sync value true so download from central repo :: " +downloadUrl);
                 
        	}
         }
        	else {
        		 if(applyVeraProtection != null && ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))){
        			 downloadUrl = alfrescoURL + contextName + "/ext/download/" + nodeRef.toString().replace(":/", "") + "/" + en_filename + ".html?a=true";
        		 }else{
            	 downloadUrl = alfrescoURL + contextName + "/ext/download/"+ nodeRef.toString().replace(":/", "") + "/" + en_filename + "?a=true";
        		 }
            	   }
      
        
        //Uthra GCS  - END
        
        
        
        
        document.setDownloadUrl(downloadUrl);
        
        boolean externalyShared = false;
        if(edcsId!= null && edcsId.contains("EDCS-")){
        	externalyShared = true; 
        }
        document.setExternalyShared(externalyShared);

        /*QName extShareableAspect = QName
                .createQName("{http://www.alfresco.org/model/external/content/1.0}extShareableAspect");
        boolean externalyShared = false;

        if (nodeService.hasAspect(nodeRef, extShareableAspect))
        {

            LOGGER.info("...............externally Shared aspect present........");
            LOGGER.info("...............externally Shared ***************" + externalyShared);

            externalyShared = (Boolean) nodeProp.get(QName.createQName(
                "http://www.alfresco.org/model/external/content/1.0", "isExternalyShared"));
        }
        LOGGER.info("externaly Shared value**************" + externalyShared);

        document.setExternalyShared(externalyShared);*/
        String logginUser = AuthenticationUtil.getFullyAuthenticatedUser();
        NodeRef personNodereff = serviceRegistry.getPersonService().getPerson(logginUser);
        	NodeRef originalnoderef = null;
        if (!nodeService.hasAspect(nodeRef, ContentModel.ASPECT_CHECKED_OUT))
        {
            boolean canUserCancelCheckout = false;
            String workingCopyOwner = null;
            boolean isCheckedOut = false;
            if (serviceRegistry.getNodeService().hasAspect(nodeRef, ContentModel.ASPECT_WORKING_COPY))
            {
                isCheckedOut = true;
                workingCopyOwner = serviceRegistry
                        .getNodeService()
                            .getProperty(nodeRef, ContentModel.PROP_WORKING_COPY_OWNER)
                            .toString();
				originalnoderef =(NodeRef)serviceRegistry.getCheckOutCheckInService().getCheckedOut(nodeRef);
            }
            if ((workingCopyOwner != null && workingCopyOwner.equals(logginUser))
                    || serviceRegistry
                            .getPermissionService()
                                .hasPermission(nodeRef, "AdminRole")
                                .toString()
                                .equals("ALLOWED"))
            {
                canUserCancelCheckout = true;
            }
            document.setCheckOutStatus(isCheckedOut);
            document.setCanCancelCheckOut(canUserCancelCheckout);
            document.setWorkingCopyOwner(workingCopyOwner);
        }
        boolean isfavorite = false;
        final List<NodeRef> customFablist = new ArrayList<NodeRef>();
        List<ChildAssociationRef> childAssocList = nodeService.getChildAssocs(personNodereff,
            ASSOC_NAME_MYFAVORITE_ASSOCIATE, RegexQNamePattern.MATCH_ALL);
        if (childAssocList.size() > 0)
        {
            for (ChildAssociationRef child : childAssocList)
            {
                NodeRef childNodeRef = child.getChildRef();
                customFablist.add(childNodeRef);
            }
		}
         if(originalnoderef != null){
        	 isfavorite = customFablist.contains(originalnoderef);
        		}else{
        			isfavorite = customFablist.contains(nodeRef);}
        document.setFavoriteStatus(isfavorite);
        
      //Tags -  Uthra
        String tagName = "";
        if(nodeService.hasAspect(nodeRef,ExternalSharingConstants.CISCO_TAG_ASPECT)){
        	tagName = (String) nodeService.getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
   			LOGGER.info("tagName :: " +tagName);
   		}
        
       	 if(originalnoderef != null ){
       		if(nodeService.hasAspect(originalnoderef,ExternalSharingConstants.CISCO_TAG_ASPECT)){
               	tagName = (String) nodeService.getProperty(originalnoderef, ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
          			LOGGER.info("tagName for original nodeRef:: " +tagName);
          		}
         }
       	 document.setTags(tagName);
      // Tags - Uthra
        
        // START : DE1900 - prbadam added for checking if node having different domains.
        if(CheckDomain.getDomainStatus(nodeRef.toString()).get("status1") == "401"){
        	LOGGER.info("in if inside 401-------");
        	document.setDomainMismatch(false);
        } else {
        	document.setDomainMismatch(true);
        }
	     // END : DE1900 - prbadam added for checking if node having different domains.
        
        boolean isExpirationDateChanged = serviceRegistry.getNodeService().getProperty(nodeRef, MigrationConstants.IS_EXP_DATE_CHANGED_PROP) == null ? false :  (boolean) serviceRegistry.getNodeService().getProperty(nodeRef, QName.createQName("{http://www.alfresco.org/model/external/content/1.0}isExpirationDateChanged"));
        LOGGER.info("isExpirationDateChanged------ :: " +isExpirationDateChanged);
        document.setExpirationDateChanged(isExpirationDateChanged);
        documentList.add(document);
        return documentList;

    }

    private void populateCommonProperties(Map<QName, Serializable> nodeProp, ExtDocument document, NodeRef nodeRef)
    {
        String currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
        LOGGER.info("currentUser.........." + currentUser);
        document
                .setEdcsId((String) nodeProp.get(QName.createQName("http://www.cisco.com/model/content/1.0", "alf_id")));
        document.setSecurity((String) nodeProp.get(QName.createQName("http://www.cisco.com/model/content/1.0",
            "security")));
        document.setDescription((String) nodeProp.get(ContentModel.PROP_DESCRIPTION));
        LOGGER.info("nodeRef.........." + nodeRef);
        String folderId = FavUploadFile.getNavigateToFolderNode(currentUser,nodeRef);
        document.setFolderId(folderId);
        LOGGER.info("folderId........." + folderId);
        document.setPermissionLevel(ExternalSharingFileFolderUtil.getUserRole(serviceRegistry, currentUser, nodeRef));
        document
                .setCanUserCancelWorkflow(ExternalSharingFileFolderUtil.canUserCancelWorkflow(serviceRegistry, nodeRef));
        String lockType = (String) nodeProp.get(ContentModel.PROP_LOCK_TYPE);
        document.setLocked(lockType != null ? true : false);
        document.setExpirationDate(ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp
                .get(ExternalSharingConstants.PROP_EXPIRAIONDATE))));

    }

    public static boolean hasAccess(final String currentUser, NodeRef nodeRef, final ServiceRegistry serviceRegistry)
    {
    	boolean currentUserHasGroupMember = false;
        // if Admin user allow
        if (currentUser.equals(ExternalSharingConstants.USER_ADMIN))
        {
            return true;
        }

        Set<AccessPermission> userSet = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
        LOGGER.info("UserSet:" + userSet.toString());
        String userSetString = userSet.toString();
        // if current user has any authority allow
        if (userSetString.indexOf(currentUser) != -1)
            return true;
        Set<String> authStrings = serviceRegistry.getAuthorityService().getAuthoritiesForUser(currentUser);
        String groupSetString = authStrings.toString();
        // if current user is having GROUP_EDCSNG_INFOSEC allow
        if (groupSetString.indexOf("GROUP_EDCSNG_INFOSEC") != -1)
            return true;
        // if user group has been assigned permission then also allow
        if (userSet.size() > 0)
        {
        	 for (AccessPermission accessPermission : userSet)
             {
             	final String userIdOrMemberOfGroupId = accessPermission.getAuthority();
                 LOGGER.info("user : " + userIdOrMemberOfGroupId);
                 //check user is member of group that group has permissions on folder
                 if(userIdOrMemberOfGroupId.contains(GROUP_IDENTITY)){
                 	if (accessPermission.getPermission() != null
     						&& accessPermission.getPermission().equals("SiteAdmin")
     						|| accessPermission.getPermission().equals("SiteEditor")
     						|| accessPermission.getPermission().equals("SiteReader")
     						|| accessPermission.getPermission().equals("SiteOwner")
     						|| accessPermission.getPermission().equals("SiteManager")
     						|| accessPermission.getPermission().equals("ReadPermissions")
     						|| accessPermission.getPermission().equals("SiteViewer")) {
                 		 LOGGER.info("inside if authority permissions------" +accessPermission.getPermission());
     				} else{
                 	LOGGER.info("groupId : " + userIdOrMemberOfGroupId);
                 	currentUserHasGroupMember = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
        				  @Override
        				  public Boolean doWork() throws Exception {
        					  boolean currentUserIsGroupMember=false;
         					  if(userIdOrMemberOfGroupId!= null && !userIdOrMemberOfGroupId.equalsIgnoreCase(GROUP_EVERYONE)){
         						  currentUserIsGroupMember=serviceRegistry.getAuthorityService().getAuthoritiesForUser(currentUser).contains(userIdOrMemberOfGroupId);
         					  }
         					 return currentUserIsGroupMember;
        				  }
        				  }, "admin");
                 LOGGER.info("currentUserHasGroupMember of accessPermission.getAuthorityType : " + currentUserHasGroupMember);
                 }
                 }
                 if (userIdOrMemberOfGroupId.equals(currentUser) || currentUserHasGroupMember)
                 {
                     return true;
                 }
        }
        }
        return false;
    }
    
    public Map<String,String> getNodePermissionList(NodeRef nodeRef)
    {
    	 Map<String,String> permList = new HashMap<String,String>();
   		 Set<AccessPermission> fileAccessPermissions = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
		      Iterator<AccessPermission> fIterator = fileAccessPermissions.iterator();
		        while (fIterator.hasNext())
		        {
		            AccessPermission accessPermission = (AccessPermission) fIterator.next();
		            LOGGER.info("accessPermission------"+accessPermission);
		            if (accessPermission.getAuthorityType() == AuthorityType.USER)
		            {
		                if (LOGGER.isDebugEnabled())
		                {
		                    LOGGER.debug("Authority(User): " + accessPermission.getAuthority() + " Permission:  "
		                            + accessPermission.getPermission());
		                }
		                String autherityUserName = accessPermission.getAuthority();
		                String autherityUserPermission = accessPermission.getPermission();
		                permList.put(autherityUserName, autherityUserPermission);
		            }// End of if
		            }// End of while
		            LOGGER.info("permList------"+permList);
		            return permList;
    }
    
    public boolean isSupportGroupUser(String currentUserName) {
		boolean isUserExistinGroup = false;
		try {
			AuthenticationUtil.setFullyAuthenticatedUser(currentUserName);
			Set<String> userAuthorities = serviceRegistry.getAuthorityService().getAuthorities();
			String supportGroupName = globalProperties.getProperty("docex.supportgroup.name");
			if(supportGroupName != null && userAuthorities.contains(supportGroupName)) {
				isUserExistinGroup = true;
			}
		}catch(Exception ex)
		{
			LOGGER.error("Exception while checking the support group user", ex);
		}
		return isUserExistinGroup;
	}

    public NodeService getNodeService()
    {
        return nodeService;
    }

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    public NamespaceService getNamespaceService()
    {
        return namespaceService;
    }

    public void setNamespaceService(NamespaceService namespaceService)
    {
        this.namespaceService = namespaceService;
    }

    public VersionService getVersionService()
    {
        return versionService;
    }

    public void setVersionService(VersionService versionService)
    {
        this.versionService = versionService;
    }

    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

	public void setGlobalProperties(Properties globalProperties) {
		this.globalProperties = globalProperties;
	}
    
    

}
