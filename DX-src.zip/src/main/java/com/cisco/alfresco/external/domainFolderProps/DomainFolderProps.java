package com.cisco.alfresco.external.domainFolderProps;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.alfresco.external.editFolderProperties.ProcessUserDomains;
import com.cisco.docex.exceptions.ErrorObject;
import com.cisco.docex.exceptions.ValidationException;

/**
 * 
 * @author prbadam - US9587:Move Domain field from Folder Properties to Folder Permissions.(Add Domain)
 * 
 */
public class DomainFolderProps extends DeclarativeWebScript
{
    private static final Logger LOGGER = Logger.getLogger(DomainFolderProps.class);
    private ServiceRegistry serviceRegistry = null;
    private PermissionService permissionService =null;
    private AuditComponent auditComponent;
    private ExternalLDAPUtil ldapUtil;
    private static final Pattern pattern = Pattern.compile("[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
    public PermissionService getPermissionService() {
		return permissionService;
	}

	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}

    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }
 
	
	public AuditComponent getAuditComponent() {
		return auditComponent;
	}

	public void setAuditComponent(AuditComponent auditComponent) {
		this.auditComponent = auditComponent;
	}

	public ExternalLDAPUtil getLdapUtil()
    {
        return ldapUtil;
    }
    public void setLdapUtil(ExternalLDAPUtil ldapUtil)
    {
        this.ldapUtil = ldapUtil;
    }
        

	  @Override
	    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
	    {
		  	Map<String, Object> model = new HashMap<String, Object>();
		  	String inputJSONValue = readRequestBody(req);
			JSONObject jsonObject = null;
			String nodeId = null, folderDomain = null;
			
			try {
				jsonObject = new JSONObject(inputJSONValue);
				nodeId = jsonObject.getString("nodeId");
				folderDomain = jsonObject.getString("domain");
				folderDomain= folderDomain.replaceAll("\\s", "");
				LOGGER.info("nodeId---------"+nodeId +"---folderDomain----"+folderDomain);
				
				NodeRef folderNodeRef = new NodeRef(nodeId);
				String oldDomain = (String)serviceRegistry.getNodeService().getProperty(folderNodeRef,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"));
				oldDomain = oldDomain != null ? oldDomain : "";
				LOGGER.info("oldDoamin  :: " +oldDomain);
				String folderName = (String) serviceRegistry.getNodeService().getProperty(folderNodeRef, ContentModel.PROP_NAME);
				QName type = serviceRegistry.getNodeService().getType(folderNodeRef);
				if (type.equals(ContentModel.TYPE_FOLDER))
	                {
						  Map<String,String> permList = new HashMap<String,String>();
	            		  String currentLoginUserName = serviceRegistry.getAuthenticationService().getCurrentUserName();
	    				  LOGGER.info("currentLoginUserName---------"+currentLoginUserName);
	            		
	            		 Set<AccessPermission> folderAccessPermissions = permissionService.getAllSetPermissions(folderNodeRef);
	            		 LOGGER.info("folderAccessPermissions -------------"+folderAccessPermissions);
	   			      
	            		 Iterator<AccessPermission> fIterator = folderAccessPermissions.iterator();
	   			        while (fIterator.hasNext())
	   			        {
	   			            AccessPermission accessPermission = (AccessPermission) fIterator.next();
	   			            LOGGER.info("accessPermission------"+accessPermission);
	   			            if (accessPermission.getAuthorityType() == AuthorityType.USER)
	   			            {
	   			                if (LOGGER.isDebugEnabled())
	   			                {
	   			                    LOGGER.debug("Authority(User): " + accessPermission.getAuthority() + " Permission:  "
	   			                            + accessPermission.getPermission());
	   			                }
	   			                String autherityUserName = accessPermission.getAuthority();
	   			                LOGGER.info("autherityUserName------"+autherityUserName);
	   			                String autherityUserPermission = accessPermission.getPermission();
	   			                LOGGER.info("autherityUserPermission------"+autherityUserPermission);
	   			                
	   			                if(autherityUserPermission.equals("AdminRole")){
	   			                permList.put(autherityUserName, autherityUserPermission);
	   			                }
	   			            }// End of if
	   			            }// End of while
	   			            LOGGER.info("permList------"+permList);
	   			               // Start : only Folder admin can perform following operations
	   			            if (permList.containsKey(currentLoginUserName) &&  permList.containsValue("AdminRole")) //AdminRole = Area Admin/Folder Admin
	   			                {
	   			            	LOGGER.info("vaid user------"+currentLoginUserName);
	   			            	
	   			           //START: removing duplicates from folderDomain
	   			     		String[] doaminSplit = folderDomain.split(",");
	   			     		List<String> doaminList = new ArrayList<String>();
	   			     		Collections.addAll(doaminList, doaminSplit);
		   			     	//TA17657 changes starts here
		   			     	for(int j=0; j<doaminList.size();j++){
		   			     		if(!doaminList.get(j).isEmpty() && doaminList.get(j)!=null) {
						   	           if (!pattern.matcher(doaminList.get(j)).matches()) {
			   				        	   LOGGER.info("provide valid input for domain :: "+doaminList.get(j));
				   				               	ErrorObject eob = new ErrorObject();
				   								eob.setField("domain");
				   								eob.setError("Submitted domain is not in correct format("+doaminList.get(j)+"),The domains have not been saved. Please try again");
				   								throw new ValidationException(eob);
				   				           }
		   			     		}
		   			     		}
				     	       //TA17657 ends here
	   			     		HashSet<String> emailHashList = new HashSet<String>(doaminList);
	   			     		String listFolderString = emailHashList.toString().replace("[", "").replace("]", "").replace(", ", ",");
	   			     		  
	   			     	       if (listFolderString.startsWith(",")) {
	   			     	    	   listFolderString = listFolderString.replaceFirst(",", "");
	   			     	        	}
	   			     	       if (listFolderString.endsWith(",")) {
	   			     	    	   listFolderString = listFolderString.substring(0, listFolderString.length() - 1);
	   			     	        	}
	   			     	       LOGGER.info("listFolderString-------"+listFolderString);
	   			     	     //END: removing duplicates from folderDomain
	   			            	
	   			        // adding domainAspect to the node
	            	    Map<QName, Serializable> domainProp = new HashMap<QName, Serializable>(1);
	            	    domainProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"),listFolderString);
	            	    serviceRegistry.getNodeService().addAspect(folderNodeRef,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domainAspect"), domainProp);
	            	    
	            	    setCascadedDomainFolderProp(folderNodeRef, folderDomain, oldDomain);
	            	    
	            	    //added by mkatnam for domain audit
	            	    if(folderDomain != null && folderDomain.length() >0){
	            	    	 LOGGER.info(" Domain Added is calling... ");
	            	    	 folderDomain = folderDomain.replaceAll(",", ";");
	            			recordAuditInfo(folderNodeRef,folderName,null,folderDomain,currentLoginUserName,"Domain Added");
	            	    }
	            	    LOGGER.info("Successfully domain added---------");
	            	    model.put("success", "Domain added successfully");
	                }
			}
		}// End of try
			catch(ValidationException ve) {
				LOGGER.error("Domain validation Exception" , ve);
				ErrorObject eob = ((ValidationException) ve).getErrorObj();
				model.put("success", eob.getError());
				return model;
			}
			 catch (Exception e) {
					e.printStackTrace();
					LOGGER.info("in e---------"+e);
				}
			return model;
	    }
	  
		
		/**
		 * 
		 * @param req
		 * @return
		 */
		private String readRequestBody(WebScriptRequest req) {
			try {
				return IOUtils.toString(req.getContent().getInputStream(), req
						.getContent().getEncoding());
			} catch (Exception e) {
				try {
					return req.getContent().getContent();
				} catch (IOException e1) {
					LOGGER.error("Unable to read JSON request body", e1);
					throw new WebScriptException(
							"Unable to read JSON request body!! Epic fail.");
				}
			}
		}
	  
	    public void setCascadedDomainFolderProp(NodeRef folderNodeRef, String folderDomain, String oldDomain)
	    {
	    LOGGER.info("inside setCascadedDomainFolderProp---------");
	    //String oldDomain = null;
	    String folderName = (String) serviceRegistry.getNodeService().getProperty(folderNodeRef, ContentModel.PROP_NAME);
		//oldDomain = (String)serviceRegistry.getNodeService().getProperty(folderNodeRef,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"));
		
		@SuppressWarnings("deprecation")
		List<FileInfo> deepFolderNodeRefs = serviceRegistry.getFileFolderService().listDeepFolders(folderNodeRef, null);
		LOGGER.info("deepFolderNodeRefs---------"+deepFolderNodeRefs);
		try{
		// START: DE2112 - Domain changes are not getting cascaded to its sub folder. - prbadam
		if(deepFolderNodeRefs.size() > 0){
	       for (FileInfo childAssoc : deepFolderNodeRefs) {
	           
	    	 final NodeRef  childNodeRef = childAssoc.getNodeRef();
	    	 LOGGER.info("childNodeRef---------"+childNodeRef);
	            
	           String childDomain = (String)serviceRegistry.getNodeService().getProperty(childNodeRef, QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"));
	           LOGGER.info("childDomain---------"+childDomain);
	           
	           if(childDomain !=null){
	        	   LOGGER.info("in if childDomain---------");
	           List<String> deepFolderDomain = getFolderDomain(oldDomain,childDomain,folderDomain);
	           // Removing duplicates
	           HashSet<String> domainHashList = new HashSet<String>(deepFolderDomain);
	           LOGGER.info("after removing duplicates domainHashList---------"+domainHashList);
	           String listString = domainHashList.toString().replace("[", "").replace("]", "").replace(", ", ",");
	           if (listString.startsWith(",")) {
	        	   listString = listString.replaceFirst(",", "");
		        	}
	           if (listString.endsWith(",")) {
					listString = listString.substring(0, listString.length() - 1);
		        	}
	           LOGGER.info("Final domains listString-------"+listString);
			
			final String listStringFinal = listString;
			
			AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
		             {
		             @Override
		             public Object doWork() throws Exception
		             {
		            	 serviceRegistry.getNodeService().setProperty(childNodeRef, QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"), listStringFinal);
					return null;
		            }
		            }, "admin");
	       }
	           else{
	        	   LOGGER.info("in else childDomain---------");
	        		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
				             {
				             @Override
				             public Object doWork() throws Exception
				             {
				            		// adding domainAspect to the childDomainProp node if domain aspect is not there for older folders
									Map<QName, Serializable> childDomainProp = new HashMap<QName, Serializable>(1);
									childDomainProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"),"");

									serviceRegistry.getNodeService().addAspect(childNodeRef,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domainAspect"),childDomainProp);

							return null;
				            }
				            }, "admin");
	           }
	       }
		} 
		} catch(Exception e){
			e.printStackTrace();
			LOGGER.info("in exception childDomain---------"+e);
		}
		// END: DE2112 - Domain changes are not getting cascaded to its sub folder. - prbadam
		
		//added by mkatnam for domain audit
				String creator = (String) serviceRegistry.getNodeService().getProperty(folderNodeRef, ContentModel.PROP_CREATOR);
				if(folderDomain != null && folderDomain.length() > 0){
					if(!folderDomain.equalsIgnoreCase(oldDomain)){
						LOGGER.info(" Domain Modified is calling....");
						folderDomain = folderDomain.replaceAll(",", ";");
						if (oldDomain != null && !oldDomain.trim().equals(""))
							oldDomain = oldDomain.replaceAll(",", ";");
						recordAuditInfo(folderNodeRef,folderName,oldDomain,folderDomain,creator,"Domain Modified");
					}
				}else{
					if(oldDomain != null && (folderDomain == null || folderDomain.equalsIgnoreCase(""))){
						LOGGER.info(" Domain Removed is calling....");
						oldDomain = oldDomain.replaceAll(",", ";");
						recordAuditInfo(folderNodeRef,folderName,oldDomain,folderDomain,creator,"Domain Removed");
					}
				}
				//end -mkatnam
				
				      //Domain Management START - US9112 
						if(folderDomain != null && folderDomain.length() > 0){
							LOGGER.info("folderDomain :: " +folderDomain +  " oldDomain :: " +oldDomain);
							if(!folderDomain.equalsIgnoreCase(oldDomain)){
								LOGGER.info("Calling ProcessUserDomains thread...");
								ProcessUserDomains processUserDomains = new ProcessUserDomains(folderNodeRef,folderDomain,deepFolderNodeRefs,serviceRegistry,ldapUtil);
				                new Thread(processUserDomains).start();
							}
							}
						//Domain Management END - US9112 
	    }

	    
	    // START: DE2112 - Domain changes are not getting cascaded to its sub folder. - prbadam
		public List<String> getFolderDomain(String parent, String child, String newParent) {
		
		LOGGER.info("oldparent-----"+parent +", child------"+child +", newParent-----"+newParent);
		String[] parentSplit = parent.split(",");
		String[] childSplit = child.split(",");
		String[] newParentSplit = newParent.split(",");

		List<String> parentList = new ArrayList<String>();
		Collections.addAll(parentList, parentSplit);

		List<String> childList = new ArrayList<String>();
		Collections.addAll(childList, childSplit);

		List<String> newParentList = new ArrayList<String>();
		Collections.addAll(newParentList, newParentSplit);
		
		for (int i = 0; i < parentList.size(); i++) {

			boolean cList = childList.contains(parentList.get(i));
			if (cList) {
				childList.remove(parentList.get(i));
			}
		}
		childList.addAll(newParentList);
		LOGGER.info("Final values in getFolderDomain method------" + childList);
		return childList;
		}
		// END: DE2112 - Domain changes are not getting cascaded to its sub folder. - prbadam
		
		public void recordAuditInfo(NodeRef folderNodeRef, String folderName, String oldDomain, String folderDomain, String currentUserName, String event) {
			String modifier = AuthenticationUtil.getFullyAuthenticatedUser();
			Map<String, Serializable> auditEntry = new HashMap<String, Serializable>();
			auditEntry.put("foldername",folderName);
			auditEntry.put("noderef", folderNodeRef);
			auditEntry.put("creator", currentUserName );
			auditEntry.put("modifier", modifier);
			String nodePath = serviceRegistry.getNodeService().getPath(folderNodeRef).toDisplayPath(serviceRegistry.getNodeService(), permissionService);
			auditEntry.put("path",nodePath);
			auditEntry.put("folderprefixpath", serviceRegistry.getNodeService().getPath(folderNodeRef).toPrefixString(serviceRegistry.getNamespaceService()));
			auditEntry.put("olddomain", oldDomain);
			auditEntry.put("newdomain",folderDomain );
			auditEntry.put("event", event);
			auditComponent.recordAuditValues("/folder-domain/folder", auditEntry);
		}
	  
}