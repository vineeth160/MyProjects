package com.cisco.alfresco.external.editFolderProperties;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.apache.log4j.Logger;

import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;


public class ProcessUserDomains extends Thread{
	private static final Logger LOGGER = Logger.getLogger(ProcessUserDomains.class);
	private NodeRef folderNodeRef;
	private String folderDomain;
	private List<FileInfo> deepFolderNodeRefs;
	private ServiceRegistry serviceRegistry;
	private ExternalLDAPUtil ldapUtil;
	public ProcessUserDomains(final NodeRef folderNodeRef,final String folderDomain,List<FileInfo> deepFolderNodeRefs, ServiceRegistry serviceRegistry,ExternalLDAPUtil ldapUtil){
		this.folderNodeRef=folderNodeRef;
		this.folderDomain=folderDomain;
		this.deepFolderNodeRefs=deepFolderNodeRefs;
		this.serviceRegistry=serviceRegistry;
		this.ldapUtil=ldapUtil;
		
	}
	@Override
	public void run() {
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				String[] domains = null;
				List<NodeRef> nodeRefList = new ArrayList<NodeRef>();
				if(deepFolderNodeRefs.size()>0){
					 for (FileInfo childAssoc : deepFolderNodeRefs) {
				        NodeRef childFolderNodeRef = childAssoc.getNodeRef();
				        nodeRefList.add(childFolderNodeRef);
					 }
				}
				LOGGER.info("deepFolderNodeRefs---------"+deepFolderNodeRefs);
				nodeRefList.add(folderNodeRef);
				if(folderDomain!=null && !folderDomain.isEmpty())
				domains= folderDomain.split(";");
				if(nodeRefList.size()>0) {
				manageDomain(nodeRefList,folderNodeRef,domains);
				}
				return null;	
			}
		},"admin");
     }
	
	
	public void checkDomainAndRemovePermission(NodeRef fileNoderef,String[] domains){
		List<String> userList = new ArrayList<String>();
		List<String> keyList = new ArrayList<String>();
		Hashtable<String, String> userDefaultPermission = getUsersOnNodeRef(fileNoderef);
		if (!userDefaultPermission.isEmpty()) {
			 for(String domain : domains){
				 domain=domain.replaceAll(" ",""); 
				 
            for(Map.Entry entry: userDefaultPermission.entrySet()){
            		 String key = (String) entry.getKey();
            		 if(!keyList.contains(key)){
            		 keyList.add(key);
            		 }
            		 if(domain.equalsIgnoreCase(entry.getValue().toString()) || entry.getValue().toString().equalsIgnoreCase("cisco.com")){
            			if(!userList.contains(key)){
            				userList.add(key);
            				}
		                
		               }  
            		}
			 } 								
            }
		if(keyList.size()>0){
			for(String user : keyList){
				if(!userList.contains(user)){
					serviceRegistry.getPermissionService().clearPermission(fileNoderef,user);
			}
		}
	}
	}
	
	public synchronized void manageDomain(List<NodeRef> folderNodeRefList,NodeRef folderNodeRef,String[] domains)
	{
		List<NodeRef> fileNodeList  = new ArrayList<NodeRef>();
			for(NodeRef foldernodeId : folderNodeRefList){
			  checkDomainAndRemovePermission(foldernodeId,domains);
				List<FileInfo> fileNodeRefs = serviceRegistry.getFileFolderService().listFiles(foldernodeId);
				if(fileNodeRefs.size()>0){
					for(FileInfo nodeId : fileNodeRefs){
						fileNodeList.add(nodeId.getNodeRef());
					}
					}
				if(fileNodeList!= null){
					LOGGER.info("Processing file noderef values...");
					for(NodeRef fileNoderef :fileNodeList){
						checkDomainAndRemovePermission(fileNoderef,domains);
				}
			    
				}   
			}
		
		
	}
	
	public Hashtable<String, String> getUsersOnNodeRef(NodeRef nodeRef)
	{
		String[] temp;
		String delimiter = "@";
		String emailValue =  null;
		Hashtable<String, String> userPermission = new Hashtable<String, String>();
		Iterator<AccessPermission> fIterator;
		try {
		Set<AccessPermission> accessPermissions1 = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
		fIterator = accessPermissions1.iterator();
		while (fIterator.hasNext()) {
			AccessPermission accessPermission = (AccessPermission) fIterator.next();
			if (accessPermission.getAuthorityType() == AuthorityType.USER && accessPermission.isSetDirectly()) {
				String autherityUserName = accessPermission.getAuthority();
				String emailId = ldapUtil.getManagerEmailFromLDAP(autherityUserName);
				if (emailId != null && emailId.length() > 0 && !emailId.isEmpty()) {
					temp = emailId .split(delimiter);
					emailValue = temp[1];
				}
				if(autherityUserName!=null && emailValue!=null) {
				userPermission.put(autherityUserName,emailValue);
				}
			}
		}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return userPermission;
		
	}
	
	
}