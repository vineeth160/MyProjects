package com.cisco.alfresco.external.webscript;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;

public class GetOptInUsers extends DeclarativeWebScript
{
	private static final Logger LOGGER = Logger.getLogger(GetOptInUsers.class);
	private ServiceRegistry serviceRegistry;
	@Override
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
	{
		if (LOGGER.isDebugEnabled())
			LOGGER.debug("------------- GetOptInUsers executeImpl ----------");
		final Map<String, Object> model = new HashMap<String, Object>();
		try
		{
			 JSONArray personArray=new JSONArray();
			 List<String> optInUserList = new ArrayList<String>();
			 boolean personExist =false;
			 Content reqContent = req.getContent();
	            if (reqContent == null)
	            {
	                throw new WebScriptException(Status.STATUS_BAD_REQUEST, "Missing POST body.");
	            }
	            JSONObject personJosn = new JSONObject(reqContent.getContent());
	            LOGGER.info("GetOptInUsers personJosn :: "+personJosn.toString());
	            personArray=personJosn.getJSONArray("users");
	            for(int i=0;i<personArray.length();i++){
	            	 LOGGER.info("GetOptInUsers person :: "+personArray.getString(i));
	                personExist = serviceRegistry.getPersonService().personExists(personArray.getString(i));
	                LOGGER.info("GetOptInUsers personExist :: "+personExist);
	  			  if(personExist){
	  				  NodeRef personId = serviceRegistry.getPersonService().getPerson(personArray.getString(i));
	  				LOGGER.info("GetOptInUsers personId :: "+personId);
	  				boolean optOutEmailNotification=optOutEmailNotify(personId);
	  				if(optOutEmailNotification){
	  					LOGGER.info("GetOptInUsers ActivityMailsJob User is Opt out Email Notifications:::::::::::::"+personArray.getString(i));
	  				}else{
	  					optInUserList.add(personArray.getString(i));
	  				}
	  			  }else{
	  				LOGGER.info("GetOptInUsers ActivityMailsJob User is not exists in repo :::::::::::::"+personArray.getString(i));
	  			  }
	    		}
			
			if (LOGGER.isDebugEnabled())
			{
				LOGGER.debug("Result JSON Size: " + optInUserList.size());
				LOGGER.debug("Result JSON : " + optInUserList.toString());
			}
			model.put("optInUserList", optInUserList);
		}
		catch (InvalidNodeRefException ine)
		{
			LOGGER.error("InvalidNodeRefException : " + ine);
		}
		catch (Exception e)
		{
			LOGGER.error("Exception : " + e);
			e.printStackTrace();
		}

		return model;
	}
	
	//US10205-start of Opt in/out Email Notification
		private boolean optOutEmailNotify(NodeRef personNode){
			 boolean optOutEmailNotify=false;
			 boolean hasEmailNotificationAspect =false;
			 hasEmailNotificationAspect = serviceRegistry.getNodeService().hasAspect(personNode, ExternalSharingConstants.ASPECT_OPTINOUT_EMAIL_NOTIFICATION);
			 LOGGER.info("GetOptInUsers hasEmailNotificationAspect :: "+hasEmailNotificationAspect);    
			 if(hasEmailNotificationAspect){
		        	  optOutEmailNotify = (Boolean) serviceRegistry.getNodeService().getProperty(personNode, ExternalSharingConstants.PROP_OPTOUT_EMAIL_NOTIFY);
		          }
		     LOGGER.info("GetOptInUsers optOutEmailNotify :: "+optOutEmailNotify);
			return optOutEmailNotify;
		}
	//US10205-end of Opt in/out Email Notification
	
	/**
	 * @param serviceRegistry
	 *            the serviceRegistry to set
	 */
	public void setServiceRegistry(ServiceRegistry serviceRegistry)
	{
		this.serviceRegistry = serviceRegistry;
	}
}
