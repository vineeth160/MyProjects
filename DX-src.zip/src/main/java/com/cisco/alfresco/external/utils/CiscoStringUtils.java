package com.cisco.alfresco.external.utils;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.json.JSONObject;

public final class CiscoStringUtils {
	private CiscoStringUtils() {
		// Private Constructor
	}

	private static final Log LOGGER = LogFactory.getLog(CiscoStringUtils.class);
	private static final String BOOL_TRUE = "true";


	/**
	 * @param folderName
	 * @param userId
	 * @return
	 */
	public static String getLinkNameofShareFolder(String folderName, String userId) {
		StringBuffer linkFolderName = new StringBuffer();
		linkFolderName.append("SHARED_WIDGET");
		linkFolderName.append('_');
		linkFolderName.append(new Date().getTime());
		linkFolderName.append('_');
		// linkFolderName.append("_SharedBY_");
		linkFolderName.append(userId);
		// linkFolderName.append(AcrowitConstant.LINK_EXTENSION);
		return linkFolderName.toString();
	}

	public static boolean isPasswordOfValidLength(String password) {
		if (password.length() >= 6 && password.length() <= 100) {
			return true;
		}

		return false;
	}

	/**
	 * @param val1
	 * @param val2
	 * @return
	 */
	public static String concatString(String val1, String val2) {
		StringBuffer result = new StringBuffer();
		if (isNullOrEmpty(val1)) {
			result.append(val2);
		} else {
			result.append(val1);
			result.append(',');
			result.append(val2);
		}
		return result.toString();
	}

	/**
	 * @param val
	 * @return
	 */
	public static boolean isNullOrEmpty(String val) {
		boolean flag = false;
		if (val == null || "".equals(val)) {
			flag = true;
		}
		return flag;
	}

	/**
	 * @param string
	 * @param separator
	 * @return List of String
	 */
	public static List<String> convertStringToList(String string, String separator) {
		List<String> stringList = new ArrayList<String>();
		if (string == null || "".equals(string) || separator == null || "".equals(separator)) {
			return stringList;
		} else {
			// stringList = new ArrayList<String>();
			String arr[] = string.split(separator);
			for (int i = 0; i < arr.length; i++) {
				if (arr[i].trim().length() > 0) {
					stringList.add(arr[i].trim());
				}
			}
		}
		return stringList;
	}

	/**
	 * @param string
	 * @param separator
	 * @return Set of String
	 */
	public static Set<String> convertStringToSet(String string, String separator) {
		Set<String> stringSet = new HashSet<String>();
		if (string == null || "".equals(string) || separator == null || "".equals(separator)) {
			return stringSet;
		} else {
			String arr[] = string.split(separator);
			for (int i = 0; i < arr.length; i++) {
				stringSet.add(arr[i]);
			}
		}
		return stringSet;
	}

	/**
	 * @param e
	 * @return String of StackTrace
	 */
	public static String stackTraceToString(final Exception e) {
		final ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
		final PrintStream printStream = new PrintStream(byteStream);
		e.printStackTrace(printStream);
		printStream.flush();
		return byteStream.toString();
	}

	/**
	 * converts string separated by any token into list
	 * 
	 * @param stringVal
	 * @param token
	 * @return
	 */
	public static List<String> getStringToList(final String stringVal, final String token) {
		List<String> stringList = new ArrayList<String>();
		if (!(stringVal == null || "".equals(stringVal))) {
			StringTokenizer elements = new StringTokenizer(stringVal, token);
			while (elements.hasMoreElements()) {
				stringList.add(elements.nextElement().toString());
			}
		}
		return stringList;
	}

	/**
	 * converts list into string
	 * 
	 * @param stringVal
	 * @param separator
	 * @return
	 */
	public static String convertListIntoString(List<String> stringVal, String separator) {
		StringBuffer stringValue = new StringBuffer();
		String string = "";
		if (stringVal != null && !stringVal.isEmpty()) {
			for (int count = 0; count < stringVal.size(); count++) {
				stringValue.append(stringVal.get(count));
				if (count < stringVal.size() - 1) {
					stringValue.append(separator);
				}
				// stringValue = stringValue + stringVal.get(count) + separator;
			}

			string = stringValue.toString();
		}

		return string;
	}

	/**
	 * 
	 * @param stringVal
	 * @param separator
	 * @return
	 */
	public static String convertSetIntoString(Set<String> stringVal, String separator) {
		StringBuffer stringValue = new StringBuffer();
		String string = "";
		if (!stringVal.isEmpty()) {
			for (String strValue : stringVal) {
				stringValue.append(strValue);
				stringValue.append(separator);
				// stringValue = stringValue + stringVal.get(count) + separator;
			}

			string = stringValue.toString();
			string = string.substring(0, stringValue.length() - 1);
		}

		return string;
	}

	/**
	 * converts vector into string
	 * 
	 * @param stringVal
	 * @param separator
	 * @return
	 */
	public static String convertVectorIntoString(Vector<String> stringVal, String separator) {
		StringBuffer stringValue = new StringBuffer();
		if (!stringVal.isEmpty()) {
			for (int count = 0; count < stringVal.size(); count++) {
				stringValue.append(stringVal.get(count));
				stringValue.append(separator);
			}
		}
		String string = stringValue.toString();
		string = string.substring(0, stringValue.length() - 1);
		return string;
	}

	public boolean isNullString(String strValue) {
		boolean isNull = false;
		if (strValue != null && !strValue.equals("")) {
			isNull = true;
		}
		return isNull;
	}

	/**
	 * 
	 * @param strValue
	 * @return empty String if NULL
	 */
	public static String getString(String strValue) {
		if (strValue == null) {
			return "";
		}

		return strValue;
	}

	/**
	 * Will Return Integer List Object From Passed String List
	 * 
	 * @param stringVal
	 * @return
	 */
	public static List<Integer> convertStringListToIntegerList(List<String> stringVal) {
		List<Integer> valueList = null;
		if (!stringVal.isEmpty()) {
			valueList = new ArrayList<Integer>();
			Integer intObj = null;
			for (int count = 0; count < stringVal.size(); count++) {
				intObj = Integer.valueOf(stringVal.get(count));
				valueList.add(intObj);
			}
		}
		return valueList;
	}

	/**
	 * Will Return Integer List Object From Passed String List
	 * 
	 * @param stringVal
	 * @return
	 */
	public static List<String> convertIntegerListToStringList(List<Integer> stringVal) {
		List<String> valueList = null;
		if (!stringVal.isEmpty()) {
			valueList = new ArrayList<String>();
			for (int count = 0; count < stringVal.size(); count++) {
				String strObj = String.valueOf(stringVal.get(count));
				valueList.add(strObj);
			}
		}
		return valueList;
	}

	/**
	 * will return trimmed string if string is not null
	 * 
	 * @param tripStr
	 * @return
	 */
	public static String trim(String stringVal) {
		return (stringVal == null ? stringVal : stringVal.trim());
	}

	/**
	 * @param val
	 * @return
	 */
	public static int getIntFromString(String val) {
		int result = -1;
		if (val != null && !"".equals(val)) {
			try {
				result = Integer.parseInt(val);
			} catch (NumberFormatException e) {
				LOGGER.error(e.getMessage(), e);
			}
		}
		return result;
	}

	/**
	 * @param val
	 * @return
	 */
	public static long getLongFromString(String val) {
		long result = -1;
		if (val != null && !"".equals(val)) {
			try {
				result = Long.parseLong(val);
			} catch (NumberFormatException e) {
				LOGGER.error(e.getMessage(), e);
			}
		}
		return result;
	}

	/**
	 * @param value
	 * @return
	 */
	public static boolean getBooleanFromString(String value) {
		boolean result = false;
		if (value != null) {
			if (BOOL_TRUE.equals(value)) {
				result = true;
			}
		}
		return result;
	}

	/**
	 * 
	 * @param jsonObj
	 * @param paramterName
	 * @return
	 * @throws JSONException
	 */
	public static String getParameterValue(JSONObject jsonObj, String paramterName) throws JSONException {

		if (jsonObj.has(paramterName)) {
			return jsonObj.getString(paramterName);
		}

		return null;
	}

	public static boolean checkEmailValidation(String hex) {
		Matcher matcher;
		String emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

		matcher = Pattern.compile(emailPattern).matcher(hex);
		return matcher.matches();

	}

	public static int wordCount(String str) {
		if (str == null) {
			return 0;
		}

		return str.trim().split("\\s+").length;
	}

	public static String convertArrayToString(String[] strArray) {
		if (strArray != null && strArray.length > 0) {
			String result = Arrays.toString(strArray);
			if (result.startsWith("[") && result.endsWith("]")) {
				result = result.replace("[", "");
				result = result.replace("]", "");
				return result;
			}
		}
		return null;
	}

	public static String convertMapToString(Map<String, String> map , String separator , String keyValueSeparator) {
		StringBuilder stringBuilder = new StringBuilder();

		for (String key : map.keySet()) {
			if (stringBuilder.length() > 0) {
				stringBuilder.append(separator);
			}
			String value = map.get(key);
			try {
				/*
				 * stringBuilder.append((key != null ? URLEncoder.encode((String) key, "UTF-8")
				 * : "")); stringBuilder.append("="); stringBuilder.append(value != null ?
				 * URLEncoder.encode((String) value, "UTF-8") : "");
				 */
				stringBuilder.append(key);
				stringBuilder.append(keyValueSeparator);
				stringBuilder.append(value);

			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}

		}

		return stringBuilder.toString();
	}

	public static Map<Object, Serializable> convertStringToMap(String input) {
		Map<Object, Serializable> map = new HashMap<Object, Serializable>();

		String[] nameValuePairs = input.split("&");
		for (String nameValuePair : nameValuePairs) {
			String[] nameValue = nameValuePair.split("=");
			try {
				map.put(nameValue[0], nameValue.length > 1 ? nameValue[1] : "");
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		return map;
	}

}
