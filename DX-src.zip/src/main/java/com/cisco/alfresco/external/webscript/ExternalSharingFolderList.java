package com.cisco.alfresco.external.webscript;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.InvalidQNameException;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.namespace.RegexQNamePattern;
import org.alfresco.util.ISO9075;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.external.common.model.Folder;
import com.cisco.alfresco.external.common.model.FolderList;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.alfresco.external.utils.CharUtil;
import com.cisco.sd.rest.service.MigrationConstants;

public class ExternalSharingFolderList extends DeclarativeWebScript
{
    private static final Logger LOGGER = Logger.getLogger(ExternalSharingFolderList.class);
    private static final String CISCO_MODEL_URI = "http://www.cisco.com/model/content/1.0";
    private static final String SITE_DOCLIB_PATH = "/Company Home/Sites/edcsng/documentLibrary";
    private NodeService nodeService;
    private ServiceRegistry serviceRegistry;
    private PreferenceService preferenceService;

    public void setPreferenceService(PreferenceService preferenceService)
    {
        this.preferenceService = preferenceService;
    }

    @Override
    public Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
    {
        if (LOGGER.isDebugEnabled())
            LOGGER.debug("------------- ExternalSharingFolderList executeImpl ----------");
        //start US8623 Publish a file from Doc Central to multiple target folders in Doc Exchange
        String publisherId = req.getParameter("publisherId");
		LOGGER.info(" In case of caling ExternalSharingFolderList with publisherId ::: "+publisherId);
        //end of US8623 Publish a file from Doc Central to multiple target folders in Doc Exchange
        final Map<String, Object> model = new HashMap<String, Object>();
        try
        {

            FolderList searchList = getFolderList(publisherId);
            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("Result JSON Size: " + searchList.getFolderList().size());
                LOGGER.debug("Result JSON : " + searchList.toString());
            }
            model.put("result", searchList);
        }
        catch (InvalidNodeRefException ine)
        {
            LOGGER.error("InvalidNodeRefException : " + ine);
        }
        catch (Exception e)
        {
            LOGGER.error("Exception : " + e);
        }

        return model;
    }

    /**
     * 
     * @return
     */
    private FolderList getFolderList(String publisherId)
    {
        FolderList library = new FolderList();

        try
        {
        	//start US8623 Publish a file from Doc Central to multiple target folders in Doc Exchange
        	String currentUser=null;
        	if(publisherId!=null&&!publisherId.isEmpty()){
        		currentUser =publisherId;
        	}else{
        		 currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
        	}
        	//end of US8623 Publish a file from Doc Central to multiple target folders in Doc Exchange
        	LOGGER.debug(" In case of caling ExternalSharingFolderList with publisherId ::: "+currentUser);
        	/**
             * Get ExternalSharealeAspect Folders
             */
            List<NodeRef> externalShareableAspectFolderList = getExternalShareableAspectFolderList(currentUser);
            if (LOGGER.isDebugEnabled())
                LOGGER.debug("externalShareableAspectFolderList size : " + externalShareableAspectFolderList.size());

            /**
             * Get Preference Folders
             */
            List<NodeRef> preferenceFolderList = getPreferenceFolderList(currentUser);
            if (LOGGER.isDebugEnabled())
                LOGGER.debug("preferenceFolderList size : " + preferenceFolderList.size());

            Set<NodeRef> folderSet = new HashSet<NodeRef>();
            folderSet.addAll(externalShareableAspectFolderList);
            folderSet.addAll(preferenceFolderList);
            List<NodeRef> uniqueFolderList = new ArrayList<NodeRef>(folderSet);
            if (LOGGER.isDebugEnabled())
                LOGGER.debug("uniqueFolderList size :::: " + uniqueFolderList.size());
            
            /**
             * Get MyFavorites Folders
             */
            List<NodeRef> myFavoritesFolderList = getMyFavoriteFolderList();
            if (LOGGER.isDebugEnabled())
                LOGGER.debug("myFavoritesFolderList size : " + myFavoritesFolderList.size());

            // Populate Folder Library List
            library.setFolderList(populateFolderInfo(currentUser, uniqueFolderList, myFavoritesFolderList));
            if (LOGGER.isDebugEnabled())
                LOGGER.debug("Successfuly added list to library-------");
        }
        catch (InvalidQNameException e)
        {
            LOGGER.error("Exception :", e);
        }
        catch (InvalidNodeRefException e)
        {
            LOGGER.error("Exception :", e);
        }
        catch (Exception e)
        {
            LOGGER.error("Exception :", e);
        }

        return library;
    }

    /**
     * 
     * @param currentUser
     * @return
     */
    private List<NodeRef> getExternalShareableAspectFolderList(String currentUser)
    {
        if (LOGGER.isDebugEnabled())
            LOGGER.debug("getExternalShareableAspectFolderList method");
        List<NodeRef> extShareableAspectFolderList = new ArrayList<NodeRef>();

        String searchQuery = "TYPE:\"cm:folder\" AND ASPECT:\"ext:extShareableAspect\"";
        List<NodeRef> nodeRefList = EDCSUtil.getNodeRefList(searchQuery, serviceRegistry);

        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("searchQuery : " + searchQuery);
            LOGGER.debug("nodeRefList : " + nodeRefList);
        }

        if (nodeRefList != null && nodeRefList.size() > 0)
        {
            for (NodeRef nodeRef : nodeRefList)
            {
                try
                {
                    if (LOGGER.isDebugEnabled())
                        LOGGER.debug("hasPermission on NodeRef : " + nodeRef + ", currentUser :" + currentUser);
                    boolean hasPermission = ExternalSharingFileFolderUtil.hasAccess(currentUser, nodeRef,
                        serviceRegistry);
                    boolean hasUserAccessOnParent=ExternalSharingFileFolderUtil.canUserHavePermissionOnParentFolder(nodeRef.toString(),serviceRegistry,currentUser);
                	
                    if (hasUserAccessOnParent && hasPermission)
                    {
                        extShareableAspectFolderList.add(nodeRef);
                    }
                }
                catch (Exception e)
                {
                    LOGGER.error("Exception in getExternalShareableAspectFolderList():" + e);
                }
            }
        }

        return extShareableAspectFolderList;
    }

    /**
     * 
     * @return
     */
    private List<NodeRef> getMyFavoriteFolderList()
    {
        if (LOGGER.isDebugEnabled())
            LOGGER.debug("getMyFavoriteFolderList method");
        List<NodeRef> myFavFolderList = new ArrayList<NodeRef>();
        NodeRef personNode = serviceRegistry.getPersonService().getPerson(
            AuthenticationUtil.getFullyAuthenticatedUser());
        List<ChildAssociationRef> childAssocList = nodeService.getChildAssocs(personNode,
            QName.createQName(CISCO_MODEL_URI, "myFavorite"), RegexQNamePattern.MATCH_ALL);

        if (childAssocList != null && childAssocList.size() > 0)
        {
            if (LOGGER.isDebugEnabled())
                LOGGER.debug("MyFavoriteFolderList : " + childAssocList.toString());
            for (ChildAssociationRef child : childAssocList)
            {
                myFavFolderList.add(child.getChildRef());
            }
        }

        return myFavFolderList;
    }

    /**
     * 
     * @param currentUser
     * @return
     */
    private List<NodeRef> getPreferenceFolderList(final String currentUser)
    {
        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("getPreferenceFolderList method");
        }
        final List<NodeRef> preferenceFolderList = new ArrayList<NodeRef>();
        try
        {
            String preferenceFilter = "org.alfresco.share.folders.favourites";
            Map<String, Serializable> currentPreferencesFolder = preferenceService.getPreferences(currentUser,
                preferenceFilter);

            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("PreferenceFolderList : " + currentPreferencesFolder);
            }

            if (currentPreferencesFolder.containsKey(preferenceFilter))
            {

                String item = (String) currentPreferencesFolder.get(preferenceFilter);

                if (item.indexOf(",") != -1 && item.indexOf(",") < 2)
                {
                    item = item.substring(1);
                }

                String[] itemArray = item.trim().split(",");
                for (int i = 0; i < itemArray.length; i++)
                {
                    final NodeRef nodeRef = new NodeRef(itemArray[i]);
                    AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
                    {
                        @Override
                        public Object doWork() throws Exception 
                        {
                            if (serviceRegistry.getNodeService().exists(nodeRef) && !serviceRegistry.getNodeService().hasAspect(nodeRef, ContentModel.ASPECT_HIDDEN))
                            {
                            	
                                if (LOGGER.isDebugEnabled())
                                {
                                    LOGGER.debug("hasPermission on NodeRef : " + nodeRef + ", currentUser :"
                                            + currentUser);
                                }

                                final boolean hasFolderPermission = ExternalSharingFileFolderUtil.hasAccess(
                                    currentUser, nodeRef, serviceRegistry);
                                boolean hasUserAccessOnParent=ExternalSharingFileFolderUtil.canUserHavePermissionOnParentFolder(nodeRef.toString(),serviceRegistry,currentUser);
                            	
                                if (hasUserAccessOnParent && hasFolderPermission)
                                {
                                    preferenceFolderList.add(nodeRef);
                                }
                            }
                            return null;
                        }
                    }, "admin");

                }
            }
        }
        catch (Exception e)
        {
            LOGGER.error("Exception in getPreferenceFolderList : ", e);
        }
        return preferenceFolderList;
    }

    /**
     * 
     * @param currentUserName
     * @param uniqueFolderList
     * @param myFavoritesFolderList
     * @return
     */
    private List<Folder> populateFolderInfo(String currentUserName, List<NodeRef> uniqueFolderList,
            List<NodeRef> myFavoritesFolderList)
    {
        List<Folder> folderList = new ArrayList<Folder>();
        for (NodeRef nodeRef : uniqueFolderList)
        {
            Folder folder = new Folder();
            Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);

            String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
            fileName = CharUtil.replaceEscape(fileName);
            folder.setName(ISO9075.decode(fileName));
            folder.setNodeId(nodeRef.toString());

            String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
            title = CharUtil.replaceEscape(title);
            folder.setTitle(ISO9075.decode(title));

            String description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
            description = CharUtil.replaceEscape(description);
            folder.setDescription(ISO9075.decode(description));

            folder.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));

            folder.setCreationdate(ExternalSharingFileFolderUtil.getGMTDateFormat((Date) nodeProp
                    .get(ContentModel.PROP_CREATED)));
            folder.setModifieddate(ExternalSharingFileFolderUtil.getGMTDateFormat((Date) nodeProp
                    .get(ContentModel.PROP_MODIFIED)));

            folder.setModDate(getGMTDateFormatFromString((Date) nodeProp.get(ContentModel.PROP_MODIFIED)));
            // Badam End - DE2566
            // UTHRA START
            folder.setCreated(getGMTDateFormat((Date) nodeProp.get(ContentModel.PROP_CREATED)));
            folder.setModified(getGMTDateFormat((Date) nodeProp.get(ContentModel.PROP_MODIFIED)));
            // UTHRA END
            folder.setType("folder");
            folder.setPermissionLevel(ExternalSharingFileFolderUtil.getUserRole(serviceRegistry, currentUserName,
                nodeRef));
            //Venkat
            folder.setApplyVeraProtection((String) nodeProp.get(ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION));

            // DEEPAK
            String folderAminRole = "Folder Admin";
            if (folderAminRole.equals(folder.getPermissionLevel()))
            {
            	 folder.setFolderEmpty(true);
            }
            else
            {
                folder.setFolderEmpty(false);
            }

            // DEEPAK
            String folderDisplayPath = serviceRegistry
                    .getNodeService()
                        .getPath(nodeRef)
                        .toDisplayPath(serviceRegistry.getNodeService(), serviceRegistry.getPermissionService());

            StringBuilder folderPath = new StringBuilder();
            if (folderDisplayPath.length() > SITE_DOCLIB_PATH.length() && folderDisplayPath.contains(SITE_DOCLIB_PATH))
            {
                folderPath.append(folderDisplayPath.split(SITE_DOCLIB_PATH)[1]).append("/").append(folder.getName());
            }
            else
            {
                folderPath.append("/").append(folder.getName());
            }
            folder.setRelativePath(ISO9075.decode(folderPath.toString()));

            folder.setFavoriteStatus(myFavoritesFolderList.contains(nodeRef));

            //prbadam Start: Added for US5491 - Root Folder Creation in Doc Exchange
    		if(serviceRegistry.getNodeService().hasAspect(nodeRef, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT)){
    			folder.setCreatedInDocExchange(false);
    		} else{
    		folder.setCreatedInDocExchange(true);
    		}
    		//prbadam End: Added for US5491 - Root Folder Creation in Doc Exchange
    		
    		
    		// checking deep level folders contains DC published folders
			List<FileInfo> deepTargetFolderNodeRefs = serviceRegistry.getFileFolderService().listDeepFolders(nodeRef, null);
			// LOGGER.info("deepTargetFolderNodeRefs------------"+deepTargetFolderNodeRefs);
			if(deepTargetFolderNodeRefs.size() > 0){
			       for (FileInfo childAssoc : deepTargetFolderNodeRefs) {
			    	 final NodeRef  childNodeRef = childAssoc.getNodeRef();
			    	// LOGGER.info("childNodeRef---------"+childNodeRef);
			    		if(serviceRegistry.getNodeService().hasAspect(childNodeRef, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT)){
			    			LOGGER.info("DC folder exists---------");
			    			folder.setDcFolderExists(true);
			    			//throw new WebScriptException("You can't move the folder, as source contains DC published folder(s)");
	            		} else {
	            			folder.setDcFolderExists(false);
	            		}
			       }
			}

			//Tags -  Uthra
            String tagName = "";
            if(nodeService.hasAspect(nodeRef,ExternalSharingConstants.CISCO_TAG_ASPECT)){
            	tagName = (String) nodeService.getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
       			LOGGER.info("tagName :: " +tagName);
       		}
            
            folder.setTags(tagName);
          // Tags - Uthra

            folderList.add(folder);
        }

        return folderList;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    /**
     * @param nodeService
     *            the nodeService to set
     */
    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    public static String getGMTDateFormat(Date date)
    {
        DateFormat df;
        String formatedDate = "";
        try
        {
            df = new SimpleDateFormat("yyyy/MM/dd HH:mm z"); // YYYY/MM/DD HH:MM GMT
            df.setTimeZone(TimeZone.getTimeZone("GMT"));
            formatedDate = df.format(date);
        }
        catch (Exception e)
        {
            LOGGER.error(e.getMessage());
        }
        return formatedDate;
    }

    public static Date getGMTDateFormatFromString(Date date)
    {
        DateFormat df;
        String formatedDate = "";
        Date date1 = null;
        try
        {
            df = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
            df.setTimeZone(TimeZone.getTimeZone("GMT"));
            if (date != null)
            {
                formatedDate = df.format(date);
                date1 = df.parse(formatedDate);
            }
        }
        catch (Exception e)
        {
            LOGGER.error("Exception....." + e);
        }
        return date1;
    }

}
