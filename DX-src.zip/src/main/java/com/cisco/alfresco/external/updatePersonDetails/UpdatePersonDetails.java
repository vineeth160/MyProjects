package com.cisco.alfresco.external.updatePersonDetails;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AuthorityService;
import org.alfresco.service.cmr.security.MutableAuthenticationService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;

/**
 * 
 * @author prbadam - US5888 - Ability to send email notifications to an email address different from the CEC email for cisco.com users
 * 
 */
public class UpdatePersonDetails extends DeclarativeWebScript
{
    private static final Logger logs = Logger.getLogger(UpdatePersonDetails.class);
    private ServiceRegistry serviceRegistry = null;
    private static String zoneId = AuthorityService.ZONE_AUTH_EXT_PREFIX + "ldap";
    private ExternalLDAPUtil ldapUtil;
    
    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }
 
    public ExternalLDAPUtil getLdapUtil()
    {
        return ldapUtil;
    }

    public void setLdapUtil(ExternalLDAPUtil ldapUtil)
    {
        this.ldapUtil = ldapUtil;
    }
    
	/**
	 * 
	 * @param req
	 * @return
	 */
	private String readRequestBody(WebScriptRequest req) {
		try {
			return IOUtils.toString(req.getContent().getInputStream(), req
					.getContent().getEncoding());
		} catch (Exception e) {
			try {
				return req.getContent().getContent();
			} catch (IOException e1) {
				logs.error("Unable to read JSON request body", e1);
				throw new WebScriptException(
						"Unable to read JSON request body!! Epic fail.");
			}
		}
	}
	
	 public void createLDAPUser(String userid)
	    {
	        logs.info(".Start creating LDAP users.. " + userid);

	        final Set<String> zoneSet = getZones(zoneId);
	        String idAndName = ldapUtil.getUserDetailsFromLDAP(userid);
	        logs.info("idAndName =" + idAndName);
	        // idAndName =spathi::Satya Narayana::Cisco Systems, Inc.

	        final String userName = (idAndName.split("::"))[0];
	        logs.info("userName =" + userName);

	        String name = (idAndName.split("::"))[1];
	        logs.info("name =" + name);

	        String organization = (idAndName.split("::"))[2];

	        String firstName = "", lastName = "";
	        if (name.contains(" "))
	        {

	            firstName = (name.split(" "))[0];
	            logs.info("firstName =" + firstName);

	            lastName = (name.split(" "))[1];
	            logs.info("lastName =" + lastName);
	        }
	        else
	            firstName = name;

	        String email = (idAndName.split("::"))[3];

	        final HashMap<QName, Serializable> properties = new HashMap<QName, Serializable>();
	        properties.put(ContentModel.PROP_USERNAME, userName);
	        properties.put(ContentModel.PROP_FIRSTNAME, firstName);
	        properties.put(ContentModel.PROP_LASTNAME, lastName);
	        properties.put(ContentModel.PROP_EMAIL, email);
	        properties.put(ContentModel.PROP_ORGANIZATION, organization);
	        try
	        {
	            NodeRef newPerson = serviceRegistry.getPersonService().createPerson(properties, zoneSet);
	            logs.info("newPerson==" + newPerson);
	            MutableAuthenticationService authService = serviceRegistry.getAuthenticationService();
	            authService.createAuthentication(userName, userName.toCharArray());
	            authService.setAuthenticationEnabled(userName, true);
	        }
	        catch (Exception e)
	        {
	            logs.info("Exception at creating person:: " + e);
	            e.printStackTrace();
	        }
	    }
	
	 private Set<String> getZones(final String zoneId)
	    {
	        Set<String> zones = new HashSet<String>(5);
	        zones.add(AuthorityService.ZONE_APP_DEFAULT);
	        zones.add(zoneId);
	        return zones;
	    }
	
	
	  @Override
	    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
	    {
			
		  Map<String, Object> model = new HashMap<String, Object>();
		  String inputJSONValue = readRequestBody(req);
		  String userId = null, secondaryEmailId = null;
		  JSONObject jsonObject = null;
		  boolean usrExist = false;
		  
		  try {
			
			  jsonObject = new JSONObject(inputJSONValue);
			  userId = jsonObject.getString("userId");
			  secondaryEmailId = jsonObject.getString("secEmailId");
			  logs.info("userId--and--secEmailId-----"+userId+"--"+secondaryEmailId);
			  // checking user exists or not
			  usrExist = serviceRegistry.getPersonService().personExists(userId);
			   if (!usrExist)	
	           {
	               createLDAPUser(userId);
	           }
			   NodeRef personNode = serviceRegistry.getPersonService().getPerson(userId);
			   logs.info("personNode-------"+personNode);
			   
				QName mailAspect = QName.createQName("http://www.alfresco.org/model/external/content/1.0", "mailAspect");
				QName secondaryMailName = QName.createQName("http://www.alfresco.org/model/external/content/1.0", "secondaryMail");
				boolean hasMailAspect = serviceRegistry.getNodeService().hasAspect(personNode, mailAspect);
				logs.info("hasMailAspect-------"+hasMailAspect);
				
				Serializable secondaryMailvalue = serviceRegistry.getNodeService().getProperty(personNode, secondaryMailName);
				logs.info("secondaryMailvalue-------"+secondaryMailvalue);
			   
				if(hasMailAspect && secondaryMailvalue !=null && !secondaryMailvalue.toString().trim().equals("")){
					logs.info("in if------");
					serviceRegistry.getNodeService().setProperty(personNode, secondaryMailName, secondaryEmailId);
				} else {
					  // adding mailAspect to person node
					logs.info("in else------");
				    Map<QName, Serializable> mailProp = new HashMap<QName, Serializable>(1);
				    mailProp.put(secondaryMailName,secondaryEmailId);
				    serviceRegistry.getNodeService().addAspect(personNode,mailAspect, mailProp);
				    logs.info("mailAspect added successfully------");
				}
				model.put("msg", "Property updated successfully and user noderef is : "+personNode);
		  } catch (JSONException e) {
					e.printStackTrace();
				}
		return model;
	    }
}
