package com.cisco.alfresco.external.webscript;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;

/**
 * 
 * @author nathammi
 * 
 */
public class UpdateOptInOutEMailNotification  extends DeclarativeWebScript
{
    private static final Logger logs = Logger.getLogger(UpdateOptInOutEMailNotification.class);
    private ServiceRegistry serviceRegistry = null;
    
    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }
	
	  @Override
	    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
	    {
			
		  Map<String, Object> model = new HashMap<String, Object>();
		  boolean usrExist = false;
		  String statusMsg="Start of adding optInOut property";
		  try {
			  //for getting description file url (placeholder)
			  Map<String, String> templateArgs = req.getServiceMatch().getTemplateVars();
	          String action = templateArgs.get("action");
			  String userId = AuthenticationUtil.getFullyAuthenticatedUser();
			  logs.info("userId ::::::"+userId);
			  // checking user exists or not
			  usrExist = serviceRegistry.getPersonService().personExists(userId);
			  if(usrExist){
				 if ("optIn".equalsIgnoreCase(action))
			        {
					 statusMsg=updateOptInOutPersonProp(userId,false);
			        }
			        else if ("optOut".equalsIgnoreCase(action))
			        {
			        	statusMsg=updateOptInOutPersonProp(userId,true);
			        }
			  }
		  } catch (Exception e) {
			  		statusMsg=" Exception while adding optInOut property...";
			  		logs.error("Exception at updating person:: " + e);
					e.printStackTrace();
				}
		  model.put("message", statusMsg);
		  	return model;
	    }
	  
	  /**
		 * 
		 * @param userId
		 * @param requiredEmailNotify
		 * @return
		 */
		private String updateOptInOutPersonProp(String userId,boolean requiredEmailNotify) {
			String result="Start of adding optInOut property";
			try{
			 NodeRef personNode = serviceRegistry.getPersonService().getPerson(userId);
			   logs.info("personNodeId :::"+personNode);
				boolean hasEmailNotificationAspect = serviceRegistry.getNodeService().hasAspect(personNode, ExternalSharingConstants.ASPECT_OPTINOUT_EMAIL_NOTIFICATION);
				logs.info("hasEmailNotificationAspect on person ::::::"+hasEmailNotificationAspect);
				if(hasEmailNotificationAspect){
					serviceRegistry.getNodeService().setProperty(personNode, ExternalSharingConstants.PROP_OPTOUT_EMAIL_NOTIFY, requiredEmailNotify);
					result="Property requiredEmailNotify updated successfully for User Id : "+userId;
				} else {
					  // adding emailNotificationAspect to person node
					logs.info(":::::: inside else add aspect:::::::::");
				    Map<QName, Serializable> emailNotificationAspectProps = new HashMap<QName, Serializable>(1);
				    emailNotificationAspectProps.put(ExternalSharingConstants.PROP_OPTOUT_EMAIL_NOTIFY,requiredEmailNotify);
				    serviceRegistry.getNodeService().addAspect(personNode,ExternalSharingConstants.ASPECT_OPTINOUT_EMAIL_NOTIFICATION, emailNotificationAspectProps);
				    logs.info("emailNotificationAspect added successfully------");
				    result="Property requiredEmailNotify updated successfully for User Id : "+userId;
				}
			}catch(Exception exe){
				result=" Exception while adding optInOut property...";
		  		logs.error("Exception at updating person:: " + exe);
				exe.printStackTrace();
			}
			return result;
			
		}
}
