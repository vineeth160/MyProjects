package com.cisco.alfresco.external.favorite;
	
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.namespace.RegexQNamePattern;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthenticationService;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.security.PersonService;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

public class FavoriteAction extends DeclarativeWebScript{
	private static final Logger LOGGER = Logger.getLogger(FavoriteAction.class);
	private ServiceRegistry serviceRegistry;
	private AuthenticationService authenticationService;
	private PermissionService permissionService;
	private NodeService nodeService;
	private PersonService personService;
    final static String CISCO_MODEL_URI = "http://www.cisco.com/model/content/1.0"; //getChildAssocs http://www.cisco.com/model/content/1.0
    final static String CISCO_MODEL_URI_CM = "http://www.alfresco.org/model/content/1.0";
    private BehaviourFilter policyFilter;
  public BehaviourFilter getPolicyFilter() {
		return policyFilter;
	}
	public void setPolicyFilter(BehaviourFilter policyFilter) {
		this.policyFilter = policyFilter;
	}

	public PermissionService getPermissionService() {
		return permissionService;
	}
	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}
	public NodeService getNodeService() {
		return nodeService;
	}
	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}
	public AuthenticationService getAuthenticationService() {
		return authenticationService;
	}
	public void setAuthenticationService(AuthenticationService authenticationService) {
		this.authenticationService = authenticationService;
	}
    public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}
	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
	 public PersonService getPersonService() {
			return personService;
		}
		public void setPersonService(PersonService personService) {
			this.personService = personService;
		}
		QName ASSOC_NAME_MYFAVORITE_ASSOCIATE = QName.createQName(CISCO_MODEL_URI, "myFavorite");
	@Override
	    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
	    {
		ArrayList<String> userList = null;
		ArrayList<String> noderefList = null;
		userList = new ArrayList<String>();
		noderefList = new ArrayList<String>();
		String action = null;
		QName ASPECT_MYFAVORITEDOCS = QName.createQName(CISCO_MODEL_URI, "FavAspect"); 
   		Map<String, String> templateArgs = req.getServiceMatch().getTemplateVars();
		action = templateArgs.get("action");
		Map<String, Object> favoriteDetails=null;
		Map<String, Object> model=new HashMap<String, Object>();
		authenticationService = serviceRegistry.getAuthenticationService();
		String currentUserName = authenticationService.getCurrentUserName();
		LOGGER.info("Current Username :::" + currentUserName);
		NodeRef personNodereff=personService.getPerson(currentUserName);
		LOGGER.info("Person nodereff   ::" +personNodereff);
		String noderef = null;
		try {
			String str = req.getContent().getContent();
			try {
				JSONObject json = new JSONObject(str);
				noderef=json.getString("nodeId").toString();
				LOGGER.info("noderef............"+noderef);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		NodeRef nodereff=new NodeRef(noderef);
		if(nodeService.hasAspect(nodereff, ContentModel.ASPECT_WORKING_COPY)){
   		 LOGGER.info("workingCopyId ::::::::::::::  "+nodereff);
   		 NodeRef originalnoderef =(NodeRef)serviceRegistry.getCheckOutCheckInService().getCheckedOut(nodereff);
				 LOGGER.info("Original noderef:::::::::::::: "+originalnoderef);
				 nodereff = originalnoderef;
				LOGGER.info("nodeRef ::::::::::::::  "+nodereff);
   	 }
	 	if(serviceRegistry.getNodeService().exists(nodereff)){
    	Set<AccessPermission> userSet = getAllNodeRefPermissions(serviceRegistry, nodereff);
        LOGGER.info("userset size :: "+userSet.size());
        if (userSet.size() > 0)
        {
        	for (AccessPermission accessPermission : userSet)
            {
                String user = accessPermission.getAuthority();
                userList.add(user);
            }
        	if(userList.contains(currentUserName)){
                LOGGER.info("User have the permission on the document....Valid user");
        List<ChildAssociationRef> childAssocList = nodeService.getChildAssocs(personNodereff,ASSOC_NAME_MYFAVORITE_ASSOCIATE,RegexQNamePattern.MATCH_ALL);
       	if(childAssocList.size() >0)
    	{
    	for (ChildAssociationRef child : childAssocList)
    	{ 
			NodeRef childNodeRef = child.getChildRef();
			noderefList.add(childNodeRef.toString());
	    }
    	}
    	if(noderefList.contains(nodereff.toString())){
				LOGGER.info("Already file/folder is in list");
				 if (action.equalsIgnoreCase("remove")) {
					 try{
					 policyFilter.disableBehaviour(nodereff, ContentModel.ASPECT_AUDITABLE);
	               	if(childAssocList.size() >1){
	            		for (ChildAssociationRef child : childAssocList){ 
	        			NodeRef childNodeRef = child.getChildRef();
	        			if(childNodeRef.equals(nodereff)){
	        			nodeService.removeChildAssociation(child);
	        			break;
	        			}
	        		}
	            	}else if(childAssocList.size()==1){
	            		for (ChildAssociationRef child : childAssocList){ 
		        			NodeRef childNodeRef = child.getChildRef();
		        			if(childNodeRef.equals(nodereff)){
		        			nodeService.removeChildAssociation(child);
		        			nodeService.removeAspect(personNodereff, ASPECT_MYFAVORITEDOCS);
		        			break;
		        			}
		            	}
	            	}
	               // favoriteDetails = onremovePreferencesMethod(currentUserName , nodereff );
	                LOGGER.info("Removed from Fav list");
	                //nodeService.setProperty(nodereff, ContentModel.PROP_MODIFIER,currentUserName);
	                }
					 finally{
	                policyFilter.enableBehaviour(nodereff, ContentModel.ASPECT_AUDITABLE);
					 }
	   	 			}
				 else if(action.equalsIgnoreCase("add")){
					 LOGGER.info("Already file/folder is there in your fav list");
					 model.put("docNoderef", "Already file/folder is there in your fav list");
					 return model;
				 }
			}else{
			           if (action.equalsIgnoreCase("add")) {
			        	   try{
			        	   policyFilter.disableBehaviour(nodereff, ContentModel.ASPECT_AUDITABLE);
			        	   //favoriteDetails = setRemovePreferences(currentUserName , nodereff );
		               	if (nodeService.hasAspect(personNodereff, ASPECT_MYFAVORITEDOCS) == false)
		   	              {
		   	 				 this.nodeService.addAspect(personNodereff, ASPECT_MYFAVORITEDOCS, null);
		   	                  nodeService.addChild(personNodereff, nodereff, ASSOC_NAME_MYFAVORITE_ASSOCIATE, QName.createQName(CISCO_MODEL_URI_CM, nodereff.getId()));
		   	              }  
		   	          else{
		   	        	   nodeService.addChild(personNodereff, nodereff, ASSOC_NAME_MYFAVORITE_ASSOCIATE, QName.createQName(CISCO_MODEL_URI_CM, nodereff.getId()));
			   	            }
		   	 		    	//List<ChildAssociationRef> list2 =nodeService.getChildAssocs(personNodereff);
		   	 		    	// nodeService.setProperty(nodereff, ContentModel.PROP_MODIFIER,currentUserName);
		   	 		
			        	   }finally{
			        		   policyFilter.enableBehaviour(nodereff, ContentModel.ASPECT_AUDITABLE);
			        		   
			        	   }
		   	 				} 
		               else if (action.equalsIgnoreCase("remove")) {
		            	   LOGGER.info("File/Folder not there in your Favorite list...so,Not able to remove");
		            	   model.put("docNoderef", "File/Folder not there in your Favorite list...so,Not able to remove");
		            	   return model;
		            	   
		               }
		    }
	 	}
	 	else{
           	LOGGER.info("You Don't have the permission on the document");
           	model.put("docNoderef","You Don't have the permission on the document");
           	return model;
           }
       }
        else{
	 		LOGGER.info(" Invalid user id");
        	model.put("docNoderef","Invalid user id");
			return model;
	 	}
    	}else{
	 		LOGGER.info("invalid noderef");
	 		model.put("docNoderef","Invalid document noderef....");
	 		return model;
	 	}
	    
			return favoriteDetails;
	    }
	
	  
	
	
	public static Set<AccessPermission> getAllNodeRefPermissions(final ServiceRegistry serviceRegistry, final NodeRef nodeRef){
    	final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
	   	 AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				@Override
				public Object doWork() throws Exception {
					accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef));
					return null;
				}
	   	 }, "admin");
    	return accessPermission;
    }
		
}
	


