package com.cisco.alfresco.external.webscript;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.alfresco.external.utils.CharUtil;


public class GCSGetNoderefProps  extends DeclarativeWebScript {
	
	private static final Logger LOGGER = Logger.getLogger(GCSGetNoderefProps.class);
	private ServiceRegistry serviceRegistry;
	
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
	public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status,	Cache cache) 
	{
		final Map<String, Object> result = new HashMap<String, Object>();
		
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() 
	    {
			@Override
			public Object doWork() throws Exception 
			{
				Date isFileSyncDate = null;
				String fileSyncDate = "";
				boolean isSynced = false;
				String noderef = req.getParameter("nodeId");
			    String isVersion = req.getParameter("isVersion");
			    LOGGER.info("noderef :: " +noderef  + " isver  :: " +isVersion);
			    String node = null;
			    if(noderef==null || noderef.isEmpty())
			    {
					LOGGER.info("noderef is null");
					status.setMessage("noderef is not found in the input request parameter.");
					status.setCode(500);
				 }
				 else if(isVersion==null || isVersion.isEmpty())
				 {
					 LOGGER.info("is version is null");
					 status.setMessage("isVersion is not found in the input request parameter.");
					 status.setCode(500);
				 }
			     if(isVersion.equalsIgnoreCase("true"))
				 {
					  node = "versionStore://version2Store/".concat(noderef);
					  LOGGER.info("version node :: " +node);
				 }else{
					  node = "workspace://SpacesStore/".concat(noderef);
					  LOGGER.info("live node :: " +node);
				 }
			     NodeRef nodeRef = new NodeRef(node);
			     String fileName =null,description = null,security = null,expirationDate=null,versionNumber=null;
				 LOGGER.info("noderef :: " +nodeRef);
				 if(nodeRef.toString().contains("workspace://SpacesStore/") && nodeRef != null){
					 Map<QName, Serializable> nodeProp = serviceRegistry.getNodeService().getProperties(nodeRef);
					 fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
                     description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
                      security = (String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY);
                      expirationDate = ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp.get(ExternalSharingConstants.PROP_EXPIRAIONDATE)));
                      versionNumber = (String) nodeProp.get(ContentModel.PROP_VERSION_LABEL);
                      SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd kk:mm:ss z yyyy");
                     //LOGGER.error("nodeRef :: " + nodeRef+"  fileName :: " +fileName + "  description :: " +description + "  security :: " +security + "  expirationDate :: " +expirationDate );
                     if(serviceRegistry.getNodeService().hasAspect(nodeRef, ExternalSharingConstants.CISCO_GLOBAL_CACHING_ASPECT)){
            			 isFileSyncDate = (Date) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_FILE_SYNC_DATE_PROP);
            			 isSynced = (Boolean) serviceRegistry.getNodeService().getProperty(nodeRef, ExternalSharingConstants.CISCO_QNAME_IS_FILE_SYNCHED_PROP);
            			 LOGGER.info("isFileSyncDate :: " +isFileSyncDate);
            			 fileSyncDate = sdf.format(isFileSyncDate);
            		}
                    
                     result.put("nodeRef", nodeRef.toString());
                     result.put("versionNodeRef", "");
                     result.put("name", fileName);
                     result.put("description", description);
                     result.put("security", security);
                     result.put("expiryDate", expirationDate);
                     result.put("lastSyncedDate",fileSyncDate);
                     result.put("versionNumber",versionNumber);
                     if(isSynced){
                     result.put("isSynced","true");}
                     else{
                    	 result.put("isSynced","false");} 
				 }else if(nodeRef.toString().contains("versionStore://version2Store/") && nodeRef != null){
					 NodeRef livenode = liveNode(nodeRef);
					 LOGGER.info("livenode :: " +livenode);
					 VersionHistory versionHistory = serviceRegistry.getVersionService().getVersionHistory(livenode);
				        if (versionHistory != null && versionHistory.getAllVersions().size() > 0)
				        {
				            Collection<Version> versions = versionHistory.getAllVersions();
                            for (Version versionNode : versions)
				            {
				                // Properties from VersioNode
				                NodeRef vnodeRef = versionNode.getFrozenStateNodeRef();
				                LOGGER.info(" vnodeRef  :: " +vnodeRef);
				                
				              if(vnodeRef.toString().equalsIgnoreCase(nodeRef.toString())){
				            	 // LOGGER.error("inside setting");
				            	  Map<String, Serializable> versionNodeRefProps = versionNode.getVersionProperties();
				            	   fileName = (String) versionNodeRefProps.get(ContentModel.PROP_NAME);
				            	 //  LOGGER.error("fileName1 :: "+fileName);
				            	   fileName =   (String) versionNodeRefProps.get("name");
				            	  // LOGGER.error("fileName2 :: "+fileName);
				            	   fileName = CharUtil.replaceEscape(fileName);
				            	  // LOGGER.error("fileName3 :: "+fileName);
				                  String versionLabel = versionNode.getVersionLabel();
				                  result.put("nodeRef", livenode.toString());
				                  result.put("versionNodeRef", nodeRef.toString());
				                  result.put("name", fileName);
				                  result.put("versionNumber",versionLabel);
				                  result.put("description", description);
				                     result.put("security", security);
				                     result.put("expiryDate", "");
				                     result.put("lastSyncedDate","");
				                     result.put("issynced","");
				            	  break;
				            }

				            }

				        }
				      
				 }
				
				
		       return result;
	
		    }
		 },"admin");
		return result;
	}

	
	public NodeRef liveNode(NodeRef node) {
		LOGGER.info("node  :: " +node );
		NodeRef nodeRef = null;
		 VersionHistory versionHistory = serviceRegistry.getVersionService().getVersionHistory(node);
	        
	        if (versionHistory != null && versionHistory.getAllVersions().size() > 0)
	        {
	            Collection<Version> versions = versionHistory.getAllVersions();

	            for (Version versionNode : versions)
	            {
	                // Properties from VersioNode
	                 nodeRef = versionNode.getVersionedNodeRef();
	                LOGGER.info(" livenode  nodeRef  :: " +nodeRef);
	                break;
	               
	            }

	        }
			return nodeRef;
	        
		
	}	

}
