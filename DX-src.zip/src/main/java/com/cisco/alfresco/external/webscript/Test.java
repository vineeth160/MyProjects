package com.cisco.alfresco.external.webscript;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.alfresco.model.ContentModel;
import org.alfresco.util.ISO9075;

import com.cisco.alfresco.external.utils.CharUtil;

public class Test {

	public static void main(String[] args) throws UnsupportedEncodingException {
		// TODO Auto-generated method stub
		String fileName ="道可道非常道，名可名非常名.pdf";
		System.out.println(fileName);
	    //String headerName = "Accesstoken";
		
		String myString = "道可道非常道，名可名非常名.pdf";
		byte bytes[] = myString.getBytes("UTF-8"); 
		String value = new String(bytes, "UTF-8"); 
		System.out.println("russian encoding::::::"+value);
	    
	   // if((headerName.contains("AccessToken")||headerName.contains("Accesstoken"))&&headerName.equalsIgnoreCase("AccessToken")) {
	   // 	System.out.println(headerName);
	   // }
	    //String newFilename = new String(fileName.getBytes(),"UTF-8");
        String newFilename = new String(fileName.getBytes("ISO-8859-1"),"UTF-8");
        System.out.println(newFilename);
        String newFilename1 = new String(fileName.getBytes("ISO-8859-1"),"UTF-8");
        String en_name = ISO9075.encode(newFilename);   
        System.out.println(en_name);
       //String newFilename1 = new String(fileName.getBytes("Windows-1251"),"UTF-8");
      // System.out.println(newFilename1);
       String fname = URLEncoder.encode(fileName,"UTF-8").replaceAll("\\+", "%20");
       System.out.println("testing:-"+ fname);
       // System.out.println(newFilename);
       // fileName = CharUtil.replaceEscape(newFilename);
       // System.out.println(fileName);
        // String fn = ISO9075.decode(newFilename);
        // System.out.println(fn);
        // String en_name = ISO9075.encode(newFilename); 
         //System.out.println(en_name);

	}

}
