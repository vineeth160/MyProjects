package com.cisco.alfresco.external.common.model;

import org.alfresco.service.cmr.repository.NodeRef;



/**
 * 
 * @author vepagada
 * 
 */

public class UserActionsEntity {

    private String fileName;
    private String fileTitle;
    private String docPath;
    private String EDCSID;
    private String Publisher;
    private String updatedDate;
    private NodeRef ParentNodeRef;
    
    
    
	public String getEDCSID() {
		return EDCSID;
	}
	public void setEDCSID(String eDCSID) {
		EDCSID = eDCSID;
	}
	public String getPublisher() {
		return Publisher;
	}
	public void setPublisher(String publisher) {
		Publisher = publisher;
	}
	
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDocPath() {
		return docPath;
	}
	public void setDocPath(String docPath) {
		this.docPath = docPath;
	}
	public String getFileTitle() {
		return fileTitle;
	}
	public void setFileTitle(String fileTitle) {
		this.fileTitle = fileTitle;
	}
	public NodeRef getParentNodeRef() {
		return ParentNodeRef;
	}
	public void setParentNodeRef(NodeRef parentNodeRef) {
		ParentNodeRef = parentNodeRef;
	}
    
}
