package com.cisco.alfresco.external.rootFolderCreation;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.site.SiteInfo;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.FavoriteUtil;
import com.cisco.docex.exceptions.ErrorObject;
import com.cisco.docex.exceptions.ValidationException;

/**
 * 
 * @author prbadam - US5491 and DE4624 (Root Folder Creation in Doc Exchange)
 * 
 */
public class CreateRootFolder extends DeclarativeWebScript
{
	private static final Logger LOGGER = Logger.getLogger(CreateRootFolder.class);
	String SITE_NAME = "edcsng";
	String USERS = "Users";
    private ServiceRegistry serviceRegistry;
    private PermissionService permissionService;
    private ExternalLDAPUtil ldapUtil;
    private BehaviourFilter policyFilter;
    private static final Pattern pattern = Pattern.compile("[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
    
    public BehaviourFilter getPolicyFilter() {
  		return policyFilter;
  	}
  	public void setPolicyFilter(BehaviourFilter policyFilter) {
  		this.policyFilter = policyFilter;
  	}
    
  	public void setPreferenceService(PreferenceService preferenceService) {
  	}
    
    public ExternalLDAPUtil getLdapUtil() {
		return ldapUtil;
	}

	public void setLdapUtil(ExternalLDAPUtil ldapUtil) {
		this.ldapUtil = ldapUtil;
	}
    
    public PermissionService getPermissionService() {
		return permissionService;
	}

	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}

	public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }
 
    
	public NodeRef getSiteDocLibNodeRef (String siteName){
		LOGGER.info("inside getSiteDocLibNodeRef :::: "+siteName);
		SiteInfo siteInfo = serviceRegistry.getSiteService().getSite(siteName);
		LOGGER.info("siteInfo :::: "+siteInfo);
		NodeRef docLibNodRef = serviceRegistry.getSiteService().getContainer(siteInfo.getShortName(), "documentLibrary");
		LOGGER.info("docLibNodRef :::: "+docLibNodRef);
		return docLibNodRef;
	}
	
	public NodeRef createFolder(final NodeRef parentNodeRef, final String folderName,String folderDescription,String domain,String isGusetAccess, String applyVeraProtection, String tags){
		NodeRef folderNodeRef = null;
		try {
		final Map<QName, Serializable> props = new HashMap<QName, Serializable>(1);
		props.put(ContentModel.PROP_NAME, folderName);
		props.put(ContentModel.PROP_TITLE, folderName);
		props.put(ContentModel.PROP_DESCRIPTION, folderDescription);
        //US8499 :prbadam start
		 folderNodeRef = serviceRegistry.getNodeService().createNode(parentNodeRef, ContentModel.ASSOC_CONTAINS,
					QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, folderName), ContentModel.TYPE_FOLDER, props).getChildRef();
         //US8499 :prbadam end
		//Uthra changes start - Tag
  	    if(tags != null && !tags.isEmpty()){
  	    	LOGGER.info("if tag is not empty on Node :: "+folderNodeRef +"  :: " +tags);
  	    	serviceRegistry.getNodeService().addAspect(folderNodeRef, ExternalSharingConstants.CISCO_TAG_ASPECT, null);
  	    	serviceRegistry.getNodeService().setProperty(folderNodeRef, ExternalSharingConstants.CISCO_QNAME_TAG_NAME, tags);
  	    }
  	    //Uthra changes end - Tag
  	    
		 //Vera changes for applying folder protection
		 LOGGER.info("applyVeraProtection value is " + applyVeraProtection + " for folder Name : " + folderName);
		 if(applyVeraProtection != null && applyVeraProtection.matches("Cisco Restricted|All Contents")){
			 Map<QName, Serializable> verFolderProtectionProps = new HashMap<>(6);
				verFolderProtectionProps.put(ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION,applyVeraProtection);
				verFolderProtectionProps.put(ExternalSharingConstants.PROP_IS_VERA_ROOT_FOLDER,true);
				verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ENABLED_DATE,new Date());
				verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ENABLED_BY,AuthenticationUtil.getFullyAuthenticatedUser());
				verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ROOT_FOLDER_NODEREF,folderNodeRef.toString());
				serviceRegistry.getNodeService().addAspect(folderNodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION, verFolderProtectionProps);
		 }
		 //vera changes End
		
		 // adding domainAspect to the node
	    Map<QName, Serializable> domainProp = new HashMap<QName, Serializable>(1);
	    domainProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domain_name"),domain);
	    serviceRegistry.getNodeService().addAspect(folderNodeRef,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domainAspect"), domainProp);
	    
	    //adding disableguestUser Aspect to the node
	    Boolean isGusetAccessEnabled = false;
		 if(isGusetAccess!=null && isGusetAccess!="")
			 isGusetAccessEnabled = Boolean.valueOf(isGusetAccess);	 
	    Map<QName, Serializable> disableGuestProp = new HashMap<QName, Serializable>(1);
	    disableGuestProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}disableguestUser"),isGusetAccessEnabled);
	    serviceRegistry.getNodeService().addAspect(folderNodeRef,
	    		QName.createQName("{http://www.alfresco.org/model/external/content/1.0}domainAspect"), disableGuestProp);
	    
	    // setting Inherit permissions false by default
	    permissionService.setInheritParentPermissions(folderNodeRef, false);
		} catch (Exception e) {
    		LOGGER.error("Exception in createFolder mothod-----------"+e);
    		e.printStackTrace();
		}
		return folderNodeRef;
	}
	
	public Map<String, Object> getTargetNode(final String folderName,final String folderDescription,final String domain, final String logginUser,final String isGusetAccess,final String isFavorite, final String applyVeraProtction, final String tags, final String isEditorDeleteFiles)
	{
		LOGGER.info("inside getTargetNode :::: ");
		Map<String, Object> statusMessage = new HashMap<String, Object>();
		try{
		statusMessage = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Map<String, Object>>() {
				@Override
				public Map<String, Object> doWork() throws Exception {
					
					final Map<String, Object> innerModel = new HashMap<String, Object>();
					
					NodeRef siteNodeRef = getSiteDocLibNodeRef(SITE_NAME);
					
					NodeRef usersFolNodeRef = serviceRegistry.getFileFolderService().searchSimple(siteNodeRef, USERS);
					if (usersFolNodeRef == null) {
						if (LOGGER.isDebugEnabled()) {
							LOGGER.debug("Creating users folder under documentLibrary");
						}
						usersFolNodeRef = createFolder(siteNodeRef, USERS,folderDescription,domain,isGusetAccess,null, null);
					}
					LOGGER.info("usersFolNodeRef creation completd :::: "+usersFolNodeRef);
					String year = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
					NodeRef yearNode = null;

					yearNode = serviceRegistry.getNodeService().getChildByName(usersFolNodeRef, ContentModel.ASSOC_CONTAINS, year);
					Map<QName, Serializable> props = new HashMap<QName, Serializable>(1);
					if (yearNode == null) {
						LOGGER.info("Creating year folder under USERS");
						props.put(ContentModel.PROP_NAME, year);
						yearNode = createFolder(usersFolNodeRef, year,folderDescription,domain,isGusetAccess,null, null);
					}
					LOGGER.info("yearNode folder creation completd ::: "+yearNode);
					
					NodeRef userNodeRef = serviceRegistry.getFileFolderService().searchSimple(yearNode, logginUser);
					if (userNodeRef == null) {
						LOGGER.info("Creating folder with cec of loginuser under year");
						userNodeRef = createFolder(yearNode, logginUser,folderDescription,domain,isGusetAccess,null, null);
					}
					LOGGER.info("logginUser folder creation completd ::: "+userNodeRef);
					NodeRef userFolderNode = serviceRegistry.getFileFolderService().searchSimple(userNodeRef, folderName);
					if (userFolderNode == null) {
						LOGGER.info("inside if ::"+userNodeRef);
						//setting Preferences to userFolderNode to show it in Library section. Added in transaction service for concurrency exception.
						 NodeRef finalUserFolderNode = createFolder(userNodeRef, folderName,folderDescription,domain,isGusetAccess,applyVeraProtction, tags);
						// START: US9855- adding editorDeleteFileAspect to the node
				     	    Map<QName, Serializable> editorDeleteFilesProp = new HashMap<QName, Serializable>(1);
				     	    editorDeleteFilesProp.put(QName.createQName("{http://www.alfresco.org/model/external/content/1.0}editorDeleteFiles"),isEditorDeleteFiles);
				     	    serviceRegistry.getNodeService().addAspect(finalUserFolderNode,QName.createQName("{http://www.alfresco.org/model/external/content/1.0}editorDeleteFileAspect"), editorDeleteFilesProp);
				     	    // END: US9855- adding editorDeleteFileAspect to the node
				     	    //START : US8067 - PRBADAM added Ability to mark a folder as favorite while creating a folder.
							FavoriteUtil.addFavorite(serviceRegistry, policyFilter, logginUser, isFavorite, finalUserFolderNode);
							//END : US8067 - PRBADAM added Ability to mark a folder as favorite while creating a folder.
							//setting Folder Admin permissions to finalUserFolderNode
				        	 permissionService.setPermission(finalUserFolderNode, logginUser, "AdminRole", true);
						 LOGGER.info("Successfully created folder with Folder Admin permissions for folder node ---"+finalUserFolderNode);
						 innerModel.put("innerStatus", "Root folder created successfully");
						 innerModel.put("nodeId", finalUserFolderNode);
					} else {
						innerModel.put("innerStatus", "Duplicate child name not allowed");
					LOGGER.info("Folder already exists ::::");
					}
					return innerModel;
				} 
	   	 }, "admin");
		
		} catch (Exception e) {
    		LOGGER.error("Exception in getTargetNode mothod :::: "+e);
    		e.printStackTrace();
		}
		return statusMessage;
	}
	
	/**
	 * 
	 * @param req
	 * @return
	 */
	private String readRequestBody(WebScriptRequest req) {
		try {
			return IOUtils.toString(req.getContent().getInputStream(), req
					.getContent().getEncoding());
		} catch (Exception e) {
			try {
				return req.getContent().getContent();
			} catch (IOException e1) {
				LOGGER.error("Unable to read JSON request body", e1);
				throw new WebScriptException(
						"Unable to read JSON request body!! Epic fail.");
			}
		}
	}
  
	  @Override
	    public Map<String, Object> executeImpl(final WebScriptRequest req, final Status status, final Cache cache)
	    {
		  	LOGGER.info("--- Started RootFolderCreation----");
		  	Map<String, Object> model = new HashMap<String, Object>();
		  	String logginUser = AuthenticationUtil.getFullyAuthenticatedUser();
		  	LOGGER.info("logginUser------:: "+logginUser);
		  	
			String inputJSONValue = readRequestBody(req);
			JSONObject jsonObject = null;
			String folderName=null , folderDescription=null, domain=null, isGusetAccess=null, isFavorite=null, applyVeraProtction=null, tags="", isEditorDeleteFiles=null;
			
			if(isUserInternal(logginUser) || isUserGenerics(logginUser)){
			try {
				jsonObject = new JSONObject(inputJSONValue);
				folderName = jsonObject.getString("name");
				isGusetAccess = jsonObject.getString("disableGuestUsers");
				applyVeraProtction = jsonObject.getString("applyVeraProtection");
				folderDescription = jsonObject.has("description")&&jsonObject.getString("description") !=null ? jsonObject.getString("description") : "";
 				domain = jsonObject.has("domain")&&jsonObject.getString("domain") !=null ? jsonObject.getString("domain") : "";	
				LOGGER.info("folderName  :::: "+folderName);
				
				isFavorite = jsonObject.getString("favorite");
 				LOGGER.info("isFavorite :: "+isFavorite);
 				if(jsonObject.has("tags")){
 				tags = jsonObject.getString("tags");
 				LOGGER.info("tags :: "+tags);
 				
 				isEditorDeleteFiles = jsonObject.getString("disableDeleteDocuments");
 				LOGGER.info("isEditorDeleteFiles :::::: "+isEditorDeleteFiles);
 				
 				}
 				//TA18357 changes starts here
 				String[] doaminSplit = domain.split(",");
		     		List<String> doaminList = new ArrayList<String>();
		     		Collections.addAll(doaminList, doaminSplit);
			     	//TA17657 changes starts here
			     	for(int j=0; j<doaminList.size();j++){
			     		if(!doaminList.get(j).isEmpty() && doaminList.get(j)!=null) {
			   	           if (!pattern.matcher(doaminList.get(j)).matches()) {
   				        	   LOGGER.info("provide valid input for domain :: "+doaminList.get(j));
	   				               	ErrorObject eob = new ErrorObject();
	   								eob.setField("domain");
	   								eob.setError("Submitted domain is not in correct format("+doaminList.get(j)+")");
	   								throw new ValidationException(eob);
	   				           }
			     		}
			     		}
	     	       //TA18357 ends here
 				
 				
				Map<String, Object> finalStatusMessage = getTargetNode(folderName,folderDescription,domain,logginUser,isGusetAccess,isFavorite,applyVeraProtction,tags,isEditorDeleteFiles);
				
				LOGGER.info("finalStatusMessage :::::: "+finalStatusMessage);
				
				model.put("message", finalStatusMessage);
				LOGGER.info("--- Finished in RootFolderCreation----");
				
				}// End of try
			     //TA18357 changes starts here
			catch(ValidationException ve) {
				Map<String, Object> errorStatusMessage = new HashMap<String, Object>();
				LOGGER.error("Domain validation Exception" , ve);
				ErrorObject eob = ((ValidationException) ve).getErrorObj();
				status.setMessage(eob.getError().toString());
				status.setCode(Status.STATUS_BAD_REQUEST);
				errorStatusMessage.put("innerStatus", eob.getError());
				errorStatusMessage.put("nodeId", "");
				model.put("message", errorStatusMessage);
				return model;
			  }
			//TA18357 changes ends here
			 catch (Exception e) {
					LOGGER.error("Exception at creating rootfolder ::::--"+e);
					e.printStackTrace();
				}
			} // End of checking internal user
			  else
	            {
	                model.put("message", "You are not authorized to perform this operation.");
	            }
			return model;
	    }
	  
	  public boolean isUserInternal(String userid)
	    {
	        LOGGER.info((new StringBuilder("Start checking if internal LDAP users.. ")).append(userid).toString());
	        return ldapUtil.isLdapUserInternal((new StringBuilder(String.valueOf(userid))).toString());
	    }
	  public boolean isUserGenerics(String userid)
	  {
		  LOGGER.info((new StringBuilder("Start checking if Generics LDAP users.. ")).append(userid).toString());
	      return ldapUtil.isLdapUserGeneric((new StringBuilder(String.valueOf(userid))).toString());
	  }
}
