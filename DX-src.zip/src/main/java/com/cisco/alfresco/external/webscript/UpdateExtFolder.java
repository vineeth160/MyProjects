package com.cisco.alfresco.external.webscript;


import java.io.IOException;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.util.ISO9075;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.edcsng.util.EDCSUtil;


public class UpdateExtFolder extends AbstractWebScript {
	private static final Logger log = Logger.getLogger(UpdateExtFolder.class);
	
	private ServiceRegistry serviceRegistry;
	private NodeService nodeService;
	private BehaviourFilter policyFilter;
	
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}
	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
	public NodeService getNodeService() {
		return nodeService;
	}
	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}
	
	public BehaviourFilter getPolicyFilter() {
		return policyFilter;
	}
	public void setPolicyFilter(BehaviourFilter policyFilter) {
		this.policyFilter = policyFilter;
	}
	
	public void execute(WebScriptRequest req, WebScriptResponse res)
	        throws IOException
	    {
	    	try
	    	{
	    		log.info("UpdateExtFolder class called:");
	    		
	    		JSONParser jsonParser = new JSONParser();
	    		org.json.simple.JSONObject jsonObject = null;
	    
	    		jsonObject = (org.json.simple.JSONObject) jsonParser.parse(req.getParameter("jsonMetadata"));
	    		
	    		String path = (String) jsonObject.get("path");
	    		log.info("path:"+path);
	    		String folderName = (String) jsonObject.get("folderName");
	    		log.info("folderName:"+folderName);
	    		String title = (String) jsonObject.get("title");
	    		String description = (String) jsonObject.get("description");
	    		log.info("title:"+title+" , "+"desc:"+description);
	    		
	    		String name_present = (String)jsonObject.get("name_present");
	    	
	    		String title_present = (String)jsonObject.get("title_present");
	    		String desc_present = (String)jsonObject.get("desc_present");
	    		
	    		String modifiedBy = (String)jsonObject.get("modifiedBy");
	    
	    
	    		JSONObject obj = new JSONObject();
	    		             	                		
	    		StringBuilder sb = new StringBuilder();
	    		sb.append("PATH:\"");
	    		sb.append(path);
	    		sb.append("\"");
	    		String query = sb.toString();
	    		//Start of DE1177
	    		//get the name changed folder parent node through query	 
	    		log.info("Query from DC:"+query);
	    		String parentNodePathQuery=query.substring(0,query.lastIndexOf("/"))+"\"";
	    		log.info("Query to get parent node of folder :"+parentNodePathQuery);
	    		//query = ISO9075.decode(query); 
	    		NodeRef parentNodeRef= EDCSUtil.doSearch(parentNodePathQuery, serviceRegistry);
	    		log.info("Parent path Query result:"+parentNodeRef);
	    		String oldFolderName=query.substring(query.lastIndexOf("/")+1,query.length());
	    		oldFolderName=oldFolderName.replace("cm:", "");
	    		oldFolderName=oldFolderName.replace("\"", "");
	    		log.info("oldFolderName after decode ::::"+ISO9075.decode(oldFolderName));
	    		NodeRef nodeRef=nodeService.getChildByName(parentNodeRef, ContentModel.ASSOC_CONTAINS, ISO9075.decode(oldFolderName));
	    		log.info("oldNamedFolder nodeRef::"+nodeRef);
	    		//End of DE1177
	    		
	    		if (nodeRef != null && name_present != null && name_present.equalsIgnoreCase("Y")) {
	    			serviceRegistry.getFileFolderService().rename(nodeRef, folderName);
	    		}
	    		
	    		//nodeService.setProperty(nodeRef, ContentModel.PROP_NAME, folderName);
	    		if (nodeRef != null && title_present != null && title_present.equalsIgnoreCase("Y")) {
	    			nodeService.setProperty(nodeRef, ContentModel.PROP_TITLE, title);
	    		}
	    		if (nodeRef != null && desc_present != null && desc_present.equalsIgnoreCase("Y"))	{
	    			nodeService.setProperty(nodeRef, ContentModel.PROP_DESCRIPTION, description);
	    		}
	    			    		
	    		obj.put("queryResult",nodeRef);
	    		
	    		// build a JSON string and send it back
		    	String jsonString = obj.toString();
		    	res.getWriter().write(jsonString);
		    	if(nodeRef != null && modifiedBy != null && !modifiedBy.isEmpty()){
		    		setModifierAsLogedInUser(nodeRef, modifiedBy);
		    	}
		    	log.info(":::::: Folder ReNamed successfully ::::");
	    	} catch(Exception e) {
	    		log.error(e.getStackTrace(),e);
	    		
	    	}
	    }
	
	private void setModifierAsLogedInUser(NodeRef nodeRef, String modifiedBy) throws Exception{
		try{
			policyFilter.disableBehaviour(nodeRef, ContentModel.ASPECT_AUDITABLE);
			nodeService.setProperty(nodeRef, ContentModel.PROP_MODIFIER, modifiedBy);
		}finally {
			policyFilter.enableBehaviour(nodeRef,ContentModel.ASPECT_AUDITABLE);
		}
	}

	
}
