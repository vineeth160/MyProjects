/**
 * 
 */
package com.cisco.alfresco.dx.cache.service;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.Document;
import org.bson.types.Binary;
import org.json.simple.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;
import org.springframework.extensions.webscripts.servlet.FormData;

import com.cisco.alfresco.dx.cache.service.encryption.DecryptingCacheContentReader;
import com.cisco.alfresco.dx.cache.service.encryption.EncryptingCacheContentStore;
import com.cisco.alfresco.dx.cache.util.CryptoUtil;
import com.cisco.alfresco.edcsng.constants.ApplicationConstants;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.model.GridFSFile;
import com.mongodb.client.model.Filters;

/**
 * @author rajatag
 *
 */
public class CacheSyncUpload extends AbstractWebScript {
	private static Logger log = Logger.getLogger(CacheSyncUpload.class);
	private ServiceRegistry registry;
	private String identity = null;
	private String key = null;
	private String mongoDbName = null;
	
	private BehaviourFilter behaviourFilter;
	private String env;

	EncryptingCacheContentStore cacheContentStore = new EncryptingCacheContentStore();
	
    public void setEnvironment(String sysEnvironment)
    {
    	env = sysEnvironment;
    }
    
    /**
     * Spring configuration
     * 
     * @param behaviourFilter the behaviourFilter to set
     */
    public void setBehaviourFilter(BehaviourFilter behaviourFilter)
    {
        this.behaviourFilter = behaviourFilter;
    }
	
	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void execute(final WebScriptRequest req, final WebScriptResponse res)
			throws IOException {
		final JSONObject responseObject = new JSONObject();
		final String nodeRefString = req.getParameter("nodeRef");
		final String location = req.getParameter("geoLoc");
		final String versionRefString = req.getParameter("versionRef");
		String user = req.getParameter("versionRef");	
		user = null == user ? registry.getAuthenticationService().getCurrentUserName() : user;
		if (log.isInfoEnabled()){
			log.info(":: Upload Sync : CURRENT USER:: "+ user);
		}

		if(nodeRefString == null)
		{
			res.setStatus(530);
			responseObject.put("message", "File Syncing Failed because of null noderef");
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			return;
		}
		
		NodeRef nodeRef = new NodeRef(nodeRefString);
		
		if(req.getParameter("fallback") != null && "true".equals(req.getParameter("fallback")))
		{
			behaviourFilter.disableBehaviour(nodeRef, ContentModel.ASPECT_VERSIONABLE);
			behaviourFilter.disableBehaviour(nodeRef, ContentModel.ASPECT_AUDITABLE);
			if(registry.getCheckOutCheckInService().isCheckedOut(nodeRef))
			{
				NodeRef workingNodeRef = registry.getCheckOutCheckInService().getWorkingCopy(nodeRef);
				registry.getCheckOutCheckInService().cancelCheckout(workingNodeRef);
			}
			FormData formData = (FormData) req.parseContent();
			FormData.FormField[] fields = formData.getFields();
			String mimetype = null;
			InputStream in = null;
			String modifier = (String) registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_MODIFIER);
			for (FormData.FormField field : fields) {
				if (field.getName().equals("file") && field.getIsFile()) {
					mimetype = field.getMimetype();
					in = field.getInputStream();
					
					String mt = registry.getMimetypeService().guessMimetype(field.getFilename());
				    if (mt != null)
				    	mimetype = mt;
				    
				    ContentWriter writer = registry.getContentService().getWriter(nodeRef, ContentModel.TYPE_CONTENT, true);
					writer.setMimetype(mimetype);
					writer.putContent(in);
					registry.getNodeService().setProperty(nodeRef, ContentModel.PROP_MODIFIER, modifier);
					behaviourFilter.enableBehaviour(nodeRef, ContentModel.ASPECT_VERSIONABLE);
					behaviourFilter.enableBehaviour(nodeRef, ContentModel.ASPECT_AUDITABLE);
					return;
				}
			}
		}
		
		if(versionRefString == null)
		{
			res.setStatus(530);
			responseObject.put("message", "File Syncing Failed because of null VersionRef");
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			return;
		}
		
		if(location == null)
		{
			res.setStatus(530);
			responseObject.put("message", "File Syncing Failed because of null location");
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			return;
		}
		
		identity = ApplicationConstants.getValue(env + ".mongo.usrname");
		key = ApplicationConstants.getValue(env + ".mongo.pswrd");
		mongoDbName = ApplicationConstants.getValue("mongo.cache.dbname");
		
		String mongoHost = ApplicationConstants.getValue(env + "." + location + ".mongo.host");
		MongoClientURI uri = new MongoClientURI("mongodb://" + identity.trim() + ":" + URLEncoder.encode(CryptoUtil.decryptString(key).trim(), "UTF-8") + "@" + mongoHost + ":28017/" + mongoDbName.trim());
		try (MongoClient mongo = new MongoClient(uri);)
		{
			behaviourFilter.disableBehaviour(nodeRef, ContentModel.ASPECT_VERSIONABLE);
			behaviourFilter.disableBehaviour(nodeRef, ContentModel.ASPECT_AUDITABLE);
			String modifier = (String) registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_MODIFIER);
		    MongoDatabase db = mongo.getDatabase(mongoDbName);
		    
			if(registry.getCheckOutCheckInService().isCheckedOut(nodeRef))
			{
				NodeRef workingNodeRef = registry.getCheckOutCheckInService().getWorkingCopy(nodeRef);
				registry.getCheckOutCheckInService().cancelCheckout(workingNodeRef);
				String versionUUID =  versionRefString.substring(versionRefString.lastIndexOf("/") +1 );
				String versionStoreStr = registry.getVersionService().getVersionStoreReference()+ "/" + versionUUID;
				registry.getNodeService().removeAspect(new NodeRef(versionStoreStr), ContentModel.ASPECT_CHECKED_OUT);
				registry.getNodeService().removeAspect(new NodeRef(versionStoreStr), ContentModel.ASPECT_LOCKABLE);
			}
			ContentWriter writer = registry.getContentService().getWriter(nodeRef, ContentModel.TYPE_CONTENT, true);
			writer.setMimetype(registry.getMimetypeService().guessMimetype(registry.getFileFolderService().getFileInfo(nodeRef).getName()));
			
			GridFSBucket fsBucket = GridFSBuckets.create(db);
			
			BsonValue id = new BsonString(versionRefString);
			
			GridFSFile file = fsBucket.find(Filters.eq("_id", versionRefString)).first();
			Document metadata = file.getMetadata();
			String masterKeyAlias = String.valueOf(metadata.get("alias"));
			byte[] byteData = ((Binary)metadata.get("byteData")).getData();
			DecryptingCacheContentReader reader = cacheContentStore.getCacheReader(masterKeyAlias, byteData, env);

			try{
				writer.putContent(reader.getDecryptedStream(fsBucket.openDownloadStream(id)));			
				log.info("SUCCESSfully written your file with noderef : " + nodeRefString + " and VersionRef : " + versionRefString);
				registry.getNodeService().setProperty(nodeRef, ContentModel.PROP_MODIFIER, modifier);
				behaviourFilter.enableBehaviour(nodeRef, ContentModel.ASPECT_VERSIONABLE);
				behaviourFilter.enableBehaviour(nodeRef, ContentModel.ASPECT_AUDITABLE);	
				return;
			} catch (Exception e) {
				e.printStackTrace();
				behaviourFilter.enableBehaviour(nodeRef, ContentModel.ASPECT_VERSIONABLE);
				behaviourFilter.enableBehaviour(nodeRef, ContentModel.ASPECT_AUDITABLE);
				res.setStatus(530);
				responseObject.put("message", "File Syncing Failed");
				res.getWriter().write(responseObject.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
			behaviourFilter.enableBehaviour(nodeRef, ContentModel.ASPECT_VERSIONABLE);
			behaviourFilter.enableBehaviour(nodeRef, ContentModel.ASPECT_AUDITABLE);	
			res.setStatus(530);
			responseObject.put("message", "File Syncing Failed");
			res.getWriter().write(responseObject.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			return;
		}
		
	}

}
