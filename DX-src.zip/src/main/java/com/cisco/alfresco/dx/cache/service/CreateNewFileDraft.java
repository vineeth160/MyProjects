/**
 * 
 */
package com.cisco.alfresco.dx.cache.service;

import java.io.IOException;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.transaction.RetryingTransactionHelper;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessStatus;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.service.commons.ServiceConstants;
import com.cisco.alfresco.service.constants.ErrorStatus;
import com.cisco.alfresco.service.util.ServiceUtil;

/**
 * @author kaudutta
 *
 */
public class CreateNewFileDraft extends AbstractWebScript {

	private ServiceRegistry registry;
	private BehaviourFilter behaviourFilter;
	
	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

    /**
     * Spring configuration
     * 
     * @param behaviourFilter the behaviourFilter to set
     */
    public void setBehaviourFilter(BehaviourFilter behaviourFilter)
    {
        this.behaviourFilter = behaviourFilter;
    }
    
	private static final Map<String, QName> qNameMap = new HashMap<String, QName>();
	private static final ArrayList<String> docTypeValues = new ArrayList<String>();
	private static final Logger log = Logger.getLogger(CreateNewFileDraft.class);
	private final DateFormat formatter = DateFormat.getDateTimeInstance( DateFormat.FULL, 
            DateFormat.FULL, 
            Locale.US);
	private static final SimpleDateFormat sdt = new SimpleDateFormat(
			"MM-dd-yyyy_hh-mm-ss-S-a-zzz");
	// added by skorutla for DE4266
	static {
		docTypeValues.add(ServiceConstants.Cisco_Corporate_Document);
		docTypeValues.add(ServiceConstants.Cisco_Engineering_Document);
		docTypeValues.add(ServiceConstants.Cisco_Finance_Document);
		docTypeValues.add(ServiceConstants.Cisco_General_Document);
		docTypeValues.add(ServiceConstants.Cisco_HR_Document);
		docTypeValues.add(ServiceConstants.Cisco_IT_Document);
		docTypeValues.add(ServiceConstants.Cisco_Legal_Document);
		docTypeValues.add(ServiceConstants.Cisco_Marketing_Document);
		docTypeValues.add(ServiceConstants.Cisco_Operations_Document);
		docTypeValues.add(ServiceConstants.Cisco_Sales_Document);
		docTypeValues.add(ServiceConstants.Cisco_Services_Document);
	}
	// end by skorutla for DE4266
	static {
		qNameMap.put("title", ContentModel.PROP_TITLE);
		qNameMap.put("description", ContentModel.PROP_DESCRIPTION);
		qNameMap.put("docType", CiscoModelConstants.CISCO_DOC_TYPE_PROP);
		qNameMap.put("securityLevel", CiscoModelConstants.CISCO_SECURITY_PROP);
		qNameMap.put("theatre", CiscoModelConstants.CISCO_THEATRE_PROP);
		qNameMap.put("status", CiscoModelConstants.CISCO_DOC_STATUS);
	}

	@Override
	public void execute(final WebScriptRequest req, final WebScriptResponse res) throws IOException {
		String strUser = req.getParameter("user");
		log.error("user param:: " + strUser);
		if (null == strUser || "".equals(strUser.trim())) {
			strUser = registry.getAuthenticationService().getCurrentUserName();
		}

		log.error(formatter.format(new Date()) + "  :: Upload : CURRENT USER:: " + strUser);
		final String user = strUser;

		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<NodeRef>() {
			public NodeRef doWork() throws Exception {
				JSONObject metadataJsonObject = null;
				JSONArray permissionJsonArray = null;
				final JSONObject responseObject = new JSONObject();
				try {
					if(!registry.getAuthorityService().authorityExists(user)) {
						log.error(formatter.format(new Date()) + "  :: Upload error: invalid metadata. ");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_AUTHENTICATION);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("message", "");
						responseObject.put("edcsID", "");
						responseObject.put("error", "Username "+user+" doesn't exist in the system.");
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;
					}
					metadataJsonObject = new JSONObject(req.getParameter("metadata")
							.trim());
					permissionJsonArray = new JSONArray(req.getParameter("permissions")
							.trim());
				} catch (JSONException e2) {
					try {
						log.error(formatter.format(new Date()) + "  :: Upload error: invalid metadata. ");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("message", "");
						responseObject.put("edcsID", "");
						responseObject.put("error", "Malformed metadata JSON object.");
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;
					} catch (JSONException e1) {
						e1.printStackTrace();
						return null;
					}
				}

				String aspects= req.getParameter("aspects");
				try {
					if (metadataJsonObject.length() == 0) {
						log.error(formatter.format(new Date()) + "  :: Upload error: invalid metadata. ");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("message", "");
						responseObject.put("edcsID", "");
						responseObject.put("error", "Metadata cannot be blank.");
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;
					}
					// Added by utmahesh for DE4829
					if(metadataJsonObject.has("docType")){
						//added by skorutla for DE4266	
						String docType = (String) metadataJsonObject.get("docType");
						log.info("docType String:::"+docType);
						if (null == docType || "".equals(docType.trim())) {
							log.error(formatter.format(new Date())
									+ "  :: Upload error: invalid metadata. ");
							res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
							responseObject.put("versionRef", "");
							responseObject.put("versionLabel", "");
							responseObject.put("message", "");
							responseObject.put("edcsID", "");
							responseObject.put("error", "DocType cannot be blank.");
							res.getWriter().write(responseObject.toString());
							res.setContentType("application/json");
							res.getWriter().close();
							return null;
						}
						if (!docTypeValues.contains(docType)) {
							log.error("docType:::"+docType);				
							log.error(formatter.format(new Date())
									+ "  :: Upload error: invalid metadata. ");
							res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
							responseObject.put("versionRef", "");
							responseObject.put("versionLabel", "");
							responseObject.put("edcsID", "");
							responseObject
							.put("docType", docType);

							responseObject.put("message", "");
							responseObject.put("error",
									ErrorStatus.STATUS_MSG_INVALID_METATDATA);
							res.getWriter().write(responseObject.toString());
							res.setContentType("application/json");
							res.getWriter().close();
							return null;
						}	
					}else{
						log.error(formatter.format(new Date()) + "  :: Upload error: invalid metadata. ");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("message", "");
						responseObject.put("edcsID", "");
						responseObject.put("error", "DocType is a Mandatory field");
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;
					}// Closed by utmahesh for DE4829
					//end by skorutla for DE4266
					// Added by utmahesh for DE4833
					if(metadataJsonObject.has("securityLevel")){
					//added by skorutla for DE4267
					String securityLevel = (String) metadataJsonObject.get("securityLevel");
					log.error("securityLevel String:::"+securityLevel);
					log.info("securityLevel String:::"+securityLevel);
					if (null == securityLevel || "".equals(securityLevel.trim())) {
						log.error(formatter.format(new Date())
								+ "  :: Upload error: invalid metadata. ");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("message", "");
						responseObject.put("edcsID", "");
						responseObject.put("error", "SecurityLevel cannot be blank.");
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;
					}
					}else{
						log.error(formatter.format(new Date()) + "  :: Upload error: invalid metadata. ");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("message", "");
						responseObject.put("edcsID", "");
						responseObject.put("error", "Theatre is a Mandatory field");
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;
					}// Closed by utmahesh for DE4833
					// Added by utmahesh for DE4834
					if(metadataJsonObject.has("theatre")){
					String theaterValueString = (String) metadataJsonObject.get("theatre");
					log.info("theaterValue String:::"+theaterValueString);
					if (null == theaterValueString || "".equals(theaterValueString.trim())) {
						log.error(formatter.format(new Date())
								+ "  :: Upload error: invalid metadata. ");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("message", "");
						responseObject.put("edcsID", "");
						responseObject.put("error", "Theatre cannot be blank.");
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;
					}
					}else{
						log.error(formatter.format(new Date()) + "  :: Upload error: invalid metadata. ");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("message", "");
						responseObject.put("edcsID", "");
						responseObject.put("error", "Theatre is a Mandatory field");
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;
					}// Closed by utmahesh for DE4834
					String status = (String) metadataJsonObject.get("status");
					log.info("status String:::"+status);
					if (null == status || "".equals(status.trim())) {
						log.error(formatter.format(new Date())
								+ "  :: Upload error: invalid metadata. ");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("message", "");
						responseObject.put("edcsID", "");
						responseObject.put("error", "Status cannot be blank.");
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;
					}			
					//end by skorutla for DE4267

					String nodeRefString;
					nodeRefString = (String) metadataJsonObject.get("parent");
					log.info(formatter.format(new Date()) + "  :: Upload: parent noderef:: " + nodeRefString);
					if (null == nodeRefString || "".equals(nodeRefString.trim())) {
						log.error(formatter.format(new Date()) + "  :: Upload: parent noderef null. ");
						res.setStatus(ErrorStatus.STATUS_CODE_NULL_NODEREF);
						res.getWriter()
						.write("Parent folder noderef must be provided.");
						res.getWriter().close();
						return null;
					}
					NodeRef parentRef = null;
					parentRef = new NodeRef(nodeRefString);
					if (!registry.getNodeService().exists(parentRef)) {
						log.error(formatter.format(new Date()) + "  :: Upload: parent noderef does not exist.");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_NODEREF);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("message", "");
						responseObject.put("edcsID", "");
						responseObject.put("error",
								"Parent folder noderef doesn't exist.");
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;
					}

					String fileName = (String) metadataJsonObject.get("fileName");
					if (null == fileName) {
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("message", "");
						responseObject.put("edcsID", "");
						responseObject.put("error", "File name cannot be blank.");
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;
					}
					//added by skorutla for DE4753
					if(!fileName.contains(".")){
						log.error("fileName:::"+fileName);
						log.error(formatter.format(new Date())+ "  :: Upload error: invalid metadata. ");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("edcsID", "");
						responseObject.put("message", "");
						responseObject.put("error", "Extension is mandatory for file name.");
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null; 
					}//end by skorutla for DE4753
					
					if (!registry.getPermissionService().hasPermission(parentRef, "Write").equals(AccessStatus.ALLOWED)){
						log.error(formatter.format(new Date()) + "  :: Error while uploading ---- Access Denied");
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_PERMISSION);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("edcsID", "");
						responseObject.put("message", "");
						responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_PERMISSION);
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;
					}
					
					NodeRef nodeRef = uploadFile(registry, fileName, parentRef, metadataJsonObject);

					//Added by veerai for US10103 - start
					JSONObject invalidDataJSON = new JSONObject();
					JSONObject invalidPropertyJSONObject = ServiceUtil.getInvalidMetadataProperties(metadataJsonObject,registry);
					if(invalidPropertyJSONObject.length()>0){
						invalidDataJSON.put("metadata", invalidPropertyJSONObject);	
					}

					if(null!= permissionJsonArray && permissionJsonArray.length()>0){
						JSONArray invalidPermissionJson = ServiceUtil.getInvalidPermission(permissionJsonArray, registry);
						if(invalidPermissionJson.length()>0){
							invalidDataJSON.put("permissions", invalidPermissionJson);	
						}
					}
					if(invalidDataJSON.length()>0){
						log.error(formatter.format(new Date()) + "  :: invalidData :: " + invalidDataJSON.toString());
						res.setStatus(ErrorStatus.STATUS_CODE_INVALID_METADATA);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("edcsID", "");
						responseObject.put("message", "");
						responseObject.put("invalidData", invalidDataJSON);
						responseObject.put("error", ErrorStatus.STATUS_MSG_INVALID_METATDATA);
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;		
					}
					//Added by veerai for US10103 - end
					
					if (null == nodeRef){
						log.error(formatter.format(new Date()) + "  :: Error while uploading ---- UNABLE TO WRITE NODEREF");
						res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("message", "");
						responseObject.put("edcsID", "");
						responseObject.put("error", "Content writing failed.");
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;
					}
					//DISABLING BEHAVIOUR FILTER
					behaviourFilter.disableBehaviour(nodeRef, ContentModel.ASPECT_AUDITABLE);
					try {
						if(aspects!=null){
							setAspects((aspects.trim()).split(","), nodeRef);
						}
						
						boolean propertyWritten = setUploadedFileProperties(nodeRef, metadataJsonObject, user);
						Map<QName, Serializable> propMap = new HashMap<QName, Serializable>();
						propMap.put(qNameMap.get("title"), registry.getNodeService().getProperty(nodeRef, qNameMap.get("title")));
						propMap.put(qNameMap.get("description"), registry.getNodeService().getProperty(nodeRef, qNameMap.get("description")));
						propMap.put(qNameMap.get("docType"), registry.getNodeService().getProperty(nodeRef, qNameMap.get("docType")));
						propMap.put(qNameMap.get("securityLevel"), registry.getNodeService().getProperty(nodeRef, qNameMap.get("securityLevel")));
						propMap.put(qNameMap.get("theatre"), registry.getNodeService().getProperty(nodeRef, qNameMap.get("theatre")));
						propMap.put(qNameMap.get("status"), registry.getNodeService().getProperty(nodeRef, qNameMap.get("status")));
						propMap.put(ContentModel.PROP_CREATOR, registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_CREATOR));
						registry.getVersionService().ensureVersioningEnabled(nodeRef, propMap);

						String versionRef = "";
						if(registry.getVersionService().isVersioned(nodeRef)){
							versionRef = String.valueOf(registry.getVersionService().getCurrentVersion(nodeRef).getFrozenStateNodeRef());
						}
						log.info(formatter.format(new Date()) + "  :: Upload successful. new noderef:: " + nodeRef +"  VersionRef:: " + versionRef );
						
						if (null!= permissionJsonArray && permissionJsonArray.length()>0){
							for(int i = 0 ; i< permissionJsonArray.length(); i++){
								JSONObject permissionJsonObject = (JSONObject) permissionJsonArray.get(i);
								registry.getPermissionService().setPermission(nodeRef, permissionJsonObject.getString("authority"), ServiceConstants.PERMISSION_MAP.get(permissionJsonObject.getString("permission").toLowerCase()), true);
							}
						}

						registry.getCheckOutCheckInService().checkout(nodeRef);
						responseObject.put("nodeRef", String.valueOf(nodeRef));
						responseObject.put("createdBy", String.valueOf(registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_CREATOR)));
						responseObject.put("versionRef", versionRef);
						responseObject.put("edcsID", String.valueOf(registry.getNodeService().getProperty(nodeRef, CiscoModelConstants.PROP_ALF_ID)));
						responseObject.put("fileName", fileName);
						responseObject.put("message", "Successfully uploaded your file.");
						if(propertyWritten){
							responseObject.put("error", "");
						}else{
							responseObject.put("error", "Failed to write at least one of the properties.");
						}

						res.setContentType("application/json");
						res.getWriter().write(responseObject.toString());	
						res.getWriter().close();
						
					} finally {
						//ENABLING BEHAVIOUR FILTER
						behaviourFilter.enableBehaviour(nodeRef, ContentModel.ASPECT_AUDITABLE);
					}

				} catch (Exception e) {
					log.error(formatter.format(new Date()) + "  *UPLOAD SERVICE*: Error from " + this.getClass().getCanonicalName()
							+ ":: \n" + e.fillInStackTrace());
					
					e.printStackTrace();
					res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
					try {
						responseObject.put("versionRef", "");
						responseObject.put("versionLabel", "");
						responseObject.put("message", "");
						responseObject.put("edcsID", "");
						responseObject.put("error", ErrorStatus.STATUS_MSG_FAILURE);
						res.getWriter().write(responseObject.toString());
						res.setContentType("application/json");
						res.getWriter().close();
						return null;
					} catch (JSONException e1) {
						e1.printStackTrace();
						return null;
					}
				}
				return null;
			}
		}, user);
	}

	private void setAspects(String[] arrAspects, NodeRef nodeRef) {
		Set<QName> setAspects = new HashSet<>(registry.getDictionaryService().getAllAspects());
		for (QName aspect : setAspects) {
			for (String aspectName : arrAspects) {
				if (aspect.getLocalName().equals(aspectName))
					try {
						registry.getNodeService().addAspect(nodeRef, aspect, null);
					} catch (Exception e) {
						log.error("UNABLE TO SET ASPECT:: " + aspectName);
					}
			}
		}

	}

	private boolean setUploadedFileProperties(final NodeRef nodeRef, final JSONObject metadataJsonObject, String user) {
		boolean isSuccess = false;
		try {
			if (metadataJsonObject.has("description")) {
				registry.getNodeService().setProperty(nodeRef, qNameMap.get("description"),
						(String) metadataJsonObject.get("description"));
				metadataJsonObject.remove("description");
			} else {
				registry.getNodeService().setProperty(nodeRef, qNameMap.get("description"),
						registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NAME));
				metadataJsonObject.remove("description");
			}
			registry.getNodeService().setProperty(nodeRef, qNameMap.get("docType"),
					(String) metadataJsonObject.get("docType"));
			metadataJsonObject.remove("docType");
			registry.getNodeService().setProperty(nodeRef, qNameMap.get("securityLevel"),
					(String) metadataJsonObject.get("securityLevel"));
			metadataJsonObject.remove("securityLevel");
			registry.getNodeService().setProperty(nodeRef, qNameMap.get("theatre"),
					(String) metadataJsonObject.get("theatre"));
			metadataJsonObject.remove("theatre");
			registry.getNodeService().setProperty(nodeRef, qNameMap.get("status"),
					(String) metadataJsonObject.get("status"));
			metadataJsonObject.remove("status");
			registry.getNodeService().setProperty(nodeRef, ContentModel.PROP_CREATOR, user);
			isSuccess = true;
		} catch (Exception e) {
			isSuccess = false;
		}
		Set<QName> setproperties = new HashSet<>();
		Set<QName> setAspect = registry.getNodeService().getAspects(nodeRef);
		for (QName aspect : setAspect) {
			setproperties.addAll(registry.getDictionaryService().getAspect(aspect).getProperties().keySet());
		}
		for (QName property : setproperties) {
			Iterator<?> keys = metadataJsonObject.keys();
			while (keys.hasNext()) {
				String key = (String) keys.next();
				if (property.getLocalName().equals(key)) {
					try {
						registry.getNodeService().setProperty(nodeRef, property, (String) metadataJsonObject.get(key));
						break;
					} catch (Exception e) {
						log.error("UNABLE TO SET property:: " + key);
					}
				}
			}
		}
		return isSuccess;
	}

	private NodeRef uploadFile(final ServiceRegistry registry, final String fileName, final NodeRef parentRef,
			final JSONObject metadataJsonObject) {

		return registry.getTransactionService().getRetryingTransactionHelper()
				.doInTransaction(new RetryingTransactionHelper.RetryingTransactionCallback<NodeRef>() {
					public NodeRef execute() throws Throwable {
						log.debug("Upload: Executing transaction. File Name: " + fileName);
						NodeRef newNodeRef = null;
						String newFileName = fileName;
						try {
							NodeRef tempNodeRef = registry.getNodeService().getChildByName(parentRef,
									ContentModel.ASSOC_CONTAINS, fileName);
							if (null != tempNodeRef) {
								if (fileName.lastIndexOf(".") > 0) {
									String extensionString = fileName.substring(fileName.lastIndexOf("."));
									newFileName = fileName.substring(0, fileName.lastIndexOf(".")) + "-"
											+ sdt.format(new Date()) + extensionString;
								} else {
									newFileName = fileName.substring(0, fileName.lastIndexOf(".")) + "-"
											+ sdt.format(new Date());
								}

							}
							log.debug("Final File name:: " + newFileName);
							newNodeRef = (registry.getFileFolderService().create(parentRef, newFileName,
									ServiceConstants.TYPE_CISCODOCS)).getNodeRef();
							log.debug("NodeRef:: " + newNodeRef);
							registry.getNodeService().addAspect(newNodeRef, ServiceConstants.ASPECT_CISCOMETADATA,
									null);
							registry.getNodeService().setType(newNodeRef, ServiceConstants.TYPE_CISCODOCS);
							registry.getNodeService().addAspect(newNodeRef, ContentModel.ASPECT_AUDITABLE, null);
							registry.getNodeService().addAspect(newNodeRef, ContentModel.ASPECT_REFERENCEABLE, null);
							String title;
							if (metadataJsonObject.has("title")) {
								title = metadataJsonObject.getString("title");
							} else {
								title = newFileName;
							}
							registry.getNodeService().setProperty(newNodeRef, qNameMap.get("title"), title);
							return newNodeRef;
						} catch (Exception e) {
							log.error("Error while uploading:: \n" + e.fillInStackTrace());
							e.printStackTrace();
							return null;
						}

					}

				}, false, true);
	}
			
}
