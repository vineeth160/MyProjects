package com.cisco.alfresco.dx.cache.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.Security;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import com.cisco.alfresco.edcsng.constants.ApplicationConstants;
import com.cisco.alfresco.edcsng.constants.CiscoApplicationContext;

/**
 * Base utility for encryption related actions.
 *
 * @author kaudutta
 *
 *
 */
public class CryptoUtil {

	private static Logger log = Logger.getLogger(CryptoUtil.class);

	protected static final IvParameterSpec IV = new IvParameterSpec(
			new byte[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });

	private static final byte[] SALT = "24poi5mfvmfvporetpepkgkptrvlfvkgtkptpvvprgtso4kg5"
			.getBytes(StandardCharsets.UTF_8);
	
	private static final String AN_RANGE = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!@#$%^&*()_+";
	private static SecureRandom RND = new SecureRandom();
	
	private static final char[] PASSWORD = "04fm90fmcklfc4r34rrf43r434rclm43".toCharArray();
	private static final byte[] IV_BYTES = "dsf3ec023vt53fdc".getBytes(StandardCharsets.UTF_8);

	private CryptoUtil() {
	}


	public static String encryptString(String message) {
		log.debug("Starting encrypting password.");

		String result = null;
		try {
			Cipher cipher = CacheEncryptionUtil.getCipher(getKey(), IV_BYTES, 1);
			result = Base64.encodeBase64String(cipher.doFinal(message.getBytes(StandardCharsets.UTF_8)));
		} catch (Exception e) {
			log.error(String.format("An Exception occured while encrypting password. %s", new Object[] { e }));
		}
		return result;
	}

	public static String decryptString(String message) {
		log.debug(String.format("Starting decrypting password %s.", new Object[] { message }));

		String result = null;
		try {
			Cipher cipher = CacheEncryptionUtil.getCipher(getKey(), IV_BYTES, 2);
			result = new String(cipher.doFinal(Base64.decodeBase64(message)));
		} catch (Exception e) {
			log.error("An Exception occured while decrypting password.", e);
		}
		return result;
	}

	private static Key getKey() throws Exception {
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
		SecretKey key = keyFactory.generateSecret(new PBEKeySpec(PASSWORD, SALT, 100));
		SecretKey secretKey = new SecretKeySpec(key.getEncoded(), "AES");
		return secretKey;
	}

	/**
	 * Generates a random alphanumeric password of a given char size
	 * 
	 * @return {@link String}
	 */
	private static String generateRandomPassword(int length) {
		StringBuilder sb = new StringBuilder(length);
		for (int i = 0; i < length; i++)
			sb.append(AN_RANGE.charAt(RND.nextInt(AN_RANGE.length())));
		return sb.toString();
	}

	/**
	 * **For future use**
	 * 
	 * Creates a random secret key based on a random password of 128 char size.
	 * 
	 * Password based secret key generation with bouncy castle(Provider:
	 * PBEWITHSHA256AND128BITAES-CBC-BC)
	 * 
	 * @return {@link String}
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeySpecException
	 * @throws NoSuchProviderException
	 */
	public static SecretKey getRandomSecretKey()
			throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchProviderException {
		Security.addProvider(new BouncyCastleProvider());
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBEWITHSHA256AND128BITAES-CBC-BC", "BC");
		SecretKey key = keyFactory.generateSecret(new PBEKeySpec(generateRandomPassword(128).toCharArray(), SALT, 100));
		return new SecretKeySpec(key.getEncoded(), "AES");
	}

	/**
	 * Saves a secret key to the keystore using an unique identifier as alias.
	 * Returns true is save successful.
	 * 
	 * @param alias
	 * @param secretKey
	 * 
	 * @return {@link Boolean}
	 */
	public static boolean saveSecretKey(String alias, SecretKey secretKey, String env) {
		String keyStoreLocation = ApplicationConstants.getValue("keystore.location");
		KeyStore ks = null;
		String KEY = ApplicationConstants.getValue(env + ".keystore.pwd");
		byte[] keystorePwd = CryptoUtil.decryptString(KEY).getBytes();
		char[] password = new String(keystorePwd).toCharArray();
		try (FileInputStream fis = new FileInputStream(keyStoreLocation)) {
			ks = KeyStore.getInstance("JCEKS");
			ks.load(fis, password);
			KeyStore.ProtectionParameter protParam = new KeyStore.PasswordProtection(password);
			KeyStore.SecretKeyEntry skEntry = new KeyStore.SecretKeyEntry(secretKey);
			ks.setEntry(alias, skEntry, protParam);
			return true;
		} catch (FileNotFoundException e) {
			log.error("Unable to read keystore file.", e);
			return false;
		} catch (IOException e) {
			log.error("Unable to read keystore file: IO Exception.", e);
			return false;
		} catch (KeyStoreException e) {
			log.error("Unable to get keystore.", e);
			return false;
		} catch (NoSuchAlgorithmException e) {
			log.error("No such algorithm.", e);
			return false;
		} catch (CertificateException e) {
			log.error("certification exception.", e);
			return false;
		} catch (Exception e) {
			log.error("Generic Exception : ", e);
			return false;
		}
	}

	/**
	 * Fetches a secretkey from keystore by alias.
	 * 
	 * @param alias
	 * 
	 * @return {@link SecretKey}
	 */
	public static SecretKey getSecretKeyFromKS(String alias, String env) {
		log.error("ENVIRONMENT:: " + env);
		String keyStoreLocation = ApplicationConstants.getValue("keystore.location");
		KeyStore ks = null;
		String key = ApplicationConstants.getValue(env + ".keystore.pwd");
		byte[] keystorePwd = CryptoUtil.decryptString(key).getBytes();
		
		char[] password = new String(keystorePwd).toCharArray();
		String aliasKey = ApplicationConstants.getValue(env + ".alias.pwd");
		byte[] aliasPwd = CryptoUtil.decryptString(aliasKey).getBytes();

		char[] aliasPassword = new String(aliasPwd).toCharArray();
		try (FileInputStream fis = new FileInputStream(keyStoreLocation)) {
			ks = KeyStore.getInstance("JCEKS");
			ks.load(fis, password);
			return (SecretKey) ks.getKey(alias, aliasPassword);
		} catch (FileNotFoundException e) {
			log.error("Unable to read keystore file.", e);
			return null;
		} catch (IOException e) {
			log.error("Unable to read keystore file: IO Exception.", e);
			return null;
		} catch (KeyStoreException e) {
			log.error("Unable to get keystore.", e);
			return null;
		} catch (NoSuchAlgorithmException e) {
			log.error("No such algorithm.", e);
			return null;
		} catch (CertificateException e) {
			log.error("certification exception.", e);
			return null;
		} catch (UnrecoverableKeyException e) {
			log.error("Unrecoravable key.", e);
			return null;
		} catch (Exception e) {
			log.error("Generic Exception : ", e);
			return null;
		}
	}
}