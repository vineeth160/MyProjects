package com.cisco.alfresco.dx.cache.service.encryption.data;

import java.io.Serializable;

public class CacheEncryptionData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private byte[] encryptedKeyAsBytes;
	private String masterKeyAlias;

	public byte[] getEncryptedKeyAsBytes() {
		return encryptedKeyAsBytes;
	}

	public void setEncryptedKeyAsBytes(byte[] encryptedKeyAsBytes) {
		this.encryptedKeyAsBytes = encryptedKeyAsBytes;
	}

	public String getMasterKeyAlias() {
		return masterKeyAlias;
	}

	public void setMasterKeyAlias(String masterKeyAlias) {
		this.masterKeyAlias = masterKeyAlias;
	}

}
