package com.cisco.alfresco.dx.cache.service;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;

import javax.crypto.CipherInputStream;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessStatus;
import org.apache.log4j.Logger;
import org.bson.Document;
import org.json.simple.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;
import org.springframework.http.HttpStatus;

import com.cisco.alfresco.dx.cache.service.encryption.EncryptingCacheContentStore;
import com.cisco.alfresco.dx.cache.service.encryption.EncryptingCacheContentWriter;
import com.cisco.alfresco.dx.cache.util.CryptoUtil;
import com.cisco.alfresco.dx.cache.util.MongoDBUtil;
import com.cisco.alfresco.edcsng.constants.ApplicationConstants;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoDatabase;

/**
 * @author kaudutta
 *
 */
public class SyncDownload extends AbstractWebScript {
	private static Logger log = Logger.getLogger(SyncDownload.class);
	private ServiceRegistry registry;

	EncryptingCacheContentStore cacheContentStore = new EncryptingCacheContentStore();
	private String identity = null;
	private String key = null;
	private String mongoDbName = null;
	private String env;

    public void setEnvironment(String sysEnvironment)
    {
    	env = sysEnvironment;
    }
	
	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void execute(WebScriptRequest req, final WebScriptResponse res) throws IOException {
		
		identity = ApplicationConstants.getValue(env + ".mongo.usrname");
		key = ApplicationConstants.getValue(env + ".mongo.pswrd");
		mongoDbName = ApplicationConstants.getValue("mongo.cache.dbname");
		
		final JSONObject jsonObj = new JSONObject();
		String versionRefString = req.getParameter("versionRef");
		String user = req.getParameter("user");
		String location = req.getParameter("geoLoc");
		
		if (versionRefString == null || "".equals(versionRefString.trim()))
	    {
			res.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			jsonObj.put("error", "Blank or null nodeRef");
			res.getWriter().write(jsonObj.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			return;
	    }
		
		if (null == user || "".equals(user.trim())) {
			user = registry.getAuthenticationService().getCurrentUserName();
		}
		
		String nodeRefString = versionRefString;
		if(versionRefString.startsWith("versionStore"))
		{
			nodeRefString = versionRefString.replace("versionStore", "workspace");
		}
		final NodeRef nodeRef = new NodeRef(nodeRefString);
    
		
		String strResponse = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<String>() {
			@Override
			public String doWork() throws Exception {
				
				if (!registry.getNodeService().exists(nodeRef)) {
					return "Noderef"+ nodeRef + "doesn't exist.";
				}
				
				if (!registry.getPermissionService().hasPermission(nodeRef, "Download").equals(AccessStatus.ALLOWED)) {
					return "You do not have permission to download this content on nodeRef " + nodeRef + ".";
				}
				return null;
			}
		}, user);
		
		if(null!=strResponse)
		{
			res.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			jsonObj.put("error", strResponse);
			res.getWriter().write(jsonObj.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			return;
		}
		
		String mongoHost = ApplicationConstants.getValue(env + "." + location + ".mongo.host");
        MongoClientURI uri = new MongoClientURI("mongodb://" + identity.trim() + ":" + URLEncoder.encode(CryptoUtil.decryptString(key).trim(), "UTF-8") + "@" + mongoHost + ":28017/" + mongoDbName.trim());
		try(InputStream in = registry.getContentService().getReader(nodeRef, ContentModel.TYPE_CONTENT).getContentInputStream();
				MongoClient mongo = new MongoClient(uri);) {

	        MongoDatabase db = mongo.getDatabase(mongoDbName);

			EncryptingCacheContentWriter writer = cacheContentStore.getCacheWriter(env);
			Document dbObject = MongoDBUtil.getDBObject(registry, nodeRef, writer.getData());
			CipherInputStream cis = (CipherInputStream) writer.getCipheredStream(in);
			MongoDBUtil.saveFile(db, cis, dbObject, versionRefString);
			
			jsonObj.put("success", "true");
			res.getWriter().write(jsonObj.toString());
			res.setContentType("application/json");
			res.getWriter().close();
		} catch (Exception e) {
			log.error("Download Caching: Storage exception", e);
			res.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			jsonObj.put("error", "Generic exception");
			res.getWriter().write(jsonObj.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			return;
		}
	}

}