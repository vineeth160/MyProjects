package com.cisco.alfresco.dx.cache.service;

import java.io.IOException;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessStatus;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;
import org.springframework.http.HttpStatus;

/**
 * @author kaudutta
 *
 */
public class CheckPermission extends AbstractWebScript {
	private static Logger log = Logger.getLogger(CheckPermission.class);
	private ServiceRegistry registry;

	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}
	@SuppressWarnings("unchecked")
	@Override
	public void execute(WebScriptRequest req, final WebScriptResponse res) throws IOException {
		final JSONObject jsonObj = new JSONObject();
		final String versionRef = req.getParameter("versionRef");
		String user = req.getParameter("user");
		
		if (null == versionRef || "".equals(versionRef.trim())) {
			log.error("Caching: invalid versionRef or NodeRef");
			res.setStatus(HttpStatus.BAD_REQUEST.value());
			jsonObj.put("error", "Blank or null nodeRef");
			res.getWriter().write(jsonObj.toString());
			res.setContentType("application/json");
			res.getWriter().close();
			return;
		}
		
		if (null == user || "".equals(user.trim())) {
			user = registry.getAuthenticationService().getCurrentUserName();
		}
		
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<WebScriptResponse>() {
			@Override
			public WebScriptResponse doWork() throws Exception {
				
				String nodeRefString = versionRef;
				
				if(versionRef.startsWith("versionStore"))
				{
					nodeRefString = versionRef.replace("versionStore", "workspace");
				}
				final NodeRef nodeRef = new NodeRef(nodeRefString);
				
				
				if (!registry.getNodeService().exists(nodeRef)) {
					log.error("Caching: no versionRef/NodeRef");
					res.setStatus(HttpStatus.EXPECTATION_FAILED.value());
					jsonObj.put("error", "Noderef doesn't exist");
					res.getWriter().write(jsonObj.toString());
					res.setContentType("application/json");
					res.getWriter().close();
					return res;
				}
				if (!registry.getPermissionService().hasPermission(nodeRef, "Download").equals(AccessStatus.ALLOWED)) {
					log.error("Caching: No Permission");
					res.setStatus(HttpStatus.UNAUTHORIZED.value());
					jsonObj.put("error", "User doesn't have permission.");
					jsonObj.put("hasPermission", "false");
					res.getWriter().write(jsonObj.toString());
					res.setContentType("application/json");
					res.getWriter().close();
					return res;
				}

				jsonObj.put("versionRef", versionRef);
				if(nodeRefString.indexOf("SpacesStore")>-1)
				{
					jsonObj.put("versionRef", String.valueOf(registry.getVersionService().getCurrentVersion(nodeRef).getFrozenStateNodeRef()));
				}
				
				jsonObj.put("hasPermission", "true");
				res.getWriter().write(jsonObj.toString());
				res.setContentType("application/json");
				res.getWriter().close();
				return res;
				
			}
		}, user);
	}
}