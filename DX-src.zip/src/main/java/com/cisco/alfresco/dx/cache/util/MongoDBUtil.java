package com.cisco.alfresco.dx.cache.util;
 
import java.util.Date;

import javax.crypto.CipherInputStream;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.QName;
import org.bson.BsonString;
import org.bson.BsonValue;
import org.bson.Document;

import com.cisco.alfresco.dx.cache.service.encryption.data.CacheEncryptionData;
import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.model.GridFSUploadOptions;
 
public class MongoDBUtil
{
	public static Document getDBObject(ServiceRegistry registry, NodeRef nodeRef, CacheEncryptionData data) {
    	Document dbObject = new Document();
    	dbObject.put("createdBy", registry.getAuthenticationService().getCurrentUserName());
		dbObject.put("createdDate", new Date());
		dbObject.put("createdTimeMillis", System.currentTimeMillis());
    	dbObject.put("lastAccessedBy", registry.getAuthenticationService().getCurrentUserName());
		dbObject.put("lastAccessDate", new Date());
		dbObject.put("lastAccessedTimeMillis", System.currentTimeMillis());
		dbObject.put("docId", registry.getNodeService().getProperty(nodeRef, CiscoModelConstants.PROP_ALF_ID));
		dbObject.put("fileName", registry.getFileFolderService().getFileInfo(nodeRef).getName());
		dbObject.put("nodeRef", String.valueOf(new NodeRef("workspace://SpacesStore/" + registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NODE_UUID))));
		if(nodeRef.toString().indexOf("version2Store")>-1) 
			dbObject.put("nodeRef", String.valueOf(registry.getNodeService().getProperty(nodeRef, QName.createQName("http://www.alfresco.org/model/versionstore/2.0","frozenNodeRef"))));
		dbObject.put("versionLabel", String.valueOf(registry.getNodeService().getProperty(nodeRef, ContentModel.PROP_VERSION_LABEL)));
		dbObject.put("size", Long.valueOf(registry.getFileFolderService().getFileInfo(nodeRef).getContentData().getSize()));
		dbObject.put("mimeType", registry.getMimetypeService().guessMimetype(registry.getFileFolderService().getFileInfo(nodeRef).getName()));
		//Saving master key and encrypted key in mongo
		dbObject.put("alias", data.getMasterKeyAlias());
		dbObject.put("byteData", data.getEncryptedKeyAsBytes());
        return dbObject;
    }
    
    public static void saveFile(MongoDatabase db, CipherInputStream cis, Document metadata, String versionRefString) {
    	GridFSBucket fsBucket = GridFSBuckets.create(db);
    	GridFSUploadOptions options = new GridFSUploadOptions().metadata(metadata);
    	BsonValue id = new BsonString(versionRefString);
    	fsBucket.uploadFromStream(id, versionRefString, cis, options);
    }
}