package com.cisco.alfresco.dx.cache.service.encryption;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.cisco.alfresco.dx.cache.service.encryption.data.CacheEncryptionData;

import sun.misc.BASE64Decoder;

/**
 * Encrypting content writer for GCS.
 * 
 * @author mumuthar
 *
 */

public class EncryptingCacheContentWriter {
	// password and salt for passwords, IT MUST BE HARDCODED IN PLAIN TEXT HERE.
	private static final char[] PASSWORD = "GCS2018$".toCharArray();

	private static final byte[] SALT = { (byte) 0xde, (byte) 0x33, (byte) 0x10,
			(byte) 0x12, (byte) 0xde, (byte) 0x33, (byte) 0x10, (byte) 0x12, };

	private String keyStoreLocation;
	private String keyStorePassword;
	private byte[] encryptedKey;
	private String[] secretKeys;
	private String[] pwds;
	private String selectedMasterKey;
	private String selectedMasterPwd;
	// master key
	private Cipher mEncipher = null;
	// Symmetric key
	private Cipher symmetricCipher = null;
	private byte[] encoded = null;
	private int totalBytes;
	private CacheEncryptionData data;

	protected EncryptingCacheContentWriter(String keystoreLocation,
			String keystorePassword, String selectedMasterKey,
			String selectedMasterKeyPassword) {
		this.keyStoreLocation = keystoreLocation;
		this.keyStorePassword = keystorePassword;
		this.selectedMasterKey = selectedMasterKey;
		this.selectedMasterPwd = selectedMasterKeyPassword;

		data = new CacheEncryptionData();
		setupEncryption();

	}

	private void setupEncryption() {
		Logger.getRootLogger().debug(
				"In EncryptingCacheContentWriter setupEncryption");
		final IvParameterSpec iv = new IvParameterSpec(new byte[] { 0, 1, 2, 3,
				4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });
		char[] password = null;

		KeyStore ks = null;
		try {
			ks = KeyStore.getInstance("JCEKS");
		} catch (KeyStoreException e1) {
			e1.printStackTrace();
		}
		// get user password and file input stream
		try {
			password = decrypt(keyStorePassword).toCharArray();
		} catch (GeneralSecurityException | IOException e2) {
			Logger.getRootLogger().error(e2);
			e2.printStackTrace();
		}

		java.io.FileInputStream fis = null;
		try {
			fis = new java.io.FileInputStream(this.keyStoreLocation);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			Logger.getRootLogger().error("unbale to read keyStoreFile  " + e);
		}
		try {
			ks.load(fis, password);
		} catch (NoSuchAlgorithmException e1) {
			Logger.getRootLogger().error(e1);
		} catch (CertificateException e1) {
			Logger.getRootLogger().error(e1);
		} catch (IOException e1) {
			Logger.getRootLogger().error(e1);
		}

		SecretKey secret = null;
		try {
			secret = (SecretKey) ks.getKey(selectedMasterKey,
					(decrypt(null)).toCharArray());

		} catch (UnrecoverableKeyException e1) {
			Logger.getRootLogger().error(e1);
		} catch (KeyStoreException e1) {
			Logger.getRootLogger().error(e1);
		} catch (NoSuchAlgorithmException e1) {
			Logger.getRootLogger().error(e1);
		} catch (GeneralSecurityException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		try {
			fis.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		try {
			mEncipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "BC");
		} catch (NoSuchProviderException e) {
			Logger.getRootLogger().error(e);
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			Logger.getRootLogger().error(e);
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			Logger.getRootLogger().error(e);
			e.printStackTrace();
		}
		try {
			mEncipher.init(Cipher.ENCRYPT_MODE, secret, iv);
		} catch (InvalidKeyException e) {
			Logger.getRootLogger().error(e);
			e.printStackTrace();
		} catch (InvalidAlgorithmParameterException e) {
			Logger.getRootLogger().error(e);
			e.printStackTrace();
		}

		KeyGenerator keyGen = null;
		try {
			keyGen = KeyGenerator.getInstance("AES");
		} catch (NoSuchAlgorithmException e) {
			Logger.getRootLogger().error(e);
			e.printStackTrace();
		}
		keyGen.init(256);

		encoded = keyGen.generateKey().getEncoded();

		final SecretKeySpec keySpec = new SecretKeySpec(encoded, "AES");

		try {
			symmetricCipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "BC");
		} catch (NoSuchAlgorithmException | NoSuchProviderException
				| NoSuchPaddingException e) {
			Logger.getRootLogger().error(e);
			e.printStackTrace();
		}

		try {
			symmetricCipher.init(Cipher.ENCRYPT_MODE, keySpec, iv);
		} catch (InvalidKeyException e) {
			Logger.getRootLogger().error(e);
			e.printStackTrace();
		} catch (InvalidAlgorithmParameterException e) {
			Logger.getRootLogger().error(e);
			e.printStackTrace();
		}

		try {
			encryptedKey = mEncipher.doFinal(encoded);
		} catch (IllegalBlockSizeException | BadPaddingException e) {
			Logger.getRootLogger().error(e);
			e.printStackTrace();
		}

		data.setEncryptedKeyAsBytes(encryptedKey);
		data.setMasterKeyAlias(selectedMasterKey);
	}

	public InputStream getCipheredStream(InputStream payLoad) {
		InputStream cis = new CipherInputStream(payLoad, symmetricCipher);
		return cis;
	}

	private String decrypt(String pwd) throws GeneralSecurityException,
			IOException {
		// String encryptedPwd = mkeysPwd.get(selectMKey);
		SecretKeyFactory keyFactory = SecretKeyFactory
				.getInstance("PBEWithMD5AndDES");
		SecretKey key = keyFactory.generateSecret(new PBEKeySpec(PASSWORD));
		Cipher pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");
		pbeCipher
				.init(Cipher.DECRYPT_MODE, key, new PBEParameterSpec(SALT, 20));
		return new String(
				pbeCipher.doFinal(base64Decode(pwd == null ? selectedMasterPwd
						: pwd)), "UTF-8");
	}

	private byte[] base64Decode(String property) throws IOException {
		return new BASE64Decoder().decodeBuffer(property);
	}

	public CacheEncryptionData getData() {
		return data;
	}

	public void setData(CacheEncryptionData data) {
		this.data = data;
	}
}
