package com.cisco.alfresco.dx.cache.util;

import java.security.Key;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;

/**
 * @author kaudutta
 *
 */
public class CacheEncryptionUtil {
	private CacheEncryptionUtil(){}
	public static final int IV_SIZE = 16;

	public static byte[] buildInitializationVector() {
		byte[] iv = new byte[16];
		new SecureRandom().nextBytes(iv);
		return iv;
	}

	public static byte[] buildMessageFromInitializationVectoreAndContent(byte[] iv, byte[] encrypted) {
		byte[] toRet = new byte[encrypted.length + 16];
		System.arraycopy(iv, 0, toRet, 0, iv.length);
		System.arraycopy(encrypted, 0, toRet, 16, encrypted.length);
		return toRet;
	}

	public static byte[] extractInitializationVectorFromMessage(byte[] message) {
		byte[] toRet = new byte[16];
		System.arraycopy(message, 0, toRet, 0, 16);
		return toRet;
	}

	public static byte[] extractEncryptedContentFromMessage(byte[] message) {
		byte[] toRet = new byte[message.length - 16];
		System.arraycopy(message, 16, toRet, 0, toRet.length);
		return toRet;
	}

	public static Cipher getCipher(Key key, byte[] ivBytes, int cipherMode) throws Exception {
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		IvParameterSpec ivParams = new IvParameterSpec(ivBytes);
		cipher.init(cipherMode, key, ivParams);
		return cipher;
	}
}