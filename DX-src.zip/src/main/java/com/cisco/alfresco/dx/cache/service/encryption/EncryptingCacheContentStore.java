package com.cisco.alfresco.dx.cache.service.encryption;

import java.util.Random;

import com.cisco.alfresco.edcsng.constants.ApplicationConstants;
/**
 * Encrypting store for GCS.
 * @author mumuthar
 * 
 * Modified by Kaustav for dx complience
 *
 */

public class EncryptingCacheContentStore {
	
	private String keystoreLocation;
	private String[] secretKeys;
	private String[] pwds;
	private String keystorePwd;
	
	private Random rnd = new Random();
	
	public EncryptingCacheContentWriter getCacheWriter(String env){
		keystoreLocation = ApplicationConstants.getValue("keystore.location");
		secretKeys = ApplicationConstants.getValue(env+".ciscoCache.encryption.secretkeys").split(",");
		pwds = ApplicationConstants.getValue(env+".ciscoCache.encryption.pwds").split(",");
		keystorePwd = ApplicationConstants.getValue(env+".ciscoCache.encryption.keystorePwd");
		
		int rndm = rnd.nextInt(secretKeys.length);
		String selectedMasterKey = secretKeys[rndm];
		String selectedPwd = pwds[rndm];
		EncryptingCacheContentWriter writer = new EncryptingCacheContentWriter(keystoreLocation, keystorePwd, selectedMasterKey, selectedPwd);
		return writer;
	}
	
	public DecryptingCacheContentReader getCacheReader(String masterKey, byte[] symmetricKey, String env){
		keystoreLocation = ApplicationConstants.getValue("keystore.location");
		secretKeys = ApplicationConstants.getValue(env+".ciscoCache.encryption.secretkeys").split(",");
		pwds = ApplicationConstants.getValue(env+".ciscoCache.encryption.pwds").split(",");
		keystorePwd = ApplicationConstants.getValue(env+".ciscoCache.encryption.keystorePwd");
		
		DecryptingCacheContentReader reader = new DecryptingCacheContentReader(keystoreLocation, masterKey, symmetricKey, pwds, keystorePwd);
		return reader;
	}

}
