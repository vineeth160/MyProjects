package com.cisco.alfresco.dx.cache.service.encryption;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.log4j.Logger;
import org.fusesource.hawtbuf.ByteArrayInputStream;

import sun.misc.BASE64Decoder;

/**
 * Decrypting content reader for GCS.
 * @author mumuthar
 *
 */

public class DecryptingCacheContentReader {

	// password and salt for passwords, IT MUST BE HARDCODED IN PLAIN TEXT HERE.
	private static final char[] PASSWORD = "GCS2018$".toCharArray();

	private static final byte[] SALT = { (byte) 0xde, (byte) 0x33, (byte) 0x10,
			(byte) 0x12, (byte) 0xde, (byte) 0x33, (byte) 0x10, (byte) 0x12, };

	private Cipher mDecipher = null;
	private String keyStoreLocation;
	private byte[] symmetricKey;
	private String[] passwords;
	private String keyStorePassword;
	private String mKey;
	// Symmetric key
	private Cipher symmetricCipher = null;

	protected DecryptingCacheContentReader(String keyStoreLocation,
			String masterKey, byte[] symmetricKey, String[] pwds,
			String keystorePwd) {
		this.keyStoreLocation = keyStoreLocation;
		this.symmetricKey = symmetricKey;
		this.passwords = pwds;
		this.keyStorePassword = keystorePwd;
		this.mKey = masterKey;

		try {
			setupDecryption();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void setupDecryption() throws Exception {
		Logger.getRootLogger().debug(
				"In DecryptingCacheContentReader setupDecryption");

		// Initialize secret key first
		SecretKey secret = null;
		KeyStore ks = null;
		try {
			ks = KeyStore.getInstance("JCEKS");
		} catch (KeyStoreException e1) {
			e1.printStackTrace();
			Logger.getRootLogger().error("Unable to get keystore" + e1);
		}
		char[] password = decryptKeyStorePwd(keyStorePassword).toCharArray();
		java.io.FileInputStream fis = null;
		try {
			fis = new java.io.FileInputStream(this.keyStoreLocation);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			Logger.getRootLogger().error("Unable to read keystore file" + e);
		}
		try {
			ks.load(fis, password);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			Logger.getRootLogger().error(e);
		} catch (CertificateException e) {
			e.printStackTrace();
			Logger.getRootLogger().error(e);
		} catch (IOException e) {
			e.printStackTrace();
			Logger.getRootLogger().error(e);
		}
		try {
			fis.close();
		} catch (IOException e1) {
			Logger.getRootLogger().error(e1);
			e1.printStackTrace();
		}
		try {
			secret = (SecretKey) ks.getKey(mKey, decrypt(mKey, ks)
					.toCharArray());
		} catch (UnrecoverableKeyException e1) {
			e1.printStackTrace();
			Logger.getRootLogger().error(e1);
		} catch (KeyStoreException e1) {
			e1.printStackTrace();
			Logger.getRootLogger().error(e1);
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
			Logger.getRootLogger().error(e1);
		}
		try {
			mDecipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "BC");
		} catch (NoSuchProviderException e) {
			e.printStackTrace();
		}

		final IvParameterSpec iv = new IvParameterSpec(new byte[] { 0, 1, 2, 3,
				4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 });

		mDecipher.init(Cipher.DECRYPT_MODE, secret, iv);

		KeyGenerator keyGen = null;
		try {
			keyGen = KeyGenerator.getInstance("AES");
		} catch (NoSuchAlgorithmException e) {
			Logger.getRootLogger().error(e);
			e.printStackTrace();
		}
		keyGen.init(256);

		CipherInputStream cipherInputStream = new CipherInputStream(
				new ByteArrayInputStream(symmetricKey), mDecipher);
		byte[] decrypted = mDecipher.doFinal(symmetricKey);
		final SecretKeySpec keySpec = new SecretKeySpec(decrypted, "AES");
		try {
			symmetricCipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "BC");
		} catch (NoSuchAlgorithmException | NoSuchProviderException
				| NoSuchPaddingException e) {
			e.printStackTrace();
		}

		try {

			symmetricCipher.init(Cipher.DECRYPT_MODE, keySpec, iv);
		} catch (InvalidKeyException e) {
			Logger.getRootLogger().error(e);
			e.printStackTrace();
		}

	}

	public InputStream getDecryptedStream(InputStream payLoad) {
		if (symmetricCipher != null) {
			CipherInputStream cis = new CipherInputStream(payLoad,
					symmetricCipher);
			return cis;
		}
		return null;
	}

	private String decrypt(String selectMKey, KeyStore ks) {
		String pwd = null;
		for (int i = 0; i < passwords.length; i++) {
			SecretKeyFactory keyFactory = null;
			try {
				keyFactory = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
			} catch (NoSuchAlgorithmException e) {
				Logger.getRootLogger().error(e);
			}
			SecretKey key = null;
			try {
				key = keyFactory.generateSecret(new PBEKeySpec(PASSWORD));
			} catch (InvalidKeySpecException e) {
				Logger.getRootLogger().error(e);
			}
			Cipher pbeCipher = null;
			try {
				pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");
			} catch (NoSuchAlgorithmException e) {
				Logger.getRootLogger().error(e);
			} catch (NoSuchPaddingException e) {
				Logger.getRootLogger().error(e);
			}
			try {
				pbeCipher.init(Cipher.DECRYPT_MODE, key, new PBEParameterSpec(
						SALT, 20));
			} catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
				Logger.getRootLogger().error(e);
			}
			try {
				pwd = new String(pbeCipher.doFinal(base64Decode(passwords[i])),
						"UTF-8");
				// see if this is the right password for the selected key
				SecretKey key2 = (SecretKey) ks.getKey(selectMKey,
						pwd.toCharArray());
				if (key2 != null) {
					break;
				}
			} catch (IllegalBlockSizeException | BadPaddingException
					| IOException e) {
				Logger.getRootLogger().error(e);
			} catch (UnrecoverableKeyException e) {
				// Just swallow the exception, as it is expected here.
				// Logger.getRootLogger().error(e);
			} catch (KeyStoreException e) {
				// Just swallow the exception, as it is expected here.
				// Logger.getRootLogger().error(e);
			} catch (NoSuchAlgorithmException e) {
				// Just swallow the exception, as it is expected here.
				// Logger.getRootLogger().error(e);
			}
		}
		return pwd;
	}

	private String decryptKeyStorePwd(String pwd)
			throws GeneralSecurityException, IOException {
		SecretKeyFactory keyFactory = SecretKeyFactory
				.getInstance("PBEWithMD5AndDES");
		SecretKey key = keyFactory.generateSecret(new PBEKeySpec(PASSWORD));
		Cipher pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");
		pbeCipher
				.init(Cipher.DECRYPT_MODE, key, new PBEParameterSpec(SALT, 20));
		return new String(pbeCipher.doFinal(base64Decode(pwd)), "UTF-8");
	}

	private byte[] base64Decode(String property) throws IOException {
		return new BASE64Decoder().decodeBuffer(property);
	}

}
