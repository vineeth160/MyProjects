package com.cisco.alfresco.edcsng.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.security.PersonService;
import org.apache.log4j.Logger;

public class UserPermissionUtil {

	private static final Logger out = Logger
			.getLogger(UserPermissionUtil.class);
	static String AUTHORITY = "authority";
	static String ROLE = "role";
	 private static final String GROUP_IDENTITY ="GROUP_";
	 private static String CISCO_MAILID="@cisco.com";
	 private static final String GROUP_EVERYONE="GROUP_EVERYONE";
	public static List<HashMap<String, String>> getPermissions(NodeRef nodeRef,
			ServiceRegistry serviceRegistry) {

		PermissionService permissionService = serviceRegistry
				.getPermissionService();
		Set<AccessPermission> accessPermissions = permissionService
				.getAllSetPermissions(nodeRef);

		out.info("Inherited Permissions: "
				+ permissionService.getInheritParentPermissions(nodeRef));

		Iterator<AccessPermission> fIterator = accessPermissions.iterator();
		List<HashMap<String, String>> authorities = new ArrayList<HashMap<String, String>>();

		Map<String, String> authority = null;
		String userRole = null;
		Boolean isInheritedValue = null;
		String[] role = null;
		while (fIterator.hasNext()) {
			AccessPermission accessPermission = (AccessPermission) fIterator
					.next();
			if (accessPermission.getAuthorityType() == AuthorityType.USER || accessPermission.getAuthorityType() == AuthorityType.GROUP) {
				out.info("Authority(User): " + accessPermission.getAuthority()
						+ " Permission:  " + accessPermission.getPermission());

				//START: Added by prbadam for defect Site Manager and all other OOTB roles are getting displayed in inherited permissions in Doc Exchange. 
				if (accessPermission.getPermission() != null
						&& accessPermission.getPermission().equals("SiteAdmin")
						|| accessPermission.getPermission().equals("SiteEditor")
						|| accessPermission.getPermission().equals("SiteReader")
						|| accessPermission.getPermission().equals("SiteOwner")
						|| accessPermission.getPermission().equals("SiteManager")
						|| accessPermission.getPermission().equals("SiteViewer")) {
					out.info("inside if authority permissions------" +accessPermission.getPermission());
				} 
				//END: Added by prbadam for defect Site Manager and all other OOTB roles are getting displayed in inherited permissions in Doc Exchange.
				else {
				if(accessPermission.getAuthorityType() == AuthorityType.USER){
				boolean userExistInRepo = serviceRegistry.getPersonService().personExists(accessPermission.getAuthority());
				out.info("userExistInRepo------" +userExistInRepo);
				if(userExistInRepo){
				authority = new HashMap<String, String>();
				authority.put(AUTHORITY, accessPermission.getAuthority());
				isInheritedValue = accessPermission.isInherited();
				out.info("isInheritedValue: " + isInheritedValue);
				authority.put("inherit", isInheritedValue.toString());
				
				userRole = accessPermission.getPermission();
				role = userRole.split("Role");
				authority.put(ROLE, role[0]);
				
				PersonService personService = serviceRegistry
						.getPersonService();
				NodeRef personNode = personService.getPerson(accessPermission
						.getAuthority());
				out.info("Person Propeties:: "
						+ serviceRegistry.getNodeService().getProperties(personNode)
								.get(ContentModel.PROP_ORGANIZATION));
				String company = (String) serviceRegistry.getNodeService()
						.getProperties(personNode).get(ContentModel.PROP_ORGANIZATION);
				authority.put("company", company != null ? company : "");

				String firstname =
				(String) serviceRegistry.getNodeService().getProperties(personNode)
						.get(ContentModel.PROP_FIRSTNAME);
				authority.put("firstname", firstname != null ? firstname : "");

				String email =
				(String) serviceRegistry.getNodeService().getProperties(personNode)
						.get(ContentModel.PROP_EMAIL);
				authority.put("email", email != null ? email : "");
				authority.put("type", "user");
				if (role[0].equals("Admin")) {
					authority.put(ROLE, "Folder Admin");
				}
				out.info("user authority:::" + authority);
				authorities.add((HashMap<String, String>) authority);
				}else{
					out.info("UserId NotExist InRepo ::: " +accessPermission.getAuthority());
				}
				}else if(accessPermission.getAuthorityType() == AuthorityType.GROUP){
					if(accessPermission.getAuthority()!= null && !accessPermission.getAuthority().equalsIgnoreCase(GROUP_EVERYONE)){
					boolean groupExistInRepo=serviceRegistry.getAuthorityService().authorityExists(accessPermission.getAuthority());
					out.info("groupExistInRepo------" +groupExistInRepo);
					if(groupExistInRepo){
					authority = new HashMap<String, String>();
					out.info("Group Name: " + accessPermission.getAuthority());
					authority.put(AUTHORITY, accessPermission.getAuthority());
					
					isInheritedValue = accessPermission.isInherited();
					out.info("Group isInheritedValue: " + isInheritedValue);
					authority.put("inherit", isInheritedValue.toString());
					userRole = accessPermission.getPermission();
					role = userRole.split("Role");
					authority.put(ROLE, role[0]);
					NodeRef groupIdNode=serviceRegistry.getAuthorityService().getAuthorityNodeRef(accessPermission.getAuthority());
					out.info("Group groupIdNode: " + groupIdNode);
					authority.put("company", "");
					String displayName =
					(String) serviceRegistry.getNodeService().getProperties(groupIdNode)
							.get(ContentModel.PROP_AUTHORITY_DISPLAY_NAME);
					out.info("Group Display Name: " + displayName);
					authority.put("firstname", displayName != null ? displayName : "");
					
					String groupId = accessPermission.getAuthority().replaceAll(GROUP_IDENTITY, "");
					out.info("Group groupId: " + groupId);
					String email=groupId.concat(CISCO_MAILID);
					out.info("Group email: " + email);
					authority.put("email", email != null ? email : "");
					authority.put("type", "grouper");
					if (role[0].equals("Admin")) {
						authority.put(ROLE, "Folder Admin");
					}
					out.info("group authority:::" + authority);
					authorities.add((HashMap<String, String>) authority);
					}else{
						out.info("GroupId NotExist InRepo ::: " +accessPermission.getAuthority());
					}
				}
				}
				}
			}
		}
		out.info("authorities:::" + authorities);
		return authorities;
	}

}