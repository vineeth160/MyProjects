package com.cisco.alfresco.edcsng.download;

import org.alfresco.error.AlfrescoRuntimeException;


/**
 * Just a marker exception for the specific type of error event
 * 
 * @author dhshaw
 * 
 */
public class DownloadLimitReachedException extends AlfrescoRuntimeException
{
    public DownloadLimitReachedException(String msgId)
    {
        super(msgId);
    }
}
