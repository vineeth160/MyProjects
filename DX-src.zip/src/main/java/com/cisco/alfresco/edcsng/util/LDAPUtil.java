package com.cisco.alfresco.edcsng.util;

import java.util.Hashtable;
import java.util.StringTokenizer;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.ldap.PagedResultsResponseControl;

import org.apache.log4j.Logger;

import com.sun.jndi.ldap.ctl.PagedResultsControl;


/**
 * @author dhshaw
 */

public class LDAPUtil
{
    private static Logger logger = Logger.getLogger(LDAPUtil.class);
    // private static final String LDAP_HOST =
    // EDCSPropertiesUtil.getEDCSEnvProperties().getProperty(EDCSNGConstants.LDAP_HOST);
    // private static final String LDAP_PORT
    // =EDCSPropertiesUtil.getEDCSEnvProperties().getProperty(EDCSNGConstants.LDAP_PORT);
    private static final String LDAP_USER_SEARCH_BASE = "ou=ccoentities,o=cco.cisco.com";
    private static final String LDAP_USER_SEARCH_FILTER = "uid=";
    private static LdapContext _ctx = null;

    /**
     * to get ManagerId from the LDAP
     * 
     * @param userName
     * @return String
     */
    public static String getManagerId(String userName, String ldapHost, String ldapPort)
    {
        String manager = null;
        try
        {
            String strAttribuleValue = getAttributeValueLdap(userName, "manager", ldapHost, ldapPort);
            StringTokenizer fistSetTokens = new StringTokenizer(strAttribuleValue, ",");
            String strValue = null;

            if (strAttribuleValue != null)
            {
                manager = strAttribuleValue;
                while (fistSetTokens.hasMoreTokens())
                {
                    strValue = fistSetTokens.nextToken();
                    if (strValue.contains(LDAP_USER_SEARCH_FILTER))
                    {
                        manager = strValue;
                        break;
                    }
                }
                logger.info("manager : " + manager);
                if (manager != null && manager.trim().length() > 0)
                {
                    manager = manager.replace(LDAP_USER_SEARCH_FILTER, "");
                }
                logger.info("[" + userName + "] user manager : [" + manager + "]");

                logger.info("In LDAPUtils -->  getUserNameFromLDAP() --END");
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return manager;
    }

    /**
     * to get any attribute from the LDAP
     * 
     * @param userName
     * @param attributeName
     * @return String
     */
    public static String getAttributeValueLdap(String userName, String attributeName, String ldapHost, String ldapPort)
    {
        logger.info("In LDAPUtils -->  getAttributeValueLdap() --START");
        int pageSize = 1000;
        int maxCount = 400;
        byte[] cookie = null;
        String strAttributeValue = null;

        try
        {
            try
            {
                _ctx = getLdapContext(ldapHost, ldapPort);
            }
            catch (Exception dfException)
            {
                logger.info("Problem in initiating LDAP config." + dfException);
                dfException.printStackTrace();
            }
            SearchControls searchCtls = getSearchControls();
            // Request the paged results control
            Control[] ctls = new Control[]
            { new PagedResultsControl(pageSize) };
            _ctx.setRequestControls(ctls);

            // initialize counter to total the results
            int totalResults = 0;

            String searchFilter = LDAP_USER_SEARCH_FILTER + userName;

            // Search for objects using the filter
            do
            {
                NamingEnumeration<SearchResult> results = _ctx.search(LDAP_USER_SEARCH_BASE, searchFilter, searchCtls);

                // loop through the results in each page
                while (results != null && results.hasMoreElements())
                {
                    // Aborts the iteration once the results count reaches
                    // configured max count
                    if (totalResults == maxCount)
                    {
                        // To break outer loop
                        cookie = null;
                        // Breaks the current loop
                        break;
                    }
                    SearchResult sr = (SearchResult) results.next();
                    Attributes attributes = sr.getAttributes();
                    if (attributes.get(attributeName) != null)
                    {
                        strAttributeValue = (String) attributes.get(attributeName).get();
                    }
                    else
                    {
                        strAttributeValue = "";
                    }
                    totalResults++;
                }
                Control[] controls = _ctx.getResponseControls();
                // examine the response controls
                cookie = parseControls(controls);
                // pass the cookie back to the server for the next page
                _ctx.setRequestControls(new Control[]
                { new PagedResultsControl(pageSize, cookie, Control.CRITICAL) });
            }
            while ((cookie != null) && cookie.length != 0);
            logger.info("Total entries: " + totalResults);
        }
        catch (NamingException e)
        {
            logger.info("Paged Search failed." + e);
        }
        catch (java.io.IOException e)
        {
            logger.info("Paged Search failed." + e);
        }
        finally
        {
            if (_ctx != null)
                try
                {
                    _ctx.close();
                }
                catch (NamingException e)
                {
                    logger.info("Paged Search failed." + e);
                }
        }
        logger.info("In LDAPUtils -->  getAttributeValue() --END");
        return strAttributeValue;
    }

    /**
     * Construct Search Controls Scope
     * 
     * @return
     */
    private static SearchControls getSearchControls()
    {
        // Create the search controls
        SearchControls searchCtls = new SearchControls();
        // Specify the search scope
        searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        return searchCtls;
    }

    /**
     * Fetching LDAP Context
     * 
     * @return
     * @throws NamingException
     */

    private static LdapContext getLdapContext(String ldapHost, String ldapPort) throws NamingException
    {
        logger.info("In the method getLdapContext");
        Hashtable<String, String> env = new Hashtable<String, String>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        // set security , note using simple clear text
        // authentication
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        // env.put(Context.SECURITY_PRINCIPAL, adminName);
        env.put("java.naming.ldap.attributes.binary", "objectGUID");
        // connect to my domain controller
        env.put(Context.PROVIDER_URL, "ldap://" + ldapHost + ":" + ldapPort);
        // Create the initial directory context
        try
        {
            return new InitialLdapContext(env, null);
        }
        catch (NamingException e)
        {
            logger.info("NamingException in ldap" + e);
            throw e;
        }
    }

    /**
     * 
     * @param controls
     * @return
     * @throws NamingException
     */
    public static byte[] parseControls(Control[] controls) throws NamingException
    {
        byte[] cookie = null;
        if (controls != null)
        {
            for (int i = 0; i < controls.length; i++)
            {
                if (controls[i] instanceof PagedResultsResponseControl)
                {
                    PagedResultsResponseControl prrc = (PagedResultsResponseControl) controls[i];
                    cookie = prrc.getCookie();
                }
            }
        }
        return (cookie == null) ? new byte[0] : cookie;
    }
}
