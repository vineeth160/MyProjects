package com.cisco.alfresco.edcsng.util;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.alfresco.repo.action.executer.MailActionExecuter;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.action.Action;
import org.alfresco.service.cmr.action.ActionService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;

/**
 * 
 * @author dhshaw
 * 
 */

public class MailUtil
{
    private static Logger log = Logger.getLogger(MailUtil.class);

    /**
     * Sends mail to the user using email template.
     * 
     * @param strFrom
     * @param strTo
     * @param strSubject
     * @param objModel
     * @param objServiceRegistry
     * @param objTemplateNodeRef
     * @return boolean
     */

    public static boolean sendMail(final String strFrom, final String strTo, final String strSubject,
            final Map<String, Serializable> objModel, final ServiceRegistry objServiceRegistry,
            final NodeRef objTemplateNodeRef)
    {
        log.info("sendMail1 start......");
        final ActionService objActionService = objServiceRegistry.getActionService();
        try
        {
            AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
            {
                @Override
                public Object doWork() throws Exception
                {

                    if (null == strTo || 0 == strTo.length())
                    {
                        log.error("couldn't get email address to send mail..");
                        throw new Exception("couldn't get email address to send mail");
                    }
                    if (null == strFrom || 0 == strFrom.length())
                    {
                        log.error("couldn't get sender email address..");
                        throw new Exception("couldn't get sender email address");
                    }
                    // send email message
                    Action objEmailAction = objActionService.createAction(MailActionExecuter.NAME);
                    objEmailAction.setParameterValue(MailActionExecuter.PARAM_TO, strTo);
                    objEmailAction.setParameterValue(MailActionExecuter.PARAM_FROM, strFrom);
                    objEmailAction.setParameterValue(MailActionExecuter.PARAM_SUBJECT, strSubject);

                    objEmailAction.setParameterValue(MailActionExecuter.PARAM_TEMPLATE, objTemplateNodeRef);
                    Map<String, Serializable> objTemplateModel = new HashMap<String, Serializable>();
                    objTemplateModel.put("args", (Serializable) objModel);
                    objEmailAction.setParameterValue(MailActionExecuter.PARAM_TEMPLATE_MODEL,
                        (Serializable) objTemplateModel);
                    objActionService.executeAction(objEmailAction, null);
                    return null;
                }
            }, "admin");
            log.info("sendMail method end...");
        }
        catch (Exception e)
        {
            log.error("EmailUtil Exception while sending mail.." + e);
            return false;
        }
        return true;
    }

    
    /**
	 * Sends mail to the user, cc user using email template and with attachment.
	 *
	 */
	public static boolean sendMail(String mailServer, String from, String[] toMany, String cc,String subject, String messageBody,String fileAttachment) throws Exception {
	    try {
		Properties props = System.getProperties();
		props.put("mail.smtp.host", mailServer);
		Session session = Session.getDefaultInstance(props, null);
		Message message = new MimeMessage(session);
		message.setFrom(new InternetAddress(from));
		//message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
		
		InternetAddress[] addressTo = new InternetAddress[toMany.length];

		for (int i = 0; i < toMany.length; i++)
		{
		    addressTo[i] = new javax.mail.internet.InternetAddress(toMany[i]);
		}
		message.addRecipients(Message.RecipientType.TO, addressTo);
		
		log.info("cc:: "+cc);
		if(cc!=null && !cc.equals("")){
			message.addRecipient(Message.RecipientType.CC, new InternetAddress(cc));
		}
		message.setSubject(subject);
 		MimeBodyPart messageBodyPart = new MimeBodyPart();
		messageBodyPart.setContent(messageBody, "text/html");
		Multipart multipart = new MimeMultipart();
		multipart.addBodyPart(messageBodyPart);
		
		if(fileAttachment != null){
		log.info("FileAttachment != NULL ");
		MimeBodyPart attachmentPart = new MimeBodyPart();
		FileDataSource fileDataSource = new FileDataSource(fileAttachment) {
			@Override
			public String getContentType(){
			    return "application/octet-stream";
			}
		};
		attachmentPart.setDataHandler(new DataHandler(fileDataSource));
		attachmentPart.setFileName(fileDataSource.getName());
		multipart.addBodyPart(attachmentPart);
		}
		log.info("#### Multipart.getCount() = " + multipart.getCount());
		for(int i=0;i<multipart.getCount();i++){
			log.info("Count == " + i);
			BodyPart bodyPart = multipart.getBodyPart(i);
			log.info("BodyPart content " + i + " == " + bodyPart.getContent());
			
		}
		
		message.setContent(multipart);
		Transport.send(message);
		return true;
	    }catch (Exception e) {
	    	log.error("EmailUtil Exception.." + e);
		return false;
			}
	}

	/**
	 * Sends mail to the single user, with cc user using email template and with attachment.
	 *
	 */
	public static boolean sendMail(String mailServer, String from, String to, String cc,String subject, String messageBody,String fileAttachment) throws Exception {
	    try {
		Properties props = System.getProperties();
		props.put("mail.smtp.host", mailServer);
		Session session = Session.getDefaultInstance(props, null);
		Message message = new MimeMessage(session);
		message.setFrom(new InternetAddress(from));
		message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
		log.info("cc:: "+cc);
		if(cc!=null && !cc.equals("")){
			message.addRecipient(Message.RecipientType.CC, new InternetAddress(cc));
		}
		message.setSubject(subject);
 		MimeBodyPart messageBodyPart = new MimeBodyPart();
		messageBodyPart.setContent(messageBody, "text/html");
		Multipart multipart = new MimeMultipart();
		multipart.addBodyPart(messageBodyPart);
		
		if(fileAttachment != null){
		log.info("FileAttachment != NULL ");
		MimeBodyPart attachmentPart = new MimeBodyPart();
		FileDataSource fileDataSource = new FileDataSource(fileAttachment) {
			@Override
			public String getContentType(){
			    return "application/octet-stream";
			}
		};
		attachmentPart.setDataHandler(new DataHandler(fileDataSource));
		attachmentPart.setFileName(fileDataSource.getName());
		multipart.addBodyPart(attachmentPart);
		}
		log.info("#### Multipart.getCount() = " + multipart.getCount());
		for(int i=0;i<multipart.getCount();i++){
			log.info("Count == " + i);
			BodyPart bodyPart = multipart.getBodyPart(i);
			log.info("BodyPart content " + i + " == " + bodyPart.getContent());
			
		}
		
		message.setContent(multipart);
		Transport.send(message);
		return true;
	    }catch (Exception e) {
	    	log.error("EmailUtil Exception.." + e);
		return false;
			}
	}

	
}
