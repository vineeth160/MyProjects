package com.cisco.alfresco.edcsng.util;

import java.io.Reader;
import java.math.BigInteger;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.mybatis.spring.MyBatisSystemException;
import org.apache.log4j.Logger;

/**
 * @author nupparap
 *
 *For postgres db, execute below SQLs
 *
 * CREATE SEQUENCE CISCO_DOCID_SEQ
 * START WITH 1
 *	INCREMENT BY 1
 *	MINVALUE 1
 *	NO MAXVALUE
 *	CACHE 1;
 *	GRANT USAGE, SELECT ON SEQUENCE CISCO_DOCID_SEQ TO alfresco;
 *
 */

public class DocIdGenerator {

	public static Logger log = Logger.getLogger(DocIdGenerator.class);
	private static final String EDCS_ID_PREFIX = "EDCSX-";
	private static final String POSTGRES_DB = "postgresql";
	private static final String ORACLE_DB = "oracle";
	
	private SqlSessionFactory localFactory;
	final static String env = System.getProperty("sys.env");
	private String sql = null;
	private String dbName;
	public SqlSessionFactory getLocalFactory() {
		return localFactory;
	}

	public void setLocalFactory(SqlSessionFactory localFactory) {
		this.localFactory = localFactory;
	}
	
	public String getDbName() {
		return dbName;
	}

	public void setDbName(String dbName) {
		this.dbName = dbName;
	}

	public String getDocIdNextVal() {
	
		SqlSession sqlSession=null;	
		String docId = "";
		try {
			sqlSession=getSqlSession();
			log.info(" DB sqlSession --- >"+ sqlSession);
			log.info(" DB Name --- >"+ dbName);
		
			//docId = EDCS_ID_PREFIX ;
			if(dbName != null && dbName.contains(POSTGRES_DB)) {// assume its developers local env, so use postgres sql
				log.info("Executing postgres.......");	
				/*sql = "SELECT nextval('serial') as nextval";
				log.info("Postgres sql ---- >"+ sql);
				Query query = session.createSQLQuery(sql);
				docId = String.valueOf(((BigInteger) query.uniqueResult()).longValue());*/
				String id=sqlSession.selectOne("docIdNextValPostgress");// added
				
				sqlSession.commit();
				docId=EDCS_ID_PREFIX +id;//added
				log.info("docId ---- >"+ docId);
				sql = "select nextval('CISCO_DOCID_SEQ')";
				
			} else if (dbName != null && dbName.contains(ORACLE_DB)) {
				
				log.info("Executing ORACLE.......");	
				String id;
				/*
				  sql = "select CISCO_DOCID_SEQ.nextval as docId from dual"; 
				  Query query =  session.createSQLQuery(sql).addScalar("docId", Hibernate.BIG_INTEGER); 
				  docId = EDCS_ID_PREFIX + String.valueOf(((BigInteger)query.uniqueResult()).longValue());
				 */
				id =sqlSession.selectOne("docIdNextValOracle");
				
				sqlSession.commit();
				//sqlSession.selectOne(statement)
				docId=EDCS_ID_PREFIX +id;
				log.info("docId ---- >"+ docId);
				
			}
		} catch (MyBatisSystemException e) {
			log.error("Error while executing seq select query--  " + e);
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
		return docId;
	}
	
	private SqlSession getSqlSession(){
		  Reader reader;
		  SqlSession dbSession = null;
		try {
			reader = Resources.getResourceAsReader("sql-processNodes-config.xml");
			localFactory = new SqlSessionFactoryBuilder().build(reader);
			dbSession = localFactory.openSession(); 
			log.info("session>>>>>>"+dbSession);
		} catch (Exception e) {
			log.error("Error getting db session ",e);
		}
			return dbSession;
	  }
}
