/**
 * 
 */
package com.cisco.alfresco.edcsng.constants;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * @author rajatag
 *
 */
public class ApplicationConstants {
	private static final Properties prop = new Properties();

	static{
		try {
			prop.load(ApplicationConstants.class
					.getResourceAsStream("/alfresco/extension/gcProperties/gcs.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static String getValue(String key){
		return prop.getProperty(key);
	}
}