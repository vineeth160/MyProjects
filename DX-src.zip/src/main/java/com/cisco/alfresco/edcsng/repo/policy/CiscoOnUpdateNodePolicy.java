package com.cisco.alfresco.edcsng.repo.policy;

import java.io.Serializable;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.node.NodeServicePolicies;
import org.alfresco.repo.policy.Behaviour;
import org.alfresco.repo.policy.Behaviour.NotificationFrequency;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.policy.JavaBehaviour;
import org.alfresco.repo.policy.PolicyComponent;
import org.alfresco.repo.version.Version2Model;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.cmr.version.VersionService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;


public class CiscoOnUpdateNodePolicy implements NodeServicePolicies.OnUpdatePropertiesPolicy
{

    private static final Logger LOGGER = Logger.getLogger(CiscoOnUpdateNodePolicy.class);
    private static final String CISCO_MODEL_NS = "http://www.cisco.com/model/content/1.0";

    private static final QName QNAME_CISCO_CONTENT_MODEL = QName.createQName(CISCO_MODEL_NS, "ciscodoc");

    // Dependencies
    private NodeService nodeService;
    private VersionService versionService;
    private PolicyComponent policyComponent;
    // Behaviours
    private Behaviour onUpdateProperties;
    private BehaviourFilter policyFilter;

    /**
     * @param nodeService
     *            the node service
     * 
     */
    public NodeService getNodeService()
    {

        return nodeService;

    }

    public PolicyComponent getPolicyComponent()
    {

        return policyComponent;

    }

    public void setVersionService(VersionService versionService)
    {
        this.versionService = versionService;
    }

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    public void setPolicyComponent(PolicyComponent policyComponent)
    {
        this.policyComponent = policyComponent;
    }

    public BehaviourFilter getPolicyFilter()
    {
        return policyFilter;
    }

    public void setPolicyFilter(BehaviourFilter policyFilter)
    {
        this.policyFilter = policyFilter;
    }

    public void init()
    {
        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("--------- CiscoOnUpdateNodePolicy init() method called ---------");
        }

        // Create behaviours
        this.onUpdateProperties = new JavaBehaviour(this, "onUpdateProperties",
                NotificationFrequency.TRANSACTION_COMMIT);

        // Bind behaviours to node policies
        this.policyComponent.bindClassBehaviour(QName.createQName(NamespaceService.ALFRESCO_URI, "onUpdateProperties"),
            QNAME_CISCO_CONTENT_MODEL, this.onUpdateProperties);
    }

    @Override
    public void onUpdateProperties(NodeRef nodeRef, Map<QName, Serializable> before, Map<QName, Serializable> after)
    {

        /**
         * This code should be skipped for Working Copy Nodes.
         */
        // DE2151 STARTS by Deepak
        if (nodeRef == null || !(nodeService.exists(nodeRef))
                || nodeService.hasAspect(nodeRef, ContentModel.ASPECT_WORKING_COPY))
        {

            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug(" OnUpdateProperties Behaviour skipped for NodeRef= " + nodeRef);
            }
            return;
        }
        // DE2151 ENDS by Deepak

        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug(" OnUpdateProperties Behaviour called for NodeRef= " + nodeRef);

            LOGGER.debug(" Before Properties of NodeRef: " + nodeRef + " are:  " + before);

            LOGGER.debug(" After Properties of NodeRef: " + nodeRef + " are:  " + after);
        }

        VersionHistory vh = versionService.getVersionHistory(nodeRef);
        if (vh == null)
        {
            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug(" Version History NOT found for NodeRef= " + nodeRef);
            }
            return;
        }

        // Get the HEAD version
        Version currVersion = vh.getHeadVersion();
        Map<String, Serializable> propsVer = currVersion.getVersionProperties();
        Serializable nodeuuid = propsVer.get(ContentModel.PROP_NODE_UUID.getLocalName());

        String versionStoreStr = versionService.getVersionStoreReference() + "/" + nodeuuid.toString();
        NodeRef versionStoreRef = new NodeRef(versionStoreStr);

        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug(" Current(Head) Version NodeRef is : " + versionStoreRef);
            LOGGER.debug(" Current(Head) Version NodeRef Properties : " + nodeService.getProperties(versionStoreRef));
        }

        /**
         * Current Version Label should be equal to Live Node Version label
         */
        if (after == null || !(currVersion.getVersionLabel().equals(after.get(ContentModel.PROP_VERSION_LABEL))))
        {

            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug(" Current(Head) Version Label:" + versionStoreRef
                        + " and after propMap Version Label are not equal: " + after);
            }
            return;
        }

        try
        {
            /**
             * Disable ASPECT_AUDITABLE behaviour
             */
            policyFilter.disableBehaviour(versionStoreRef, ContentModel.ASPECT_AUDITABLE);

            for (Map.Entry<QName, Serializable> entry : after.entrySet())
            {
                if (!(entry.getKey().toString().contains("node-uuid")))
                {
                    nodeService.setProperty(versionStoreRef, entry.getKey(), entry.getValue());
                }
            }

            nodeService.setProperty(versionStoreRef, ContentModel.PROP_CREATOR, after.get(ContentModel.PROP_CREATOR));
            // DE 1590 - Saranyan - Start 3
            nodeService.setProperty(versionStoreRef, Version2Model.PROP_QNAME_FROZEN_CREATOR,
                after.get(ContentModel.PROP_CREATOR));
            // DE 1590 - Saranyan - End 3
            nodeService.setProperty(versionStoreRef, ContentModel.PROP_MODIFIER, after.get(ContentModel.PROP_MODIFIER));

        }
        finally
        {
            /**
             * Enable ASPECT_AUDITABLE behaviour
             */
            policyFilter.enableBehaviour(versionStoreRef, ContentModel.ASPECT_AUDITABLE);
        }

    }

}
