package com.cisco.alfresco.edcsng.constants;

import org.alfresco.service.namespace.QName;


public interface EDCSNGConstants
{

    // Defining Constants for PAIndividualDeletionReport
    String EDCS_FROM_MAIL_ID = "edcs.ng.from.mail.id";

    // INFOSEC
    String EDCS_INFOSEC_MAX_DOWNLOAD_SUBJECT = "edcs.infosec.max.download.subject";

    // Audit Download Docs Limit
    String DOWNLOAD_COUNT_MAIL_TEMPLATE_PATH = "download.count.mail.template.path";
    String DOWNLOAD_COUNT_DEFAULT_LIMIT = "download.count.default.limit";
    String DOWNLOAD_COUNT_WEBSCRIPT_URL = "download.count.webscript.url";
    String DOWNLOAD_COUNT_USERNAME = "download.count.username";
    String DOWNLOAD_COUNT_PASSWORD = "download.count.password";
    String DOWNLOAD_COUNT_DOCFOLDER_PATH = "download.count.docfolder.path";
    String DOWNLOAD_UNABLE = "download.unable";

    /** Adding an aspect to a node to set "DownloadDocsLimit" status */
    QName PROP_QNAME_DOWNLOAD_LIMIT = QName.createQName(CiscoModelConstants.CISCO_MODEL_URI, "downloadDocCountLimit");
    QName PROP_QNAME_DOWNLOAD_LIMIT_EXP_DATE = QName.createQName(CiscoModelConstants.CISCO_MODEL_URI,
        "downloadDocLimitExpirationDate");
    QName PROP_QNAME_DOWNLOAD_LIMIT_EXCEED_DATE = QName.createQName(CiscoModelConstants.CISCO_MODEL_URI,
        "downloadDocLimitExceededDate");

    // LDAP details
    String LDAP_HOST = "ldap.host";
    String LDAP_PORT = "ldap.port";

    // Antivirus Scanner
    String ANTIVIRUS_ENABLE = "cisco.antivirus.enabled";
    String ANTIVIRUS_EXE = "antivirus.exe";
    String ANTIVIRUS_DELETION_NOTICE_FILE = "antivirus.deletion.notice.file";
    String TEMP_FOLDER_CLEANUP_NOOFDAYS = "temp.folder.cleanup.noofdays";
    String LUCENE_SCAN_SEARCH_QUERY = "lucene.virusscan.searchquery";
    String LUCENE_SEARCH_FOR_DAYS = "lucene.virusscan.fordays";
    String PRCESS_TEMPLATE_FOR_VIRUS = "process.templatepath.for.virus";
    String TEMP_DOWNLOAD_FOLDER = "temp.download.folder";

}
