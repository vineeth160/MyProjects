package com.cisco.alfresco.edcsng.constants;

import org.alfresco.service.namespace.QName;


/**
 * This class should contain all the QNames and URIs for the Cisco models, including the core EDCS NG model, the Sales
 * Enablement models and the workflow models.
 * 
 * @author adschwar
 * 
 */
public interface CiscoModelConstants
{
	final static String MIGRATION_MODEL_URI = "http://www.alfresco.org/model/migration/1.0";
    final static String CISCO_MODEL_URI = "http://www.cisco.com/model/content/1.0";
    final static QName CISCO_MODEL = QName.createQName(CISCO_MODEL_URI, "ciscodoc");
    final static QName CISCO_SECURITY_PROP = QName.createQName(CISCO_MODEL_URI, "security");
    final static QName CISCO_DOC_TYPE_PROP = QName.createQName(CISCO_MODEL_URI, "doctype");
    final static QName CISCO_THEATRE_PROP = QName.createQName(CISCO_MODEL_URI, "theatre");
    final static QName CISCO_DOC_STATUS = QName.createQName(CISCO_MODEL_URI, "status");
    final static QName CISCO_WORKFLOW_STATUS_PROP = QName.createQName(CISCO_MODEL_URI, "workflowStatus");

    final static QName PROP_ALF_ID = QName.createQName(CiscoModelConstants.CISCO_MODEL_URI, "alf_id");
    final static QName PROP_DOC_STATUS = QName.createQName(CiscoModelConstants.CISCO_MODEL_URI, "status");

    final static QName PROP_CS_CANCEL_WF_LOG = QName.createQName(CiscoModelConstants.CISCO_MODEL_URI, "cancelWFLog");
    final static QName MIGRATION_OLD_URL = QName.createQName(MIGRATION_MODEL_URI, "oldUrl");
    //added by mkatnam for donwload count
    public final static QName PROP_CISCO_DOWNLOAD_COUNT = QName.createQName(CISCO_MODEL_URI,"noOfDownloads");

    final static QName CISCO_DX_FOLDER_ASPECT = QName.createQName(CISCO_MODEL_URI,"dxFolderAspect");
    final static QName CISCO_DX_FOLDER_ASSOCIATION=QName.createQName(CiscoModelConstants.CISCO_MODEL_URI, "dxFolderAssoc");
}
