package com.cisco.alfresco.edcsng.repo.copy;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.repo.node.NodeServicePolicies;
import org.alfresco.repo.policy.Behaviour;
import org.alfresco.repo.policy.Behaviour.NotificationFrequency;
import org.alfresco.repo.policy.JavaBehaviour;
import org.alfresco.repo.policy.PolicyComponent;
import org.alfresco.service.cmr.attributes.AttributeService;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.springframework.util.StopWatch;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.edcsng.util.DocIdGenerator;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;


public class CiscoOnCreateNodePolicy implements NodeServicePolicies.OnCreateNodePolicy
{

    private static Logger log = Logger.getLogger(CiscoOnCreateNodePolicy.class);
    // Dependencies
    private NodeService nodeService;
    private AttributeService attributeService;
    private PolicyComponent policyComponent;
    private DocIdGenerator docIdGenBean;
    // Behaviours
    private Behaviour onCreateNode;
    public static final String KEY_ALFID = "alf_id";
    Serializable value = 10000000;
    QName QNAME_CISCO_CONTENT_MODEL;

    /**
     * @param nodeService
     *            the node service
     * 
     */
    public NodeService getNodeService()
    {

        return nodeService;

    }

    public PolicyComponent getPolicyComponent()
    {

        return policyComponent;

    }

    public void setAttributeService(AttributeService attributeService)
    {
        this.attributeService = attributeService;
    }

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    public void setPolicyComponent(PolicyComponent policyComponent)
    {
        this.policyComponent = policyComponent;
    }
 

	public DocIdGenerator getDocIdGenBean() {
		return docIdGenBean;
	}

	public void setDocIdGenBean(DocIdGenerator docIdGenBean) {
		this.docIdGenBean = docIdGenBean;
	}

	public void init()
    {
        log.info("CiscoOnCreateNodePolicy::::");

        // Create behaviours
        this.onCreateNode = new JavaBehaviour(this, "onCreateNode", NotificationFrequency.TRANSACTION_COMMIT);

        // Bind behaviours to node policies
        String CISCO_MODEL_NS = "http://www.cisco.com/model/content/1.0";

        QNAME_CISCO_CONTENT_MODEL = QName.createQName(CISCO_MODEL_NS, "ciscodoc");

        this.policyComponent.bindClassBehaviour(QName.createQName(NamespaceService.ALFRESCO_URI, "onCreateNode"),
            QNAME_CISCO_CONTENT_MODEL, this.onCreateNode);

    }

    
   @Override
    public void onCreateNode(ChildAssociationRef childAssocRef)
    {
	   log.info("method:: onCreateNode() -Start" );
            addAlfrescoId(childAssocRef);
            /**
             * This method will mark documents as vera protected based on the parent folders vera protection aspect
             */
            applyVeraProtectionToDocuments(childAssocRef);
        
    }
   
    public void addAlfrescoId(ChildAssociationRef childAssocRef)
    {

        NodeRef parentNode = childAssocRef.getParentRef(); // getChildRef

         Serializable oldId = Integer.valueOf(0);
        log.info("method:: addAlfrescoId(childAssocRef) - childAssocRef.getChildRef() :" + childAssocRef.getChildRef().toString());
        log.info("method:: addAlfrescoId(childAssocRef) - childAssocRef.getParentRef() :" + parentNode.toString());
        log.info("method:: addAlfrescoId(childAssocRef) - childAssocRef :" + childAssocRef.toString());
        String CISCO_MODEL_NS = "http://www.cisco.com/model/content/1.0";
        QName PROP_QNAME_ALF_ID_PROPERTY = QName.createQName(CISCO_MODEL_NS, "alf_id");

        if(nodeService.exists(childAssocRef.getChildRef())){
        		oldId = nodeService.getProperty(childAssocRef.getChildRef(), PROP_QNAME_ALF_ID_PROPERTY);
        	} else {
        		log.info("Document node id is temporary/working copy/checking in newversion or not found by NodeService. So new Doc id setting is not required");
        	}

        log.info("OLD EDCS ID, if got: " + oldId + " for Node ID:" + childAssocRef.getChildRef().toString());
        
        if (oldId == null || oldId.toString().trim().equals(""))  {
            Serializable alfrescoId = 0;
            log.info("Invoking docID gen Bean");
            StopWatch t1= new StopWatch();
            t1.start();
            alfrescoId = docIdGenBean.getDocIdNextVal();
            t1.stop(); // logger used to monitor docID generation total time taken
            log.info("Total time taken for docID generation(ms): " + alfrescoId +" :"+ t1.getTotalTimeMillis());
            nodeService.setProperty(childAssocRef.getChildRef(), PROP_QNAME_ALF_ID_PROPERTY, alfrescoId);

        }
        //log.error(" After: New EDCS ID: " + nodeService.getProperty(childAssocRef.getChildRef(), PROP_QNAME_ALF_ID_PROPERTY) + " Node ID:" + childAssocRef.getChildRef().toString());
    }
    
    /**
     * 
     * @param childAssocRef
     */
    private void applyVeraProtectionToDocuments(ChildAssociationRef childAssocRef){
    	if(nodeService.exists(childAssocRef.getChildRef())){
    		String applyVeraProtection = (String)nodeService.getProperty(childAssocRef.getParentRef(), ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION);
    		String security = (String)nodeService.getProperty(childAssocRef.getChildRef(), CiscoModelConstants.CISCO_SECURITY_PROP);
    		if((applyVeraProtection != null && applyVeraProtection.equals("All Contents")) || "Cisco Restricted".equals(security)){	    	
    			Map<QName, Serializable> verDocumentProtectionProps = new HashMap<QName, Serializable>(1);
    			verDocumentProtectionProps.put(ExternalSharingConstants.PROP_IS_DOCUMENT_VERA_PROTECTED,true);
    			nodeService.addAspect(childAssocRef.getChildRef(), ExternalSharingConstants.ASPECT_VERA_PROTECTION, verDocumentProtectionProps);
    		}
    	}
    }
}
