package com.cisco.alfresco.edcsng.constants;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;


public class CiscoApplicationContext implements ApplicationContextAware
{

    private static ApplicationContext context;
    private static String environment = "dev";

    public CiscoApplicationContext()
    {
    }

    public static ApplicationContext getApplicationContext()
    {
        return context;
    }

    public static String getEnvironment()
    {
        return environment;
    }

    public void setEnvironment(String sysEnvironment)
    {

        if (sysEnvironment != null && !sysEnvironment.equalsIgnoreCase("${sys.environment}"))
            environment = sysEnvironment;
        System.out.println("--- Setting environment to " + environment);
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException
    {
        context = applicationContext;
    }
}
