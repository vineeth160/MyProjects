package com.cisco.alfresco.edcsng.virusscan.job;

/**
 * 
 * @author dhshaw
 * 
 */

import java.io.File;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.alfresco.error.AlfrescoRuntimeException;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.Path;
import org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.cmr.version.VersionService;
import org.alfresco.util.exec.RuntimeExec;
import org.alfresco.util.exec.RuntimeExec.ExecutionResult;
import org.apache.log4j.Logger;
import org.quartz.JobExecutionContext;
import org.springframework.scheduling.quartz.QuartzJobBean;
import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.edcsng.util.MailUtil;


public class AntivirusExecuter extends QuartzJobBean
{

    public static final Logger LOGGER = Logger.getLogger(AntivirusExecuter.class);

    public static final String VAR_SOURCE = "source";
    private ServiceRegistry serviceRegistry;
    private ContentService contentService;
    private NodeService nodeService;
    private PersonService personService;
    private VersionService versionService;
    private String fromEmail;
    private RuntimeExec command;
    private String searchQuery;
    private String tempFolderDaysClean;
    private String sscanFordays;
    private String templatePath;
    private String antivirusExe;
    private String scanEnable;
    private String tempDownloadFolder;
    private String deletionNoticeFile;

    @Override
    protected void executeInternal(JobExecutionContext arg0)
    {
        LOGGER.error("executeInternal method start...");
        try
        {
            if (scanEnable.equals("true"))
            {
                int searchForDays = Integer.parseInt(sscanFordays);
                String scanDate = doConvertDateFormat(searchForDays, true);
                doSearch(scanDate);
                int intTempCleanDays = Integer.parseInt(tempFolderDaysClean);
                int intCnt = cleanTempFolder(tempDownloadFolder, intTempCleanDays);
                LOGGER.error("cnt:::" + intCnt);
            }
            LOGGER.error("executeInternal method end...");
        }
        catch (Exception e)
        {
            LOGGER.error("ERROR:" + e);
        }
    }

    /**
     * do lucene search of the node_ref modified within scanDate
     * 
     * @param scanDate
     * @return void
     */
    public void doSearch(final String scanDate)
    {
        LOGGER.error("doSearch method start...");
        try
        {
            AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
            {
                @Override
                public Object doWork() throws Exception
                {
                    nodeService = serviceRegistry.getNodeService();
                    versionService = serviceRegistry.getVersionService();
                    LOGGER.error("Query to Execute  is :" + searchQuery + scanDate);
                    NodeRef currentNodeRef = null;
                    List<NodeRef> nodeRefList = EDCSUtil.getNodeRefList(searchQuery + scanDate, serviceRegistry);
                    if (nodeRefList != null)
                    {
                        for (NodeRef nodeRef : nodeRefList)
                        {
                            currentNodeRef = nodeRef;
                            VersionHistory versionHistory = versionService.getVersionHistory(currentNodeRef);
                            if (versionHistory != null)
                            {
                                Collection<Version> collection = versionService
                                        .getVersionHistory(currentNodeRef)
                                            .getAllVersions();
                                for (Version node : collection)
                                {
                                    NodeRef versionNode = node.getFrozenStateNodeRef();
                                    LOGGER.error("FrozenStateNodeRef for scan : " + versionNode);
                                    String strDate = scanDate.substring(1, scanDate.indexOf("T"));
                                    Date objScanDatefrom = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(strDate
                                            + " 00:00:00");
                                    Date objModifiedDate = (Date) nodeService.getProperty(versionNode,
                                        ContentModel.PROP_MODIFIED);
                                    LOGGER.error("objModifiedDate:: " + objModifiedDate);
                                    LOGGER.error("objScanDatefrom:: " + objScanDatefrom);
                                    if (objScanDatefrom.before(objModifiedDate))
                                    {
                                        try
                                        {
                                            doScan(null, versionNode, node);
                                        }
                                        catch (Exception e)
                                        {
                                            LOGGER.error("Exception...." + e);
                                        }
                                    }
                                }
                            }
                            else
                            {
                                try
                                {
                                    LOGGER.error("currentNodeRef for scan : " + currentNodeRef);
                                    doScan(currentNodeRef, null, null);
                                }
                                catch (Exception e)
                                {
                                    LOGGER.error("Exception...." + e);
                                }
                            }
                        }
                    }

                    return null;
                }
            }, "admin");
            LOGGER.error("doSearch method end...");
        }
        catch (InvalidNodeRefException e)
        {
            LOGGER.error("InvalidNodeRefException...." + e);
        }
        catch (Exception e)
        {
            LOGGER.error("Exception...." + e);
        }
    }

    /**
     * Converts to alfresco specific dateformat
     * 
     * @param days
     * @param isMax
     * @return String
     */
    public String doConvertDateFormat(int days, boolean isMax)
    {
        LOGGER.error("doConvertDateFormat method start...");
        Date date = new Date(System.currentTimeMillis() - days * 24L * 3600 * 1000);
        StringBuilder dtFormat = new StringBuilder();
        StringBuilder actualDateObj = null;
        if (isMax)
        {
            dtFormat.append("[" + DefaultTypeConverter.INSTANCE.convert(String.class, date) + " TO ");
            dtFormat.append("NOW");
            dtFormat.append("]");
        }
        else
        {
            dtFormat.append("[MIN TO ");
            dtFormat.append(DefaultTypeConverter.INSTANCE.convert(String.class, date));
            dtFormat.append("]");
        }
        LOGGER.error("dtFormat Date is ----> " + dtFormat.toString());
        String dtFrmtObj = dtFormat.toString();
        int firstTindex = dtFrmtObj.indexOf("T");
        int lastTindex = dtFrmtObj.lastIndexOf("T");

        if (isMax)
        {
            actualDateObj = new StringBuilder();
            actualDateObj.append(dtFrmtObj.substring(0, firstTindex + 1));
            actualDateObj.append("00:00:00");
            actualDateObj.append(dtFrmtObj.substring(lastTindex - 1, dtFrmtObj.length()));
        }
        else
        {
            actualDateObj = new StringBuilder();
            actualDateObj.append(dtFrmtObj.substring(0, lastTindex));
            actualDateObj.append("T00:00:00");
            actualDateObj.append("]");
        }
        LOGGER.error("doConvertDateFormat method end...");
        return actualDateObj.toString();
    }

    /**
     * do the mcafee virus scan of the searched node_ref's. If there is any virus found sending the e-mail notification
     * to the user, deleting the virus infected file and replacing with deletion_notice pdf file
     * 
     * @param currentNodeRef
     * @param versionNode
     * @param version
     * @return void
     */
    public void doScan(final NodeRef currentNodeRef, final NodeRef versionNode, final Version version)
    {
        LOGGER.error("AntivirusExecuter doScan start...");
        try
        {
            contentService = serviceRegistry.getContentService();
            personService = serviceRegistry.getPersonService();
            NodeRef actionedUponNodeRef = null;
            ExecutionResult result = null;
            int exitVal = 0;
            if (currentNodeRef != null)
            {
                actionedUponNodeRef = currentNodeRef;
            }
            else
            {
                actionedUponNodeRef = versionNode;
            }
            LOGGER.error("executeCommand: " + antivirusExe);
            // put content into temp file
            ContentReader reader = contentService.getReader(actionedUponNodeRef, ContentModel.PROP_CONTENT);
            LOGGER.error("ContentReader: " + reader);
            if (reader != null)
            {
                String fileName = (String) nodeService.getProperty(actionedUponNodeRef, ContentModel.PROP_NAME);
                LOGGER.error("AntivirusExecuter fileName: " + fileName);
                if (!tempDownloadFolder.endsWith("/"))
                    tempDownloadFolder = tempDownloadFolder + "/";
                File sourceFile = new File(tempDownloadFolder + "anti_virus_check_" + fileName);
                LOGGER.error("temp folfer path: " + sourceFile.getPath());
                reader.getContent(sourceFile);
                // add the source property
                Map<String, String> properties = new HashMap<String, String>(5);
                properties.put(VAR_SOURCE, sourceFile.getAbsolutePath());
                // execute the transformation command
                try
                {
                    LOGGER.error("AntivirusExecuter inside try...");
                    command = new RuntimeExec();
                    HashMap<String, String> commandMap = new HashMap<String, String>(1);
                    commandMap.put(".*", antivirusExe + " " + sourceFile.getAbsolutePath());
                    command.setCommandMap(commandMap);
                    command.setErrorCodes("1");
                    result = command.execute(properties);
                    exitVal = result.getExitValue();
                    LOGGER.error("AntivirusExecuter result: " + result.toString());
                }
                catch (Exception e)
                {
                    LOGGER.error("AntivirusExecuter ERROR: " + e);
                    throw new AlfrescoRuntimeException("Antivirus check error: \n" + command, e);
                }
                if (!result.getSuccess() || exitVal == 12 || exitVal == 13 || exitVal == 19)
                {
                    // try to get document creator's email address
                    String creatorName = (String) nodeService.getProperty(actionedUponNodeRef,
                        ContentModel.PROP_CREATOR);
                    nodeService.getProperty(actionedUponNodeRef, ContentModel.PROP_TITLE);
                    nodeService.getProperty(actionedUponNodeRef, ContentModel.PROP_DESCRIPTION);
                    nodeService.getProperty(actionedUponNodeRef, ContentModel.PROP_AUTHOR);
                    if (null == creatorName || 0 == creatorName.length())
                    {
                        LOGGER.error("couldn't get creator's name..");
                        throw new Exception("couldn't get creator's name");
                    }
                    NodeRef creator = personService.getPerson(creatorName);
                    if (null == creator)
                    {
                        LOGGER.error("couldn't get creator..");
                        throw new Exception("couldn't get creator");
                    }

                    String creatorEmail = (String) nodeService.getProperty(creator, ContentModel.PROP_EMAIL);
                    if (null == creatorEmail || 0 == creatorEmail.length())
                    {
                        LOGGER.error("couldn't get creator's email address..");
                        throw new Exception("couldn't get creator's email address");
                    }
                    LOGGER.error("creatorEmail::" + creatorEmail);
                    String filePath = null;
                    Path path = nodeService.getPath(actionedUponNodeRef);
                    if (path != null)
                    {
                        filePath = path.toString();
                        filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/application/1.0\\}", "app:");
                        filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/site/1.0\\}", "st:");
                        filePath = filePath.replaceAll("\\{http://www.alfresco.org/model/content/1.0\\}", "cm:");
                        filePath = filePath.substring(0, filePath.lastIndexOf("/") + 1);
                        filePath = filePath.substring(filePath.indexOf("st:sites") + 8);
                    }
                    //sendMail(creatorEmail, fileName, filePath);
                    // delete node
                    LOGGER.error("AntivirusExecuter deleting the node : " + actionedUponNodeRef);
                    LOGGER.error("AntivirusExecuter doScan end...");
                }
            }
        }
        catch (Exception e)
        {
            LOGGER.error("Exception :" + e);
        }
    }

    /**
     * Sending email notification to the document owner using email template
     * 
     * @param strToEmailId
     * @param strSubjectFileName
     * @param strFilePath
     * @return int
     */

    public boolean sendMail(String strToEmailId, String strSubjectFileName, String strFilePath)
    {
        // sending email using template
        try
        {
            Map<String, Serializable> objModel = new HashMap<String, Serializable>();
            objModel.put("filename", strSubjectFileName);
            strSubjectFileName = "Virus found in " + strSubjectFileName;
            if (strFilePath != null)
                objModel.put("message", "File path: " + strFilePath);
            else
                objModel.put("message", "");
            String strTemplatePathQuery = "PATH:\"" + templatePath + "\"";
            LOGGER.error("strTemplatePathQuery :---------->" + strTemplatePathQuery);
            NodeRef objTemplateNodeRef = EDCSUtil.doSearch(strTemplatePathQuery, serviceRegistry);
            LOGGER.error("objTemplateNodeRef :" + objTemplateNodeRef);
            //MailUtil.sendMail(fromEmail, strToEmailId, strSubjectFileName, objModel, serviceRegistry,objTemplateNodeRef);

        }
        catch (Exception e)
        {
            LOGGER.error("Exception while sending email:" + e);
            return false;
        }
        return true;
    }

    /**
     * Get all the files from the temp folder () Defined in prop file as temp_download_folder. then clean the folder
     * 
     * @param pTempfolder
     * @param tempCleanDays
     * @return int
     */
    private int cleanTempFolder(String pTempfolder, int tempCleanDays)
    {
        LOGGER.error("the infectedFldClean method to clean " + pTempfolder);
        int cnt = 0;
        try
        {
            Date dNow = new Date();
            long sentinal = dNow.getTime() - 1000 * 3600 * 24 * tempCleanDays;
            /**
             * Get all the files from the temp folder () Defined in prop file as temp_download_folder. fList : File list
             * of all the files in the folder.
             */
            File folder = new File(pTempfolder);
            File[] fList = folder.listFiles();
            long mtime = 0;
            if (fList != null && fList.length > 0)
            {
                for (int index = 0; index < fList.length; index++)
                {
                    File file = fList[index];
                    mtime = file.lastModified();
                    LOGGER.error("File name:" + file.getName());
                    /**
                     * Delete the file
                     */
                    LOGGER.error(mtime + "--" + sentinal);
                    if (mtime < sentinal)
                    {
                        file.delete();
                        cnt++;
                    }
                }
            }
            else
                LOGGER.error(pTempfolder + " has no files to be deleted");
        }
        catch (Exception e)
        {
            LOGGER.error("Exception in deleting files from temp folder " + pTempfolder);
            LOGGER.error("ERROR", e);
        }
        LOGGER.error("the cleanTempFolder method to clean " + pTempfolder);
        return cnt;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    public String getSearchQuery()
    {
        return searchQuery;
    }

    public void setSearchQuery(String searchQuery)
    {
        this.searchQuery = searchQuery;
    }

    public String getTempFolderDaysClean()
    {
        return tempFolderDaysClean;
    }

    public void setTempFolderDaysClean(String tempFolderDaysClean)
    {
        this.tempFolderDaysClean = tempFolderDaysClean;
    }

    public String getSscanFordays()
    {
        return sscanFordays;
    }

    public void setSscanFordays(String sscanFordays)
    {
        this.sscanFordays = sscanFordays;
    }

    public String getTemplatePath()
    {
        return templatePath;
    }

    public void setTemplatePath(String templatePath)
    {
        this.templatePath = templatePath;
    }

    public String getAntivirusExe()
    {
        return antivirusExe;
    }

    public void setAntivirusExe(String antivirusExe)
    {
        this.antivirusExe = antivirusExe;
    }

    public String getScanEnable()
    {
        return scanEnable;
    }

    public void setScanEnable(String scanEnable)
    {
        this.scanEnable = scanEnable;
    }

    public String getTempDownloadFolder()
    {
        return tempDownloadFolder;
    }

    public void setTempDownloadFolder(String tempDownloadFolder)
    {
        this.tempDownloadFolder = tempDownloadFolder;

    }

    public String getDeletionNoticeFile()
    {
        return deletionNoticeFile;
    }

    public void setDeletionNoticeFile(String deletionNoticeFile)
    {
        this.deletionNoticeFile = deletionNoticeFile;
    }

    public String getFromEmail()
    {
        return fromEmail;
    }

    public void setFromEmail(String fromEmail)
    {
        this.fromEmail = fromEmail;
    }
}
