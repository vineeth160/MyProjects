package com.cisco.alfresco.edcsng.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.LimitBy;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.apache.log4j.Logger;

public class SearchUtil {
	
	static Logger logger = Logger.getLogger(SearchUtil.class);

	 public static List<NodeRef> getNodeRefList(String query, ServiceRegistry registry)
	    {
	    	List<NodeRef> arrNodeRef = null;
			int skipCount = 0;
	    	try{
	    		
	    	while(true){	    		    	
	        SearchParameters sp = new SearchParameters();
	        sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
	        sp.setLanguage(SearchService.LANGUAGE_LUCENE);
	        sp.setMaxItems(200);     
			sp.setSkipCount(skipCount);
	        sp.setQuery(query);
	        ResultSet results = registry.getSearchService().query(sp);

	        if (skipCount == 0)
				arrNodeRef = new ArrayList<NodeRef>();
	        if (null == results || results.length() <= 0)
	        	break;
	        if (results != null && results.length() > 0) {
	        	for (ResultSetRow row : results)
	            {
	                arrNodeRef.add(row.getNodeRef());
	            }
	            results.close();	           
	        }else {
				logger.info("No Search Results found");
				break;
			}
			skipCount += 200;
	    	}
	    	HashSet<NodeRef> searchNodeRefSet = new HashSet<NodeRef>(arrNodeRef);
			arrNodeRef = new ArrayList<NodeRef>(searchNodeRefSet);
	    	}catch (Exception e) {
				logger.error("Exception getNodeRefList : " + e);
			}	        
	        return arrNodeRef;
	    }



public static List<NodeRef> getNodeRefListForUsers(String query, ServiceRegistry registry, final int limit)
{

	List<NodeRef> arrNodeRef = null;
	int skipCount = 0;
	try{
	while(true){	
	arrNodeRef = new ArrayList<NodeRef>();
    SearchParameters sp = new SearchParameters();
    sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
    sp.setLanguage(SearchService.LANGUAGE_LUCENE);
    sp.setMaxItems(200);     
	sp.setSkipCount(skipCount);
    sp.setQuery(query);
    sp.setLimitBy(LimitBy.FINAL_SIZE);
    sp.setLimit(limit);
    ResultSet results = registry.getSearchService().query(sp);
    if (skipCount == 0)
		arrNodeRef = new ArrayList<NodeRef>();
    if (null == results || results.length() <= 0)
    	break;
    if (results != null && results.length() > 0) {
    	for (ResultSetRow row : results)
        {
            arrNodeRef.add(row.getNodeRef());
        }
        results.close();        
    }else {
		 logger.info("No Search Results found");
		break;
	}
	skipCount += 200;
	}
	HashSet<NodeRef> searchNodeRefSet = new HashSet<NodeRef>(arrNodeRef);
	arrNodeRef = new ArrayList<NodeRef>(searchNodeRefSet);
	}catch (Exception e) {
		logger.error("Exception getNodeRefListForUsers : " + e);
	}               
    return arrNodeRef;
}


}