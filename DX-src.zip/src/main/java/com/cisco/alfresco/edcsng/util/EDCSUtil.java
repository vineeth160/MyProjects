/**
 * 
 */
package com.cisco.alfresco.edcsng.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.Path;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.LimitBy;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.ResultSetRow;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


/**
 * @author Kaustav Dutta (kaudutta)
 * 
 */
public class EDCSUtil
{
    private static final Logger LOGGER = Logger.getLogger(EDCSUtil.class);

    private EDCSUtil()
    {
    }

    /**
     * @author Adam returns a *single* NodeRef object after passing a lucene query in String format
     * @param query
     * @param registry
     * @return
     */
    public static NodeRef doSearch(String query, ServiceRegistry registry)
    {
        SearchParameters sp = new SearchParameters();
        sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
        sp.setLanguage(SearchService.LANGUAGE_LUCENE);
        sp.setQuery(query);
        ResultSet results = null;
        try
        {
            results = registry.getSearchService().query(sp);
            // This does lazy eval... should iterate as .length() checks may not
            // be reliable
            for (ResultSetRow row : results)
            {
                return row.getNodeRef();
            }
        }
        finally
        {
            if (results != null)
            {
                results.close();
            }
        }
        return null;
    }

    /**
     * @author kaudutta returns a list of NodeRef object after passing a lucene query in String format
     * @param query
     * @param registry
     * @return
     */
    public static List<NodeRef> getNodeRefList(String query, ServiceRegistry registry)
    {
        SearchParameters sp = new SearchParameters();
        sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
        sp.setLanguage(SearchService.LANGUAGE_LUCENE);
        sp.setQuery(query);
        ResultSet results = registry.getSearchService().query(sp);

        if (null == results || results.length() <= 0)
        {
            return null;
        }

        List<NodeRef> arrNodeRef = new ArrayList<NodeRef>();
        for (ResultSetRow row : results)
        {
            arrNodeRef.add(row.getNodeRef());
        }
        results.close();
        return arrNodeRef;
    }

    /**
     * @author kaudutta returns all users of a noderef in csv foramt
     * @param strNodeRef
     * @param registry
     * @return
     */
    public static String getUserNames(String strNodeRef, ServiceRegistry registry)
    {
        String userName;
        StringBuilder users = new StringBuilder();
        NodeRef nodeRef = new NodeRef(strNodeRef);

        Set<AccessPermission> userSet = registry.getPermissionService().getAllSetPermissions(nodeRef);
        if (null == userSet || userSet.isEmpty())
        {
            return "";
        }

        for (AccessPermission accessPermission : userSet)
        {
            userName = accessPermission.getAuthority();
            if (userName.indexOf("@") == -1)
            {
                users.append(userName).append("@cisco.com").append(" ");
                continue;
            }
            users.append(userName).append(" ");
        }
        users.deleteCharAt(users.lastIndexOf(" "));
        return users.toString();
    }

    /**
     * @author kaudutta returns all users of a noderef in csv foramt
     * @param strNodeRef
     * @param registry
     * @return
     */
    public static String getUserNames(NodeRef nodeRef, ServiceRegistry registry)
    {
        String userName;
        StringBuilder users = new StringBuilder();

        Set<AccessPermission> userSet = registry.getPermissionService().getAllSetPermissions(nodeRef);
        if (null == userSet || userSet.isEmpty())
        {
            return "";
        }

        for (AccessPermission accessPermission : userSet)
        {
            userName = accessPermission.getAuthority();
            if (userName.indexOf("@") == -1)
            {
                users.append(userName).append("@cisco.com").append(" ");
                continue;
            }
            users.append(userName).append(" ");
        }
        users.deleteCharAt(users.lastIndexOf(" "));
        return users.toString();
    }

    /**
     * @author dhshaw returns org.hibernate.SessionFactory
     * @return
     */
    public static SessionFactory getSessionFactory(String url, String uname, String pwd)
    {
        SessionFactory factory = null;
        try
        {
            Configuration cfg = new Configuration();
            cfg.configure();
            System.setProperty("hibernate.connection.url", url);
            System.setProperty("hibernate.connection.username", uname);
            System.setProperty("hibernate.connection.password", pwd);
            cfg.setProperties(System.getProperties());
            factory = cfg.buildSessionFactory();
        }
        catch (Exception ex)
        {
            LOGGER.error("Exception " + ex);
            throw new ExceptionInInitializerError(ex);
        }
        return factory;
    }

    /**
     * Retrieving Primary Path & Latest Version of the document
     * 
     * @param nodeRef
     * @return Map<String,String>
     * @throws Exception
     */
    public static Map<String, String> getPrimaryPath(NodeRef nodeRef, ServiceRegistry serviceRegistry)
    {
        Map<String, String> currentVersionPath = new HashMap<String, String>();
        NodeService nodeService = serviceRegistry.getNodeService();
        PermissionService permissionService = serviceRegistry.getPermissionService();

        // get element Path
        Path path = nodeService.getPath(nodeRef);

        // getting frozenNoderef from versionstore
        NodeRef frozenNoderef = (NodeRef) nodeService.getProperty(nodeRef,
            QName.createQName("http://www.alfresco.org/model/versionstore/2.0", "frozenNodeRef"));

        // By using frozenNoderef of versionstore again hitting Workspace store to get Primary Path & Latest Version
        SearchParameters versionSP = new SearchParameters();

        versionSP.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);

        versionSP.setLanguage(SearchService.LANGUAGE_LUCENE);

        String versionQry = "ID:\"" + frozenNoderef + "\"";

        versionSP.setQuery(versionQry);

        ResultSet results = null;

        try
        {
            results = serviceRegistry.getSearchService().query(versionSP);

            for (ResultSetRow row : results)
            {
                NodeRef currentNodeRef = row.getNodeRef();
                // Getting a Latestversion from a NodeRef
                String latestVersion = (String) nodeService
                        .getProperty(currentNodeRef, ContentModel.PROP_VERSION_LABEL);
                String fileName = (String) nodeService.getProperty(currentNodeRef, ContentModel.PROP_NAME);
                currentVersionPath.put("LatestVersion", latestVersion);
                currentVersionPath.put("FileName", fileName);
                path = nodeService.getPath(currentNodeRef);
            }
        }
        finally
        {
            if (results != null)
            {
                results.close();
            }
        }

        // get element Path as String
        String basePath = path.toDisplayPath(nodeService, permissionService);

        currentVersionPath.put("PrimaryPath", basePath + "/");

        return currentVersionPath;
    }

    /**
     * @author murali returns a list of NodeRef object after passing a lucene query in String format with a limit of
     *         results set as MAX_VALUE
     * @param query
     * @param registry
     * @param limit
     * @return
     */
    public static List<NodeRef> getNodeRefListForUsers(String query, ServiceRegistry registry, final int limit)
    {

        SearchParameters sp = new SearchParameters();
        sp.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
        sp.setLanguage(SearchService.LANGUAGE_LUCENE);
        sp.setQuery(query);
        sp.setLimitBy(LimitBy.FINAL_SIZE);
        sp.setLimit(limit);

        ResultSet results = registry.getSearchService().query(sp);

        if (null == results || results.length() <= 0)
        {
            return null;
        }

        List<NodeRef> arrNodeRef = new ArrayList<NodeRef>();
        for (ResultSetRow row : results)
        {
            arrNodeRef.add(row.getNodeRef());
        }
        results.close();
        return arrNodeRef;
    }

}
