package com.cisco.alfresco.edcsng.download;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.audit.AuditQueryParameters;
import org.alfresco.service.cmr.audit.AuditService.AuditQueryCallback;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter;
import org.alfresco.service.cmr.repository.datatype.TypeConversionException;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;
import org.springframework.extensions.webscripts.servlet.WebScriptServletRequest;
import org.springframework.extensions.webscripts.servlet.WebScriptServletResponse;

import com.cisco.alfresco.edcsng.constants.CiscoApplicationContext;
import com.cisco.alfresco.edcsng.constants.EDCSNGConstants;
import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.edcsng.util.LDAPUtil;
import com.cisco.alfresco.edcsng.util.MailUtil;


public class DownloadCountWebScript extends AbstractWebScript
{
    private static Logger _log = Logger.getLogger(DownloadCountWebScript.class);
    // private String host;
    private String alfrescoURL;
    private ServiceRegistry registry;
    private NodeRef userDownloadObjNoderef;
    // private String webscriptUrl ;
    private String ldapHost;
    private String ldapPort;
    private String defaultDownloadLimit;
    private String emailtemplatePath;
    private String downloadDocNodeFolder;
    private String mailerFromID;
    private String mailerGroup;
    public static final String JSON_KEY_ENTRY_COUNT = "count";
    public static final String JSON_KEY_ENTRIES = "entries";
    public static final String JSON_KEY_ENTRY_ID = "id";
    public static final String JSON_KEY_ENTRY_APPLICATION = "application";
    public static final String JSON_KEY_ENTRY_USER = "user";
    public static final String JSON_KEY_ENTRY_TIME = "time";
    public static final String JSON_KEY_ENTRY_VALUES = "values";

    StoreRef storeRef = StoreRef.STORE_REF_WORKSPACE_SPACESSTORE;
    HttpServletResponse httpRes;

    public void execute(final WebScriptRequest req, final WebScriptResponse res)
    {
        _log.info("In RandomSelectWebScript execute()");
        // dhshaw added for error message
        try
        {
            AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
            {
                @Override
                public Object doWork() throws Exception
                {
                    // Don't send email to the Manager - STARTS - Deepak - on July 23, 2014
                    // String checkUser = null;
                    // String loginUser = ((WebScriptServletRequest) req).getHttpServletRequest().getParameter(
                    // "loggedInUser");
                    //
                    // checkUser = LDAPUtil.getManagerId(loginUser, ldapHost, ldapPort);
                    // if (checkUser != null && !checkUser.equals(""))
                    // {
                    // doDownLoadCount(req, res);
                    // }

                    doDownLoadCount(req, res);
                    // Don't send email to the Manager - ENDS - Deepak - on July 23, 2014

                    return null;
                }
            }, "admin");
        }
        catch (DownloadLimitReachedException e)
        {
            _log.error("DownloadLimitReachedException exception occured... " + e.getMessage());
            e.printStackTrace();
            String strErrMessage = e.getMessage();
            strErrMessage = strErrMessage.substring(strErrMessage.indexOf("You"));
            res.setHeader("ErrorMSG", strErrMessage);
            httpRes.setStatus(4004, strErrMessage);
        }
        catch (Exception e)
        {
            _log.error("Exception exception occured... " + e.getMessage());
            e.printStackTrace();
            res.setHeader("ErrorMSG", "Unable to download the file, please contact your administrator");
            httpRes.setStatus(4004, "Unable to download the file, please contact your administrator");
        }
    }

    /**
     * Do the download count for loggedin user sending the email notification on exceding the limit for the day
     * 
     * @param req
     * @param res
     * @return void
     */
    private void doDownLoadCount(WebScriptRequest req, WebScriptResponse res) throws DownloadLimitReachedException,
            Exception
    {
        _log.info(" In RandomSelectWebScript.doDownLoadCount()");
        int intConfiguredLimit = 0;
        int intDefaultLimit = Integer.parseInt(defaultDownloadLimit);
        String nodePath = req.getParameter("nodeRef");
        NodeRef currentNodeRef = new NodeRef(nodePath);

        Date currDate = new Date();
        DateFormat dateformatter = new SimpleDateFormat("yyyy-MM-dd");
        DateFormat dateTimeformatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

        String toDay = "";
        Date fromTime = new Date();
        Date toTime = new Date();
        try
        {
            toDay = dateformatter.format(currDate);
            fromTime = dateTimeformatter.parse(toDay + "T00:00:00");
            toTime = dateTimeformatter.parse(toDay + "T23:59:59");

        }
        catch (java.text.ParseException e)
        {
            _log.error("Exception ocured while formatting the date ..." + e.getMessage());
        }

        if (!(req instanceof WebScriptServletRequest))
        {
            throw new WebScriptException("Content retrieval must be executed in HTTP Servlet environment");
        }

        HttpServletRequest httpReq = ((WebScriptServletRequest) req).getHttpServletRequest();
        httpRes = ((WebScriptServletResponse) res).getHttpServletResponse();

        String loggedInUser = httpReq.getParameter("loggedInUser");
        // this.host = httpReq.getParameter("host");
        // _log.info("Logged in User HOST::::: " + this.host);

        int intDownloadCount = getAuditQuery(req, loggedInUser, fromTime.getTime(), toTime.getTime());

        // dhshaw added for error message
        String downloadDocQuery = "TYPE:\"cs\\:downloaddoc\" AND @cm\\:name:\"" + loggedInUser + "\" ";
        userDownloadObjNoderef = EDCSUtil.doSearch(downloadDocQuery, registry);

        /**
         * Audit all Cisco Documents - STARTS - Deepak - on July 23, 2014
         */

        // String strSecurityProp = (String) this.registry.getNodeService().getProperty(currentNodeRef,
        // CiscoModelConstants.CISCO_SECURITY_PROP);
        // if (strSecurityProp != null && !strSecurityProp.equalsIgnoreCase("Cisco Public"))
        // {
        if (userDownloadObjNoderef != null)
        {
            intConfiguredLimit = (Integer) registry.getNodeService().getProperty(userDownloadObjNoderef,
                EDCSNGConstants.PROP_QNAME_DOWNLOAD_LIMIT);
            Date objDownloadExpireDate = (Date) registry.getNodeService().getProperty(userDownloadObjNoderef,
                EDCSNGConstants.PROP_QNAME_DOWNLOAD_LIMIT_EXP_DATE);
            Date objToday = new Date();
            if (objDownloadExpireDate.compareTo(objToday) < 0)
            {
                if (intDownloadCount >= intDefaultLimit)
                {
                    registry.getNodeService().setProperty(userDownloadObjNoderef,
                        EDCSNGConstants.PROP_QNAME_DOWNLOAD_LIMIT_EXCEED_DATE, objToday);

                    // Don't send email to the Manager - STARTS - Deepak - on July 23, 2014
                    // sendMail(intDefaultLimit, loggedInUser);
                    // Don't send email to the Manager - ENDS - Deepak - on July 23, 2014

                    throw new DownloadLimitReachedException(
                            "You have exceeded your download limit, please contact your manager to download additional documents.");
                }
            }
            else if (intDownloadCount >= intConfiguredLimit)
            {
                registry.getNodeService().setProperty(userDownloadObjNoderef,
                    EDCSNGConstants.PROP_QNAME_DOWNLOAD_LIMIT_EXCEED_DATE, objToday);

                // Don't send email to the Manager - STARTS - Deepak - on July 23, 2014
                // sendMail(intConfiguredLimit, loggedInUser);
                // Don't send email to the Manager - ENDS - Deepak - on July 23, 2014

                throw new DownloadLimitReachedException(
                        "You have exceeded your download limit, please contact your manager to download additional documents.");
            }
        }
        else if (intDownloadCount >= intDefaultLimit)
        {
            // Don't send email to the Manager - STARTS - Deepak - on July 23, 2014
            // sendMail(intDefaultLimit, loggedInUser);
            // Don't send email to the Manager - ENDS - Deepak - on July 23, 2014

            throw new DownloadLimitReachedException(
                    "You have exceeded your download limit, please contact your manager to download additional documents.");
        }
        // }

    }

    /**
     * sending the email notification on exceding the limit for the day
     * 
     * @param intUserDownloadLimit
     * @param strLoggedInUser
     * @return boolean
     */
    private boolean sendMail(int intUserDownloadLimit, String strLoggedInUser) throws Exception
    {
        _log.info("emailtemplatePath -->" + emailtemplatePath);
        String strManagerID = null;
        if (CiscoApplicationContext.getEnvironment() != null)
        {
            String environment = CiscoApplicationContext.getEnvironment();
            if (environment.equalsIgnoreCase("prod"))
            {
                strManagerID = LDAPUtil.getManagerId(strLoggedInUser, ldapHost, ldapPort);
            }
            else
            {
                strManagerID = mailerGroup;
            }
        }
        else
        {
            strManagerID = LDAPUtil.getManagerId(strLoggedInUser, ldapHost, ldapPort);
        }
        _log.info("strManagerID :---------->" + strManagerID);
        String strSubject = "Reached maximum download count per day";
        Map<String, Serializable> objModel = new HashMap<String, Serializable>();
        String strEditURL = "";
        if (userDownloadObjNoderef != null)
        {
            strEditURL = alfrescoURL + "/share/page/edit-metadata?nodeRef=" + userDownloadObjNoderef.toString();
            objModel.put("editorcreate", "edit");
        }
        else
        {
            _log.info("downloadDocNodeFolder -->" + downloadDocNodeFolder);
            NodeRef objDownloadDocFolder = EDCSUtil.doSearch("PATH:\"" + downloadDocNodeFolder + "\"", registry);
            strEditURL = alfrescoURL + "/share/page/create-content?destination=" + objDownloadDocFolder.toString()
                    + "&itemId=cs:downloaddoc";
            objModel.put("editorcreate", "create");
        }
        _log.info("strEditURL :---------->" + strEditURL);
        objModel.put("editurl", strEditURL);
        objModel.put("userdownloadlimit", intUserDownloadLimit + "");
        objModel.put("loggedinuser", strLoggedInUser);
        String strTemplatePathQuery = "PATH:\"" + emailtemplatePath + "\"";
        _log.info("strTemplatePathQuery :---------->" + strTemplatePathQuery);

        NodeRef objTemplateNodeRef = EDCSUtil.doSearch(strTemplatePathQuery, registry);
        _log.info("objTemplateNodeRef :---------->" + objTemplateNodeRef);
        MailUtil
                .sendMail(mailerFromID, strManagerID + "@cisco.com", strSubject, objModel, registry, objTemplateNodeRef);
        return true;
    }

    /**
     * getting the download count for the logedin user
     * 
     * @param req
     * @param user
     * @paramf romTime
     * @param toTime
     * @return int
     */
    public int getAuditQuery(WebScriptRequest req, String user, long fromTime, long toTime)
    {

        _log.info("getAuditQuery start...");
        int limit = 0;
        final boolean verbose = true;
        // Execute the query
        int intDownloadcount = 0;
        try
        {
            AuditQueryParameters params = new AuditQueryParameters();
            params.setApplicationName("download-report");
            params.setFromTime(fromTime);
            params.setToTime(toTime);
            params.setUser(user);
            final List<Map<String, Object>> entries = new ArrayList<Map<String, Object>>(limit);
            AuditQueryCallback callback = new AuditQueryCallback()
            {
                @Override
                public boolean valuesRequired()
                {
                    return verbose;
                }

                @Override
                public boolean handleAuditEntryError(Long entryId, String errorMsg, Throwable error)
                {
                    return true;
                }

                @Override
                public boolean handleAuditEntry(Long entryId, String applicationName, String user, long time,
                        Map<String, Serializable> values)
                {
                    Map<String, Object> entry = new HashMap<String, Object>(11);
                    entry.put(JSON_KEY_ENTRY_ID, entryId);
                    entry.put(JSON_KEY_ENTRY_APPLICATION, applicationName);
                    if (user != null)
                    {
                        entry.put(JSON_KEY_ENTRY_USER, user);
                    }
                    entry.put(JSON_KEY_ENTRY_TIME, new Date(time));
                    if (values != null)
                    {
                        // Convert values to Strings
                        Map<String, String> valueStrings = new HashMap<String, String>(values.size() * 2);
                        for (Map.Entry<String, Serializable> mapEntry : values.entrySet())
                        {
                            String key = mapEntry.getKey();
                            Serializable value = mapEntry.getValue();
                            try
                            {
                                String valueString = DefaultTypeConverter.INSTANCE.convert(String.class, value);
                                valueStrings.put(key, valueString);
                            }
                            catch (TypeConversionException e)
                            {
                                // Use the toString()
                                valueStrings.put(key, value.toString());
                            }

                        }
                        entry.put(JSON_KEY_ENTRY_VALUES, valueStrings);
                    }
                    entries.add(entry);

                    return true;
                }
            };

            registry.getAuditService().auditQuery(callback, params, limit);
            intDownloadcount = entries.size();
            _log.info("entries.size()::" + intDownloadcount);
        }
        catch (Exception e)
        {
            _log.error("Exception:::" + e);
            e.printStackTrace();
        }

        _log.info("getAuditQuery end...");
        return intDownloadcount;
    }

    public void setServiceRegistry(ServiceRegistry registry)
    {
        this.registry = registry;
    }

    public String getLdapPort()
    {
        return ldapPort;
    }

    public void setLdapPort(String ldapPort)
    {
        this.ldapPort = ldapPort;
    }

    public String getDefaultDownloadLimit()
    {
        return defaultDownloadLimit;
    }

    public void setDefaultDownloadLimit(String defaultDownloadLimit)
    {
        this.defaultDownloadLimit = defaultDownloadLimit;
    }

    public String getEmailtemplatePath()
    {
        return emailtemplatePath;
    }

    public void setEmailtemplatePath(String emailtemplatePath)
    {
        this.emailtemplatePath = emailtemplatePath;
    }

    public String getDownloadDocNodeFolder()
    {
        return downloadDocNodeFolder;
    }

    public void setDownloadDocNodeFolder(String downloadDocNodeFolder)
    {
        this.downloadDocNodeFolder = downloadDocNodeFolder;
    }

    public String getMailerFromID()
    {
        return mailerFromID;
    }

    public void setMailerFromID(String mailerFromID)
    {
        this.mailerFromID = mailerFromID;
    }

    public String getLdapHost()
    {
        return ldapHost;
    }

    public void setLdapHost(String ldapHost)
    {
        this.ldapHost = ldapHost;
    }

    public String getMailerGroup()
    {
        return mailerGroup;
    }

    public void setMailerGroup(String mailerGroup)
    {
        this.mailerGroup = mailerGroup;
    }

    /**
     * @param alfrescoURL
     *            the alfrescoURL to set
     */
    public void setAlfrescoURL(String alfrescoURL)
    {
        this.alfrescoURL = alfrescoURL;
    }

}