package com.cisco.alfresco.edcsng.constants;

public interface CiscoWorkflowConstants
{
    // ACTIONS
    public static final String APPROVE_ACTION = "approve";
    public static final String REJECT_ACTION = "reject";
    public static final String ACCEPT_ACTION = "accept";
    public static final String CANCEL_ACTION = "cancel";

    // Document Status
    public static final String DOCUMENT_APPROVED = "Document Approved";
    public static final String DOCUMENT_REJECTED = "Document Rejected";
    public static final String DOCUMENT_RETURNED_TO_REQUESTER = "Document Returned to Requester";
    public static final String DOCUMENT_RESUBMITTED = "Document Resubmitted";
    public static final String DOCUMENT_CANCELLED = "Document Cancelled";

    // Workflows Status
    public static final String WORKFLOW_STARTED = "Workflow Started";
    public static final String WORKFLOW_CANCELLED = "Workflow Cancelled";

    // MISC
    public static final String NOT_APPLICABLE = "N/A";
}
