package com.cisco.alfresco.ext.workflow;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.repo.action.executer.CiscoMailActionExecuter;
import org.alfresco.repo.action.executer.MailActionExecuter;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.action.Action;
import org.alfresco.service.cmr.action.ActionService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;

/**
 * 
 * @author nabbeher
 *
 */
public class CustomMailAction {

	private static Log logger = LogFactory.getLog(CustomMailAction.class);
	
	public void sendMails(ServiceRegistry serviceRegistry, Map<String, Serializable> args, NodeRef templateRef, String mailSubject, String mailFrom,String mailTo, String shareURL)
	{

		
		try {
			 System.out.println("custom mail called for external sharing....subject:"+mailSubject+"and mailFrom:"+mailFrom+" and mail to:"+mailTo);
			 Logger.getRootLogger().info("ciscoUrl: "+shareURL);
			ActionService actionService = serviceRegistry.getActionService();
			Action mailAction = actionService.createAction("mail");
			mailAction.setParameterValue(MailActionExecuter.PARAM_SUBJECT, mailSubject);        
			mailAction.setParameterValue(MailActionExecuter.PARAM_TO, mailTo);
			//mailAction.setParameterValue(MailActionExecuter.PARAM_FROM, "noreply@cisco.com");
			mailAction.setParameterValue(MailActionExecuter.PARAM_FROM, mailFrom);
			mailAction.setParameterValue(MailActionExecuter.PARAM_TEMPLATE, templateRef);
			Logger.getRootLogger().info("Template ID"+templateRef.getId());
           
		
            Map<String, Serializable> templateModel = new HashMap<String, Serializable>();
			args.put("ciscoUrl", shareURL+"/share");
			templateModel.put("args",(Serializable)args);
			mailAction.setParameterValue(MailActionExecuter.PARAM_TEMPLATE_MODEL,(Serializable)templateModel);
			
			
			actionService.executeAction(mailAction, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void sendMails(ServiceRegistry serviceRegistry, Map<String, Serializable> args, NodeRef templateRef, String mailSubject,String mailFrom, String mailTo,  List<String>mailCc, String shareURL)
	{
		try {
			 System.out.println("custom mail called for external sharing....subject:"+mailSubject+"and mailFrom:"+mailFrom+"and mail to:"+mailTo+ "and mail CC:"+ mailCc.toString());
			 Logger.getRootLogger().info("ciscoUrl: "+shareURL);
			ActionService actionService = serviceRegistry.getActionService();
			Action mailAction = actionService.createAction("mail");
			mailAction.setParameterValue(MailActionExecuter.PARAM_SUBJECT, mailSubject);        
			mailAction.setParameterValue(MailActionExecuter.PARAM_TO, mailTo);
			mailAction.setParameterValue(MailActionExecuter.PARAM_FROM, mailFrom);
			if(mailCc!=null){
				mailAction.setParameterValue(CiscoMailActionExecuter.PARAM_CC, (Serializable)mailCc);
			}
			mailAction.setParameterValue(MailActionExecuter.PARAM_TEMPLATE, templateRef);
			Logger.getRootLogger().info("Template ID"+templateRef.getId());
            Map<String, Serializable> templateModel = new HashMap<String, Serializable>();
			args.put("ciscoUrl", shareURL+"/share");
			templateModel.put("args",(Serializable)args);
			mailAction.setParameterValue(MailActionExecuter.PARAM_TEMPLATE_MODEL,(Serializable)templateModel);
			actionService.executeAction(mailAction, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	
	public void sendMails(ServiceRegistry serviceRegistry, Map<String, Object> args, String shareURL){
		
		try {
			System.out.println("custom mail called....");
			
			ActionService actionService = serviceRegistry.getActionService();
			Action mailAction = actionService.createAction("mail");
			mailAction.setParameterValue(MailActionExecuter.PARAM_SUBJECT, (String)args.get("subject"));        
			mailAction.setParameterValue(MailActionExecuter.PARAM_TO, (String)args.get("to"));
			mailAction.setParameterValue(MailActionExecuter.PARAM_FROM, "noreply@cisco.com");
			
			String templateConditionalPath = "PATH:\""+(String)args.get("templatePath")+"//*\" AND "+
											"TYPE:cm\\:content AND @cm\\:name:\""+(String)args.get("templateName")+"\"" ;
			
			Logger.getRootLogger().info("LUCENE QRY: "+templateConditionalPath);
			
			ResultSet resultSet = serviceRegistry.getSearchService().query(new StoreRef(StoreRef.PROTOCOL_WORKSPACE, "SpacesStore"), SearchService.LANGUAGE_LUCENE, templateConditionalPath);
			if (resultSet.length()==0){
				logger.error("Template "+ templateConditionalPath+" not found.");
				return;
			}
			NodeRef template = resultSet.getNodeRef(0);
			mailAction.setParameterValue(MailActionExecuter.PARAM_TEMPLATE, template);
			Logger.getRootLogger().info("Template ID"+template.getId());
			
			
            Logger.getRootLogger().info("ciscoUrl: "+shareURL);
        
			//workflowId, docTitle, wfInitiator, 
			// Define parameters for the model (set fields in the ftl like : args.workflowTitle)
			Map<String, Serializable> templateArgs = new HashMap<String, Serializable>();
			templateArgs.put("bomTitle",(Serializable)args.get("bomTitle").toString());
			templateArgs.put("docTitle",(Serializable)args.get("docTitle").toString());
            templateArgs.put("ciscoUrl", shareURL+"/share");			
			Map<String, Serializable> templateModel = new HashMap<String, Serializable>();
			templateModel.put("args",(Serializable)templateArgs);
			mailAction.setParameterValue(MailActionExecuter.PARAM_TEMPLATE_MODEL,(Serializable)templateModel);
			
			actionService.executeAction(mailAction, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
