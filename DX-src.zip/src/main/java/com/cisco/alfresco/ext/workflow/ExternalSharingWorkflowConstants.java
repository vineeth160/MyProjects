package com.cisco.alfresco.ext.workflow;

import org.alfresco.service.namespace.QName;

public  class ExternalSharingWorkflowConstants {
	
public static String REVIEW_CREATE_TEMPLATE="review$create";
public static String REVIEW_APPROVE_TEMPLATE="review$accept";
public static String REVIEW_REJECT_TEMPLATE="review$reject";
public static String REVIEW_RESUBMIT_TEMPLATE="review$resubmit";
public static String INITIATOR_APPROVE_REJECT_TEMPLATE="initiator$acceptreject";
public static String REVIEW_CANCEL_TEMPLATE="review$cancel";
public static QName PROP_QNAME_STATUS = QName.createQName("http://www.cisco.com/model/content/1.0", "status");
public static QName PROP_QNAME_WORKFLOW_STATUS = QName.createQName("http://www.cisco.com/model/content/1.0", "workflowStatus");
public static final String APPROVED = "Approved";
public static final String REJECTED = "Rejected";
public static final String CANCELLED = "Cancelled";
public static final String SUBMITTED_FOR_APPROVAL = "Submitted for Approval";
public static final String WORKFLOW_IN_PROGRESS = "In-Progress";
public static final String WORKFLOW_COMPLETED = "Complete";

}
