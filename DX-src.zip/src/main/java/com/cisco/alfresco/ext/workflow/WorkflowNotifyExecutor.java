package com.cisco.alfresco.ext.workflow;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.activiti.engine.delegate.DelegateTask;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.workflow.WorkflowConstants;
import org.alfresco.repo.workflow.WorkflowNotificationUtils;
import org.alfresco.repo.workflow.activiti.ActivitiScriptNode;
import org.alfresco.repo.workflow.activiti.tasklistener.ScriptTaskListener;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * @author rajbaska nathammi
 * Send Notify Emails based on user events for External
 *
 */
public class WorkflowNotifyExecutor extends ScriptTaskListener{

	private static Log logger = LogFactory.getLog(WorkflowNotifyExecutor.class);
	
	private String templateName;
	private String ftlLocation;
	private  String shareURL;
	private String contextName;
	private String titleURL; 
	
	public void setContextName(String contextName) {
		this.contextName = contextName;
	}

	public void setShareURL(String shareURL) {
		this.shareURL = shareURL;
	}
	public String getFtlLocation() {
		return ftlLocation;
	}
	public void setFtlLocation(String ftlLocation) {
		this.ftlLocation = ftlLocation;
	}
	public String getTemplateName() {
		return templateName;
	}
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
	private ServiceRegistry serviceRegistry;

	public String getTitleURL() {
		return titleURL;
	}

	public void setTitleURL(String titleURL) {
		this.titleURL = titleURL;
	}
	
	/**
	 * @param task object passed by Activiti engine
	 * Override method only
	 */
	@Override
	public void notify(DelegateTask delegateTask) {
		super.notify();

	}

	/**
	 * To Get Workflow Document Title Details
	 */
	private String getWorkflowDocumentTitle(List<NodeRef> wfAttacheddocuments)
	{
		logger.info("Get Workflow Document Title Details");
		String docTitle = "";
		String docName = "";
		try{
		if(wfAttacheddocuments.size()!=0){
		NodeRef nodeRef = wfAttacheddocuments.get(0);
		docTitle = (String)serviceRegistry.getNodeService().getProperties(nodeRef).get(ContentModel.PROP_TITLE);
		docName =(String)serviceRegistry.getNodeService().getProperties(nodeRef).get(ContentModel.PROP_NAME);
		 if(docTitle == null || docTitle.equals("")){
         	docTitle = docName;
         	}
		}else {
			logger.info("No Workflow Attacements are found : ");
		}
		} catch(Exception e){
			logger.error("Document Title Details Exception : " + e.getMessage());
		}
		return docTitle;
	}
	
	
	/**
	 * To Get Workflow Document version Details
	 */
	private String getWorkflowDocumentVersion(List<NodeRef> wfAttacheddocuments)
	{
		logger.info("Get Workflow Document version Details");
		String versionLabel="";
		try{
		if(wfAttacheddocuments.size()!=0){
		NodeRef nodeRef = wfAttacheddocuments.get(0);
		versionLabel=(String)serviceRegistry.getNodeService().getProperties(nodeRef).get(ContentModel.PROP_VERSION_LABEL);
		versionLabel=versionLabel!=null? versionLabel: "1.0";
		}else {
			logger.info("No Workflow Attacements are found : ");
		}
		} catch(Exception e){
			logger.error("Document Version Details Exception : " + e.getMessage());
		}
		return versionLabel;
	}

	/**
	 * To Get Person Email Details
	 */
	private String getEmail(String userName)
	{
		NodeRef personNodeRef = serviceRegistry.getPersonService().getPerson(userName,false);

		return (String)serviceRegistry.getNodeService().getProperty(personNodeRef, ContentModel.PROP_EMAIL);
	}

	/**
	 * To Get Person Full Name Details
	 */
	private String getFullName(String assignee){
		String fullName = "";
		NodeRef personNode = serviceRegistry.getPersonService().getPerson(assignee, false);
		if(personNode == null)
			return fullName;
		fullName = ((String)serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_FIRSTNAME)==null?"":(String)serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_FIRSTNAME)) +" "+
		((String)serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_FIRSTNAME)==null?"":(String)serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_LASTNAME));     

		return fullName;
	}


	/**
	 * 
	 * @param serviceRegistry
	 * Set all the attachment noderefs to the list
	 * @return 
	 */
	private List<NodeRef> getAllwfAttachments( DelegateTask task)
	{
		logger.info("Getting the WF Attachments");
		List<NodeRef> wfAttacheddocuments = new ArrayList<NodeRef>();
		ActivitiScriptNode scriptNode = (ActivitiScriptNode)task.getExecution().getVariable(WorkflowNotificationUtils.PROP_PACKAGE);
		NodeRef packagenode = scriptNode.getNodeRef();

		if(serviceRegistry==null)
			serviceRegistry = super.getServiceRegistry();;

			if(serviceRegistry.getNodeService().getChildAssocs(packagenode) != null)
			{
				NodeRef docRef = null;
				for(int i =0 ; i < serviceRegistry.getNodeService().getChildAssocs(packagenode).size(); i++)
				{
					docRef =serviceRegistry.getNodeService().getChildAssocs(packagenode).get(i).getChildRef();
					wfAttacheddocuments.add(docRef);
				}
			}
			logger.info("Got the WF Attachments"+wfAttacheddocuments.size());
			
			return wfAttacheddocuments;
	}

	/**
	 * For External Sharing Mail Notification
	 */
	@SuppressWarnings("unchecked")
	public void notifyEmail(DelegateTask task, String eventName, String sendMail, String mailSubject, String mailReciverType)
	{
		logger.info("EXTERNAL SHARING SENDING EMAIL FOR EVENTNAME:"+eventName);
		String subject = "";
		String wfInitiator=null;
		String wfInitiatorFullName=null;
		List<String> mailCc=null;
		String taskAssignee=null;
		String docTitle = "";
		String versionLabel="";
		List<NodeRef> wfAttacheddocuments=new ArrayList<NodeRef>();
		HashMap<String, Object> workflowVariables = new HashMap<String, Object>();
		Date currentDate = new Date();
    	String year = new SimpleDateFormat("yyyy").format(currentDate); 
		//Initiate registry
		serviceRegistry = super.getServiceRegistry();
		final DelegateTask delegateTask = task;
		final String finalMailSubject = mailSubject;
		//final String finalDocStatus = docStatus;
		final String finalEventName = eventName;
		//final String finalMailReciverType = mailReciverType;
		try{
			workflowVariables=AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<HashMap<String,Object>>() {
				HashMap<String, Object> workflowinfo = new HashMap<String, Object>();
			@Override
			public HashMap<String, Object> doWork() throws Exception {
				String initiator=getWfInitiator(delegateTask);
				String initiatorFullName=getWfInitiatorFullName(delegateTask);
				List<String> assigneesMailcc=getAssigneesList(delegateTask);
				String taskAssigneeValue=delegateTask.getAssignee();
				workflowinfo.put("initiator", initiator);
				workflowinfo.put("initiatorFullName", initiatorFullName);
				workflowinfo.put("assigneesMailcc", assigneesMailcc);
				workflowinfo.put("taskAssigneeValue", taskAssigneeValue);
				List<NodeRef> wfAttacheddocuments=getAllwfAttachments(delegateTask);
				workflowinfo.put("wfAttacheddocuments", wfAttacheddocuments);
				String documentTitle=getWorkflowDocumentTitle(wfAttacheddocuments);
				workflowinfo.put("documentTitle", documentTitle);
				String documentVersionLabel=getWorkflowDocumentVersion(wfAttacheddocuments);
				workflowinfo.put("documentVersionLabel", documentVersionLabel);
				return workflowinfo;
					}
				}, "admin");
			
			wfInitiator=(String) workflowVariables.get("initiator");
			wfInitiatorFullName=(String) workflowVariables.get("initiatorFullName");
			mailCc=(List<String>) workflowVariables.get("assigneesMailcc");
			docTitle=(String) workflowVariables.get("documentTitle");
			versionLabel=(String) workflowVariables.get("documentVersionLabel");
			taskAssignee=(String) workflowVariables.get("taskAssigneeValue");
			wfAttacheddocuments= (List<NodeRef>) workflowVariables.get("wfAttacheddocuments");
			logger.info("WorkflowNotifyExecutor initiator : "+wfInitiator);
			logger.info("initiatorFullName :"+wfInitiatorFullName);
			logger.info("assigneesMailcc : "+mailCc.toString());
			logger.info("documentTitle : "+docTitle);
			logger.info("documentVersionLabel : "+versionLabel);
			logger.info("taskAssigneeValue : "+taskAssignee);
			logger.info("wfAttacheddocuments :"+wfAttacheddocuments.toString());
				//setWFInitiatorFullName(delegateTask);
				//getAssigneesLst(delegateTask);
				//constructMailSubject(finalMailSubject);
				CustomMailAction mailAction = new CustomMailAction();
				logger.info("Task Name:"+delegateTask.getName());
				logger.info("Event Name:"+finalEventName);
				//String initatorFullName =getFullName(wfInitiator);
				NodeRef templateRef=null;
				if( ("Review Task".equalsIgnoreCase(delegateTask.getName())) && ("create".equalsIgnoreCase(finalEventName)) ){
					
					//logger.info("Comment:"+delegateTask.getExecution().getVariable("bpm_comment").toString());
					logger.info("Task is Review Task and event is create");
					//logger.info("Resubmited ...:"+delegateTask.getExecution().getVariable("resubmited"));
					Boolean isResubmitted  = Boolean.parseBoolean(delegateTask.getVariable("resubmited").toString());
					logger.info("Resubmited from ...:"+delegateTask.getVariable("resubmited"));
					//String comment =delegateTask.getExecution().getVariable("bpm_comment").toString();
					String comment ="";
					String dueDate =delegateTask.getExecution().getVariable("bpm_workflowDueDate").toString();
					logger.info("Comment from Execution variable:"+delegateTask.getExecution().getVariable("bpm_comment"));
					if (delegateTask.getExecution().getVariable("bpm_comment")!=null){
						logger.info("Comment from Execution variable:"+delegateTask.getExecution().getVariable("bpm_comment").toString());
						comment=delegateTask.getExecution().getVariable("bpm_comment").toString();
                    }
					if (delegateTask.getVariable("bpm_comment")!=null){
	 
						logger.info("Comments from variable:"+delegateTask.getVariable("bpm_comment").toString());
					}
					
					//NodeRef templateRef = getEmailtemplate("Authoring", "Author", "create", null);
					Map<String, Serializable> templateArgs = new HashMap<String, Serializable>();
					templateArgs.put("initiator", wfInitiatorFullName);
					templateArgs.put("docName", docTitle);
					templateArgs.put("version", versionLabel);
					templateArgs.put("comment", comment);
					templateArgs.put("dueDate", formatDate(dueDate));
					templateArgs.put("taskId", (Serializable)"activiti$"+delegateTask.getId());
					templateArgs.put("appUrl", shareURL);
					templateArgs.put("appContext", contextName);
					templateArgs.put("titleURL", titleURL); 
					templateArgs.put("year", year );
					if(isResubmitted){
						setNodeProperties(wfAttacheddocuments.get(0),ExternalSharingWorkflowConstants.PROP_QNAME_STATUS,ExternalSharingWorkflowConstants.SUBMITTED_FOR_APPROVAL);
						templateName =ExternalSharingWorkflowConstants.REVIEW_RESUBMIT_TEMPLATE;
						templateRef =getEmailtemplate(templateName);
						subject ="$InitiatorName has resubmitted $filename $version on Doc Exchange to be completed by $DueDate";
						subject=StringUtils.replaceEach(subject, new String[]{"$InitiatorName","$filename","$version","$DueDate"}, new String[]{wfInitiatorFullName,docTitle,versionLabel,formatDate(dueDate)});
						logger.info("######Sending mail for Resubmit task");
						
						logger.info("Template Args:::");
						logger.info("Mail From:"+wfInitiator);
						logger.info("Mail To:"+getEmail(delegateTask.getAssignee()));
						logger.info("subject::"+subject);
						logger.info("docName::"+templateArgs.get("docName"));
						logger.info("version:"+versionLabel);
						logger.info("comments::"+templateArgs.get("comment"));
						logger.info("initiator::"+templateArgs.get("initiator"));
						logger.info("taskId::"+templateArgs.get("taskId"));
						logger.info("Task Due Date:"+templateArgs.get("dueDate"));
						//mailAction.sendMails(serviceRegistry, templateArgs, templateRef, subject, getEmail(delegateTask.getAssignee()), shareURL);
					}else{
						setNodeProperties(wfAttacheddocuments.get(0),ExternalSharingWorkflowConstants.PROP_QNAME_STATUS,ExternalSharingWorkflowConstants.SUBMITTED_FOR_APPROVAL);
						setNodeProperties(wfAttacheddocuments.get(0),ExternalSharingWorkflowConstants.PROP_QNAME_WORKFLOW_STATUS,ExternalSharingWorkflowConstants.WORKFLOW_IN_PROGRESS);
						templateName =ExternalSharingWorkflowConstants.REVIEW_CREATE_TEMPLATE;
						templateRef =getEmailtemplate(templateName);
						subject=finalMailSubject;
						//subject ="$InitiatorName has assigned you a workflow approval task in Doc Exchange to be completed by $DueDate";
						subject=StringUtils.replaceEach(subject, new String[]{"$InitiatorName","$filename","$DueDate"}, new String[]{wfInitiatorFullName,"",formatDate(dueDate)});
						logger.info("######Sending mail for Review task");
						
						logger.info("Template Args:::");
						logger.info("Mail From:"+wfInitiator);
						logger.info("Mail To:"+getEmail(delegateTask.getAssignee()));
						logger.info("subject::"+subject);
						logger.info("docName::"+templateArgs.get("docName"));
						logger.info("version:"+versionLabel);
						logger.info("comments::"+templateArgs.get("comment"));
						logger.info("initiator::"+templateArgs.get("initiator"));
						logger.info("taskId::"+templateArgs.get("taskId"));
						logger.info("Task Due Date:"+templateArgs.get("dueDate"));
						//mailAction.sendMails(serviceRegistry, templateArgs, templateRef, subject, getEmail(delegateTask.getAssignee()), shareURL);

					}
					//mailAction.sendMails(serviceRegistry, templateArgs, templateRef, subject, getEmail(delegateTask.getAssignee()), shareURL);
					mailAction.sendMails(serviceRegistry, templateArgs, templateRef, subject, wfInitiator,getEmail(delegateTask.getAssignee()), shareURL);
					logger.info("delegateTask.getExecution().getVariables()"+delegateTask.getExecution().getVariables());
				}
				else if( ("Review Task".equalsIgnoreCase(delegateTask.getName())) && ("complete".equalsIgnoreCase(finalEventName)) ){

					logger.info("Task is Review Task and event is complete");
					String comment ="";
					 logger.info(" bpm_comment in Review Task "+delegateTask.getVariable("bpm_comment"));
                    if (delegateTask.getVariable("bpm_comment")!=null){
                    	 
                    	 comment = delegateTask.getVariable("bpm_comment").toString();
                    }
					
					if("Accept".equalsIgnoreCase(delegateTask.getVariable("wf_reviewOutcome").toString())) 
					{
						logger.info("Authoring outcome is Accept");
						//templateRef = getEmailtemplate("Authoring", "Author", "complete", "Accept");
						Double approversCount=Double.parseDouble(delegateTask.getVariable("wf_numberApprovers").toString());
						Double approvedCount=Double.parseDouble(delegateTask.getVariable("wf_approveCount").toString());
						//List reviewerLst =(ArrayList)delegateTask.getVariable("bpm_assignees");
						//mailCc =new ArrayList();
						//logger.info("ReviewerLst size:"+reviewerLst.size());
						if(approversCount.intValue()==approvedCount.intValue()){
							logger.info("###Approval Process Completed sent the mail......");
							setNodeProperties(wfAttacheddocuments.get(0),ExternalSharingWorkflowConstants.PROP_QNAME_STATUS,ExternalSharingWorkflowConstants.APPROVED);
							setNodeProperties(wfAttacheddocuments.get(0),ExternalSharingWorkflowConstants.PROP_QNAME_WORKFLOW_STATUS,ExternalSharingWorkflowConstants.WORKFLOW_COMPLETED);
							String templateName =ExternalSharingWorkflowConstants.REVIEW_APPROVE_TEMPLATE;
							templateRef =getEmailtemplate(templateName);
							//subject=finalMailSubject;
							subject="$DocumentName Approved in Doc Exchange";
							subject =StringUtils.replaceEach(subject, new String[]{"$DocumentName"}, new String[]{docTitle});
							Map<String, Serializable> templateArgs = new HashMap<String, Serializable>();
							templateArgs.put("initiator", wfInitiator);
							templateArgs.put("docName", docTitle);
							templateArgs.put("version", versionLabel);
							templateArgs.put("appUrl", shareURL);
							templateArgs.put("appContext", contextName);
							templateArgs.put("titleURL", titleURL); 
							templateArgs.put("year", year );
							logger.info("Template Args:::");
							logger.info("Mail From:"+wfInitiator);
							logger.info("Mail To:"+wfInitiator);
							logger.info("Mail CC:"+mailCc.toString());
							logger.info("subject::"+subject);
							logger.info("docName::"+templateArgs.get("docName"));
							logger.info("version:"+versionLabel);
							logger.info("initiator::"+templateArgs.get("initiator"));
							logger.info("comments for Approved:"+comment);
							//logger.info("taskId::"+templateArgs.get("taskId"));
							//logger.info("Task Due Date:"+delegateTask.getExecution().getVariable("bpm_workflowDueDate").toString());
							//mailAction.sendMails(serviceRegistry, templateArgs, templateRef, subject, wfInitiator, shareURL);
							logger.info("######Sending mail for Approved Document");
							logger.info("delegateTask.getExecution().getVariables()"+delegateTask.getExecution().getVariables());
							//mailAction.sendMails(serviceRegistry, templateArgs, templateRef, subject, wfInitiator, shareURL);
							mailAction.sendMails(serviceRegistry, templateArgs, templateRef, subject,wfInitiator, wfInitiator, mailCc,shareURL);
						}
					}
				}else if( ("Resubmit Task".equalsIgnoreCase(delegateTask.getName())) && ("create".equalsIgnoreCase(finalEventName)) ){
						logger.info("Authoring outcome is Reject and new Resubmit task is created");
						setNodeProperties(wfAttacheddocuments.get(0),ExternalSharingWorkflowConstants.PROP_QNAME_STATUS,ExternalSharingWorkflowConstants.REJECTED);
						String comment =""; 
						String rejectedUser="";
						logger.info("delegateTask.getExecution().getVariables()"+delegateTask.getExecution().getVariables());
						if(delegateTask.getVariable("previousUser")!=null){
							logger.info("Pervious user####:"+delegateTask.getVariable("previousUser").toString());
							 rejectedUser =delegateTask.getVariable("previousUser").toString();
						}
						 if (delegateTask.getVariable("bpm_comment")!=null){
						  comment = delegateTask.getVariable("bpm_comment").toString();
					      } 
						String templateName =ExternalSharingWorkflowConstants.REVIEW_REJECT_TEMPLATE;
						templateRef =getEmailtemplate(templateName);
						subject=finalMailSubject;
						String reviewer =getFullName(taskAssignee);
						String rejectUserName=getFullName(rejectedUser);
						logger.info("Current Task Reviewer:"+reviewer);
						logger.info("Current Task Owner :"+rejectedUser);
						if(mailCc.contains(getEmail(taskAssignee))){
							mailCc.remove(getEmail(taskAssignee));
							}
						subject=StringUtils.replaceEach(subject, new String[]{"$ReviewerName","$filename","$version"}, new String[]{rejectUserName,docTitle,versionLabel});
						Map<String, Serializable> templateArgs = new HashMap<String, Serializable>();
						templateArgs.put("initiator", wfInitiator);
						templateArgs.put("docName", docTitle);
						templateArgs.put("version", versionLabel);
						templateArgs.put("assignee", rejectUserName);
						templateArgs.put("comment", comment);
						templateArgs.put("taskId", (Serializable)"activiti$"+delegateTask.getId());
						templateArgs.put("appUrl", shareURL);
						templateArgs.put("appContext", contextName);
						templateArgs.put("titleURL", titleURL); 
						templateArgs.put("year", year );
						logger.info("######Sending mail for Review task");
						logger.info("Template Args:::");
						logger.info("Mail From:"+wfInitiator);
						logger.info("Mail To:"+wfInitiator);
						logger.info("Mail CC:"+mailCc.toString());
						logger.info("subject::"+subject);
						logger.info("docName::"+templateArgs.get("docName"));
						logger.info("version:"+versionLabel);
						logger.info("Rejected reviewer:"+delegateTask.getAssignee());
						logger.info("Rejected comments::"+templateArgs.get("comment"));
						logger.info("initiator::"+templateArgs.get("initiator"));
						logger.info("taskId::"+templateArgs.get("taskId"));
						logger.info("######Sending mail for Reject task");
						//mailAction.sendMails(serviceRegistry, templateArgs, templateRef, subject, wfInitiator, shareURL);
						mailAction.sendMails(serviceRegistry, templateArgs, templateRef, subject, getEmail(rejectedUser),wfInitiator, mailCc,shareURL);
				}
				 
		}catch(Exception e){
			logger.error(" Failed to Send Email Notification : "+e.getMessage());
		}
	}

	/**
	 * To Get Email Template
	 */
	private NodeRef getEmailtemplate(String templateName)
	{
		String templateConditionalPath = "PATH:\""+ftlLocation+"//*\" AND "+"TYPE:cm\\:content AND @cm\\:title:\""+templateName+"\"" ;
		logger.info("LUCENE QRY: "+templateConditionalPath);
		ResultSet resultSet = serviceRegistry.getSearchService().query(new StoreRef(StoreRef.PROTOCOL_WORKSPACE, "SpacesStore"), SearchService.LANGUAGE_LUCENE, templateConditionalPath);
		if (resultSet.length()==0){
			logger.error("Template "+ templateConditionalPath+" not found.");
			return null;
		}
		NodeRef template = resultSet.getNodeRef(0);
		logger.info("Got the Email Template:"+template.toString());
		return template;
	}
	
	/**
	 * To Get Workflow Initiator Details
	 */
	private String getWfInitiator(DelegateTask task)
	{
		String wfInitiator=null;
		final ActivitiScriptNode initiatorNode = (ActivitiScriptNode) task.getExecution().getVariable(WorkflowConstants.PROP_INITIATOR);
		if(initiatorNode != null) 
		{
			wfInitiator= (String) serviceRegistry.getNodeService().getProperty(initiatorNode.getNodeRef(), ContentModel.PROP_EMAIL);

		}
		if(logger.isDebugEnabled()){
			logger.debug("Got the WF Initiator : "+wfInitiator);
		}
		logger.info("Got the WF Initiator : "+wfInitiator);
		return wfInitiator;
	}
	
	/**
	 * To Get Workflow Initiator Full Name
	 */
	private String getWfInitiatorFullName(DelegateTask task)
	{
		String wfInitiatorFullName=null;
		final ActivitiScriptNode initiatorNode = (ActivitiScriptNode) task.getExecution().getVariable(WorkflowConstants.PROP_INITIATOR);
		if(initiatorNode != null) 
		{
			wfInitiatorFullName = ((String)serviceRegistry.getNodeService().getProperty(initiatorNode.getNodeRef(), ContentModel.PROP_FIRSTNAME)==null?"":(String)serviceRegistry.getNodeService().getProperty(initiatorNode.getNodeRef(), ContentModel.PROP_FIRSTNAME)) +" "+
					((String)serviceRegistry.getNodeService().getProperty(initiatorNode.getNodeRef(), ContentModel.PROP_FIRSTNAME)==null?"":(String)serviceRegistry.getNodeService().getProperty(initiatorNode.getNodeRef(), ContentModel.PROP_LASTNAME));     

		}
		if(logger.isDebugEnabled()){
			logger.debug("Got the WF Initiator Full Name: "+wfInitiatorFullName);
		}
		logger.info("Got the WF Initiator Full Name: "+wfInitiatorFullName);
		return wfInitiatorFullName;
	}

	/**
	 * To Get Workflow Assignees Details
	 */
	private List<String> getAssigneesList(DelegateTask task){
		List<String> mailCc=null;
		List<Object> reviewerLst =(ArrayList)task.getVariable("bpm_assignees");
		mailCc =new ArrayList<String>();
		if(reviewerLst!=null){
						for(int i=0 ;i<reviewerLst.size();i++){
				logger.info("Reviewer....:"+reviewerLst.get(i));
				final ActivitiScriptNode assigneeNode = (ActivitiScriptNode)reviewerLst.get(i);
				logger.info("Person detail:"+serviceRegistry.getNodeService().getProperty(assigneeNode.getNodeRef(), ContentModel.PROP_FIRSTNAME));
				//String reviewerName =(String)serviceRegistry.getNodeService().getProperty(assigneeNode.getNodeRef(), ContentModel.PROP_FIRSTNAME);
				mailCc.add(serviceRegistry.getNodeService().getProperty(assigneeNode.getNodeRef(), ContentModel.PROP_EMAIL).toString());

			}
		}
		return mailCc;
	}
	/**
	 * To Format Date
	 */
	private String formatDate(String dueDate){
		String formatedDate="";
		DateFormat dateformat =new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
		try {
			Date date =dateformat.parse(dueDate);
			DateFormat dateString =new SimpleDateFormat("MM/dd/yyyy");
			formatedDate =dateString.format(date);
			logger.info("Formated Date:"+formatedDate);
		} catch (ParseException e) {
			logger.error("Unbale to Parse the date:"+e.getMessage());
		}
		return formatedDate;
	}
	
	private void setNodeProperties(final NodeRef nodeRef, final QName qName,final String Status){
		serviceRegistry=this.serviceRegistry;
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
		try{
		serviceRegistry.getNodeService().setProperty(nodeRef, qName,Status);
		} catch(Exception e){
			logger.error("Unbale to Update Node : "+e.getMessage());
		}
		return null;
			}
		}, "admin");
	}
}
