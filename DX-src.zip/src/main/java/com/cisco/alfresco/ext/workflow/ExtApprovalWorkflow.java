package com.cisco.alfresco.ext.workflow;

import java.io.IOException;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.invitation.WorkflowModelNominatedInvitation;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.workflow.WorkflowModel;
import org.alfresco.service.Auditable;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.cmr.workflow.WorkflowDefinition;
import org.alfresco.service.cmr.workflow.WorkflowPath;
import org.alfresco.service.cmr.workflow.WorkflowService;
import org.alfresco.service.cmr.workflow.WorkflowTask;
import org.alfresco.service.cmr.workflow.WorkflowTaskState;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.namespace.QName;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.ext.workflow.util.ExtWorkflowConstants;


public class ExtApprovalWorkflow extends DeclarativeWebScript implements ExtWorkflowConstants
{

    private static final Logger LOGGER = Logger.getLogger(ExtApprovalWorkflow.class);
    private ServiceRegistry serviceRegistry;
    private WorkflowService workflowService;
    private NodeService nodeService;
    private PersonService personService;
    private Properties globalProperties;
    private String ftlLocationPath;
    //private String versionLabel = null;
    private static final String TIME_ZONE = "GMT+0";
    private static final String WORKFLOW_DOCUMENT_STATUS = "Rejected";
    private static final String WORKFLOW_STATUS = "Complete";
    private static final String VERSION_STORE = "versionStore";
    private static final String WORKSPACE_STORE = "workspace";
    public static final QName PROP_REVIEWOUTCOME = QName.createQName("http://www.alfresco.org/model/workflow/1.0",
        "reviewOutcome");

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    public String getFtlLocationPath()
    {
        return ftlLocationPath;
    }

    public void setFtlLocationPath(String ftlLocationPath)
    {
        this.ftlLocationPath = ftlLocationPath;
    }

    public Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
    {
        String action = req.getExtensionPath();

        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("Action:" + action);
        }

        workflowService = serviceRegistry.getWorkflowService();
        nodeService = serviceRegistry.getNodeService();
        personService = serviceRegistry.getPersonService();

        String inputJSON = null;

        if (TASKLIST.equalsIgnoreCase(action))
        {
            return getTaskList(serviceRegistry.getAuthenticationService().getCurrentUserName());
        }
        else if (TASKDETAILS.equalsIgnoreCase(action))
        {
            return getTaskDetails(req.getParameter("taskId"));
        }
        else if (START.equalsIgnoreCase(action))
        {
            inputJSON = readRequestBody(req);
            try
            {
                JSONObject jsonObject = new JSONObject(inputJSON);

                return startWorkflow(jsonObject);

            }
            catch (JSONException e)
            {
                return null;
            }

        }
        else if (APPROVE.equalsIgnoreCase(action) || REJECT.equalsIgnoreCase(action))
        {
            inputJSON = readRequestBody(req);
            try
            {
                JSONObject jsonObject = new JSONObject(inputJSON);

                return updateTask(jsonObject, action);

            }
            catch (JSONException e)
            {
                // TODO Auto-generated catch block
                return null;
            }
        }
        else if (RESUBMIT.equalsIgnoreCase(action))
        {
            inputJSON = readRequestBody(req);
            try
            {
                JSONObject jsonObject = new JSONObject(inputJSON);

                return resubmitTask(jsonObject);

            }
            catch (JSONException e)
            {
                return null;
            }
        }

        return null;
    }

    @Auditable
    private Map<String, Object> startWorkflow(JSONObject jsonObject)
    {
        try
        {
            WorkflowDefinition definition = workflowService.getDefinitionByName(WORKFLOW_NAME);
            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("Got the definition:" + definition);
            }
            NodeRef workflowPackage = workflowService.createPackage(null);
            NodeRef nodeRef = null;
            if (jsonObject.getString("nodeId").startsWith("workspace://SpacesStore/"))
            {
                nodeRef = new NodeRef(jsonObject.getString("nodeId"));
            }
            else
            {
                nodeRef = new NodeRef("workspace://SpacesStore/" + jsonObject.getString("nodeId"));
            }

            ChildAssociationRef childAssoc = nodeService.getPrimaryParent(nodeRef);
            this.nodeService.addChild(workflowPackage, nodeRef, WorkflowModel.ASSOC_PACKAGE_CONTAINS,
                childAssoc.getQName());

            JSONArray approvers = jsonObject.getJSONArray("approvers");
            List<NodeRef> personList = new ArrayList<NodeRef>();
            for (int i = 0; i < approvers.length(); i++)
            {
                personList.add(personService.getPerson(approvers.getString(i)));
            }

            Map<QName, Serializable> parameters = new HashMap<QName, Serializable>();
            parameters.put(WorkflowModel.ASSOC_PACKAGE, workflowPackage);
            parameters.put(WorkflowModel.ASSOC_ASSIGNEES, (Serializable) personList);
            parameters.put(WorkflowModel.PROP_PACKAGE_ACTION_GROUP, getVersionNum(nodeRef));
            if (jsonObject.getString("dueDate") != null)
            {
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
                sdf.setTimeZone(TimeZone.getTimeZone(TIME_ZONE));
                Date dueDate = sdf.parse(jsonObject.getString("dueDate"));
                parameters.put(WorkflowModel.PROP_WORKFLOW_DUE_DATE, dueDate);
            }

            if (jsonObject.getString("comment") != null)
            {
                parameters.put(WorkflowModel.PROP_COMMENT, jsonObject.getString("comment"));

            }
            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("workflow parameters:" + parameters);
            }
            WorkflowPath workflowPath = workflowService.startWorkflow(definition.getId(), parameters);

            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("Workflow Started Successfully::" + workflowPath);
            }
            Map<String, Object> model = new HashMap<String, Object>();

            model.put("response", "Workflow Started Successfully");
            return model;

        }
        catch (InvalidNodeRefException e)
        {
            LOGGER.error(" InvalidNodeRefException : ", e);
        }
        catch (JSONException e)
        {
            LOGGER.error(" JSONException : ", e);
        }
        catch (ParseException e)
        {
            LOGGER.error(" ParseException : ", e);
        }

        return null;
    }

    public String readRequestBody(WebScriptRequest req)
    {
        try
        {
            return IOUtils.toString(req.getContent().getInputStream(), req.getContent().getEncoding());
        }
        catch (Exception e)
        {
            try
            {
                return req.getContent().getContent();
            }
            catch (IOException e1)
            {
                LOGGER.error(" Unable to read JSON request body ", e);
                throw new WebScriptException("Unable to read JSON request body!! Epic fail.");
            }
        }
    }

    @Auditable
    private Map<String, Object> updateTask(JSONObject jsonObject, String action)
    {
        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("Action in Update Task:" + action);
        }
        String userName = null;
        Map<String, Object> model = new HashMap<String, Object>();
        // String action = null;
        try
        {
            String taskId = jsonObject.getString("taskId");
            // action = jsonObject.getString("action");
            WorkflowTask task = workflowService.getTaskById(taskId);
            NodeRef initiator = task.getPath().getInstance().getInitiator();

            // determine if the current user is the initiator of the workflow
            if (initiator != null)
            {
                // get the username of the initiator
                userName = (String) nodeService.getProperty(initiator, ContentModel.PROP_USERNAME);
                if (LOGGER.isDebugEnabled())
                {
                    LOGGER.debug("Username of the Initiator : " + userName);
                }
            }
            if (canUserIsInitiator(userName))
            {

                if (LOGGER.isDebugEnabled())
                {
                    LOGGER.debug("Initioator is not able approve or reject : ");
                }
                // for send mail
                // String templateName=ExternalSharingWorkflowConstants.INITIATOR_APPROVE_REJECT_TEMPLATE;
                // sendMailNotification(task,templateName,userName,action);
                model.put("response", "User does not have permission to perform workflow task action:" + action);

            }
            else
            {
                Map<QName, Serializable> parameters = task.getProperties();
                if (LOGGER.isDebugEnabled())
                {
                    LOGGER.debug("before updating comments:" + parameters.toString());
                    LOGGER.debug("Comment from user Task:" + jsonObject.getString("comment"));
                }
                parameters.put(WorkflowModel.PROP_COMMENT, jsonObject.getString("comment"));
                parameters.put(WorkflowModel.PROP_PACKAGE_ACTION_GROUP, getNodeVersionLabel(taskId));
                workflowService.updateTask(taskId, parameters, null, null);

                if (LOGGER.isDebugEnabled())
                {
                    LOGGER.debug("After updating comments:" + task.getProperties().toString());
                    LOGGER.debug("Initiator with in Update Task :" + task.getPath().getInstance().getInitiator());
                }

                if (APPROVE.equalsIgnoreCase(action))
                {
                    if (LOGGER.isDebugEnabled())
                    {
                        LOGGER.debug("APPROVING::" + taskId);
                    }
                    setDocumentWorkflowStatus(taskId);
                    workflowService.endTask(task.getId(), WorkflowModelNominatedInvitation.WF_TRANSITION_ACCEPT);
                }
                else if (REJECT.equalsIgnoreCase(action))
                {
                    if (LOGGER.isDebugEnabled())
                    {
                        LOGGER.debug("REJECTING::" + taskId);
                    }
                    workflowService.endTask(task.getId(), WorkflowModelNominatedInvitation.WF_TRANSITION_REJECT);
                }
                model.put("response", "The workflow task action:" + action + " successfully");
            }

        }
        catch (JSONException e)
        {
            LOGGER.error(" Exception: ", e);
        }
        return model;
    }

    @Auditable
    private Map<String, Object> resubmitTask(JSONObject jsonObject)
    {
        Date dueDate;
        String userName = null;
        
        Map<String, Object> model = new HashMap<String, Object>();
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
        sdf.setTimeZone(TimeZone.getTimeZone(TIME_ZONE));
        try
        {
            String taskId = jsonObject.getString("taskId");
            WorkflowTask task = workflowService.getTaskById(taskId);
            NodeRef initiator = task.getPath().getInstance().getInitiator();
            // determine if the current user is the initiator of the workflow
            if (initiator != null)
            {
                // get the username of the initiator
                userName = (String) nodeService.getProperty(initiator, ContentModel.PROP_USERNAME);
                if (LOGGER.isDebugEnabled())
                {
                    LOGGER.debug("Username of the Initiator : " + userName);
                }
            }
            if (canUserIsInitiator(userName))
            {
                Map<QName, Serializable> parameters = task.getProperties();
                if (jsonObject.getString("dueDate") != null && !jsonObject.getString("dueDate").equals(""))
                {
                    if (LOGGER.isDebugEnabled())
                    {
                        LOGGER.debug("Json date : " + jsonObject.getString("dueDate"));
                    }
                    dueDate = sdf.parse(jsonObject.getString("dueDate"));
                    parameters.put(WorkflowModel.PROP_WORKFLOW_DUE_DATE, dueDate);
                }
                else
                {
                    if (LOGGER.isDebugEnabled())
                    {
                        LOGGER.debug("if json is null date : " + task.getPath().getInstance().getDueDate().toString());
                    }
                    String dateFormatString = null;
                    dateFormatString = getDateFormat(task.getPath().getInstance().getDueDate().toString());
                    dueDate = sdf.parse(dateFormatString);
                    parameters.put(WorkflowModel.PROP_WORKFLOW_DUE_DATE, dueDate);
                }
                parameters.put(WorkflowModel.PROP_COMMENT, jsonObject.getString("comment"));
                parameters.put(WorkflowModel.PROP_PACKAGE_ACTION_GROUP, getNodeVersionLabel(taskId));
                parameters.put(PROP_REVIEWOUTCOME, "Approve");
                workflowService.updateTask(taskId, parameters, null, null);
                if (LOGGER.isDebugEnabled())
                {
                    LOGGER.debug("After updating task:" + parameters.toString());
                }
                workflowService.endTask(task.getId(), null);
                if (LOGGER.isDebugEnabled())
                {
                    LOGGER.debug("Resubmitted task");
                }
                model.put("response", "The workflow resubmitted successfully");
            }
            else
            {
                model.put("response", "User does not have permission to perform workflow task action: resubmit");
            }
        }
        catch (JSONException e)
        {
            LOGGER.error(" Exception: ", e);
        }
        catch (ParseException e)
        {
            LOGGER.error(" Exception: ", e);
        }

        return model;
    }

    private Map<String, Object> getTaskDetails(String taskId)
    {

        Map<String, Object> model = new HashMap<String, Object>();

        WorkflowTask task = workflowService.getTaskById(taskId);

        model.put("response", getTaskDetailsObject(task));

        return model;

    }

    private Map<String, Object> getTaskList(String userName)
    {
        List<WorkflowTask> list = workflowService.getAssignedTasks(userName, WorkflowTaskState.IN_PROGRESS);
        List<String> taskList = new ArrayList<String>();
        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("TaskList size:" + list.size());
        }
        for (WorkflowTask task : list)
        {
            taskList.add(getTaskDetailsObject(task).toString());
        }

        Map<String, Object> model = new HashMap<String, Object>();
        model.put("response", taskList.toString());

        return model;
    }

    private TaskDetails getTaskDetailsObject(WorkflowTask task)
    {
        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("Inside getTaskDetailsObject Method:");

            LOGGER.debug("Workflow Details:" + task.getPath().getInstance().toString());
            LOGGER.debug("##task properties:" + task.getProperties().toString());
        }
        Map<QName, Serializable> taskProps = task.getProperties();
        String comments = (String) taskProps.get(WorkflowModel.PROP_COMMENT);
        TaskDetails details = new TaskDetails(this.serviceRegistry);
        details.setTaskName(task.getTitle());
        details.setTaskId(task.getId());
        if (task.getPath().getInstance().getDueDate() != null)
        {
            details.setDueDate(getDateFormat(task.getPath().getInstance().getDueDate().toString()));
        }
        else
        {
            details.setDueDate("");
        }

        details.setComment(comments);
        details.setInitiator(getUserName(task.getPath().getInstance().getInitiator()));
        details.setAppUrl(globalProperties.getProperty(ALFRESCO_URL));

        if (RESUBMIT_TASK.equals(task.getPath().getNode().getTitle()))
            details.setType(RESUBMIT);
        else if (REVIEW_TASK.equals(task.getPath().getNode().getTitle()))
            details.setType(REVIEW);
        else
            details.setType("");

        List<NodeRef> packageList = workflowService.getPackageContents(task.getId());
        for (NodeRef nodeRef : packageList)
        {
            details.setFileName(getFileName(nodeRef));
            details.setFileTitle(getFileTitle(nodeRef));
            details.setNodeId(nodeRef.toString());
            details.setVersionId(getVersionNum(nodeRef));
            details.setNodeRef(nodeRef);
        }

        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("TaskPackageDetail:" + details.toString());
        }
        return details;
    }

    private String getUserName(NodeRef nodeRef)
    {
        return (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_USERNAME);
    }

    private String getFileName(NodeRef nodeRef)
    {
        return (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NAME);
    }

    private String getFileTitle(NodeRef nodeRef)
    {
        return (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_TITLE);
    }

    private String getVersionNum(NodeRef nodeRef)
    {
        if (serviceRegistry.getVersionService().getCurrentVersion(nodeRef) != null)
            return serviceRegistry.getVersionService().getCurrentVersion(nodeRef).getVersionLabel();
        else
            return "1.0";
        
    }

    /**
     * To change date format
     */
    private String getDateFormat(String dateValue)
    {
        String formatedDate = null;
        // start of task details due date format
        try
        {
            SimpleDateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
            // formatter.setTimeZone(TimeZone.getTimeZone(TIME_ZONE));
            Date date = null;
            try
            {
                date = (Date) formatter.parse(dateValue);
            }
            catch (ParseException e)
            {
                // TODO Auto-generated catch block
                LOGGER.error("Exception: ", e);
            }
            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("Date:" + date);
            }
            DateFormat dateFormatToString = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
            dateFormatToString.setTimeZone(TimeZone.getTimeZone("GMT"));
            formatedDate = dateFormatToString.format(date);

            // dateFormatToString.setTimeZone(TimeZone.getTimeZone(TIME_ZONE));
            // formatedDate = dateFormatToString.format(date)+" "+GMT_TIME_ZONE;
            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("Formated Due Date :" + formatedDate);
            }

            // end of task details due date format
        }
        catch (Exception e)
        {
            LOGGER.error("Exception: "+e);
        }
        return formatedDate;

    }

    /**
     * To Check User is a initiator
     */
    private boolean canUserIsInitiator(String initiatorUserId)
    {
        boolean canIntiator = false;
        // String currentUserName = authenticationService.getCurrentUserName();
        String currentUserName = serviceRegistry.getAuthenticationService().getCurrentUserName();

        if (currentUserName.equals(initiatorUserId))
        {
            canIntiator = true;
        }
        return canIntiator;
    }

    public void setGlobalProperties(Properties globalProperties)
    {
        this.globalProperties = globalProperties;
    }
    /**
     * To set version of node
     */
    private String getNodeVersionLabel(final String taskId)
   	{
    	final StringBuffer  versionLabel = new StringBuffer();
    	AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				List<NodeRef> packageItemNode=workflowService.getPackageContents(taskId);
                NodeRef workflowPackageNoderef=packageItemNode.get(0);
   		if(nodeService.getProperty(workflowPackageNoderef, ContentModel.PROP_VERSION_LABEL) !=null){
   			versionLabel.append((String) nodeService.getProperty(workflowPackageNoderef, ContentModel.PROP_VERSION_LABEL));
   		}else{
   			versionLabel.append("1.0");
   		}
   	 if (LOGGER.isDebugEnabled())
     {
   		LOGGER.debug("Node Version Label : "+versionLabel.toString());
     }
   		return null;
			}
		}, "admin");
    	return versionLabel.toString();
   	}
    /**
     * To set document workflow status for previous versions of node
     */
    private void setDocumentWorkflowStatus(final String taskId)
   	{
    	try{
    	AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				List<NodeRef> packageItemNode=workflowService.getPackageContents(taskId);
                NodeRef node=packageItemNode.get(0);
                VersionHistory versions = serviceRegistry.getVersionService().getVersionHistory(node);
                if (LOGGER.isDebugEnabled())
                {
                	LOGGER.debug("Workflow attachment Node : "+node);
                    LOGGER.debug("Workflow attachment Node versions : "+versions);
                }
                if(versions!=null){
                	Collection<Version> allVersions=new ArrayList<Version>();
                	allVersions = versions.getAllVersions();
                	  if (LOGGER.isDebugEnabled())
                      {
                		  LOGGER.debug("Workflow attachment Node versions : "+allVersions.toString());
                      }
                	Iterator<Version> versionIterator = allVersions.iterator();
                	while(versionIterator.hasNext()){
                		Version versionNode  = (Version)(versionIterator.next());
                		NodeRef versionNodeId=versionNode.getFrozenStateNodeRef();
                		 if (LOGGER.isDebugEnabled())
                         {
                			 LOGGER.debug("Workflow attachment Node versionNodeId : "+versionNodeId);
                         }
                		String workflowDocumentStatus = (String)nodeService.getProperty(versionNodeId, CiscoModelConstants.CISCO_DOC_STATUS);
                		NodeRef versionedNodeId=new NodeRef(versionNodeId.toString().replace(VERSION_STORE,WORKSPACE_STORE));
                		if(workflowDocumentStatus.equals(WORKFLOW_DOCUMENT_STATUS)){
                			nodeService.setProperty(versionedNodeId, CiscoModelConstants.CISCO_WORKFLOW_STATUS_PROP, WORKFLOW_STATUS);
                		}
                	}
                }else{
                	LOGGER.info("This document has no previous versions");
                }
   		return null;
			}
		}, "admin");
    	}catch (Exception e)
         {
             LOGGER.error("setDocumentWorkflowStatus Exception: "+e);
         }
   	}
}
