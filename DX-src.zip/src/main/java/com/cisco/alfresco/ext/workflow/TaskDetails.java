package com.cisco.alfresco.ext.workflow;


import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentData;
import org.alfresco.service.cmr.repository.MimetypeService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.json.JSONException;
import org.json.JSONObject;

public class TaskDetails {

	private ServiceRegistry serviceRegistry;

	public TaskDetails(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	private String getFullName(String assignee){
		String fullName = "";
		NodeRef personNode = serviceRegistry.getPersonService().getPerson(assignee);
		if(personNode == null)
			return fullName;
		fullName = ((String)serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_FIRSTNAME)==null?"":(String)serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_FIRSTNAME)) +" "+
				((String)serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_LASTNAME)==null?"":(String)serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_LASTNAME));     

		return fullName;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		JSONObject detailJSON = new JSONObject();

		try {
			detailJSON.put("file", this.getFileDetails());
			detailJSON.put("taskName", this.getTaskName());
			detailJSON.put("dueDate", this.getDueDate()==null?"":this.getDueDate());
			detailJSON.put("reviewComment", this.getComment()==null?"":this.getComment());
			detailJSON.put("taskId", this.getTaskId());
			detailJSON.put("versionId", this.getVersionId()==null?"":this.getVersionId());
			detailJSON.put("initiator", this.getInitiator());
			detailJSON.put("type", this.getType());

		} catch (JSONException e) {
			e.printStackTrace();
		}
		return detailJSON.toString();
	}

	private String fileName;
	private String fileTitle;
	private String modifier;
	private String description;
	private String creator;
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFileName()
	{
		return this.fileName;
		
	}
	
	public String getFileTitle()
	{
		return this.fileTitle;
		
	}
	
	public JSONObject getFileDetails() {

		JSONObject jsonObject = new JSONObject();
		try {
			jsonObject.put("nodeId", this.getNodeId());
			if(getNodeId()!=null) {
				ContentData contentData = (ContentData) serviceRegistry.getNodeService().getProperty(getNodeRef(), ContentModel.PROP_CONTENT);
				String originalMimeType = contentData==null?"":contentData.getMimetype();
				this.creator=(String)serviceRegistry.getNodeService().getProperty(getNodeRef(), ContentModel.PROP_CREATOR);
				this. modifier=(String)serviceRegistry.getNodeService().getProperty(getNodeRef(), ContentModel.PROP_MODIFIER);
				
				
				MimetypeService mimetypeService = serviceRegistry.getMimetypeService();
				jsonObject.put("type", mimetypeService.getExtensionsByMimetype().get(originalMimeType)==null?"":mimetypeService.getExtensionsByMimetype().get(originalMimeType));
				jsonObject.put("name", this.fileName);
				jsonObject.put("title", this.fileTitle);
				jsonObject.put("downloadUrl", getAppUrl()+"/alfext/ext/download/"+getNodeRef().toString().replace(":/", "") + "/" + fileName + "?a=true") ;
				jsonObject.put("description", this.description);
				jsonObject.put("creator", this.creator);
				jsonObject.put("modifier", this.modifier);
				
			}
			else
			{
				jsonObject.put("type", "");
				jsonObject.put("name", "");
				jsonObject.put("title", "");
				jsonObject.put("downloadUrl", "");
				jsonObject.put("description", "");
				jsonObject.put("creator", "");
				jsonObject.put("modifier", "");
			}
			
			

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jsonObject;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public void setFileTitle(String fileTitle) {
		this.fileTitle = fileTitle;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String[] getApprovers() {
		return approvers;
	}

	public void setApprovers(String[] approvers) {
		this.approvers = approvers;
	}

	public String getNodeId() {
		return nodeId;
	}

	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getVersionId() {
		return versionId;
	}

	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}

	public JSONObject getInitiator() {

		JSONObject jsonObject = new JSONObject();
		try {
			jsonObject.put("userId", initiator);
			jsonObject.put("name", getFullName(initiator));
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return jsonObject;
	}

	public void setInitiator(String initiator) {
		this.initiator = initiator;
	}

	public void setAppUrl(String url) {
		appUrl = url;
	}

	public String getAppUrl() {
		return this.appUrl;
	}
	
	public String getAction() {
		return this.action;
	}

	private String taskName;
	private String dueDate;
	private String comment;
	private String[] approvers;
	private String nodeId;
	private String taskId;
	private String action;
	private String versionId;
	private String initiator;
	private String appUrl;
	private NodeRef nodeRef;
	private String type;
	
	public String getType() {
		return this.type;
	}
	
	public void setType(String type) {
		
		this.type = type;
	}
	public NodeRef getNodeRef() {
		return nodeRef;
	}

	public void setNodeRef(NodeRef nodeRef) {
		this.nodeRef = nodeRef;
	}

	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	

}
