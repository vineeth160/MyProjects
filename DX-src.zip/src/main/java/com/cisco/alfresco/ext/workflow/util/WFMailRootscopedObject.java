/**
 * @author prbadam nathammi
 * 
 */
package com.cisco.alfresco.ext.workflow.util;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.workflow.WorkflowModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.TemplateService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.cmr.workflow.WorkflowInstance;
import org.alfresco.service.cmr.workflow.WorkflowService;
import org.alfresco.service.cmr.workflow.WorkflowTask;
import org.alfresco.service.cmr.workflow.WorkflowTaskQuery;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.edcsng.util.MailUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.sd.rest.service.MigrationConstants;



public class WFMailRootscopedObject
{
    public static String UNPUBLISH_NOTIFICATION_TEMPLATE = "/alfresco/extension/templates/email/unpublishNotificationTemplate.ftl";
    public static String UNPUBLISH_TEMPLATE = "/alfresco/extension/templates/email/unPublishTemplate.ftl";
    public static String UNPUBLISH_FROM_MAIL = "donotreply@cisco.com";
    public static String UNPUBLISH_SUBJECT = " Unpublished From Doc Exchange";
    public static String CANCEL_UNPUBLISH_SUBJECT = " Document is  checked out by ";
    public static String CANCEL_UNPUBLISH_CHECKEDOUTSUBJECT =" in doc exchange and cannot be unpublished ";
    public static String CANCELUNPUBLISH_NOTIFICATION_TEMPLATE = "/alfresco/extension/templates/email/cancelWorkflowNotificationTemplate.ftl";
    public static String CANCELUNPUBLISH_SUBJECT = " cancelled workflow for ";
    public static String MAIL_SERVER = "outbound.cisco.com";
    public static String CANCEL_UNPUBLISH_DESCRIPTION = "Document Unpublished from Doc Exchange";
    public static String CANCEL_REPUBLISH_DESCRIPTION = "New version of the file published";
   // public static String FTL_FILEPATH = "/app:company_home/app:dictionary/app:email_templates/cm:ExternalSharing";
    private static final Logger LOGGER = Logger.getLogger(WFMailRootscopedObject.class);
    private WorkflowService workflowService;
    private NodeService nodeService;
    private ServiceRegistry serviceRegistry;
    private TemplateService templateService;
    private String TASK_IN_PROGRESS = "IN_PROGRESS";
    public WFMailRootscopedObject(ServiceRegistry serviceRegistry)
    {
        // TODO Auto-generated constructor stub
        this.serviceRegistry = serviceRegistry;
    }

    public void cancelWFandSendMail(String externalNodeRef, String action, String currentLoginUserName, String bannerAlfrescoUrl)
    {
        workflowService = serviceRegistry.getWorkflowService();
        nodeService = serviceRegistry.getNodeService();
        serviceRegistry.getAuthenticationService();
        Set<String> workflowUsersEmailList = new HashSet<String>();
        Set<String> unpublishUsersEmailList = new HashSet<String>();
        String currentUserFullName = null;
        String reasonForCancel = null;
        String documentVersionLabel = null;
        String cancelWorkflowFromMail=null;
        boolean isAutoUnPublish=false;
        try
        {
            String nodeRefStr = externalNodeRef;
            LOGGER.debug("request string node ref ids : " + nodeRefStr);
            NodeRef node = new NodeRef(nodeRefStr);
            LOGGER.info("request node ref ids  : " + node);
            LOGGER.info("nodeService :"+serviceRegistry);
            //start of unpublish document mail code
            documentVersionLabel = getVersionNum(node);
            Date currentDate = new Date();
        	String year = new SimpleDateFormat("yyyy").format(currentDate); 
            List<WorkflowInstance> workflows = new ArrayList<WorkflowInstance>();
            //currentLoginUserName
            if(currentLoginUserName!=null){
            NodeRef currentUserNode = serviceRegistry.getPersonService().getPerson(currentLoginUserName);
            currentUserFullName = ((String)serviceRegistry.getNodeService().getProperty(currentUserNode , ContentModel.PROP_FIRSTNAME)==null?"":(String)serviceRegistry.getNodeService().getProperty(currentUserNode, ContentModel.PROP_FIRSTNAME)) +" "+
            		((String)serviceRegistry.getNodeService().getProperty(currentUserNode, ContentModel.PROP_FIRSTNAME)==null?"":(String)serviceRegistry.getNodeService().getProperty(currentUserNode, ContentModel.PROP_LASTNAME));     
            cancelWorkflowFromMail=getPersonEmail(currentLoginUserName);
            } else{
            	currentUserFullName="Doc Exchange";
            	currentLoginUserName="N/A";
            	cancelWorkflowFromMail=UNPUBLISH_FROM_MAIL;
            }
            //check current user is a admin for auto unpublish
            if(serviceRegistry.getAuthorityService().isAdminAuthority(currentLoginUserName)){
            	currentUserFullName="Doc Exchange";
            	isAutoUnPublish=true;
            }
            String unpublishDocName = (String) nodeService.getProperty(node, ContentModel.PROP_TITLE);
            if(unpublishDocName == null || unpublishDocName.equals("")){
            	unpublishDocName = (String) nodeService.getProperty(node, ContentModel.PROP_NAME);
            	}
           
            
            unpublishUsersEmailList=getUnpublishUserEmailList(node,isAutoUnPublish);
            String fromMail = UNPUBLISH_FROM_MAIL;
            templateService = serviceRegistry.getTemplateService();
            String subject = unpublishDocName + UNPUBLISH_SUBJECT;
           // NodeRef template = getEmailtemplate(UNPUBLISH_NOTIFICATION_TEMPLATE);
           // NodeRef checktemplate = getEmailtemplate(UNPUBLISH_TEMPLATE);
            LOGGER.info("outside aspect working copy");
            
                      
            if (action.equals("unpublish"))
            {
            	reasonForCancel=CANCEL_UNPUBLISH_DESCRIPTION;
            }else{
            	reasonForCancel=CANCEL_REPUBLISH_DESCRIPTION;
            }
            if (LOGGER.isDebugEnabled())
            {
            LOGGER.debug("unpublish Document Name : " + unpublishDocName);
            LOGGER.debug("unpublish Document Version : " + documentVersionLabel);
            LOGGER.debug("current login user :" + currentLoginUserName);
            LOGGER.debug("current login user full name :" + currentUserFullName);
            LOGGER.debug("reason for cancellation : " + reasonForCancel);
            LOGGER.debug("unpublishUsersEmailList before send mail : " + unpublishUsersEmailList);
            LOGGER.debug("user action for util unpublish and workflow : " + action);
            }
            Map<String, Object> model = new HashMap<String, Object>();
            model.put("docName", unpublishDocName);
            model.put("version", documentVersionLabel);
            model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
            model.put("year", year); 
            model.put("reasonForCancel", reasonForCancel);
            model.put("currentUserFullName", currentUserFullName);
            String htmlBody = templateService.processTemplate(UNPUBLISH_NOTIFICATION_TEMPLATE, model);
            String htmlbody = templateService.processTemplate(UNPUBLISH_TEMPLATE, model);
            
            boolean isDocCheckedOut = serviceRegistry.getNodeService().hasAspect(node, ContentModel.ASPECT_CHECKED_OUT);
            boolean cancelWF = true;
            LOGGER.info("before starting action unpublish" + isDocCheckedOut);
            if (action.equals("unpublish") || isDocCheckedOut)
            {
            	//uthra start
            	
            	if(isDocCheckedOut){
            		//new
            		SimpleDateFormat dtformat=new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy"); //EEE MMM dd HH:mm:ss Z yyyy
            		SimpleDateFormat formatneeded=new SimpleDateFormat("YYYY-MM-dd");
            		String expiryDate = serviceRegistry.getNodeService().getProperty(node, MigrationConstants.CISCO_EXTERNAL_PUBLISH_EXPIRATION_DATE_PROP).toString();
            		Date expirationdate = dtformat.parse(expiryDate);
            		String expirydf =formatneeded.format(expirationdate);
            		Date date = new Date();
            		String currentdate = formatneeded.format(date);
       		        if(expirydf.equalsIgnoreCase(currentdate)){
       		        	LOGGER.info(" auto unpublish mail starts ....");
       		        	if(unpublishUsersEmailList != null && unpublishUsersEmailList.size() > 0){
       		        		MailUtil.sendMail(MAIL_SERVER, fromMail, unpublishUsersEmailList.toArray(new String[unpublishUsersEmailList.size()]), null, subject, htmlBody, null);
       		        	} else{
       		        		LOGGER.info("Email Receipients are not found for the node : " + node);
       		        	}
       		        	
       		        }
       		        else{
                    //end
            		cancelWF = false;
				LOGGER.info("Document is Locked...can not unpublish the document");
             	String lockOwner = serviceRegistry.getNodeService().getProperty(node, ContentModel.PROP_LOCK_OWNER).toString();
            			LOGGER.info("lockOwner :: "+lockOwner);
            			String cancelsubject = unpublishDocName + CANCEL_UNPUBLISH_SUBJECT + lockOwner + CANCEL_UNPUBLISH_CHECKEDOUTSUBJECT;
            			 //String cancelsubject = unpublishDocName + CANCEL_UNPUBLISH_SUBJECT;
            		 if(unpublishUsersEmailList != null && unpublishUsersEmailList.size() > 0){
            			 MailUtil.sendMail(MAIL_SERVER, fromMail, unpublishUsersEmailList.toArray(new String[unpublishUsersEmailList.size()]), null, cancelsubject, htmlbody, null);
            		 } else {
            			 LOGGER.error("Email Receipients are not found for the node :: "+node);
            		 }
           		             	             	
             }
            	}
             //uthra end
            	 else{
            		 LOGGER.info("unpublish mail starts....");
            if(unpublishUsersEmailList != null && unpublishUsersEmailList.size() > 0){
            	MailUtil.sendMail(MAIL_SERVER, fromMail, unpublishUsersEmailList.toArray(new String[unpublishUsersEmailList.size()]), null, subject, htmlBody, null);
            } else {
            	LOGGER.error("Email Receipients are not found while sending email for the node : " + node);
            }
                     }
            }
            LOGGER.info("after all changes......");
            //end of unpublish document mail code
            // start of cancel workflow mail code
            // Get all Active Workflows
           // if(action.equals("unpublish") && serviceRegistry.getNodeService().hasAspect(node, ContentModel.ASPECT_CHECKED_OUT)){}
            if (cancelWF){
            workflows.addAll(workflowService.getWorkflowsForContent(node, true));
            LOGGER.debug("workflows on node is :  " + workflows);
            if (workflows != null && workflows.size() > 0)
            {
                // list out all the workflows the document is part of
                for (WorkflowInstance wi : workflows)
                {
                    WorkflowTaskQuery tasksQuery = new WorkflowTaskQuery();
                    tasksQuery.setTaskState(null);
                    tasksQuery.setActive(null);
                    tasksQuery.setProcessId(wi.getId());
                    List<WorkflowTask> tasks = workflowService.queryTasks(tasksQuery, false);
                    for (WorkflowTask task : tasks)
                    {
                        String workflowInstanceId = wi.getId();
                        workflowInstanceId = workflowInstanceId.substring(workflowInstanceId.indexOf("$") + 1);
                        /*if (wi.getInitiator() != null)
                        {
                            String requestor = (String) nodeService.getProperty(wi.getInitiator(),
                                ContentModel.PROP_USERNAME);
                            //workflowUsersEmailList.add(getPersonEmail(requestor));
                        }*/
                        Map<QName, Serializable> taskProp = task.getProperties();
                        String personEmail = getPersonEmail((String) taskProp.get(ContentModel.PROP_OWNER));
                        workflowUsersEmailList.add(personEmail);
                        if (LOGGER.isDebugEnabled())
	                    {
                        LOGGER.debug("personEmail : " + personEmail);
                        LOGGER.debug("unpublishDocName : " + unpublishDocName);
	                    }
                        try
                        {
                            String cancelSubject =currentUserFullName+CANCELUNPUBLISH_SUBJECT+unpublishDocName;
                            //NodeRef cancelTemplate = getEmailtemplate(CANCELUNPUBLISH_NOTIFICATION_TEMPLATE);
                            String cancelHtmlBody = templateService.processTemplate(CANCELUNPUBLISH_NOTIFICATION_TEMPLATE, model);
                            if (!task.getId().equals(workflowService.getStartTask(wi.getId()).getId()))
                            {
                                String taskStatus = task.getState().toString();
                                if (LOGGER.isDebugEnabled())
    		                    {
                                LOGGER.debug("workflowUsersEmailList before send mail : " + workflowUsersEmailList);
                                LOGGER.debug("Workflow task status is  : " + taskStatus);
                                LOGGER.debug("Workflow task Id is  : " + task.getId());
    		                    }
                               
                              //US9853-start of Opt in/out Email Notification
                                NodeRef wfPersonNode = serviceRegistry.getPersonService().getPerson((String) taskProp.get(ContentModel.PROP_OWNER));
                  	        	boolean optOutEmailNotification=optOutEmailNotify(wfPersonNode);
                              if(isAutoUnPublish){
                            	  if(optOutEmailNotification){
                            		  if (taskStatus.equals(TASK_IN_PROGRESS))
                                      {
                                          cancelWorkflow(node, task, currentLoginUserName);
                                          LOGGER.debug("canceled Workflow successfully.");
                                      }
                            	  }else{
                                      if (MailUtil.sendMail(MAIL_SERVER, cancelWorkflowFromMail,
                                          workflowUsersEmailList.toArray(new String[workflowUsersEmailList.size()]), null, cancelSubject,
                                          cancelHtmlBody, null))
                                      {
                                          if (taskStatus.equals(TASK_IN_PROGRESS))
                                          {
                                              cancelWorkflow(node, task, currentLoginUserName);
                                              LOGGER.debug("canceled Workflow successfully.");
                                          }
                                      }
                                     }
                              }else{
                            	  if (MailUtil.sendMail(MAIL_SERVER, cancelWorkflowFromMail,
                                          workflowUsersEmailList.toArray(new String[workflowUsersEmailList.size()]), null, cancelSubject,
                                          cancelHtmlBody, null))
                                      {
                                          if (taskStatus.equals(TASK_IN_PROGRESS))
                                          {
                                              cancelWorkflow(node, task, currentLoginUserName);
                                              LOGGER.debug("canceled Workflow successfully.");
                                          }
                                      } 
                              }
                            }
                           // LOGGER.debug("unpublishUsersEmailList After send mail : " + unpublishUsersEmailList);
                            workflowUsersEmailList.clear();
                            //unpublishUsersEmailList.clear();
                            //end of cancel workflow mail code
                        }
                        catch (Exception e)
                        {
                            LOGGER.error("mail Exception : " + e);
                            e.printStackTrace();
                        }
                        // mail code end----------
                    }
                }
                //unpublishUsersEmailList.clear();
                LOGGER.info("Mail Sent sucessfully.");
            }
        }else {
            	 LOGGER.info("This document is not part of any workflows to cancel.");
            }
        }
        catch (Exception e)
        {
            LOGGER.error("WFMailRootscopedObject Exception : " + e);
        }
    }

    /**
     * 
     * @param docNodeRef
     * @param task
     * @param currentUser
     * @return
     */
    private void cancelWorkflow(NodeRef docNodeRef, WorkflowTask task, String currentUser)
    {
        try
        {
            propertyUpdates(docNodeRef);
            Map<QName, Serializable> parameters = task.getProperties();
            parameters.put(WorkflowModel.PROP_COMMENT, "Document Cancelled by " + currentUser);
            parameters.put(WorkflowModel.PROP_OUTCOME, "cancel");
            if (LOGGER.isDebugEnabled())
            {
            LOGGER.debug("Upadted taskid in rootscoped cancel workflow is : " + task.getId());
            }
            workflowService.updateTask(task.getId(), parameters, null, null);
            workflowService.endTask(task.getId(), "cancel");
        }
        catch (Exception e)
        {
            LOGGER.error("Failed to cancel workflows", e);
        }
    }

    /**
     * 
     * @param nodeRef
     */
    private void propertyUpdates(NodeRef nodeRef)
    {
        nodeService.setProperty(nodeRef, CiscoModelConstants.PROP_DOC_STATUS, "Draft");
        nodeService.setProperty(nodeRef, CiscoModelConstants.CISCO_WORKFLOW_STATUS_PROP, "Cancelled");
    }

    /**
     * To Get Email Template
     */
   /* private NodeRef getEmailtemplate(String templateName)
    {

        String templateConditionalPath = "PATH:\"" + FTL_FILEPATH + "//*\" AND "
                + "TYPE:cm\\:content AND @cm\\:name:\"" + templateName + "\"";
        if (LOGGER.isDebugEnabled())
        {
        LOGGER.debug("LUCENE QRY: " + templateConditionalPath);
        }
        ResultSet resultSet = serviceRegistry.getSearchService().query(
            new StoreRef(StoreRef.PROTOCOL_WORKSPACE, "SpacesStore"), SearchService.LANGUAGE_LUCENE,
            templateConditionalPath);
        if (resultSet.length() == 0)
        {
            LOGGER.error("Template " + templateConditionalPath + " not found.");
            return null;
        }
        NodeRef template = resultSet.getNodeRef(0);
        LOGGER.info("Got the Email Template:" + template.toString());
        return template;
    }*/

    public String getPersonEmail(String userName)
    {

        NodeRef personNodeRef = serviceRegistry.getPersonService().getPerson(userName, false);
        if (LOGGER.isDebugEnabled())
        {
        LOGGER.debug("personNodeRef is : " + personNodeRef);
        }
        return (String) serviceRegistry.getNodeService().getProperty(personNodeRef, ContentModel.PROP_EMAIL);

    }
    private String getVersionNum(NodeRef nodeRef)
    {
    	
        if ((String) nodeService.getProperty(nodeRef, ContentModel.PROP_VERSION_LABEL) != null){
            return  (String) nodeService.getProperty(nodeRef, ContentModel.PROP_VERSION_LABEL);
        }else{
            return "1.0";
        }
    }
    
    private HashSet<String> getUnpublishUserEmailList(NodeRef nodeRef,boolean isAutoUnPublish){
    	HashSet<String> authority = new HashSet<String>();
    	try{
  	  PermissionService permissionService = this.serviceRegistry.getPermissionService();
  	  Set<AccessPermission> accessPermissions = permissionService.getAllSetPermissions(nodeRef);
  	  //LOGGER.debug("Inherited Permissions: "+permissionService.getInheritParentPermissions(nodeRef));
  	  Iterator<AccessPermission> fIterator = accessPermissions.iterator();
  	    while (fIterator.hasNext())
  	    {
  	      AccessPermission accessPermission = (AccessPermission)fIterator.next();
  	      if (accessPermission.getAuthorityType() == AuthorityType.USER)
  	      {
  	   //    LOGGER.debug("Authority(User): " + accessPermission.getAuthority() + " Permission:  " +accessPermission.getPermission());
  	       if(accessPermission.getPermission().equalsIgnoreCase("OwnerRole")){
	  	        PersonService personService = this.serviceRegistry.getPersonService();
	  	        NodeRef personNode = personService.getPerson(accessPermission.getAuthority());
	  	       // LOGGER.debug("Person Propeties:: " + this.serviceRegistry .getProperties(per).get(ContentModel.PROP_ORGANIZATION));
	  	      if(isAutoUnPublish){
	    	        //US9853-start of Opt in/out Email Notification
	    	        	boolean optOutEmailNotification=optOutEmailNotify(personNode);
	    	        	if(optOutEmailNotification){
	    	        		LOGGER.info("AutoUnPublish User is Opt out Email Notifications:::::::::::::"+accessPermission.getAuthority());
	    	        	}else{
	    	        		String email = (String)this.serviceRegistry.getNodeService().getProperties(personNode).get(ContentModel.PROP_EMAIL);
		    	  	        LOGGER.info("isAutoUnPublish and isRequiredEmailNotify email:::::::::::::"+email);
		    	        	 authority.add(email);
	    	        	}
	    	        //US9853-end of Opt in/out Email Notification
	    	        }else{
	    	        	String email = (String)this.serviceRegistry.getNodeService().getProperties(personNode).get(ContentModel.PROP_EMAIL);
	    	  	        LOGGER.info("UnPublish email:::::::::::::"+email);
	    	        	 authority.add(email);
	    	        }
  	    	  }
  	      }
  	    }
  	  if (LOGGER.isDebugEnabled())
      {
  	  LOGGER.debug("document users emial list for send mail : " + authority.toString());
      } 
     
    }catch(Exception e){
    	LOGGER.error("Error in getUnpublishUserEmailList : "+e.getMessage());	
    }
    	 return authority;
    }
  //US9853-start of Opt in/out Email Notification
    private boolean optOutEmailNotify(NodeRef personNode){
    	 boolean optOutEmailNotify=false;
    	 boolean hasEmailNotificationAspect =false;
    	 hasEmailNotificationAspect = serviceRegistry.getNodeService().hasAspect(personNode, ExternalSharingConstants.ASPECT_OPTINOUT_EMAIL_NOTIFICATION);
	          if(hasEmailNotificationAspect){
	        	  optOutEmailNotify = (Boolean) serviceRegistry.getNodeService().getProperty(personNode, ExternalSharingConstants.PROP_OPTOUT_EMAIL_NOTIFY);
	          }
    	 
		return optOutEmailNotify;
    }
    //US9853-end of Opt in/out Email Notification
}