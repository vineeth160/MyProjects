package com.cisco.alfresco.ext.workflow.util;

public interface ExtWorkflowConstants {

	public final String TASKLIST = "tasklist";
	public final String TASKDETAILS = "taskdetails";
	public final String START = "start";
	public final String APPROVE = "approve";
	public final String REJECT = "reject";
	public final String RESUBMIT = "resubmit";
	public final String REVIEW = "review";
	//public final String CANCELWORKFLOW = "cancel";
	public final String ALFRESCO_URL = "alfresco.url"; 
	public final String WORKFLOW_NAME = "activiti$externalSharingProcess";
	public final String RESUBMIT_TASK = "Resubmit Task";
	public final String REVIEW_TASK = "Review Task";
	
}
