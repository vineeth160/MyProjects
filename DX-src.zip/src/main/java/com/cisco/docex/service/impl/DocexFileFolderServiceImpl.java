package com.cisco.docex.service.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.query.PagingRequest;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileFolderService;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.ContentData;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.Path;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.site.SiteInfo;
import org.alfresco.service.namespace.InvalidQNameException;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.namespace.RegexQNamePattern;
import org.alfresco.util.ISO9075;
import org.alfresco.util.Pair;
import org.apache.log4j.Logger;

import com.cisco.alfresco.external.common.model.ExtDocument;
import com.cisco.alfresco.external.common.model.Folder;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.alfresco.external.utils.CharUtil;
import com.cisco.alfresco.external.webscript.UserRoleConstants;
import com.cisco.docex.service.DocexDomainService;
import com.cisco.docex.service.DocexFileFolderService;
import com.cisco.docex.transferobjects.outbound.SupportGroupFileFolderOutbound;
import com.cisco.sd.rest.service.MigrationConstants;

public class DocexFileFolderServiceImpl implements DocexFileFolderService {

	private static final Logger LOGGER = Logger.getLogger(DocexFileFolderServiceImpl.class);
	private FileFolderService fileFolderService;
	private ServiceRegistry serviceRegistry;
	private NodeService nodeService;
	private DocexDomainService dxDomainService;
	private static final String GROUP_EVERYONE = "GROUP_EVERYONE";
	private String alfrescoURL;
	private String contextName;
	private int pageSize;
	private static ExternalLDAPUtil ldapUtil;
	String SITE_NAME = "edcsng";
	

	@Override
	public SupportGroupFileFolderOutbound getSupportGroupFileFolders(String docexUserName,
			Map<String, Object> paramMap) {

		String strNodeRef = (String) paramMap.get("id");
		AuthenticationUtil.setAdminUserAsFullyAuthenticatedUser();
		NodeRef nodeRef = null;
		if (strNodeRef != null && strNodeRef.length() > 0) {
			nodeRef = new NodeRef(strNodeRef);
		} else {
			nodeRef = getSiteDocLibNodeRef(SITE_NAME);
		}

		SupportGroupFileFolderOutbound fileFolderOutbound = new SupportGroupFileFolderOutbound();
		String managerEmailId = ldapUtil.getManagerEmailFromLDAP(docexUserName);

		boolean isFolderEmpty = false;
		try {
			QName PROP_CONTENT_SIZE = QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, "content.size");
			String pageNo = (String) paramMap.get("pageNo");
			String sortBy = (String) paramMap.get("sortBy");
			String sortOrder = (String) paramMap.get("sortOrder");
			String hostname = (String) paramMap.get("geoHostName");
			String pageSizeString = (String) paramMap.get("pageSize");
			int pageNum;
			if (pageNo == null || pageNo == "" || pageNo.isEmpty()) {
				pageNum = 1;
			} else {
				pageNum = Integer.parseInt((String) paramMap.get("pageNo"));
			}
			if (pageSizeString != null && !(pageSizeString.isEmpty())) {
				pageSize = Integer.parseInt(pageSizeString);
			}

			// Pagination
			PagingRequest paging = new PagingRequest(0, Integer.MAX_VALUE, null);
			boolean isAscOrder = false;
			if (sortOrder == null || sortOrder == "" || ("asc").equalsIgnoreCase(sortOrder)) {
				isAscOrder = true;
				sortOrder = "asc";
			}
			// Sorting
			List<Pair<QName, Boolean>> sort = new ArrayList<Pair<QName, Boolean>>();
			if (sortBy == null || sortBy == "" || ("modified").equalsIgnoreCase(sortBy)) {
				sortBy = "modified";
				sort.add(new Pair<QName, Boolean>(ContentModel.PROP_MODIFIED, isAscOrder));
			} else if (("name").equalsIgnoreCase(sortBy)) {
				sort.add(new Pair<QName, Boolean>(ContentModel.PROP_NAME, isAscOrder));
			} else if (("expirationDate").equalsIgnoreCase(sortBy)) {
				sort.add(new Pair<QName, Boolean>(ExternalSharingConstants.PROP_EXPIRAIONDATE, isAscOrder));
			}

			else if (("size").equalsIgnoreCase(sortBy)) {
				sort.add(new Pair<QName, Boolean>(PROP_CONTENT_SIZE, isAscOrder));
			}

			else if (("edcsId").equalsIgnoreCase(sortBy)) {
				sort.add(new Pair<QName, Boolean>(ExternalSharingConstants.PROP_EDCS_ID, isAscOrder));
			}

			int totalResults = 0;
			List<FileInfo> folderInfoList = new ArrayList<FileInfo>();
			Set<QName> excludeQname = new HashSet<>(1);
			excludeQname.add(ContentModel.ASPECT_CHECKED_OUT);

			if (("type").equalsIgnoreCase(sortBy)) {
				LOGGER.debug("-------inside sort by type ---------");
				folderInfoList = fileFolderService.list(nodeRef, true, true, excludeQname, null, paging).getPage();
				if (sortOrder == null || sortOrder == "" || sortOrder.equalsIgnoreCase("asc")) {
					folderInfoList.sort((FileInfo f1, FileInfo f2) -> f1.getName()
							.substring(f1.getName().lastIndexOf(".") + 1, f1.getName().length()).compareTo(
									f2.getName().substring(f2.getName().lastIndexOf(".") + 1, f2.getName().length())));
				} else {
					folderInfoList.sort((FileInfo f1, FileInfo f2) -> f2.getName()
							.substring(f2.getName().lastIndexOf(".") + 1, f2.getName().length()).compareTo(
									f1.getName().substring(f1.getName().lastIndexOf(".") + 1, f1.getName().length())));
				}
			} else {
				// getting folders list
				folderInfoList = fileFolderService.list(nodeRef, false, true, excludeQname, sort, paging).getPage();
				// getting files list
				folderInfoList
						.addAll(fileFolderService.list(nodeRef, true, false, excludeQname, sort, paging).getPage());
			}
			totalResults = folderInfoList.size();

			LOGGER.debug("totalResults---> " + totalResults);
			LOGGER.debug("folderInfoList---> " + folderInfoList);
			// Retrieving per page items only
			int startRow = 0;
			int endRow = 0;
			if (pageNum != 0) {
				startRow = (pageNum - 1) * pageSize;
				endRow = startRow + pageSize;
			}
			startRow = startRow == 0 ? startRow : startRow;
			endRow = endRow > totalResults ? totalResults : endRow - 1;
			@SuppressWarnings("rawtypes")
			List<ArrayList> searchList = new ArrayList<ArrayList>();
			searchList = getFileFolderList(folderInfoList, docexUserName, isFolderEmpty, hostname, startRow, endRow,
					pageNum, managerEmailId);
			LOGGER.debug("searchList  ::" + searchList);

			List<Folder> breadcrumbLst = new ArrayList<Folder>();
			Folder folderInfo = getNodeRefProperties(nodeRef,isFolderEmpty, docexUserName, managerEmailId);
			if (!folderInfo.getName().equalsIgnoreCase("Document Library")) {
				getAllParentNodeRef(nodeRef, breadcrumbLst, docexUserName,managerEmailId);
				//Collections.reverse(breadCrumbNodeLst);
			}
			Collections.reverse(breadcrumbLst);
			breadcrumbLst.add(folderInfo);
			/*List<Folder> folderInfo = new ArrayList<Folder>();
			folderInfo = getNodeRefProperties(nodeRef, folderInfo, isFolderEmpty, docexUserName, managerEmailId);*/
			// model.put("result", searchList);
			if (searchList.size() > 1) {
				fileFolderOutbound.addChildren(searchList.get(0));
				fileFolderOutbound.addChildren(searchList.get(1));

			} else {
				fileFolderOutbound.setChildren(searchList.get(0));
			}

			fileFolderOutbound.setBreadCrumbList(breadcrumbLst);
			// fileFolderOutbound.setFolderInfo(folderInfo);
			fileFolderOutbound.setNodeRefId(nodeRef.toString());
			fileFolderOutbound.setPermissionLevel(getUserRole(docexUserName, nodeRef));
			fileFolderOutbound.setTotalCount(totalResults);
			fileFolderOutbound.setPageNo(pageNum);
			fileFolderOutbound.setPageSize(pageSize);

			if (sortOrder != null || sortOrder != "" || !sortOrder.isEmpty()) {
				fileFolderOutbound.setSortOrder(sortOrder);
			}

			if (sortBy != null || sortBy != "" || !sortBy.isEmpty()) {
				fileFolderOutbound.setSortBy(sortBy);
			}
			fileFolderOutbound.setHasFolderAccess(true);

		} catch (InvalidNodeRefException ine) {
			LOGGER.error("InvalidNodeRefException : " + ine);
			ine.printStackTrace();
		} catch (Exception e) {
			LOGGER.error("Exception : " + e);
			e.printStackTrace();
		}
		LOGGER.debug("--- Finished in ExternalSharingFileFolderList ---");
		// return model;
		return fileFolderOutbound;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<ArrayList> getFileFolderList(List<FileInfo> fileInfoList, String currentUser, boolean isFolderEmpty,
			String hostname, int startRow, int endRow, int pageNum, String managerEmailId) {

		ArrayList fileFolderList = new ArrayList<ArrayList>();
		ArrayList<ExtDocument> listFolder = new ArrayList<ExtDocument>();
		ArrayList<ExtDocument> listExtDocs = new ArrayList<ExtDocument>();
		try {
			LOGGER.debug("current user : " + currentUser);
			LOGGER.debug("startRow ----------------> " + startRow + " \t endRow ----------------> " + endRow);
			if (!fileInfoList.isEmpty()) {
				for (int fldIndex = startRow; (fldIndex < fileInfoList.size() && fldIndex <= endRow); fldIndex++) {
					LOGGER.debug("Getting  folderInfoList.get(" + fldIndex + ") ----------------> ");
					FileInfo fileInfo = fileInfoList.get(fldIndex);
					NodeRef nodeRef = fileInfo.getNodeRef();
					LOGGER.debug("nodeRef : " + nodeRef);
					ExtDocument extAlfNodeDetails = new ExtDocument();
					Map<QName, Serializable> nodeProp = fileInfo.getProperties();

					String fileName = CharUtil.replaceEscape((String) nodeProp.get(ContentModel.PROP_NAME));
					String title = CharUtil.replaceEscape((String) nodeProp.get(ContentModel.PROP_TITLE));
					String description = CharUtil.replaceEscape((String) nodeProp.get(ContentModel.PROP_DESCRIPTION));

					extAlfNodeDetails.setName(ISO9075.decode(fileName));
					extAlfNodeDetails.setTitle(ISO9075.decode(title));
					extAlfNodeDetails.setDescription(ISO9075.decode(description));
					extAlfNodeDetails.setNodeId(nodeRef.toString());
					extAlfNodeDetails.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
					extAlfNodeDetails.setCreationdate(ExternalSharingFileFolderUtil
							.getGMTDateFormat(((Date) nodeProp.get(ContentModel.PROP_CREATED))));
					extAlfNodeDetails.setModifieddate(ExternalSharingFileFolderUtil
							.getGMTDateFormat(((Date) nodeProp.get(ContentModel.PROP_MODIFIED))));

					if (fileInfo.getType().equals(ContentModel.TYPE_FOLDER)) {
						isFolderEmpty = true;
						Path path = nodeService.getPath(nodeRef);
						String filePath = "";
						if (path != null) {
							filePath = path.toString();
							filePath = filePath.replaceAll(
									"\\{http://www.alfresco.org/model/application/1.0\\}|\\{http://www.alfresco.org/model/site/1.0\\}|\\{http://www.alfresco.org/model/content/1.0\\}",
									"");
						}
						extAlfNodeDetails.setType(ContentModel.TYPE_FOLDER.getLocalName());
						extAlfNodeDetails.setRelativePath(ISO9075.decode(filePath));

						if (dxDomainService.getDomainStatus(nodeRef.toString(), managerEmailId)
								.get("status1") == "401") {
							LOGGER.debug("in if inside 401-------");
							extAlfNodeDetails.setDomainMismatch(false);
						} else {
							extAlfNodeDetails.setDomainMismatch(true);
						}

						extAlfNodeDetails.setApplyVeraProtection(
								(String) nodeProp.get(ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION));
						extAlfNodeDetails.setPermissionLevel(getUserRole(currentUser, nodeRef));
						extAlfNodeDetails.setFolderEmpty(isFolderEmpty);

						if (nodeService.hasAspect(nodeRef, MigrationConstants.CISCO_EXTERNAL_SHARAEABLE_ASPECT)) {
							extAlfNodeDetails.setCreatedInDocExchange(false);
						} else {
							extAlfNodeDetails.setCreatedInDocExchange(true);
						}

						String tagName = "";
						if (nodeService.hasAspect(nodeRef, ExternalSharingConstants.CISCO_TAG_ASPECT)) {
							tagName = (String) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
							LOGGER.debug("tagName :: " + tagName);
						}
						extAlfNodeDetails.setTags(tagName);
						listFolder.add(extAlfNodeDetails);
					} else {
						if (!nodeService.hasAspect(nodeRef, ContentModel.ASPECT_CHECKED_OUT)) {
							String strVersion = (String) nodeProp.get(ContentModel.PROP_VERSION_LABEL);
							double version = Double.parseDouble((strVersion != null ? strVersion : "1.0"));
							extAlfNodeDetails.setVersion(version);
							Boolean issynced = false;
							String tempMimeType = "";
							String nodeUploadedGeolocation = null;
							LOGGER.debug("nodeRef :: " + nodeRef + "         fileName  :: " + fileName);
							if (nodeService.hasAspect(nodeRef, ExternalSharingConstants.CISCO_GLOBAL_CACHING_ASPECT)) {
								issynced = (Boolean) nodeProp
										.get(ExternalSharingConstants.CISCO_QNAME_IS_FILE_SYNCHED_PROP);
								if (issynced != null && !issynced) {
									Long size = (Long) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_GCS_TEMP_SIZE);
									tempMimeType = (String) nodeProp
											.get(ExternalSharingConstants.CISCO_QNAME_GCS_TEMP_MIMETYPE);
									extAlfNodeDetails.setSize((int) (size != null ? size : 0));
									LOGGER.debug("size not synced :: " + size + " tempMimeType :: " + tempMimeType);
								} else {
									long size = nodeProp.get(ContentModel.PROP_CONTENT) != null
											? ((ContentData) nodeProp.get(ContentModel.PROP_CONTENT)).getSize()
											: 0;
									extAlfNodeDetails.setSize((int) (size));
									if (issynced == null)
										issynced = true;
								}
								nodeUploadedGeolocation = (String) nodeProp
										.get(ExternalSharingConstants.CISCO_QNAME_UPLOAD_GELOLOCATION_PROP);
								LOGGER.debug("nodeUploadedGeolocation :: " + nodeUploadedGeolocation);

							} else {
								issynced = true;
								LOGGER.debug("issynced :: " + issynced);
								long size = nodeProp.get(ContentModel.PROP_CONTENT) != null
										? ((ContentData) nodeProp.get(ContentModel.PROP_CONTENT)).getSize()
										: 0;
								extAlfNodeDetails.setSize((int) (size));
								LOGGER.debug("size :: " + size);
							}
							extAlfNodeDetails.setSynced(issynced);
							if (tempMimeType == null || tempMimeType.isEmpty()) {
								extAlfNodeDetails
										.setMimetype((ContentData) nodeProp.get(ContentModel.PROP_CONTENT) != null
												? ((ContentData) nodeProp.get(ContentModel.PROP_CONTENT)).getMimetype()
												: "");
							} else {
								extAlfNodeDetails.setMimetype(tempMimeType);
							}
							// Extra Attributes
							String lockType = (String) nodeProp.get(ContentModel.PROP_LOCK_TYPE);
							String edcsId = (String) nodeProp.get(ExternalSharingConstants.PROP_EDCS_ID);
							LOGGER.debug("Locktype:" + lockType);
							extAlfNodeDetails.setLocked(lockType != null ? true : false);
							extAlfNodeDetails
									.setSecurity((String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY));
							extAlfNodeDetails.setModifier((String) nodeProp.get(ContentModel.PROP_MODIFIER));
							extAlfNodeDetails
									.setType(fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length()));
							extAlfNodeDetails.setShareUrl((String) nodeProp.get(ContentModel.PROP_NODE_UUID));
							String en_name = ISO9075.encode(fileName);
							NodeRef folderId = nodeService.getPrimaryParent(nodeRef).getParentRef();
							String downloadUrl = null;
							String applyVeraProtection = ExternalSharingFileFolderUtil
									.getFolderVeraProtectionStatus(nodeRef, serviceRegistry);
							if (applyVeraProtection != null
									&& ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals(
											(String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))) {
								extAlfNodeDetails.setApplyVeraProtection(applyVeraProtection);
							} else {
								extAlfNodeDetails.setApplyVeraProtection("");
							}

							if (nodeUploadedGeolocation != null && hostname != null) {
								if (issynced != null && !issynced) {
									String redirectUrl = "https://" + nodeUploadedGeolocation;
									LOGGER.debug("redirectUrl  :: " + redirectUrl); // redirect to the server where it
																					// was uploaded
									if (applyVeraProtection != null && ("All Contents".equals(applyVeraProtection)
											|| applyVeraProtection.equals((String) nodeProp
													.get(ExternalSharingConstants.PROP_EXT_SECURITY)))) {
										downloadUrl = alfrescoURL + contextName + "/ext/download/"
												+ nodeRef.toString().replace(":/", "") + "/" + en_name + ".html?a=true";
									} else {
										downloadUrl = redirectUrl + contextName + "/ext/download/"
												+ nodeRef.toString().replace(":/", "") + "/" + en_name + "?a=true";
									}
									LOGGER.debug("downloadurl in redirction  :: " + downloadUrl);

								} else {
									// its synced so sync central repository
									if (applyVeraProtection != null && ("All Contents".equals(applyVeraProtection)
											|| applyVeraProtection.equals((String) nodeProp
													.get(ExternalSharingConstants.PROP_EXT_SECURITY)))) {
										downloadUrl = alfrescoURL + contextName + "/ext/download/"
												+ nodeRef.toString().replace(":/", "") + "/" + en_name + ".html?a=true";
									} else {
										downloadUrl = "https://" + hostname + contextName + "/ext/download/"
												+ nodeRef.toString().replace(":/", "") + "/" + en_name + "?a=true"; // need
																													// to
																													// check
									}
									LOGGER.debug("downloadurl sync value true so download from central repo :: "
											+ downloadUrl);

								}
							} else {
								if (applyVeraProtection != null
										&& ("All Contents".equals(applyVeraProtection) || applyVeraProtection.equals(
												(String) nodeProp.get(ExternalSharingConstants.PROP_EXT_SECURITY)))) {
									downloadUrl = alfrescoURL + contextName + "/ext/download/"
											+ nodeRef.toString().replace(":/", "") + "/" + en_name + ".html?a=true";
								} else {
									downloadUrl = alfrescoURL + contextName + "/ext/download/"
											+ nodeRef.toString().replace(":/", "") + "/" + en_name + "?a=true";
								}
								LOGGER.debug("downloadurl  :: " + downloadUrl);
							}

							LOGGER.debug("Download URL:" + downloadUrl);
							extAlfNodeDetails.setDownloadUrl(downloadUrl);
							extAlfNodeDetails.setPermissionLevel(getUserRole(currentUser, nodeRef));
							extAlfNodeDetails.setEdcsId(edcsId);
							extAlfNodeDetails
									.setDocStatus((String) nodeProp.get(ExternalSharingConstants.PROP_DOCSTATUS));
							extAlfNodeDetails.setWorkflowStatus(
									(String) nodeProp.get(ExternalSharingConstants.PROP_WORKFLOWSTATUS));
							extAlfNodeDetails.setExpirationDate(ExternalSharingFileFolderUtil.getGMTDateFormat(
									((Date) nodeProp.get(ExternalSharingConstants.PROP_EXPIRAIONDATE))));
							boolean canUserCancelWorkflow = ExternalSharingFileFolderUtil
									.canUserCancelWorkflow(serviceRegistry, nodeRef);
							extAlfNodeDetails.setCanUserCancelWorkflow(canUserCancelWorkflow);
							boolean isPublishedInternally = false;
							if (edcsId != null && edcsId.contains("EDCS-")) {
								isPublishedInternally = true;
							}
							extAlfNodeDetails.setExternalyShared(isPublishedInternally);

							if (dxDomainService.getDomainStatus(nodeRef.toString(), managerEmailId)
									.get("status1") == "401") {
								LOGGER.debug("in if inside 401-------");
								extAlfNodeDetails.setDomainMismatch(false);
							} else {
								extAlfNodeDetails.setDomainMismatch(true);
							}

							boolean canUserCancelCheckout = false;
							String workingCopyOwner = null;
							boolean isCheckedOut = false;
							NodeRef originalnoderef = null;
							if (nodeService.hasAspect(nodeRef, ContentModel.ASPECT_WORKING_COPY)) {
								isCheckedOut = true;
								workingCopyOwner = nodeProp.get(ContentModel.PROP_WORKING_COPY_OWNER).toString();
								originalnoderef = (NodeRef) serviceRegistry.getCheckOutCheckInService()
										.getCheckedOut(nodeRef);
							}
							if ((workingCopyOwner != null && workingCopyOwner.equals(currentUser))
									|| serviceRegistry.getPermissionService().hasPermission(nodeRef, "AdminRole")
											.toString().equals("ALLOWED")) {
								canUserCancelCheckout = true;
							}
							extAlfNodeDetails.setCheckOutStatus(isCheckedOut);
							extAlfNodeDetails.setCanCancelCheckOut(canUserCancelCheckout);
							extAlfNodeDetails.setWorkingCopyOwner(workingCopyOwner);
							extAlfNodeDetails.setFolderId(folderId.toString());
							String tagName = "";
							if (originalnoderef != null && nodeService.hasAspect(originalnoderef,
									ExternalSharingConstants.CISCO_TAG_ASPECT)) {
								tagName = (String) nodeProp.get(ExternalSharingConstants.CISCO_QNAME_TAG_NAME);
							} else {
								if (nodeService.hasAspect(nodeRef, ExternalSharingConstants.CISCO_TAG_ASPECT)) {
									tagName = nodeProp.get(ExternalSharingConstants.CISCO_QNAME_TAG_NAME).toString();
								}
							}
							extAlfNodeDetails.setTags(tagName);
							listExtDocs.add(extAlfNodeDetails);
						}
					}
				}
			}
			fileFolderList.add(listFolder);
			fileFolderList.add(listExtDocs);

		} catch (InvalidQNameException e) {
			e.printStackTrace();
		} catch (InvalidNodeRefException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return fileFolderList;
	}

	private Folder getNodeRefProperties(NodeRef sourceNodeRef,boolean isFolderEmpty,
			String currentUser, String managerEmailId) {
		LOGGER.debug("current user : " + currentUser);

		Folder folder = new Folder();
		Map<QName, Serializable> nodeProp = nodeService.getProperties(sourceNodeRef);

		String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
		fileName = fileName.equalsIgnoreCase("documentLibrary") ?  "Document Library" : CharUtil.replaceEscape(fileName);
		isFolderEmpty = true;
		folder.setName(ISO9075.decode(fileName));
		folder.setNodeId(sourceNodeRef.toString());
		String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
		title = CharUtil.replaceEscape(title);
		folder.setTitle(ISO9075.decode(title));
		String description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
		description = CharUtil.replaceEscape(description);
		folder.setDescription(ISO9075.decode(description));
		folder.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
		folder.setCreationdate(
				ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp.get(ContentModel.PROP_CREATED))));
		folder.setModifieddate(
				ExternalSharingFileFolderUtil.getGMTDateFormat(((Date) nodeProp.get(ContentModel.PROP_MODIFIED))));
		folder.setType("folder");
		Path path = nodeService.getPath(sourceNodeRef);
		String filePath = "";
		if (path != null) {
			filePath = path.toString();
			filePath = filePath.replaceAll(
					"\\{http://www.alfresco.org/model/application/1.0\\}|\\{http://www.alfresco.org/model/site/1.0\\}|\\{http://www.alfresco.org/model/content/1.0\\}",
					"");
		}
		folder.setRelativePath(ISO9075.decode(filePath));

		if (dxDomainService.getDomainStatus(sourceNodeRef.toString(), managerEmailId).get("status1") == "401") {
			LOGGER.debug("in if inside 401-------");
			folder.setDomainMismatch(false);
		} else {
			folder.setDomainMismatch(true);
		}
		folder.setPermissionLevel(
				ExternalSharingFileFolderUtil.getUserRole(serviceRegistry, currentUser, sourceNodeRef));
		folder.setFolderEmpty(isFolderEmpty);

		folder.setApplyVeraProtection((String) nodeProp.get(ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION));
		folder.setFavoriteStatus(false);
		//breadcrumbLst.add(folder);
		return folder;
	}

	private void getAllParentNodeRef(final NodeRef sourceNodeRef, final List<Folder> breadcrumbLst,
			final String currentUser, final String managerEmailId) {

		try {
			AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				@Override
				public Object doWork() throws Exception {
					LOGGER.debug("current user : " + currentUser);
					List<ChildAssociationRef> parentRefs = nodeService.getParentAssocs(sourceNodeRef,
							ContentModel.ASSOC_CONTAINS, RegexQNamePattern.MATCH_ALL);

					if (parentRefs != null && parentRefs.size() > 0) {	
						LOGGER.debug("parentRefs size....:" + parentRefs.size());
						NodeRef nodeRef = parentRefs.get(0).getParentRef();
								Folder folder = new Folder();
								Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);

								String fileName = (String) nodeProp.get(ContentModel.PROP_NAME);
								fileName = fileName.equalsIgnoreCase("documentLibrary") ?  "Document Library" : CharUtil.replaceEscape(fileName);
								folder.setName(ISO9075.decode(fileName));
								folder.setNodeId(nodeRef.toString());

								String title = (String) nodeProp.get(ContentModel.PROP_TITLE);
								title = CharUtil.replaceEscape(title);
								folder.setTitle(ISO9075.decode(title));

								String description = (String) nodeProp.get(ContentModel.PROP_DESCRIPTION);
								description = CharUtil.replaceEscape(description);
								folder.setDescription(ISO9075.decode(description));

								folder.setOwner((String) nodeProp.get(ContentModel.PROP_CREATOR));
								folder.setCreationdate(ExternalSharingFileFolderUtil
										.getGMTDateFormat(((Date) nodeProp.get(ContentModel.PROP_CREATED))));
								folder.setModifieddate(ExternalSharingFileFolderUtil
										.getGMTDateFormat(((Date) nodeProp.get(ContentModel.PROP_MODIFIED))));
								folder.setType(ContentModel.TYPE_FOLDER.getLocalName());
								folder.setApplyVeraProtection(
										(String) nodeProp.get(ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION));
								Path path = nodeService.getPath(nodeRef);
								String filePath = "";
								if (path != null) {
									filePath = path.toString();
									filePath = filePath.replaceAll(
											"\\{http://www.alfresco.org/model/application/1.0\\}|\\{http://www.alfresco.org/model/site/1.0\\}|\\{http://www.alfresco.org/model/content/1.0\\}",
											"");
								}
								folder.setRelativePath(ISO9075.decode(filePath));

								if (dxDomainService.getDomainStatus(nodeRef.toString(), managerEmailId)
										.get("status1") == "401") {
									folder.setDomainMismatch(false);
								} else {
									folder.setDomainMismatch(true);
								}
								folder.setFavoriteStatus(false);
								folder.setPermissionLevel(getUserRole(currentUser, nodeRef));
								/*
								 * if (hasPermission) { breadcrumbLst.add(folder); }
								 */
								breadcrumbLst.add(folder);
								if (fileName.equalsIgnoreCase("Document Library")) {
									return null;
								}
								getAllParentNodeRef(nodeRef, breadcrumbLst, currentUser, managerEmailId);

					}
					return null;
				}
			}, AuthenticationUtil.getAdminUserName());
		} catch (InvalidNodeRefException ine) {
			LOGGER.error("InvalidNodeRefException : " + ine);
			ine.printStackTrace();
		} catch (Exception e) {
			LOGGER.error("Exception : " + e);
			e.printStackTrace();
		}
	}

	/**
	 * To get loggedUser Permission Role
	 */
	@SuppressWarnings("unused")
	public String getUserRole(String currentUser, NodeRef nodeRef) {
		Set<AccessPermission> userSet = getAllNodeRefPermissions(nodeRef);
		String userRole = "";
		LOGGER.debug("userSet : " + userSet);
		if (userSet.size() > 0) {
			int currentRoleIndex = 0;
			int tempRoleIndex = 0;
			String tempUserRole = "";
			for (AccessPermission accessPermission : userSet) {
				if (accessPermission.getAuthorityType() == AuthorityType.USER) {
					String user = accessPermission.getAuthority();
					LOGGER.debug("user : " + user);
					String authorityType = accessPermission.getAuthorityType().toString();
					if (user.equals(currentUser)) {
						String role = accessPermission.getPermission();
						userRole = role.split("Role")[0];
						LOGGER.debug((new StringBuilder("userRole: ")).append(userRole).toString());
						if (ExternalSharingConstants.UsersRoleHerarcy.containsKey(userRole)) {
							LOGGER.debug("...............contains user role.........");
							tempRoleIndex = ExternalSharingConstants.UsersRoleHerarcy.get(userRole).intValue();
							LOGGER.debug((new StringBuilder("tempRoleIndex: ")).append(tempRoleIndex).toString());
						} else {
							tempRoleIndex = -1;
							LOGGER.debug((new StringBuilder("tempRoleIndex: ")).append(tempRoleIndex).toString());
						}
						if (tempRoleIndex > currentRoleIndex) {
							tempUserRole = userRole;
							currentRoleIndex = tempRoleIndex;
						}

					}
				}
			}
			String groupMemberRole = getGroupMemberUserRole(currentUser, nodeRef, userSet);
			if (groupMemberRole != null && groupMemberRole != "") {
				int currentGroupOrUserRoleIndex = 0;
				int tempGroupOrUserRoleIndex = 0;
				String tempGroupOrUserRole = "";
				List<String> userOrGroupIdRole = new ArrayList<String>();
				userOrGroupIdRole.add(userRole);
				userOrGroupIdRole.add(groupMemberRole);
				for (String permissionRole : userOrGroupIdRole) {
					if (ExternalSharingConstants.UsersRoleHerarcy.containsKey(permissionRole)) {
						LOGGER.debug(" :: Has group role ::");
						tempGroupOrUserRoleIndex = ExternalSharingConstants.UsersRoleHerarcy.get(permissionRole)
								.intValue();
					} else {
						tempGroupOrUserRoleIndex = -1;
						LOGGER.debug(
								(new StringBuilder("tempRoleIndex: ")).append(tempGroupOrUserRoleIndex).toString());
					}
					if (tempGroupOrUserRoleIndex > currentGroupOrUserRoleIndex) {
						tempGroupOrUserRole = permissionRole;
						currentGroupOrUserRoleIndex = tempGroupOrUserRoleIndex;
					}
				}
				userRole = tempGroupOrUserRole;
			} else {
				userRole = tempUserRole;
			}
			if (userRole.equalsIgnoreCase("Admin")) {
				userRole = UserRoleConstants.USER_ADMIN_ROLE;
			}
		}
		return userRole;
	}

	/**
	 * To get GroupMember of loggedUser Permission Role
	 * 
	 * @param userSet
	 */
	public String getGroupMemberUserRole(final String currentUser, NodeRef nodeRef, Set<AccessPermission> userSet) {
		String userInGroupRole = "";
		boolean userIsInGroup = false;
		LOGGER.debug("userSet : " + userSet);
		if (userSet.size() > 0) {
			int currentRoleIndex = 0;
			int tempRoleIndex = 0;
			String tempUserRole = "";
			LOGGER.debug(" Current User ===> " + currentUser + " Runas User ===> " + AuthenticationUtil.getRunAsUser());
			for (AccessPermission accessPermission : userSet) {
				if (accessPermission.getAuthorityType() == AuthorityType.GROUP) {
					if (accessPermission.getPermission() != null && accessPermission.getPermission().equals("SiteAdmin")
							|| accessPermission.getPermission().equals("SiteEditor")
							|| accessPermission.getPermission().equals("SiteReader")
							|| accessPermission.getPermission().equals("SiteOwner")
							|| accessPermission.getPermission().equals("SiteManager")
							|| accessPermission.getPermission().equals("ReadPermissions")
							|| accessPermission.getPermission().equals("SiteViewer")) {
						LOGGER.debug("Inside if ootb authority permissions :::: " + accessPermission.getPermission());
					} else {
						final String groupId = accessPermission.getAuthority();
						userIsInGroup = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
							@Override
							public Boolean doWork() throws Exception {
								boolean currentUserIsGroupMember = false;
								if (groupId != null && !groupId.equalsIgnoreCase(GROUP_EVERYONE)) {
									final Set<String> userAuthorities = serviceRegistry.getAuthorityService()
											.getAuthoritiesForUser(currentUser);
									currentUserIsGroupMember = userAuthorities.contains(groupId);
								}
								return currentUserIsGroupMember;
							}
						}, AuthenticationUtil.getAdminUserName());
						if (userIsInGroup) {
							String role = accessPermission.getPermission();
							userInGroupRole = role.split("Role")[0];
							LOGGER.debug((new StringBuilder("userRole: ")).append(userInGroupRole).toString());
							if (ExternalSharingConstants.UsersRoleHerarcy.containsKey(userInGroupRole)) {
								tempRoleIndex = ExternalSharingConstants.UsersRoleHerarcy.get(userInGroupRole)
										.intValue();
								LOGGER.debug((new StringBuilder("tempRoleIndex: ")).append(tempRoleIndex).toString());
							} else {
								tempRoleIndex = -1;
								LOGGER.debug((new StringBuilder("tempRoleIndex: ")).append(tempRoleIndex).toString());
							}
							if (tempRoleIndex > currentRoleIndex) {
								tempUserRole = userInGroupRole;
								currentRoleIndex = tempRoleIndex;
							}
						}
					}
				}
			}
			userInGroupRole = tempUserRole;
		}
		return userInGroupRole;
	}

	public Set<AccessPermission> getAllNodeRefPermissions(final NodeRef nodeRef) {
		final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef));
				return null;
			}
		}, AuthenticationUtil.getAdminUserName());
		return accessPermission;
	}

	public NodeRef getSiteDocLibNodeRef(String siteName) {
		SiteInfo siteInfo = serviceRegistry.getSiteService().getSite(siteName);
		NodeRef docLibNodRef = serviceRegistry.getSiteService().getContainer(siteInfo.getShortName(),"documentLibrary");
		LOGGER.debug("docLibNodRef :::: " + docLibNodRef);
		return docLibNodRef;
	}

	public void setAlfrescoURL(String alfrescoURL) {
		this.alfrescoURL = alfrescoURL;
	}

	public void setContextName(String contextName) {
		this.contextName = contextName;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public void setFileFolderService(FileFolderService fileFolderService) {
		this.fileFolderService = fileFolderService;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public void setDxDomainService(DocexDomainService dxDomainService) {
		this.dxDomainService = dxDomainService;
	}

	public static void setLdapUtil(ExternalLDAPUtil ldapUtil) {
		DocexFileFolderServiceImpl.ldapUtil = ldapUtil;
	}

}
