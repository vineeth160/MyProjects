package com.cisco.docex.service;

import java.util.Map;

import com.cisco.docex.transferobjects.outbound.SupportGroupFileFolderOutbound;

public interface DocexFileFolderService {

	public SupportGroupFileFolderOutbound getSupportGroupFileFolders(String docexUserName , Map<String,Object> paramMap);

}
