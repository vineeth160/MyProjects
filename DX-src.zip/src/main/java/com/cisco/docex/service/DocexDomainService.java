package com.cisco.docex.service;

import java.util.Map;

public interface DocexDomainService {
	
	public  Map<String, Object> getDomainStatus(String currentNodeRef ,String userEmail);
}
