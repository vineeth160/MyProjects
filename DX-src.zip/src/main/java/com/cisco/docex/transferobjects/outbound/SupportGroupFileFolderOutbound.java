package com.cisco.docex.transferobjects.outbound;

import java.util.ArrayList;
import java.util.List;

import com.cisco.alfresco.external.common.model.ExtDocument;
import com.cisco.alfresco.external.common.model.Folder;

public class SupportGroupFileFolderOutbound {

	private List<Folder> breadCrumbList = new ArrayList<Folder>();
	//private List<Folder> folderInfo = new ArrayList<Folder>();
	private String nodeRefId = "";
	private String permissionLevel = "";
	private Integer totalCount = 0;
	private Integer pageNo = 0;
	private Integer pageSize = 0;
	private String sortOrder = "asc";
	private String sortBy = "modified";
	private boolean hasFolderAccess = false;
	private List<ExtDocument> children = new ArrayList<>();
	
	public SupportGroupFileFolderOutbound() {
		super();
	}

	public List<Folder> getBreadCrumbList() {
		return breadCrumbList;
	}

	public void setBreadCrumbList(List<Folder> breadCrumbList) {
		this.breadCrumbList = breadCrumbList;
	}

	/*public List<Folder> getFolderInfo() {
		return folderInfo;
	}

	public void setFolderInfo(List<Folder> folderInfo) {
		this.folderInfo = folderInfo;
	}*/

	public String getNodeRefId() {
		return nodeRefId;
	}

	public void setNodeRefId(String nodeRefId) {
		this.nodeRefId = nodeRefId;
	}

	public String getPermissionLevel() {
		return permissionLevel;
	}

	public void setPermissionLevel(String permissionLevel) {
		this.permissionLevel = permissionLevel;
	}

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	public List<ExtDocument> getChildren() {
		return children;
	}

	public void setChildren(List<ExtDocument> children) {
		this.children = children;
	}

	public void addChild(ExtDocument child) {
		this.children.add(child);
	}

	public void addChildren(List<ExtDocument> children) {
		this.children.addAll(children);
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public boolean isHasFolderAccess() {
		return hasFolderAccess;
	}

	public void setHasFolderAccess(boolean hasFolderAccess) {
		this.hasFolderAccess = hasFolderAccess;
	}

	@Override
	public String toString() {
		return "SupportGroupFileFolderOutbound [breadCrumbList=" + breadCrumbList + /*", folderInfo=" + folderInfo +*/
				 ", nodeRefId=" + nodeRefId + ", permissionLevel=" + permissionLevel + ", totalCount=" + totalCount
				+ ", pageNo=" + pageNo + ", pageSize=" + pageSize + ", sortOrder=" + sortOrder + ", sortBy=" + sortBy
				+ ", hasFolderAccess=" + hasFolderAccess + ", children=" + children + "]";
	}

	
	
}
