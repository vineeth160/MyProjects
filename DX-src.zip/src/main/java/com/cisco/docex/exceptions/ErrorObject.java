package com.cisco.docex.exceptions;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "error")
public class ErrorObject
{

    String code;
    String error;
    String field;
    String identifier;

    public ErrorObject(String code, String error)
    {
        this.code = code;
        this.error = error;
    }
    
    public ErrorObject()
    {
    }

    public ErrorObject(String code, String error, String field)
    {
        this.code = code;
        this.error = error;
        this.field = field;
    }

    public ErrorObject(String code, String error, String field, String identifier)
    {
        this.code = code;
        this.error = error;
        this.field = field;
        this.identifier = identifier;
    }

    public String getCode()
    {
        return code;
    }

    public void setCode(String code)
    {
        this.code = code;
    }

    public String getError()
    {
        return error;
    }

    public void setError(String error)
    {
        this.error = error;
    }

    public String getField()
    {
        return field;
    }

    public void setField(String field)
    {
        this.field = field;
    }

    public String getIdentifier()
    {
        return identifier;
    }

    public void setIdentifier(String identifier)
    {
        this.identifier = identifier;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (obj == null)
            return Boolean.FALSE;
        if (obj instanceof ErrorObject)
            return this.getCode().equalsIgnoreCase(((ErrorObject) obj).getCode().trim());
        else
            return Boolean.FALSE;
    }

    @Override
    public String toString()
    {
        return "ErrorObject [code=" + code + ", error=" + error + ", field=" + field + ", identifier=" + identifier
                + "]";
    }

}