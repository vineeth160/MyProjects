/**
 * 
 */
package com.cisco.docex.exceptions;

import java.util.HashSet;
import java.util.Set;


/**
 * @author parreddy
 *
 */
public interface BaseValidator {

	public Set<ErrorObject> errors = new HashSet<ErrorObject>();
	
	public abstract void processInputValidation();

    public abstract void processBusinessValidation();
    
    public default void validate()
    {
        this.processInputValidation();
        if (errors.size() == 0)
        {
            this.processBusinessValidation();
        }
        this.postValidation();
    }
    
    public default void postValidation()
    {
        errors.remove(null);
        System.out.println("errors size ===> " + errors.size());
        if (!errors.isEmpty() || errors.size() != 0)
        {
            throw new ValidationException(errors.toString());
        }

    }
	
}
