package com.cisco.docex.exceptions;

public class ValidationException extends RuntimeException
{
   // Response response;
    ErrorObject errorObj;
    String response;

    public ValidationException(ErrorObject obj)
    {
        this.errorObj = obj;
        //this.response = new Response(obj);
        this.response = "";
    }
    
    public ValidationException(String response) {
    	this.response = response;
    }

    /*public ValidationException(Response response)
    {
        this.response = response;
    }*/

    /*public Response getResponse()
    {
        return response;
    }

    public void setResponse(Response response)
    {
        this.response = response;
    }*/

    public ErrorObject getErrorObj()
    {
        return errorObj;
    }

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
    
    

}
