package com.cisco.edcsng.userinfo.permission;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.PermissionService;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.edcsng.util.UserPermissionUtil;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;

public class UserPermission  extends DeclarativeWebScript
{
  private Logger out = Logger.getLogger(UserPermission.class);
  private ServiceRegistry serviceRegistry;
  private ExternalLDAPUtil ldapUtil;
  private static final String CISCO_RESTRICTED="Cisco Restricted";
  private Properties globalProperties;
  protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {
	
	  Map<String, Object> model = new HashMap<String, Object>();
	  Boolean isInheritedValue = false;
	  Boolean isCiscoRestricted = false;
    try{
    	out.info("Start View Permissions (External) ...");
        
        PermissionService permissionService = this.serviceRegistry.getPermissionService();
//        Map<String, Object> model = new HashMap<String, Object>();
        List<HashMap<String, String>> authorities = new ArrayList<HashMap<String, String>>();
        NodeRef nodeRef = null;
        String idParameter = req.getParameter("id");
        String folderPath = req.getParameter("folderPath");//folderPath
        String fromInternalDocID = req.getParameter("fromInternalDocID");
        String message = "";
        out.info("..idParameter : " + idParameter);
        out.info("..folderPath : " + folderPath);
        out.info("..fromInternalDocID : " + fromInternalDocID);
        
        boolean opsRequest = Boolean.parseBoolean(req.getParameter("isOpsRequest"));
        boolean listPermissions = false;
        String currentLoginUserName = AuthenticationUtil.getFullyAuthenticatedUser();
       
        if(opsRequest && isSupportGroupUser(currentLoginUserName)) {
        	listPermissions = true;
			AuthenticationUtil.setAdminUserAsFullyAuthenticatedUser();
			out.debug("Current User Name in action===> " + AuthenticationUtil.getRunAsUser());
		}
        
        if ((folderPath != null) && (!folderPath.startsWith("workspace://SpacesStore/")))
        {
          folderPath = folderPath.replace("nextgen-edcs", "edcsng");
          String folderSearchQuery = "TYPE:\"cm:folder\" AND PATH:\"" + folderPath + "\"";
          out.info("folderSearchQuery: " + folderSearchQuery);
          nodeRef = EDCSUtil.doSearch(folderSearchQuery, this.serviceRegistry);
          out.info("if Node ref (Internal): " + nodeRef);
          if(nodeRef != null){
        	  out.info("if Node ref (Internal): 2");
        	  authorities=UserPermissionUtil.getPermissions(nodeRef,serviceRegistry);
              model.put("persons", authorities);
          }else{
      		model.put("groupinherit", "false");
      		model.put("ciscorestricted", "false");
       		model.put("message","Folder or document is not found. NodeRef found null");
           	status.setCode(Status.STATUS_OK);
           	out.info("End View Permissions .... model: "+model.toString());
      	 }
         }
         else if(fromInternalDocID != null && fromInternalDocID!="")
         {
        	 nodeRef = new NodeRef(fromInternalDocID);
             out.info("else if ..Noderef (Internal): " + nodeRef);
       		 if(nodeRef != null){
       			authorities=UserPermissionUtil.getPermissions(nodeRef,serviceRegistry);
          		model.put("persons", authorities);
       		 }
        	 
         } else
         {
        	 nodeRef = new NodeRef(idParameter);
             out.info("else..Noderef (External): " + nodeRef);
             
             String logginUser = AuthenticationUtil.getFullyAuthenticatedUser();
             out.info("Logged User::::: "+logginUser);
       	  
            if(isUserInternal(logginUser) || isUserGenerics(logginUser) || listPermissions){
       		  authorities=UserPermissionUtil.getPermissions(nodeRef,serviceRegistry);
       		  model.put("persons", authorities);
       	    } else {
       	    	message = "You are not authorized to perform this operation..";
       	    }
         }
        	if(nodeRef != null){
        		String securityTypeProp = (String) serviceRegistry.getNodeService().getProperty(nodeRef, CiscoModelConstants.CISCO_SECURITY_PROP);
        		out.info("UserPermission Document Security Type Prop :: " +securityTypeProp);
        		//US8123 start
        		if (securityTypeProp != null && securityTypeProp.equalsIgnoreCase(CISCO_RESTRICTED)){
                 	isInheritedValue = false;
                 	isCiscoRestricted=true;
                 }
                else{
                	isInheritedValue=permissionService.getInheritParentPermissions(nodeRef);
                	isCiscoRestricted=false;
                }
        		//US8123 end
        		model.put("groupinherit", String.valueOf(isInheritedValue));
        		model.put("ciscorestricted", String.valueOf(isCiscoRestricted));
            	model.put("message", message);
            	status.setCode(Status.STATUS_OK);
            	out.info("End View Permissions .... model: "+model.toString());
        	} else {
        		model.put("groupinherit", "false");
        		model.put("ciscorestricted", "false");
        		model.put("message","Folder or document is not found. NodeRef found null");
            	status.setCode(Status.STATUS_OK);
            	out.info("End View Permissions .... model: "+model.toString());
        	}
        
    } catch(Exception e){
    	status.setCode(Status.STATUS_INTERNAL_SERVER_ERROR);
		status.setMessage(e.getMessage());
		out.info("Exception occured : " + e.getMessage());
    }
    return model;
  }
  
  public boolean isUserInternal(String userid)
  {
  	out.info((new StringBuilder("Start checking if internal LDAP users.. ")).append(userid).toString());

      return ldapUtil.isLdapUserInternal((new StringBuilder(String.valueOf(userid))).toString());
      //out.info((new StringBuilder("idAndName: ")).append(idAndName).toString());
  }
  public boolean isUserGenerics(String userid)
  {
  	out.info((new StringBuilder("Start checking if Generics LDAP users.. ")).append(userid).toString());

      return ldapUtil.isLdapUserGeneric((new StringBuilder(String.valueOf(userid))).toString());
      //out.info((new StringBuilder("idAndName: ")).append(idAndName).toString());
  }
  
  public boolean isSupportGroupUser(String currentUserName) {
		boolean isUserExistinGroup = false;
		Set<String> userAuthorities = serviceRegistry.getAuthorityService().getAuthorities();
		String supportGroupName = globalProperties.getProperty("docex.supportgroup.name");
		if(supportGroupName != null && userAuthorities.contains(supportGroupName)) {
			isUserExistinGroup = true;
		}
		return isUserExistinGroup;
	}
  
  public void setServiceRegistry(ServiceRegistry serviceRegistry)
  {
    this.serviceRegistry = serviceRegistry;
  }
  
  public ExternalLDAPUtil getLdapUtil() {
      return ldapUtil;
  }
  
  public void setLdapUtil(ExternalLDAPUtil ldapUtil) {
      this.ldapUtil = ldapUtil;
  }

public void setGlobalProperties(Properties globalProperties) {
	this.globalProperties = globalProperties;
}
  
  
}
