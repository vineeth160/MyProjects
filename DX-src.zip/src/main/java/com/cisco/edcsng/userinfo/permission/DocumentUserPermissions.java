package com.cisco.edcsng.userinfo.permission;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Properties;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Stack;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.TemplateService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityService;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.MutableAuthenticationService;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.edcsng.util.MailUtil;
import com.cisco.alfresco.external.common.util.ExternalLDAPUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.external.common.util.ExternalSharingFileFolderUtil;
import com.cisco.alfresco.external.manageMailerGroups.MailerGroupSearchUtil;
import com.cisco.alfresco.external.utils.CiscoStringUtils;
import com.cisco.alfresco.external.utils.ExternalPermissionAuditUtil;

public class DocumentUserPermissions extends DeclarativeWebScript
{
    private Logger logs = Logger.getLogger(DocumentUserPermissions.class);
    private static String zoneId = AuthorityService.ZONE_AUTH_EXT_PREFIX + "ldap";
    private static String preferenceFilter = "org.alfresco.share.folders.favourites";
    private ServiceRegistry serviceRegistry;
    private ExternalLDAPUtil ldapUtil;
    private MailerGroupSearchUtil mailerGroupLdapUtil;
	private NodeService nodeService;
    private TemplateService templateService;
   // private String addUserFtlLocationPath;
    private String mailServer;
    private String bannerAlfrescoUrl;
    private String mailerFromID;
	private String contextName;
    public static String ADD_USER_NOTIFICATION_TEMPLATE = "/alfresco/extension/templates/email/addPermissionsNotificationTemplate.ftl";
    public static String CASCADE_USER_NOTIFICATION_TEMPLATE = "/alfresco/extension/templates/email/CascadePermissionUpdatedNotification.ftl";
    public static String ADD_USER_FOLDER_SUBJECT = "has published a folder on Doc Exchange";
    public static String ADD_USER_DOC_SUBJECT = "has published a document on Doc Exchange";
    public static String FOLDER_MSG = "Please click on folder name to view the contents of this folder.";
    public static String PREFERENCE_REMOVE_ACTION_YES="yes";
    public static String PREFERENCE_REMOVE_ACTION_NO="no";
    private static final String GROUP_IDENTITY ="GROUP_";
    private static final String CISCO_MAILID="@cisco.com";
    private static final String CISCO_RESTRICTED="Cisco Restricted";
    private String titleURL; 
    private PreferenceService preferenceService;
    private ExternalPermissionAuditUtil auditComponent;
    private Properties globalProperties;
	public void setPreferenceService(PreferenceService preferenceService) {
		this.preferenceService = preferenceService;
	}
	
	public void setGlobalProperties(Properties globalProperties) {
		this.globalProperties = globalProperties;
	}
	
    @Override
    protected Map<String, Object> executeImpl(final WebScriptRequest req, Status status, Cache cache)
    {
    	Map<String, Object> model = new HashMap<String, Object>();
    	Boolean inheritPermissionValue = false;
    	Boolean isCascadePermissionValue = false;
    	String cascadePermission =null;
    	logs.info("..Start DocumentUserPermissions save/update....");
        try
        {
            Content c = req.getContent();
            if (c == null)
            {
                throw new WebScriptException(Status.STATUS_BAD_REQUEST, "Missing POST body.");
            }
            JSONObject userPermissionsJson = new JSONObject(c.getContent());
            NodeRef nodeRefId = new NodeRef(userPermissionsJson.getString("nodeId"));
            String inheritPermission = userPermissionsJson.getString("inherit");
            inheritPermissionValue = Boolean.parseBoolean(inheritPermission);
            logs.info("inheritPermission: " + inheritPermission + "inheritPermissionValue: " + inheritPermissionValue);
            if(userPermissionsJson.has("cascade")){
            	cascadePermission = userPermissionsJson.getString("cascade");
            }
            if(cascadePermission!=null && !cascadePermission.isEmpty()) {
            	isCascadePermissionValue = Boolean.parseBoolean(cascadePermission);
            }
            logs.info("cascadePermission: " + cascadePermission + "isCascadePermissionValue:: " + isCascadePermissionValue);
            String logginUser = AuthenticationUtil.getFullyAuthenticatedUser();
            logs.info("loggin User: " + logginUser);
           
            if (isUserInternal(logginUser) || isUserGenerics(logginUser))
            {
            	model=processUsersPermissions(userPermissionsJson,nodeRefId,logginUser,inheritPermissionValue,isCascadePermissionValue);
            }
            else
            {
                model.put("permissionMessage", "You are not authorized to perform this operation.");
            }
        }
        catch (Exception e)
        {
            model
                    .put(
                        "permissionMessage",
                        "Permission is not udpated. You are not authorized to perform this operation or contact System Admin for further information.");
            e.printStackTrace();
        }
        return model;

    }
    
    /**
   	 * This method allow user permission on folder/documents 
   	 *  
   	 */
    private Map<String, Object> processUsersPermissions(JSONObject userPermissionsJson,NodeRef documentNodeRef,String logginUser,Boolean inheritPermissionValue,Boolean isCascadePermissionValue){
    	 
    	 JSONArray usersArray=new JSONArray();
    	 List<String> newUserPerms = null;
         List<String> existingUsersList = null;
         Boolean isCiscoRestricted = false;
         ArrayList<String> loggedInUserPermission = new ArrayList<String>();
         HashMap<String, String> permissionsInfo = new HashMap<String, String>();
         HashMap<String, String> removeUsersMap=new HashMap<String, String>();
         HashMap<String, String> addUsersMap=new HashMap<String, String>();
         HashMap<String, String> updateUsersMap=new HashMap<String, String>();
         HashMap<String, String> addUpdateUsersMap=new HashMap<String, String>();
         HashMap<String, String> updateRemoveUsersMap=new HashMap<String, String>();
         JSONArray updatedUsersArray=new JSONArray();
         final Map<String, Object> model = new HashMap<String, Object>();
         try {
        	 usersArray=userPermissionsJson.getJSONArray("users");
        	if (userPermissionsJson.has("users") && userPermissionsJson.getJSONArray("users").length() >= 0)
        	 {
            existingUsersList = new ArrayList<String>();
            PermissionService permissionService = serviceRegistry.getPermissionService();
            Set<AccessPermission> accessPermissions = permissionService.getAllSetPermissions(documentNodeRef);// getPermissions(documentNodeRef);
            logs.info("Permissions: " + accessPermissions);
            Iterator<AccessPermission> fIterator = accessPermissions.iterator();
            AccessPermission accessPerm = null;
            while (fIterator.hasNext())
            {
                accessPerm = fIterator.next();
                //logs.info("isInherited ::"+accessPerm.isInherited());
                //logs.info("In while loop ::"+accessPerm.getAuthority()+":");
                if(!accessPerm.isInherited()){
                permissionsInfo.put(accessPerm.getAuthority(), accessPerm.getPermission().toString());
                }
                if (logginUser.equalsIgnoreCase(accessPerm.getAuthority()))
                {
                	logs.info("In if loop - adding users to the permission ::"+accessPerm.getAuthority()+":");
                   //loggedInUserPermission = accessPerm.getPermission().toString();
                	  loggedInUserPermission.add(accessPerm.getPermission());
                }
            }
            logs.info("node permissionsInfo ::"+permissionsInfo.size());
            logs.info("node permissionsInfo ::"+permissionsInfo);
            removeUsersMap.putAll(permissionsInfo);
            logs.info("usersArray length  :: "+ usersArray.length());
            for (int j = 0; j < usersArray.length(); j++)
            {
                String userid = usersArray.getJSONObject(j).getString("userId").toString();
                String permid = usersArray.getJSONObject(j).getString("permissionLevel").toString();
                if(permid.equalsIgnoreCase("Folder Admin")){
                	permid="AdminRole";
                }else{
                    permid = permid.concat("Role").toString();
                    }
                addUsersMap.put(userid, permid);
            }
            logs.info("request addUsersMap  :: "+ addUsersMap.size());
            logs.info("request addUsersMap  :: "+ addUsersMap.toString());
            for (int i = 0; i < usersArray.length(); i++)
            {
                String userid = usersArray.getJSONObject(i).getString("userId").toString();
                String permid = usersArray.getJSONObject(i).getString("permissionLevel").toString();
                if(permid.equalsIgnoreCase("Folder Admin")){
                	permid="AdminRole";
                }else{
                permid = permid.concat("Role").toString();
                }
                //logs.info("check for  :: "+ userid+"::"+permid);
                if(permissionsInfo.size()>0){
                for (Map.Entry<String, String> entry : permissionsInfo.entrySet()) {
                	
                	//logs.info("Map check for :: "+ entry.getKey()+"::"+entry.getValue());
                	if (entry.getKey().equals(userid)) {
                		if (!entry.getValue().equals(permid)) {
                			//updated users map
                			updateUsersMap.put(userid, permid);
                		} else {
                			//remove users map
                			//logs.info("none add or update :: "+ userid+"::"+permid);
                        	removeUsersMap.remove(entry.getKey());
                		}
                	} else {
                		//add users map
                		//logs.info("add or update for  :: "+ userid);
                    	addUsersMap.remove(entry.getKey());
                	}
                }
                }
        	}
            logs.info("addUsersMap :: "+addUsersMap.toString());
            logs.info("removeUsersMap :: "+removeUsersMap.toString());
            logs.info("updateUsersMap :: "+updateUsersMap.toString());
            addUpdateUsersMap.putAll(updateUsersMap);
            addUpdateUsersMap.putAll(addUsersMap);
            updateRemoveUsersMap.putAll(updateUsersMap);
            updateRemoveUsersMap.putAll(removeUsersMap);
            logs.info("addUpdateUsersMap :: "+addUpdateUsersMap.toString());
            logs.info("updateRemoveUsersMap :: "+updateRemoveUsersMap.toString());
            if(addUpdateUsersMap.size()>0){
            	updatedUsersArray=mapToJsonArray(addUpdateUsersMap);
            }
            if(updateRemoveUsersMap.size()>0){
            	existingUsersList=getRemovedUsers(updateRemoveUsersMap,logginUser);
            }
            logs.info("final existingUsersList :: "+existingUsersList.toString());
            logs.info("final updated Users Array :: "+updatedUsersArray.toString());
            
            //US8123- uellappa
            String securityTypeProp = (String) nodeService.getProperty(documentNodeRef, CiscoModelConstants.CISCO_SECURITY_PROP);
            if (securityTypeProp != null && securityTypeProp.equalsIgnoreCase(CISCO_RESTRICTED)){
            	logs.info("If documentNodeRef  :: " + documentNodeRef + " Cisco Restricted .");
            	inheritPermissionValue = false;
            	isCiscoRestricted=true;
            }
            logs.info("inheritPermissionValue  :: " +inheritPermissionValue);
            //US8123- uellappa
            
            if (isPermissionChangeAllowed(logginUser, loggedInUserPermission))
            {
                newUserPerms = addUserPermissions(documentNodeRef, updatedUsersArray,
                    existingUsersList, logginUser, inheritPermissionValue,isCiscoRestricted,isCascadePermissionValue);
                model.put("permissionMessage", "Permission updated successfully.");
                //START: Added by prbadam for the defect DE1465. The below code will add the user to favorites for specified node
                logs.info("logginUser-------------"+logginUser);
                processUserPreferences(existingUsersList,documentNodeRef,newUserPerms,logginUser);
                //END: Added by prbadam for the defect DE1465 
            }
            else
            {
                model.put("permissionMessage", "You do not have authority to perform this operation.");
            }
        }
        else
        {
            model.put("permissionMessage", "Submitted Json is not in correct format.");
        }
       
       	//Permission Audit Starts
		Map<String, String> addpermissionsAuditMap = new HashMap<>();
		addpermissionsAuditMap.putAll(addUsersMap);
		addpermissionsAuditMap.putAll(updateUsersMap);
		auditUserPermissions(addpermissionsAuditMap,removeUsersMap,documentNodeRef);
		//Permission Audit Ends
    
		  //DE5251 start of cascade perms changes
			if (isCascadePermissionValue) {
				logs.info("..Start DocumentUserPermissions cascade childs save/update....");
				logs.info("..Existing userlist...." + existingUsersList.toString() + "===Updated Users==="
						+ updatedUsersArray.toString());
				ProcessCascadePermissions processCascadePermissionsObj = new ProcessCascadePermissions(documentNodeRef,
						updatedUsersArray, existingUsersList, logginUser, inheritPermissionValue,
						isCascadePermissionValue, mailerFromID, mailServer, bannerAlfrescoUrl, titleURL, contextName,
						logginUser);
				logs.info("..mailerFromID...." + mailerFromID + "====mailServer==" + mailServer
						+ "===bannerAlfrescoUrl===" + bannerAlfrescoUrl + "====titleURL==" + titleURL
						+ "===contextName===" + contextName + "===logginUser==" + logginUser);
				new Thread(processCascadePermissionsObj).start();
			}
         }catch(Exception ex) {
        	 model
             .put(
                 "permissionMessage",
                 "Permission is not udpated. You are not authorized to perform this operation or contact System Admin for further information.");
        	 ex.printStackTrace();
         }
         return model;
    }
    
    /**
   	 * This method allow user permission cascade from parent to sub folders 
   	 *  
   	 */
    private void processCascadeUserPermissions(NodeRef documentNodeRef,final JSONArray users,
            final List<String> existingUsersList,String logginUser,Boolean inheritPermissionValue,Boolean isCascadePermissionValue){
    	 	List<String> newUserPerms = null;
        	ArrayList<String> loggedInUserPermission = new ArrayList<String>();
        	HashMap<String, String> permissionsInfo = new HashMap<String, String>();
        	Map<String, String> addpermissionsAuditMap = new HashMap<>();
        	HashMap<String, String> removeUsersAuditMap=new HashMap<String, String>();
        	newUserPerms = new ArrayList<String>();
        	List<String> nodeSpecificExistingUsersList = null;
        try {
        	nodeSpecificExistingUsersList = new ArrayList<String>();
           PermissionService permissionService = serviceRegistry.getPermissionService();
           Set<AccessPermission> accessPermissions = permissionService.getAllSetPermissions(documentNodeRef);
           logs.info("Permissions: " + accessPermissions);
           Iterator<AccessPermission> fIterator = accessPermissions.iterator();
           AccessPermission accessPerm = null;
           while (fIterator.hasNext())
           {
               accessPerm = fIterator.next();
               if(!accessPerm.isInherited()){
               permissionsInfo.put(accessPerm.getAuthority(), accessPerm.getPermission().toString());
               }
               if (logginUser.equalsIgnoreCase(accessPerm.getAuthority()))
               {
               	logs.info("In if loop - adding users to the permission ::"+accessPerm.getAuthority()+":");
                  //loggedInUserPermission = accessPerm.getPermission().toString();
               	  loggedInUserPermission.add(accessPerm.getPermission());
               }
           }
           logs.info("cascade node permissionsInfo ::"+permissionsInfo.size());
           logs.info("cascade node permissionsInfo ::"+permissionsInfo);
           logs.info("cascade final existingUsersList :: "+existingUsersList.toString());
           logs.info("cascade final updated Users Array :: "+users.toString());
           
           if (isPermissionChangeAllowed(logginUser, loggedInUserPermission))
           {
        	// Removing ALL existing users & permissions
        	   if(users.length()>0){
   	        	for (int r = 0; r < users.length(); r++)
   	            {
   	        		existingUsersList.add(users.getJSONObject(r).getString("userId"));
   	            }
        	   }
        	   
           	if(existingUsersList.size()>0){
           	for (String existUser : existingUsersList)
               {
           		if(permissionsInfo.containsKey(existUser)) {
           			logs.info("  ::::: Removed users from node  :::::: "+existUser+" :::permission ::: "+permissionsInfo.get(existUser));
           			nodeSpecificExistingUsersList.add(existUser);
           		  removeUsersAuditMap.put(existUser, permissionsInfo.get(existUser));
                  serviceRegistry.getPermissionService().clearPermission(documentNodeRef, existUser);
                  //remove user preferences 
                  setRemovePreferences(existUser,documentNodeRef,PREFERENCE_REMOVE_ACTION_YES,logginUser);
                  //Fix for library performance issue adding custom aspect
       			  addUserPreferencesProps(existUser,documentNodeRef,PREFERENCE_REMOVE_ACTION_YES);
           		}
               }
           	}
           	if(users.length()>0){
        		logs.info(".users...."+users.toString());
	        	for (int i = 0; i < users.length(); i++)
	            {
	        		newUserPerms.add(users.getJSONObject(i).getString("userId"));
	                logs.info("permissions update for :::: " + users.getJSONObject(i).getString("userId")+":::"+users.getJSONObject(i).getString("permissionLevel"));
	                String userValue = users.getJSONObject(i).getString("userId");
	                String permission = users.getJSONObject(i).getString("permissionLevel");
	                logs.debug("the name of the user or group is ::" +userValue);
	                logs.debug("the name of the permission is::"+permission);
	                
	                if(!userValue.isEmpty() && !permission.isEmpty()){
	                		if (userValue.contains(GROUP_IDENTITY) && permission.contains("AdminRole")){
		                    	logs.info("you are not authorised to create this group"+users.getJSONObject(i).getString("userId"));
		                    }else{
		                    	serviceRegistry.getPermissionService().setPermission(documentNodeRef,
		                        users.getJSONObject(i).getString("userId"),
		                        users.getJSONObject(i).getString("permissionLevel"), true);
		                    	addpermissionsAuditMap.put(users.getJSONObject(i).getString("userId"), users.getJSONObject(i).getString("permissionLevel"));
		                    	//serviceRegistry.getPermissionService().setInheritParentPermissions(documentNodeRef,inheritPermissionValue);
		                    }
	                }
	             }
           	    }else{
           	    	logs.info("::::: Inherit and folder conditions  ::::::::: "+inheritPermissionValue);
           	    	//serviceRegistry.getPermissionService().setInheritParentPermissions(documentNodeRef,inheritPermissionValue);
           	    }
           	   //START: Add the user to favorites for specified node
           	logs.info("cascade nodeSpecificExistingUsersList ::"+nodeSpecificExistingUsersList.toString());
            logs.info("cascade Preferences final newUserPerms :: "+newUserPerms.toString());
              // processUserPreferences(nodeSpecificExistingUsersList,documentNodeRef,newUserPerms);
               //END: Add the user to favorites for specified node
           }
           else
           {
        	   logs.info("You do not have authority to perform this operation on child folders.");
           }
           //Permission Audit Starts
           logs.info("cascade addpermissionsAuditMap ::"+addpermissionsAuditMap.toString());
           logs.info("cascade removeUsersAuditMap :: "+removeUsersAuditMap.toString());
           auditUserPermissions(addpermissionsAuditMap,removeUsersAuditMap,documentNodeRef);
           //Permission Audit ends
        }catch(Exception ex) {
         logs.error("Permission is not udpated on child folders. You are not authorized to perform this operation or contact System Admin for further information.");
       	 ex.printStackTrace();
        }
   }
    /**
   	 * This method record audit entries for permission changes
   	 *  
   	 */
    private void auditUserPermissions(Map<String, String> addpermissionsAuditMap, HashMap<String, String> removeUsersAuditMap,NodeRef nodeRefId) {
    	logs.info("************* Permission Audit Start*****************");
		StringBuilder action = new StringBuilder();
		StringBuilder permissionAuditData = new StringBuilder();
		try {
		if (addpermissionsAuditMap != null && !addpermissionsAuditMap.isEmpty()
				&& addpermissionsAuditMap.size() > 0) {
			action.append("ADD");
			List<String> addUsersList = new ArrayList<>();
			for (String addUser : addpermissionsAuditMap.keySet()) {
				addUsersList.add(addUser);
			}
			permissionAuditData.append("ADD:")
					.append(CiscoStringUtils.convertListIntoString(addUsersList, ","));
		}

		if (removeUsersAuditMap != null && !removeUsersAuditMap.isEmpty() && removeUsersAuditMap.size() > 0) {
			action.append(",REMOVE");
			List<String> removeUsersList = new ArrayList<>();
			for (String removeUser : removeUsersAuditMap.keySet()) {
				removeUsersList.add(removeUser);
			}
			permissionAuditData.append(";REMOVE:")
					.append(CiscoStringUtils.convertListIntoString(removeUsersList, ","));
		}

		logs.debug("Action for Permission Audit ====> " + action.toString());
		logs.debug("Permission Audit Data ====> " + permissionAuditData.toString());

		if (action != null && action.length() > 0) {
			auditComponent.createPermissionAudit(nodeRefId, permissionAuditData.toString(),
					action.toString());
		}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		logs.info("************* Permission Audit Ends****************");
    }
    
    /**
   	 * This method creates/updates users preferences for the library folders
   	 *  
   	 */
    private void processUserPreferences(List<String> existingUsersList, NodeRef documentNodeRef,List<String> newUserPerms,String logginUser) {
    	List<String> newlyAddedUserPerms = new ArrayList<String>();
    	logs.info("documentNodeRef-------------"+documentNodeRef);
    	logs.info("existingUsersList :: "+existingUsersList);
        logs.info("newUserPerms-------------"+newUserPerms);
    	boolean isDoc = serviceRegistry.getDictionaryService().isSubClass(nodeService.getType(documentNodeRef), ContentModel.TYPE_CONTENT);
    	logs.info("isDoc-------------"+isDoc);
        try{
         if(!isDoc){
           if(newUserPerms.size() > 0){
    	   logs.info("in if newUserPerms-----------");
    	   //add preferences for group members along with users
    	   newlyAddedUserPerms=getAllMemebersFromGroup(newUserPerms);
    	   for(String addedUser : newlyAddedUserPerms){
    		   logs.info("addedUser------------"+addedUser);
    		   if(!addedUser.contains(GROUP_IDENTITY))
    		   setRemovePreferences(addedUser,documentNodeRef,PREFERENCE_REMOVE_ACTION_NO,logginUser);
    		   logs.info("setting preferences finished in if-----------");
        	   //Fix for library performance issue adding custom aspect 
			   addUserPreferencesProps(addedUser,documentNodeRef,PREFERENCE_REMOVE_ACTION_NO);
    	   }
        } 
         if(existingUsersList.size()>0) {
        	 logs.info("in else newUserPerms[] empty-----------");
             logs.info("existingUsersList-------------"+existingUsersList);
             HashSet<String> docUserList = getUserNameList(documentNodeRef);
             logs.info("docUserList-------------"+docUserList);
             List<String> sourceList = new ArrayList<String>(existingUsersList);
             sourceList.removeAll( docUserList );
             //sourceList-------------[GROUP_site_edcsng_SiteManager, sarokuma]
               logs.info("sourceList-------------"+sourceList);
               List<String> usersSourceList = new ArrayList<String>();
               usersSourceList=getAllMemebersFromGroup(sourceList);
               logs.info("usersSourceList after removing GROUP---------"+usersSourceList);
               for(String sourceListUsers : usersSourceList){
        		   setRemovePreferences(sourceListUsers,documentNodeRef,PREFERENCE_REMOVE_ACTION_YES,logginUser);
        		   logs.info("finished in else block-----------");
        		   //Fix for library performance issue adding custom aspect
				   addUserPreferencesProps(sourceListUsers,documentNodeRef,PREFERENCE_REMOVE_ACTION_YES);
        	   }
          }else{
        	logs.info("There are no users avialable to remove preferences in else block-----------");
          	} // end of newUserPerms else -- end else for removing user from favorites
        	}
        	} catch (Exception e){
    		   logs.error("exception while updating preferences :: "+ e);
    		   e.printStackTrace();
    	   }
    }
    
    
    /**
	 * This method creates association for the library folders
	 *  
	 */
    private void addUserPreferencesProps(String logginUser, NodeRef finalUserFolderNode,String preferenceRemoveAction) {
		
    			logs.info("inside addUserPreferencesProps-------");
	    		try{
	    			if (logginUser.contains(GROUP_IDENTITY)) {
	    				List<String> sourceGroupList = new ArrayList<String>();
	    				sourceGroupList.add(logginUser);
	    				 logs.info("addUserPreferencesProps GROUP ID---------"+sourceGroupList.toString());
	    				List<String> groupMemberList = new ArrayList<String>();
	    				groupMemberList=getAllMemebersFromGroup(sourceGroupList);
                        logs.info("usersSourceList after removing GROUP---------"+groupMemberList);
                        for(String groupMember : groupMemberList){
                        	createFolderAssocForUserPreferences(groupMember,finalUserFolderNode,preferenceRemoveAction);
                        }
	    				}else {
	    					createFolderAssocForUserPreferences(logginUser,finalUserFolderNode,preferenceRemoveAction);
	    				}
	    		} catch (Exception e) {
   	        		logs.error("Exception in addUserPreferencesProps----"+e);
   	        		e.printStackTrace();
				}
	}
    
     private void createFolderAssocForUserPreferences(String userID, NodeRef finalUserFolderNode,String preferenceRemoveAction) {
    	 try{
    		 AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
    	 			@Override
    	 			public Object doWork() throws Exception {
			final NodeRef personNodereff=serviceRegistry.getPersonService().getPerson(userID);
			logs.info("Person nodereff   ::" +personNodereff);
			boolean hasAspect = nodeService.hasAspect(finalUserFolderNode, CiscoModelConstants.CISCO_DX_FOLDER_ASPECT);
			if(preferenceRemoveAction.equals(PREFERENCE_REMOVE_ACTION_YES)){
				logs.info("updated preferences node value is ::: "+personNodereff);
				logs.info("remove preferences is ::: "+PREFERENCE_REMOVE_ACTION_YES+" ::node value is:: "+finalUserFolderNode+" ::for user id :: "+userID);
				serviceRegistry.getNodeService().removeChild(personNodereff, finalUserFolderNode);
				logs.info("assoc removed successfully---");
			}else{
				if(hasAspect) {
   				serviceRegistry.getNodeService().addChild(personNodereff, finalUserFolderNode,
							CiscoModelConstants.CISCO_DX_FOLDER_ASSOCIATION,
							QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, finalUserFolderNode.getId()));
   				logs.info("assoc added successfully---");
   			}else {
   				serviceRegistry.getNodeService().addAspect(finalUserFolderNode, CiscoModelConstants.CISCO_DX_FOLDER_ASPECT,
							null);
					serviceRegistry.getNodeService().addChild(personNodereff, finalUserFolderNode,
							CiscoModelConstants.CISCO_DX_FOLDER_ASSOCIATION,
							QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, finalUserFolderNode.getId()));
					logs.info("assoc added successfully---");
   			}
			}
			return null;
    	 			}
    	 		}, "admin");
    	 } catch (Exception e) {
        		logs.error("Exception in createFolderAssocForUserPreferences----"+e);
        		e.printStackTrace();
			}
       }
    
	//START: Added by prbadam for the defect DE1465.
    private  void setRemovePreferences(String usersList, NodeRef documentNodeRef,String preferenceRemoveAction,String logginUser){
		Map<String, Serializable> preferences = null;
		Map<String, Serializable> updatedPreferences = null;
		AuthenticationUtil.setFullyAuthenticatedUser("admin");
		preferences = preferenceService.getPreferences(usersList,	preferenceFilter);
		//logs.info("preferences for perticular user----------"+preferences);
		updatedPreferences = updatedPreference(preferences, preferenceFilter, documentNodeRef.toString(),preferenceRemoveAction,usersList);
		//logs.info("Preferences to update-------------" + updatedPreferences);
		preferenceService.setPreferences(usersList, updatedPreferences);
		AuthenticationUtil.setFullyAuthenticatedUser(logginUser);
		logs.info("finished setRemovePreferences method-----------");
    }
    
    private HashSet<String> getUserNameList(NodeRef nodeRef){
    	HashSet<String> authority = new HashSet<String>();
    	try{
    	PermissionService permissionService = this.serviceRegistry.getPermissionService();
    	Set<AccessPermission> accessPermissions = permissionService.getAllSetPermissions(nodeRef);
    	Iterator<AccessPermission> fIterator = accessPermissions.iterator();
    	while (fIterator.hasNext())
    	{
    	AccessPermission accessPermission = (AccessPermission)fIterator.next();
    	logs.info("accessPermission users and groups are : " + accessPermission.getAuthority().toString());
    	authority.add(accessPermission.getAuthority());
    	}
    	if (logs.isDebugEnabled())
    	{
    		logs.info("folder or document users and groups are : " + authority.toString());
    	} 
    	}catch(Exception e){
    		logs.info("Error in getUserEmailList : "+e.getMessage()); 
    	}
    	logs.info("authority---------------"+authority);
    	return authority;
    	} 
    
	/**
	 * To Update the user preferences with the given preference filter 
	 * @param preferences
	 * @param preferenceFilter
	 * @param values
	 * @return preference object
	 */
	private Map<String, Serializable> updatedPreference(Map<String, Serializable> preferences,String preferenceFilter,String values,String preferenceRemoveAction,String usersId){
		logs.info("Values-----------"+values);
		logs.info("Preference size------"+preferences.size());
		logs.info("preferenceFilter------"+preferenceFilter);
		 Set<String> userPreferencesFoldersSet = new HashSet<String>();
		 List<String> userPreferencesFoldersList = new ArrayList<String>();
		 try {
				if(preferences.containsKey(preferenceFilter)){
				String item=(String)preferences.get(preferenceFilter);
				//logs.info("item----------"+item);
				
				String[] itemArray =item.split(",");
				List<String> list = new ArrayList<String>();
				if(itemArray.length > 0){
					Collections.addAll(list, itemArray);
				}
				if(list.size()>0) {
					userPreferencesFoldersSet.addAll(list);
				}
				if(!userPreferencesFoldersSet.isEmpty()) {
				 for (String folderId : userPreferencesFoldersSet){
						 userPreferencesFoldersList.add(folderId);
			        }
				}
				boolean hasUserAccessOnParent=ExternalSharingFileFolderUtil.canUserHavePermissionOnParentFolder(values,serviceRegistry,usersId);
				logs.info("if current login user dont have access on parent folder :::: "+hasUserAccessOnParent);
				if(preferenceRemoveAction.equals(PREFERENCE_REMOVE_ACTION_YES)){
					logs.info("updated preferences node value is ::: "+values);
					logs.info("remove preferences ::: "+PREFERENCE_REMOVE_ACTION_YES);
					if(userPreferencesFoldersList.contains(values) && preferenceRemoveAction.equals(PREFERENCE_REMOVE_ACTION_YES)) {
						userPreferencesFoldersList.remove(values);
						List<String> userPreferencesChildFoldersList =ExternalSharingFileFolderUtil.getChildsForPreferenceFolderList(serviceRegistry,values,usersId);
						 if(userPreferencesChildFoldersList!=null && userPreferencesChildFoldersList.size()>0) {
							 logs.info("child folder exists ::: "+userPreferencesChildFoldersList.toString());
							 userPreferencesFoldersList.addAll(userPreferencesChildFoldersList);
						}	
					}else{
						List<String> userPreferencesChildFoldersList =ExternalSharingFileFolderUtil.getChildsForPreferenceFolderList(serviceRegistry,values,usersId);
						 if(userPreferencesChildFoldersList!=null && userPreferencesChildFoldersList.size()>0) {
							 logs.info("child folder exists ::: "+userPreferencesChildFoldersList.toString());
							 userPreferencesFoldersList.addAll(userPreferencesChildFoldersList);
						}	
					}
				}else if(preferenceRemoveAction.equals(PREFERENCE_REMOVE_ACTION_NO) && hasUserAccessOnParent){
					userPreferencesFoldersList.add(values);
				}
				//logs.info("userPreferencesFoldersList----------:"+userPreferencesFoldersList);
				preferences.put(preferenceFilter, StringUtils.join(userPreferencesFoldersList, ","));
				} else{
					preferences.put(preferenceFilter, values);
				}
		 }catch(Exception exe) {
			 logs.error("Exception in updatedPreferences ----"+exe);
			 exe.printStackTrace();
		 }
		return preferences;
	}
	//END: Added by prbadam for the defect DE1465.
	
    private List<String> addUserPermissions(final NodeRef documentNodeRef, final JSONArray users,
            final List<String> existingUsersList, final String loggedinUser,final boolean inheritPermissionValue,final boolean isCiscoRestricted,boolean isCascadePermissionValue)
            throws Exception
    {
        logs.info(".Starting Add User(s) & Permissions....");
        logs.info(".existingUsersList...."+existingUsersList.toString());
        logs.info(".inheritPermissionValue...."+inheritPermissionValue);
        QName folderdoctype = serviceRegistry.getNodeService().getType(documentNodeRef);
        final String folderType = folderdoctype.toString().substring(43);
        logs.info("Folder Root: " + folderType);  //folder
        final List<String> newUsers = new ArrayList<String>();
        try{
        
        AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
        {
            @Override
            public Object doWork() throws Exception
            {
                boolean usrExist = false;
                boolean groupExistInRepo = false;
                try{
                	// Removing ALL existing users & permissions
                	if(existingUsersList.size()>0){
                	for (String existUser : existingUsersList)
                    {
                		logs.info("  ::::: Removed users from node  :::::: "+existUser);
                        // serviceRegistry.getPermissionService().deletePermissions(documentNodeRef,existUser);
                        //if (!loggedinUser.equalsIgnoreCase(existUser))
                            serviceRegistry.getPermissionService().clearPermission(documentNodeRef, existUser);
                          //Fix for library performance issue adding custom aspect
            			  addUserPreferencesProps(existUser,documentNodeRef,PREFERENCE_REMOVE_ACTION_YES);
                    }
                	}
                	
            	if(users.length()>0){
            		logs.info(".users...."+users.toString());
            	for (int i = 0; i < users.length(); i++)
                {
            		if(users.getJSONObject(i).getString("type").toString().equalsIgnoreCase("user")){
            			logs.info(users.getJSONObject(i).getString("type").toString()+" :::::: " +users.getJSONObject(i).getString("userId"));
                    usrExist = serviceRegistry.getPersonService().personExists(		
                        users.getJSONObject(i).getString("userId"));
                    if (!usrExist)	
                    {
                        createLDAPUser(users.getJSONObject(i).getString("userId"));
                    }
            		}
            		if(users.getJSONObject(i).getString("type").toString().equalsIgnoreCase("grouper")){
            			logs.info(users.getJSONObject(i).getString("type").toString()+" :::::: " +users.getJSONObject(i).getString("userId"));
            			groupExistInRepo=serviceRegistry.getAuthorityService().authorityExists(users.getJSONObject(i).getString("userId"));
            			logs.info(users.getJSONObject(i).getString("userId")+" Group ExistInRepo :::: "+groupExistInRepo);
            			if (!groupExistInRepo)	
                         {
            				 createLDAPGroupInRepository(users.getJSONObject(i).getString("userId"));
                         }
            		}
                    
                    newUsers.add(users.getJSONObject(i).getString("userId"));
                    logs.info("permissions update for :::: " + users.getJSONObject(i).getString("userId")+":::"+users.getJSONObject(i).getString("permissionLevel"));
                    String userValue = users.getJSONObject(i).getString("userId");
                    String permission = users.getJSONObject(i).getString("permissionLevel");
                    logs.debug("the name of the user or group is ::" +userValue);
                    logs.debug("the name of the permission is::"+permission);
                    
                    if(!userValue.isEmpty() && !permission.isEmpty()){
                    	//Start:US8124 Disallow groups on Restricted Content
                    	if(isCiscoRestricted && !userValue.contains(GROUP_IDENTITY)){
                    		serviceRegistry.getPermissionService().setPermission(documentNodeRef,
        	                        users.getJSONObject(i).getString("userId"),
        	                        users.getJSONObject(i).getString("permissionLevel"), true);
        	                    serviceRegistry.getPermissionService().setInheritParentPermissions(documentNodeRef,
        	                            inheritPermissionValue);
                    	}else{
                    		if (userValue.contains(GROUP_IDENTITY) && permission.contains("AdminRole")){
    	                    	logs.info("you are not authorised to create this group"+users.getJSONObject(i).getString("userId"));
    	                    }else{
    	                    	serviceRegistry.getPermissionService().setPermission(documentNodeRef,
    	                        users.getJSONObject(i).getString("userId"),
    	                        users.getJSONObject(i).getString("permissionLevel"), true);
    	                    serviceRegistry.getPermissionService().setInheritParentPermissions(documentNodeRef,
    	                            inheritPermissionValue);
    	                    }
                    	}
                    	//End:US8124 Disallow groups on Restricted Content
                    }
                }
            }else{
            	logs.info("::::: Inherit and folder conditions  ::::::::: "+inheritPermissionValue);
            	serviceRegistry.getPermissionService().setInheritParentPermissions(documentNodeRef,inheritPermissionValue);
            }
                }catch(Exception ex){
                	ex.printStackTrace();
                	logs.info("exception "+ex.getMessage());
                }
              //START: prbadam commented below line because of US5946 - Send Publishing Notifications on a weekly basis
                //sendMailNotification(documentNodeRef, newUsers, loggedinUser);
              //END: prbadam commented below line because of US5946 - Send Publishing Notifications on a weekly basis
               // long endTime = System.currentTimeMillis();
               // logs.info("EndTime addUserPermissions  : "+new Date(endTime));
                
                logs.info("newUsers addUserPermissions  : "+newUsers);
                return null;
            }
        }, "admin");
        }catch(Exception e){
        	e.printStackTrace();
        	logs.info("exception "+e);
        }
        return newUsers;
    }

    public boolean isPermissionChangeAllowed(String userId, ArrayList<String> permission)
    {
        logs.info(new StringBuffer("Checking whether user can change the permision or not. User Id: ")
                .append(userId)
                    .append("Permission :")
                    .append(permission));
        String supportGroupName = globalProperties.getProperty("docex.supportgroup.name");
        boolean isSupportUser=ExternalSharingFileFolderUtil.isMemberofGroup(serviceRegistry,userId,supportGroupName);
        if (permission != null
                && (permission.contains("OwnerRole") || permission.contains("AdminRole") || permission.contains("Folder Admin") || isSupportUser))
            return true;
        else
            return false;
    }

    public boolean isUserInternal(String userid)
    {
        logs.info((new StringBuilder("Start checking if internal LDAP users.. ")).append(userid).toString());

        return ldapUtil.isLdapUserInternal((new StringBuilder(String.valueOf(userid))).toString());
        // out.info((new StringBuilder("idAndName: ")).append(idAndName).toString());
    }
    public boolean isUserGenerics(String userid)
	  {
    	logs.info((new StringBuilder("Start checking if Generics LDAP users.. ")).append(userid).toString());
	      return ldapUtil.isLdapUserGeneric((new StringBuilder(String.valueOf(userid))).toString());
	  }
    public void sendMailNotification(NodeRef documentNodeRef, List<String> users, String logginUser)
    {
        logs.info(".sendMailNotification: " + users);
        Date currentDate = new Date();
    	String year = new SimpleDateFormat("yyyy").format(currentDate);
        String userid = null;
        List<String> usersEmailList = new ArrayList<String>();
        final Map<String, Object> templateModel = new HashMap<String, Object>();
        
    	boolean isDocument = serviceRegistry.getDictionaryService().isSubClass(nodeService.getType(documentNodeRef), ContentModel.TYPE_CONTENT);
    	logs.info("isDocument-------------"+isDocument);
        for (int i = 0; i < users.size(); i++)
        {
            userid = users.get(i);
            String personEmail = getEmail(userid);
            logs.info("personEmail : " + personEmail);
            // for removing email duplicates from list
            if (!usersEmailList.contains(personEmail))
            {
                usersEmailList.add(personEmail);
            }
        }
        // end of removing email duplicates from list
        logs.info("usersEmailList : " + usersEmailList);

        // String fromMail = ADD_USER_FROM_MAIL;
        String fromMail = getEmail(logginUser);
        String DocName = (String) nodeService.getProperty(documentNodeRef, ContentModel.PROP_NAME);
        String docVersion =(String) nodeService.getProperty(documentNodeRef, ContentModel.PROP_VERSION_LABEL); 
        if(docVersion ==null || docVersion.equals("")){
        	docVersion="1.0";
        }
        logs.info("doc version ::"+docVersion);
        NodeRef publisherNode = serviceRegistry.getPersonService().getPerson(logginUser);

        String firstName = (String) nodeService.getProperty(publisherNode, ContentModel.PROP_FIRSTNAME);
        String lastName = (String) nodeService.getProperty(publisherNode, ContentModel.PROP_LASTNAME);
        String fullName = firstName + " " + lastName;
        String subject;
      /*  NodeRef template = getEmailtemplate(addUserFtlLocationPath, ADD_USER_NOTIFICATION_TEMPLATE);
        logs.info("addUserFtlLocationPath: " + addUserFtlLocationPath); 
        logs.info("Template: " + template);*/

        templateService = serviceRegistry.getTemplateService();
        templateModel.put("docName", DocName);
       
        templateModel.put("fullName", fullName);
        templateModel.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
		if(isDocument){
            subject = fullName + " " + ADD_USER_DOC_SUBJECT;
            templateModel.put("msg",fullName+" has published ");
            templateModel.put("titleURL", titleURL+"/alfext/ui/#/whatsnew"); 
            templateModel.put("folderMsg","");
            templateModel.put("docVersion", docVersion);
            } else{
            	 logs.info("folder noderef-------------"+documentNodeRef);
            	 subject = fullName + " " + ADD_USER_FOLDER_SUBJECT;
            	 String uuid = documentNodeRef.getId();
            	 templateModel.put("msg",fullName+" has published a folder");
            	 templateModel.put("titleURL", titleURL+"/alfext/ui/#/library/"+uuid); 
            	 templateModel.put("folderMsg",FOLDER_MSG);
            	 templateModel.put("docVersion", "");
            }
		templateModel.put("year", year); 
       // logs.info("templateService: " + templateService + " template: " + template);
        String htmlBody = templateService.processTemplate(ADD_USER_NOTIFICATION_TEMPLATE, templateModel);
        logs.info("usersEmailList before send mail : " + usersEmailList);

        try
        {
            MailUtil.sendMail(mailServer, fromMail, usersEmailList.toArray(new String[usersEmailList.size()]), null,
                subject, htmlBody, null);
            logs.info("Mail sent successfully from DocumentUserPermissions.java--------->");
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        logs.info("usersEmailList After send mail : " + usersEmailList);
        usersEmailList.clear();
    }

    /**
     * To Get Email Template
     */
  /*  private NodeRef getEmailtemplate(String path, String templateName)
    {
        String templateConditionalPath = "PATH:\"" + path + "//*\" AND " + "TYPE:cm\\:content AND @cm\\:name:\""
                + templateName + "\"";
        if (logs.isDebugEnabled())
        {
            logs.info("LUCENE QRY: " + templateConditionalPath);
        }
        ResultSet resultSet = serviceRegistry.getSearchService().query(
            new StoreRef(StoreRef.PROTOCOL_WORKSPACE, "SpacesStore"), SearchService.LANGUAGE_LUCENE,
            templateConditionalPath);

        if (resultSet.length() == 0)
        {
            logs.info("Template " + templateConditionalPath + " not found.");
            return null;
        }
        NodeRef template = resultSet.getNodeRef(0);
        if (logs.isDebugEnabled())
        {
            logs.info("Got the Email Template:" + template.toString());
        }
        return template;
    }
*/
    public void createLDAPUser(String userid)
    {
        logs.info(".Start creating LDAP users.. " + userid);

        final Set<String> zoneSet = getZones(zoneId);
        String idAndName = ldapUtil.getUserDetailsFromLDAP(userid);
        logs.info("idAndName =" + idAndName);
        // idAndName =spathi::Satya Narayana::Cisco Systems, Inc.

        final String userName = (idAndName.split("::"))[0];
        logs.info("userName =" + userName);

        String name = (idAndName.split("::"))[1];
        logs.info("name =" + name);

        String organization = (idAndName.split("::"))[2];

        String firstName = "", lastName = "";
        if (name.contains(" "))
        {

            firstName = (name.split(" "))[0];
            logs.info("firstName =" + firstName);

            lastName = (name.split(" "))[1];
            logs.info("lastName =" + lastName);
        }
        else
            firstName = name;

        String email = (idAndName.split("::"))[3];

        final HashMap<QName, Serializable> properties = new HashMap<QName, Serializable>();
        properties.put(ContentModel.PROP_USERNAME, userName);
        // properties.put(ContentModel.PROP_HOMEFOLDER, userNodeRef);
        properties.put(ContentModel.PROP_FIRSTNAME, firstName);
        properties.put(ContentModel.PROP_LASTNAME, lastName);
        properties.put(ContentModel.PROP_EMAIL, email);
        properties.put(ContentModel.PROP_ORGANIZATION, organization);

        try
        {
            NodeRef newPerson = serviceRegistry.getPersonService().createPerson(properties, zoneSet);
            logs.info("newPerson==" + newPerson);
            MutableAuthenticationService authService = serviceRegistry.getAuthenticationService();
            authService.createAuthentication(userName, userName.toCharArray());
            authService.setAuthenticationEnabled(userName, true);
        }
        catch (Exception e)
        {
            logs.info("Exception at creating person:: " + e);
            e.printStackTrace();
        }

    }

    /**
     * @param groupId
     * @return create group with members
     */
    @SuppressWarnings("unused")
	public void createLDAPGroupInRepository(String groupId)
    {
    	String groupType="allgroups";//mailer or hrgroup or allgroups
    	logs.info("Looking for members for " + groupId);
    	groupId = groupId.replaceAll(GROUP_IDENTITY, "");
    	logs.info("group name is ::"+groupId);
		Map<String, Set<String>> members = mailerGroupLdapUtil.getGroupMembers(groupId);
		logs.info("again the real group name is::"+groupId);
		logs.info("totel members in group"+members);
		logs.info("size of the members"+ members.size());
		if( members.size() > 1) {
			logs.info("Unable to create groups. Search for " + groupId + " " +
					"matched multiple group names and it must match only a single group.");
		} else if( members.size() == 0 ) {
			logs.info("Unable to create groups. Search for " + groupId + " " +
					"matched no group names.");
		} else {
			for( Entry<String, Set<String>> curGroup : members.entrySet() ) {
				String displayName = curGroup.getKey();
				
				String givenName = serviceRegistry.getAuthorityService().createAuthority(AuthorityType.GROUP, groupId);
				displayName=displayName.replace("displayName: ", "");
				logs.info("Created group " + givenName + " with display " + displayName );
				serviceRegistry.getAuthorityService().setAuthorityDisplayName(givenName, displayName);
				List<String> groupAsList = Arrays.asList(new String [] { givenName });
				//Add users!
				for( String childName : curGroup.getValue() ){
					//logs.info("User Exited in Repo : " + serviceRegistry.getPersonService().getPerson(childName));
					logs.info("User Exited in Repo :" +childName);
					String userEmail = ldapUtil.getManagerEmailFromLDAP(childName);
					if(userEmail!=null && userEmail!="" ){
					logs.info("user email address::"+userEmail);
					 boolean isCiscoDomainUser = userEmail.contains(CISCO_MAILID);
					 logs.info("is user exists in cisco::"+isCiscoDomainUser);
					//Adding only cisco domain users to Groups
					if(isCiscoDomainUser && serviceRegistry.getPersonService().getPerson(childName) != null)
						serviceRegistry.getAuthorityService().addAuthority(groupAsList, childName);
					else
						logs.info("Couldn't find authority to add: " + childName);
					}else{
						logs.info("Couldn't add inactive user authority to group: " + childName);
					}
				}
				logs.info("Added " + serviceRegistry.getAuthorityService().getContainedAuthorities(null, givenName, true).size());
			}
			logs.info("Successfully created group " + groupId);
		}
    }
    
    private List<String> getAllMemebersFromGroup(List<String> listOfUsersandGroups){
    	List<String> allUsersandGroupMembers=new ArrayList<String>();
    	
    	 for(String addedUserNames : listOfUsersandGroups){
  		   logs.info("added User and groups------------"+addedUserNames);
  		   if(addedUserNames.contains(GROUP_IDENTITY)){
  			 Set<String> members=serviceRegistry.getAuthorityService().getContainedAuthorities(AuthorityType.USER, addedUserNames, true);
  			Iterator<String> memberUserIds = members.iterator();
  		     while(memberUserIds.hasNext()){
  		    	allUsersandGroupMembers.add(memberUserIds.next());
  		     }
  		   }else{
  			 allUsersandGroupMembers.add(addedUserNames);
  		   }
  		   logs.info("allUsersandGroupMembers ::::"+allUsersandGroupMembers.toString());
  	   }
		return allUsersandGroupMembers;
    }
    
    
    /**
     * @param userName
     * @return Get email of person
     */
    private String getEmail(String userName)
    {
    	NodeRef personNodeRef = serviceRegistry.getPersonService().getPerson(userName, false);
        String personEmailId = (String) serviceRegistry.getNodeService().getProperty(personNodeRef, ContentModel.PROP_EMAIL); 
        logs.info("personEmailId----------"+personEmailId);
        return personEmailId != null ? personEmailId : "";
    }
    
    /**
     * for List of the Removed users
     */
    private List<String> getRemovedUsers(HashMap<String, String> updateRemoveUsersMap,String logginUser) {
    	List<String> users=new ArrayList<String>();
		
    	 for (Entry<String, String> updateRemoveUsers : updateRemoveUsersMap.entrySet()) {
             String key = updateRemoveUsers.getKey();
            // if(!logginUser.equals(key)){
             users.add(key);
             //}
    	 }
		return users;
	}
    
    
    /**
     * for list of add or updated user permissions 
     */
    public JSONArray mapToJsonArray(Map<String, String> addUpdateUsersMap )
    {       
    	JSONArray usersArray=new JSONArray();
        for (Entry<String, String> addUpdateUsers : addUpdateUsersMap.entrySet()) {
            String key = addUpdateUsers.getKey();
            Object value = addUpdateUsers.getValue();
            JSONObject usersJsonObj=null;
            try {
            	usersJsonObj = new JSONObject();
            	usersJsonObj.put("userId",key);
            	usersJsonObj.put("permissionLevel",value);
            	if(key.contains(GROUP_IDENTITY)){
            		usersJsonObj.put("type","grouper");
            	}else{
            		usersJsonObj.put("type","user");
            	}
            	
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }    
            usersArray.put(usersJsonObj);
        }
        return usersArray;
    }
    
    public ExternalLDAPUtil getLdapUtil()
    {
        return ldapUtil;
    }

    public void setLdapUtil(ExternalLDAPUtil ldapUtil)
    {
        this.ldapUtil = ldapUtil;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    public NodeService getNodeService()
    {
        return nodeService;
    }

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

  /*  public String getAddUserFtlLocationPath()
    {
        return addUserFtlLocationPath;
    }

    public void setAddUserFtlLocationPath(String addUserFtlLocationPath)
    {
        this.addUserFtlLocationPath = addUserFtlLocationPath;
    }
*/
    public void setMailServer(String mailServer)
    {
        this.mailServer = mailServer;
    }

    public String getMailServer()
    {
        return mailServer;
    }

    private Set<String> getZones(final String zoneId)
    {
        Set<String> zones = new HashSet<String>(5);
        zones.add(AuthorityService.ZONE_APP_DEFAULT);
        zones.add(zoneId);
        return zones;
    }
    public void setBannerAlfrescoUrl(String bannerAlfrescoUrl)
    {
        this.bannerAlfrescoUrl = bannerAlfrescoUrl;
    }

    public String getBannerAlfrescoUrl()
    {
        return bannerAlfrescoUrl;
    }

	public String getTitleURL() {
		return titleURL;
	}

	public void setTitleURL(String titleURL) {
		this.titleURL = titleURL;
	}

	public MailerGroupSearchUtil getMailerGroupLdapUtil() {
		return mailerGroupLdapUtil;
	}

	public void setMailerGroupLdapUtil(MailerGroupSearchUtil mailerGroupLdapUtil) {
		this.mailerGroupLdapUtil = mailerGroupLdapUtil;
	}

	public void setAuditComponent(ExternalPermissionAuditUtil auditComponent) {
		this.auditComponent = auditComponent;
	}

	public String getMailerFromID() {
		return mailerFromID;
	}

	public void setMailerFromID(String mailerFromID) {
		this.mailerFromID = mailerFromID;
	}

	public String getContextName() {
		return contextName;
	}

	public void setContextName(String contextName) {
		this.contextName = contextName;
	}
	
	public class ProcessCascadePermissions extends Thread {

		private NodeRef nodeRef;
		private JSONArray users;
		private List<String> existingUsersList;
		private String logginUser;
		private Boolean inheritPermissionValue;
		private Boolean isCascadePermissionValue;
		private String mailerFromID;
		private String mailServer;
		private String bannerAlfrescoUrl;
		private String titleURL;
		private String contextName;
		private String loggedeInUser;

		public ProcessCascadePermissions(final NodeRef nodeRefValue, final JSONArray users,
				final List<String> existingUsersList, final String logginUser, final Boolean inheritPermissionValue,
				final Boolean isCascadePermissionValue, final String mailerFromID, final String mailServer,
				final String bannerAlfrescoUrl, final String titleURL, final String contextName,
				final String loggedeInUser) {
			this.nodeRef = nodeRefValue;
			this.users = users;
			this.existingUsersList = existingUsersList;
			this.logginUser = logginUser;
			this.inheritPermissionValue = inheritPermissionValue;
			this.isCascadePermissionValue = isCascadePermissionValue;
			this.mailerFromID = mailerFromID;
			this.mailServer = mailServer;
			this.bannerAlfrescoUrl = bannerAlfrescoUrl;
			this.titleURL = titleURL;
			this.contextName = contextName;
			this.loggedeInUser = loggedeInUser;
		}

		@Override
		public void run() {

			try {
				AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
					@Override
					public Object doWork() throws Exception {
						ApplyCascadePermissions(nodeRef, users, existingUsersList, logginUser, inheritPermissionValue,
								isCascadePermissionValue, mailerFromID, mailServer, bannerAlfrescoUrl, titleURL,
								contextName, loggedeInUser);
						return null;
					}
				}, "admin");
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}
	private void ApplyCascadePermissions(NodeRef nodeRef, JSONArray users, List<String> existingUsersList,
			String logginUser, Boolean inheritPermissionValue, Boolean isCascadePermissionValue, String mailerFromID,
			String mailServer, String bannerAlfrescoUrl, String titleURL, String contextName, String loggedeInUser) {
		logs.info("...Applying permissions Bottom to Top....");
		List<NodeRef> reverse = new ArrayList<NodeRef>();
		List<NodeRef> nodeRefs = getDeepLevelFolders(nodeRef);
		ListIterator<NodeRef> itr = nodeRefs.listIterator(nodeRefs.size());
		while (itr.hasPrevious()) {
			reverse.add(itr.previous());
		}
		for (NodeRef folderId : nodeRefs) {
			Map<String, String> localInfo = getLocalPermissions(folderId);
			Map<String, String> inheritInfo = new HashMap<String, String>();
			Set<AccessPermission> userSet = ExternalSharingFileFolderUtil.getAllNodeRefPermissions(serviceRegistry, folderId);
			Iterator<AccessPermission> fIterator = userSet.iterator();
			while (fIterator.hasNext()) {
				AccessPermission accessPermission = (AccessPermission) fIterator.next();
				inheritInfo.put(accessPermission.getAuthority(), accessPermission.getPermission());
			}
			//logs.info("==Child Folder inheritInfo==" + inheritInfo.toString());
			Map<String, String> inheritPermissions = new HashMap<String, String>();
			for (String user : inheritInfo.keySet()) {
				//logs.info("==Child Folder iterating users==" + user);
				String highestPermission = ExternalSharingFileFolderUtil.getUserRole(serviceRegistry, user, nodeRef);
				//logs.info("==Child Folder Inherit User==" + user + "==highestPermission=" + highestPermission);
				if (highestPermission.equals("Reader") || highestPermission.equals("Viewer")
						|| highestPermission.equals("Editor"))
					highestPermission = highestPermission + "Role";
				inheritPermissions.put(user, highestPermission);

			}

			//logs.info("==Child Folder inheritPermissions==" + inheritPermissions.toString());
			Map<String, String> comparePermissions = compringLocalAndInheritPermissions(inheritPermissions, localInfo);
			//logs.info("==Child Folder comparePermissions==" + comparePermissions.toString());
			Map<String, String> finalMap = new HashMap<String, String>();
			for (String key : comparePermissions.keySet()) {
				String permission = comparePermissions.get(key);
				//logs.info("==Child Folder User ==" + key + "==Permission=" + permission);
				if (permission.contains(",")) {
					//logs.info("==Child Folder permission.contains()==" + permission.contains(","));
					String split[] = permission.split(",");
					int perm1 = 0;
					int perm2 = 0;
					String permCompare1 = split[0];
					String permCompare2 = split[1];
					String newPerm1 = (String) permCompare1.replace(" ", "").replace("[", "").replace("Role", "")
							.toString();
					if (newPerm1.equals("FolderAdmin")) {
						newPerm1 = "Admin";
					}
					String newPerm2 = (String) permCompare2.replace(" ", "").replace("]", "").replace("Role", "")
							.toString();
					if (newPerm2.equals("FolderAdmin")) {
						newPerm2 = "Admin";
					}
					//logs.info("==Child Folder User permCompare1 ==" + newPerm1 + "==permCompare2=" + newPerm2);
					if (ExternalSharingConstants.UsersRoleHerarcy.containsKey(newPerm1)) {
						perm1 = ExternalSharingConstants.UsersRoleHerarcy.get(newPerm1.toString()).intValue();
					}
					if (ExternalSharingConstants.UsersRoleHerarcy.containsKey(newPerm2)) {
						perm2 = ExternalSharingConstants.UsersRoleHerarcy.get(newPerm2.toString()).intValue();
					}
					permission = (perm1 > perm2) ? newPerm1 : newPerm2;
					if (permission.equals("Admin")) {
						permission = "AdminRole";
					}
					//logs.info(" Permission Changed ==" + permission + "==for ==" + key);
					finalMap.put(key, permission);

				}
				if (permission.equals("Folder Admin")) {
					permission = "AdminRole";
				}
				finalMap.put(key, permission);

			}
			//logs.info("==Child Folder finalMap==" + finalMap.toString());
			if (finalMap != null && !finalMap.isEmpty()) {
				for (Map.Entry<String, String> entry : finalMap.entrySet()) {
					String userValue = entry.getKey();
					String permissionValue = entry.getValue();
					if (!userValue.isEmpty() && !permissionValue.isEmpty()) {
						if (userValue.contains(GROUP_IDENTITY) && permissionValue.contains("AdminRole")) {
							logs.info("you are not authorised to create this group" + userValue);
						} else {
							serviceRegistry.getPermissionService().setPermission(folderId, userValue, permissionValue,
									true);
						}
					}

				}
			}
			serviceRegistry.getPermissionService().setInheritParentPermissions(folderId, false);
		}

		for (NodeRef folderNodeID : reverse) {
			processCascadeUserPermissions(folderNodeID, users, existingUsersList, logginUser, inheritPermissionValue,
					isCascadePermissionValue);
		}

		String strManagerID = ldapUtil.getManagerEmailFromLDAP(loggedeInUser);
		final QName type = serviceRegistry.getNodeService().getType(nodeRef);
		String permissionUrl = null;
		if (type.equals(ContentModel.TYPE_FOLDER)) {
			permissionUrl = titleURL + contextName + "/ui/#/folder/permissions/" + nodeRef.getId();
		} else {
			permissionUrl = titleURL + contextName + "/ui/#/file/permissions/" + nodeRef.getId();
		}
		String navigatePemissionMsg = "<span style='color:#6683BF;text-decoration: none;'><a href=" + permissionUrl
				+ ">Click here</a></span> to go to updated permissions page.";
		Map<QName, Serializable> nodeProp = serviceRegistry.getNodeService().getProperties(nodeRef);
		String name = (String) nodeProp.get(ContentModel.PROP_NAME);
		//send cascade update status email notification to user
		sendEMail(name, strManagerID, null, navigatePemissionMsg);
	}
	/**
	 * To get the deep level child folders
	 */
	public List<NodeRef> getDeepLevelFolders(NodeRef parentNodeRef) {
		List<NodeRef> result = new ArrayList<NodeRef>();
		// Build a list of folder types
		Set<QName> folderTypeQNames = new HashSet<QName>();
		folderTypeQNames.add(ContentModel.TYPE_FOLDER);
		Stack<NodeRef> toSearch = new Stack<NodeRef>();
		toSearch.push(parentNodeRef);
		// Now we need to walk down the folders.
		while (!toSearch.empty()) {
			NodeRef currentDir = toSearch.pop();
			List<ChildAssociationRef> folderAssocRefs = nodeService.getChildAssocs(currentDir, folderTypeQNames);
			for (ChildAssociationRef folderRef : folderAssocRefs) {
				NodeRef nodeRef = folderRef.getChildRef();
				final QName nodeType = nodeService.getType(nodeRef);
				if (ContentModel.TYPE_FOLDER.isMatch(nodeType)) {
					toSearch.push(nodeRef);
					result.add(nodeRef);
				}
			}
		}
		return result;
	}
	public void sendEMail(String name, String strManagerID, String filePath, String navigatePemissionMsg) {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("year", new SimpleDateFormat("yyyy").format(new Date()));
		model.put("bannerAlfrescoUrl", bannerAlfrescoUrl);
		model.put("name", name);
		model.put("navigatePemissionMsg", navigatePemissionMsg);
		TemplateService templateService = serviceRegistry.getTemplateService();
		String strArray[] = strManagerID.split(",");
		String mailSubject = "Applying Cascade Permissions to (" + name + ") is now complete";
		String htmlBody = templateService.processTemplate(CASCADE_USER_NOTIFICATION_TEMPLATE, model);
		boolean mailstatus = false;
		try {
			mailstatus = MailUtil.sendMail(mailServer, mailerFromID, strArray, null, mailSubject, htmlBody, filePath);
			logs.info("Mail Sataus >>>" + mailstatus + "   For user  ::  " + strManagerID);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private Map<String, String> getLocalPermissions(NodeRef nodeRef) {

		Map<String, String> permissionInfo = new HashMap<String, String>();
		try {
			PermissionService permissionService = serviceRegistry.getPermissionService();
			Set<AccessPermission> accessPermissions = permissionService.getAllSetPermissions(nodeRef);
			logs.info("Permissions: " + accessPermissions);
			Iterator<AccessPermission> fIterator = accessPermissions.iterator();
			AccessPermission accessPerm = null;
			while (fIterator.hasNext()) {
				accessPerm = fIterator.next();
				if (!accessPerm.isInherited()) {
					permissionInfo.put(accessPerm.getAuthority(), accessPerm.getPermission().toString());
				}
			}

		} catch (Exception e) {
			logs.info("Error in getUserEmailList : " + e.getMessage());
		}
		return permissionInfo;
	}
	
	private Map<String, String> compringLocalAndInheritPermissions(Map<String, String> localPermissions,
			Map<String, String> inheritPermissions) {
		Map<String, String> finalMap = new HashMap<String, String>();
		List<String> list = new ArrayList<String>();
		try {
			for (final String key : localPermissions.keySet()) {
				if (inheritPermissions.containsKey(key)
						&& localPermissions.get(key).equalsIgnoreCase(inheritPermissions.get(key))) {
					logs.info("==Skipping............");
					continue;
				} else if (inheritPermissions.containsKey(key)
						&& !localPermissions.get(key).equalsIgnoreCase(inheritPermissions.get(key))) {
					list.add(localPermissions.get(key));
					list.add(inheritPermissions.get(key));
					finalMap.put(key, list.toString());
				} else if (!localPermissions.get(key).equalsIgnoreCase(inheritPermissions.get(key))) {
					finalMap.put(key, localPermissions.get(key));
				}
				for (String string : inheritPermissions.keySet()) {
					if (!localPermissions.containsKey(string) && inheritPermissions.containsKey(string)) {
						finalMap.put(string, inheritPermissions.get(string));
					}
				}
			}
		} catch (Exception e) {
			logs.info("Error in getUserEmailList : " + e.getMessage());
		}
		return finalMap;
	}
}