package com.cisco.edcsng.userinfo.permission;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.json.JSONObject;

public class UpdateUserProperties extends AbstractWebScript {
	
	private static Logger log = Logger.getLogger(UpdateUserProperties.class);
	private PersonService personService;
	private Properties globalProperties;
	private ServiceRegistry serviceRegistry;
	
	public void setGlobalProperties(Properties globalProperties) {
		this.globalProperties = globalProperties;
	}
	
	public PersonService getPersonService() {
		return personService;
	}

	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }
	
	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		try {
			
			log.info("entering into UpdateUserProps class:");
			
			org.springframework.extensions.surf.util.Content content = req.getContent();
			org.json.JSONObject json = new org.json.JSONObject(content.getContent());
			JSONObject jsonObj = new JSONObject();
			
			String userId;
			String email		= null;
			String firstName	= null;
			String lastName		= null;
			String company		= null;
			boolean isExisted   = false;
			boolean isOpsSupportUser = false;
            //Checking is Support User or not.
			 String currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
            isOpsSupportUser = isSupportGroupUser(currentUser);
            log.info("coming from group ===> " + isOpsSupportUser);
			if(isOpsSupportUser) {
			final HashMap<QName, Serializable> properties = new HashMap<QName, Serializable>();
			/* userId is mandatory */
			if (json.getString("userId") != null && json.getString("userId").length()>0) {
				userId	  = json.getString("userId");
				isExisted = personService.personExists(userId);
				if (personService.personExists(userId)) {
					properties.put(ContentModel.PROP_USERNAME, userId);
				} else {
					log.info("userId is not existed in repo:"+isExisted);
					jsonObj.put("message", "userId is not existed in repo");
					res.setContentType("application/json");
					res.getWriter().write(jsonObj.toString());
					res.getWriter().close();
					return;
				}
			} else {
				jsonObj.put("message", "userId is missing/invalid");
				res.setContentType("application/json");
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
				return;
			}
			
			/*below are otional */
			if (json.has("firstName")) {
				if (json.getString("firstName") != null && json.getString("firstName").length()>0) {
					firstName	  = json.getString("firstName");
					properties.put(ContentModel.PROP_FIRSTNAME, firstName);
				}
			} else {
				log.info("firstName not existed");
			}
			
			if (json.has("lastName")) {
				if (json.getString("lastName") != null && json.getString("lastName").length()>0) {
					lastName	  = json.getString("lastName");
					properties.put(ContentModel.PROP_LASTNAME, lastName);
				}
			}
			
			if (json.has("company")) {
				if (json.getString("company") != null && json.getString("company").length()>0) {
					company	  = json.getString("company");
					properties.put(ContentModel.PROP_ORGANIZATION, company);
				}
			}
			
			if (json.has("email")) {
				if (json.getString("email") != null && json.getString("email").length()>0) {
					email	  = json.getString("email");
					properties.put(ContentModel.PROP_EMAIL, email);
				}
			}
			
				
			if (properties != null && properties.size() >0) {
				log.info("final map elements:"+properties.toString());
				
		    String message=AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<String>()
               {
                @Override
                public String doWork() throws Exception 
                {
				personService.setPersonProperties(userId, properties);
				return "user properties updated successfully";
                     }
                 }, "admin");
		        jsonObj.put("message", message);
				
			} else {
				log.info("Empty map is empty:");
			}
			res.setContentType("application/json");
			res.getWriter().write(jsonObj.toString());
			res.getWriter().close();
			}else {
				jsonObj.put("message", "User details are not udpated. You are not authorized to perform this operation, please contact System Admin for further information.");
				res.setContentType("application/json");
				res.getWriter().write(jsonObj.toString());
				res.getWriter().close();
				return;
			}
		} catch (Exception e) {
			log.info ("Exception:"+e);
			e.printStackTrace();
		}
	}
	
	public boolean isSupportGroupUser(String currentUserName) {
		boolean isUserExistinGroup = false;
		isUserExistinGroup=AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>()
        {
         @Override
         public Boolean doWork() throws Exception 
         {
        	 boolean isUserExistinGroup = false;
        	 Set<String> userAuthorities = serviceRegistry.getAuthorityService().getAuthoritiesForUser(currentUserName);
     		String supportGroupName = globalProperties.getProperty("docex.supportgroup.name");
     		if(supportGroupName != null && userAuthorities.contains(supportGroupName)) {
     			isUserExistinGroup = true;
     		}
			return isUserExistinGroup;
              }
          }, "admin");
			return isUserExistinGroup;
	}
	
}
