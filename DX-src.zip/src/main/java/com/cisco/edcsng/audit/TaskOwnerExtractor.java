package com.cisco.edcsng.audit;

import java.io.Serializable;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.extractor.AbstractDataExtractor;
import org.alfresco.service.cmr.workflow.WorkflowService;
import org.alfresco.service.cmr.workflow.WorkflowTask;


/**
 * 
 * @author dhshaw
 * 
 */
public class TaskOwnerExtractor extends AbstractDataExtractor
{

    public boolean isSupported(Serializable data)
    {
        return (data instanceof String);
    }

    public Serializable extractData(Serializable in) throws Throwable
    {
        Serializable owner = null;
        try
        {
            logger.debug("[TaskOwnerExtractor] - Serializable Data : " + in);
            String taskId = (String) in;
            WorkflowTask task = workflowService.getTaskById(taskId);
            owner = task.getProperties().get(ContentModel.PROP_OWNER);
            // task.getId();
            logger.info("[TaskOwnerExtractor] - Task getId: " + task.getId());
            logger.debug("[TaskOwnerExtractor] - Task owner: " + owner);
        }
        catch (Exception e)
        {
            logger.error(e);
            throw e;
        }
        return owner;
    }

    private WorkflowService workflowService;

    public void setWorkflowService(WorkflowService workflowService)
    {
        this.workflowService = workflowService;
    }

}
