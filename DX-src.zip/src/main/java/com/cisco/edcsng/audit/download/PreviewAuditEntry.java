package com.cisco.edcsng.audit.download;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.audit.access.AccessAuditor;
import org.alfresco.repo.processor.BaseProcessorExtension;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.ISO9075;
import org.apache.log4j.Logger;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;

public class PreviewAuditEntry  extends BaseProcessorExtension 
    {
	private AccessAuditor accessAuditor;
	private static Logger Log = Logger.getLogger(PreviewAuditEntry.class);
	private NodeService nodeService;
	private PermissionService permissionService;
	private NamespaceService namespaceService;
	private PersonService personService;
	private AuditComponent auditComponent;
	
	
	
	public PersonService getPersonService() {
		return personService;
	}

	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}

	public AuditComponent getAuditComponent() {
		return auditComponent;
	}

	public void setAuditComponent(AuditComponent auditComponent) {
		this.auditComponent = auditComponent;
	}

	public NodeService getNodeService() {
		return nodeService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public PermissionService getPermissionService() {
		return permissionService;
	}

	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}

	public NamespaceService getNamespaceService() {
		return namespaceService;
	}

	public void setNamespaceService(NamespaceService namespaceService) {
		this.namespaceService = namespaceService;
	}

	public void createPreviewAudit(String node) {
		try {
			Log.info("calling createPreviewAudit::");
			
			NodeRef nodeRef = new NodeRef(node);
			Map<String, Serializable> resultAudit = null;
			resultAudit = getPreviewAuditInfoMap(nodeRef);
			
			 if(resultAudit != null && resultAudit.size() >0) {
             	auditComponent.recordAuditValues("/preview-report/document", resultAudit);
			 }
			
			//accessAuditor.onContentRead(nodeRef);
			//Log.info("executed accessAuditor.onContentRead successfuly");
			
			
			
			
		} catch (Exception e) {
			Log.error("Exception:"+e);
		}
	}
	
	public Map<String, Serializable> getPreviewAuditInfoMap(NodeRef nodeRef) {
		
		Log.info("calling getPreviewAuditInfoMap::");
		String displayPath 			= nodeService.getPath(nodeRef).toDisplayPath(nodeService, permissionService);
		String prefixPath 			= ISO9075.decode(nodeService.getPath(nodeRef).toPrefixString(namespaceService));
		String user = AuthenticationUtil.getFullyAuthenticatedUser();
		NodeRef person = personService.getPerson(user);
		String email = (String)nodeService.getProperty(person, ContentModel.PROP_EMAIL);
		StringBuffer sb = new StringBuffer();
		sb.append((String) nodeService.getProperty(person, ContentModel.PROP_FIRSTNAME)).append(" ").append((String) nodeService.getProperty(person, ContentModel.PROP_LASTNAME));
		String company = (String) nodeService.getProperty(person, ContentModel.PROP_ORGANIZATION);
		if(company == null){
			company = "";
		}
		Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);
		Map<String, Serializable> auditValues = new HashMap<String, Serializable>();
		
		auditValues.put("path", displayPath);
		auditValues.put("noderef", nodeRef);
		auditValues.put("docname", nodeProp.get(ContentModel.PROP_NAME));
        auditValues.put("edcsid", nodeProp.get(CiscoModelConstants.PROP_ALF_ID));
        auditValues.put("security", nodeProp.get(CiscoModelConstants.CISCO_SECURITY_PROP));
        auditValues.put("description", nodeProp.get(ContentModel.PROP_DESCRIPTION));
        auditValues.put("prefixPath", prefixPath);
        auditValues.put("previewedBy", user);
        auditValues.put("first_lastName", sb.toString());
        auditValues.put("company", company);
        auditValues.put("email", email);
        auditValues.put("action", "READ");
        Log.info(" Audit Values ::" + auditValues.toString());
	
		return auditValues;
	}

	public AccessAuditor getAccessAuditor() {
		return accessAuditor;
	}

	public void setAccessAuditor(AccessAuditor accessAuditor) {
		this.accessAuditor = accessAuditor;
	}

}
