package com.cisco.edcsng.audit.logout;

/*
 * This class is designed to record logout audit info for particular user.
 * 
 * @author mkatnam
 */

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.PersonService;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

public class LogoutAuditService extends AbstractWebScript{
	private static final Logger logger = Logger.getLogger(LogoutAuditService.class);
	
	private AuditComponent auditComponent;
	private PersonService personService;
	private NodeService nodeService;
	
	public void setAuditComponent(AuditComponent auditComponent) {
		this.auditComponent = auditComponent;
	}

	public PersonService getPersonService() {
		return personService;
	}


	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}


	public NodeService getNodeService() {
		return nodeService;
	}


	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}


	/* (non-Javadoc)
	 * logout audit info recording.
	 * @see org.springframework.extensions.webscripts.WebScript#execute(org.springframework.extensions.webscripts.WebScriptRequest, org.springframework.extensions.webscripts.WebScriptResponse)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		JSONObject jsonObj = new JSONObject();
		try{
			
			String logginUser = AuthenticationUtil.getFullyAuthenticatedUser().trim();
			if(logginUser!= null && !logginUser.equalsIgnoreCase("admin") && !logginUser.equalsIgnoreCase("ciscoadmin.gen")){
				logger.info(" User for Logout :"+logginUser);
				String company 				= null;
				if(logginUser != null && logginUser.length() > 0){
					 logger.info(" Audit info for Logout is started......"); 
					 NodeRef person =  personService.getPerson(logginUser);
					 company = (String) nodeService.getProperty(person, ContentModel.PROP_ORGANIZATION);
					 if(company == null){
						company = "";
					 }
					 Map<String, Serializable> auditValues = new HashMap<String, Serializable>();
					 auditValues.put("username", logginUser); 
					 auditValues.put("accesstype", "Logout");
					 auditValues.put("company", company);
					 auditComponent.recordAuditValues("/user-access/details", auditValues);
					 logger.info(" Audit for Logout was completed successfully....");
				} 
			}
			jsonObj.put("Message", "Logout audit was completed successfully");
			jsonObj.put("Status", "200");
			
		}catch(WebScriptException e){
			e.printStackTrace();
			 jsonObj.put("Message", e.getMessage());
			 jsonObj.put("Status", "500");
		}
		res.setContentType("application/json;charset=UTF-8");
		res.getWriter().write(jsonObj.toJSONString());
	}

}
