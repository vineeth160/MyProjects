package com.cisco.edcsng.audit;

import java.io.Serializable;
import java.util.Map;

import org.alfresco.repo.audit.extractor.AbstractDataExtractor;
import org.alfresco.repo.workflow.WorkflowModel;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.apache.log4j.Logger;


public class TaskIdWorkflowExtractor extends AbstractDataExtractor
{
    private static final Logger LOGGER = Logger.getLogger(TaskIdWorkflowExtractor.class);
    private NodeService nodeService;

    public boolean isSupported(Serializable data)
    {
        return data instanceof Map;
    }

    public Serializable extractData(Serializable in) throws Throwable
    {
        String instanceId = null;
        try
        {
            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("[TaskIdWorkflowExtractor] - Serializable Data : " + in);
            }

            Map params = (Map) in;
            NodeRef packageRef = (NodeRef) params.get(WorkflowModel.ASSOC_PACKAGE);

            if (LOGGER.isDebugEnabled())
            {
                LOGGER.debug("[TaskIdWorkflowExtractor] - packageRef: " + packageRef);

                LOGGER.debug("[TaskIdWorkflowExtractor] - PROP_WORKFLOW_INSTANCE_ID: "
                        + WorkflowModel.PROP_WORKFLOW_INSTANCE_ID);
            }

            instanceId = (String) nodeService.getProperty(packageRef, WorkflowModel.PROP_WORKFLOW_INSTANCE_ID);
            instanceId = instanceId.substring(instanceId.indexOf("$") + 1);

        }
        catch (InvalidNodeRefException e)
        {
            LOGGER.error(" InvalidNodeRefException::  " + e);
            // e.printStackTrace();
        }

        return instanceId;
    }

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }
}