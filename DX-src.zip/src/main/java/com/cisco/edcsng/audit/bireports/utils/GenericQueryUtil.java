package com.cisco.edcsng.audit.bireports.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

public class GenericQueryUtil
{
    private static final Logger LOGGER = Logger.getLogger(GenericQueryUtil.class);
	
    /**
     * Return List with audit data
     * 
     * @param reportType
     * @param map
     * @return List
     */
    
    public static List<BIReportsAuditMap> reportList(Map<String, Object> auditMap, SqlSession sqlSession,
            String appType)
    {
        LOGGER.info("reportList method invoked:");
        List<BIReportsAuditMap> auditList = null;
        String users = null;
        String dStart = null;
        String dEnd = null;
        String folderPath = null;
        String loginUser = null;
        int limit = 0;
        String folderPath1 = null;
        try
        {
            if (auditMap != null)
            {
                if (auditMap.get("users") != null)
                {
                    users = (String) auditMap.get("users");

                }
                if (auditMap.get("folderPath") != null)
                {
                    folderPath1 = (String) auditMap.get("folderPath");
                    folderPath1 = folderPath1.substring(1);
                    LOGGER.info(" folderPath1  >>>>:: " + folderPath1);
                    
                }
                LOGGER.info("app Type::"+appType);
                if (BIReportsUtil.valueNotNull((String) auditMap.get("folderPath")))
                    folderPath = (String) auditMap.get("folderPath");
                if (BIReportsUtil.valueNotNull((String) auditMap.get("dStart")))
                    dStart = (String) auditMap.get("dStart");
                if (BIReportsUtil.valueNotNull((String) auditMap.get("dEnd")))
                    dEnd = (String) auditMap.get("dEnd");
                if (BIReportsUtil.valueNotNull((String) auditMap.get("loginUser")))
                    loginUser = (String) auditMap.get("loginUser");

                LOGGER.info("BI Report::" + auditMap.toString());
                
                if (BIReportsUtil.valueNotNull(folderPath) && !appType.equalsIgnoreCase("uploadReport") && !appType.equalsIgnoreCase("publishReport") && !appType.equalsIgnoreCase("publishReportIncludeVersions"))
                {
                    folderPath = folderPath + "%";
                    
                }

       			DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
       			Date dateStart = formatter.parse(dStart);
       			Date dateEnd = formatter.parse(dEnd);
        		if (!(auditMap.get("reportType").toString().equalsIgnoreCase("json"))) {
        				if (BIReportsUtil.valueNotNull((String) auditMap.get("limit")))
                            limit = Integer.parseInt((String) auditMap.get("limit"));
                        if (limit <= 0)
                            limit = 65000;
        			}	

    			if(BIReportsUtil.valueNotNull(appType) && appType.equalsIgnoreCase("uploadReport")) {
        			BIReportsAuditMap uploadParams  = new BIReportsAuditMap();
          			uploadParams.setFolderPath(folderPath1);
        			uploadParams.setDate1(dateStart);
        			uploadParams.setDate2(dateEnd);
        			uploadParams.setEntryId(limit);
        			auditList =  sqlSession.selectList("uploadReport", uploadParams);
        			LOGGER.info("audit List:::"+auditList);
                    
    			}
                else if(BIReportsUtil.valueNotNull(appType) && appType.equalsIgnoreCase("userActivityReport")) {
                	BIReportsAuditMap userActivityParams = new BIReportsAuditMap();
                	userActivityParams.setUserId(users);
                	userActivityParams.setFolderPath(folderPath);
                	userActivityParams.setDate1(dateStart);
                	userActivityParams.setDate2(dateEnd);
                	userActivityParams.setEntryId(limit);
                	auditList =  sqlSession.selectList("userActivityReport", userActivityParams);
                }
                else if (BIReportsUtil.valueNotNull(appType) && appType.equalsIgnoreCase("publishReport"))
                {	BIReportsAuditMap publishParams = new BIReportsAuditMap();
                	publishParams.setDate1(dateStart);
                	publishParams.setDate2(dateEnd);
                	publishParams.setUserId(users);
                	publishParams.setFolderPath(folderPath);
                	publishParams.setEntryId(limit);
                	//LOGGER.info("get publish Params:::"+publishParams.getDate1().toString()+">>>"+publishParams.getDate2().toString()+">>>>>"+publishParams.getUserId()+">>>>"+publishParams.getFolderPath().toString()+">>>>"+publishParams.getEntryId());
                    if (Boolean.valueOf((String) auditMap.get("bIncludeVersions")))
                    {
                    	auditList = sqlSession.selectList("publishReportIncludeVersions", publishParams);
                    }
                    else
                    {	
                    	auditList = sqlSession.selectList("publishReport", publishParams);
                    }
                }
                else if (BIReportsUtil.valueNotNull(appType) && appType.equalsIgnoreCase("myDownloadReport"))
                {	BIReportsAuditMap myDownloadParams = new BIReportsAuditMap();
                	myDownloadParams.setFolderPath(folderPath);
                	myDownloadParams.setUserId(loginUser);
                	myDownloadParams.setEntryId(limit);
                	auditList = sqlSession.selectList("myDownloadReport", myDownloadParams);
                }
                else if (BIReportsUtil.valueNotNull(appType) && appType.equalsIgnoreCase("downloadReport"))
                {	BIReportsAuditMap downloadParams = new BIReportsAuditMap();
                	downloadParams.setDate1(dateStart);
                	downloadParams.setDate2(dateEnd);
                	downloadParams.setFolderPath(folderPath);
                	downloadParams.setUserId(users);
                	downloadParams.setEntryId(limit);
                	auditList = sqlSession.selectList("downloadReport", downloadParams);
                }    
              }
        }
        catch (Exception e)
        {
            LOGGER.error("reportList Exception:" + e);
            return null;
        }
        return auditList;
    }


	
}