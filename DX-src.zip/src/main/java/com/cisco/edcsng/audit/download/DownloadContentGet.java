package com.cisco.edcsng.audit.download;

import static javax.servlet.http.HttpServletResponse.SC_FORBIDDEN;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.version.Version2Model;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.audit.AuditQueryParameters;
import org.alfresco.service.cmr.audit.AuditService.AuditQueryCallback;
import org.alfresco.service.cmr.model.FileFolderService;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.repository.TemplateService;
import org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter;
import org.alfresco.service.cmr.repository.datatype.TypeConversionException;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AccessStatus;
import org.alfresco.service.cmr.security.AuthorityService;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.namespace.QName;
import org.alfresco.slingshot.web.scripts.SlingshotContentGet;
import org.alfresco.util.ISO9075;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;
import org.springframework.extensions.webscripts.servlet.WebScriptServletRequest;
import org.springframework.extensions.webscripts.servlet.WebScriptServletResponse;

import com.cisco.alfresco.edcsng.constants.CiscoApplicationContext;
import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.edcsng.constants.EDCSNGConstants;
import com.cisco.alfresco.edcsng.download.DownloadLimitReachedException;
import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.edcsng.util.LDAPUtil;
import com.cisco.alfresco.edcsng.util.MailUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
import com.cisco.alfresco.service.constants.ErrorStatus;
import com.cisco.vera.sdk.connector.VeraDocxConnector;
import com.cisco.vera.utils.VeraProtectionUtil;


public class DownloadContentGet extends SlingshotContentGet
{

    private String alfrescoURL;
    private ServiceRegistry registry;
    private String ldapHost;
    private String ldapPort;
    private String defaultDownloadLimit;
    private String emailtemplatePath;
    private String downloadDocNodeFolder;
    private String mailerFromID;
    private String mailerGroup;
    
    StoreRef storeRef = StoreRef.STORE_REF_WORKSPACE_SPACESSTORE;
    private static final Log logger = LogFactory.getLog(DownloadContentGet.class);

    private PermissionService permissionService;
    private TemplateService templateService;
    private PersonService personService;
    private AuditComponent auditComponent;
    private AuthorityService authorityService;
    HttpServletResponse httpRes;
    private FileFolderService fileFolderService;
    private BehaviourFilter behaviourFilter;
    protected VeraProtectionUtil veraProtectionUtil;
    private String searchUser;
    private Map<String, String> roleMap;

    public Map<String, String> getRoleMap()
    {
        return roleMap;
    }

    public void setRoleMap(Map<String, String> roleMap)
    {
        this.roleMap = roleMap;
    }
    
    
	public FileFolderService getFileFolderService() {
		return fileFolderService;
	}

	public void setFileFolderService(FileFolderService fileFolderService) {
		this.fileFolderService = fileFolderService;
	}

    public AuthorityService getAuthorityService()
    {
        return authorityService;
    }

    public void setAuthorityService(AuthorityService authorityService)
    {
        this.authorityService = authorityService;
    }
    public BehaviourFilter getBehaviourFilter() {
		return behaviourFilter;
	}

	public void setBehaviourFilter(BehaviourFilter behaviourFilter) {
		this.behaviourFilter = behaviourFilter;
	}

	public VeraProtectionUtil getVeraProtectionUtil() {
		return veraProtectionUtil;
	}

	public void setVeraProtectionUtil(VeraProtectionUtil veraProtectionUtil) {
		this.veraProtectionUtil = veraProtectionUtil;
	}
	
	public String getSearchUser() {
		return searchUser;
	}

	public void setSearchUser(String searchUser) {
		this.searchUser = searchUser;
	}
	
    @Override
    public void execute(final WebScriptRequest req, final WebScriptResponse res) throws IOException
    {

        logger.info("--------DownloadLimitedContentGet's execute() starts--------");
        String urlExtension = req.getExtensionPath();

        // String nodeRef = urlExtension.split("/")[3];
        // nodeRef= "workspace://SpacesStore/" + nodeRef;

        // Prepare NodeRef - STARTS - Deepak - on July 23, 2014
        final StringBuffer nodeRefBuffer = new StringBuffer()
                .append(urlExtension.split("/")[1])
                    .append("://")
                    .append(urlExtension.split("/")[2])
                    .append("/")
                    .append(urlExtension.split("/")[3]);
        NodeRef node = new NodeRef(nodeRefBuffer.toString());
        // Prepare NodeRef - ENDS - Deepak - on July 23, 2014

        final String currentUser = AuthenticationUtil.getFullyAuthenticatedUser();

        AuthenticationUtil.getFullAuthentication().setAuthenticated(true);

        // DE 1028 -1 Saranyan - Start

        String previewMode = "false";
        // check for preview mode
        try
        {

            previewMode = req.getParameter("viewmode");
            if (previewMode == null){
                previewMode = "true";
            
            }
                        
            
        }
        catch (Exception ex)
        {
            logger.error("Exception in getting mode: " + ex);
        }

        // DE 1028 -1 Saranyan - End

        /**
         * Check whether user has access to this document/folder.
         */
        if (permissionService.hasPermission(node, "DownloadPermission") == AccessStatus.ALLOWED)
                //|| previewMode.equalsIgnoreCase("true")) // commented for US4567 by dhshaw
        {

            logger.info("Permitted to download document ");
            try
            {

                String downloadedBy = AuthenticationUtil.getRunAsUser();
                /**
                 * Step 1a: Saranyan : Check whether download is allowed
                 */

                try
                {
	                    AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
	                    {
	                        @Override
	                        public Object doWork() throws Exception
	                        {
	                        	
//	                        	res.setHeader("Content-Disposition", "attachment; filename="+ URLEncoder.encode(fileName,"UTF-8").replaceAll("\\+", "%20"));
	                        	res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
	                        	res.setHeader("Pragma", "no-cache");
	                        	res.setHeader("Expires", "0");
	                            String checkUser = null;
	                            String loginUser = ((WebScriptServletRequest) req).getHttpServletRequest().getParameter(
	                                "loggedInUser");
	                            loginUser = currentUser;
	                            checkUser = LDAPUtil.getManagerId(loginUser, ldapHost, ldapPort);
	                            if (checkUser != null && !checkUser.equals(""))
	                            {
	                                doDownLoadCount(req, res, currentUser, nodeRefBuffer.toString());
	                            }
	                            return null;
	                        }
	                    }, "admin");
                	
                }
                catch (DownloadLimitReachedException e)
                {
                    logger.error("DownloadLimitReachedException exception occured... " + e.getMessage());
                    e.printStackTrace();
                    String strErrMessage = e.getMessage();
                    strErrMessage = strErrMessage.substring(strErrMessage.indexOf("You"));
                    res.setHeader("ErrorMSG", strErrMessage);
                    res.setStatus(402);
                    httpRes.sendError(429, strErrMessage);
                    throw new WebScriptException(HttpServletResponse.SC_BAD_REQUEST,
                            "You have exceeded your download limit, please contact your manager to download/preview additional documents.");
                    // return;
                }
                catch (Exception e)
                {
                    logger.error("Exception exception occured... " + e.getMessage());
                    e.printStackTrace();
                    res.setHeader("ErrorMSG", "Unable to download the file, please contact your administrator");
                    httpRes.setStatus(4004, "Unable to download the file, please contact your administrator");
                }

                // Step 1a: Saranyan - end
                /**
                 * Step 1: Download the content
                 */
                
             // commented for US4567 by dhshaw
               // if (previewMode.equalsIgnoreCase("true"))
               // {

               // }
               // else
               // {
                String securityProp = (String) nodeService.getProperty(node, CiscoModelConstants.CISCO_SECURITY_PROP);
                Boolean isDocVeraProtected = (Boolean) nodeService.getProperty(node, ExternalSharingConstants.PROP_IS_DOCUMENT_VERA_PROTECTED);
				if ((securityProp != null && securityProp.equals("Cisco Restricted")) || (isDocVeraProtected != null && isDocVeraProtected)) {

					logger.info("Node to be encrypted***" + node);
					String nodeName = (String) registry.getNodeService().getProperty(node, ContentModel.PROP_NAME);
					
					if (registry.getFileFolderService().getFileInfo(node)
							.isFolder()) {
						res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
						res.getWriter().write("Content not a file.");
						res.getWriter().close();
						return;
					}
					try {
						//US7298:method to apply Vera Encryption on a Restrict type document node
						applyVeraProtection(node, nodeName, res);
					} catch (Exception e) {
						e.printStackTrace();
					}

				}
                else
               {
                    try
                    {
                        super.execute(req, res);
                    }
                    catch (IOException e)
                    {
                        logger.error(" IOException occured... " + e.getMessage());
                        e.printStackTrace();
                    }
               	}

                /**
                 * Step 2: Capture download information
                 */

                Date currentTime = new Date();

                /**
                 * Code commented for temporary purpose. We have to Audit all Cisco Documents - Deepak - on July 23,
                 * 2014
                 */
                // String strSecurityProp = (String) nodeService
                // .getProperty(node, CiscoModelConstants.CISCO_SECURITY_PROP);
                // logger.info("  strSecurityProp " + strSecurityProp);
                // if (strSecurityProp != null && !strSecurityProp.equalsIgnoreCase("Cisco Public"))
                // {
                // getDownloadAuditInfo(nodeRefBuffer.toString(), downloadedBy, currentTime);
                // }
                //added if condition by mkatnam
                if(previewMode.equalsIgnoreCase("true")){
	                // Audit all Cisco Documents - STARTS - Deepak - on July 23, 2014
	                getDownloadAuditInfo(nodeRefBuffer.toString(), downloadedBy, currentTime, currentUser);
	                // Audit all Cisco Documents - ENDS - Deepak - on July 23, 2014
                }
            }
            catch (Exception e)
            {
                logger.error(SC_FORBIDDEN + " exception occured... " + e.getMessage());
            }
        }
        else
        {
            logger.info(" ------------- Access Denied ---------------- ");

            String template = "/alfresco/extension/templates/email/accessdenied.ftl";
            Map<String, Object> model = new HashMap<String, Object>();

            AuthenticationUtil.getFullyAuthenticatedUser();
            Set<AccessPermission> setPermissions = permissionService.getAllSetPermissions(node);

            List<UserRole> userRoles = new ArrayList<UserRole>();

            for (AccessPermission permission : setPermissions)
            {
                if ((permission.getPermission().contains("Admin") || permission.getPermission().contains("Owner"))
                        && (!permission.getPermission().contains("Site")))
                {

                    if (permission.getAuthority().startsWith("GROUP_"))
                    {

                        AuthenticationUtil.setRunAsUser(AuthenticationUtil.getAdminUserName());
                        AuthenticationUtil.setFullyAuthenticatedUser(AuthenticationUtil.getAdminUserName());
                        logger.info("Group = " + permission.getAuthority());
                        Set<String> groupMembers = authorityService.getContainedAuthorities(AuthorityType.USER,
                            permission.getAuthority(), false);
                        for (String member : groupMembers)
                        {

                            logger.info("Member " + member);

                            NodeRef person = personService.getPerson(member);
                            UserRole userRole = new UserRole();
                            String permissionRole = permission.getPermission();
                            if (roleMap.containsKey(permissionRole))
                            {
                                permissionRole = roleMap.get(permissionRole);
                            }
                            userRole.setRole(permissionRole);
                            userRole.setName((String) nodeService.getProperty(person, ContentModel.PROP_FIRSTNAME));
                            userRole.setEmail((String) nodeService.getProperty(person, ContentModel.PROP_EMAIL));
                            userRoles.add(userRole);
                        }

                        AuthenticationUtil.setRunAsUser(currentUser);
                        AuthenticationUtil.setFullyAuthenticatedUser(currentUser);

                    }
                    else
                    {
                        UserRole userRole = new UserRole();
                        String permissionRole = permission.getPermission();
                        if (roleMap.containsKey(permissionRole))
                        {
                            permissionRole = roleMap.get(permissionRole);
                        }
                        userRole.setRole(permissionRole);
                        userRole.setName((String) nodeService.getProperty(
                            personService.getPerson(permission.getAuthority()), ContentModel.PROP_FIRSTNAME));
                        userRole.setEmail((String) nodeService.getProperty(
                            personService.getPerson(permission.getAuthority()), ContentModel.PROP_EMAIL));
                        userRoles.add(userRole);
                    }

                }
            }

            model.put("roles", userRoles);

            String htmlBody = templateService.processTemplate(template, model);

            res.setStatus(HttpStatus.SC_FORBIDDEN);
            res.setContentType("text/html" + ";charset=UTF-8");
            res.getOutputStream().write(htmlBody.getBytes());

        }

    }
    
 //US7298:START:mdanaven-method to apply Vera Encryption on a Restrict type document node
    /**
     * 
     * @param nodeRef
     * @param fileName
     * @param res
     * @throws Exception
     */
    public void applyVeraProtection(NodeRef nodeRef, String fileName, final WebScriptResponse res)	throws Exception {

		// Reading the data content of a NodeRef (binary)
		ContentReader reader = registry.getContentService().getReader(nodeRef, ContentModel.PROP_CONTENT);
		InputStream sourceStream = null;
		InputStream veraSecureStream = null;
		try {
			sourceStream = reader.getContentInputStream();
			String alfId=nodeRef.getId();
            String clientDocId=nodeRef.toString();
            long t1 = System.currentTimeMillis();
            veraSecureStream=VeraDocxConnector.secureStream(sourceStream, fileName, alfId, clientDocId);
            logger.info("Vera Ecnryption time***"+(System.currentTimeMillis() - t1));
            long t2 = System.currentTimeMillis();
			res.setHeader("Content-disposition", "attachment; filename="+ URLEncoder.encode(fileName,"UTF-8").replaceAll("\\+", "%20"));
			res.setContentType("text/html");
			ByteArrayOutputStream memoryOutputStream = null;
			 try {
				 //1 read into memory to make sure sourceStream can be properly consumed
				 memoryOutputStream = new ByteArrayOutputStream();
		        	byte[] buf = new byte[4096];
		        	int bytesRead = 0;
		        	while ((bytesRead = veraSecureStream.read(buf, 0, buf.length)) >= 0){
		        		//2 output source data
		        		memoryOutputStream.write(buf, 0, bytesRead); 
		        	}
		        	memoryOutputStream.writeTo(res.getOutputStream());
		        	
		        	//byte[] sourceBytes = memoryOutputStream.toByteArray();
		        	//3 create inputSecureStream based on source bytes in memory
		        	logger.info("Reading and writing the encrypted content to response time***"+(System.currentTimeMillis() - t2));
		        } finally {
		            if (veraSecureStream != null) 
		            	veraSecureStream.close();
		            
		            if(sourceStream != null){
		            	sourceStream.close();
		            }
		            if(memoryOutputStream != null){
		            	memoryOutputStream.close();
		            }
		            if(res.getOutputStream() != null){
		            	res.getOutputStream().close();
		            }
		        }
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		} 

	}
	
	public static byte[] getBytes(InputStream is) throws IOException {

		int len;
		int size = 1024;
		byte[] buf;

		if (is instanceof ByteArrayInputStream) {
			size = is.available();
			buf = new byte[size];
			len = is.read(buf, 0, size);
		} else {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			buf = new byte[size];
			while ((len = is.read(buf, 0, size)) != -1)
				bos.write(buf, 0, len);
			buf = bos.toByteArray();
		}
		return buf;
	}

    /**
     * Capture download information
     * 
     * @param nodeRefStr
     * @param downloadedBy
     * @return void
     */
    private void getDownloadAuditInfo(String nodeRefStr, String downloadedBy, Date currentTime,String currentUser)
    {
        logger.info("-------- Download Document Auditing STARTS ------------");

        Map<String, Serializable> auditEntry = new HashMap<String, Serializable>();
        auditEntry.put("noderef", nodeRefStr);

        // NodeRef nodeRef = new NodeRef("workspace://SpacesStore/" + nodeRefStr);
        NodeRef nodeRef = new NodeRef(nodeRefStr); // Phani

        Map<QName, Serializable> nodeProp = nodeService.getProperties(nodeRef);

        String nodePath = nodeService.getPath(nodeRef).toDisplayPath(nodeService, permissionService);
        String prefixedPath = ISO9075.decode(nodeService.getPath(nodeRef).toPrefixString(registry.getNamespaceService()));
        /**
         * For Verison Nodes, we have to fetch the FrozenNode (Live Node) and get the display path. - STARTS - Deepak -
         * On July 23, 2014
         */
        if (Version2Model.STORE_ID.equals(nodeRef.getStoreRef().getIdentifier())) // "version2Store"
        {   
            nodeRef = new NodeRef(StoreRef.PROTOCOL_WORKSPACE, Version2Model.STORE_ID, nodeRef.getId());
            NodeRef  frozenNodeRef= (NodeRef) nodeService.getProperty(nodeRef, Version2Model.PROP_QNAME_FROZEN_NODE_REF);
            System.out.println("frozenNodeRef : " + frozenNodeRef);
            nodePath = nodeService.getPath(frozenNodeRef).toDisplayPath(nodeService, permissionService);
            prefixedPath = ISO9075.decode(nodeService.getPath(frozenNodeRef).toPrefixString(registry.getNamespaceService()));
            System.out.println("nodePath : " + nodePath);
        }
        
        /**
         * For Verison Nodes, we have to fetch the FrozenNode (Live Node) and get the display path. - STARTS - Deepak -
         * On July 23, 2014
         */

        auditEntry.put("docname", (String) nodeProp.get(ContentModel.PROP_NAME));
        auditEntry.put("creator", (String) nodeProp.get(ContentModel.PROP_CREATOR));
        auditEntry.put("modifier", currentUser);
        auditEntry.put("path", nodePath);
        auditEntry.put("prefixedPath", prefixedPath);
        auditEntry.put("description", (String) nodeProp.get(ContentModel.PROP_DESCRIPTION));
        auditEntry.put("security", (String) nodeProp.get(CiscoModelConstants.CISCO_SECURITY_PROP));

       // QName edcsIdQName = QName.createQName(CiscoModelConstants.CISCO_MODEL_URI, "alf_id");
        auditEntry.put("edcsid", (String) nodeProp.get(CiscoModelConstants.PROP_ALF_ID));
        
        //added by mkatnam for download Audit Report and setting download count property
        int downloadCount = 1;
	    auditEntry.put("contentsize",formatFileSize(fileFolderService.getReader(nodeRef).getContentData().getSize()));
	     
	        if(nodeProp.get(CiscoModelConstants.PROP_CISCO_DOWNLOAD_COUNT) != null){
		        downloadCount = (Integer) nodeProp.get(CiscoModelConstants.PROP_CISCO_DOWNLOAD_COUNT);
	        }
	        logger.info("downloadCount: "+downloadCount );    
	        auditEntry.put("downloadcount", String.valueOf(downloadCount));	
	        
        //end mkatnam
        auditComponent.recordAuditValues("/download-report/document", auditEntry);

        logger.info(" AuditEntry :" + auditEntry);
        logger.info("---------- Download Document Auditing ENDS -----------");

    }

    /**
     * @param templateService
     *            the templateService to set
     */
    public void setTemplateService(TemplateService templateService)
    {
        this.templateService = templateService;
    }

    /**
     * @param personService
     *            the personService to set
     */
    public void setPersonService(PersonService personService)
    {
        this.personService = personService;
    }

    /**
     * @param permissionService
     *            the permissionService to set
     */
    public void setPermissionService(PermissionService permissionService)
    {
        this.permissionService = permissionService;
    }

    /**
     * @param auditComponent
     *            the auditComponent to set
     */
    public void setAuditComponent(AuditComponent auditComponent)
    {
        this.auditComponent = auditComponent;
    }

    /**
     * Do the download count for loggedin user sending the email notification on exceding the limit for the day
     * 
     * @param req
     * @param res
     * @return void
     */
    private void doDownLoadCount(WebScriptRequest req, WebScriptResponse res, String currentUser, String nodeRef)
            throws DownloadLimitReachedException, Exception
    {

        int intConfiguredLimit = 0;
        int intDefaultLimit = Integer.parseInt(defaultDownloadLimit);
        String nodePath = nodeRef;
        NodeRef userDownloadObjNoderef = null;
        NodeRef currentNodeRef = new NodeRef(nodePath);
        String strSecurityProp = (String) this.registry.getNodeService().getProperty(currentNodeRef,
            CiscoModelConstants.CISCO_SECURITY_PROP);
        Date currDate = new Date();
        DateFormat dateformatter = new SimpleDateFormat("yyyy-MM-dd");
        DateFormat dateTimeformatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

        String toDay = "";
        Date fromTime = new Date();
        Date toTime = new Date();
        try
        {
            toDay = dateformatter.format(currDate);
            fromTime = dateTimeformatter.parse(toDay + "T00:00:00");
            toTime = dateTimeformatter.parse(toDay + "T23:59:59");

        }
        catch (java.text.ParseException e)
        {
            logger.error("Exception ocured while formatting the date ..." + e.getMessage());
        }
        if (!(req instanceof WebScriptServletRequest))
        {
            throw new WebScriptException("Content retrieval must be executed in HTTP Servlet environment");
        }
        httpRes = ((WebScriptServletResponse) res).getHttpServletResponse();
        String loggedInUser = currentUser;
        int intDownloadCount = getAuditQuery(req, loggedInUser, fromTime.getTime(), toTime.getTime());
        // added for error message
        String downloadDocQuery = "TYPE:\"cs\\:downloaddoc\" AND @cm\\:name:\"" + loggedInUser + "\" ";
        userDownloadObjNoderef = EDCSUtil.doSearch(downloadDocQuery, registry);
        if (strSecurityProp != null && !strSecurityProp.equalsIgnoreCase("Cisco Public"))
        {
            if (userDownloadObjNoderef != null)
            {
                Date objToday = new Date();
                intConfiguredLimit = (Integer) registry.getNodeService().getProperty(userDownloadObjNoderef,
                    EDCSNGConstants.PROP_QNAME_DOWNLOAD_LIMIT);
                Date objDownloadExpireDate = (Date) registry.getNodeService().getProperty(userDownloadObjNoderef,
                    EDCSNGConstants.PROP_QNAME_DOWNLOAD_LIMIT_EXP_DATE);
                if (objDownloadExpireDate.compareTo(objToday) < 0)
                {
                    if (intDownloadCount >= intDefaultLimit)
                    {
                        try
                        {

                            UserTransaction trx = registry.getTransactionService().getNonPropagatingUserTransaction(
                                false);
                            trx.begin();
                            nodeService.setProperty(userDownloadObjNoderef,
                                EDCSNGConstants.PROP_QNAME_DOWNLOAD_LIMIT_EXCEED_DATE, objToday);
                            registry.getNodeService().setProperty(userDownloadObjNoderef,
                                EDCSNGConstants.PROP_QNAME_DOWNLOAD_LIMIT_EXCEED_DATE, objToday);
                            trx.commit();
                        }
                        catch (Exception exec)
                        {
                            logger.error(" #######################13" + exec);
                        }
                        sendMail(intDefaultLimit, loggedInUser, userDownloadObjNoderef);
                        throw new DownloadLimitReachedException(
                                "You have exceeded your download limit, please contact your manager to download additional documents.");
                    }
                }
                else if (intDownloadCount >= intConfiguredLimit)
                {
                    try
                    {
                        UserTransaction trx = registry.getTransactionService().getNonPropagatingUserTransaction(false);
                        trx.begin();
                        nodeService.setProperty(userDownloadObjNoderef,
                            EDCSNGConstants.PROP_QNAME_DOWNLOAD_LIMIT_EXCEED_DATE, objToday);
                        registry.getNodeService().setProperty(userDownloadObjNoderef,
                            EDCSNGConstants.PROP_QNAME_DOWNLOAD_LIMIT_EXCEED_DATE, objToday);
                        trx.commit();
                    }
                    catch (Exception exec)
                    {
                        logger.error(" #######################13" + exec);
                    }
                    sendMail(intConfiguredLimit, loggedInUser, userDownloadObjNoderef);
                    throw new DownloadLimitReachedException(
                            "You have exceeded your download limit, please contact your manager to download additional documents.");
                }
            }
            else if (intDownloadCount >= intDefaultLimit)
            {
                sendMail(intDefaultLimit, loggedInUser, userDownloadObjNoderef);
                throw new DownloadLimitReachedException(
                        "You have exceeded your download limit, please contact your manager to download additional documents.");
            }
        }

    }

    /**
     * sending the email notification on exceeding the limit for the day
     * 
     * @param intUserDownloadLimit
     * @param strLoggedInUser
     * @return boolean
     */
    private boolean sendMail(int intUserDownloadLimit, String strLoggedInUser, NodeRef userDownloadObjNoderef) throws Exception
    {
        String strManagerID = null;
        if (CiscoApplicationContext.getEnvironment() != null)
        {
            String environment = CiscoApplicationContext.getEnvironment();
            if (environment.equalsIgnoreCase("prod"))
            {
                strManagerID = LDAPUtil.getManagerId(strLoggedInUser, ldapHost, ldapPort);
            }
            else
            {
                strManagerID = mailerGroup;
            }
        }
        else
        {
            strManagerID = LDAPUtil.getManagerId(strLoggedInUser, ldapHost, ldapPort);
        }
        logger.info("strManagerID :---------->" + strManagerID);
        String strSubject = "Reached maximum download count per day";
        Map<String, Serializable> objModel = new HashMap<String, Serializable>();
        String strEditURL = "";
        if (userDownloadObjNoderef != null)
        {
            strEditURL = alfrescoURL + "/share/page/edit-metadata?nodeRef=" + userDownloadObjNoderef.toString();
            objModel.put("editorcreate", "edit");
        }
        else
        {
            logger.info("downloadDocNodeFolder -->" + downloadDocNodeFolder);
            NodeRef objDownloadDocFolder = EDCSUtil.doSearch("PATH:\"" + downloadDocNodeFolder + "\"", registry);
            strEditURL = alfrescoURL + "/share/page/create-content?destination=" + objDownloadDocFolder.toString()
                    + "&itemId=cs:downloaddoc";
            objModel.put("editorcreate", "create");
        }
        logger.info("strEditURL :---------->" + strEditURL);
        objModel.put("editurl", strEditURL);
        objModel.put("userdownloadlimit", intUserDownloadLimit + "");
        objModel.put("loggedinuser", strLoggedInUser);
        String strTemplatePathQuery = "PATH:\"" + emailtemplatePath + "\"";
        logger.info("strTemplatePathQuery :---------->" + strTemplatePathQuery);
        NodeRef objTemplateNodeRef = EDCSUtil.doSearch(strTemplatePathQuery, registry);
        logger.info("objTemplateNodeRef :---------->" + objTemplateNodeRef);
        MailUtil
                .sendMail(mailerFromID, strManagerID + "@cisco.com", strSubject, objModel, registry, objTemplateNodeRef);
        return true;
    }

    /**
     * getting the download count for the logedin user
     * 
     * @param req
     * @param user
     * @paramf romTime
     * @param toTime
     * @return int
     */
    public int getAuditQuery(WebScriptRequest req, String user, long fromTime, long toTime)
    {

        int limit = 0;
        final boolean verbose = true;
        // Execute the query
        int intDownloadcount = 0;
        final String JSON_KEY_ENTRY_ID = "id";
        final String JSON_KEY_ENTRY_APPLICATION = "application";
        final String JSON_KEY_ENTRY_USER = "user";
        final String JSON_KEY_ENTRY_TIME = "time";
        final String JSON_KEY_ENTRY_VALUES = "values";
        try
        {
            AuditQueryParameters params = new AuditQueryParameters();
            params.setApplicationName("download-report");
            params.setFromTime(fromTime);
            params.setToTime(toTime);
            params.setUser(user);
            final List<Map<String, Object>> entries = new ArrayList<Map<String, Object>>(limit);
            AuditQueryCallback callback = new AuditQueryCallback()
            {
                @Override
                public boolean valuesRequired()
                {
                    return verbose;
                }

                @Override
                public boolean handleAuditEntryError(Long entryId, String errorMsg, Throwable error)
                {
                    return true;
                }

                @Override
                public boolean handleAuditEntry(Long entryId, String applicationName, String user, long time,
                        Map<String, Serializable> values)
                {
                    Map<String, Object> entry = new HashMap<String, Object>(11);
                    entry.put(JSON_KEY_ENTRY_ID, entryId);
                    entry.put(JSON_KEY_ENTRY_APPLICATION, applicationName);
                    if (user != null)
                    {
                        entry.put(JSON_KEY_ENTRY_USER, user);
                    }
                    entry.put(JSON_KEY_ENTRY_TIME, new Date(time));
                    if (values != null)
                    {
                        // Convert values to Strings
                        Map<String, String> valueStrings = new HashMap<String, String>(values.size() * 2);
                        for (Map.Entry<String, Serializable> mapEntry : values.entrySet())
                        {
                            String key = mapEntry.getKey();
                            Serializable value = mapEntry.getValue();
                            try
                            {
                                String valueString = DefaultTypeConverter.INSTANCE.convert(String.class, value);
                                valueStrings.put(key, valueString);
                            }
                            catch (TypeConversionException e)
                            {
                                // Use the toString()
                                valueStrings.put(key, value.toString());
                            }

                        }
                        entry.put(JSON_KEY_ENTRY_VALUES, valueStrings);
                    }
                    entries.add(entry);

                    return true;
                }
            };

            registry.getAuditService().auditQuery(callback, params, limit);
            intDownloadcount = entries.size();
        }
        catch (Exception e)
        {
            logger.error("Exception:::" + e);
            e.printStackTrace();
        }
        return intDownloadcount;
    }
    
    public static String formatFileSize(long size) {
	    String hrSize = null;

	    double b = size;
	    double k = size/1024.0;
	    double m = ((size/1024.0)/1024.0);
	    double g = (((size/1024.0)/1024.0)/1024.0);
	    double t = ((((size/1024.0)/1024.0)/1024.0)/1024.0);

	    DecimalFormat dec = new DecimalFormat("0.00");

	    if ( t>1 ) {
	        hrSize = dec.format(t).concat(" TB");
	    } else if ( g>1 ) {
	        hrSize = dec.format(g).concat(" GB");
	    } else if ( m>1 ) {
	        hrSize = dec.format(m).concat(" MB");
	    } else if ( k>1 ) {
	        hrSize = dec.format(k).concat(" KB");
	    } else {
	        hrSize = dec.format(b).concat(" Bytes");
	    }
	    return hrSize;
	}

    public void setServiceRegistry(ServiceRegistry registry)
    {
        this.registry = registry;
    }

    public String getLdapPort()
    {
        return ldapPort;
    }

    public void setLdapPort(String ldapPort)
    {
        this.ldapPort = ldapPort;
    }

    public String getDefaultDownloadLimit()
    {
        return defaultDownloadLimit;
    }

    public void setDefaultDownloadLimit(String defaultDownloadLimit)
    {
        this.defaultDownloadLimit = defaultDownloadLimit;
    }

    public String getEmailtemplatePath()
    {
        return emailtemplatePath;
    }

    public void setEmailtemplatePath(String emailtemplatePath)
    {
        this.emailtemplatePath = emailtemplatePath;
    }

    public String getDownloadDocNodeFolder()
    {
        return downloadDocNodeFolder;
    }

    public void setDownloadDocNodeFolder(String downloadDocNodeFolder)
    {
        this.downloadDocNodeFolder = downloadDocNodeFolder;
    }

    public String getMailerFromID()
    {
        return mailerFromID;
    }

    public void setMailerFromID(String mailerFromID)
    {
        this.mailerFromID = mailerFromID;
    }

    public String getLdapHost()
    {
        return ldapHost;
    }

    public void setLdapHost(String ldapHost)
    {
        this.ldapHost = ldapHost;
    }

    public String getMailerGroup()
    {
        return mailerGroup;
    }

    public void setMailerGroup(String mailerGroup)
    {
        this.mailerGroup = mailerGroup;
    }

    /**
     * @param alfrescoURL
     *            the alfrescoURL to set
     */
    public void setAlfrescoURL(String alfrescoURL)
    {
        this.alfrescoURL = alfrescoURL;
    }

}