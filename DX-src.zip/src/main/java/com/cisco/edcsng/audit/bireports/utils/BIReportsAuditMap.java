package com.cisco.edcsng.audit.bireports.utils;

import java.util.Date;

/**
 * @author vpotnuru
 *
 */

public class BIReportsAuditMap implements java.io.Serializable{
	private int entryId;
	private String edcsId;
	private String securityClassification;
	private Date auditTime;
	private String action;
	private String userId;
	private String fileName;
	private String description;
	private String folderPath;
	private String noderef;
	private String companyName;
	private String emailAddress;
	private String string1;
	private String string2;
	private Date date1;
	private Date date2;
	private String propKeyValue;
	
	
	public BIReportsAuditMap(){}
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFolderPath() {
		return folderPath;
	}
	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}
	public String getNoderef() {
		return noderef;
	}
	public void setNoderef(String noderef) {
		this.noderef = noderef;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getString1() {
		return string1;
	}
	public void setString1(String string1) {
		this.string1 = string1;
	}
	public String getString2() {
		return string2;
	}
	public void setString2(String string2) {
		this.string2 = string2;
	}
	public Date getDate1() {
		return date1;
	}
	public void setDate1(Date date1) {
		this.date1 = date1;
	}
	public Date getDate2() {
		return date2;
	}
	public void setDate2(Date date2) {
		this.date2 = date2;
	}
	public String getPropKeyValue() {
		return propKeyValue;
	}
	public void setPropKeyValue(String propKeyValue) {
		this.propKeyValue = propKeyValue;
	}
	public int getEntryId() {
		return entryId;
	}
	public void setEntryId(int entryId) {
		this.entryId = entryId;
	}
	public String getEdcsId() {
		return edcsId;
	}
	
	public String getSecurityClassification() {
		return securityClassification;
	}

	public void setSecurityClassification(String securityClassification) {
		this.securityClassification = securityClassification;
	}

	public void setEdcsId(String edcsId) {
		this.edcsId = edcsId;
	}
	
	public Date getAuditTime() {
		return auditTime;
	}
	public void setAuditTime(Date auditTime) {
		this.auditTime = auditTime;
	}
	
	
	
}
