package com.cisco.edcsng.audit.bireports.utils;

import java.text.DecimalFormat;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import jxl.CellView;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class BIReportsUtil {
	
	private WritableCellFormat times;
    private WritableCellFormat timesBoldUnderline;
    WritableCellFormat timesHeading;
    
    WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);
    
	
	/** creating label
	 * @param sheet
	 * @param label
	 * @param col
	 * @throws WriteException
	 */
	public void createLabel(WritableSheet sheet, String label, int col) throws WriteException
    {

        WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
        times = new WritableCellFormat(times10pt);
        times.setWrap(false);

        // Create create a bold font
       
        timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
        timesBoldUnderline.setWrap(false);

        CellView cv = new CellView();
        cv.setFormat(times);
        cv.setFormat(timesBoldUnderline);
        // Write a few headers
        addCaption(sheet, col, 1, label);
    }

    /** adding caption
     * @param sheet
     * @param column
     * @param row
     * @param s
     * @throws RowsExceededException
     * @throws WriteException
     */
    public void addCaption(WritableSheet sheet, int column, int row, String s) throws RowsExceededException,
            WriteException
    {
        Label label;
        label = new Label(column, row, s, timesBoldUnderline);
        sheet.addCell(label);
    }

    /** adding label
     * @param sheet
     * @param column
     * @param row
     * @param s
     * @throws WriteException
     * @throws RowsExceededException
     */
    public void addLabel(WritableSheet sheet, int column, int row, String s) throws WriteException,
            RowsExceededException
    {
        Label label;
        label = new Label(column, row, s, times);
        sheet.addCell(label);
    }
    
    /** adding heading
     * @param sheet
     * @param column
     * @param row
     * @param s
     * @throws WriteException
     * @throws RowsExceededException
     */
    public void addHeading(WritableSheet sheet, int column, int row, String s) throws WriteException,
            RowsExceededException
    {
    	 timesHeading = new WritableCellFormat(times10ptBoldUnderline);
         // do not automatically wrap the cells
         timesHeading.setWrap(true);
    	
        Label label;
        label = new Label(column, row, s, timesHeading);
        sheet.addCell(label);
    }
    
    public void createHeading(WritableSheet wSheet, String reportHeading) throws WriteException {
		WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);
		timesHeading = new WritableCellFormat(times10ptBoldUnderline);
          // do not automatically wrap the cells
         timesHeading.setWrap(true);
		 wSheet.setColumnView(0, 20);
         wSheet.setColumnView(1, 20);
         wSheet.setRowView(0, 800);
         addHeading(wSheet, 0, 0, reportHeading);
         wSheet.mergeCells(0, 0, 13, 0);
		
	}
    
    /** Size conversion
	 * @param size
	 * @return
	 */
	public String formatFileSize(long size) {
		    String hrSize = null;

		    double b = size;
		    double k = size/1024.0;
		    double m = ((size/1024.0)/1024.0);
		    double g = (((size/1024.0)/1024.0)/1024.0);
		    double t = ((((size/1024.0)/1024.0)/1024.0)/1024.0);

		    DecimalFormat dec = new DecimalFormat("0.00");

		    if ( t>1 ) {
		        hrSize = dec.format(t).concat(" TB");
		    } else if ( g>1 ) {
		        hrSize = dec.format(g).concat(" GB");
		    } else if ( m>1 ) {
		        hrSize = dec.format(m).concat(" MB");
		    } else if ( k>1 ) {
		        hrSize = dec.format(k).concat(" KB");
		    } else {
		        hrSize = dec.format(b).concat(" Bytes");
		    }
		    return hrSize;
		}
	
	/**
	 * Separating key and values for Reports
	 * @param prop_values
	 * @return
	 */
	public static Map<String,Object> getPropValues(String prop_values){
		
		if(prop_values != null && prop_values.length() > 0 ){
			Map<String,Object> propMap 	= new HashMap<String, Object>();
			String[] propArray 			= prop_values.split(",");
			
			for(String property:propArray){
				String[] keyArray = property.split("=");
				if(keyArray.length > 1)
				propMap.put(keyArray[0].trim(), keyArray[1].trim());
			}
			return propMap;
		}else{
			return null;
		}
	}
	
	 /**
	  * checks the given value is null 
	 * @param value
	 * @return
	 */
	public static boolean valueNotNull(String value){
		 if(value != null && value.trim().length() > 0 && value !=""){
			 return true;
		 }else{
			 return false;
		 }
	 }
	
	/*Comparator for sorting the list by Published date*/
    public static Comparator<BIReportsAuditMap> auditDateComparator = new Comparator<BIReportsAuditMap>() {
	public int compare(BIReportsAuditMap biMap1, BIReportsAuditMap biMap2) {
		int result = 0;
		   try {
				result =  (biMap2.getAuditTime()).compareTo(biMap1.getAuditTime());
			} catch (Exception e) {
				e.printStackTrace();
			}
			return result;
    }
	};

}
