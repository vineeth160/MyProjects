/**
 * Class is used to get uploaded files(new versions too) in folders where the internal user is having folder admin role 
 * 
 * @author vpotnuru
 *
 */


package com.cisco.edcsng.audit.bireports.publish;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import jxl.Workbook;
import jxl.write.DateFormat;
import jxl.write.WritableCell;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WritableHyperlink;
import jxl.format.Colour;
import jxl.write.Label;

import org.alfresco.model.ContentModel;
import org.alfresco.query.PagingRequest;
import org.alfresco.query.PagingResults;
import org.alfresco.repo.forum.CommentService;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.preference.PreferenceService;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.cmr.version.VersionService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.edcsng.audit.bireports.utils.BIReportsAuditMap;
import com.cisco.edcsng.audit.bireports.utils.BIReportConstants;
import com.cisco.edcsng.audit.bireports.utils.BIReportsUtil;
import com.cisco.edcsng.audit.bireports.utils.GenericQueryUtil;

public class UploadReport extends AbstractWebScript implements BIReportConstants{

	private Logger log = Logger.getLogger(UploadReport.class);
	BIReportsUtil biReportsUtil 		= null;
	private static final String PREFIX_PATH = "/app:company_home/st:sites/cm:edcsng/cm:documentLibrary";
	private WritableCellFormat times;
	private WritableCellFormat timesBoldUnderline;
	private WritableCellFormat timesHeading;
	
	private ServiceRegistry serviceRegistry;
	private NodeService nodeService;
	private PermissionService permissionService;
	private PreferenceService preferenceService;
	private NamespaceService namespaceService;
	private Properties globalProperties;
	private SessionFactory localFactory;
	private CommentService commentService;
	private ContentService contentService;
	private VersionService versionService;
	private String folderURL;
	
	
	public VersionService getVersionService() {
		return versionService;
	}


	public void setVersionService(VersionService versionService) {
		this.versionService = versionService;
	}


	public ContentService getContentService() {
		return contentService;
	}


	public void setContentService(ContentService contentService) {
		this.contentService = contentService;
	}


	public CommentService getCommentService() {
		return commentService;
	}


	public void setCommentService(CommentService commentService) {
		this.commentService = commentService;
	}


	public String getFolderURL() {
		return folderURL;
	}


	public void setFolderURL(String folderURL) {
		this.folderURL = folderURL;
	}


	public SessionFactory getLocalFactory() {
		return localFactory;
	}


	public void setLocalFactory(SessionFactory localFactory) {
		this.localFactory = localFactory;
	}


	public Properties getGlobalProperties() {
		return globalProperties;
	}


	public void setGlobalProperties(Properties globalProperties) {
		this.globalProperties = globalProperties;
	}


	public NamespaceService getNamespaceService() {
		return namespaceService;
	}


	public void setNamespaceService(NamespaceService namespaceService) {
		this.namespaceService = namespaceService;
	}


	public PreferenceService getPreferenceService() {
		return preferenceService;
	}


	public void setPreferenceService(PreferenceService preferenceService) {
		this.preferenceService = preferenceService;
	}


	public NodeService getNodeService() {
		return nodeService;
	}


	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}


	public PermissionService getPermissionService() {
		return permissionService;
	}


	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}


	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}


	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	private static final String DATE_FORMAT="yyyy-MM-dd";
	@Override
	 public void execute(WebScriptRequest req, WebScriptResponse res) {
		
		log.info("PermissionReport excute method:");
		
		String dStart				= null;
		String dEnd					= null;
		//String nodeName 			= null;
		NodeRef processNode 		= null;
		String displayPath			= null;
		String folderNodeRef		= null;
		boolean isFolderEmpty 		= false;
		String prefixPath			= null;
        boolean hasFolderPermission = false;
        String queryLimit 			= null;
        String format				= null;
        Set<NodeRef> finalList		= null;
        Map<String, Object> auditMap= new HashMap<String, Object>();
        List<BIReportsAuditMap> queryResultList		= new ArrayList<BIReportsAuditMap>();
        List<BIReportsAuditMap> auditMapObjList		= null;
		try {
			biReportsUtil 		= new BIReportsUtil();
			Content c 		= req.getContent();
			if (c == null) {
				throw new WebScriptException(Status.STATUS_BAD_REQUEST,"Missing POST body.");
			}
			JSONObject json;
			json = new JSONObject(c.getContent());
			dStart 				= json.getString("dateStart");
			dEnd 				= json.getString("dateEnd");
			
			log.info("dstart:"+dStart+", dEnd:"+dEnd);
			
			log.info("nodeId is there or not"+json.has("nodeId"));
			if(json.has("nodeId")) {
				log.info("folderId:"+json.getString("nodeId"));
			}
			
			if(json.has("nodeId") && BIReportsUtil.valueNotNull(json.getString("nodeId"))) {
				folderNodeRef 		= json.getString("nodeId");
				processNode = new NodeRef(folderNodeRef);
			}
			
			if(json.has("format") && BIReportsUtil.valueNotNull(json.getString("format"))){
	        	 format = json.getString("format");
	         }
			String currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
			log.info("currentUser:"+currentUser);
			
			 if (processNode != null) {
				 String name = (String)nodeService.getProperty(processNode, ContentModel.PROP_NAME);
				 prefixPath 			= nodeService.getPath(processNode).toPrefixString(namespaceService);
				 displayPath			= nodeService.getPath(processNode).toDisplayPath(nodeService, permissionService)+"/"+name;
				 log.info("prefixPath:"+prefixPath);
				 log.info("displayPath:"+displayPath);
			 } 
			 queryLimit = globalProperties.getProperty("audit.results.limit");
			 
			 long startTime = System.currentTimeMillis();
	         log.info("StartTime   : "+new Date(startTime));
	         if (processNode != null) {
	        	 finalList = getFolderList("PATH:\""+prefixPath+"//*\" AND TYPE:\"cm:folder\"",hasFolderPermission, processNode, isFolderEmpty); 
	         }else {
	        	 finalList = getFolderList("PATH:\""+PREFIX_PATH+"//*\" AND TYPE:\"cm:folder\"",hasFolderPermission, processNode, isFolderEmpty);
	         }
			 long luceneTime = System.currentTimeMillis();
	         log.info("luceneTime   : "+new Date(luceneTime));
			if (finalList != null) {
				log.info("Result JSON Size: " + finalList.size());
				List<String> folderDisplayPathList = new ArrayList<String>();
				if (processNode != null) {
				for (NodeRef nodeRef : finalList) {
						if (nodeRef != null) {
							String nodeName = (String)nodeService.getProperty(nodeRef, ContentModel.PROP_NAME);
							String folderDisplayPath = nodeService.getPath(nodeRef).toDisplayPath(nodeService, permissionService)+"/"+nodeName;
							if (folderDisplayPath.contains(displayPath)) {
							folderDisplayPathList.add(folderDisplayPath);
							}else {
								continue;
							}
							}
						log.info("folderDisplayPathList  :: " +folderDisplayPathList.size());
					}
				} else {
					for (NodeRef nodeRef : finalList) {
							if (nodeRef != null) {
							String nodeName = (String)nodeService.getProperty(nodeRef, ContentModel.PROP_NAME);
							String folderDisplayPath = nodeService.getPath(nodeRef).toDisplayPath(nodeService, permissionService)+"/"+nodeName;
							folderDisplayPathList.add(folderDisplayPath);
						}
							}
						log.info("folderDisplayPathList  :: " +folderDisplayPathList.size());
				}
				if(folderDisplayPathList.size()>0 && !folderDisplayPathList.isEmpty()){
				List<List<String>> childList = splitListToSubList(folderDisplayPathList,15);
				log.info("childlist size  ::: " +childList.size());
				if(!childList.isEmpty() && childList.size()>0){
					for(int i=0;i<=childList.size()-1;i++){
						List<String> list1= childList.get(i);
						StringBuilder rString = new StringBuilder();
					   for(String li : list1){
							rString.append(",").append(li);
						}
					   //log.info("rstring  :: " +rString);
						auditMap.put("folderPath",rString.toString());
						auditMap.put("dStart",dStart);
						auditMap.put("dEnd",dEnd);
						auditMap.put("reportType",format);
						auditMap.put("limit",queryLimit);
						//log.info("before calling reportlist .....");
						auditMapObjList = GenericQueryUtil.reportList(auditMap, localFactory, "uploadReport");
						//log.info("after calling reportlist .....");
						if (auditMapObjList != null)
							queryResultList.addAll(auditMapObjList);
					}
				}
				}
			}
			 long endTime = System.currentTimeMillis();
	         log.info("endTime   : "+new Date(endTime));
			 log.info("queryResultList:"+queryResultList.size());
			 Collections.sort(queryResultList, BIReportsUtil.auditDateComparator); 
			 
			 getUploadReport(queryResultList,res, dStart, dEnd);
		} catch(Exception e) {
			log.error("Exception in PermissionReport class:"+e);
			e.printStackTrace();
		}

	}
	
	 public Set<NodeRef> getFolderList(String searchQuery, boolean hasFolderPermission, NodeRef processNode, boolean isFolderEmpty)
	    {
		 log.info("Inside getFolderList:");
		 Set<NodeRef> finalSet = (Set<NodeRef>) new HashSet<NodeRef>();
		 Set<NodeRef> resultSet = (Set<NodeRef>) new HashSet<NodeRef>();
		 Set<NodeRef> luceneList = (Set<NodeRef>) new HashSet<NodeRef>();
		 Set<NodeRef> favList = (Set<NodeRef>) new HashSet<NodeRef>();
		 
		 try {
			 log.info("search query:"+searchQuery);
			 List<NodeRef> nodeRefList = EDCSUtil.getNodeRefList(searchQuery, serviceRegistry);
			
			 if (nodeRefList != null) {
				 luceneList = new HashSet<NodeRef>(nodeRefList);
			 }
			 
			 if (luceneList != null) {
				 log.info("lucene set size:"+luceneList.size());
				 finalSet.addAll(luceneList);
			 }
			 
			 
			 List<NodeRef> favouritesList = getFavouriteFolderList(isFolderEmpty);
			 if (favouritesList != null) {
				 favList =  new HashSet<NodeRef>(favouritesList);
			 }
			 
			 if (favList != null) {
				 log.info("favList set size:"+favList.size());
				 finalSet.addAll(favList);
			 }
	         
	         if (processNode != null) {
	        	 finalSet.add(processNode);
	         }
	        
	         String currentUser = AuthenticationUtil.getFullyAuthenticatedUser();
             log.info("current user : " + currentUser);
	         if (finalSet != null && finalSet.size() > 0)
	            {
	        	 log.info("finalSet set size:"+finalSet.size());
	                for (NodeRef nodeRef : finalSet)
	                {
	                	try {
	                		boolean hasAccess = (String.valueOf(serviceRegistry.getPermissionService().hasPermission(nodeRef,
	    	                        PermissionService.READ)).equals("ALLOWED"));
	    	                    if(!hasAccess)
	                                continue;
	    	                    if(serviceRegistry.getFileFolderService().list(nodeRef).isEmpty())
	    	                    	isFolderEmpty=true;
	    	                    else
	    	                    	isFolderEmpty=false;
	    	                    
	    	                    boolean hasPermission = hasAdminAccess(nodeRef, currentUser, serviceRegistry);
	    	                    if (hasPermission)
	    	                    {
	    	                    	resultSet.add(nodeRef);
	    	                    }
	    	                    
	                	}catch(Exception e) {
	                		e.printStackTrace();
	                	}
	                }
	            } else {
	            	log.info("finalSet resulting zero result:");
	            }
	         
		 }catch(Exception e) {
			 e.printStackTrace();
			 return null;
		 }
			return resultSet;
		 
	    }
	 
	 /**
	     * To check the user have "ADMIN" permission on the node
	     * 
	     * @param currentUser
	     * @param nodeRef
	     * @param serviceRegistry
	     * @return
	     */
	    public boolean hasAdminAccess(NodeRef nodeRef, String currentUser, ServiceRegistry serviceRegistry)
	    {
	        Set<AccessPermission> userSet = serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef);
	        log.debug("UserSet size:" + userSet.size());
	        if (userSet.size() > 0)
	        {
	            for (AccessPermission accessPermission : userSet)
	            {
	            	
	            	if (accessPermission.getAuthorityType() == AuthorityType.USER)
	            	{
	            		String authorityUser = accessPermission.getAuthority();
	            		String permission = accessPermission.getPermission();
		            	log.debug("authorityUser : " + authorityUser);
	            		log.debug("accessPermission.getPermission : " + permission);
	            		if (authorityUser.equals(currentUser) && permission.equals("AdminRole"))
	            		{
	            			return true;
	            		}
	            	}
	            }
	        }

	        return false;
	    }
	    
	    public List<NodeRef> getFavouriteFolderList(final boolean isFolderEmpty){
	    	
	    	final List<NodeRef> favList = new ArrayList<NodeRef>();
	    	
	    	log.info("Inside getFavouriteFolderList method:");
	    	try {
	    		String preferenceFilter="org.alfresco.share.folders.favourites";
	    		final String currentUserName=AuthenticationUtil.getFullyAuthenticatedUser();
	    		Map<String, Serializable> currentPreferencesFolder = preferenceService.getPreferences(currentUserName,preferenceFilter);
	    		if(currentPreferencesFolder.containsKey(preferenceFilter)){
	    			String item=(String)currentPreferencesFolder.get(preferenceFilter);
	    			log.info("item----------"+item);
	    			
	    			if(item.indexOf(",")!=-1 && item.indexOf(",")<2 )
	    			item = item.substring(1);
	    			String[] itemArray =item.trim().split(",");
	    			log.info("itemArray----------"+itemArray.length);
	    			
	    			for(int i=0; i<itemArray.length; i++){
	    				final NodeRef nodeRef = new NodeRef(itemArray[i]); 
	    				log.info("nodeRef in for loop-----------"+nodeRef);
	    				
	    				AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
	    			             {
	    			             @Override
	    			             public Object doWork() throws Exception
	    			             {
	    			            	 if(serviceRegistry.getNodeService().exists(nodeRef)){
	    				            final boolean hasFolderPermission = hasAdminAccess(nodeRef,currentUserName, serviceRegistry); 
	    							log.info("in runas hasFolderPermission----------"+hasFolderPermission);
	    	
	    			                    if (hasFolderPermission)
	    			                    {
	    			                    	favList.add(nodeRef);
	    			                    }
	    			            	 }
	    			            	//end of noderef exists
	    			            	 return null;
	    			             
	    			             }
	    			            }, "admin");
	    				 
	    				}
	    		}
	    	}catch(Exception e) {
	    		e.printStackTrace();
	    		return null;
	    	}
	    	log.debug("fav list size:"+favList.size());
	    	
			return favList;
	    }
	    
	    /** Returning results in JSON object
		 * @param uploadList
		 * @param response
		 * @param dStart
		 * @param dEnd
		 */
		public void getJSONReport(List<BIReportsAuditMap> uploadInfoList, WebScriptResponse response, String dStart, String dEnd) {
			
			log.info("inside the getJSONReport.....");
			try {
				JSONArray jsonArray = new JSONArray();
				JSONObject jsonObj = null;
				Map<String,Object> propValues = null;
				if (uploadInfoList != null && uploadInfoList.size() > 0) {
					for (BIReportsAuditMap bo : uploadInfoList) {
						if (bo != null) {
							if(bo.getEdcsId() != null && bo.getEdcsId().trim().length() > 0
									&& bo.getSecurityClassification() != null && bo.getSecurityClassification().trim().length() > 0){
								propValues = BIReportsUtil.getPropValues(bo.getPropKeyValue());
								jsonObj = new JSONObject();
								jsonObj.put(DocTitle, bo.getFileName());
								jsonObj.put(DocId, bo.getEdcsId());
								jsonObj.put(Security, bo.getSecurityClassification());
								String folderPath = bo.getFolderPath();
								if(folderPath.contains(DISPLAY_EXTERNAL_PATH)){
									folderPath = folderPath.substring(DISPLAY_EXTERNAL_PATH.length(), folderPath.length());
								}
								String auditTime = formatter2.format(bo.getAuditTime());
								jsonObj.put(FolderPath, folderPath);
								jsonObj.put(PublishedDate, auditTime);
								jsonObj.put(Publisher, bo.getUserId());
								jsonObj.put(Description, bo.getDescription());
								jsonObj.put(LastModifiedBy, bo.getUserId());
								jsonObj.put(ModifiedDate, auditTime);
								if(propValues != null){
									String size =  (String)propValues.get("contentSize");
	                    			String contentSize ="";
	                    			if(size != null){
	                    				contentSize = biReportsUtil.formatFileSize(Long.parseLong(size));
	                    			}
	                    			jsonObj.put(ContentSize, contentSize);
									if((String)propValues.get("publishExpirationDate") != null)
									jsonObj.put(ExpiryDate, formatter2.format(formatter3.parse((String)propValues.get("publishExpirationDate"))));
									jsonObj.put(ExtPublishedUsers, (String)propValues.get("externalUsers"));
									jsonObj.put(DocumentStatus, (String)propValues.get("status"));
									jsonObj.put(WorkflowStatus, (String)propValues.get("workflowStatus"));
								}
								jsonArray.put(jsonObj);
							}
						}
					}
				}
				response.setContentType("application/json");
				response.setContentEncoding("UTF-8");
				response.getWriter().write(jsonArray.toString());
			}catch(Exception e) {
				log.error("Exception:"+e);
				e.printStackTrace();
			}
		}
	    
	public void getUploadReport(final List<BIReportsAuditMap> searchList,final WebScriptResponse response, final String dStart, final String dEnd) {
		log.info("inside the getPermissionReport.....");
		final WritableCellFormat EXCEL_DATE_FORMATTER = new WritableCellFormat(new DateFormat("MM/dd/yyyy hh:mm:ss"));
		
			AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
				{
					@Override
					public Object doWork() throws Exception
					{
						 // creating workbook
		                 WritableWorkbook workbook = null;
		                 String reportHeading = "Upload Audit Report from "+dStart+" to "+dEnd;
		                 String noDataFound = " No Audit data found";
		                 Map<String,Object> propValues = null;
		                 String folderPathLinkURL = null;
		                 
		                 try {
		                 WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);
		                 
		                 OutputStream os = response.getOutputStream();
	                     workbook = Workbook.createWorkbook(os);
	                     
	                     WritableSheet wSheet1 = workbook.createSheet("Upload Report", 0);
	                     wSheet1.setRowView(0, 800);
	                     timesHeading = new WritableCellFormat(times10ptBoldUnderline);
	                     
	                     timesHeading.setWrap(true);
	                     // do not automatically wrap the cells
	                     biReportsUtil.addHeading(wSheet1, 0, 0, reportHeading);
	                     wSheet1.mergeCells(0, 0, 13, 0);
	                     
	                     biReportsUtil.createLabel(wSheet1, DocTitle, 0);
                         biReportsUtil.createLabel(wSheet1, DocId, 1);
                         biReportsUtil.createLabel(wSheet1, Security, 2);
                         biReportsUtil.createLabel(wSheet1, FolderPath, 3);
                         biReportsUtil.createLabel(wSheet1, "Expiry Date (GMT)", 4);
                         biReportsUtil.createLabel(wSheet1, PublishedDate, 5);
                         biReportsUtil.createLabel(wSheet1, Publisher, 6);
                         biReportsUtil.createLabel(wSheet1, ExtPublishedUsers, 7);
                         biReportsUtil.createLabel(wSheet1, Description, 8);
                         biReportsUtil.createLabel(wSheet1, ContentSize, 9);
                         biReportsUtil.createLabel(wSheet1, LastModifiedBy, 10);
                         biReportsUtil.createLabel(wSheet1, ModifiedDate, 11);
                         biReportsUtil.createLabel(wSheet1, DocumentStatus, 12);
                         biReportsUtil.createLabel(wSheet1, WorkflowStatus, 13);
                         biReportsUtil.createLabel(wSheet1, CurrentVersion, 14);
                         biReportsUtil.createLabel(wSheet1, Comments, 15);
	                     
                         WritableCellFormat  cellFormat = null;
                         Label label = null;
	                     int rowNumber = 2;
	                     boolean checkIn;
	                     wSheet1. setColumnView(4, 20);
                         wSheet1. setColumnView(5, 20);
	                     if (searchList != null && searchList.size() >0) {
	                    	 for (BIReportsAuditMap bo : searchList) {
	                    		 if (bo != null) {
	                    			 checkIn = true;
	                    		 if (bo.getEdcsId() != null && !bo.getEdcsId().trim().equals("") &&
	                    				 (bo.getSecurityClassification() != null && bo.getSecurityClassification().trim().length() > 0)
	                    				 && !bo.getUserId().equalsIgnoreCase("ciscoadmin.gen")) {
		                    		String nodeRefString = bo.getNoderef(); 
		                    		 if (nodeRefString != null) {
	                    				 propValues = BIReportsUtil.getPropValues(bo.getPropKeyValue());
	                    				 log.info("propValues map:"+propValues.toString());
	                    				 biReportsUtil.addLabel(wSheet1, 0, rowNumber, bo.getFileName());
	                            			biReportsUtil.addLabel(wSheet1, 1, rowNumber, bo.getEdcsId());
	                            			biReportsUtil.addLabel(wSheet1, 2, rowNumber, bo.getSecurityClassification());
	                            			
	                            			NodeRef nodeRef = new NodeRef(nodeRefString);
	                            			NodeRef parentNodeRef = null;
	                            			
	                            			
	                            			String folderPath = bo.getFolderPath();
	                						if(folderPath.contains(DISPLAY_EXTERNAL_PATH)){
	                							folderPath = folderPath.substring(DISPLAY_EXTERNAL_PATH.length(), folderPath.length());
	                						}
	                						if (nodeService.exists(nodeRef)) {
	                            				parentNodeRef = serviceRegistry.getNodeService().getPrimaryParent(nodeRef).getParentRef();
	                            				folderPathLinkURL= folderURL+parentNodeRef.getId();
	                            				URL folderUrl = new URL(folderPathLinkURL);
	                            				WritableHyperlink wh = new WritableHyperlink(3, rowNumber, folderUrl);
	                            				wSheet1.addHyperlink(wh);
	                            				WritableFont   blueFont = new WritableFont(WritableFont.ARIAL);
	                            				blueFont.setColour(Colour.BLUE);
	                    						cellFormat = new WritableCellFormat(blueFont);
	                    						label = new Label(3 ,rowNumber,folderPath,cellFormat);
	                    						wSheet1.addCell(label);
	                    			
	                            			} else {
	                            				biReportsUtil.addLabel(wSheet1, 3, rowNumber, folderPath);
	                            			}  
	                            			
	                            			
	                            			String auditTime = formatter2.format(bo.getAuditTime());
	                            			
	                            			Date date = formatter4.parse(auditTime);
	                                        WritableCell cell = new jxl.write.DateTime(5, rowNumber, date); //2015/09/07 04:06:48
	                                        cell.setCellFormat(EXCEL_DATE_FORMATTER);
	                                        wSheet1.addCell(cell);
	                                        
	                                        biReportsUtil.addLabel(wSheet1, 6, rowNumber, bo.getUserId());
	                            			biReportsUtil.addLabel(wSheet1, 8, rowNumber, bo.getDescription());
	                            			biReportsUtil.addLabel(wSheet1, 10, rowNumber, bo.getUserId());
	                            			biReportsUtil.addLabel(wSheet1, 11, rowNumber, auditTime);
	                            			
	                            			String version = null;
	                            			if(propValues != null){
	                            				if((String)propValues.get("publishExpirationDate") != null) {
	                            					Date expDate = formatter4.parse(formatter2.format(formatter3.parse((String)propValues.get("publishExpirationDate"))));
	                            					 WritableCell cell2 = new jxl.write.DateTime(4, rowNumber, expDate);
	                            					 cell2.setCellFormat(EXCEL_DATE_FORMATTER);
	     	                                        wSheet1.addCell(cell2);
	                            				}
	                            				if((String)propValues.get("version") != null) {
	                            					version = (String)propValues.get("version");
	                            					log.info("version :"+version);
	                            					biReportsUtil.addLabel(wSheet1, 14, rowNumber, version);
	                            				}
	                            				
	                            				 log.info("externalUsers:"+(String)propValues.get("externalUsers"));
	                            				 if (bo.getAction() != null && !bo.getAction().equalsIgnoreCase("CHECK IN")) {
	                            					 biReportsUtil.addLabel(wSheet1, 7, rowNumber, (String)propValues.get("externalUsers"));
	                            					 checkIn = false;
	                            				 }
		                            			String size =  (String)propValues.get("contentSize");
		                            			String contentSize ="";
		                            			if(BIReportsUtil.valueNotNull(size)){
		                            				contentSize = biReportsUtil.formatFileSize(Long.parseLong(size));
		                            			}
		                            			biReportsUtil.addLabel(wSheet1, 9, rowNumber,contentSize);
		                            			biReportsUtil.addLabel(wSheet1, 12, rowNumber,(String)propValues.get("status"));
		                            			biReportsUtil.addLabel(wSheet1, 13, rowNumber, (String)propValues.get("workflowStatus"));
		                            			
		                            			
	                            			}
	                            			String comment = "";
	                            			String externalUsers = "";
	                            			if (nodeService.exists(nodeRef)) {
	                    						VersionHistory versionHistory=versionService.getVersionHistory(nodeRef);
	                    						if(versionHistory != null && versionHistory.getAllVersions().size() > 0) {
	                    							Collection<Version> versions =  versionHistory.getAllVersions();
	                    							for(Version versionNode : versions) {
	                    								NodeRef vnodeRef=versionNode.getFrozenStateNodeRef();
	                    								String currVersion = nodeService.getProperty(vnodeRef, ContentModel.PROP_VERSION_LABEL).toString();
	                    								if (currVersion != null && currVersion.equalsIgnoreCase(version)) {
	                    									QName qComment = QName.createQName("http://www.cisco.com/model/content/1.0","comment");
		                    								comment = (String) nodeService.getProperty(vnodeRef, qComment);
	                    									if (comment != null && comment.trim().length() > 0) {
	                    										biReportsUtil.addLabel(wSheet1, 15, rowNumber, comment);
	                    									}
	                    									if(checkIn) {
	                    										QName qExternalUsers = QName.createQName("http://www.alfresco.org/model/external/content/1.0","externalUsers");
	                    										externalUsers = (String) nodeService.getProperty(vnodeRef, qExternalUsers);
	                    										if (externalUsers != null && externalUsers.trim().length() > 0) {
	                    											biReportsUtil.addLabel(wSheet1, 7, rowNumber, externalUsers);
	                    										}
	                    									}
	                    								}
	                    							}
	                    						}
	                            			}
	                    				 rowNumber++;
		                    			 
		                    	 		}
	                    	 		}
	                    		 }
	                    	 }
	                     } else {
	                    	 biReportsUtil.addHeading(wSheet1, 0, 2, noDataFound);
	                     }
	                    	 workbook.write();
	                         workbook.close();
	                         log.info("Successfully " + rowNumber + " Records created. ");
	                         response.addHeader("Content-Disposition", "attachment;filename=Upload-Report.xls");
	                         response.setContentType("application/vnd.ms-excel");
	                         response.setContentEncoding("UTF-8");
	                         response.setHeader("Cache-Control", "private, max-age=0");
	                         log.info("Excel File Downloaded Successfully...");
		                 } catch (Exception e)
	                         {
	                             log.info("Exception : " + e);
	                             e.printStackTrace();
	                         }
	                     
						return null;
					}
				}, "admin");
		
	}
	
	public static List splitListToSubList(List<String> parentList, int pageSize) {
		List<List<String>> childList = new ArrayList<List<String>>();
		List<String> tempList = new ArrayList<String>();
        int count = 0;
        if (parentList != null) {
            for (String obj : parentList) {
                if (count < pageSize) {
                    count = count + 1;
                    tempList.add(obj);
                } else {
                    childList.add(tempList);
                    tempList = new ArrayList<String>();
                    tempList.add(obj);
                    count = 1;
                }
 
            }
            if (tempList.size() <= pageSize) {
                childList.add(tempList);
            }
        }
        return childList;
    }

}
