/**
 * Class is used to get all Download documents audit info 
 * 
 * @author mkatnam
 *
 */
package com.cisco.edcsng.audit.bireports.publish;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.cmr.repository.InvalidStoreRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.PermissionService;
import org.apache.log4j.Logger;
//import org.hibernate.SessionFactory;
import org.apache.ibatis.session.SqlSessionFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.edcsng.audit.bireports.utils.BIReportConstants;
import com.cisco.edcsng.audit.bireports.utils.BIReportsAuditMap;
import com.cisco.edcsng.audit.bireports.utils.BIReportsUtil;
import com.cisco.edcsng.audit.bireports.utils.GenericQueryUtil;

public class DownloadAuditReport extends AbstractWebScript implements BIReportConstants
{
    private Logger _logger = Logger.getLogger(DownloadAuditReport.class);
    BIReportsUtil biReportsUtil = null; 
    
    private NodeService nodeService;
    private PermissionService permissionService;
    private Properties globalProperties;
	//private SessionFactory localFactory;
	private SqlSessionFactory localFactory;

	/*public void setLocalFactory(SessionFactory localFactory) {
		this.localFactory = localFactory;
	}*/
	 public SqlSessionFactory getLocalFactory() {
			return localFactory;
		}

		public void setLocalFactory(SqlSessionFactory localFactory) {
			this.localFactory = localFactory;
		}	

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}
	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}

	public void setGlobalProperties(Properties globalProperties) {
		this.globalProperties = globalProperties;
	}

	public void execute(WebScriptRequest req, WebScriptResponse res){
        _logger.info("Start Admin-Download Report's......");
        NodeRef processNode 			= null;
        String dStart 					= null;
        String dEnd 					= null;
        String folderPath 				= null;
        String  userID					= null;
        String jsonFormat 				= null;
        String queryLimit 				= null;
        Map<String, Object> auditMap    = new HashMap<String, Object>();
        List<BIReportsAuditMap> queryResultList		= null;
        JSONObject json;
        
        try{
        	biReportsUtil 		= new BIReportsUtil();
            Content content 	= req.getContent();
            if (content == null)
            {
                throw new WebScriptException(Status.STATUS_BAD_REQUEST, "Missing POST body.");
            }
                json = new JSONObject(content.getContent());

                dStart 				= json.getString("dateStart");
				dEnd 				= json.getString("dateEnd");
				if(json.has("userIDs") && BIReportsUtil.valueNotNull(json.getString("userIDs"))){
					 userID = json.getString("userIDs");
				}
				
				if(json.has("nodeId") && BIReportsUtil.valueNotNull(json.getString("nodeId"))){
					processNode = new NodeRef(json.getString("nodeId"));
				}
				_logger.info("folderNodeRef:"+processNode);
				
				if(json.has("format") && BIReportsUtil.valueNotNull(json.getString("format"))){
					jsonFormat = json.getString("format");
				}
				

                if (dStart == null || dStart.length() == 0)
                {
                    throw new WebScriptException(HttpServletResponse.SC_BAD_REQUEST, "Start Date not specified");
                }
                if (dEnd == null)
                {
                    throw new WebScriptException(HttpServletResponse.SC_BAD_REQUEST, "End Date not specified");
                }

            if(processNode != null){
            	
            	String nodeName = (String)nodeService.getProperty(processNode, ContentModel.PROP_NAME);
            	folderPath 		= nodeService.getPath(processNode).toDisplayPath(nodeService, permissionService)+"/"+nodeName;
            	
			}
            queryLimit = globalProperties.getProperty("audit.results.limit");
            
			 auditMap.put("folderPath",folderPath);
			 auditMap.put("users",userID);
			 auditMap.put("dStart",dStart);
			 auditMap.put("dEnd",dEnd);
			 auditMap.put("reportType",jsonFormat);
			 auditMap.put("limit",queryLimit);
			 
			 queryResultList = GenericQueryUtil.reportList(auditMap, localFactory, "downloadReport");

	         Collections.sort(queryResultList,BIReportsUtil.auditDateComparator);
            
            if(jsonFormat != null && jsonFormat.equalsIgnoreCase("json")){
            	getJSONReport(queryResultList,res,dStart,dEnd);
            }else{
	            getDownloadReport(queryResultList,res,dStart,dEnd);
            
            }
            
        }catch(WebScriptException e){
        	e.printStackTrace() ;      	
        }  catch (JSONException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InvalidStoreRefException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    }
    
/** writing the audit data into excel sheet 
 * @param downloadList
 * @param response
 * @param dStart
 * @param dEnd
 */
public void getDownloadReport(final List<BIReportsAuditMap> downloadList, final WebScriptResponse response, final String dStart, final String dEnd)
{
    _logger.info("inside the getDownloadreport.....");
    
    AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
            {
                @Override
                public Object doWork() throws Exception
                {
                	 // creating workbook
                    WritableWorkbook workbook = null;
                    String reportHeading = "Download Audit data from "+dStart+" to "+dEnd;
                    String noDataFound = " No Audit data found";
                    Map<String,Object> propValues = null;
                    String downloadCount          = "";
                    try                    {
                        OutputStream os = response.getOutputStream();
                        workbook = Workbook.createWorkbook(os);

                        // creating sheets in the workbook
                        WritableSheet wSheet1 = workbook.createSheet("Audit Download Report", 0);
                        wSheet1.setColumnView(0, 20);
                        wSheet1.setColumnView(1, 20);
                        wSheet1.setRowView(0, 800);
                       
                        biReportsUtil.addHeading(wSheet1, 0, 0, reportHeading);
                        wSheet1.mergeCells(0, 0, 13, 0);

                        biReportsUtil.createLabel(wSheet1, CompanyName, 0);
                        biReportsUtil.createLabel(wSheet1, UserID, 1);
                        biReportsUtil.createLabel(wSheet1, LastnameFirstname, 2);
                        biReportsUtil.createLabel(wSheet1, DownloadedContentTitle, 3);
                        biReportsUtil.createLabel(wSheet1, DownloadedTime, 4);
                        biReportsUtil.createLabel(wSheet1, NoOfDownloads, 5);
                        biReportsUtil.createLabel(wSheet1, DataTransferred, 6);
                        biReportsUtil.createLabel(wSheet1, FolderPath, 7);

                        int rowNumber = 2;
                        if(downloadList != null && downloadList.size() > 0){
                        	for (BIReportsAuditMap recordKey : downloadList)	{
                        		if (recordKey != null)
                        		{
                        			if (recordKey.getEdcsId() != null &&
                        						!recordKey.getEdcsId().trim().equals("")) {
                        			String folderPath = recordKey.getFolderPath();
                        			if (BIReportsUtil.valueNotNull(folderPath))  {
	                        			propValues = BIReportsUtil.getPropValues(recordKey.getPropKeyValue());
	                        			biReportsUtil.addLabel(wSheet1, 0, rowNumber, recordKey.getCompanyName());
	                        			biReportsUtil.addLabel(wSheet1, 1, rowNumber, recordKey.getUserId());
	                        			if (propValues.get("first_last_name") != null) {
	                        				biReportsUtil.addLabel(wSheet1, 2, rowNumber, (String)propValues.get("first_last_name"));
	                        			}
	                        			biReportsUtil.addLabel(wSheet1, 3, rowNumber, recordKey.getFileName());
	                        			
	    	                 			String auditTime = formatter2.format(recordKey.getAuditTime());
	                        			biReportsUtil.addLabel(wSheet1, 4, rowNumber, auditTime);
	                        			if (propValues.get("download_count") != null) {
	                        				downloadCount = (String)propValues.get("download_count");
	                        				if(downloadCount.equalsIgnoreCase("0")){
	                        					biReportsUtil.addLabel(wSheet1, 5, rowNumber,"-");
	                        				}else{
	                        					biReportsUtil.addLabel(wSheet1, 5, rowNumber, downloadCount);
	                        				}
	                        			}
	                                    if (propValues.get("content_size") != null) {
	                                    	biReportsUtil.addLabel(wSheet1, 6, rowNumber, (String)propValues.get("content_size"));
	                                    }
	                                    if (folderPath.contains(DISPLAY_EXTERNAL_PATH)){
	    	                 				folderPath = folderPath.substring(DISPLAY_EXTERNAL_PATH.length(), folderPath.length());
	    	                 			}
	                                    biReportsUtil.addLabel(wSheet1, 7, rowNumber, folderPath);
	                                    rowNumber++;
                        			} 
                        		}
                        		}
                             
                        		
                        	}
                        }else{
                        	biReportsUtil.addHeading(wSheet1, 0, 2, noDataFound);
                        }
                        workbook.write();
                        workbook.close();
                        _logger.info("..Successfully " + rowNumber + " Records created. ");

                        response.addHeader("Content-Disposition", "attachment;filename=Audit-DownloadReport.xls");
                        response.setContentType("application/vnd.ms-excel");
                        response.setContentEncoding("UTF-8");
                        response.setHeader("Cache-Control", "private, max-age=0");
                        _logger.info("Excel File Downloaded Successfully...");
                    }
                    catch (Exception e)
                    {
                        _logger.info("Exception : " + e);
                        e.printStackTrace();
                    }
                    return null;
                }

            }, "admin");
   
}

/** Returning results in JSON object
 * @param downloadList
 * @param response
 * @param dStart
 * @param dEnd
 */
public void getJSONReport(List<BIReportsAuditMap> downloadList, WebScriptResponse response, String dStart, String dEnd) {

	_logger.info("inside the getDownloadreport.....");

	try {
		JSONArray jsonArray = new JSONArray();

		JSONObject jsonObj = null;
		 Map<String,Object> propValues = null;
         String downloadCount          = null;
		
		if (downloadList != null && downloadList.size() > 0) {
			for (BIReportsAuditMap biMap : downloadList) {
				if (biMap != null) {
					String folderPath = biMap.getFolderPath();
					if (BIReportsUtil.valueNotNull(folderPath)){
						jsonObj = new JSONObject();
						propValues = BIReportsUtil.getPropValues(biMap.getPropKeyValue());
						jsonObj.put(CompanyName, biMap.getCompanyName());
						jsonObj.put(UserID, biMap.getUserId());
						if (propValues.get("first_last_name") != null) {
	        				jsonObj.put(LastnameFirstname, (String)propValues.get("first_last_name"));
						}
						jsonObj.put(DownloadedContentTitle, biMap.getFileName());
						jsonObj.put(DownloadedTime, biMap.getAuditTime());
						if (propValues.get("download_count") != null) {
	        				downloadCount = (String)propValues.get("download_count");
							if (downloadCount.equalsIgnoreCase("0")) {
								jsonObj.put(NoOfDownloads, "-");
							} else {
								jsonObj.put(NoOfDownloads,downloadCount);
							}
						}
						  if (propValues.get("content_size") != null) {
	                      	jsonObj.put(DataTransferred,(String)propValues.get("content_size"));
						  }
						  
						 if (folderPath.contains(DISPLAY_EXTERNAL_PATH)){
	           				folderPath = folderPath.substring(DISPLAY_EXTERNAL_PATH.length(), folderPath.length());
	           			}
						jsonObj.put(FolderPath, folderPath);
						jsonArray.put(jsonObj);
					}
				}

			}
		}

		response.setContentType("application/json");
		response.setContentEncoding("UTF-8");
		response.getWriter().write(jsonArray.toString());
		
	} catch (Exception e) {
		_logger.info("Exception : " + e);
		e.printStackTrace();
	}

}
	
}