package com.cisco.edcsng.audit.bireports.publish;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;

public class FolderAdminPermission {
	
	public  Set<AccessPermission> getAllNodeRefPermissions(final ServiceRegistry serviceRegistry,
			final NodeRef nodeRef) {
		final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef));
				return null;
			}
		}, "admin");
		return accessPermission;
	}

	

	public List<String> getFolderAdminUsers(NodeRef node, ServiceRegistry serviceRegistry) {
		List<String> permissionsList  = new ArrayList<String>();
		try {
			//List<Object> canPermission;
			AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				@Override
				public List<String> doWork() throws Exception {
					//List canPermission ;
					if (serviceRegistry.getNodeService().exists(node)) {
						Set<AccessPermission> accessPermissions = getAllNodeRefPermissions(serviceRegistry, node);
						//log.info("accessPermissions : " + accessPermissions);

						Iterator<AccessPermission> fIterator = accessPermissions.iterator();

					//	String currentUserName = serviceRegistry.getAuthenticationService().getCurrentUserName();
						//log.info("Current login UserName : " + currentUserName);
						// AdminRole
						while (fIterator.hasNext()) {
							AccessPermission accessPermission = (AccessPermission) fIterator.next();

							if (accessPermission.getAuthorityType() == AuthorityType.USER) {
								//log.info("Authority(User): " + accessPermission.getAuthority() + " Permission:  "+ accessPermission.getPermission());
							//	String autherityUserName = accessPermission.getAuthority();
								String user = accessPermission.getAuthority();
								String autherityUserPermission = accessPermission.getPermission();
								if ((user!=null &&autherityUserPermission!=null) &&autherityUserPermission.equals("AdminRole")) {
									permissionsList.add(user);
								}
							}
						}
					}
					return permissionsList;
				}
			}, "admin");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return permissionsList;
	}

	
}						
	

