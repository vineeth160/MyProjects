package com.cisco.edcsng.audit.bireports.publish;

import java.io.OutputStream;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jxl.CellView;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.security.AccessPermission;
import org.alfresco.service.cmr.security.AuthorityType;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.edcsng.audit.bireports.utils.BIReportConstants;
import com.cisco.edcsng.audit.bireports.utils.BIReportsUtil;
import com.cisco.edcsng.audit.bireports.utils.BIReportsAuditMap;


public class UserActivityExcel implements BIReportConstants{

private Logger log = Logger.getLogger(UserActivityExcel.class);
private WritableCellFormat times;
private WritableCellFormat timesBoldUnderline;
private WritableCellFormat timesHeading;
private static final String GROUP_EVERYONE = "GROUP_EVERYONE";
private static final String userIdOrMemberOfGroupId = "GROUP_CISCOSHARE_ADMIN";

	
    
    public void getUserActivityReport(final List<BIReportsAuditMap> bo, final WebScriptResponse response, final String dStart, final String dEnd,final String logginUser, ServiceRegistry serviceRegistry) {
    	 
    	log.info("inside the getUserActivityReport.....");
         AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
        	{
        	 @Override
             public Object doWork() throws Exception
             {
        		 // creating workbook
                 WritableWorkbook workbook = null;
                 String reportHeading = "User Activity Audit Report from "+dStart+" to "+dEnd;
                 String noDataFound = " No Audit data found";
                 Map<String,Object> propValues = null;
                 String oldDomain 		= null;
                 String newDomain 		= null;
                 StringBuffer domain    = null;
                
                 WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);
                 try {
                	 OutputStream os = response.getOutputStream();
                     workbook = Workbook.createWorkbook(os);

                     // creating sheets in the workbook
                     WritableSheet wSheet1 = workbook.createSheet("UserActivity Report", 0);
                     wSheet1.setColumnView(0, 20);
                     wSheet1.setColumnView(1, 20);
                     wSheet1.setRowView(0, 800);
                     timesHeading = new WritableCellFormat(times10ptBoldUnderline);
                     // do not automatically wrap the cells
                     timesHeading.setWrap(true);
                     // do not automatically wrap the cells
                     addHeading(wSheet1, 0, 0, reportHeading);
                     wSheet1.mergeCells(0, 0, 13, 0);
                     createLabel(wSheet1, CompanyName, 0);
                     createLabel(wSheet1, UserID, 1);
                     createLabel(wSheet1, DocTitle, 2);
                     createLabel(wSheet1, AccessedTime, 3);
                     createLabel(wSheet1, FolderPath, 4);
                     createLabel(wSheet1, DocId, 5);
                     createLabel(wSheet1, Action, 6);
                     createLabel(wSheet1, Remarks, 7);
                     
                     int rowNumber = 2;
                     Boolean userAdminPermissionFlag = canUserHaveAdminGroupPermission(serviceRegistry, logginUser);
 					log.info("userAdminPermissionFlag....." + userAdminPermissionFlag);
 					if (userAdminPermissionFlag) {
                     if(bo != null && bo.size() > 0) {
	                     for (BIReportsAuditMap recordKey : bo)	{
	                 		if (recordKey != null)
	                 		{
	                 			if (recordKey.getUserId().equalsIgnoreCase("ciscoadmin.gen") && recordKey.getEdcsId() != null &&
	                 					 !recordKey.getEdcsId().trim().equals("")) {
	                 				continue;
	                 			}
	                 			if (recordKey.getFolderPath() != null && recordKey.getFolderPath().trim().length() > 0) {
	                 				addLabel(wSheet1, 0, rowNumber, recordKey.getCompanyName());
		                 			addLabel(wSheet1, 1, rowNumber, recordKey.getUserId());
		                 			addLabel(wSheet1, 2, rowNumber, recordKey.getFileName());
		                 			//SimpleDateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
		                 			String auditTime = formatter6.format(recordKey.getAuditTime());
		                 			addLabel(wSheet1, 3, rowNumber, auditTime);
		                 			if (recordKey.getFolderPath().contains(DISPLAY_EXTERNAL_PATH))
		                 			{
		                 				String folderPath = recordKey.getFolderPath();
		                 				folderPath = folderPath.substring(DISPLAY_EXTERNAL_PATH.length(), folderPath.length());
		                 				addLabel(wSheet1, 4, rowNumber, folderPath);
		                 			}
		                 			addLabel(wSheet1, 5, rowNumber, recordKey.getEdcsId());
		                 			addLabel(wSheet1, 6, rowNumber, recordKey.getAction());
		                 			String act = recordKey.getAction();
		                 			if(act.contains("Domain")){
		                 				domain       = new StringBuffer();
		                 				propValues = BIReportsUtil.getPropValues(recordKey.getPropKeyValue());
		                 				if (propValues != null) {
		                 					if ((oldDomain = (String) propValues.get("old_domain")) != null && oldDomain.length() > 0){
		                 						domain.append("Old domain:"+oldDomain+"\n");
		                 					}
		                 					if ((newDomain = (String) propValues.get("new_domain")) != null && newDomain.length() > 0){
		                 						domain.append(" New domain:"+newDomain);
		                 					}
		                 				}
		                 				if(domain.length() > 0)
		                 					addLabel(wSheet1, 7, rowNumber, domain.toString());
		                 			}
		                 			rowNumber++;
	                 			}
	                 			
	                 		}
	                 		
	                     }
                     } else{
                    	 addHeading(wSheet1, 0, 2, noDataFound);
                 }
 					}else {
 						if (bo != null && bo.size() > 0) {
							log.info("Came to Non-Admin user block.....");
							for (BIReportsAuditMap recordKey : bo) {

								// log.info("nodeRef....." + nodeRef + "==NodeRef Name==== " + docName);
								if (recordKey != null) {
									String nodeRefValue = recordKey.getNoderef();
									if (nodeRefValue!=null) {
									NodeRef nodeRef = new NodeRef(nodeRefValue);
									log.info("recordKey.getCompanyName()....." + recordKey.getFileName());
									Boolean canUserHavePermission = canUserHavePermission(nodeRef, serviceRegistry);
									log.info("canUserHavePermission....." + canUserHavePermission);
									// String docName = (String)
									// serviceRegistry.getNodeService().getProperty(nodeRef,ContentModel.PROP_NAME);
									if (recordKey.getUserId().equalsIgnoreCase("ciscoadmin.gen")
											&& recordKey.getEdcsId() != null && !recordKey.getEdcsId().trim().equals("")
											&& !canUserHavePermission) {
										continue;
									}

									if (recordKey.getFolderPath() != null
											&& recordKey.getFolderPath().trim().length() > 0 && canUserHavePermission) {
										//log.info("recordKey.getCompanyName()....." + recordKey.getCompanyName());
										//log.info("recordKey.getUserId()....." + recordKey.getUserId());
										//log.info("rowNumber, recordKey.getFileName()....." + recordKey.getFileName());
										//log.info("recordKey....." + recordKey.toString());
										addLabel(wSheet1, 0, rowNumber, recordKey.getCompanyName());
										addLabel(wSheet1, 1, rowNumber, recordKey.getUserId());
										addLabel(wSheet1, 2, rowNumber, recordKey.getFileName());
										// SimpleDateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss z
										// yyyy");
										String auditTime = formatter6.format(recordKey.getAuditTime());
										//log.info("auditTime....." + auditTime);
										addLabel(wSheet1, 3, rowNumber, auditTime);
										if (recordKey.getFolderPath().contains(DISPLAY_EXTERNAL_PATH)) {
											String folderPath = recordKey.getFolderPath();
											//log.info("folderPath....." + folderPath);
											folderPath = folderPath.substring(DISPLAY_EXTERNAL_PATH.length(),
													folderPath.length());
											addLabel(wSheet1, 4, rowNumber, folderPath);
										}
										addLabel(wSheet1, 5, rowNumber, recordKey.getEdcsId());
										addLabel(wSheet1, 6, rowNumber, recordKey.getAction());
										String act = recordKey.getAction();
										//log.info("act....." + act);
										if (act.contains("Domain")) {
											domain = new StringBuffer();
											propValues = BIReportsUtil.getPropValues(recordKey.getPropKeyValue());
											//log.info("propValues....." + propValues);
											if (propValues != null) {
												if ((oldDomain = (String) propValues.get("old_domain")) != null
														&& oldDomain.length() > 0) {
													domain.append("Old domain:" + oldDomain + "\n");
												}
												if ((newDomain = (String) propValues.get("new_domain")) != null
														&& newDomain.length() > 0) {
													domain.append(" New domain:" + newDomain);
												}
												//log.info("domain....." + domain);
											}
											if (domain.length() > 0)
												addLabel(wSheet1, 7, rowNumber, domain.toString());
										}
										rowNumber++;
									}
								}
							}
							}
						} else {
							addHeading(wSheet1, 0, 2, noDataFound);
						}
 					}
                     workbook.write();
                     workbook.close();
                     log.info("Successfully " + rowNumber + " Records created. ");
                     response.addHeader("Content-Disposition", "attachment;filename=UserActivity-Report.xls");
                     response.setContentType("application/vnd.ms-excel");
                     response.setContentEncoding("UTF-8");
                     response.setHeader("Cache-Control", "private, max-age=0");
                     log.info("Excel File Downloaded Successfully...");
                 }  catch (Exception e) {
                     log.info("Exception : " + e);
                     e.printStackTrace();
                 }
                 return null;
             }
        }, "admin");
    }
   
  
    public void createLabel(WritableSheet sheet, String label, int col) throws WriteException
    {

        WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
        times = new WritableCellFormat(times10pt);
        times.setWrap(false);

        // Create create a bold font
        WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);
        timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
        timesBoldUnderline.setWrap(false);

        CellView cv = new CellView();
        cv.setFormat(times);
        cv.setFormat(timesBoldUnderline);
        // Write a few headers
        addCaption(sheet, col, 1, label);
    }
    public void addCaption(WritableSheet sheet, int column, int row, String s) throws RowsExceededException,
        WriteException
	{
		Label label;
		label = new Label(column, row, s, timesBoldUnderline);
		sheet.addCell(label);
	}
		
	public void addLabel(WritableSheet sheet, int column, int row, String s) throws WriteException,
		    RowsExceededException
	{
		Label label;
		label = new Label(column, row, s, times);
		sheet.addCell(label);
	}
		
	public void addHeading(WritableSheet sheet, int column, int row, String s) throws WriteException,
		    RowsExceededException
	{
		Label label;
		label = new Label(column, row, s, timesHeading);
		sheet.addCell(label);
	}
	public  Set<AccessPermission> getAllNodeRefPermissions(final ServiceRegistry serviceRegistry,
			final NodeRef nodeRef) {
		final Set<AccessPermission> accessPermission = new HashSet<AccessPermission>();
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				accessPermission.addAll(serviceRegistry.getPermissionService().getAllSetPermissions(nodeRef));
				return null;
			}
		}, "admin");
		return accessPermission;
	}

	public boolean canUserHaveAdminGroupPermission(ServiceRegistry serviceRegistry, String currentUser) {
		boolean currentUserHasGroupMember = false;
		try {
			currentUserHasGroupMember = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
				@Override
				public Boolean doWork() throws Exception {
					boolean currentUserIsGroupMember = false;
					if (userIdOrMemberOfGroupId != null && !userIdOrMemberOfGroupId.equalsIgnoreCase(GROUP_EVERYONE)) {
						currentUserIsGroupMember = serviceRegistry.getAuthorityService()
								.getAuthoritiesForUser(currentUser).contains(userIdOrMemberOfGroupId);
					}
					return currentUserIsGroupMember;
				}
			}, "admin");
			//log.info("currentUserHasGroupMember of accessPermission.getAuthorityType : " + currentUserHasGroupMember);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return currentUserHasGroupMember;

	}

	public boolean canUserHavePermission(NodeRef node, ServiceRegistry serviceRegistry) {
		boolean canPermission = false;
		//log.info("Condition Check for User is folderAdmin :");
		try {
			canPermission = AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Boolean>() {
				@Override
				public Boolean doWork() throws Exception {
					boolean canPermission = false;
					if (serviceRegistry.getNodeService().exists(node)) {
						Set<AccessPermission> accessPermissions = getAllNodeRefPermissions(serviceRegistry, node);
						//log.info("accessPermissions : " + accessPermissions);

						Iterator<AccessPermission> fIterator = accessPermissions.iterator();

						String currentUserName = serviceRegistry.getAuthenticationService().getCurrentUserName();
						//log.info("Current login UserName : " + currentUserName);
						// AdminRole
						while (fIterator.hasNext()) {
							AccessPermission accessPermission = (AccessPermission) fIterator.next();

							if (accessPermission.getAuthorityType() == AuthorityType.USER) {
								//log.info("Authority(User): " + accessPermission.getAuthority() + " Permission:  "+ accessPermission.getPermission());

								String autherityUserName = accessPermission.getAuthority();
								String autherityUserPermission = accessPermission.getPermission();
								if (autherityUserName.equals(currentUserName) && autherityUserPermission.equals("AdminRole")) {

									//log.info("Condition Authority(User): " + accessPermission.getAuthority() + " Permission: "+ accessPermission.getPermission());
									canPermission = true;

								}
							}
						}
					}
					return canPermission;
				}
			}, "admin");
			//log.info("currentUserHasGroupMember of accessPermission.getAuthorityType : " + currentUserHasGroupMember);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return canPermission;
	}
}