package com.cisco.edcsng.audit.download;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Map;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.transaction.RetryingTransactionHelper.RetryingTransactionCallback;
import org.alfresco.repo.version.Version2Model;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.service.cmr.audit.AuditQueryParameters;
import org.alfresco.service.cmr.audit.AuditService;
import org.alfresco.service.cmr.audit.AuditService.AuditQueryCallback;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter;
import org.alfresco.service.cmr.repository.datatype.TypeConversionException;
import org.alfresco.service.transaction.TransactionService;
import org.apache.log4j.Logger;
import java.util.Properties;
import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;

public class UpdateDownloadCount extends QuartzJobBean{
	
	private Logger log = Logger.getLogger(UpdateDownloadCount.class);
	private static final String JSON_KEY_ENTRY_ID = "id";
	private static final String JSON_KEY_ENTRY_APPLICATION = "application";
	private static final String JSON_KEY_ENTRY_USER = "user";
	private static final String JSON_KEY_ENTRY_TIME = "time";
	private static final String JSON_KEY_ENTRY_VALUES = "values";
	List<Map<String, Object>> downloadEntries 	= null;
	
	private static final String DOWNLOAD_COUNT_JOB_ENABLED = "UpdateDownloadCountJobEnable";
	NodeRef frozenNodeRef = null;
	
	private AuditService auditService;
	private NodeService nodeService;
	private TransactionService transactionService;
	private BehaviourFilter behaviourFilter;
	private Properties globalProperties;
	
	
	public BehaviourFilter getBehaviourFilter() {
		return behaviourFilter;
	}

	public void setBehaviourFilter(BehaviourFilter behaviourFilter) {
		this.behaviourFilter = behaviourFilter;
	}

	public TransactionService getTransactionService() {
		return transactionService;
	}

	public void setTransactionService(TransactionService transactionService) {
		this.transactionService = transactionService;
	}

	public NodeService getNodeService() {
		return nodeService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public AuditService getAuditService() {
		return auditService;
	}

	public void setAuditService(AuditService auditService) {
		this.auditService = auditService;
	}
	
	public void setGlobalProperties(Properties globalProperties)
    {
        this.globalProperties = globalProperties;
    }

	@Override
	protected void executeInternal(JobExecutionContext context)
			throws JobExecutionException {
		log.info("UpdateDownloadCount excuteInternal method...");
		
		String isJobEnabledStr = null;
		boolean isJobEnabled = false;
		downloadEntries      = new ArrayList<Map<String, Object>>();
		
		JobDataMap jobData = context.getJobDetail().getJobDataMap();
		isJobEnabledStr = (String) jobData.get(DOWNLOAD_COUNT_JOB_ENABLED);
		 log.info("DOWNLOAD_COUNT_JOB_ENABLED "+isJobEnabledStr);
		
		if (isJobEnabledStr != null)
        {
            try
            {
                isJobEnabled = new Boolean(isJobEnabledStr);
            }
            catch (Exception e)
            {
                log.error("Invalid '" + DOWNLOAD_COUNT_JOB_ENABLED + "' value, using default: " + isJobEnabled, e);
             }
          }
		
		 if (!isJobEnabled)
	        {
	            log.info("Skipping " + DOWNLOAD_COUNT_JOB_ENABLED + " to execute.");
	            return;
	        }
		 Date dt = new Date();
		 final long toTime = dt.getTime();
		 
		 long hours_12_Milli = TimeUnit.HOURS.toMillis(12);  //milli seconds of 12 hours
		 
		 
		 final long fromTime = toTime-hours_12_Milli;
		 
		 log.info("fromTime:"+fromTime+",ToTime:"+toTime);
		 
		 AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				@Override
				public Object doWork() throws Exception 
				{
					getDownloadData(fromTime, toTime);
					log.info("downloadEntries size..."+downloadEntries.size());
					updateDownloadCount(downloadEntries);
					return null;
					
				}
		 }, "admin");
		 
		
	}
	
	private void getDownloadData(Long fromTime, Long toTime)
    {
        int limit = 0;
        limit  = Integer.parseInt(globalProperties.getProperty("audit.results.limit"));
        final boolean verbose = true;
        AuditQueryParameters params = new AuditQueryParameters();
        params.setApplicationName("download-report"); 
        params.setFromTime(fromTime);
        params.setToTime(toTime);
        AuditQueryCallback callback = new AuditQueryCallback()
        {
        	 @Override
             public boolean valuesRequired()
             {
                 return verbose;
             }

             @Override
             public boolean handleAuditEntryError(Long entryId, String errorMsg, Throwable error)
             {
                 return true;
             }
             @Override
             public boolean handleAuditEntry(Long entryId, String applicationName, String user, long time,
                     Map<String, Serializable> values)
             {
                 Map<String, Object> entry = new HashMap<String, Object>(11);
                 entry.put(JSON_KEY_ENTRY_ID, entryId);
                 entry.put(JSON_KEY_ENTRY_APPLICATION, applicationName);

                 if (user != null)
                 {
                     entry.put(JSON_KEY_ENTRY_USER, user);
                 }
                 entry.put(JSON_KEY_ENTRY_TIME, new Date(time));

                 if (values != null)
                 {
                     // Convert values to Strings
                     Map<String, String> valueStrings = new HashMap<String, String>(values.size() * 2);
                     for (Map.Entry<String, Serializable> mapEntry : values.entrySet())
                     {
                         String key = mapEntry.getKey();
                         Serializable value = mapEntry.getValue();
                         try
                         {
                             String valueString = DefaultTypeConverter.INSTANCE.convert(String.class, value);
                             valueStrings.put(key, valueString);
                         }
                         catch (TypeConversionException e)
                         {
                             // Use the toString()
                             valueStrings.put(key, value.toString());
                         }
                     }
                     entry.put(JSON_KEY_ENTRY_VALUES, valueStrings);
                 }
                 downloadEntries.add(entry);

                 return true;
             }
         };

         // Make an audit call to applicationName
         auditService.auditQuery(callback, params, limit);
     }
	
	public void updateDownloadCount(List<Map<String, Object>> entries) {
		
		String nodeRefStr	= null;
		
		
		 if (entries.size() > 0) {
			 for (Map<String, Object> entryMap : entries) {
				 @SuppressWarnings("unchecked")
				Map<String, String> valuesMap = (Map<String, String>) entryMap.get(JSON_KEY_ENTRY_VALUES);
				 if(valuesMap != null) {					 
						 nodeRefStr = valuesMap.get("/download-report/document/noderef");
						 final NodeRef nodeRef = new NodeRef(nodeRefStr);
						 log.info("if check  :: " +Version2Model.STORE_ID  + "next part ::  " +nodeRef.getStoreRef().getIdentifier());
					if(nodeRef != null && !(Version2Model.STORE_ID.equals(nodeRef.getStoreRef().getIdentifier()))) { // "version2Store"						
						 try {
							 if (nodeService.exists(nodeRef)) {
							 AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {

								@Override
								public Object doWork() throws Exception {
									
									 transactionService.getRetryingTransactionHelper().doInTransaction(new RetryingTransactionCallback<Void>(){
										 @Override
										 public Void execute() throws Throwable {
											 
											 int downloadCount = 0;
											 if (nodeService.getProperty(nodeRef, CiscoModelConstants.PROP_CISCO_DOWNLOAD_COUNT) != null) {
												 downloadCount= (Integer) nodeService.getProperty(nodeRef, CiscoModelConstants.PROP_CISCO_DOWNLOAD_COUNT);
													 downloadCount =  downloadCount+1;
											 } else {
												 downloadCount = 1;
											 }
											 
											 behaviourFilter.disableBehaviour(ContentModel.ASPECT_AUDITABLE);
			        	                     nodeService.setProperty(nodeRef, CiscoModelConstants.PROP_CISCO_DOWNLOAD_COUNT, downloadCount);
			        	                     behaviourFilter.enableBehaviour(ContentModel.ASPECT_AUDITABLE);	

											 return null;
										 }
									 }, false, true); 
	        	                     
									return null;
								}
								 
							 }, "admin");
						 }
						 }catch (Exception e)
					        {
					            log.error("Exception in UpdateDownloadCount class:" + e);
					            e.printStackTrace();
					        }						 						 
					 }
				 }
				 
			 }
		 }
	}

}