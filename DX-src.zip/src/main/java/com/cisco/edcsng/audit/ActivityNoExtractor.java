package com.cisco.edcsng.audit;

import java.io.Serializable;

import org.alfresco.repo.audit.extractor.AbstractDataExtractor;
import org.alfresco.service.cmr.workflow.WorkflowService;
import org.alfresco.service.cmr.workflow.WorkflowTask;


/**
 * 
 * @author dhshaw
 * 
 */
public class ActivityNoExtractor extends AbstractDataExtractor
{

    public boolean isSupported(Serializable data)
    {
        return (data instanceof String);
    }

    public Serializable extractData(Serializable in) throws Throwable
    {
        Serializable activityNum = null;
        try
        {
            logger.debug("[ActivityNoExtractor] - Serializable Data : " + in);
            String taskId = (String) in;
            WorkflowTask task = workflowService.getTaskById(taskId);
            activityNum = task.getId();
            activityNum = activityNum.toString().substring(activityNum.toString().indexOf("$") + 1);
            logger.debug("[ActivityNoExtractor] - activityNum: " + activityNum);
        }
        catch (Exception e)
        {
            logger.error(e);
            throw e;
        }
        return activityNum;
    }

    private WorkflowService workflowService;

    public void setWorkflowService(WorkflowService workflowService)
    {
        this.workflowService = workflowService;
    }

}
