package com.cisco.edcsng.audit.bireports.utils;

import java.text.SimpleDateFormat;

public interface BIReportConstants {
	
	public static final SimpleDateFormat formatter 			= new SimpleDateFormat("MM/dd/yyyy");
	public static SimpleDateFormat formatter2				= new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
	public static SimpleDateFormat formatter3		   	 	= new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	public static SimpleDateFormat formatter4				= new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy");
	public static SimpleDateFormat formatter6				= new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
	
	 public static final String EXTERNAL_FOLDER_PATH  		= " PATH:\"/app:company_home/st:sites/cm:edcsng/cm:documentLibrary/cm:External_x0020_Sharing\"";
	 public static final String DISPLAY_EXTERNAL_PATH 		= "/Company Home/Sites/edcsng/documentLibrary";
	 
	 public static final String PUBLISH_APP_NAME			= "publish-report";
	 public static final String DOWNLOAD_APP_NAME			= "download-report";
	 public static final String USER_ACCESS_APP_NAME		= "user-access";

	 public static final String JSON_KEY_ENTRY_ID 			= "id";
	 public static final String JSON_KEY_ENTRY_APPLICATION 	= "application";
	 public static final String JSON_KEY_ENTRY_USER 		= "user";
	 public static final String JSON_KEY_ENTRY_TIME 		= "time";
	 public static final String JSON_KEY_ENTRY_VALUES 		= "values";

	 public static final String AUDIT_PUBLISH_PARAM_SEARCH_KEY 	= "/publish-report/document/path";
	 public static final String AUDIT_PUBLISH_PARAM_EVENT_KEY 	= "/publish-report/document/event";
	 public static final String AUDIT_DOWNLOAD_PARAM_SEARCH_KEY = "/download-report/document/path";
	 public static final String SEARCH_KEY_ACCESS_USER			= "/user-access/details/username";
	 
	 //work sheet column names
	 public static final String DocTitle 				= "Document Title";
	 public static final String DocId 					= "Document Id";
	 public static final String Security 				= "Data Classification";
	 public static final String FolderPath				= "Folder Path";
	 public static final String ExpiryDate 				= "Expiry Date";
	 public static final String PublishedDate 			= "Published Date (GMT)";
	 public static final String Publisher 				= "CEC/CCO Id (Publisher)";
	 public static final String ExtPublishedUsers 		= "List of CEC/CCO Ids (External Shared Users)";
	 public static final String Description 			= "Description";
	 public static final String ContentSize 			= "Size";
	 public static final String LastModifiedBy 			= "Last Modified By";
	 public static final String ModifiedDate 			= "Last Modified Date";
	 public static final String DocumentStatus 			= "Document Status";
	 public static final String WorkflowStatus 			= "Workflow Status";
	 public static final String CompanyName 			= "Company Name";
	 public static final String UserID 					= "User ID";
	 public static final String LastnameFirstname 		= "User Firstname Lastname";
	 public static final String DownloadedContentTitle 	= "Downloaded content title";
	 public static final String DownloadedTime 			= "Downloaded Time";
	 public static final String NoOfDownloads 			= "No. of Downloads";
	 public static final String DataTransferred 		= "Amount of Data Transferred";
	 public static final String AccessType 				= "Access Type";
	 public static final String AccessedTime 			= "Accessed Time (GMT)";
	 public static final String Remarks					= "Remarks";
	 public static final String Action					= "User Action";
	 public static final String Creator 				= "Creator";
	 public static final String Modifier 				= "Modifier";
	 public static final String DownloadedBy 			= "Downloaded By";
	 public static final String Comments 				= "Comments";
	 public static final String CurrentVersion 			= "Version";
}