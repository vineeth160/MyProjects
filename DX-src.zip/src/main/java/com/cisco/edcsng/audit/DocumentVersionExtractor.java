package com.cisco.edcsng.audit;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.extractor.AbstractDataExtractor;
import org.alfresco.repo.workflow.WorkflowModel;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.version.VersionService;
import org.alfresco.service.namespace.QName;


/**
 * 
 * @author dhshaw
 * 
 */
public class DocumentVersionExtractor extends AbstractDataExtractor
{

    public boolean isSupported(Serializable data)
    {
        return (data instanceof Map);
    }

    public Serializable extractData(Serializable in) throws Throwable
    {
        Serializable documentVersion = null;
        try
        {
            logger.debug("[DocumentVersionExtractor] - Serializable Data : " + in);
            Map<QName, Serializable> params = (Map<QName, Serializable>) in;
            NodeRef packageRef = (NodeRef) params.get(WorkflowModel.ASSOC_PACKAGE);
            logger.debug("[DocumentVersionExtractor] - PackageRef : " + packageRef);
            if (packageRef != null)
            {
                List<ChildAssociationRef> docListRef = nodeService.getChildAssocs(packageRef);
                if (docListRef == null || docListRef.isEmpty())
                {
                    logger.warn("Cannot audit a workflow with no documents attached");
                }
                else if (docListRef.size() > 1)
                {
                    logger.warn("Too many documents attached to the workflow; expecting only 1");
                }
                else
                {
                    NodeRef docRef = docListRef.get(0).getChildRef();
                    if (versionService.isVersioned(docRef))
                    {
                        documentVersion = versionService.getCurrentVersion(docRef).getVersionLabel();
                        logger.debug("[DocumentVersionExtractor] - Current Version: " + documentVersion);
                    }
                    else
                    {
                        documentVersion = nodeService.getProperty(docRef, ContentModel.PROP_VERSION_LABEL);
                        logger.debug("[DocumentVersionExtractor] - Document Version: " + documentVersion);
                        if (documentVersion == null)
                            documentVersion = "1.0";

                    }
                }
            }
        }
        catch (Exception e)
        {
            logger.error(e);
            throw e;
        }
        return documentVersion;
    }

    private NodeService nodeService;

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    private VersionService versionService;

    public void setVersionService(VersionService versionService)
    {
        this.versionService = versionService;
    }

}
