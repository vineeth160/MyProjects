package com.cisco.edcsng.audit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.extractor.AbstractDataExtractor;
import org.alfresco.repo.workflow.WorkflowModel;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;


/**
 * 
 * @author dhshaw
 * 
 */
public class AssigneeWorkflowExtractor extends AbstractDataExtractor
{

    public boolean isSupported(Serializable data)
    {
        return (data instanceof Map);
    }

    public Serializable extractData(Serializable in) throws Throwable
    {
        Serializable assigneeName = null;
        try
        {
            logger.debug("[AssigneeWorkflowExtractor] - Serializable Data : " + in);

            Map<QName, Serializable> params = (Map<QName, Serializable>) in;
            Object personRefObj = params.get(WorkflowModel.ASSOC_ASSIGNEE);
            ArrayList<NodeRef> personRefList = null;
            if (personRefObj instanceof ArrayList)
                personRefList = (ArrayList) personRefObj;
            else if (personRefObj instanceof NodeRef)
            {
                personRefList = new ArrayList<NodeRef>();
                personRefList.add((NodeRef) personRefObj);
            }
            else if (personRefObj != null)
            {
                Logger.getRootLogger()
                            .fatal(
                                "Received an object of type "
                                        + personRefObj.getClass()
                                        + " from a workflow's Assignee field. AssigneeWorkflowExtractor doesn't know how to handle it. Skipping auditing.");
                return "Assignee Unknown";
            }

            ArrayList obj = (ArrayList) params.get(WorkflowModel.PROP_TASK_ID);
            if (obj != null && obj.size() > 0)
            {
                NodeRef objRef = (NodeRef) obj.get(0);
                String taskId = objRef.getId();
                logger.debug("taskId: " + taskId);
            }
            logger.debug("[AssigneeWorkflowExtractor] - ArrayList : " + personRefList);
            if (personRefList != null && personRefList.size() > 0)
            {
                NodeRef personRef = personRefList.get(0);
                assigneeName = nodeService.getProperty(personRef, ContentModel.PROP_USERNAME);
                logger.debug("[AssigneeWorkflowExtractor] - Assignee Name: " + assigneeName);
            }
        }
        catch (Exception e)
        {
            logger.error(e);
            throw e;
        }
        return assigneeName;
    }

    private NodeService nodeService;

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }
}
