/**
 * Class is used to get all Published documents audit info 
 * 
 * @author mkatnam
 *
 */
package com.cisco.edcsng.audit.bireports.publish;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.write.WritableCell;
import jxl.write.WritableCellFormat;
import jxl.write.DateFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.cmr.repository.InvalidStoreRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.PermissionService;
import org.apache.log4j.Logger;
//import org.hibernate.SessionFactory;
import org.apache.ibatis.session.SqlSessionFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.edcsng.audit.bireports.utils.BIReportConstants;
import com.cisco.edcsng.audit.bireports.utils.BIReportsAuditMap;
import com.cisco.edcsng.audit.bireports.utils.BIReportsUtil;
import com.cisco.edcsng.audit.bireports.utils.GenericQueryUtil;

public class PublishDocumentsInfo extends AbstractWebScript implements BIReportConstants{
	
	private static final Logger logger 	= Logger.getLogger(PublishDocumentsInfo.class);
	BIReportsUtil biReportsUtil 		= null;

	private NodeService nodeService;
	private PermissionService permissionService;
	private Properties globalProperties;
	//private SessionFactory localFactory;
	private SqlSessionFactory localFactory;
	 
	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public void setGlobalProperties(Properties globalProperties) {
		this.globalProperties = globalProperties;
	}

/*	public SessionFactory getLocalFactory()
	{
	   return localFactory;
	}

	public void setLocalFactory(SessionFactory localFactory)
	{
		this.localFactory = localFactory;
	}*/
	
	public SqlSessionFactory getLocalFactory() {
		return localFactory;
	}

	public void setLocalFactory(SqlSessionFactory localFactory) {
		this.localFactory = localFactory;
	}	

	/* (non-Javadoc)
	 * @see org.springframework.extensions.webscripts.WebScript#execute(org.springframework.extensions.webscripts.WebScriptRequest, org.springframework.extensions.webscripts.WebScriptResponse)
	 */
	public void execute(WebScriptRequest req, WebScriptResponse res){
		logger.info(" Execution started in PublishDocumentsInfo method");
		
		List<BIReportsAuditMap> publishInfo = null;
		Map<String, Object> auditMap 		= null;
		String userID 						= null;
		String reportType 					= null;
		NodeRef processNode 				= null;
		String bIncludeVersions 			= null;
		String folderPath 					= null;
		String dStart 						= null;
		String dEnd 						= null;
		String queryLimit 					= null;
		 
	        try{
	        	biReportsUtil 		= new BIReportsUtil();
				auditMap 			= new HashMap<String, Object>();
				Content content 	= req.getContent();
				
				if (content == null) {
					throw new WebScriptException(Status.STATUS_BAD_REQUEST,"Missing POST body.");
				}
				
				JSONObject json = new JSONObject(content.getContent());
	
				dStart 				= json.getString("dateStart");
				dEnd 				= json.getString("dateEnd");
				if(json.has("userIDs") && BIReportsUtil.valueNotNull(json.getString("userIDs"))){
					 userID = json.getString("userIDs");
				}
				if(json.has("nodeId") && BIReportsUtil.valueNotNull(json.getString("nodeId"))){
					processNode   = new NodeRef(json.getString("nodeId"));
				}
				logger.info(" folderNodeRef:"+processNode);
				
				if(json.has("includeVersions") && BIReportsUtil.valueNotNull(json.getString("includeVersions"))){
					bIncludeVersions = json.getString("includeVersions");
				}else{
					bIncludeVersions = "false";
				}
				if(json.has("format") && BIReportsUtil.valueNotNull(json.getString("format"))){
					reportType = json.getString("format");
				}
				logger.info("Report Type ===>>"+reportType );
				
				if (dStart == null || dStart.length() == 0) {
					throw new WebScriptException(HttpServletResponse.SC_BAD_REQUEST,"Start Date not specified");
				}
				if (dEnd == null) {
					throw new WebScriptException(HttpServletResponse.SC_BAD_REQUEST,"End Date not specified");
				}
		        if(processNode != null){
			        String nodeName 	= (String)nodeService.getProperty(processNode, ContentModel.PROP_NAME);
			        folderPath 		= nodeService.getPath(processNode).toDisplayPath(nodeService, permissionService)+"/"+nodeName;
			        logger.info(" Folder Path:"+folderPath);
			         
		        }
		        
		        queryLimit = globalProperties.getProperty("audit.results.limit");
		        
				auditMap.put("dStart", dStart);
				auditMap.put("dEnd", dEnd);
				auditMap.put("users", userID);
				auditMap.put("bIncludeVersions", bIncludeVersions);
				auditMap.put("folderPath", folderPath);
				auditMap.put("reportType", reportType);
				auditMap.put("limit", queryLimit);
		         
		        publishInfo = GenericQueryUtil.reportList(auditMap, localFactory, "publishReport");
				
				if(publishInfo != null && publishInfo.size() > 0)
					Collections.sort(publishInfo,BIReportsUtil.auditDateComparator);
				
				 if(reportType != null && reportType.equalsIgnoreCase("json")){
					 logger.info(" JSON format is calling ......");
		            	getJSONReport(publishInfo,res,dStart,dEnd);
		            }else{
		            	logger.info(" XLS format is calling ......");
						getPublishedDocsReport(publishInfo, res, dStart, dEnd);
		            }
				
			}catch(WebScriptException e){
	        	e.printStackTrace() ;      	
	        }  catch (JSONException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InvalidStoreRefException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
    
	/** Returning results in JSON object
	 * @param downloadList
	 * @param response
	 * @param dStart
	 * @param dEnd
	 */
	public void getJSONReport(List<BIReportsAuditMap> PublishInfoList, WebScriptResponse response, String dStart, String dEnd) {
		
		logger.info("inside the getDownloadreport.....");

		try {
			JSONArray jsonArray = new JSONArray();
			JSONObject jsonObj = null;
			Map<String,Object> propValues = null;
			
			if (PublishInfoList != null && PublishInfoList.size() > 0) {
				for (BIReportsAuditMap extDoc : PublishInfoList) {
					if (extDoc != null) {
						if(extDoc.getEdcsId() != null && extDoc.getEdcsId().trim().length() > 0
								&& extDoc.getSecurityClassification() != null && extDoc.getSecurityClassification().trim().length() > 0){
							propValues = BIReportsUtil.getPropValues(extDoc.getPropKeyValue());
							jsonObj = new JSONObject();
							jsonObj.put(DocTitle, extDoc.getFileName());
							jsonObj.put(DocId, extDoc.getEdcsId());
							jsonObj.put(Security, extDoc.getSecurityClassification());
							String folderPath = extDoc.getFolderPath();
							if(folderPath.contains(DISPLAY_EXTERNAL_PATH)){
								folderPath = folderPath.substring(DISPLAY_EXTERNAL_PATH.length(), folderPath.length());
							}
							String auditTime = formatter2.format(extDoc.getAuditTime());
							jsonObj.put(FolderPath, folderPath);
							jsonObj.put(PublishedDate, auditTime);
							jsonObj.put(Publisher, extDoc.getUserId());
							jsonObj.put(Description, extDoc.getDescription());
							jsonObj.put(LastModifiedBy, extDoc.getUserId());
							jsonObj.put(ModifiedDate, auditTime);
							if(propValues != null){
								String size =  (String)propValues.get("contentSize");
                    			String contentSize ="";
                    			if(size != null){
                    				contentSize = biReportsUtil.formatFileSize(Long.parseLong(size));
                    			}
                    			jsonObj.put(ContentSize, contentSize);
								if((String)propValues.get("publishExpirationDate") != null)
								jsonObj.put(ExpiryDate, formatter2.format(formatter3.parse((String)propValues.get("publishExpirationDate"))));
								jsonObj.put(ExtPublishedUsers, (String)propValues.get("externalUsers"));
								jsonObj.put(DocumentStatus, (String)propValues.get("status"));
								jsonObj.put(WorkflowStatus, (String)propValues.get("workflowStatus"));
							}
							
							jsonArray.put(jsonObj);
						}
					}
	
				}
			}
	
			response.setContentType("application/json");
			response.setContentEncoding("UTF-8");
			response.getWriter().write(jsonArray.toString());
			
		} catch (Exception e) {
			logger.info("Exception : " + e);
			e.printStackTrace();
		}
	}
	
	 public void getPublishedDocsReport(final List<BIReportsAuditMap> publishedList, final WebScriptResponse response, final String dStart, final String dEnd)
	    {logger.info("inside the getDownloadreport.....");
	    
	    final WritableCellFormat EXCEL_DATE_FORMATTER = new WritableCellFormat(new DateFormat("MM/dd/yyyy hh:mm:ss"));
        AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
                {
                    @Override
                    public Object doWork() throws Exception
                    {
                    	 // creating workbook
                        WritableWorkbook workbook = null;
                        String reportHeading = "Published Documents Audit data from "+dStart+" to "+dEnd;
                        String noDataFound = " No Audit data found";
                        try
                        {
                            OutputStream os = response.getOutputStream();
                            workbook = Workbook.createWorkbook(os);

                            // creating sheets in the workbook
                            WritableSheet wSheet1 = workbook.createSheet("Published Documents Report", 0);
                            wSheet1.setColumnView(0, 20);
                            wSheet1.setColumnView(1, 20);
                            wSheet1.setRowView(0, 800);
                            biReportsUtil.addHeading(wSheet1, 0, 0, reportHeading);
                            wSheet1.mergeCells(0, 0, 13, 0);

                            biReportsUtil.createLabel(wSheet1, DocTitle, 0);
                            biReportsUtil.createLabel(wSheet1, DocId, 1);
                            biReportsUtil.createLabel(wSheet1, Security, 2);
                            biReportsUtil.createLabel(wSheet1, FolderPath, 3);
                            biReportsUtil.createLabel(wSheet1, "Expiry Date (GMT)", 4);
                            biReportsUtil.createLabel(wSheet1, PublishedDate, 5);
                            biReportsUtil.createLabel(wSheet1, Publisher, 6);
                            biReportsUtil.createLabel(wSheet1, ExtPublishedUsers, 7);
                            biReportsUtil.createLabel(wSheet1, Description, 8);
                            biReportsUtil.createLabel(wSheet1, ContentSize, 9);
                            biReportsUtil.createLabel(wSheet1, LastModifiedBy, 10);
                            biReportsUtil.createLabel(wSheet1, ModifiedDate, 11);
                            biReportsUtil.createLabel(wSheet1, DocumentStatus, 12);
                            biReportsUtil.createLabel(wSheet1, WorkflowStatus, 13);

                            Map<String,Object> propValues = null;
                            int rowNumber = 2;
                            wSheet1. setColumnView(4, 20);
                            wSheet1. setColumnView(5, 20);
                            if(publishedList != null && publishedList.size() > 0){
                            	for (BIReportsAuditMap extDoc : publishedList)	{
                            		if (extDoc != null)
                            		{
                            			if(extDoc.getEdcsId() != null && extDoc.getEdcsId().trim().length() > 0
                								&& extDoc.getSecurityClassification() != null && extDoc.getSecurityClassification().trim().length() > 0
                								&& !extDoc.getUserId().equalsIgnoreCase("ciscoadmin.gen")){
	                            			propValues = BIReportsUtil.getPropValues(extDoc.getPropKeyValue());
	                            			biReportsUtil.addLabel(wSheet1, 0, rowNumber, extDoc.getFileName());
	                            			biReportsUtil.addLabel(wSheet1, 1, rowNumber, extDoc.getEdcsId());
	                            			biReportsUtil.addLabel(wSheet1, 2, rowNumber, extDoc.getSecurityClassification());
	                            			String folderPath = extDoc.getFolderPath();
	                						if(folderPath.contains(DISPLAY_EXTERNAL_PATH)){
	                							folderPath = folderPath.substring(DISPLAY_EXTERNAL_PATH.length(), folderPath.length());
	                						}
	                            			biReportsUtil.addLabel(wSheet1, 3, rowNumber, folderPath);
	                            			String auditTime = formatter2.format(extDoc.getAuditTime());
	                            			
	                            			//uthra -  sorting publishDate manually through excel
	                                        
	                            			Date date = formatter4.parse(auditTime);
	                                        WritableCell cell = new jxl.write.DateTime(5, rowNumber, date); //2015/09/07 04:06:48
	                                        cell.setCellFormat(EXCEL_DATE_FORMATTER);
	                                        wSheet1.addCell(cell);
	                                        
	                                      //uthra - sorting publishDate manually through excel
	                            			biReportsUtil.addLabel(wSheet1, 6, rowNumber, extDoc.getUserId());
	                            			biReportsUtil.addLabel(wSheet1, 8, rowNumber, extDoc.getDescription());
	                            			biReportsUtil.addLabel(wSheet1, 10, rowNumber, extDoc.getUserId());
	                            			biReportsUtil.addLabel(wSheet1, 11, rowNumber, auditTime);
	                            			if(propValues != null){
	                            				if((String)propValues.get("publishExpirationDate") != null) {
	                            					Date expDate = formatter4.parse(formatter2.format(formatter3.parse((String)propValues.get("publishExpirationDate"))));
	                            					 WritableCell cell2 = new jxl.write.DateTime(4, rowNumber, expDate);
	                            					 cell2.setCellFormat(EXCEL_DATE_FORMATTER);
	     	                                        wSheet1.addCell(cell2);
	                            				}
		                            			biReportsUtil.addLabel(wSheet1, 7, rowNumber, (String)propValues.get("externalUsers"));
		                            			String size =  (String)propValues.get("contentSize");
		                            			String contentSize ="";
		                            			if(BIReportsUtil.valueNotNull(size)){
		                            				contentSize = biReportsUtil.formatFileSize(Long.parseLong(size));
		                            			}
		                            			biReportsUtil.addLabel(wSheet1, 9, rowNumber,contentSize);
		                            			biReportsUtil.addLabel(wSheet1, 12, rowNumber,(String)propValues.get("status"));
		                            			biReportsUtil.addLabel(wSheet1, 13, rowNumber, (String)propValues.get("workflowStatus"));
	                            			}
		            	            	    rowNumber++;
	                            		}
                            		}
                            		
                            	}
                            }else{
                            	biReportsUtil.addHeading(wSheet1, 0, 2, noDataFound);
                            }
                            workbook.write();
                            workbook.close();
                            logger.info("..Successfully " + rowNumber + " Records created. ");

                            response.addHeader("Content-Disposition", "attachment;filename=Publish-AuditReport.xls");
                            response.setContentType("application/vnd.ms-excel");
                            response.setContentEncoding("UTF-8");
                            response.setHeader("Cache-Control", "private, max-age=0");
                            logger.info("Excel File Downloaded Successfully...");
                        }
                        catch (Exception e)
                        {
                            logger.info("Exception : " + e);
                            e.printStackTrace();
                        }
                        return null;
                    }

                }, "admin");
        }
}
