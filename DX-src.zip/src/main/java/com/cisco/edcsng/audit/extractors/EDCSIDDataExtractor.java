
package com.cisco.edcsng.audit.extractors;

import java.io.Serializable;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.extractor.AbstractDataExtractor;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.PropertyCheck;

/**
 * An extractor that pulls out the {@link ContentModel#PROP_DESCRIPTION <b>cm:name</b>} property from a node.
 * 
 
 */
public class EDCSIDDataExtractor extends AbstractDataExtractor
{
    private NodeService nodeService;
    
    /**
     * Set the service to get the property from
     */
    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    @Override
    public void afterPropertiesSet() throws Exception
    {
        super.afterPropertiesSet();
        PropertyCheck.mandatory(this, "nodeService", nodeService);
    }

    /**
     * @return          Returns <tt>true</tt> if the data is a {@link NodeRef}
     */
    public boolean isSupported(Serializable data)
    {
        return (data != null && data instanceof NodeRef);
    }

    /**
     * Gets the <b>cs:name</b> property from the node
     */
    public Serializable extractData(Serializable in) throws Throwable
    {
        NodeRef nodeRef = (NodeRef) in;
        String edcsId = null;
        final String CISCO_MODEL_URI = "http://www.cisco.com/model/content/1.0";
        final QName CISCO_EDCSID_PROP = QName.createQName(CISCO_MODEL_URI, "alf_id");
        if (!nodeService.exists(nodeRef))
        {
            if (logger.isDebugEnabled())
            {
                logger.debug("Extractor can't pull value from non-existent node: " + nodeRef);
            }
        }
        else
        {
        	edcsId = (String) nodeService.getProperty(nodeRef, CISCO_EDCSID_PROP);
        }
        
        if(edcsId == null){
        	edcsId ="";
        	
        }
        return edcsId;
    }
}
