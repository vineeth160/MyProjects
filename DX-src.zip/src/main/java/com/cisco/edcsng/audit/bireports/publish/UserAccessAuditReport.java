package com.cisco.edcsng.audit.bireports.publish;

import java.io.OutputStream;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

import org.activiti.engine.impl.util.json.JSONException;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.cmr.audit.AuditQueryParameters;
import org.alfresco.service.cmr.audit.AuditService;
import org.alfresco.service.cmr.audit.AuditService.AuditQueryCallback;
import org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter;
import org.alfresco.service.cmr.repository.datatype.TypeConversionException;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.external.common.model.ExtDocument;
import com.cisco.edcsng.audit.bireports.utils.BIReportConstants;
import com.cisco.edcsng.audit.bireports.utils.BIReportsUtil;
import com.ibm.icu.util.Calendar;

/**
 * @param mkatnam
 */

public class UserAccessAuditReport extends AbstractWebScript implements BIReportConstants
{
    private Logger _logger = Logger.getLogger(UserAccessAuditReport.class);

    private AuditService auditService;
    private Properties globalProperties;
    
    BIReportsUtil biReportUtil 			= null;
    
	public void setAuditService(AuditService auditService)
    {
        this.auditService = auditService;
    }
	public void setGlobalProperties(Properties globalProperties) {
		this.globalProperties = globalProperties;
	}
    
	/* (non-Javadoc)
	 * @see org.springframework.extensions.webscripts.WebScript#execute(org.springframework.extensions.webscripts.WebScriptRequest, org.springframework.extensions.webscripts.WebScriptResponse)
	 */
	public void execute(WebScriptRequest req, WebScriptResponse res){
        _logger.info("Start Admin-Download Report's......");
        final String users[];
        biReportUtil 		= new BIReportsUtil();
        Date startDate 		= null;
        Date endDate 		= null;
        String userID 		= null;
        String[] usersList 	= null;
        List<ExtDocument> userInfo = null;
        final List<Map<String, Object>> entries 	= new ArrayList<Map<String, Object>>();
        try
        {
        	
            Content content = req.getContent();
            if (content == null)
            {
                throw new WebScriptException(Status.STATUS_BAD_REQUEST, "Missing POST body.");
            }

            // extract username and password from JSON object
            JSONObject json;
            String dStart, dEnd;
            String jsonFormat = null;
             try {
            	json = new JSONObject(content.getContent());

                dStart 				= json.getString("dateStart");
				dEnd 				= json.getString("dateEnd");
				//userID 				= json.getString("userIDs");
				
				if(json.has("userIDs") && BIReportsUtil.valueNotNull(json.getString("userIDs"))){
					 userID = json.getString("userIDs");
				}
				if(json.has("format") && BIReportsUtil.valueNotNull(json.getString("format"))){
					jsonFormat = json.getString("format");
				}
            	 
				/*if(json.getString("format")!= null){
					jsonFormat = json.getString("format");
				}*/
				_logger.info("jsonFormat ===>>"+jsonFormat );
				
                if (dStart == null || dStart.length() == 0)
                {
                    throw new WebScriptException(HttpServletResponse.SC_BAD_REQUEST, "Start Date not specified");
                }
                if (dEnd == null)
                {
                    throw new WebScriptException(HttpServletResponse.SC_BAD_REQUEST, "End Date not specified");
                }
            }
            catch (JSONException jErr)
            {
                throw new WebScriptException(Status.STATUS_BAD_REQUEST, "Unable to parse JSON POST body: "
                        + jErr.getMessage());
            }
            _logger.info("---------startDate ::: " + dStart + " endDate : : :" + dEnd + " userIDs :::" + userID);

            startDate = formatter.parse(dStart);
            endDate = formatter.parse(dEnd);

            Calendar calInstance = Calendar.getInstance();
            calInstance.setTime(startDate);
            
            _logger.info("Start Date Time: 1 "+calInstance.getTime()); 
            
            final Long fromTime = calInstance.getTimeInMillis();
            calInstance.setTime(endDate);
            
            _logger.info("End Date Time: 2 "+calInstance.getTime());
            
            calInstance.add(Calendar.DATE, 1);
            
            _logger.info("End Date Time: 3 "+calInstance.getTime());
            
            final Long toTime = calInstance.getTimeInMillis();
            
            _logger.info("---------startDate ::: " + startDate + " endDate : : :" + endDate + " userIDs :::" + userID);
            
			if(userID != null && userID.length() > 0)
            usersList = userID.split(",");
			
			if(usersList != null && usersList.length > 0){
				users = usersList;
			}else{
				users = null;
			}
            
            AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>(){
                @Override
                public Object doWork() throws Exception{
                	if(users != null && users.length > 0){
	                    for ( String user : users){
	                    	getUserAccessAuditQuery(fromTime, toTime, user,SEARCH_KEY_ACCESS_USER,entries);
	                    	 _logger.info("entries Size :"+entries.size());
	                    }
                	}else{
                		getUserAccessAuditQuery( fromTime, toTime, null,SEARCH_KEY_ACCESS_USER,entries);
                	}
                    return null;
                }

            }, "admin");
            
            userInfo = getUserBOList(entries);
            
            if(userInfo != null && userInfo.size() >0)
	            Collections.sort(userInfo, accessedDateComparator);
            
            if(jsonFormat != null && jsonFormat.equalsIgnoreCase("json")){
            	_logger.info(" JSON format is calling ......");
            	getJSONReport(userInfo,res,dStart,dEnd);
            }else{
            	_logger.info(" XLS format is calling....");
	            getUserAccessReport(userInfo,res,dStart,dEnd);
            } 
        }
        catch (ParseException pe){
        	pe.printStackTrace();
            _logger.info("Exception" + pe);
        }
        catch (Exception ex){
        	ex.printStackTrace();
            _logger.error("Exception......." + ex);
        }
    }

    /**
     * @param fromTime
     * @param toTime
     * @param user
     * @param searchKey
     * @param entries 
     */
    private void getUserAccessAuditQuery(Long fromTime, Long toTime, String user, String searchKey, final List<Map<String, Object>> entries ){

    	int limit = 0;
    	String queryLimit = globalProperties.getProperty("audit.results.limit");
    	if(queryLimit != null){
    		limit = Integer.parseInt(queryLimit);
    	}
        final boolean verbose = true;
        _logger.info(" getUserAuditQuery started");
        // Execute the query
        AuditQueryParameters params = new AuditQueryParameters();
        params.setApplicationName(USER_ACCESS_APP_NAME); 
        params.setFromTime(fromTime);
        params.setToTime(toTime);
        params.setForward(false);
        if(user!= null){
        	params.addSearchKey(searchKey, user);
        }
        AuditQueryCallback callback = new AuditQueryCallback()
        {
        	
            @Override
            public boolean valuesRequired()
            {
                return verbose;
            }

            @Override
            public boolean handleAuditEntryError(Long entryId, String errorMsg, Throwable error)
            {
                return true;
            }

            @Override
            public boolean handleAuditEntry(Long entryId, String applicationName, String user, long time,
                    Map<String, Serializable> values)
            {
            	_logger.info(" Handle query started");
                Map<String, Object> entry = new HashMap<String, Object>(11);
                entry.put(JSON_KEY_ENTRY_ID, entryId);
                entry.put(JSON_KEY_ENTRY_APPLICATION, applicationName);

                if (user != null)
                {
                    entry.put(JSON_KEY_ENTRY_USER, user);
                }
                entry.put(JSON_KEY_ENTRY_TIME, new Date(time));

                if (values != null)
                {
                    // Convert values to Strings
                    Map<String, String> valueStrings = new HashMap<String, String>(values.size() * 2);
                    for (Map.Entry<String, Serializable> mapEntry : values.entrySet())
                    {
                        String key = mapEntry.getKey();
                        Serializable value = mapEntry.getValue();
                        try
                        {
                            String valueString = DefaultTypeConverter.INSTANCE.convert(String.class, value);
                            valueStrings.put(key, valueString);
                        }
                        catch (TypeConversionException e)
                        {
                            // Use the toString()
                            valueStrings.put(key, value.toString());
                        }
                    }
                    entry.put(JSON_KEY_ENTRY_VALUES, valueStrings);
                }
                entries.add(entry);
                entry = null;
                return true;
            }
           
        };

        // Make an audit call to applicationName
        auditService.auditQuery(callback, params, limit);

    }

    @SuppressWarnings("unchecked")
    private List<ExtDocument> getUserBOList(List<Map<String, Object>> entries)

    {
    	ExtDocument extDoc 				= null;
    	List<ExtDocument> userRecBoList = null;
    	_logger.info("getUserBOList started" );
        try{
        if(entries != null && entries.size() > 0){
        	userRecBoList = new ArrayList<ExtDocument>();
            for (Map<String, Object> entryMap : entries)
            {
            	extDoc = new ExtDocument();
                Map<String, String> valuesMap = (Map<String, String>) entryMap.get(JSON_KEY_ENTRY_VALUES);
	
						if (entryMap.get("time") != null) {
							extDoc.setModifieddate(entryMap.get("time").toString());
	
						}
						if (valuesMap != null) {
							if(valuesMap.get("/user-access/details/username") != null){
								extDoc.setName(valuesMap.get("/user-access/details/username"));
							}
							if(valuesMap.get("/user-access/details/accesstype") != null){
								extDoc.setType(valuesMap.get("/user-access/details/accesstype"));
							}
							if(valuesMap.get("/user-access/details/company") != null){
								extDoc.setCompany(valuesMap.get("/user-access/details/company"));
							}
							
						}
						userRecBoList.add(extDoc);
            	}
        }
        
    }catch(WebScriptException e){
    	_logger.error("Exception occured while processing the object List  and error is :", e);
    }
		return userRecBoList;
    }
    
    /** Returning results in JSON object
	 * @param downloadList
	 * @param response
	 * @param dStart
	 * @param dEnd
	 */
	public void getJSONReport(List<ExtDocument> userInfoList, WebScriptResponse response, String dStart, String dEnd) {

		_logger.info("inside the getDownloadreport.....");

		try {
			JSONArray jsonArray = new JSONArray();

			JSONObject jsonObj = null;
			
			if (userInfoList != null && userInfoList.size() > 0) {
				for (ExtDocument extDoc : userInfoList) {
					if (extDoc != null) {
						jsonObj = new JSONObject();

						jsonObj.put(CompanyName, extDoc.getCompany());
						jsonObj.put(UserID, extDoc.getName());
						jsonObj.put(AccessType, extDoc.getType());
						jsonObj.put(AccessedTime, extDoc.getModifieddate());

						jsonArray.put(jsonObj);
					}

				}
			}

			response.setContentType("application/json");
			response.getWriter().write(jsonArray.toString());
			
		} catch (Exception e) {
			_logger.info("Exception : " + e);
			e.printStackTrace();
		}

	}
    
    public void getUserAccessReport(final List<ExtDocument> UserList, final WebScriptResponse response, final String dStart, final String dEnd)
    {
        _logger.info("inside the getUserreport.....");
        AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
                {
                    @Override
                    public Object doWork() throws Exception
                    {
                    	 // creating workbook
                        WritableWorkbook workbook = null;
                        Map<String, String> userMap = null;
                       
                        try{
                            OutputStream os = response.getOutputStream();
                            workbook = Workbook.createWorkbook(os);

                            // creating sheets in the workbook
                            WritableSheet wSheet1 = workbook.createSheet("User Access Audit Report", 0);
                            WritableSheet wSheet2 = workbook.createSheet("Consolidated Audit Report", 1);
                            
                            userMap = createSheet1(wSheet1,UserList,dStart,dEnd);
                            if(userMap != null && userMap.size() > 0){
                            	createSheet2(wSheet2,userMap,dStart,dEnd);
                        	}	
                            workbook.write();
                            workbook.close();
                            
                            response.addHeader("Content-Disposition", "attachment;filename=Audit-UserAccessReport.xls");
                            response.setContentType("application/vnd.ms-excel");
                            response.setHeader("Cache-Control", "private, max-age=0");
                            _logger.info("Excel File Downloaded Successfully...");
                        }
                        catch (Exception e)
                        {
                            _logger.info("Exception : " + e);
                            e.printStackTrace();
                        }
                        return null;
                    }


                }, "admin");
       
    }
    
    public Map<String, String> createSheet1(WritableSheet wSheet1, List<ExtDocument> userList, String dStart, String dEnd) throws WriteException {
    	Map<String, String> userMap = new TreeMap<String,String>();
    	 String reportHeading = "User Access Audit data from "+dStart+" to "+dEnd;
    	 biReportUtil.createHeading(wSheet1, reportHeading);

    	 biReportUtil.createLabel(wSheet1, CompanyName, 0);
    	 biReportUtil.createLabel(wSheet1, UserID, 1);
    	 biReportUtil.createLabel(wSheet1, AccessType, 2);
    	 biReportUtil.createLabel(wSheet1, AccessedTime, 3);
    	int rowNumber = 2;
        	if(userList != null && userList.size() > 0){
            	for (ExtDocument extDoc : userList)	{
            		if (extDoc != null)
            		{
            			biReportUtil.addLabel(wSheet1, 0, rowNumber, extDoc.getCompany());
                        biReportUtil.addLabel(wSheet1, 1, rowNumber, extDoc.getName());
                        biReportUtil.addLabel(wSheet1, 2, rowNumber, extDoc.getType());
                        biReportUtil.addLabel(wSheet1, 3, rowNumber, extDoc.getModifieddate());
                        
                        userMap.put(extDoc.getName(), extDoc.getCompany());
            		}
            		rowNumber++;
            	}
            }else{
            	biReportUtil.addHeading(wSheet1, 0, 2, " No Audit data found");
            }
        	
        	_logger.info("..Successfully " + rowNumber + " Records created. ");
		return userMap;
	}
    
    public void createSheet2(WritableSheet wSheet2,	Map<String, String> userMap, String dStart, String dEnd) throws WriteException {String reportHeading2 = "Total No.of Unique User ID's  from "+dStart+" to "+dEnd + ": "+userMap.size();
    biReportUtil.createHeading(wSheet2,reportHeading2);

    String col21Name = "Unique User ID's";
    biReportUtil.createLabel(wSheet2, col21Name, 0);
    
    String col22Name = "Company Name";
    biReportUtil.createLabel(wSheet2, col22Name, 1);
    
   int rowNumber = 2;
	if(userMap != null && userMap.size() > 0){
    	for (Map.Entry<String, String> entry : userMap.entrySet())
    	{
    		if(entry != null){
    			biReportUtil.addLabel(wSheet2, 0, rowNumber, entry.getKey());
        	    biReportUtil.addLabel(wSheet2, 1, rowNumber, entry.getValue());
    		}
    		rowNumber++;
    	}
    }else{
    	biReportUtil.addHeading(wSheet2, 0, 2, " No Audit data found");
    }
	}
	
    
    /*Comparator for sorting the list by Downloaded date*/
    public static Comparator<ExtDocument> accessedDateComparator = new Comparator<ExtDocument>() {
    SimpleDateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
	public int compare(ExtDocument extDoc1, ExtDocument extDoc2) {
	   int result = 0;
	   try {
			result =  formatter.parse(extDoc1.getModifieddate()).compareTo(formatter.parse(extDoc2.getModifieddate()));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return result;
    }
	};
}