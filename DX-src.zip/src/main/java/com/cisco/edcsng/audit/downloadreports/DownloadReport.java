package com.cisco.edcsng.audit.downloadreports;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import jxl.CellView;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.cmr.audit.AuditQueryParameters;
import org.alfresco.service.cmr.audit.AuditService;
import org.alfresco.service.cmr.audit.AuditService.AuditQueryCallback;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter;
import org.alfresco.service.cmr.repository.datatype.TypeConversionException;
import org.alfresco.service.cmr.security.PersonService;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.ibm.icu.util.Calendar;

/**
 * @param spathi
 */

public class DownloadReport extends AbstractWebScript
{

    private Logger _logger = Logger.getLogger(DownloadReport.class);
    private WritableCellFormat times;
    private WritableCellFormat timesBoldUnderline;
    private WritableCellFormat timesHeading;
    private Properties globalProperties;

    private static final String JSON_KEY_ENTRY_COUNT = "count";
    private static final String JSON_KEY_ENTRIES = "entries";
    private static final String JSON_KEY_ENTRY_ID = "id";
    private static final String JSON_KEY_ENTRY_APPLICATION = "application";
    private static final String JSON_KEY_ENTRY_USER = "user";
    private static final String JSON_KEY_ENTRY_TIME = "time";
    private static final String JSON_KEY_ENTRY_VALUES = "values";

    private AuditService auditService;
    private PersonService personService;
    private NodeService nodeService;
    
    

    public NodeService getNodeService() {
		return nodeService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public PersonService getPersonService() {
		return personService;
	}

	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}

    public void execute(WebScriptRequest req, WebScriptResponse res)
    {
        _logger.info("Start MyDownload Report's...........");

        try
        {
            String limitDays = null;
            Calendar calInstance = Calendar.getInstance();
            final Long toTime = calInstance.getTimeInMillis();
            boolean isInternalUser;
            String email	= null;

            limitDays = (String) globalProperties.get("cisco.download.report.limit.days");
            _logger.info("Report from the Last : " + limitDays + " Dayz..");
            int days = 0;
            if (limitDays != null)
            {
                days = Integer.valueOf(limitDays);
            } else {
            	days = 90;
            }
            calInstance.add(Calendar.DATE, -days);
            final Long fromTime = calInstance.getTimeInMillis();
            _logger.info("fromTime:"+fromTime+",toTime:"+toTime);

            final String loggeduser = AuthenticationUtil.getRunAsUser();
            NodeRef person = personService.getPerson(loggeduser);
            email = (String) nodeService.getProperty(person, ContentModel.PROP_EMAIL);
            
            if( email != null && email.indexOf("@cisco.com") == -1) {
            	isInternalUser = false;
            } else {
            	isInternalUser = true;
            }
            // -------------------------------------------------------------------------------------------
            final Map<String, Object> auditDownloadRefMap = new HashMap<String, Object>();
            AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
            {
                @Override
                public Object doWork() throws Exception
                {
                    getDownloadAuditQuery(auditDownloadRefMap, fromTime, toTime, loggeduser);

                    return null;
                }

            }, "admin");

            getDownloadReport(getDownloadBOList(auditDownloadRefMap, loggeduser,isInternalUser), res);

        }
        catch (Exception ex)
        {
            System.out.println("Exception" + ex);
            ex.printStackTrace();
        }
    }

    /**
     * 
     * @param loggeduser 
     * @param applicationName
     * @return
     */
    private Map<String, Object> getDownloadAuditQuery(Map<String, Object> model, Long fromTime, Long toTime, String loggeduser)
    {

        // final Map<String, Object> model = new HashMap<String, Object>(7);

        int limit = 0;
        final boolean verbose = true;

        // Execute the query
        AuditQueryParameters params = new AuditQueryParameters();
        params.setApplicationName("download-report"); // "download-report"
        params.setFromTime(fromTime);
        params.setToTime(toTime);
        params.addSearchKey("/download-report/document/creator", loggeduser);

        final List<Map<String, Object>> entries = new ArrayList<Map<String, Object>>(limit);
        AuditQueryCallback callback = new AuditQueryCallback()
        {
            @Override
            public boolean valuesRequired()
            {
                return verbose;
            }

            @Override
            public boolean handleAuditEntryError(Long entryId, String errorMsg, Throwable error)
            {
                return true;
            }

            @Override
            public boolean handleAuditEntry(Long entryId, String applicationName, String user, long time,
                    Map<String, Serializable> values)
            {

                Map<String, Object> entry = new HashMap<String, Object>(11);
                entry.put(JSON_KEY_ENTRY_ID, entryId);
                entry.put(JSON_KEY_ENTRY_APPLICATION, applicationName);

                if (user != null)
                {
                    entry.put(JSON_KEY_ENTRY_USER, user);
                }
                entry.put(JSON_KEY_ENTRY_TIME, new Date(time));

                if (values != null)
                {
                    // Convert values to Strings
                    Map<String, String> valueStrings = new HashMap<String, String>(values.size() * 2);
                    for (Map.Entry<String, Serializable> mapEntry : values.entrySet())
                    {
                        String key = mapEntry.getKey();
                        Serializable value = mapEntry.getValue();
                        try
                        {
                            String valueString = DefaultTypeConverter.INSTANCE.convert(String.class, value);
                            valueStrings.put(key, valueString);
                        }
                        catch (TypeConversionException e)
                        {
                            // Use the toString()
                            valueStrings.put(key, value.toString());
                        }

                    }
                    entry.put(JSON_KEY_ENTRY_VALUES, valueStrings);
                }
                entries.add(entry);

                return true;
            }
        };

        // Make an audit call to applicationName
        auditService.auditQuery(callback, params, limit);

        model.put(JSON_KEY_ENTRY_COUNT, entries.size());
        model.put(JSON_KEY_ENTRIES, entries);

        if (_logger.isDebugEnabled())
        {
            _logger.debug("Audit Size : " + entries.size());
        }
        return model;
    }

    @SuppressWarnings("unchecked")
    private List<DownloadBO> getDownloadBOList(Map<String, Object> entriesMap, String loggedUser, boolean isInternalUser)

    {
    	_logger.debug("download list size : " + entriesMap.size());

        DownloadBO bo = null;
        List<DownloadBO> userRecBoList = new ArrayList<DownloadBO>();
        String DISPLAY_EXTERNAL_PATH = "/Company Home/Sites/edcsng/documentLibrary";

        if ((Integer) entriesMap.get(JSON_KEY_ENTRY_COUNT) > 0)
        {
            List<Map<String, Object>> entries = (List<Map<String, Object>>) entriesMap.get(JSON_KEY_ENTRIES);

            /*
             * _logger.info("#######entries"+entries); _logger.info("#########entriesMap"+entriesMap);
             * _logger.info("#####user "+entriesMap.get("user")); _logger.info("#####time "+entriesMap.get("/time"));
             */
            for (Map<String, Object> entryMap : entries)
            {
            	
                
                Map<String, String> valuesMap = (Map<String, String>) entryMap.get(JSON_KEY_ENTRY_VALUES);
                if (valuesMap.get("/download-report/document/edcsid") != null)
                {
                	bo = new DownloadBO();
                	bo.setDownloadedby((String) entryMap.get("user"));
                    bo.setDownloaddate(entryMap.get("time").toString());
                    bo.setEdcsId(valuesMap.get("/download-report/document/edcsid"));

	                if (valuesMap != null
	                        && (valuesMap.get("/download-report/document/creator") != null))
	                {
	                        bo.setCreator(valuesMap.get("/download-report/document/creator"));
	
	                        if (valuesMap.get("/download-report/document/path") != null)
	                        {
	                        	String folderpath = valuesMap.get("/download-report/document/path");
	                        	 try{
	                        		 if (isInternalUser) {
	                        			 folderpath = folderpath.substring(DISPLAY_EXTERNAL_PATH.length(),folderpath.length());
	                        		 } else {
	                        			 folderpath = folderpath.substring(folderpath.lastIndexOf("/"),folderpath.length());
	                        		 }
	                        		 bo.setFolderpath(folderpath);
	                        	    }catch(StringIndexOutOfBoundsException siobe){
	                        	    	 _logger.info("folder path doesn't exist: "+siobe.getMessage());
	                        	    }
	                        }
	
	                        if (valuesMap.get("/download-report/document/modifier") != null)
	                        {
	                            bo.setModifier(valuesMap.get("/download-report/document/modifier"));
	                        }
	
	                        if (valuesMap.get("/download-report/document/docname") != null)
	                        {
	                            bo.setDocname(valuesMap.get("/download-report/document/docname"));
	                        }
	                    
	                }
	                else
	                {
	                    _logger.info("no CREATOR existed for this record ");
	                }

	                if (bo.getDocname() != null)
	                {
	                    _logger.info("#####19 ");
	                    userRecBoList.add(bo);
	                }
                }
            }

        }

        return userRecBoList;
    }

    private void getDownloadReport(List<DownloadBO> bo, WebScriptResponse response)
    {
        _logger.info("inside the getDownloadreport.....");

        // creating workbook
        WritableWorkbook workbook = null;
        //String reportHeading = "Download_REPORT_HEADING";
        String noDataFound = " No Audit data found";
        WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);

        try
        {
            OutputStream os = response.getOutputStream();
            // os.write(arg0)
            workbook = Workbook.createWorkbook(os);

            // creating sheets in the workbook
            WritableSheet wSheet1 = workbook.createSheet("Download Report", 0);
            wSheet1.setColumnView(0, 20);
            wSheet1.setColumnView(1, 20);
            wSheet1.setRowView(0, 800);
            timesHeading = new WritableCellFormat(times10ptBoldUnderline);
            // do not automatically wrap the cells
            timesHeading.setWrap(true);
            //addHeading(wSheet1, 0, 0, reportHeading);
            addHeading(wSheet1, 0, 0, globalProperties.getProperty("cisco.mydocument.download.report"));
            wSheet1.mergeCells(0, 0, 13, 0);

            String col1Name = "Document Name";
            createLabel(wSheet1, col1Name, 0);

            String col2Name = "EDCS ID";
            createLabel(wSheet1, col2Name, 1);

            String col3Name = "Creator";
            createLabel(wSheet1, col3Name, 2);

            String col4Name = "Modifier";
            createLabel(wSheet1, col4Name, 3);

            String col5Name = "Downloaded By";
            createLabel(wSheet1, col5Name, 4);

            String col6Name = "Downloaded Time";
            createLabel(wSheet1, col6Name, 5);

            String col7Name = "Folder Path";
            createLabel(wSheet1, col7Name, 6);

            // Map<String, String> rowMap = null;
            int rowNumber = 2;
            if (bo != null && bo.size() > 0) {
            for (DownloadBO recordKey : bo)
            {
                if (recordKey != null)
                {
                    // checkDocPresent=checkDocPresent+1;
                    addLabel(wSheet1, 0, rowNumber, recordKey.getDocname());
                    addLabel(wSheet1, 1, rowNumber, recordKey.getEdcsId());
                    addLabel(wSheet1, 2, rowNumber, recordKey.getCreator());
                    addLabel(wSheet1, 3, rowNumber, recordKey.getModifier());
                    addLabel(wSheet1, 4, rowNumber, recordKey.getDownloadedby());
                    addLabel(wSheet1, 5, rowNumber, recordKey.getDownloaddate());
                    addLabel(wSheet1, 6, rowNumber, recordKey.getFolderpath());
                }
                rowNumber++;
                // _logger.info("..Successfully " + rowNumber +
                // " Records created. ");
            }
        } else{
        	addHeading(wSheet1, 0, 2, noDataFound);
        }
            workbook.write();
            workbook.close();
            _logger.info("..Successfully " + rowNumber + " Records created. ");
            response.addHeader("Content-Disposition", "attachment;filename=MyDownloadReport.xls");
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Cache-Control", "private, max-age=0");

            _logger.info("Excel File Downloaded Successfully...");
        }
        catch (Exception e)
        {
            _logger.info("Exception : " + e);
            e.printStackTrace();
        }
    }
    
    public void createLabel(WritableSheet sheet, String label, int col) throws WriteException
    {

        WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
        times = new WritableCellFormat(times10pt);
        times.setWrap(false);

        // Create create a bold font
        WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);
        timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
        timesBoldUnderline.setWrap(false);

        CellView cv = new CellView();
        cv.setFormat(times);
        cv.setFormat(timesBoldUnderline);
        // Write a few headers
        addCaption(sheet, col, 1, label);
    }

    public void addCaption(WritableSheet sheet, int column, int row, String s) throws RowsExceededException,
            WriteException
    {
        Label label;
        label = new Label(column, row, s, timesBoldUnderline);
        sheet.addCell(label);
    }

    public void addLabel(WritableSheet sheet, int column, int row, String s) throws WriteException,
            RowsExceededException
    {
        Label label;
        label = new Label(column, row, s, times);
        sheet.addCell(label);
    }

    public void addHeading(WritableSheet sheet, int column, int row, String s) throws WriteException,
            RowsExceededException
    {
        Label label;
        label = new Label(column, row, s, timesHeading);
        sheet.addCell(label);
    }

    private String readAll(BufferedReader rd) throws IOException
    {
        StringBuilder sb = new StringBuilder();
        String aux = "";
        while ((aux = rd.readLine()) != null)
        {
            // System.out.println("**************"+aux);
            sb.append(aux);
        }
        return sb.toString();
    }

    public void setGlobalProperties(Properties globalProperties)
    {
        this.globalProperties = globalProperties;
    }

    public void setAuditService(AuditService auditService)
    {
        this.auditService = auditService;
    }

}