package com.cisco.edcsng.audit.downloadreports;

public class DownloadBO
{

    private String docname = null;
    private String downloadedby = null;
    private String downloaddate = null;
    private String creator = null;
    private String modifier = null;
    private String folderpath = null;
    private String edcsId;

    public String getDownloadedby()
    {
        return downloadedby;
    }

    public void setDownloadedby(String downloadedby)
    {
        this.downloadedby = downloadedby;
    }

    public String getDownloaddate()
    {
        return downloaddate;
    }

    public void setDownloaddate(String downloaddate)
    {
        this.downloaddate = downloaddate;
    }

    public String getCreator()
    {
        return creator;
    }

    public void setCreator(String creator)
    {
        this.creator = creator;
    }

    public String getFolderpath()
    {
        return folderpath;
    }

    public void setFolderpath(String folderpath)
    {
        this.folderpath = folderpath;
    }

    public String getModifier()
    {
        return modifier;
    }

    public void setModifier(String modifier)
    {
        this.modifier = modifier;
    }

    public void setDocname(String docname)
    {
        this.docname = docname;
    }

    public String getDocname()
    {
        return docname;
    }

    public String getEdcsId()
    {
        return edcsId;
    }

    public void setEdcsId(String edcsId)
    {
        this.edcsId = edcsId;
    }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("DownloadBO [docname=");
        builder.append(docname);
        builder.append(", downloadedby=");
        builder.append(downloadedby);
        builder.append(", downloaddate=");
        builder.append(downloaddate);
        builder.append(", creator=");
        builder.append(creator);
        builder.append(", modifier=");
        builder.append(modifier);
        builder.append(", folderpath=");
        builder.append(folderpath);
        builder.append(", edcsId=");
        builder.append(edcsId);
        builder.append("]");
        return builder.toString();
    }
}
