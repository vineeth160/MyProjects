package com.cisco.edcsng.audit.bireports.publish;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.servlet.http.HttpServletResponse;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.PermissionService;
import org.alfresco.service.namespace.NamespaceService;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.mybatis.spring.MyBatisSystemException;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;
import com.cisco.alfresco.external.utils.DbSessionUtil;
import com.cisco.edcsng.audit.bireports.utils.BIReportsAuditMap;
import com.cisco.edcsng.audit.bireports.utils.BIReportsUtil;
import com.cisco.edcsng.audit.bireports.utils.GenericQueryUtil;

/**
 * @author vpotnuru
 */


public class UserActivitiesReport extends AbstractWebScript {

	 private Logger log = Logger.getLogger(UserActivitiesReport.class);
	 private NodeService nodeService;
	 private PermissionService permissionService;
	 private NamespaceService namespaceService;
	 private Properties globalProperties;
	 private ServiceRegistry serviceRegistry;
	 private DbSessionUtil dbSession;
	
	public Properties getGlobalProperties() {
		return globalProperties;
	}

	public void setGlobalProperties(Properties globalProperties) {
		this.globalProperties = globalProperties;
	}

	public NamespaceService getNamespaceService() {
		return namespaceService;
	}

	public void setNamespaceService(NamespaceService namespaceService) {
		this.namespaceService = namespaceService;
	}


	 public NodeService getNodeService() {
		return nodeService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public PermissionService getPermissionService() {
		return permissionService;
	}

	public void setPermissionService(PermissionService permissionService) {
		this.permissionService = permissionService;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
		}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
		}
	
	public DbSessionUtil getDbSession() {
		return dbSession;
	}

	public void setDbSession(DbSessionUtil dbSession) {
		this.dbSession = dbSession;
	}
	 
	 @SuppressWarnings("unused")
	public void execute(WebScriptRequest req, WebScriptResponse res) {
	    
		 	log.info("UserActivityReport excute method...");
			String folderNodeRef 	 					= null;
			String folderPath							= null;
			String users                  				= null;
			String dStart								= null;
			String dEnd									= null;
			String prefixPath 			    			= null;
			NodeRef processNode 	 					= null;
			boolean bSearchExtFolder 					= false;
			String jsonFormat							= null;
			String bSubFolders							= null;
			String queryLimit 							= null;
			Map<String, Object> auditMap    			= new HashMap<String, Object>();
			List<BIReportsAuditMap> queryResultList		= null;
			SqlSession sqlSession						= null;
						
			try
		    {
				Content c 		= req.getContent();
				UserActivityExcel excel = new UserActivityExcel();
				
				if (c == null) {
					throw new WebScriptException(Status.STATUS_BAD_REQUEST,"Missing POST body.");
				}
				JSONObject json;
				json = new JSONObject(c.getContent());
				
				dStart 				= json.getString("dateStart");
				dEnd 				= json.getString("dateEnd");
				
				log.info("Start Date: "+dStart+"  endDate:"+dEnd);				
				if(json.has("userIDs") && BIReportsUtil.valueNotNull(json.getString("userIDs"))){
					 users = json.getString("userIDs");
				}
				
				if (json.has("subFolders") && BIReportsUtil.valueNotNull(json.getString("subFolders"))) {
					bSubFolders = json.getString("subFolders");
				} else {
					bSubFolders = "false";
				}
				if(json.has("nodeId") && BIReportsUtil.valueNotNull(json.getString("nodeId"))) {
					folderNodeRef 		= json.getString("nodeId");
					processNode = new NodeRef(folderNodeRef);
				} 
				 
				bSearchExtFolder = true;
				log.info(" folderNodeRef ===>>>"+processNode);
					
				if (dStart == null || dStart.length() == 0) {
					throw new WebScriptException(HttpServletResponse.SC_BAD_REQUEST,"Start Date not specified");
				}
				if (dEnd == null) {
					throw new WebScriptException(HttpServletResponse.SC_BAD_REQUEST,"End Date not specified");
				}
		         
		         if(bSearchExtFolder){
		        	 bSubFolders = "true";
		         }
		         if(json.has("format") && BIReportsUtil.valueNotNull(json.getString("format"))){
		        	 jsonFormat = json.getString("format");
		         }
		         /*if(json.getString("format")!= null){
					jsonFormat = json.getString("format");
				 }*/
				 log.info("jsonFormat ===>>"+jsonFormat );
				 if (processNode != null) {
			         String nodeName 	= (String)nodeService.getProperty(processNode, ContentModel.PROP_NAME);
					 folderPath 			= nodeService.getPath(processNode).toDisplayPath(nodeService, permissionService)+"/"+nodeName;
					 prefixPath 			= nodeService.getPath(processNode).toPrefixString(namespaceService);
						
					log.info(" Folder Path:"+folderPath);
					log.info(" Folder prefixPath:"+prefixPath);
					
					//default we are taking as true
					bSubFolders = "true";
					
				}
				 queryLimit = globalProperties.getProperty("audit.results.limit");
				 auditMap.put("folderPath",folderPath);
				 auditMap.put("users",users);
				 auditMap.put("dStart",dStart);
				 auditMap.put("dEnd",dEnd);
				 auditMap.put("reportType",jsonFormat);
				 auditMap.put("limit",queryLimit);
				 try {
					if(sqlSession ==null)				
						sqlSession=dbSession.getSqlSession();
					queryResultList = GenericQueryUtil.reportList(auditMap, sqlSession, "userActivityReport");
				}catch(MyBatisSystemException e){
					log.error("MyBatisSystemException...." + e);
				}finally{
					try {
						dbSession.closeSession(sqlSession);
					}
					catch (MyBatisSystemException e){
						log.error("MyBatisSystemException...." + e);
					}
				}
				 
				Collections.sort(queryResultList, BIReportsUtil.auditDateComparator);
				
				/* Taking input from user about the type of report (Excel/Json) */
				if(jsonFormat != null && jsonFormat.equalsIgnoreCase("json")){
					log.info(" JSON format is calling ......");
		            getJSONReport(queryResultList,res,dStart,dEnd);
		         }else{
		            log.info(" XLS format is calling ......");
		            String logginUser = AuthenticationUtil.getFullyAuthenticatedUser();
		            log.info("loggin User: " + logginUser);
		            excel.getUserActivityReport(queryResultList,res, dStart, dEnd,logginUser,serviceRegistry);
		         }
		    }catch(WebScriptException e){
	        	e.printStackTrace() ;      	
	        } catch (JSONException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} 
			
	  }
	 
	 /** Returning results in JSON object
	  * @param userOperationsInfoList
	  * @param response
	  * @param dStart
	  * @param dEnd
     */
	 public void getJSONReport(List<BIReportsAuditMap> userOperationsInfoList, WebScriptResponse response, String dStart, String dEnd) {
		 
		 String col1Name = "CCO User Company name";
		 String col2Name = "CCO ID";
		 String col3Name = "Content title";
		 String col4Name = "Accessed Time";
		// String col5Name = "Amount of Data Transferred";
		 String col5Name = "Folder Path";
		 String col6Name = "User Action";
		 log.info("inside the getJSONReport:");
		 try {
				JSONArray jsonArray = new JSONArray();

				JSONObject jsonObj = null;
				
				if (userOperationsInfoList != null && userOperationsInfoList.size() > 0) {
					for (BIReportsAuditMap biMap : userOperationsInfoList) {
						if (biMap != null) {
							jsonObj = new JSONObject();
							jsonObj.put(col1Name, biMap.getCompanyName());
							jsonObj.put(col2Name, biMap.getUserId());
							jsonObj.put(col3Name, biMap.getFileName());							
							jsonObj.put(col4Name, biMap.getAuditTime());
							//jsonObj.put(col5Name, String.valueOf(extDoc.getContentSize()));
							jsonObj.put(col5Name, biMap.getFolderPath());
							jsonObj.put(col6Name, biMap.getAction());
							jsonArray.put(jsonObj);
						}
					}
				}
				response.setContentType("application/json");
				response.setContentEncoding("UTF-8");
				response.getWriter().write(jsonArray.toString());
		 } catch (Exception e) {
			log.info("Exception : " + e);
			e.printStackTrace();
		}
	 }
 
}
	             