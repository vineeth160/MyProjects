package com.cisco.edcsng.audit.downloadreports;


import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletResponse;

import jxl.CellView;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.audit.AuditQueryParameters;
import org.alfresco.service.cmr.audit.AuditService;
import org.alfresco.service.cmr.audit.AuditService.AuditQueryCallback;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter;
import org.alfresco.service.cmr.repository.datatype.TypeConversionException;
import org.alfresco.service.cmr.security.PermissionService;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.ibm.icu.util.Calendar;


/**
 * @param spathi
 */

public class DownloadActivityReport extends AbstractWebScript
{
    private Logger _logger = Logger.getLogger(DownloadActivityReport.class);

    private WritableCellFormat times;
    private WritableCellFormat timesBoldUnderline;
    private WritableCellFormat timesHeading;
    private Properties globalProperties;
   	private ServiceRegistry serviceRegistry;

    private static final String JSON_KEY_ENTRY_COUNT = "count";
    private static final String JSON_KEY_ENTRIES = "entries";
    private static final String JSON_KEY_ENTRY_ID = "id";
    private static final String JSON_KEY_ENTRY_APPLICATION = "application";
    private static final String JSON_KEY_ENTRY_USER = "user";
    private static final String JSON_KEY_ENTRY_TIME = "time";
    private static final String JSON_KEY_ENTRY_VALUES = "values";

    private String userID;
    private AuditService auditService;

    public void execute(WebScriptRequest req, WebScriptResponse res){
        _logger.info("Start Admin-Download Report's......26-Aug-2014.");
        
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        Date startDate, endDate;
        try
        {
            Content c = req.getContent();
            if (c == null)
            {
                throw new WebScriptException(Status.STATUS_BAD_REQUEST, "Missing POST body.");
            }

            // extract username and password from JSON object
            JSONObject json;
            String dStart, dEnd;
            try
            {
                json = new JSONObject(c.getContent());

                dStart = json.getString("dateStart");
                dEnd = json.getString("dateEnd");
                userID = json.getString("userIDs");

                _logger.info("Json Content Data : " + json);

                if (dStart == null || dStart.length() == 0)
                {
                    throw new WebScriptException(HttpServletResponse.SC_BAD_REQUEST, "Start Date not specified");
                }
                if (dEnd == null)
                {
                    throw new WebScriptException(HttpServletResponse.SC_BAD_REQUEST, "End Date not specified");
                }
            }
            catch (JSONException jErr)
            {
                throw new WebScriptException(Status.STATUS_BAD_REQUEST, "Unable to parse JSON POST body: "
                        + jErr.getMessage());
            }
            catch (IOException ioErr)
            {
                throw new WebScriptException(Status.STATUS_INTERNAL_SERVER_ERROR, "Unable to retrieve POST body: "
                        + ioErr.getMessage());
            }

            _logger.info("---------startDate ::: " + dStart + " endDate : : :" + dEnd + " userIDs :::" + userID);

            startDate = formatter.parse(dStart);
            endDate = formatter.parse(dEnd);

            Calendar calInstance = Calendar.getInstance();
            calInstance.setTime(startDate);
            
            _logger.info("Start Date Time: 1 "+calInstance.getTime()); 
            
            final Long fromTime = calInstance.getTimeInMillis();
            calInstance.setTime(endDate);
            
            _logger.info("End Date Time: 2 "+calInstance.getTime());
            
            calInstance.add(Calendar.DATE, 1);
            
            _logger.info("End Date Time: 3 "+calInstance.getTime());
            
            final Long toTime = calInstance.getTimeInMillis();
            
            
            _logger.info("---------startDate ::: " + startDate + " endDate : : :" + endDate + " userIDs :::" + userID);

            String loggeduser = AuthenticationUtil.getRunAsUser();
            _logger.info("...Logged User : " + loggeduser);

            final Map<String, Object> auditDownloadRefMap = new HashMap<String, Object>();

            AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
            {
                @Override
                public Object doWork() throws Exception
                {
                    _logger.info("auditDownloadRefMap" + auditDownloadRefMap + " " + fromTime + "   " + toTime);
                    getDownloadAuditQuery(auditDownloadRefMap, fromTime, toTime);

                    return null;
                }

            }, "admin");

            getDownloadReport(getDownloadBOList(auditDownloadRefMap, "admin"), res);
        }
        catch (ParseException pe)
        {
            _logger.info("Exception" + pe);
        }
        catch (Exception ex)
        {
            _logger.error("Exception......." + ex);
        }
    }

    /**
     * 
     * @param applicationName
     * @return
     */
    private Map<String, Object> getDownloadAuditQuery(Map<String, Object> model, Long fromTime, Long toTime)
    {

        int limit = 0;
        final boolean verbose = true;

        // Execute the query
        AuditQueryParameters params = new AuditQueryParameters();
        params.setApplicationName("download-report"); // "download-report"
        params.setFromTime(fromTime);
        params.setToTime(toTime);

        final List<Map<String, Object>> entries = new ArrayList<Map<String, Object>>(limit);
        AuditQueryCallback callback = new AuditQueryCallback()
        {
            @Override
            public boolean valuesRequired()
            {
                return verbose;
            }

            @Override
            public boolean handleAuditEntryError(Long entryId, String errorMsg, Throwable error)
            {
                return true;
            }

            @Override
            public boolean handleAuditEntry(Long entryId, String applicationName, String user, long time,
                    Map<String, Serializable> values)
            {

                Map<String, Object> entry = new HashMap<String, Object>(11);
                entry.put(JSON_KEY_ENTRY_ID, entryId);
                entry.put(JSON_KEY_ENTRY_APPLICATION, applicationName);

                if (user != null)
                {
                    entry.put(JSON_KEY_ENTRY_USER, user);
                }
                entry.put(JSON_KEY_ENTRY_TIME, new Date(time));

                if (values != null)
                {
                    // Convert values to Strings
                    Map<String, String> valueStrings = new HashMap<String, String>(values.size() * 2);
                    for (Map.Entry<String, Serializable> mapEntry : values.entrySet())
                    {
                        String key = mapEntry.getKey();
                        Serializable value = mapEntry.getValue();
                        try
                        {
                            String valueString = DefaultTypeConverter.INSTANCE.convert(String.class, value);
                            valueStrings.put(key, valueString);
                        }
                        catch (TypeConversionException e)
                        {
                            // Use the toString()
                            valueStrings.put(key, value.toString());
                        }
                    }
                    entry.put(JSON_KEY_ENTRY_VALUES, valueStrings);
                }
                entries.add(entry);

                return true;
            }
        };

        // Make an audit call to applicationName
        auditService.auditQuery(callback, params, limit);

        model.put(JSON_KEY_ENTRY_COUNT, entries.size());
        model.put(JSON_KEY_ENTRIES, entries);

        if (_logger.isDebugEnabled())
        {
            _logger.debug("Audit Size : " + entries.size());
        }
        return model;
    }

    @SuppressWarnings("unchecked")
    private List<DownloadBO> getDownloadBOList(Map<String, Object> entriesMap, String loggedUser)

    {
        DownloadBO bo = null;
        List<DownloadBO> userRecBoList = new ArrayList<DownloadBO>();

        if ((Integer) entriesMap.get(JSON_KEY_ENTRY_COUNT) > 0)
        {
            List<Map<String, Object>> entries = (List<Map<String, Object>>) entriesMap.get(JSON_KEY_ENTRIES);

            for (Map<String, Object> entryMap : entries)
            {

                bo = new DownloadBO();

                StringTokenizer uid = new StringTokenizer(userID, ",");

                String downloadedBy[] = new String[100];
                int i = 0;
                while (uid.hasMoreElements())
                {
                    downloadedBy[i] = uid.nextElement().toString().trim();
                    i++;

                }
                _logger.info("------downloadedBy ::: " + downloadedBy);

                Map<String, String> valuesMap = (Map<String, String>) entryMap.get(JSON_KEY_ENTRY_VALUES);

                _logger.info("#####user " + (String) entryMap.get("user"));
                bo.setDownloadedby((String) entryMap.get("user"));

                if (entryMap.get("time") != null)
                {
                    _logger.info("#####time " + entryMap.get("time").toString());
                    bo.setDownloaddate(entryMap.get("time").toString());

                }
                if (valuesMap != null
                        && (valuesMap.get("/download-report/document/creator") != null || valuesMap
                                .get("/download-report/document/modifier") != null))
                {

                   // if (valuesMap.get("/download-report/document/creator").equals(loggedUser)
                   //         || valuesMap.get("/download-report/document/modifier").equals(loggedUser))
                   // {

                        bo.setCreator(valuesMap.get("/download-report/document/creator"));

                        if (valuesMap.get("/download-report/document/path") != null)
                        {
                        	_logger.info("Full Path: "+valuesMap.get("/download-report/document/path"));
                        	String folderpath = valuesMap.get("/download-report/document/path");
                        	 try{
                        		 bo.setFolderpath(folderpath.substring(folderpath.lastIndexOf("/"),folderpath.length()));
                        	    }catch(StringIndexOutOfBoundsException siobe){
                        	    	 _logger.info("External Sharing folder path doesn't exist: "+siobe.getMessage());
                        	    }
                            _logger.info("Required Path: "+bo.getFolderpath());
                        }

                        if (valuesMap.get("/download-report/document/modifier") != null)
                        {
                            bo.setModifier(valuesMap.get("/download-report/document/modifier"));
                        }

                        if (valuesMap.get("/download-report/document/docname") != null)
                        {
                            bo.setDocname(valuesMap.get("/download-report/document/docname"));
                        }

                        // this edcsid property available in edcs-cs-dev-3 only
                        if (valuesMap.get("/download-report/document/edcsid") != null)
                        {
                            bo.setEdcsId(valuesMap.get("/download-report/document/edcsid"));
                        }
                   // }
                }
                _logger.info(bo.getDownloadedby() + "-------------------" + downloadedBy.toString());
                for (i = 0; i < downloadedBy.length; i++)
                {
                    if (bo.getDownloadedby().equalsIgnoreCase(downloadedBy[i]))
                    {
                        if (bo.getDocname() != null && bo.getDownloadedby() != null)
                        {
                            userRecBoList.add(bo);
                        }
                    }
                }
            }
        }
        return userRecBoList;
    }

    private void getDownloadReport(final List<DownloadBO> bo, final WebScriptResponse response)
    {
        _logger.info("inside the getDownloadreport.....");
        AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
                {
                    @Override
                    public Object doWork() throws Exception
                    {
                    	 // creating workbook
                        WritableWorkbook workbook = null;
                        String reportHeading = "Download_REPORT_HEADING";
                        WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);

                        try
                        {
                            OutputStream os = response.getOutputStream();
                            workbook = Workbook.createWorkbook(os);

                            // creating sheets in the workbook
                            WritableSheet wSheet1 = workbook.createSheet("Download Report", 0);
                            wSheet1.setColumnView(0, 20);
                            wSheet1.setColumnView(1, 20);
                            wSheet1.setRowView(0, 800);
                            timesHeading = new WritableCellFormat(times10ptBoldUnderline);
                            // do not automatically wrap the cells
                            timesHeading.setWrap(true);
                            //addHeading(wSheet1, 0, 0, reportHeading);
                            addHeading(wSheet1, 0, 0, globalProperties.getProperty("cisco.admin.download.report"));
                            wSheet1.mergeCells(0, 0, 13, 0);

                            String col1Name = "Document Name";
                            createLabel(wSheet1, col1Name, 0);

                            String col2Name = "EDCS ID";
                            createLabel(wSheet1, col2Name, 1);

                            String col3Name = "Creator";
                            createLabel(wSheet1, col3Name, 2);

                            String col4Name = "Modifier";
                            createLabel(wSheet1, col4Name, 3);

                            String col5Name = "Downloaded By";
                            createLabel(wSheet1, col5Name, 4);

                            String col6Name = "Downloaded Time";
                            createLabel(wSheet1, col6Name, 5);

                            String col7Name = "Folder Path";
                            createLabel(wSheet1, col7Name, 6);

                            // Map<String, String> rowMap = null;
                            int rowNumber = 2;

                            // User is checking in the Group   
                			String curuser = serviceRegistry.getAuthenticationService().getCurrentUserName(); 
                			_logger.info("..current User1: "+curuser);
                			
                			_logger.info("..current User2: "+AuthenticationUtil.getFullyAuthenticatedUser());
                            String groupUser = AuthenticationUtil.getFullyAuthenticatedUser();
                        
                            Set<String> UsersGroup = serviceRegistry.getAuthorityService().getAuthoritiesForUser(groupUser);
                            _logger.info("Users Group:::"+UsersGroup);
                      
                            Boolean groupExistsNot = UsersGroup.contains("GROUP_CISCOSHARE_ADMIN");
                            _logger.info("..User is there in the Group or Not: "+groupExistsNot);
                            
                            if(!groupExistsNot)
                            {
                            	_logger.info("..User is there NOT in Group.");
                            	//addHeading(wSheet1, 0, 0, "You are not authorized to run this operation. Please contact system administrator for further information.");
                            	addHeading(wSheet1, 0, 0, globalProperties.getProperty("cisco.groupvalid.message"));
                            	workbook.write();
                                workbook.close();
                            	return null;
                            }
                            else{
                            	_logger.info("...User is exists in the Group");
                            	
                            	for (DownloadBO recordKey : bo)	{
                            		if (recordKey != null)
                            		{
                                    addLabel(wSheet1, 0, rowNumber, recordKey.getDocname());
                                    addLabel(wSheet1, 1, rowNumber, recordKey.getEdcsId());
                                    addLabel(wSheet1, 2, rowNumber, recordKey.getCreator());
                                    addLabel(wSheet1, 3, rowNumber, recordKey.getModifier());
                                    addLabel(wSheet1, 4, rowNumber, recordKey.getDownloadedby());
                                    addLabel(wSheet1, 5, rowNumber, recordKey.getDownloaddate());
                                    addLabel(wSheet1, 6, rowNumber, recordKey.getFolderpath());
                            		}
                            		rowNumber++;
                            	}
                           }
                            workbook.write();
                            workbook.close();
                            _logger.info("..Successfully " + rowNumber + " Records created. ");

                            response.addHeader("Content-Disposition", "attachment;filename=MyDownloadReport.xls");
                            response.setContentType("application/vnd.ms-excel");
                            response.setHeader("Cache-Control", "private, max-age=0");
                            _logger.info("Excel File Downloaded Successfully...");
                        }
                        catch (Exception e)
                        {
                            _logger.info("Exception : " + e);
                            e.printStackTrace();
                        }
                        return null;
                    }

                }, "admin");
       
    }

    public void createLabel(WritableSheet sheet, String label, int col) throws WriteException
    {

        WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
        times = new WritableCellFormat(times10pt);
        times.setWrap(false);

        // Create create a bold font
        WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false);
        timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
        timesBoldUnderline.setWrap(false);

        CellView cv = new CellView();
        cv.setFormat(times);
        cv.setFormat(timesBoldUnderline);
        // Write a few headers
        addCaption(sheet, col, 1, label);
    }

    public void addCaption(WritableSheet sheet, int column, int row, String s) throws RowsExceededException,
            WriteException
    {
        Label label;
        label = new Label(column, row, s, timesBoldUnderline);
        sheet.addCell(label);
    }

    public void addLabel(WritableSheet sheet, int column, int row, String s) throws WriteException,
            RowsExceededException
    {
        Label label;
        label = new Label(column, row, s, times);
        sheet.addCell(label);
    }

    public void addHeading(WritableSheet sheet, int column, int row, String s) throws WriteException,
            RowsExceededException
    {
        Label label;
        label = new Label(column, row, s, timesHeading);
        sheet.addCell(label);
    }

    public void setGlobalProperties(Properties globalProperties)
    { 
   	  this.globalProperties = globalProperties; 
    }

    public void setAuditService(AuditService auditService)
    {
        this.auditService = auditService;
    }
    
    public void setServiceRegistry(ServiceRegistry serviceRegistry) {
        this.serviceRegistry = serviceRegistry;
    }
    

}