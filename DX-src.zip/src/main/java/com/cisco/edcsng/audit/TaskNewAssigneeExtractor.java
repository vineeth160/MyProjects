package com.cisco.edcsng.audit;

import java.io.Serializable;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.extractor.AbstractDataExtractor;
import org.alfresco.service.namespace.QName;


/**
 * 
 * @author dhshaw
 * 
 */
public class TaskNewAssigneeExtractor extends AbstractDataExtractor
{

    public boolean isSupported(Serializable data)
    {
        return (data instanceof Map);
    }

    public Serializable extractData(Serializable in) throws Throwable
    {
        Serializable assigneeName = null;
        try
        {
            logger.debug("[TaskNewAssigneeExtractor] - Serializable Data : " + in);
            Map<QName, Serializable> params = (Map<QName, Serializable>) in;
            assigneeName = (String) params.get(ContentModel.PROP_OWNER);
            logger.debug("[TaskNewAssigneeExtractor] - Assignee name : " + assigneeName);
        }
        catch (Exception e)
        {
            logger.error(e);
            throw e;
        }
        return assigneeName;
    }
}
