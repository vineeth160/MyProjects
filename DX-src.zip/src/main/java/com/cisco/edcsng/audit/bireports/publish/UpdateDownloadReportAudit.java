package com.cisco.edcsng.audit.bireports.publish;

import java.io.Reader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.apache.log4j.Logger;
import org.mybatis.spring.MyBatisSystemException;
/*import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;*/
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.Transaction;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.edcsng.audit.bireports.utils.BIReportsAuditMap;
import com.cisco.edcsng.audit.bireports.utils.BIReportsUtil;
import com.cisco.edcsng.audit.bireports.utils.GenericQueryUtil;


public class UpdateDownloadReportAudit extends QuartzJobBean
{

    private static final Logger LOGGER = Logger.getLogger(UpdateDownloadReportAudit.class);

    private static final String DOWNLOAD_COUNT_JOB_ENABLED = "UpdateDownloadCountJobEnable";
    NodeRef frozenNodeRef = null;

   // private SessionFactory localFactory;
    private SqlSessionFactory localFactory;
    private NodeService nodeService;

    public NodeService getNodeService()
    {
        return nodeService;
    }

    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    /*public SessionFactory getLocalFactory()
    {
        return localFactory;
    }

    public void setLocalFactory(SessionFactory localFactory)
    {
        this.localFactory = localFactory;
    }*/
    
    public SqlSessionFactory getLocalFactory() {
		return localFactory;
	}

	public void setLocalFactory(SqlSessionFactory localFactory) {
		this.localFactory = localFactory;
	}	


	private SqlSession getSqlSession(){
		  Reader reader;
		  SqlSession dbSession = null;
		try {
			reader = Resources.getResourceAsReader("sql-processNodes-config.xml");
			localFactory = new SqlSessionFactoryBuilder().build(reader);
			dbSession = localFactory.openSession(); 
			LOGGER.info("dbSession>>>>>>"+dbSession);
		} catch (Exception e) {
			LOGGER.error("Error getting db session ",e);
		}
			return dbSession;
	  }
    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException
    {
        LOGGER.info("UpdateDownloadReportAudit excuteInternal method...");

        String isJobEnabledStr = null;
        boolean isJobEnabled = false;

        Map<String, Object> auditMap = new HashMap<String, Object>();
        final List<BIReportsAuditMap> queryResultList;

        String downloadCountStr = null;

        DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        String propKeyValueStr = null;

        try
        {
            JobDataMap jobData = context.getJobDetail().getJobDataMap();
            isJobEnabledStr = (String) jobData.get(DOWNLOAD_COUNT_JOB_ENABLED);
            LOGGER.info("DOWNLOAD_COUNT_JOB_ENABLED " + isJobEnabledStr);
            if (isJobEnabledStr != null)
            {
                try
                {
                    isJobEnabled = new Boolean(isJobEnabledStr);
                }
                catch (Exception e)
                {
                    LOGGER.error("Invalid '" + DOWNLOAD_COUNT_JOB_ENABLED + "' value, using default: " + isJobEnabled,
                        e);
                }
            }

            if (!isJobEnabled)
            {
                LOGGER.info("Skipping " + DOWNLOAD_COUNT_JOB_ENABLED + " to execute.");
                return;
            }
            Date dt = new Date();
            final long toTimeLong = dt.getTime();

            long hours_12_Milli = TimeUnit.HOURS.toMillis(12); // milli seconds of 1
                                                               // day

            final long fromTimeLong = toTimeLong - hours_12_Milli;

            LOGGER.info("fromTimeLong:" + fromTimeLong + ",toTimeLong:" + toTimeLong);

            String toTime = formatter.format(dt);

            Date dt1 = new Date(fromTimeLong);
            String fromTime = formatter.format(dt1);

            auditMap.put("dStart", fromTime);
            auditMap.put("dEnd", toTime);
            auditMap.put("limit", "0");
            auditMap.put("reportType", "json");
            queryResultList = GenericQueryUtil.reportList(auditMap, localFactory, "downloadReport");

            if (queryResultList != null && queryResultList.size() > 0)
            {

                AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>()
                {
                    @Override
                    public Object doWork() throws Exception
                    {
                        String nodeRefStr;
                        int downloadCount = 0;
                        Map<String, Object> propValues = null;
                       // Session session = null;
                        GenericQueryUtil disableEntry = new GenericQueryUtil();
                        SqlSession session;
						try
                        {
                        	session = getSqlSession();
                        	BIReportsAuditMap ne =new BIReportsAuditMap();
                           // session = (Session) GenericQueryUtil.openSession(localFactory, session);
                            //Transaction tx = session.beginTransaction();
                            for (BIReportsAuditMap recordKey : queryResultList)
                            {
                                if (recordKey != null)
                                {
                                    nodeRefStr = null;
                                    if ((nodeRefStr = recordKey.getNoderef()) != null && nodeRefStr.trim().length() > 0)
                                    {
                                        final NodeRef nodeRef = new NodeRef(nodeRefStr);
                                        if (nodeService.exists(nodeRef))
                                        {
                                            if (nodeService.getProperty(nodeRef,
                                                CiscoModelConstants.PROP_CISCO_DOWNLOAD_COUNT) != null)
                                            {
                                                downloadCount = (Integer) nodeService.getProperty(nodeRef,
                                                    CiscoModelConstants.PROP_CISCO_DOWNLOAD_COUNT);
                                            }
                                            else
                                            {
                                                downloadCount = 1;
                                            }
                                        }
                                        else
                                        {
                                            downloadCount = 0;
                                        }
                                        if (downloadCount != 0)
                                        {
                                            propValues = BIReportsUtil.getPropValues(recordKey.getPropKeyValue());
                                            if (propValues != null)
                                            {
                                                if ((boolean) propValues.containsKey("download_count"))
                                                {
                                                    propValues.put("download_count", String.valueOf(downloadCount));
                                                }
                                            }
                                            String mapToString = String.valueOf(propValues);
                                            mapToString = mapToString.replaceAll("\\{", "");
                                            mapToString = mapToString.replaceAll("\\}", "");

                                            recordKey.setPropKeyValue(mapToString);
                                        }
                                        else
                                        {
                                            LOGGER.info("nodeRef not existed:" + nodeRef);
                                        }
                                    }

                                }

                              /*  if (session != null)
                                {

                                    session.update(recordKey);
                                }*/
                            }
                            //tx.commit();
                            session.commit();
                        }
                        catch (Exception e)
                        {
                            LOGGER.error(e);
                        }
                        finally
                        {
                            try
                            {
                               /* if (session != null)
                                {
                                    GenericQueryUtil.closeSession(session);
                                }*/
                            }
                            catch (MyBatisSystemException e)
                            {
                                LOGGER.error("HibernateException...." + e);
                            }
                        }

                        return null;

                    }
                }, "admin");
                // GenericQueryUtil.closeSession(session);
            }
        }
        catch (Exception e)
        {
            LOGGER.error("Exception:" + e);
        }

    }

}
