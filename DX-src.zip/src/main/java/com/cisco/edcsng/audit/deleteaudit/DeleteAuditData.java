package com.cisco.edcsng.audit.deleteaudit;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.cmr.audit.AuditQueryParameters;
import org.alfresco.service.cmr.audit.AuditService;
import org.alfresco.service.cmr.audit.AuditService.AuditQueryCallback;
import org.alfresco.service.cmr.security.AuthorityService;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.ibm.icu.util.Calendar;

public class DeleteAuditData extends DeclarativeWebScript{
	private Logger _logger = Logger.getLogger(DeleteAuditData.class);
	
	private AuditComponent auditComponent;
	private AuditService auditService;
	private AuthorityService authorityService;
	
	public AuthorityService getAuthorityService() {
		return authorityService;
	}
	public void setAuthorityService(AuthorityService authorityService) {
		this.authorityService = authorityService;
	}
	public AuditComponent getAuditComponent() {
		return auditComponent;
	}
	public void setAuditComponent(AuditComponent auditComponent) {
		this.auditComponent = auditComponent;
	}
	public AuditService getAuditService() {
		return auditService;
	}
	public void setAuditService(AuditService auditService) {
		this.auditService = auditService;
	}


	@Override
	public Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {
		
		final Map<String, Object> model = new HashMap<String, Object>(2);
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        Date startDate, endDate;
        int deletedIds = 0;
		int limit = 0;
		Long fromTime = null, toTime = null;
		try{
		
			String user 		= req.getParameter("user");
			String application 	= req.getParameter("application");
			String strlimit 	= req.getParameter("limit");
			String dStart 		= req.getParameter("fromTime");
	        String dEnd 		= req.getParameter("toTime");
	        
	        if(application == null){
	        	model.put("error", "Application name is missing in parameters");
	        	return model;
	        }
	        
	        if(strlimit != null){
				limit =Integer.parseInt(strlimit);
			}
	        
	        Calendar calInstance = Calendar.getInstance();
	        if(dStart != null){
		        startDate = formatter.parse(dStart);
		        calInstance.setTime(startDate);
		        fromTime = calInstance.getTimeInMillis();
	        }
	        if(dEnd != null){
		        endDate = formatter.parse(dEnd);
		        calInstance.setTime(endDate);
		        calInstance.add(Calendar.DATE, 1);
		        toTime = calInstance.getTimeInMillis();
	        }
	        _logger.info(" Logged in user ::"+AuthenticationUtil.getFullyAuthenticatedUser());
			boolean isAdminGroup = authorityService.getAuthoritiesForUser(AuthenticationUtil.getFullyAuthenticatedUser()).contains("GROUP_ALFRESCO_ADMINISTRATORS");
			_logger.info("User is part of ALFRESCO_ADMINISTRATORS::"+isAdminGroup);
			if(isAdminGroup){
				List<Long> entryIds = getAuditQuery(user,application,limit,fromTime,toTime);
				deletedIds = auditComponent.deleteAuditEntries(entryIds);
				_logger.info(" No.of Ids Deleted ::"+deletedIds);
			}else{
				model.put("error", "You do not have the appropriate permissions to perform this operation.");
			}
			model.put("count", deletedIds);
		
		}catch(WebScriptException e){
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return model;
		
	}
	
	/**
     * 
     * @param toTime 
	 * @param fromTime 
	 * @param applicationName
     * @return
     */
    private  List<Long> getAuditQuery(String user, String application,int limit, Long fromTime, Long toTime){

        final List<Long> entries 	= new ArrayList<Long>();
        final boolean verbose = false;
        AuditQueryParameters params = new AuditQueryParameters();
        params.setApplicationName(application); 
        params.setUser(user);
        params.setFromTime(fromTime);
        params.setToTime(toTime);
        params.setForward(false);
        AuditQueryCallback callback = new AuditQueryCallback()
        {
        	
            @Override
            public boolean valuesRequired()
            {
                return verbose;
            }

            @Override
            public boolean handleAuditEntryError(Long entryId, String errorMsg, Throwable error)
            {
                return true;
            }

            @Override
            public boolean handleAuditEntry(Long entryId, String applicationName, String user, long time,
                    Map<String, Serializable> values)
            {
                if (user != null)
                {
                    entries.add(entryId);
                }

                return true;
            }
        };

        // Make an audit call to applicationName
        auditService.auditQuery(callback, params, limit);
        
        _logger.info(" Entry Ids Size::"+entries.size());
        
        return entries;
    }

}
