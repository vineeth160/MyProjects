package com.cisco.edcsng.audit.move;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;


/**
 * 
 * @author dhshaw
 * 
 */
public class MoveComment extends AbstractWebScript
{
    private static Logger _log = Logger.getLogger(MoveComment.class);
    /** Custom Aspect */
    QName CUSTOM_ASPECT_FORMOVECOMMENT = QName.createQName(CiscoModelConstants.CISCO_MODEL_URI, "moveReasonAspect");
    /** Adding an aspect to a node to set "moveReason" comment */
    QName PROP_QNAME_COMMENT_REASON = QName.createQName(CiscoModelConstants.CISCO_MODEL_URI, "moveReason");

    private ServiceRegistry serviceRegistry;

    public ServiceRegistry getServiceRegistry()
    {
        return serviceRegistry;
    }

    public void setServiceRegistry(ServiceRegistry serviceRegistry)
    {
        this.serviceRegistry = serviceRegistry;
    }

    public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException
    {
        _log.info("In MoveComment.execute()");
        doSearch(req, res);
    }

    public void doSearch(WebScriptRequest req, WebScriptResponse res)
    {
        _log.info("In MoveComment.doSearch()");
        NodeService nodeService = this.serviceRegistry.getNodeService();
        _log.info("req.getParameter noderef:: " + req.getParameter("nodeRef"));
        String[] nodePath = req.getParameter("nodeRef").split(",");
        String moveComment = req.getParameter("movecomment");
        for (int i = 0; i < nodePath.length; i++)
        {
            if (nodePath[i].startsWith("workspace:"))
            {
                NodeRef currentNodeRef = new NodeRef(nodePath[i]);
                addCommnetAspect(nodeService, currentNodeRef, moveComment);
            }
        }
    }

    /**
     * Adding an aspect to a node to set "Archived" status
     * 
     * @param nodeService
     * @param currentNodeRef
     */
    private void addCommnetAspect(NodeService nodeService, NodeRef currentNodeRef, String moveComment)
    {
        _log.info(" In MoveComment.addCommnetAspect for NodeRef -->" + currentNodeRef);
        Map<QName, Serializable> aspectValues = new HashMap<QName, Serializable>();
        aspectValues.put(PROP_QNAME_COMMENT_REASON, moveComment);
        nodeService.addAspect(currentNodeRef, CUSTOM_ASPECT_FORMOVECOMMENT, aspectValues);

    }
}
