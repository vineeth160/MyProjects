package com.cisco.edcsng.audit.download;

import java.util.List;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.processor.BaseProcessorExtension;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.AssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.QName;
import org.apache.log4j.Logger;

import com.cisco.alfresco.edcsng.util.LDAPUtil;


/**
 * 
 * @author Saranyan
 * 
 */
public class ModifyDownloadLimit extends BaseProcessorExtension

{
    private static Logger LOGGER = Logger.getLogger(ModifyDownloadLimit.class);
    private String ldapHost;
    private String ldapPort;
    private NodeService nodeService;
    private ServiceRegistry registry;
    static final String NAMESPACE = "http://www.cisco.com/model/content/1.0";

    static final QName PROP_ASSOC_RELATEDUSER = QName.createQName(NAMESPACE, "relatedUser");

    /**
     * 
     * @param users
     * @return
     */
    public String checkUserAllowed(String currentUser, String nodeRefStr, String status)
    {

        String allowed = "false";
        try
        {
            nodeRefStr = nodeRefStr.replace("workspace/", "workspace://");
            LOGGER.info(" In checkUserAllowed START currentUser: " + currentUser + "  modifyUserNodeRef " + nodeRefStr
                    + " status " + status);

            NodeRef node = new NodeRef(nodeRefStr);
            String userName = "";
            if (status.equalsIgnoreCase("new"))
            {
                userName = (String) nodeService.getProperty(node, ContentModel.PROP_USERNAME);

            }
            else
            {

                List<AssociationRef> list = nodeService.getTargetAssocs(node, PROP_ASSOC_RELATEDUSER);

                for (AssociationRef x : list)
                {
                    NodeRef childNodeRef = x.getTargetRef();

                    userName = (String) nodeService.getProperty(childNodeRef, ContentModel.PROP_USERNAME);
                }
            }
            String currentUserName = AuthenticationUtil.getFullyAuthenticatedUser();
            if (currentUserName.equalsIgnoreCase("admin"))
            {
                // allowed to modify
                allowed = "true";
            }
            else
            {

                // if current user is manager for modifying user then also allow
                String managerName = LDAPUtil.getManagerId(userName, ldapHost, ldapPort);
                if (managerName.equalsIgnoreCase(currentUserName))
                {

                    allowed = "true";
                }

            }

        }
        catch (Exception e)
        {
            LOGGER.error(e);
        }
        return allowed;
    }

    public String getLdapHost()
    {
        return ldapHost;
    }

    public void setLdapHost(String ldapHost)
    {
        this.ldapHost = ldapHost;
    }

    public String getLdapPort()
    {
        return ldapPort;
    }

    public void setLdapPort(String ldapPort)
    {
        this.ldapPort = ldapPort;
    }

    /**
     * @param nodeService
     *            the nodeService to set
     */
    public void setNodeService(NodeService nodeService)
    {
        this.nodeService = nodeService;
    }

    public void setServiceRegistry(ServiceRegistry registry)
    {
        this.registry = registry;
    }

}
