package com.cisco.vera.action;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.action.executer.ActionExecuterAbstractBase;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.security.authentication.AuthenticationUtil.RunAsWork;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.action.Action;
import org.alfresco.service.cmr.action.ParameterDefinition;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.QName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cisco.alfresco.edcsng.constants.CiscoModelConstants;
import com.cisco.alfresco.edcsng.util.EDCSUtil;
import com.cisco.alfresco.external.common.util.ExternalSharingConstants;
/**
 * 
 * @author vepagada
 *
 */
public class ApplyVeraProtectionActionExecuter extends ActionExecuterAbstractBase {
	private static final Logger log = LoggerFactory.getLogger(ApplyVeraProtectionActionExecuter.class);
	private ServiceRegistry serviceRegistry;

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	@Override
	protected void executeImpl(final Action action, final NodeRef actionedUponNodeRef) {
		AuthenticationUtil.runAs(new RunAsWork<Object>() {
			@Override
			public Object doWork() throws Exception {
				NodeRef folderNodeRef = (NodeRef) action.getParameterValue("folderNodeRef");
				String strFolderNodeRef = folderNodeRef.toString();
				String veraEnabledBy = (String) action.getParameterValue("veraEnabledBy");
				String veraProtectionStatus = (String) action.getParameterValue("veraProtectionStatus");
				log.info("Inputs are : strFolderNodeRef : " + strFolderNodeRef + " ;veraEnabledBy : " + veraEnabledBy + " ;veraProtectionStatus : " + veraProtectionStatus);
				
				/**
				 * IRM Enable/Disable on action folder(i.e main folder where user initiated action)
				 */
				if(veraProtectionStatus.matches("Cisco Restricted|All Contents")){
					applyVeraProtectionAspect(folderNodeRef, veraProtectionStatus, true, veraEnabledBy, strFolderNodeRef);
				} else {
					serviceRegistry.getNodeService().removeAspect(folderNodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION);
				}

				enableOrDisableVeraProtectionAspect(folderNodeRef, veraEnabledBy, strFolderNodeRef, veraProtectionStatus);

				return null;
			}

		}, "admin");
	}

	@Override
	protected void addParameterDefinitions(List<ParameterDefinition> paramList) {
		// Do nothing.
	}

	/**
	 * 
	 * @param folderNodeRef
	 * @param veraEnabledBy
	 * @param strFolderNodeRef
	 * @param veraProtectionStatus
	 * 
	 * This method will enable or disable the vera protection on all subfolders and documents.  
	 */
	private void enableOrDisableVeraProtectionAspect(NodeRef folderNodeRef, String veraEnabledBy, String strFolderNodeRef, String veraProtectionStatus) throws Exception{
		String folderQnamePath = serviceRegistry.getNodeService().getPath(folderNodeRef).toPrefixString(serviceRegistry.getNamespaceService());
		String query = "PATH:\"" + folderQnamePath + "//*\" AND NOT ASPECT:\"cm:checkedOut\" AND (TYPE:\"cs:ciscodoc\" OR TYPE:\"cm:folder\")";
		log.info("qNamePath : " + folderQnamePath + " Query is : " + query);
		List<NodeRef> nodeRefList = EDCSUtil.getNodeRefList(query, serviceRegistry);

		if(nodeRefList != null && !nodeRefList.isEmpty()){
			for (NodeRef nodeRef : nodeRefList) {
				String nodeType = serviceRegistry.getNodeService().getType(nodeRef).getLocalName();
				String name = (String)serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NAME);
				String security = (String)serviceRegistry.getNodeService().getProperty(nodeRef, CiscoModelConstants.CISCO_SECURITY_PROP);
				log.info("nodeRef : " + nodeRef + " ;Name : " + name + " ;Type : " + nodeType + " ;security : " + security);
				/**
				 * vera protection enabling/disabling cascading starts
				 */
				if (veraProtectionStatus.matches("Cisco Restricted|All Contents")) {
					if (nodeType != null && "folder".equals(nodeType)) {
						applyVeraProtectionAspect(nodeRef, veraProtectionStatus, false, veraEnabledBy, strFolderNodeRef);
					} else if("All Contents".equals(veraProtectionStatus) || "Cisco Restricted".equals(security)){
						Map<QName, Serializable> verDocumentProtectionProps = new HashMap<>(1);
						verDocumentProtectionProps.put(ExternalSharingConstants.PROP_IS_DOCUMENT_VERA_PROTECTED, true);
						serviceRegistry.getNodeService().addAspect(nodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION, verDocumentProtectionProps);
					} else if(serviceRegistry.getNodeService().hasAspect(nodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION)){
						serviceRegistry.getNodeService().removeAspect(nodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION);
					}

				} else if (veraProtectionStatus.isEmpty() || "disable".equals(veraProtectionStatus)) {
					if(!"Cisco Restricted".equals(security)){
						serviceRegistry.getNodeService().removeAspect(nodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION);
					} else {
						log.error("Cisco Restricted data found. you are not allow to disable the the vera protection");
						throw new Exception("Cisco Restricted Data found.You can not disable IRM protection on Cisco Resricted documents");
					}
				}
			}
		}
	}
	
	private void applyVeraProtectionAspect(NodeRef folderNodeRef, String veraProtectionStatus, boolean isVeraRootFolder, String veraEnabledBy, String veraRootFolderNodeRef){
		Map<QName, Serializable> verFolderProtectionProps = new HashMap<>(6);
		verFolderProtectionProps.put(ExternalSharingConstants.PROP_APPLY_VERA_PROTECTION,veraProtectionStatus);
		verFolderProtectionProps.put(ExternalSharingConstants.PROP_IS_VERA_ROOT_FOLDER,isVeraRootFolder);
		verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ENABLED_DATE,new Date());
		verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ENABLED_BY,veraEnabledBy);
		verFolderProtectionProps.put(ExternalSharingConstants.PROP_VERA_ROOT_FOLDER_NODEREF,veraRootFolderNodeRef);
		serviceRegistry.getNodeService().addAspect(folderNodeRef, ExternalSharingConstants.ASPECT_VERA_PROTECTION, verFolderProtectionProps);

	}
}
