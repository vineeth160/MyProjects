package com.cisco.vera.sdk.connector;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import com.vera.sdk.Context;
import com.vera.sdk.Sdk;
import com.vera.sdk.Securer;
import com.google.gson.JsonParser;
import com.google.gson.JsonObject;
//US10717-nathammi,prbadam:TKL and Other apps VERA SDK connector and api methods for encryption on Doc Exchange Application
public class VeraConnector {
	
	private static Logger log = Logger.getLogger(VeraConnector.class);
	private static String FILE_EXTENSION =".p12";
	private static String veraCertFilePath;

	public static String getVeraCertFilePath() {
		return veraCertFilePath;
	}

	public static void setVeraCertFilePath(String veraCertFilePath) {
		VeraConnector.veraCertFilePath = veraCertFilePath;
	}
	
	public static void initSDK() throws IOException {
        // perform necessary Vera SDK initialization, like loading native libraries
        Sdk.initialize();
        if(log.isDebugEnabled()){
        log.debug("VERA SDK initialization done!!");
        }
    }

    private static Securer createSecurer(String jsonConfiguration) throws FileNotFoundException {
        // load configuration file from the specified folder path
        // conf.json is a starting point and put all corresponded params into that file
        // the expected way to obtain the configuration information is by grabbing it from vera portal.
        Context context = new Context(jsonConfiguration);
        context.setSignCertificatePath(getVeraCertFilePath(jsonConfiguration));
        context.setSignCertificatePassword(getVeraCertPassword(jsonConfiguration));
        return new Securer(context);
    }
    
    public static InputStream secureStream(InputStream sourceStream, String docName, String alfId, String clientDocId,String jsonConfiguration) throws IOException, NoSuchAlgorithmException {
    	ByteArrayInputStream secureSourceMemoryStream = null;
    	ByteArrayOutputStream secureMemoryOutputStream = null; 
    	InputStream secureInputStream = null;
        try {
        	Securer.SecureInputStreamResult sr = createSecurer(jsonConfiguration).secureInputStream(sourceStream, docName, alfId, clientDocId);
        	secureInputStream = sr.getSecureStream();
        	secureMemoryOutputStream = new ByteArrayOutputStream(); 
        	byte[] secureBuf = new byte[4096];
        	int secureBytesRead = 0;
        	while ((secureBytesRead = secureInputStream.read(secureBuf, 0, secureBuf.length)) >= 0){
        		secureMemoryOutputStream.write(secureBuf, 0, secureBytesRead);
        	}
        	byte[] secureSourceBytes = secureMemoryOutputStream.toByteArray();
        	secureSourceMemoryStream = new ByteArrayInputStream(secureSourceBytes);
        }
        finally {
        	if(sourceStream!=null){
        		sourceStream.close();
        	}
        	if(secureMemoryOutputStream != null){
        		secureMemoryOutputStream.close();
        	}
        	if(secureInputStream != null){
        		secureInputStream.close();
        	}
        }
        return secureSourceMemoryStream;

    }
    
	public static InputStream unsecureInputStream(InputStream sourceStream, String jsonConfiguration) throws Exception {
		return createSecurer(jsonConfiguration).unsecureInputStream(sourceStream);
	}

	public static String getMetadataForStream(InputStream stream, String jsonConfiguration) throws Exception {
		log.info("getMetadataForStream****" + stream.available());
		Securer.DocMetadata metadata = createSecurer(jsonConfiguration).getMetadataForStream(stream);
		if (metadata == null) {
			return null;
		}
		return metadata.getDocId();
	}

	public static String getDocPolicies(String docId, String userId, String jsonConfiguration)
			throws FileNotFoundException {
		String policies = createSecurer(jsonConfiguration).getDocPoliciesForUser(docId, userId);
		log.info("***policies****" + policies);
		String policyName = null;
		if (policies != null && !policies.isEmpty()) {
			JsonParser parser = new JsonParser();
			JsonObject json = parser.parse(policies).getAsJsonObject();
			log.info("json : " + json + " ;Policies present : " + json.get("policies").isJsonNull());
			if (!json.get("policies").isJsonNull()) {
				JsonObject jsonPolicies = (JsonObject) json.get("policies");
				if (jsonPolicies.has("name") && jsonPolicies.get("name") != null) {
					policyName = jsonPolicies.get("name").getAsString();
				}
			}
		}
		log.info("***policyName***" + policyName);
		return policyName;
	}

	public static String getVeraCertPassword(String jsonConfiguration) {
		String veraCertPassword = null;
		try {
			JSONObject appDetails = new JSONObject(jsonConfiguration);
			veraCertPassword = (String) appDetails.get("certPassword");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return veraCertPassword;
	}

	public static String getVeraCertFilePath(String jsonConfiguration) {
		String veraCertPath = null;
		try {
			JSONObject appDetails = new JSONObject(jsonConfiguration);
			veraCertPath = veraCertFilePath + "/" + (String) appDetails.get("appId") + FILE_EXTENSION;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return veraCertPath;
	}
}
