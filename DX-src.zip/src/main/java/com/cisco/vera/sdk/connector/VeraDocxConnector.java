package com.cisco.vera.sdk.connector;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.vera.sdk.Context;
import com.vera.sdk.Sdk;
import com.vera.sdk.Securer;
import com.vera.sdk.Securer.SecureFileResult;

//mdanaven:US7297-VERA SDK connector and api methods for encryption on Doc Exchange Application
public class VeraDocxConnector {
	
	private static Logger log = Logger.getLogger(VeraDocxConnector.class);
	 
	private static String veraJsonFilePath;
	private static String veraJsonFileName;
	private static String veraCertFilePath;
	private static String veraCertPassword;

	public static String getVeraJsonFilePath() {
		return veraJsonFilePath;
	}

	public static void setVeraJsonFilePath(String veraJsonFilePath) {
		VeraDocxConnector.veraJsonFilePath = veraJsonFilePath;
	}

	public static String getVeraJsonFileName() {
		return veraJsonFileName;
	}

	public static void setVeraJsonFileName(String veraJsonFileName) {
		VeraDocxConnector.veraJsonFileName = veraJsonFileName;
	}

	public static String getVeraCertFilePath() {
		return veraCertFilePath;
	}

	public static void setVeraCertFilePath(String veraCertFilePath) {
		VeraDocxConnector.veraCertFilePath = veraCertFilePath;
	}

	public static String getVeraCertPassword() {
		return veraCertPassword;
	}

	public static void setVeraCertPassword(String veraCertPassword) {
		VeraDocxConnector.veraCertPassword = veraCertPassword;
	}

	public static void initSDK() throws IOException {
        // perform necessary Vera SDK initialization, like loading native libraries
        Sdk.initialize();
        log.info("VERA SDK initialization done!!");
    }


    private static Securer createSecurer() throws FileNotFoundException {
        // load configuration file from the specified folder path
        // conf.json is a starting point and put all corresponded params into that file
        // the expected way to obtain the configuration information is by grabbing it from vera portal.
        Context context = new Context(new File(veraJsonFilePath, veraJsonFileName));
        context.setSignCertificatePath(veraCertFilePath);
        context.setSignCertificatePassword(veraCertPassword);

        return new Securer(context);
    }

    public static String secure(String sourcePath, String targetPath, String clientDocId) throws FileNotFoundException {
    	SecureFileResult sfr=createSecurer().secureFile(sourcePath, targetPath, clientDocId);
    	log.info("Vera DocId****"+sfr.getDocId());
    	return sfr.getDocId();
    }

    public static void unsecure(String sourcePath, String targetPath) throws FileNotFoundException {
        createSecurer().unsecureFile(sourcePath, targetPath, null);
    }

    public static void secureBulk(String[] sourcePaths) throws FileNotFoundException {
        Securer securer = createSecurer();
        for (int i = 0; i < sourcePaths.length ; i++) {
            String sourcePath = sourcePaths[i];
            String targetPath = sourcePath + ".html";
            SecureFileResult sfr= securer.secureFile(sourcePath, targetPath);
            log.info("Vera DocId"+sfr.getDocId());
        }
    }
    
    public static String getDocPolicies(String docId, String userId) throws FileNotFoundException {
        String policies = createSecurer().getDocPoliciesForUser(docId, userId);
        log.info("***policies****"+policies);
        String policyName = null;
        
        if(policies != null && !policies.isEmpty()){
        	JsonParser parser = new JsonParser();
        	JsonObject json = parser.parse(policies).getAsJsonObject();
        	log.info("json : " + json + " ;Policies present : " + json.get("policies").isJsonNull());
        	if(!json.get("policies").isJsonNull()){
        		JsonObject jsonPolicies = (JsonObject)json.get("policies");
        		if(jsonPolicies.has("name") && jsonPolicies.get("name") != null){
        			policyName = jsonPolicies.get("name").getAsString();
        		}
        	}
        }
        
        log.info("***policyName***"+policyName);
        
        return policyName;
    }
    
    public static String getMetadata(String path) throws FileNotFoundException {

        Securer.DocMetadata metadata = createSecurer().getMetadataForFile(path);
        if (metadata == null) {
            log.info(String.format("'%s' is not a secure file", path));
            return null;
        }

        return metadata.getDocId();
    }
    public static InputStream unsecureInputStream(InputStream sourceStream) throws FileNotFoundException {
        log.info("unsecureInputStream**********");
           return createSecurer().unsecureInputStream(sourceStream);
       }
    public static String getMetadataForStream(InputStream stream) throws FileNotFoundException {
        log.info("getMetadataForStream****");
        Securer.DocMetadata metadata = createSecurer().getMetadataForStream(stream);
        log.info("metadata.toString()**** : " + metadata);
        if (metadata == null) {
          return null;
        }
        return metadata.getDocId();
      }
    public static InputStream secureStream(InputStream sourceStream, String docName, String alfId, String clientDocId) throws IOException, NoSuchAlgorithmException {
    	ByteArrayInputStream secureSourceMemoryStream = null;
    	ByteArrayOutputStream secureMemoryOutputStream = null; 
    	InputStream secureInputStream = null;
        try {
        	Securer.SecureInputStreamResult sr = createSecurer().secureInputStream(sourceStream, docName, alfId, clientDocId);
        	secureInputStream = sr.getSecureStream();
        	secureMemoryOutputStream = new ByteArrayOutputStream(); 
        	byte[] secureBuf = new byte[4096];
        	int secureBytesRead = 0;
        	while ((secureBytesRead = secureInputStream.read(secureBuf, 0, secureBuf.length)) >= 0){
        		secureMemoryOutputStream.write(secureBuf, 0, secureBytesRead);
        	}
        	byte[] secureSourceBytes = secureMemoryOutputStream.toByteArray();
        	secureSourceMemoryStream = new ByteArrayInputStream(secureSourceBytes);
        }
        finally {
        	if(sourceStream!=null){
        		sourceStream.close();
        	}
        	if(secureMemoryOutputStream != null){
        		secureMemoryOutputStream.close();
        	}
        	if(secureInputStream != null){
        		secureInputStream.close();
        	}
        }
        
        return secureSourceMemoryStream;

    }
    
    
    /// Help method to calc a hash based on file content
   /* private static String calcHash(InputStream sourceStream) throws NoSuchAlgorithmException, IOException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        try {
            int bytesRead;
            byte[] buf = new byte[4096];
            while ((bytesRead = sourceStream.read(buf)) >= 0)
                md.update(buf, 0, bytesRead);

            byte[] digest = md.digest();
            String result = "";
            for (int i = 0; i < digest.length; ++i)
                result += Integer.toHexString(digest[i]);
            log.info("hashValue***"+result);
            return result;

        }
        finally {
        	sourceStream.close();
        }

    }*/
}
