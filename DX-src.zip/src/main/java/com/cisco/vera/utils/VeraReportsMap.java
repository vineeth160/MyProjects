package com.cisco.vera.utils;

import java.io.Serializable;
import java.util.Date;

public class VeraReportsMap implements Serializable{
	
	private String userName;
	private String docNoderef;
	private Date lastAccessDate;
	private String veraRootNoderef;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDocNoderef() {
		return docNoderef;
	}
	public void setDocNoderef(String docNoderef) {
		this.docNoderef = docNoderef;
	}
	public Date getLastAccessDate() {
		return lastAccessDate;
	}
	public void setLastAccessDate(Date lastAccessDate) {
		this.lastAccessDate = lastAccessDate;
	}
	public String getVeraRootNoderef() {
		return veraRootNoderef;
	}
	public void setVeraRootNoderef(String veraRootNoderef) {
		this.veraRootNoderef = veraRootNoderef;
	}
	

}
