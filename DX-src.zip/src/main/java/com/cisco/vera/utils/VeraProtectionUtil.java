package com.cisco.vera.utils;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.alfresco.util.InputStreamContent;
import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.cisco.alfresco.service.constants.ErrorStatus;
import com.cisco.vera.sdk.connector.VeraConnector;
import com.cisco.vera.sdk.connector.VeraDocxConnector;

public class VeraProtectionUtil {
	final static Logger logger = Logger.getLogger(VeraProtectionUtil.class);
	protected ServiceRegistry registry;
	private static String appsVeraJsonFilePath;
	private static String appsVeraJsonFileName;
	Map<String,JSONObject> veraUsers=new HashMap<String, JSONObject>();
	
	public VeraProtectionUtil(String appsVeraJsonFilePath, String appsVeraJsonFileName) {
		super();
		try {
			File file = new File(appsVeraJsonFilePath.trim(), appsVeraJsonFileName.trim());
			logger.info(" ::VeraProtectionUtil apps json initilized :::"+file.exists());
			if (file.exists()) {
				String jsonStr = getFileData(file);
				if (jsonStr.length() > 0) {
					JSONArray jsonarr = new JSONArray(jsonStr);
					// map object userid as json object key
					for (int i = 0; i < jsonarr.length(); i++) {
						JSONObject jsonAppDetails = jsonarr.getJSONObject(i);
						JSONArray usersIds = jsonAppDetails.getJSONArray("userid");
						// getting the users from list.
						for (int j = 0; j < usersIds.length(); j++) {
							String currentUser = (String) usersIds.get(j);
							veraUsers.put(currentUser, jsonAppDetails);
						}
					}
				}
				logger.error(" :::::: VeraProtectionUtil apps json initilized ::::::"+veraUsers.keySet());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setServiceRegistry(ServiceRegistry registry) {
		this.registry = registry;
	}

	public static String getAppsVeraJsonFilePath() {
		return appsVeraJsonFilePath;
	}

	public static String getAppsVeraJsonFileName() {
		return appsVeraJsonFileName;
	}
	
	/**
     * To check the user have "USER" permission on the node
     * 
     * @param currentUser
     * @param nodeRef
     * @param serviceRegistry
     * @return
     */
	public void applyVeraProtectionPolicy(String nodeRefString, WebScriptRequest req, WebScriptResponse res,
			String currentLoginUserName) {
		NodeRef node = new NodeRef(nodeRefString);
		String nodeName = (String) registry.getNodeService().getProperty(node, ContentModel.PROP_NAME);
		if (registry.getFileFolderService().getFileInfo(node).isFolder()) {
			res.setStatus(ErrorStatus.STATUS_CODE_FAILURE);
			try {
				res.getWriter().write("Content not a file.");
				res.getWriter().close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return;
		}

		try {
			String veraProfile = getVersUserProfile(currentLoginUserName,node);
			if(veraProfile!=null && !veraProfile.isEmpty()){
			applyVeraProtection(node, nodeName.trim(), res, veraProfile);
			}else{
				applyDocExVeraProtection(node, nodeName.trim(), res);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
        * 
        * @param nodeRef
        * @param fileName
        * @param res
        * @throws Exception
        */
       public void applyVeraProtection(NodeRef nodeRef, String fileName, final WebScriptResponse res,String jsonConfiguration)	throws Exception {
    	 if(logger.isDebugEnabled())
    	 logger.debug(" :::::::::: in side applyVeraProtection block :::::::::::");
   		// Reading the data content of a NodeRef (binary)
   		ContentReader reader = registry.getContentService().getReader(nodeRef, ContentModel.PROP_CONTENT);
   		InputStream sourceStream = null;
   		InputStream veraSecureStream = null;
   		try {
   			sourceStream = reader.getContentInputStream();
   			String alfId=nodeRef.getId();
               String clientDocId=nodeRef.toString();
               long t1 = System.currentTimeMillis();
               if(logger.isDebugEnabled()){
            	   logger.debug(" :::::: before VeraTklConnector ::::::");
       			}
               veraSecureStream=VeraConnector.secureStream(sourceStream, fileName, alfId, clientDocId,jsonConfiguration);
               logger.error("Vera Ecnryption time***"+(System.currentTimeMillis() - t1));
               long t2 = System.currentTimeMillis();
               String fileNameApp = fileName+".html";
               logger.error("fileNameApp :::: "+fileNameApp);
   			res.setHeader("Content-disposition", "attachment; filename="+ URLEncoder.encode(fileNameApp,"UTF-8").replaceAll("\\+", "%20"));
   			res.setHeader("irm-filename", fileNameApp);
   			res.setContentType("text/html");
   			ByteArrayOutputStream memoryOutputStream = null;
   			 try {
   				 //1 read into memory to make sure sourceStream can be properly consumed
   				 memoryOutputStream = new ByteArrayOutputStream();
   		        	byte[] buf = new byte[4096];
   		        	int bytesRead = 0;
   		        	while ((bytesRead = veraSecureStream.read(buf, 0, buf.length)) >= 0){
   		        		//2 output source data
   		        		memoryOutputStream.write(buf, 0, bytesRead); 
   		        	}
   		        	memoryOutputStream.writeTo(res.getOutputStream());
   		        	//byte[] sourceBytes = memoryOutputStream.toByteArray();
   		        	//3 create inputSecureStream based on source bytes in memory
   		        	logger.error("Reading and writing the encrypted content to response time***"+(System.currentTimeMillis() - t2));
   		        } finally {
   		            if (veraSecureStream != null) 
   		            	veraSecureStream.close();
   		            
   		            if(sourceStream != null){
   		            	sourceStream.close();
   		            }
   		            if(memoryOutputStream != null){
   		            	memoryOutputStream.close();
   		            }
   		            if(res.getOutputStream() != null){
   		            	res.getOutputStream().close();
   		            }
   		        }
   		} catch (Exception e) {
   			logger.error("Exception in applyVeraProtection for "+fileName+" :::: " + e.getMessage());
   			logger.error(e.getMessage(), e);
   		} 

   	}

	/**
	 * To read apps vera json file
	 * 
	 * @param file
	 * @return
	 */
	public static String getFileData(File file) {
		StringBuilder str = new StringBuilder();
		BufferedReader bufferedReader = null;
		try {
			bufferedReader = new BufferedReader(new FileReader(file));
			String temp;
			while ((temp = bufferedReader.readLine()) != null) {
				str.append(temp);
			}
		} catch (Exception e) {
			e.getStackTrace();
		} finally {
			try {
				bufferedReader.close();
			} catch (Exception e) {
				e.getStackTrace();
			}
		}
		return str.toString();
	}
	
	/**
	 * To get app vera configs from json file
	 * 
	 * @param userName
	 * @return
	 */
	public String getVersUserProfile(String userName,NodeRef nodeRef) {
		String veraProfile = null;
		logger.info(" :::::: before getVersUserProfile ::::::"+veraUsers.keySet());
		if (veraUsers.containsKey(userName)) {
			veraProfile = veraUsers.get(userName).toString();
		}
		return veraProfile;
	}
	
	 /**
     * 
     * @param nodeRef
     * @param fileName
     * @param res
     * @throws Exception
     */
    public void applyDocExVeraProtection(NodeRef nodeRef, String fileName, final WebScriptResponse res)	throws Exception {

		// Reading the data content of a NodeRef (binary)
		ContentReader reader = registry.getContentService().getReader(nodeRef, ContentModel.PROP_CONTENT);
		InputStream sourceStream = null;
		InputStream veraSecureStream = null;
		try {
			sourceStream = reader.getContentInputStream();
			String alfId=nodeRef.getId();
            String clientDocId=nodeRef.toString();
            long t1 = System.currentTimeMillis();
            veraSecureStream=VeraDocxConnector.secureStream(sourceStream, fileName, alfId, clientDocId);
            logger.info("Vera Ecnryption time***"+(System.currentTimeMillis() - t1));
            long t2 = System.currentTimeMillis();
            String encryptedFileName = fileName+".html";
			res.setHeader("Content-disposition", "attachment; filename="+ URLEncoder.encode(encryptedFileName,"UTF-8").replaceAll("\\+", "%20"));
			res.setHeader("irm-filename", encryptedFileName);
			res.setContentType("text/html");
			ByteArrayOutputStream memoryOutputStream = null;
			 try {
				 //1 read into memory to make sure sourceStream can be properly consumed
				 memoryOutputStream = new ByteArrayOutputStream();
		        	byte[] buf = new byte[4096];
		        	int bytesRead = 0;
		        	while ((bytesRead = veraSecureStream.read(buf, 0, buf.length)) >= 0){
		        		//2 output source data
		        		memoryOutputStream.write(buf, 0, bytesRead); 
		        	}
		        	memoryOutputStream.writeTo(res.getOutputStream());
		        	
		        	//byte[] sourceBytes = memoryOutputStream.toByteArray();
		        	//3 create inputSecureStream based on source bytes in memory
		        	logger.info("Reading and writing the encrypted content to response time***"+(System.currentTimeMillis() - t2));
		        } finally {
		            if (veraSecureStream != null) 
		            	veraSecureStream.close();
		            
		            if(sourceStream != null){
		            	sourceStream.close();
		            }
		            if(memoryOutputStream != null){
		            	memoryOutputStream.close();
		            }
		            if(res.getOutputStream() != null){
		            	res.getOutputStream().close();
		            }
		        }
		} catch (Exception e) {
			logger.error("Exception in applyDocExVeraProtection for "+fileName+" :::: " + e.getMessage());
			logger.error(e.getMessage(), e);
		} 

	}
    
    public boolean isVeraEncryptedDoc(InputStream in) {
		String veraDocId = null;
		 try{
			 String sCurrentLine;
			 BufferedReader br = new BufferedReader(new InputStreamReader(in));
			 while ((sCurrentLine = br.readLine()) != null) {
					String searchString = "docId&quot;:&quot;";
					if(sCurrentLine.contains(searchString)){
						veraDocId = sCurrentLine.substring((sCurrentLine.indexOf(searchString) + searchString.length()), sCurrentLine.indexOf("&quot;,&quot;"));
						//logger.error("veraDocId is : "  + veraDocId);
						sCurrentLine = null;
						break;
					}
				}
			 br.close();
			 if(veraDocId != null && !veraDocId.isEmpty()){
				 return true;
			 }
		 } catch(Exception e){
			 logger.error("isVeraEncryptedDoc error occured : "  + e);
			 e.printStackTrace();
		 }
		 return false;
	}
    
    public String getVeraAppDocId(InputStream in,String userId) throws Exception {
    	String veraProfile = getVersUserProfile(userId,null);
    	String veraDocId = null;
    	if(veraProfile!=null && !veraProfile.isEmpty()){
    		veraDocId=VeraConnector.getMetadataForStream(in, veraProfile);
    		logger.info("veraAppDocId***"+veraDocId);
    	}
    	return veraDocId;
    }
    
	public InputStream getVeraFileContentAsStream(InputStream in, String userId, String veraDocId) throws Exception {
		InputStream content = null;
		try {
			InputStreamContent unsecureFile = unsecureVeraAppInputStream(in, userId);
			if (unsecureFile != null) {
				content = unsecureFile.getInputStream();
			} else {
				logger.info("Exception occured while Unsecuring the vera secured file");
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return content;
	}
 
 public boolean checkUserAccess(InputStream in,String userId,String veraDocId) throws Exception {
	 	//logger.info("InputStream**********"+in.available());
		boolean checkUserAccess = false;
		List<String> allowedList= new ArrayList<String>(3);
		allowedList.add("TKL-Editor");
		logger.info("veraDocId***"+veraDocId + " ;userId : " + userId);
		if(veraDocId != null){
			 String veraProfile = getVersUserProfile(userId,null);
			 if(veraProfile!=null && !veraProfile.isEmpty()){
			String policyName=VeraConnector.getDocPolicies(veraDocId, userId,veraProfile);
			logger.info("Vera PolicyName *** "+policyName);
			if(policyName != null && allowedList.contains(policyName)){ 
				checkUserAccess = true;
			} else {
				logger.error("checkUserAccess()::PocicyName "+ policyName);
			}
			checkUserAccess = true;
			 }else{
				 checkUserAccess = false;
			 }
		} else {
			checkUserAccess = false;
			logger.error("checkUserAccess()::Vera Doc Id is null "+ veraDocId);
		}
		return checkUserAccess;
	}
 
	public InputStreamContent unsecureVeraAppInputStream(InputStream sourceStream, String userId) throws Exception {
		String veraProfile = getVersUserProfile(userId, null);
		InputStream unsecureStream = null;
		InputStreamContent isc = null;
		if (veraProfile != null && !veraProfile.isEmpty()) {
			unsecureStream = VeraConnector.unsecureInputStream(sourceStream, veraProfile);
			isc = new InputStreamContent(unsecureStream, "", "UTF-8");
		}
		return isc;
	}

}



