package org.alfresco.repo.action.executer;


import org.alfresco.error.AlfrescoRuntimeException;
import org.springframework.extensions.surf.util.I18NUtil;

public class CiscoMailActionExecuterMonitor
{
    private CiscoMailActionExecuter ciscoMailActionExecuter;
    
    
    public String sendTestMessage()
    {
        try
        {
        	ciscoMailActionExecuter.sendTestMessage();
            Object[] params = {ciscoMailActionExecuter.getTestMessageTo()};
            String message = I18NUtil.getMessage("email.outbound.test.send.success", params);
            return message;
        }
        catch
        (AlfrescoRuntimeException are)
        {
            return (are.getMessage());
        }
    }
    
    public int getNumberFailedSends()
    {
        return ciscoMailActionExecuter.getNumberFailedSends();
    }
    
    public int getNumberSuccessfulSends()
    {
        return ciscoMailActionExecuter.getNumberSuccessfulSends();
    }
    
    
    public void setCiscoMailActionExecuter(CiscoMailActionExecuter ciscoMailActionExecuter)
    {
        this.ciscoMailActionExecuter = ciscoMailActionExecuter;
    }
}
