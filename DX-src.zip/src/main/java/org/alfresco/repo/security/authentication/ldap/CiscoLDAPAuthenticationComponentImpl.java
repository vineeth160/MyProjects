/*
 * Copyright (C) 2005-2010 Alfresco Software Limited.
 * 
 * This file is part of Alfresco
 * 
 * Alfresco is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * Alfresco is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Lesser General Public License along with Alfresco. If not, see
 * <http://www.gnu.org/licenses/>.
 */
package org.alfresco.repo.security.authentication.ldap;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.LdapContext;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.audit.AuditComponent;
import org.alfresco.repo.security.authentication.AuthenticationException;
import org.alfresco.repo.security.sync.ldap.LDAPNameResolver;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.log4j.Logger;
import org.jasypt.exceptions.EncryptionOperationNotPossibleException;

import com.cisco.alfresco.auth.ext.EXTEncrypter;


/**
 * Authenticates a user by LDAP. To convert the user name to an LDAP DN, it uses the fixed format in
 * <code>userNameFormat</code> if set, or calls the {@link LDAPNameResolver} otherwise.
 * 
 * @author Andy Hind
 */
public class CiscoLDAPAuthenticationComponentImpl extends LDAPAuthenticationComponentImpl
{
    Logger logger = Logger.getLogger(this.getClass());
    private final String LDAP_FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
    private final String LDAP_CONTROL_FACTORY = "com.sun.jndi.ldap.ControlFactory";
    private final String SEARCH_BASE = "OU=Standard,OU=Cisco Groups,DC=cisco,DC=com";

    private String ldapURL;
    private String ldapUsername;
    private String ldapCreds;
    private String ldapAuthentication;
    private String ciscoEncryptDecryptKey;
    @SuppressWarnings("unused")
	private String ciscossourl;
    private AuditComponent auditComponent;

    /**
     * 
     * @param ciscoSSOUrl
     */
    public void setCiscossourl(String ciscossourl)
    {
        this.ciscossourl = ciscossourl;
    }
    

	public void setAuditComponent(AuditComponent auditComponent) {
		this.auditComponent = auditComponent;
	}



	/**
     * 
     * @param ldapURL
     */
    public void setLdapURL(String ldapURL)
    {
        this.ldapURL = ldapURL;
    }

    /**
     * 
     * @param ldapUsername
     */
    public void setLdapUsername(String ldapUsername)
    {
        this.ldapUsername = ldapUsername;
    }

    /**
     * 
     * @param ldapCreds
     */
    public void setLdapCreds(String ldapCreds)
    {
        this.ldapCreds = ldapCreds;
    }

    
    
    /**
     * 
     * @param ldapAuthentication
     */
    public void setLdapAuthentication(String ldapAuthentication)
    {
        this.ldapAuthentication = ldapAuthentication;
    }

    /**
     * 
     * @param ldapCreds
     */
    public void setCiscoEncryptDecryptKey(String ciscoEncryptDecryptKey)
    {
        this.ciscoEncryptDecryptKey = ciscoEncryptDecryptKey;
    }

    /**
     * 
     * @param ldapUsername
     */
    public String getCiscoEncryptDecryptKey(String ciscoEncryptDecryptKey)
    {
       return this.ciscoEncryptDecryptKey;
    }

    
    @Override
    protected void authenticateImpl(String userName, char[] password) throws AuthenticationException
    {

        System.out.println("starting auth check");
       
        // **************************************** Code to be uncommented for OAM ***********************************//
        // Check whether the given password is OAM cookie or normal password
        boolean isOam = isOAMCookie(userName, new String(password));
        System.out.println("isOam:" + isOam);
        if (isOam)
        {

            System.out.println("setting userName");
            setCurrentUser(userName);
            //record user info into user-access audit table
            if(userName!= null && !userName.equalsIgnoreCase("admin") && !userName.equalsIgnoreCase("ciscoadmin.gen")){
         		recordAuditInfo(userName.trim(), "Login");
             }
        }
        else
        {
            try {
				if (isInDenyGroup(userName))
				    throw new AuthenticationException("Unable to authenticate user.");
			} catch (UnknownHostException | UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            System.out.println("default one");
            super.authenticateImpl(userName, password);
          
        }

        // **************************************** Code to be uncommented for OAM ***********************************//

        /*
         * if( isInDenyGroup(userName) ) throw new AuthenticationException("Unable to authenticate user.");
         * System.out.println("default one"); super.authenticateImpl(userName, EXTEncrypter.decrypt(new
         * String(password)).toCharArray());
         */
    }

    /**
     * Method to check given password is OAM cookie or not
     * 
     * @param password
     * @return
     * @throws UnknownHostException 
     */
    private boolean isOAMCookie(String userName, String password)  
    {

    	//return true;
    	
    	try {
			//if(password.indexOf(' ')==-1) return isOam;
			String decPassword = EXTEncrypter.decrypt(password,ciscoEncryptDecryptKey); 

			if(decPassword != null && decPassword.indexOf(" ObSSOCookie=") >= 0)
				return true; 
			else {
				return false;
			}
		} catch(EncryptionOperationNotPossibleException e) {
			logger.info(e.getMessage());
		} catch(UnknownHostException e){
			logger.info(e.getMessage());
		} catch(Exception e){
			logger.info(e.getMessage());
		}
    	return false;
    }

/*    private boolean isOAMCookieOld(String userName, String password)
    {

        System.out.println("SSO URL:" + ciscossourl);

        OAMValidation oamValidation = new OAMValidation();
        String oamUserName = oamValidation.getOAMAuthenticatedUser(password, ciscossourl);

        if (userName.equals(oamUserName))
        {
            System.out.println("Logged in User is OAM User");
            return true;
        }
        else
            return false;
    }*/

    protected boolean isInDenyGroup(String username) throws UnsupportedEncodingException, UnknownHostException
    {
    	
        boolean denied = false;
        String strUserName = ldapUsername;        
        String strPassword = ldapCreds;        
        Hashtable hashTableEnv = new Hashtable();
    	hashTableEnv.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
    	hashTableEnv.put(Context.PROVIDER_URL, ldapURL); 
    	hashTableEnv.put(Context.SECURITY_PRINCIPAL, ldapUsername);     	
    	hashTableEnv.put(Context.SECURITY_CREDENTIALS, EXTEncrypter.decrypt(ldapCreds,ciscoEncryptDecryptKey).getBytes("UTF8"));
        hashTableEnv.put(Context.STATE_FACTORIES, "GroupStateFactory");

        try
        {        	
            DirContext context = new InitialDirContext(hashTableEnv);            
            SearchControls ctrl = new SearchControls();
            ctrl.setSearchScope(SearchControls.SUBTREE_SCOPE);
            String[] attrIDs =
            { "member" };
            ctrl.setReturningAttributes(attrIDs);
            String filter = "CN=edcsdeny";
            NamingEnumeration<SearchResult> enumSearchResult = context.search(SEARCH_BASE, filter, ctrl);            
            while (enumSearchResult.hasMore() && !denied)
            {
            	
                Attributes attrs = ((SearchResult) enumSearchResult.next()).getAttributes();                
                Attribute members = attrs.get("member");                
                if (members !=null){
                for (int i = 0; i < members.size() && !denied; i++)
                {
                    Object member = members.get(i);
                    if (member != null)
                    {
                        denied = member.toString().contains("CN=" + username);
                    }
                }
            } else{
            	denied = false;
            	break;
            }
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        if (denied)
        {
            Logger.getRootLogger().error("A black-listed user has attemped to log in: " + username);
            clearCurrentSecurityContext();
        }

        return denied;
    }
    
    /**
	 * record user access login info
	 * 
	 * @param userName
	 * @param accessType
	 */
	
	 private void recordAuditInfo(String userName, String accessType) {
		 System.out.println(" Audit info is started......"); 
		 String company 				= null;
		 NodeRef person =  this.getPersonService().getPerson(userName);
		 company = (String) this.getNodeService().getProperty(person, ContentModel.PROP_ORGANIZATION);
		 if(company == null){
			company = "";
		 }
		 System.out.println(" Company :"+company);
		 Map<String, Serializable> auditValues = new HashMap<String, Serializable>();
		 auditValues.put("username", userName); 
		 auditValues.put("accesstype", accessType);
		 auditValues.put("company", company);
		 auditComponent.recordAuditValues("/user-access/details", auditValues); 
		 System.out.println(" Audit was completed successfully....");
		 
	  }

}