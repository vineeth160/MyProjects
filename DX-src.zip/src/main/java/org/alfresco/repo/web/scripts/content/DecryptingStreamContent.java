package org.alfresco.repo.web.scripts.content;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Map;

import org.alfresco.repo.content.ContentStore;
import org.alfresco.repo.content.MimetypeMap;
import org.alfresco.repo.content.filestore.DecryptingFileContentReader;
import org.alfresco.repo.content.filestore.EncryptingFileContentStore;
import org.alfresco.repo.content.filestore.FileContentStore;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;


/**
 * Decorator for StreamContent to include the custom Encryption module.
 * 
 * @author mumuthar
 * 
 */
public class DecryptingStreamContent extends StreamContent
{

    private static final Log logger = LogFactory.getLog(DecryptingStreamContent.class);

    private EncryptingFileContentStore encryptingFileContentStore;

    @Override
    protected void streamContent(WebScriptRequest req, WebScriptResponse res, File file, boolean attach,
            String attachFileName, Map<String, Object> model) throws IOException
    {
        if (logger.isDebugEnabled())
            logger.debug("Retrieving content from file " + file.getAbsolutePath() + " (attach: " + attach + ")");

        // determine mimetype from file extension
        String filePath = file.getAbsolutePath();
        String mimetype = MimetypeMap.MIMETYPE_BINARY;
        int extIndex = filePath.lastIndexOf('.');
        if (extIndex != -1)
        {
            mimetype = mimetypeService.getMimetype(filePath.substring(extIndex + 1));
        }

        // setup file reader and stream
        DecryptingFileContentReader reader = null;
        try
        {
            reader = new DecryptingFileContentReader(file, FileContentStore.STORE_PROTOCOL
                    + ContentStore.PROTOCOL_DELIMITER + file.getAbsolutePath(), getEncryptingFileContentStore()
                    .getKeyStoreLocation());
        }
        catch (Exception e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        reader.setMimetype(mimetype);
        reader.setEncoding("UTF-8");

        long lastModified = file.lastModified();
        Date lastModifiedDate = new Date(lastModified);

        streamContentImpl(req, res, reader, null, null, attach, lastModifiedDate,
            String.valueOf(lastModifiedDate.getTime()), attachFileName, model);
    }

    public EncryptingFileContentStore getEncryptingFileContentStore()
    {
        return encryptingFileContentStore;
    }

    public void setEncryptingFileContentStore(EncryptingFileContentStore encryptingFileContentStore)
    {
        this.encryptingFileContentStore = encryptingFileContentStore;
    }

}
