package org.alfresco.repo.content.filestore;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import org.alfresco.repo.content.AbstractContentWriter;
import org.alfresco.repo.content.ContentStore;
import org.alfresco.service.cmr.repository.ContentIOException;
import org.alfresco.service.cmr.repository.ContentReader;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;


/**
 * Extends OOTB, local File writing to use encryption.
 * 
 * US4446-Rewrote the class to be derived from the Abstract layer.
 * 
 * @author adschwar, mumuthar
 */
public class EncryptingFileContentWriter extends AbstractContentWriter
{

    private File sizeFile;
    protected long totalBytes = -1;

    private Cipher mEncipher = null;
    private String keyStoreLocation;

    private File file;
    private boolean allowRandomAccess;

    /**
     * Constructor that builds a URL based on the absolute path of the file.
     * 
     * @param file
     *            the file for writing. This will most likely be directly related to the content URL.
     */
    public EncryptingFileContentWriter(File file)
    {
        this(file, null);
    }

    /**
     * Constructor that builds a URL based on the absolute path of the file.
     * 
     * @param file
     *            the file for writing. This will most likely be directly related to the content URL.
     * @param existingContentReader
     *            a reader of a previous version of this content
     */
    public EncryptingFileContentWriter(File file, ContentReader existingContentReader)
    {
        this(file, FileContentStore.STORE_PROTOCOL + ContentStore.PROTOCOL_DELIMITER + file.getAbsolutePath(),
                existingContentReader);
    }

    /**
     * Constructor that explicitely sets the URL that the reader represents.
     * 
     * @param file
     *            the file for writing. This will most likely be directly related to the content URL.
     * @param url
     *            the relative url that the reader represents
     * @param existingContentReader
     *            a reader of a previous version of this content
     */
    public EncryptingFileContentWriter(File file, String url, ContentReader existingContentReader)
    {
        super(url, existingContentReader);

        this.file = file;
        allowRandomAccess = true;
    }

    public EncryptingFileContentWriter(File file, String url, ContentReader existingContentReader,
            String keyStoreLocation)
    {
        super(url, existingContentReader);

        // super(file, url, existingContentReader);
        this.keyStoreLocation = keyStoreLocation;
        this.file = file;
        this.allowRandomAccess = true;

        try
        {
            setupEncrypt();
        }
        catch (Exception e)
        {
            Logger.getRootLogger().fatal("Unable to setup encryption.", e);
        }
    }

    public void setupEncrypt()
    {
        Logger.getRootLogger().debug("In EncryptingFileContentWriter setupEncrypt");
        sizeFile = new File(getFile().getAbsolutePath() + ".size");
        File ivFile = new File(getFile().getAbsolutePath() + ".iv");
        byte[] initVec = null;
        if (ivFile.exists())
        {
            try
            {
                initVec = IOUtils.toByteArray(new FileInputStream(ivFile));
            }
            catch (FileNotFoundException e)
            {
                // TODO Auto-generated catch block
                Logger.getRootLogger().error("unbale to read ivFile  " + e);
            }
            catch (IOException e)
            {
                // TODO Auto-generated catch block
                Logger.getRootLogger().error("unbale to read ivFile  " + e);
            }
        }
        else
        {
            SecureRandom ranGen = new SecureRandom(); // FIXME: THIS SHOULD BE A
                                                      // STATIC INSTANCE SO IT
                                                      // DOESN'T RE-SEED
            byte[] iv = new byte[16];
            ranGen.nextBytes(iv);

            initVec = iv;
        }
        KeyStore ks = null;
        try
        {
            ks = KeyStore.getInstance("JCEKS");
        }
        catch (KeyStoreException e1)
        {
            e1.printStackTrace();
        }

        // get user password and file input stream
        char[] password = "password".toCharArray();
        java.io.FileInputStream fis = null;
        try
        {
            fis = new java.io.FileInputStream(this.keyStoreLocation);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
            Logger.getRootLogger().error("unbale to read keyStoreFile  " + e);
        }
        try
        {
            ks.load(fis, password);
        }
        catch (NoSuchAlgorithmException e1)
        {
            Logger.getRootLogger().error(e1);
        }
        catch (CertificateException e1)
        {
            Logger.getRootLogger().error(e1);
        }
        catch (IOException e1)
        {
            Logger.getRootLogger().error(e1);
        }

        SecretKey secret = null;
        try
        {
            secret = (SecretKey) ks.getKey("contentEncSecretKey", "password".toCharArray());
        }
        catch (UnrecoverableKeyException e1)
        {
            Logger.getRootLogger().error(e1);
        }
        catch (KeyStoreException e1)
        {
            Logger.getRootLogger().error(e1);
        }
        catch (NoSuchAlgorithmException e1)
        {
            Logger.getRootLogger().error(e1);
        }

        try
        {
            fis.close();
        }
        catch (IOException e1)
        {
            e1.printStackTrace();
        }

        try
        {
            mEncipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "BC");
        }
        catch (NoSuchProviderException e)
        {
            Logger.getRootLogger().error(e);
            e.printStackTrace();
        }
        catch (NoSuchAlgorithmException e)
        {
            Logger.getRootLogger().error(e);
            e.printStackTrace();
        }
        catch (NoSuchPaddingException e)
        {
            Logger.getRootLogger().error(e);
            e.printStackTrace();
        }
        try
        {
            mEncipher.init(Cipher.ENCRYPT_MODE, secret, new IvParameterSpec(initVec));
        }
        catch (InvalidKeyException e)
        {
            Logger.getRootLogger().error(e);
            e.printStackTrace();
        }
        catch (InvalidAlgorithmParameterException e)
        {
            Logger.getRootLogger().error(e);
            e.printStackTrace();
        }

        if (!ivFile.exists())
            try
            {
                FileOutputStream ivOut = new FileOutputStream(ivFile);
                IOUtils.copy(new ByteArrayInputStream(initVec), ivOut);
                ivOut.flush();
                ivOut.close();
            }
            catch (FileNotFoundException e)
            {
                // TODO Auto-generated catch block
                Logger.getRootLogger().error(e);
            }
            catch (IOException e)
            {
                // TODO Auto-generated catch block
                Logger.getRootLogger().error(e);
            }
    }

    @Override
    public OutputStream getContentOutputStream() throws ContentIOException
    {
        OutputStream os = super.getContentOutputStream();
        if (mEncipher != null)
        {
            totalBytes = 0;
            CipherOutputStream cos = new CipherOutputStream(os, mEncipher)
            {

                @Override
                public void write(byte[] b, int off, int len) throws IOException
                {
                    totalBytes += Long.valueOf(len);
                    super.write(b, off, len);
                }

                @Override
                public void write(int b) throws IOException
                {
                    totalBytes++;
                    super.write(b);
                }

                @Override
                public void close() throws IOException
                {
                    if (sizeFile != null && totalBytes > -1)
                    {
                        try
                        {
                            FileWriter writer = new FileWriter(sizeFile);
                            writer.write(String.valueOf(totalBytes));
                            writer.close();
                        }
                        catch (Exception e)
                        {
                            Logger.getRootLogger().error("Unable to commit size file. Download will be wonky.", e);
                        }
                    }
                    super.close();
                }
            };

            return cos;
        }

        return os;
    }

    /**
     * The URL of the write is known from the start and this method contract states that no consideration needs to be
     * taken w.r.t. the stream state.
     */
    @Override
    protected ContentReader createReader() throws ContentIOException
    {
        DecryptingFileContentReader reader = new DecryptingFileContentReader(this.file, getContentUrl());
        reader.setAllowRandomAccess(this.allowRandomAccess);
        return reader;
    }

    /* package */void setAllowRandomAccess(boolean allow)
    {
        this.allowRandomAccess = allow;
    }

    @Override
    protected WritableByteChannel getDirectWritableChannel() throws ContentIOException
    {
        try
        {
            // we may not write to an existing file - EVER!!
            if (file.exists() && file.length() > 0)
            {
                throw new IOException("File exists - overwriting not allowed");
            }
            // create the channel
            WritableByteChannel channel = null;
            if (allowRandomAccess)
            {
                RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rw"); // will create it
                channel = randomAccessFile.getChannel();
            }
            else
            {
                OutputStream os = new FileOutputStream(file);
                channel = Channels.newChannel(os);
            }
            // done
            if (Logger.getRootLogger().isDebugEnabled())
            {
                Logger.getRootLogger().debug(
                    "Opened write channel to file: \n" + "   file: " + file + "\n" + "   random-access: "
                            + allowRandomAccess);
            }
            return channel;
        }
        catch (Throwable e)
        {
            throw new ContentIOException("Failed to open file channel: " + this, e);
        }
    }

    /**
     * @return Returns true always
     */
    public boolean canWrite()
    {
        return true; // this is a writer
    }

    /**
     * @return Returns the file that this writer accesses
     */
    public File getFile()
    {
        return file;
    }

    /**
     * @return Returns the size of the underlying file or
     */
    public long getSize()
    {
        if (file == null)
            return 0L;
        else if (!file.exists())
            return 0L;
        else
            return file.length();
    }

}
