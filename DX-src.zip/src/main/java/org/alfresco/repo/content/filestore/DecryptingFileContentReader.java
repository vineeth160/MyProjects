package org.alfresco.repo.content.filestore;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.text.MessageFormat;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import org.alfresco.repo.content.AbstractContentReader;
import org.alfresco.repo.content.ContentStore;
import org.alfresco.repo.content.MimetypeMap;
import org.alfresco.service.cmr.repository.ContentIOException;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.FileContentReader;
import org.alfresco.util.TempFileProvider;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;


/**
 * Extends OOTB, local File reading to use decryption, when necessary.
 * 
 * US446- Rewrote the DecryptingFileContentReader to be derived from the abstract layer.
 * 
 * @author adschwar, mumuthar
 * 
 * 
 */
public class DecryptingFileContentReader extends AbstractContentReader
{

    private Cipher mDecipher = null;
    private String keyStoreLocation;

    public static final String MSG_MISSING_CONTENT = "content.content_missing";

    private static final Log logger = LogFactory.getLog(FileContentReader.class);

    private File file;
    private boolean allowRandomAccess;

    /**
     * Checks the existing reader provided and replaces it with a reader onto some fake content if required. If the
     * existing reader is invalid, an debug message will be logged under this classname category.
     * <p>
     * It is a convenience method that clients can use to cheaply get a reader that is valid, regardless of whether the
     * initial reader is valid.
     * 
     * @param existingReader
     *            a potentially invalid reader or null
     * @param msgTemplate
     *            the template message that will used to format the final <i>fake</i> content
     * @param args
     *            arguments to put into the <i>fake</i> content
     * @return Returns a the existing reader or a new reader onto some generated text content
     */
    public static ContentReader getSafeContentReader(ContentReader existingReader, String msgTemplate, Object... args)
    {
        ContentReader reader = existingReader;
        if (existingReader == null || !existingReader.exists())
        {
            // the content was never written to the node or the underlying content is missing
            String fakeContent = MessageFormat.format(msgTemplate, args);

            // log it
            if (logger.isDebugEnabled())
            {
                logger.debug(fakeContent);
            }

            // fake the content
            File tempFile = TempFileProvider.createTempFile("getSafeContentReader_", ".txt");
            ContentWriter writer = new FileContentWriter(tempFile);
            writer.setMimetype(MimetypeMap.MIMETYPE_TEXT_PLAIN);
            writer.setEncoding("UTF-8");
            writer.putContent(fakeContent);
            // grab the reader from the temp writer
            reader = writer.getReader();
        }
        // done
        if (logger.isDebugEnabled())
        {
            logger.debug("Created safe content reader: \n" + "   existing reader: " + existingReader + "\n"
                    + "   safe reader: " + reader);
        }
        return reader;
    }

    /**
     * Constructor that builds a URL based on the absolute path of the file.
     * 
     * @param file
     *            the file for reading. This will most likely be directly related to the content URL.
     */
    public DecryptingFileContentReader(File file)
    {
        this(file, FileContentStore.STORE_PROTOCOL + ContentStore.PROTOCOL_DELIMITER + file.getAbsolutePath());
    }

    public DecryptingFileContentReader(File file, String url)
    {
        super(url);

        this.file = file;
        allowRandomAccess = true;
    }

    public DecryptingFileContentReader(File file, String url, String keyStoreLocation) throws Exception
    {
        // super(file, url);
        super(url);
        this.keyStoreLocation = keyStoreLocation;
        this.file = file;
        allowRandomAccess = true;
        setupDecrypt();
    }

    public void setupDecrypt() throws Exception
    {
        Logger.getRootLogger().debug("In DecryptingFileContentReader setupDecrypt");
        File ivFile = null;
        if (getFile() != null)
        {
            ivFile = new File(getFile().getAbsolutePath() + ".iv");
        }
        if (ivFile != null && ivFile.exists())
        {
            byte[] initVec = IOUtils.toByteArray(new FileInputStream(ivFile));

            KeyStore ks = null;
            try
            {
                ks = KeyStore.getInstance("JCEKS");
            }
            catch (KeyStoreException e1)
            {
                e1.printStackTrace();
                Logger.getRootLogger().error("Unable to get keystore" + e1);
            }

            // get user password and file input stream
            char[] password = "password".toCharArray();
            java.io.FileInputStream fis = null;
            try
            {
                fis = new java.io.FileInputStream(this.keyStoreLocation);
            }
            catch (FileNotFoundException e)
            {
                e.printStackTrace();
                Logger.getRootLogger().error("Unable to read keystore file" + e);
            }
            try
            {
                ks.load(fis, password);
            }
            catch (NoSuchAlgorithmException e)
            {
                e.printStackTrace();
                Logger.getRootLogger().error(e);
            }
            catch (CertificateException e)
            {
                e.printStackTrace();
                Logger.getRootLogger().error(e);
            }
            catch (IOException e)
            {
                e.printStackTrace();
                Logger.getRootLogger().error(e);
            }

            SecretKey secret = null;
            try
            {
                secret = (SecretKey) ks.getKey("contentEncSecretKey", "password".toCharArray());
            }
            catch (UnrecoverableKeyException e1)
            {
                e1.printStackTrace();
                Logger.getRootLogger().error(e1);
            }
            catch (KeyStoreException e1)
            {
                e1.printStackTrace();
                Logger.getRootLogger().error(e1);
            }
            catch (NoSuchAlgorithmException e1)
            {
                e1.printStackTrace();
                Logger.getRootLogger().error(e1);
            }

            try
            {
                fis.close();
            }
            catch (IOException e1)
            {
                Logger.getRootLogger().error(e1);
                e1.printStackTrace();
            }
            try
            {
                mDecipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "BC");
            }
            catch (NoSuchProviderException e)
            {
                e.printStackTrace();
            }
            mDecipher.init(Cipher.DECRYPT_MODE, secret, new IvParameterSpec(initVec));
        }
    }

    @Override
    public InputStream getContentInputStream() throws ContentIOException
    {
        InputStream is = super.getContentInputStream();
        if (mDecipher != null)
        {
            CipherInputStream cis = new CipherInputStream(is, mDecipher);
            return new BufferedInputStream(cis);
        }
        else
        {
            return is;
        }
    }

    /* package */void setAllowRandomAccess(boolean allow)
    {
        this.allowRandomAccess = allow;
    }

    /**
     * @return Returns the file that this reader accesses
     */
    public File getFile()
    {
        return file;
    }

    /**
     * @return Whether the file exists or not
     */
    public boolean exists()
    {

        return file.exists();

    }

    /**
     * @see File#lastModified()
     */
    public long getLastModified()
    {
        if (!exists())
        {
            return 0L;
        }
        else
        {
            return file.lastModified();
        }
    }

    /**
     * The URL of the write is known from the start and this method contract states that no consideration needs to be
     * taken w.r.t. the stream state.
     */
    @Override
    protected ContentReader createReader() throws ContentIOException
    {
        DecryptingFileContentReader reader = new DecryptingFileContentReader(this.file, getContentUrl());
        reader.setAllowRandomAccess(this.allowRandomAccess);
        return reader;
    }

    @Override
    protected ReadableByteChannel getDirectReadableChannel() throws ContentIOException
    {
        try
        {
            // the file must exist
            if (!file.exists())
            {
                throw new IOException("File does not exist: " + file);
            }
            // create the channel
            ReadableByteChannel channel = null;
            if (allowRandomAccess)
            {
                RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r"); // won't create it
                channel = randomAccessFile.getChannel();
            }
            else
            {
                InputStream is = new FileInputStream(file);
                channel = Channels.newChannel(is);
            }
            // done
            if (logger.isDebugEnabled())
            {
                logger.debug("Opened read channel to file: \n" + "   file: " + file + "\n" + "   random-access: "
                        + allowRandomAccess);
            }
            return channel;
        }
        catch (Throwable e)
        {
            throw new ContentIOException("Failed to open file channel: " + this, e);
        }
    }

    /**
     * @return Returns false as this is a reader
     */
    public boolean canWrite()
    {
        return false; // we only allow reading
    }

    @Override
    public long getSize()
    {
        File sizeFile = new File(getFile().getAbsoluteFile() + ".size");
        if (sizeFile.exists())
        {
            try
            {
                String size = IOUtils.toString(new FileInputStream(sizeFile)).trim();
                return Long.parseLong(size);
            }
            catch (Exception e)
            {
                Logger.getRootLogger().error(
                    "Unable to determine file size from .size file. Returning encrypted size instead.");
                return getFile().length();
            }
        }
        else
        {
            if (!exists())
            {
                return 0L;
            }
            else
            {
                return file.length();
            }
        }
    }
}
