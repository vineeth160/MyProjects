<import resource="classpath:alfresco/web-extension/site-webscripts/com/bh/datagrids/generic-dynamic-datagrid-widget-generator.lib.js">
//widgetUtils.deleteObjectFromArray(model.jsonModel, "id", "FCTSRCH_SET_ALL_SITES_SCOPE");
//widgetUtils.deleteObjectFromArray(model.jsonModel, "id", "FCTSRCH_SET_REPO_SCOPE");
var viewOptions = widgetUtils.findObject(model.jsonModel, "id", "FCTSRCH_VIEWS_MENU");
viewOptions.config.label="View Options";
var titleMenu = widgetUtils.findObject(model.jsonModel, "id", "HEADER_TITLE_MENU");
if( user.isAdmin)
{
var searchManagerUrl = "dp/ws/faceted-search-config";
   if (page.url.templateArgs.site)
   {
      searchManagerUrl = "site/" + page.url.templateArgs.site + "/" + searchManagerUrl;
   }
   var searchConfigMenuItem = {
      id: "FCTSRCH_CONFIG_PAGE_LINK",
      name: "alfresco/menus/AlfMenuBarItem",
      config: {
         label: msg.get("faceted-search-config.label"),
         title: msg.get("faceted-search.config.link"),
         targetUrl: searchManagerUrl
      }
   };
   titleMenu.config.widgets.splice(0, 0, searchConfigMenuItem);
}
var searchResultsWidget = widgetUtils.findObject(model.jsonModel, "id", "FCTSRCH_RESULTS_MENU");
var alfSearchResult = widgetUtils.findObject(model.jsonModel, "id", "FCTSRCH_SEARCH_RESULT");
var searchTopMenuBar = widgetUtils.findObject(model.jsonModel, "id", "FCTSRCH_TOP_MENU_BAR");
alfSearchResult.config.showSelector=true;

var searchTableConfiguration = getDataTableWidgets("tableView");
var searchResultsListWidget = widgetUtils.findObject(model.jsonModel.widgets, "id", "FCTSRCH_SEARCH_RESULTS_LIST");
searchResultsListWidget.config.view = "BH QMS Smart View";
var row = {
name: "alfresco/lists/views/layouts/Row",
config: {
widgets: searchTableConfiguration.cellWidgets
}
};

var searchTableView = {
name: "bhWidgets/tableView",
id : "DEFAULT_TABLE_SEARCH_VIEW",
config : {
additionalCssClasses : "search-table-view",
dataFullyLoadedPublishTopic: searchTableConfiguration.refreshColumnsVisibilityPublishTopic,
widgets: [row],
widgetsForHeader: searchTableConfiguration.headerWidgets
}
}

var result = remote.call("/com/bh/isQMSSiteMemebr");
	if (result.status.code == status.STATUS_OK) {
		var isQMSSiteMember = JSON.parse(result).isQMSSiteMember;
		if(isQMSSiteMember == "true" || page.url.templateArgs.site == "bh-qms-documents"){
			searchResultsListWidget.config.widgets.splice(2, 0, searchTableView);
		}
    }