//<import resource="classpath:alfresco/site-webscripts/org/alfresco/components/data-lists/datagrid.get.js">
// The above import allows us to reuse Alfresco original dnd-upload component web script.
// When end user overrides via web-extension directory, this won't pick up the override.
// This is a drawback of Alfresco JS importing.

//model.widgets[0].name = "bh.component.DataGrid";

function main()
{
   // Actions
   var actionSet = [],
      myConfig = new XML(config.script),
      xmlActionSet = myConfig.actionSet;

   for each (var xmlAction in xmlActionSet.action)
   {
      actionSet.push(
      {
         id: xmlAction.@id.toString(),
         type: xmlAction.@type.toString(),
         permission: xmlAction.@permission.toString(),
         href: xmlAction.@href.toString(),
         label: xmlAction.@label.toString()
      });
   }

   model.actionSet = actionSet;
   
   // Widget instantiation metadata...
   var dataGrid = {
      id : "DataGrid", 
      name : "bh.component.DataGrid",
      options : {
         siteId : (page.url.templateArgs.site != null) ? page.url.templateArgs.site : "",
         containerId : template.properties.container != null ? template.properties.container : "dataLists",
         usePagination : (args.pagination == "true")
      }
   };
   model.widgets = [dataGrid];
}

main();