model.dname="QMS Documents Advanced Search";

function main()
{
   // Component definition
   var qmsAdvancedSearchDashlet = {
      id: "qmsAdvancedSearchDashlet",
      name: "Alfresco.qmsAdvancedSearchDashlet",
	  options : {
         username: user.name
      }
   };
   model.widgets = [qmsAdvancedSearchDashlet];
}


main();