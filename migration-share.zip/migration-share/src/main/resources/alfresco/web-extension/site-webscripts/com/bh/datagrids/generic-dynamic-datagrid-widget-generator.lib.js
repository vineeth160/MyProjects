
function getDataTableWidgets(tableId, actionsHeader, actionsCells) {
var dynamicDataGridsConfig = config.scoped["BHSearchDynamicDataGridsConfig"].dynamicDataGrids;

if (dynamicDataGridsConfig) {
dynamicDataGridsConfig = dynamicDataGridsConfig.getChildren();
for (var i = 0; i < dynamicDataGridsConfig.size(); i++) {
var gridConfig = dynamicDataGridsConfig.get(i)

var gridId = gridConfig.getAttribute("id");

if (gridId == tableId) {
return generateDataTablWidgets(dynamicDataGridsConfig.get(i), actionsHeader, actionsCells);
}
}
}

return {};
}

/**
 * Generates the resulting object for the specified table configuration.
 * 
 * @param tableConfig
 * @param actionsHeader
 * @param actionsCells
 * @returns
 */
function generateDataTablWidgets(tableConfig, actionsHeader, actionsCells) {
var columns = tableConfig.getChildren();

var headerWidgets = [], cellWidgets = [], visibilityConfigCheckableItems = [];

for (var i = 0; i < columns.size(); i++) {
var column = columns.get(i);

headerWidgets.push(getHeaderWidget(column));
cellWidgets.push(getCellWidget(column));
var visibilityConfigCheckableItem = getCheckableVisibilityConfigWidget(column, tableConfig.getAttribute("refreshColumnsVisibilityTopic"), tableConfig.getAttribute("tablePubSubScope"));
if (visibilityConfigCheckableItem != null) {
visibilityConfigCheckableItems.push(visibilityConfigCheckableItem);
}
}

if (actionsHeader && actionsCells) {
if ((typeof actionsHeader === 'object' && actionsHeader.constructor === Array) 
&& (typeof actionsCells === 'object' && actionsCells.constructor === Array)) {
// it's array
for (var index = 0; index < actionsHeader.length; index++) {
headerWidgets.push(actionsHeader[index]);
cellWidgets.push(actionsCells[index]);
}
} else {
headerWidgets.push(actionsHeader);
cellWidgets.push(actionsCells);
}
}

var result = {
headerWidgets: headerWidgets,
cellWidgets: cellWidgets
};

result.checkableColumnsVisibilityConfig = getDropdownWithCheckableItemsWidget(tableConfig, visibilityConfigCheckableItems);

result.refreshColumnsVisibilityPublishTopic = tableConfig.getAttribute("refreshColumnsVisibilityTopic") || null;

return result;
}

function getDropdownWithCheckableItemsWidget(tableConfig, visibilityConfigCheckableItems) {
if (visibilityConfigCheckableItems.length == 0) {
return {};
}

visibilityConfigCheckableItems.splice(0, 0, {
        name: "bhWidgets/AlfCheckableMenuItem",
        config: {
            id: tableConfig.getAttribute("id") + "_SELECT_CLEAR_ALL",
        label: tableConfig.getAttribute("checkableItemSelectClearAllLabel") || "Select / Clear All",
            checked: false,
            closeOnClick: false,
            isSelectClearAllCheckBox: true
        }
    });

return {
name: "alfresco/header/AlfMenuBarPopup",
config: {
   label: tableConfig.getAttribute("checkableItemsDropdownlabel") || "Hide / Unhide columns",
   widgets: [
    {
       name: "alfresco/menus/AlfMenuGroup",
       config: {
           widgets: visibilityConfigCheckableItems,
   style: {
    "overflow-y": "scroll",
    height: "200px"
   }
       }
    }
   ]
   }
    }
}

function getCheckableVisibilityConfigWidget(column, refreshColumnsVisibilityTopic, pubSubScope) {
if (column.getAttribute("hideable") == "true") {
return {
       name: "bhWidgets/AlfCheckableMenuItem",
       config: {
           label: column.getAttribute("headerLabel"),
           value: "checked",
           publishTopic: (pubSubScope || "") + "TOGGLE_VISIBILITY_" + column.getAttribute("id"),
           checked: getInitialValue(column),
           closeOnClick: false,
           // topic that will be published after the new data has been loaded (new page, increased page size, sort, etc...)
           // to re-hide/show appropriate columns based on the user selection
           republishSelectionTopics: [ (pubSubScope || "") + refreshColumnsVisibilityTopic ]
       }
   }
}

return null;
}

function getHeaderWidget(column) {
var headerWidget = {
id: "HEADER_" + column.getAttribute("id"),
name: "alfresco/lists/views/layouts/HeaderCell",
config: {
label: column.getAttribute("headerLabel"),
sortable: isColumnSortable(column)
}
}

// check if we have configured the header with the icon and tooltip
var headerTooltipIconConfig = column.getChild("headerTooltipIconConfig");
if (headerTooltipIconConfig) {
headerWidget.name = "bhWidgets/HeaderCellWithTooltipIcon";
headerWidget.config.tooltipIconUrl = url.context + headerTooltipIconConfig.getChild("tooltipIconUrl").getValue();
headerWidget.config.tooltipIconText = headerTooltipIconConfig.getChild("tooltipIconText").getValue();
}

var sortValue = getSortValue(column);
if (sortValue) {
headerWidget.config.sortValue = sortValue;
}

resolveVisibilityConfig(headerWidget, column);

resolveAdditionalCSSClasses(headerWidget, column, "headerCellCSSClasses");

return headerWidget;
}

function getCellWidget(column) {
var cellWidget = {
        id: "CELL_" + column.getAttribute("id"),
        name: "bhWidgets/Cell",
        config: {
            widgets: getUnderlyingCellWidgets(column),
            style: getCellStyle(column)
        }
};

resolveVisibilityConfig(cellWidget, column);

resolveAdditionalCSSClasses(cellWidget, column, "dataCellCSSClasses");

return cellWidget;
}

function getPubSubScope(obj) {
var pubSubScope = obj.getAttribute("pubSubScope");

if (pubSubScope) {
return pubSubScope;
} else {
return "";
}
}

function resolveAdditionalCSSClasses(cellWidget, column, classesType) {
var additionalCSSClassesConfig = column.getChild("additionalCSSClasses");
if (additionalCSSClassesConfig) {
var classes = additionalCSSClassesConfig.getChild(classesType);
cellWidget.config.additionalCssClasses = classes ? classes.getValue() : "";
}
}

function resolveVisibilityConfig(widget, widgetConfiguration) {
widget.config.visibilityConfig = {
initialValue: getInitialValue(widgetConfiguration)
};

// if column is hideable, bind to specific topics, that will be published from the ckeckable items
if (widgetConfiguration.getAttribute("hideable") == "true") {
widget.config.visibilityConfig.rules = [
{
topic: "TOGGLE_VISIBILITY_" + widgetConfiguration.getAttribute("id"),
attribute: "selected",
is: [
"true"
]
}
]
}
}

function getInitialValue(widgetConfiguration) {
var visibilityConfig = widgetConfiguration.getChild("visibilityConfig");
// if there is no visibility config, hide in the case of column being hideable, show otherwise
if (!visibilityConfig) {
return !(widgetConfiguration.getAttribute("hideable") == "true");
}

var initialValueConfig = visibilityConfig.getChild("initialValue");
if (initialValueConfig) {
var initialValueType = initialValueConfig.getAttribute("type"),
initialValueConfiguredValue = initialValueConfig.getAttribute("value");

if (initialValueType == "boolean") {
return initialValueConfiguredValue;
}
// if evaluator type is function, call the function with the configured name
if (initialValueType == "function") {
return this[initialValueConfiguredValue].call();
}
if (initialValueType == "expression") {
return eval(initialValueConfiguredValue + '');
}
}
return true;
}

function getUnderlyingCellWidgets(column) {
var underlyingWidgets = [];

var cellWidgets = column.getChild("cellWidgets")
if (cellWidgets) {
var cellWidgets = cellWidgets.getChildren("cellWidget");
if (cellWidgets) {
for (var i = 0; i < cellWidgets.size(); i++) {
var cellWidget = cellWidgets.get(i);

var dataCellWidget = getDataCellWidget(cellWidget);
// maybe we have a tooltip configured, in that case adjust generated
// widget and configuration
dataCellWidget = resolveTooltip(dataCellWidget, cellWidget);

underlyingWidgets.push(dataCellWidget);
}
}
}

return underlyingWidgets;
}

/**
 * If we have a tooltip configured for the data cell,
 * wrap the cell with tooltip and transfer cell visibility config if it exists
 * to the tooltip.
 * 
 * @param dataCellWidget
 * @param cellWidget
 * @returns
 */
function resolveTooltip(dataCellWidget, cellWidgetConfig) {
var tooltipWidgetConfig = cellWidgetConfig.getChild("widgetForTooltip");
if (tooltipWidgetConfig) {
var widgetForTooltip = getDataCellWidget(tooltipWidgetConfig),
   dataCellRenderFilter = dataCellWidget.config.renderFilter,
   dataCellVisibilityConfig = dataCellWidget.config.visibilityConfig;


dataCellWidget = {
name: "alfresco/misc/AlfTooltip",
        config: {
           widgets: [
            dataCellWidget
           ],
           widgetsForTooltip: [
            widgetForTooltip
           ],
           renderFilter: dataCellRenderFilter || [],
           visibilityConfig: dataCellVisibilityConfig || {}
        }   
        }
    }

return dataCellWidget;
}

function getDataCellWidget(cellWidget) {
var dataCellType = cellWidget.getAttribute("type") + ""; // convert java string to JS string for the comparison

var dataCellWidget = {};

switch(dataCellType) {
  
   case "property":
    dataCellWidget =  getPropertyTypeWidget(cellWidget);
    break;
   case "propertylink":
    dataCellWidget =  getPropertyLinkTypeWidget(cellWidget);
    break;
   case "selector":
    dataCellWidget =  getSelectorTypeWidget(cellWidget);
    break;
   case "custom":
   	dataCellWidget = getCustomPropertyTypeWidget(cellWidget);
   	break;
  
}

resolveVisibilityConfig(dataCellWidget, cellWidget);

return dataCellWidget;
}

function getCustomPropertyTypeWidget(cellWidget) {

	var name = cellWidget.getAttribute("name"),
		propertyToRender = cellWidget.getChild("propertyToRender"),
		config = cellWidget.getChild("config"),
		widgetConfig = {};

	if (propertyToRender) {
		widgetConfig.propertyToRender = propertyToRender.getValue();
	}

	if (config) {
		var properties = config.getChildren();
		for (var i = 0; i < properties.size(); i++) {
			var property = properties.get(i),
				key = property.getAttribute("key");
			widgetConfig[key] = resolvePropertyValue(property);
		}
	}

	var customWidget = {
		"name": name,
		"config": widgetConfig
	}

	customWidget.config.renderFilter = getRenderFilters(cellWidget);
	customWidget.config.style = getCellStyle(cellWidget);
	customWidget.config.pubSubScope = getPubSubScope(cellWidget);

	return 	customWidget;
}


function getSelectorTypeWidget(cellWidget) {
return {
        name: "alfresco/renderers/Selector",
        config: {
            pubSubScope: getPubSubScope(cellWidget),         
            propertyToRender: cellWidget.getAttribute("propertyToRender"),
            style: getCellStyle(cellWidget)
        }
    }
}

function getPropertyLinkTypeWidget(cellWidget) {
var linkConfig = cellWidget.getChild("linkConfig");

var publishPayload = linkConfig.getChild("payload");

var widgetConfig = {
name: "alfresco/renderers/PropertyLink",
config: {
propertyToRender: cellWidget.getAttribute("propertyToRender"),
renderFilter: getRenderFilters(cellWidget),
renderedValueClass: "alfresco-renderers-Property pointer",
publishTopic: linkConfig.getAttribute("publishTopic"),
pubSubScope: getPubSubScope(cellWidget),
publishPayloadType: linkConfig.getAttribute("publishPayloadType") || "PROCESS",
publishPayloadItemMixin: getPublishPayloadItemMixinValue(linkConfig),
publishPayloadModifiers: ["processCurrentItemTokens"],
useCurrentItemAsPayload: cellWidget.getAttribute("useCurrentItemAsPayload") == "true",
publishPayload: resolvePublishPayload(publishPayload),
style: getCellStyle(cellWidget)
}
}

var propertyToDisableClick = cellWidget.getAttribute("propertyToDisableClick"),
propertyToDisableClickValue = cellWidget.getAttribute("propertyToDisableClickValue");

if (propertyToDisableClick && propertyToDisableClickValue) {
widgetConfig.name = "documentPackageWidgets/renderer/DocumentReferencePropertyLink";
widgetConfig.config.propertyToDisableClick = propertyToDisableClick;
widgetConfig.config.propertyToDisableClickValue = propertyToDisableClickValue;
}

return widgetConfig;
}

function getPublishPayloadItemMixinValue(linkConfig) {
var publishPayloadItemMixinValue = linkConfig.getAttribute("publishPayloadItemMixin");
if (publishPayloadItemMixinValue) {
return publishPayloadItemMixinValue == "true";
} else {
// return default
return false;
}
}

function getPropertyTypeWidget(cellWidget) {
return {
name: "alfresco/renderers/Property",
config: {
pubSubScope: getPubSubScope(cellWidget),
propertyToRender: cellWidget.getAttribute("propertyToRender"),
renderFilter: getRenderFilters(cellWidget),
style: getCellStyle(cellWidget)
}
}
}


function resolvePublishPayload(publishPayloadConfig) {
var payload = {};

var properties = publishPayloadConfig.getChildren();
for (var i = 0; i < properties.size(); i++) {
var property = properties.get(i),
   key = property.getAttribute("key");

payload[key] = resolvePropertyValue(property);
}

return payload;
}

function resolvePropertyValue(property) {
var propertyType = property.getAttribute("type") + '', // make sure we have JS string and not Java string
        propertyValue = property.getValue(),
        separator = property.getAttribute("separator"),
        keys = property.getAttribute("keys");

switch(propertyType) {
   case "string":
    return propertyValue || "";
   case "boolean":
    return propertyValue == "true";
   case "expression":
    return eval(propertyValue + '');
   case "function":
    return this[propertyValue].call();
   case "csv":
    return resolveCSVPropertyValue(propertyValue, separator);
   case "object":
    return resolveObjectPropertyValue(propertyValue);
}

return null;
}

function getCellStyle(column) {
var style = {};

var styles = column.getChild("styles");

if (styles) {
styleConfigs = styles.getChildren();

for (var i = 0; i < styleConfigs.size(); i++) {
var styleConfig = styleConfigs.get(i);
style[styleConfig.getAttribute("name")] = styleConfig.getValue();
}
}

return style;
}

function getRenderFilters(cellWidget) {
var renderFilters = [];
var renderFilterConfigs = cellWidget.getChild("renderFilters");
if (renderFilterConfigs) {
renderFilterConfigs = renderFilterConfigs.getChildren();

for (var i = 0; i < renderFilterConfigs.size(); i++) { 
   renderFilters.push(getRenderFilter(renderFilterConfigs.get(i)));
}
}

return renderFilters;
}

function getRenderFilter(renderFilterConfig) {
var renderFilter = {
property: renderFilterConfig.getAttribute("property")
}

var values = [];
var valuesConfig = renderFilterConfig.getChild("values").getChildren();
for (var i = 0; i < valuesConfig.size(); i++) {
var valueConfig = valuesConfig.get(i);

// special handling for boolean value, we want actual boolean and not a string
if (valueConfig.getAttribute("isBoolean") == "true") {
values.push(valueConfig.getValue() == "true");
} else {
// if it's not boolean, just put the value in the allowed values array
values.push(valueConfig.getValue());
}
}

renderFilter.values = values;

if (renderFilterConfig.getAttribute("renderOnAbsentProperty") == "true") {
renderFilter.renderOnAbsentProperty = true;
}

if (renderFilterConfig.getAttribute("negate") == "true") {
renderFilter.negate = true
}

return renderFilter;
}



function isColumnSortable(column) {
var columnSortConfig = column.getChild("sort");

if (!columnSortConfig) {
return false;
}

return columnSortConfig.getAttribute("enabled") == "true";
}

function getSortValue(column) {
var columnConfigs = column.getChildren();

for (var i = 0; i < columnConfigs.size(); i++) {
if (columnConfigs.get(i).getName() == "sort") {
// for now, we only have sortValue as a child option
// if we add new ones, we will need to find it by name and not just get the first one
var sortValue = columnConfigs.get(i).getChildren().get(0).getValue();
return sortValue || "";
}
}

return "";
}

function resolveCSVPropertyValue(propertyValue, separator) {
if (typeof separator === "undefined") {
separator = ',';
}
return (propertyValue + '').split(separator);
}

function resolveObjectPropertyValue(propertyValue) {
return jsonUtils.toObject(propertyValue + '');
}