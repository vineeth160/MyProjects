/**
 * Copyright (C) 2005-2010 Alfresco Software Limited.
 *
 * This file is part of BakerHughes Alfresco Migration
 *
 * This file contains logic for Custom upload component as per Baker Hughes requirements
 * 
 */
 
/**
 * Custom Upload component (bhCustomDocumentUpload.js).
 * 
 * @namespace BH
 * @class bhCustomDocumentUpload
 */

(function() {
	var isWindowClose = true;
	var Dom = YAHOO.util.Dom,
	Event = YAHOO.util.Event,
	Element = YAHOO.util.Element,
	KeyListener = YAHOO.util.KeyListener;
	
	var $html = Alfresco.util.encodeHTML;
	$hasEventInterest = Alfresco.util.hasEventInterest;
	
	Alfresco.module.bhCustomUpload = function(htmlId) {
        var instance = Alfresco.util.ComponentManager.get(this.id);
        if (instance !== null) {
            throw new Error("An instance of Alfresco.module.bhCustomUpload already exists.");
        }
    Alfresco.module.bhCustomUpload.superclass.constructor.call(this, "Alfresco.module.bhCustomUpload", htmlId, ["button", "container", "connection", "selector", "json"]);
	
	this.fileUpload = null;
	this.siteId = null;
	this.containerId = null;
	this.docLibNoderef = null;
	this.suppliedConfig = {};
    this.contentTypeSelectNode;
        /**
         * HTMLElement of type span that displays the dialog title.
         *
         * @property titleText
         * @type HTMLElement
         */
        titleText: null;
        
		return this;
    };
	
	YAHOO.extend(Alfresco.module.bhCustomUpload, Alfresco.component.Base, {
    show: function bhCustomUpload_show(siteId, containerId, docLibNoderef) {
		this.siteId = siteId;
		this.containerId = containerId;
		this.docLibNoderef = docLibNoderef;
		Alfresco.util.Ajax.request({
            url: Alfresco.constants.URL_SERVICECONTEXT + "/com/bh/content/customupload",
            dataObj: {
				htmlid: this.id
            },
            successCallback: {
				fn: this.onTemplateLoaded,
				scope: this
            },
            execScripts: true,
			failureMessage: "Could not load bhCustomUpload template"
        });
        // Apply the config before it is shown
        this._resetGUI();
	},
	
	_resetGUI: function bhCustomUpload_resetGUI() {
    	Dom.addClass(this.id + "-metadata-dialog", "hidden"); 
    },
	
	onTemplateLoaded: function bhCustomUpload_onTemplateLoaded(response) {
    	
        // Inject the template from the XHR request into a new DIV element
        var containerDiv = document.createElement("div");
        containerDiv.innerHTML = response.serverResponse.responseText;

        // The panel is created from the HTML returned in the XHR request, not the container
        var panelDiv = Dom.getFirstChild(containerDiv);
        this.titleText = Dom.get(this.id + "-title-span");
        this.widgets.panel = Alfresco.util.createYUIPanel(panelDiv);
		this.widgets.panel.hideEvent.subscribe(this.onHideEvent, null, this);
        this.titleText = Dom.get(this.id + "-title-span");
        Dom.addClass(this.id + "-filelist-table", "hidden");
        // Create the cancel button
        this.widgets.cancelButton = Alfresco.util.createYUIButton(this, "cancel-button", this._onCancelButtonClick);
        $("#alfresco-bhCustomUpload-instance-cancel-button").addClass("cancelButton");
        // Configure the forms runtime
        var bhCustomUploadForm = new Alfresco.forms.Form(this.id + "-form");
        this.widgets.form = bhCustomUploadForm;
        this._onContentTypeLoad();
		// Apply the config before it is shown
        this._applyConfig();
        // Show the panel
        this._showPanel();
        
    
    },
		
	_onContentTypeLoad: function bhCustomUpload_onContentTypeChange() {   
     	  Dom.removeClass(this.id + "-metadata-dialog", "hidden"); 
     	  Dom.addClass(this.id + "-metadata-form", "hidden"); 
     	  
   	     this._populateSelect();
    },
	
	onHideEvent: function AmSD_onHideEvent(e, obj)
      {
		  if(Dom.get(this.id + "-metadata-form-form-submit-button") && isWindowClose){
			  window.location.reload();
		  }
	  },
	   
	_populateSelect: function bhCustomUpload_populateSelect () {            
    	var nodeType;           
        Dom.removeClass(this.id + "-metadata-dialog", "hidden");             
        var contentTypeSelectId = this.id + "-content-type-select";
        this.contentTypeSelectNode = document.getElementById(contentTypeSelectId);                          
        var OtherNode=["Select Content Type|","QMS Documents|iso_qty_manual"];
    	nodeType=OtherNode;
    	var docCatOptions = "";
        for (docCatValue in nodeType) {
        	var nodeValue=nodeType[docCatValue];
        	var optname=nodeValue.split("|");
           docCatOptions += "<option value=\"bhqms:"+optname[1]+"\">" + optname[0] + "</option>";
        }
        document.getElementById("alfresco-bhCustomUpload-instance-content-type-select").innerHTML = docCatOptions;
      
        //YAHOO.util.Event.removeListener(this.contentTypeSelectNode, "change");
        YAHOO.util.Event.addListener(
            this.contentTypeSelectNode,
            "change",
            this._onContentTypeChange,
            this,
            true
        );           
    },
		
	_onContentTypeChange: function bhCustomUpload_onContentTypeChange() {
		Dom.removeClass(this.id + "-metadata-form", "hidden"); 
        Dom.addClass(this.widgets.cancelButton, "hidden");
        var contentType = this.contentTypeSelectNode.value
		var formHtmlId = this.id + "-metadata-form";
                        
        var url = YAHOO.lang.substitute(
                "{serviceContext}components/form" +
                "?itemKind=type&itemId={itemId}&mode=create&submitType=multipart/form-data" +
                "&formId={formId}&showCancelButton=true&htmlid={htmlid}",
            {
                serviceContext: Alfresco.constants.URL_SERVICECONTEXT,
                itemId: contentType,
				formId: "custom-upload",
                htmlid: formHtmlId
            }
        );
       
        Alfresco.util.Ajax.request({
            url: url,
            responseContentType: "html",
            execScripts: true,
            successCallback: {
            	 fn: this.onMetadataFormReceived,
                 scope: this                    
            },
            failureCallback: {
                fn: function (response) {
                    Alfresco.logger.debug("onContentTypeChange failureCallback", arguments);
                },
                scope: this
            }
        });
  	     
  	  
        
        Alfresco.logger.debug("END onContentTypeChange");
	},
	
	onMetadataFormReceived: function bhCustomUpload_onMetadataFormReceived(response){
		var currentId=this.id;
		Alfresco.logger.debug("onMetadataFormReceived", arguments);
		var formHtmlId = this.id + "-metadata-form";
		var formNode = YAHOO.util.Dom.get(formHtmlId);
		formNode.innerHTML =response.serverResponse.responseText;
		this.formUi = Alfresco.util.ComponentManager.find({
			id: this.id + "-metadata-form-form",
			name: "Alfresco.FormUI"
		})[0];
		
		console.log(" this.formUi *****************");
		console.log(this.formUi);
		
		var SoftwareLoop = SoftwareLoop || {
		hitch: function (scope, f) {
			return function () {
				f.apply(scope, arguments);
			}
		}
		};
		
		var oldOnReady = this.formUi.onReady;
		this.formUi.onReady = SoftwareLoop.hitch(this, function () {
			Alfresco.logger.debug("onReady", arguments);
			oldOnReady.apply(this.formUi, arguments);
			this._formUiFixButtons();
        });
	},
	
	_formUiFixButtons: function bhCustomUpload_formUiFixButtons() {
		var submitButton = this.formUi.buttons.submit;
        submitButton.removeListener("click");             
        submitButton.addListener(
                 "click",
                 this._onMetadataSubmit,
                 this,
                 true
             );
         var cancelButton = this.formUi.buttons.cancel;
         cancelButton.removeListener("click");
         cancelButton.addListener(
             "click",
             this._onCancelButtonClick,
             this,
             true
         );
    },
	 
	_onCancelButtonClick: function bhCustomUpload_onCancelButtonClick(type, args) {
		this.widgets.panel.hide();
		if(Dom.get(this.id + "-metadata-form-form-submit-button")){
			window.location.reload();
		}
	},
	
	_onMetadataSubmit: function bhCustomUpload_onMetadataSubmit(event){
		isWindowClose = false;
		var formRuntime = this.formUi.formsRuntime;
		this.formUi.formsRuntime._setAllFieldsAsVisited();
        if (formRuntime.validate()) {
			Alfresco.logger.debug("Form validated");
			this.widgets.panel.hide();
			//this.destroy();
            this.processMetadataFields();
            formRuntime._submitInvoked.call(this.widgets.form, event);
        } else {
            Alfresco.logger.debug("Form with errors");
            Alfresco.util.PopupManager.displayMessage({
                text: this.msg("Form validation failed, please check all mandatory fields to be filled with valid data...")
            });
        }
	},
	
	processMetadataFields: function () {
		var bhContentType = YAHOO.util.Dom.get(this.id + "-content-type-select");
		var bhDocType = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_document_type");
		var bhDocName = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_cm_name");
		var bhDocRef = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_reference");
		var bhProductCompany = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_product_company");
		var bhProductLine = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_product_line");
		var bhSubPL = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_sub_product_line");
		var bhSite = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_site");
		var bhFunction = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_function");
		var bhSubFunction = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_sub_function");
		var bhLanguage = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_language_code");
		var bhISOElement = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_iso_element");
		var bhUserRole = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_user_role");
		var bhProcess = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_process");
		var bhSubProcess = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_sub_process");
		var bhContentCategory = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_content_category");
		var bhContentAddress = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_document_url");
		//var bhEffective = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_effective_date");
		var bhExpiry = YAHOO.util.Dom.get(this.id + "-metadata-form_prop_bhqms_expiry_date");
		var docAuthor = YAHOO.util.Dom.get(this.id + "-metadata-form_assoc_bhqms_document_author");
		
		var contentCategoryValue = bhContentCategory.value;
		

		if(contentCategoryValue=="Document"){
			this.fileUpload === null
			{
				this.fileUpload = Alfresco.getFileUploadInstance();
			}
			// Show uploader for multiple files
			var multiUploadConfig =
			{
				bhContentType: bhContentType.value,
				siteId: this.siteId,
				containerId: this.containerId,
				uploadDirectory: "",
				docLibNoderef: this.docLibNoderef,
				bhDocType:bhDocType.value,
				bhDocName:bhDocName.value,
				bhDocRef:bhDocRef.value,
				bhProductCompany:bhProductCompany.value,
				bhProductLine:bhProductLine.value,
				bhSubPL:bhSubPL.value,
				bhSite:bhSite.value,
				bhFunction:bhFunction.value,
				bhSubFunction:bhSubFunction.value,
				bhLanguage:bhLanguage.value,
				bhISOElement:bhISOElement.value,
				bhUserRole: bhUserRole.value,
				bhProcess:bhProcess.value,
				bhSubProcess:bhSubProcess.value,
				bhContentCategory:bhContentCategory.value,
				//bhEffective:bhEffective.value,
				bhExpiry:bhExpiry.value,
				docAuthor:docAuthor.value,
				
				filter: [],
				mode: this.fileUpload.MODE_SINGLE_UPLOAD,
				thumbnails: "doclib",
				onFileUploadComplete:
				{
					fn:function(){
						Alfresco.util.PopupManager.displayPrompt(
						{
							text: "<span class=\"para-text text-wrap\">"+this.msg("Document has been uploaded successfully...")+"</span>",
							noEscape: true
						});
						window.location.reload();
					},
					scope: this
				}
			};
			this.fileUpload.show(multiUploadConfig);
		} else{
			var formFields = 
			{
				bhContentType: bhContentType.value,
				docLibNoderef: this.docLibNoderef,
				bhDocType:bhDocType.value,
				bhDocName:bhDocName.value,
				bhDocRef:bhDocRef.value,
				bhProductCompany:bhProductCompany.value,
				bhProductLine:bhProductLine.value,
				bhSubPL:bhSubPL.value,
				bhSite:bhSite.value,
				bhFunction:bhFunction.value,
				bhSubFunction:bhSubFunction.value,
				bhLanguage:bhLanguage.value,
				bhISOElement:bhISOElement.value,
				bhUserRole: bhUserRole.value,
				bhProcess:bhProcess.value,
				bhSubProcess:bhSubProcess.value,
				bhContentCategory:bhContentCategory.value,
				bhContentAddress:bhContentAddress.value,
				//bhEffective:bhEffective.value,
				bhExpiry:bhExpiry.value,
				docAuthor:docAuthor.value
			};
			
			Alfresco.util.Ajax.jsonRequest({
				url: Alfresco.constants.PROXY_URI + "com/bh/contentless/upload/url",
				method: "POST",
				dataObj: formFields,
				successCallback: {
					fn: function (response){
						Alfresco.util.PopupManager.displayPrompt(
						{
							text: "<span class=\"para-text text-wrap\">"+this.msg("Document URL has been uploaded successfully...")+"</span>",
							noEscape: true
						});
						YAHOO.Bubbling.fire("metadataRefresh");
						window.location.reload();
					},
					scope: this
				},
				failureCallback: {
					fn: function (response) {
						Alfresco.util.PopupManager.displayPrompt(
						{
							text: "<span class=\"para-text text-wrap\">"+this.msg("onFailure")+"</span>",
							noEscape: true
						});
						YAHOO.Bubbling.fire("metadataRefresh");
					},
					scope: this
				}
			}, this);
		}
	},
	
	_applyConfig: function bhCustomUpload_applyConfig()
    {
       // Generate the title based on number of files and destination
		var title, i18n;
		i18n = "New QMS Document Upload";
		this.titleText.innerHTML = i18n;
    },
		
	_showPanel: function bhCustomUpload_showPanel() {
        // Reset form before displaying it
       // this.widgets.form.reset();

        // Show the upload panel
        this.widgets.panel.show();

        // Firefox insertion caret fix
        Alfresco.util.caretFix(this.id + "-form");

        if (!this.widgets.escapeListener) {
            // Register the ESC key to close the dialog
            this.widgets.escapeListener = new KeyListener(document, {
                keys: KeyListener.KEY.ESCAPE
            }, {
                fn: function(id, keyEvent) {
                    this.onCancelButtonClick();
                },
                scope: this,
                correctScope: true
            });
            this.widgets.escapeListener.enable();
        }
    },
	
	});
})();

Alfresco.module.getBHCustomUploadInstance = function() {
    var instanceId = "alfresco-bhCustomUpload-instance";
    return Alfresco.util.ComponentManager.get(instanceId) || new Alfresco.module.bhCustomUpload(instanceId);
};