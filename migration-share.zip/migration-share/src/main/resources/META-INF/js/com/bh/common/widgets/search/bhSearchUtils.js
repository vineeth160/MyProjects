/**
 * Utility object for baker hughes utilities.. Note that this is not a Class, and so does
 * not need to be instantiated before use.
 *
 * @module bhWidgets/bhSearchUtils
 * 
 */
define(["alfresco/services/BaseService",
	"dojo/_base/lang"],
	function(BaseService, lang) {

	// The private container for the functionality and properties of the util
	var util = {

			/**
			 * 
			 * Caller is obliged to provide localization function.
			 */
			resolveValueBasedOnPayloadAndRules: function (payload, payloadProp, rules, i18nFn, separator) {
				var result = ""
					separator = separator || "";

				// do we have rules configured
				if (payloadProp && rules && payload[payloadProp]) {

					var rule; 
					for (var i = 0; i < rules.length; i++) {
						// we matched rule value with payload value
						if (rules[i].value == payload[payloadProp]) {

							rule = rules[i]; 

							// Get value for the rule marked as 'Prefix Rule'
							if(rule.ruleToIncludeAsPrefix) {
								result = this.resolveRuleToIncludeAsPrefix(payload, rule.ruleToIncludeAsPrefix, rules, i18nFn, separator); 

								result = result ? (result + separator) : ""; 
							}

							// check if we have fixed prefix
							if (rule.prefix) {
								result += i18nFn(rule.prefix);
							}

							// check if label value should be found in the payload
							if (rule.labelPayloadProp) {
								var propValue = "";
								if (rule.payloadPropFindDeep) {
									propValue = lang.getObject(rule.labelPayloadProp, false, payload);
								} else {
									propValue = payload[rule.labelPayloadProp]
								}

								result += i18nFn(propValue);
							}

							// check if label value is configured
							if (rule.label) {
								result += i18nFn(rule.label);
							}

							break;
						}
					}
				}

				return result;
			}, 

			resolveRuleToIncludeAsPrefix: function (payload, prefixRuleValue, rules, i18nFn, separator) {
				var result = "", rule;

				// do we have rules configured for provided prefixRuleValue
				if (prefixRuleValue && rules) {
					for (var i = 0; i < rules.length; i++) {
						// we matched rule value with provided prefixRuleValue
						if (rules[i].value == prefixRuleValue) {

							rule = rules[i]; 

							// Apply any 
							if(rule.ruleToIncludeAsPrefix) {
								result = this.resolveRuleToIncludeAsPrefix(payload, rule.ruleToIncludeAsPrefix, rules, i18nFn, separator); 

								result = result ? (result + separator) : "";
							}

							// check if we have fixed prefix
							if (rule.prefix) {
								result += i18nFn(rule.prefix);
							}

							// check if label value should be found in the payload
							if (rule.labelPayloadProp) {
								var propValue = "";
								if (rule.payloadPropFindDeep) {
									propValue = lang.getObject(rule.labelPayloadProp, false, payload);
								} else {
									propValue = payload[rule.labelPayloadProp]
								}

								result += i18nFn(propValue);
							}

							// check if label value is configured
							if (rule.label) {
								result += i18nFn(rule.label);
							}

							break;
						}
					}
				}

				return result;
			},

			/**
			 * Extracts clean error message from the Alfresco wrapped message string response.
			 */
			extractErrorMessage: function(errorMsg) {
				if (!errorMsg) {
					return "";
				}

				var regex = /^\S[0-9]+\S/i;

				var match = errorMsg.search(regex);
				if (match != -1) {
					return errorMsg.replace(regex, "");
				}

				return errorMsg;
			},

			/**
			 * Returns true if the object reference is null/undefined,
			 * or the object does not have any properties set.
			 */
			isEmptyObject: function(obj) {
				if (obj == null && obj == undefined) {
					return true;
				}

				for(var key in obj) {
					if(obj.hasOwnProperty(key)) {
						return false;
					}
				}

				return true;
			}
	};

	/**
	 * The public API for this utility class
	 *
	 * @alias module:bhWidgets/bhSearchUtils
	 */
	return {

		/**
		 * 
		 * Caller is obliged to provide localization function.
		 */
		resolveValueBasedOnPayloadAndRules: lang.hitch(util, util.resolveValueBasedOnPayloadAndRules),

		extractErrorMessage: lang.hitch(util, util.extractErrorMessage),

		isEmptyObject: lang.hitch(util, util.isEmptyObject)
	};
});