/**
 * Extends OOB AlfCheckableMenuItem to add the following features:
 * 
 * 1. configurable array of topic to trigger the republishing of item topic
 * 2. configurable select/clear all option that will check/uncheck all siblings in the menu group
 * 
 * With these features, can be used with eg. data grids to show/hide columns dynamically.
 * 
 * @module bhWidgets/AlfCheckableMenuItem
 * @extends module:alfresco/menus/AlfCheckableMenuItem
 * 
 */
define(["dojo/_base/declare",
	"dojo/_base/lang",
	"alfresco/menus/AlfCheckableMenuItem"],
	function(declare, lang, AlfCheckableMenuItem) {

	return declare([AlfCheckableMenuItem], {

		/**
		 * Topics that will trigger this item to
		 * publish its value.
		 * 
		 * If checkable items are used with a table, this can be useful
		 * in scenarios where the table is re-rendered (on page change, page size change,
		 * sort, etc...) -> when this happens, the table is rendered as per initial visibility configuration,
		 * discarding any selection that user has made; so we need these checkable items to republish their selection
		 * in order for the appropriate columns to show/hide; the way to achieve this is to add a topic to the list itself,
		 * as "refreshColumnsVisibilityTopic", that will be published when everything for the list is fully re-rendered and add
		 * that topic to checkable item as republich topic, so that the process is the following
		 * 1. user selects/deselects some items and in that way hides/shows columns
		 * 2. user clicks next page or sort, etc
		 * 3. the table is re-rendered with the new data
		 * 4. the table show columns based on initial configuration (annulling what columns the user has hidden/shown)
		 * 5. after that, the table publishes a "refreshColumnsVisibilityTopic"
		 * 6. the "refreshColumnsVisibilityTopic" from the table is in the list of "republishSelectionTopics" and triggers the checkable item
		 *    to republish its selection, thus hiding/showing the appropriate columns and restoring visibility that user has chosen
		 *    
		 */
		republishSelectionTopics: [],

		/**
		 * Indicates if checking/unchecking of the item
		 * should be propagated to all sibling checkable items in the
		 * menu group.
		 */
		isSelectClearAllCheckBox: false,

		/**
		 * To invoke the toggle function, we need an event, so we will create
		 * a singleton event and store it on the widget for this purpose.
		 */
		selectClearAllBrowserEvent: null,
		/**
		 * @instance
		 */
		postCreate: function alfresco_menus_AlfCheckableMenuItem__postCreate() {
			this.inherited(arguments);

			for (var i = 0; i < this.republishSelectionTopics.length; i++) {
				this.alfSubscribe(this.republishSelectionTopics[i], lang.hitch(this, this.publishSelection));
			}
		},

		/**
		 * Extends OOB selection toggle to add the option of
		 * propagating the selection to all siblings of the checkable menu group.
		 * 
		 * If the widget flag "isSelectClearAllCheckBox" is set to false, behaves the same
		 * as OOB, otherwise performs selection/deselection of other checkable items.
		 */
		toggleSelection: function (evt) {
			this.inherited(arguments);

			if (this.isSelectClearAllCheckBox == true) {
				if (this.selectClearAllBrowserEvent == null) {
					if (navigator.userAgent.indexOf('MSIE') !== -1 || navigator.appVersion.indexOf('Trident/') > 0) {
						// Creating an event doesn't work in Internet explorer 
						var event = document.createEvent("Event");
						event.initEvent(this.id + "_event", false, true); // args: string type, boolean bubbles, boolean cancelable
						this.selectClearAllBrowserEvent = event;
					} else {
						this.selectClearAllBrowserEvent = new Event(this.id + "_event")
					}      
				}

				var otherCheckableItemsFromGroup = this.getParent().getChildren();
				for (var i = 0; i < otherCheckableItemsFromGroup.length; i++) {
					var checkableItem = otherCheckableItemsFromGroup[i];
					// make sure we do not trigger select/clear all topic to avoid infinite loop
					if (this.id != checkableItem.id) {
						checkableItem.conditionallyToggle(this.selectClearAllBrowserEvent, this.checked);
					}
				}
			}
		},

		/**
		 * Optionally toggle selection.
		 * 
		 * Effectively behaves like a check/uncheck function, based on the passed flag. 
		 */
		conditionallyToggle: function(evt, checked) {
			// perform selection / deselection only if received state is different than the current one
			if (checked != this.checked) {
				this.toggleSelection(evt);
			}
		}
	});
});