/**
 * Extends the OOB Cell to add the option of async render filters for child widgets.
 * 
 * Configuration example for the child renderer widgets of the cell:
 * 
 * 
 * @module bhWidgets/Cell
 * @extends module:alfresco/lists/views/layouts/Cell
 */
define(["dojo/_base/declare",
	"alfresco/lists/views/layouts/Cell",
	"service/constants/Default",
	"alfresco/core/CoreXhr",
	"bhWidgets/bhSearchUtils"], 
	function(declare, Cell, AlfConstants, CoreXhr, bhSearchUtils) {
	return declare([Cell, CoreXhr], {
		/**
		 * Override oOB method to process async render configuration of the child widgets, if present.
		 * 
		 * If static configuration returns false, we do not check async configuration, it is cheched only if
		 * regular render filter is not present or returns true.
		 */
		filterWidget: function alfresco_core_CoreWidgetProcessing__filterWidget(widgetConfig, index, processWidgetsId) {
			var shouldRender = this.inherited(arguments);
			console.log("In custom renderer function!");

//			if we already know that the widget shouldn't be rendered
//			that's enough
			if (shouldRender == false) {
				return shouldRender;
			}

//			if we have async check, perform the request
			if (!bhSearchUtils.isEmptyObject(widgetConfig.config.asyncRenderFilter)){
				this.processAsyncRenderConfig(widgetConfig.config.asyncRenderFilter);
			}

			return shouldRender;
		},

		/**
		 * Process the configuration for async rendering
		 */
		processAsyncRenderConfig: function (asyncRenderFilter) {
			this.serviceXhr({
				url: AlfConstants.PROXY_URI + asyncRenderFilter.uri + this.formAsyncRenderConfigQueryParamString(asyncRenderFilter),
				method: "GET",
				successCallback: function(response, requestConfig) {
					var responsePropValue = response[asyncRenderFilter.responsePropertyKey],
					allowedValues = asyncRenderFilter.responsePropertyValues;
					var payload = {};
					// payload only needs the flag, which is determined by the response value being among allowed values
					payload[asyncRenderFilter.responsePropertyKey] = allowedValues.indexOf(responsePropValue) >= 0;
					this.alfPublish(asyncRenderFilter.visibilityUpdateTopicPrefix + this.currentItem.index, payload);
				},
				failureCallback: function(response) {
					// if there was something wrong with the response, check if tru was configured for rendering, otherwise return false
					var payload = {};
					payload[asyncRenderFilter.responsePropertyKey] = asyncRenderFilter.renderIfRequestFails == true;
					this.alfPublish(asyncRenderFilter.visibilityUpdateTopicPrefix + this.currentItem.index, payload);
				}
			});

			console.log("*********** ASYNC SHOULD RENDER REQUEST END ***********");
		},

		/**
		 * Create the query string for the request, based on the
		 * configuration and current item of the table row.
		 */
		formAsyncRenderConfigQueryParamString: function (asyncRenderFilter) {
			var queryString = "";
			for (var i = 0; i < asyncRenderFilter.parametersFromCurrentItem.length; i++) {
				var paramConfig = asyncRenderFilter.parametersFromCurrentItem[i];
				var paramValue = this.currentItem[paramConfig.currentItemPropName];
				if (i > 0) {
					queryString += "&";
				}
				queryString += paramConfig.queryParamPropName;
				queryString += "=";
				queryString += encodeURIComponent(paramValue);
			}

			if (queryString !== "") {
				queryString = "?" + queryString;
			}

			return queryString;
		}
	});
});