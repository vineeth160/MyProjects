/**
 *
 * @module bhWidgets/tableView
 * @extends alfresco/lists/views/AlfListView
 *
 */
define(["dojo/_base/declare",
	"alfresco/lists/views/AlfListView"
	],
	function(declare, AlfListView) {

	return declare([AlfListView], {

		/**
		 * Returns the name of the view that is used when saving user view preferences.
		 *
		 * @instance
		 * @returns {string} "simple"
		 */
		getViewName: function __tableView_getViewName() {
			return "BH QMS Smart View";
		},

		/**
		 * The configuration for selecting the view (configured the menu item)
		 * @instance
		 * @type {object}
		 * @property {string|null} label The label or message key for the view (as appears in the menus)
		 * @property {string|null} icon"class" The "class" to place next to the label
		 */
		viewSelectionConfig: {
			label: "BH QMS Smart View",
			iconClass: "alf-tableview-icon"
		},

		/**
		 * The view model.
		 *
		 * @instance
		 * @type {opject}
		 */
		widgetsForHeader: [
			{
				id: "TABLE_VIEW_SELECTOR_HEADING",
				name: "alfresco/lists/views/layouts/HeaderCell",
				config: {
					label: "",
					sortable: false
				}
			},
			
			{
				id: "TABLE_VIEW_NAME_HEADING",
				name: "alfresco/lists/views/layouts/HeaderCell",
				config: {
					label: "label.documentName",
					sortable: true,
					sortValue: "cm:name",
					useHash: "{useHash}"
				}
			},
			{
				id: "TABLE_REFERENCE_HEADING",
				name: "alfresco/lists/views/layouts/HeaderCell",
				config: {
					label: "Document Reference",
					sortable: true,
					sortValue: "bhqms:reference",
					useHash: "{useHash}"
				}
			},
			{
				id: "TABLE_REVISION_HEADING",
				name: "alfresco/lists/views/layouts/HeaderCell",
				config: {
					label: "Revision Number",
					sortable: true,
					sortValue: "bhqms:publish_revision",
					useHash: "{useHash}"
				}
			},
			{
				id: "TABLE_DOCUMENTSTATE_HEADING",
				name: "alfresco/lists/views/layouts/HeaderCell",
				config: {
					label: "Document State",
					sortable: true,
					sortValue: "bhqms:document_state",
					useHash: "{useHash}"
				}
			},
			{
				id: "TABLE_PC_HEADING",
				name: "alfresco/lists/views/layouts/HeaderCell",
				config: {
					label: "Product Company",
					sortable: true,
					sortValue: "bhqms:product_company",
					useHash: "{useHash}"
				}
			},
			{
				id: "TABLE_PL_HEADING",
				name: "alfresco/lists/views/layouts/HeaderCell",
				config: {
					label: "Product Line",
					sortable: true,
					sortValue: "bhqms:product_line",
					useHash: "{useHash}"
				}
			},
			{
				id: "TABLE_SPL_HEADING",
				name: "alfresco/lists/views/layouts/HeaderCell",
				config: {
					label: "Sub Product Line",
					sortable: true,
					sortValue: "bhqms:sub_product_line",
					useHash: "{useHash}"
				}
			},
			{
				id: "TABLE_SITE_HEADING",
				name: "alfresco/lists/views/layouts/HeaderCell",
				config: {
					label: "Site",
					sortable: true,
					sortValue: "bhqms:site",
					useHash: "{useHash}"
				}
			},
			{
				id: "TABLE_FUNCTION_HEADING",
				name: "alfresco/lists/views/layouts/HeaderCell",
				config: {
					label: "Function",
					sortable: true,
					sortValue: "bhqms:function",
					useHash: "{useHash}"
				}
			},
			
			{
				id: "TABLE_SUBFUNTION_HEADING",
				name: "alfresco/lists/views/layouts/HeaderCell",
				config: {
					label: "Sub Function",
					sortable: true,
					sortValue: "bhqms:sub_function",
					useHash: "{useHash}"
				}
			},
			{
				id: "TABLE_FO_HEADING",
				name: "alfresco/lists/views/layouts/HeaderCell",
				config: {
					label: "Functional Owner",
					sortable: true,
					sortValue: "bhqms:functional_owner",
					useHash: "{useHash}"
				}
			},
			{
				id: "TABLE_ADMIN_HEADING",
				name: "alfresco/lists/views/layouts/HeaderCell",
				config: {
					label: "Document Admin",
					sortable: true,
					sortValue: "bhqms:document_admin",
					useHash: "{useHash}"
				}
			}


			],


			/**
			 * The definition of how a single item is represented in the view.
			 *
			 * @instance
			 * @type {object[]}
			 */
			widgets: [{
				name: "alfresco/lists/views/layouts/Row",
				config: {
					widgets: [
						{
							id: "TABLE_SELECTOR_CELL",
							name: "alfresco/lists/views/layouts/Cell",
							config: {
								additionalCssClasses: "smallpad",
								widgets: [{
									id: "TABLE_SELECTOR",
									name: "alfresco/renderers/Selector",
									config: {
										itemKey: "node.nodeRef"
									}
								}]
							}
						},
						
						{
							id: "TABLE_NAME_CELL",
							name: "alfresco/lists/views/layouts/Cell",
							config: {
								additionalCssClasses: "smallpad",
								widgets: [{
									id: "TABLE_NAME",
									name: "alfresco/renderers/Property",
									config: {
										propertyToRender: "node.properties.cm:name",
										postParam: "prop_cm_name"
									}
								}]
							}
						} ,
						{
							id: "TABLE_REFERENCE_CELL",
							name: "alfresco/lists/views/layouts/Cell",
							config: {
								additionalCssClasses: "smallpad",
								widgets: [{
									id: "TABLE_REFERENCE",
									name: "alfresco/renderers/Property",
									config: {
										propertyToRender: "node.properties.bhqms:reference",
										postParam: "prop_bhqms_reference"
									}
								}]
							}
						} ,
						{
							id: "TABLE_REVISION_CELL",
							name: "alfresco/lists/views/layouts/Cell",
							config: {
								additionalCssClasses: "smallpad",
								widgets: [{
									id: "TABLE_REVISION",
									name: "alfresco/renderers/Property",
									config: {
										propertyToRender: "node.properties.bhqms:publish_revision",
										postParam: "prop_bhqms_publish_revision"
									}
								}]
							}
						} ,
						{
							id: "TABLE_DOCUMENTSTATE_CELL",
							name: "alfresco/lists/views/layouts/Cell",
							config: {
								additionalCssClasses: "smallpad",
								widgets: [{
									id: "TABLE_DOCUMENTSTATE",
									name: "alfresco/renderers/Property",
									config: {
										propertyToRender: "node.properties.bhqms:document_state",
										postParam: "prop_bhqms_document_state"
									}
								}]
							}
						} ,
						{
							id: "TABLE_PC_CELL",
							name: "alfresco/lists/views/layouts/Cell",
							config: {
								additionalCssClasses: "smallpad",
								widgets: [{
									id: "TABLE_PC",
									name: "alfresco/renderers/Property",
									config: {
										propertyToRender: "node.properties.bhqms:product_company",
										postParam: "prop_bhqms_product_company"
									}
								}]
							}
						} ,
						{
							id: "TABLE_PL_CELL",
							name: "alfresco/lists/views/layouts/Cell",
							config: {
								additionalCssClasses: "smallpad",
								widgets: [{
									id: "TABLE_PL",
									name: "bhWidgets/bhMultiSinglePropertyRenderer",
									config: {
										propertyToRender: "node.properties.bhqms:product_line",
										postParam: "prop_bhqms_product_line"
									}
								}]
							}
						} ,
						{
							id: "TABLE_SPL_CELL",
							name: "alfresco/lists/views/layouts/Cell",
							config: {
								additionalCssClasses: "smallpad",
								widgets: [{
									id: "TABLE_SPL",
									name: "bhWidgets/bhMultiSinglePropertyRenderer",
									config: {
										propertyToRender: "node.properties.bhqms:sub_product_line",
										postParam: "prop_bhqms_sub_product_line"
									}
								}]
							}
						} ,
						{
							id: "TABLE_SITE_CELL",
							name: "alfresco/lists/views/layouts/Cell",
							config: {
								additionalCssClasses: "smallpad",
								widgets: [{
									id: "TABLE_SITE",
									name: "bhWidgets/bhMultiSinglePropertyRenderer",
									config: {
										propertyToRender: "node.properties.bhqms:site",
										postParam: "prop_bhqms_site"
									}
								}]
							}
						},
						{
							id: "TABLE_FUNCTION_CELL",
							name: "alfresco/lists/views/layouts/Cell",
							config: {
								additionalCssClasses: "smallpad",
								widgets: [{
									id: "TABLE_FUNCTION",
									name: "bhWidgets/bhMultiSinglePropertyRenderer",
									config: {
										propertyToRender: "node.properties.bhqms:function",
										postParam: "prop_bhqms_function"
									}
								}]
							}
						} ,
						
						{
							id: "TABLE_SUBFUNCTION_CELL",
							name: "alfresco/lists/views/layouts/Cell",
							config: {
								additionalCssClasses: "smallpad",
								widgets: [{
									id: "TABLE_SUBFUNCTION",
									name: "alfresco/renderers/Property",
									config: {
										propertyToRender: "node.properties.bhqms:sub_function",
										postParam: "prop_bhqms_sub_function"
									}
								}]
							}
						} ,
						{
							id: "TABLE_FO_CELL",
							name: "alfresco/lists/views/layouts/Cell",
							config: {
								additionalCssClasses: "smallpad",
								widgets: [{
									id: "TABLE_FO",
									name: "alfresco/renderers/Property",
									config: {
										propertyToRender: "node.properties.bhqms:functional_owner",
										postParam: "prop_bhqms_functional_owner"
									}
								}]
							}
						} ,
						{
							id: "TABLE_ADMIN_CELL",
							name: "alfresco/lists/views/layouts/Cell",
							config: {
								additionalCssClasses: "smallpad",
								widgets: [{
									id: "TABLE_ADMIN",
									name: "alfresco/renderers/Property",
									config: {
										propertyToRender: "node.properties.bhqms:document_admin",
										postParam: "prop_bhqms_document_admin"
									}
								}]
							}
						}
						]
				}
			}]
	});
});