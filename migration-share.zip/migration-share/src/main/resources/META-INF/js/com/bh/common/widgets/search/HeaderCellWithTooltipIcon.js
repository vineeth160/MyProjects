/**
 * Extends OOB Aikau HeaderCell to add the option of having an additional icon
 * that displays a tooltip on hover.
 * 
 * @module bhWidgets/HeaderCellWithTooltipIcon
 * @extends alfresco/lists/views/layouts/HeaderCell
 */
define(["dojo/_base/declare",
	"alfresco/lists/views/layouts/HeaderCell",
	"alfresco/core/topics",
	"alfresco/util/hashUtils",
	"dojo/_base/lang",
	"dojo/dom-class",
	"dojo/query",
	"dojo/dom-attr",
	"dojo/text!./templates/HeaderCellWithTooltipIcon.html"], 
	function(declare, HeaderCell, topics, hashUtils, lang, domClass, query, domAttr, template) {

	return declare([HeaderCell], {

		/**
		 * The HTML template to use for the widget.
		 * 
		 * @instance
		 * @type {String}
		 */
		templateString: template,

		/**
		 * Custom styles for the tooltip.
		 */
		cssRequirements: [{cssFile:"./css/HeaderCellWithTooltipIcon.css"}],

		/**
		 * Path to the icon.
		 */
		tooltipIconUrl: "",

		/**
		 * Text that should be displayed in the tooltip.
		 */
		tooltipIconText: "",

		createWidgetDom: function alfresco_lists_views_layouts_Row__createWidgetDom() {
			this.inherited(arguments);
			// call custom setup method
			this.setupIconTooltip();
		},

		setupIconTooltip: function() {
			// setup icon node if configured
		}
	});
});