/**
 *
 * @module bhWidgets/bhMultiSinglePropertyRenderer
 * @extends alfresco/renderers/Property
 *
 */
define(["dojo/_base/declare",
		"alfresco/core/ObjectTypeUtils", 
        "alfresco/renderers/Property"], 
        function(declare, ObjectTypeUtils, Property) {

   return declare([Property], {

      getRenderedProperty: function alfresco_renderers_Property__getRenderedProperty(property, highlight) {
		 
		
    	  	var value = this.inherited(arguments);
    	  	if (ObjectTypeUtils.isArray(property) && property.length > 0)  {
				value = property.toString();	
				
    	  		
    	  	}
         return value;
      },

       /**
        * Extended to prevent IE bug where null is displayed when no value is found
        *
        * @param value
        * @returns {string}
        */
       generateRendering: function alfresco_renderers_Property__generateRendering(value) {
		  
          var valueRendering = this.inherited(arguments);

          if(!valueRendering){
              valueRendering = "";
          }

          return valueRendering;
       }
   });
});
