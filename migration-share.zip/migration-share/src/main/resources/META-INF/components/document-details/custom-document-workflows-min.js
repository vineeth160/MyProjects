(function(){
	
  YAHOO.util.Event.onDOMReady(function () {
    if (!document.getElementById("onActionAssignWorkflow")) {
      document.getElementsByName(".onAssignWorkflowClick")[0].hidden = true;
    }
  });

})();