/**
 * Copyright (C) 2005-2012 Alfresco Software Limited.
 *
 * This file is part of Alfresco
 *
 * Alfresco is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Alfresco is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Alfresco. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Credit Risk Landing page JS.
 * 
 * @namespace Alfresco.qmsAdvancedSearchDashlet
 * @class Alfresco.qmsAdvancedSearchDashlet
 */
(function()
{
   /**
    * YUI Library aliases
    */
	 var Dom = YAHOO.util.Dom;
     var table=null;
	 var mydata = null;
	 var myConfigs = null;
	 var typeValue = null;
	 var exportButton =null;
	 var clearButton =null;
	 var typeValueTop = null;
	 var exportButtonTop =null;
	 var clearButtonTop =null;
	 Event = YAHOO.util.Event;
	 var filteredData = [];    
	 var filteredDataIds = new Set(); 
   /**
    * Alfresco Slingshot aliases
    */
	 var $html = Alfresco.util.encodeHTML
       $siteURL = Alfresco.util.siteURL,
       $profileURL = Alfresco.util.profileURL;
   
   /**
    * Dashboard reportsDashlet constructor.
    * 
    * @param {String} htmlId The HTML id of the parent element
    * @return {Alfresco.reportsDashlet} The new component instance
    * @constructor
    */

   Alfresco.qmsAdvancedSearchDashlet = function qmsAdvancedSearchDashlet_constructor(htmlId)
   {
      Alfresco.qmsAdvancedSearchDashlet.superclass.constructor.call(this, "Alfresco.qmsAdvancedSearchDashlet", htmlId, ["button", "container", "datasource", "datatable", "json"]);
      this.id = htmlId;
	  return this;
   };
   
   YAHOO.extend(Alfresco.qmsAdvancedSearchDashlet, Alfresco.component.Base,
   {
		onReady: function onReady()
		{ 
			this.metadataForm = Dom.get(this.id+"-metadata-form-qmssearch");
			var custom_type = "bhqms:iso_qty_manual";
			this.renderFormTemplate(custom_type);
			typeValue = Alfresco.util.createYUIButton(this, "search-docs-button",this.onSearchClick);
			exportButton = Alfresco.util.createYUIButton(this, "export-docsList-button",this.onExportClick);
			clearButton = Alfresco.util.createYUIButton(this, "clear-docsList-button",this.onClearClick);
			typeValueTop = Alfresco.util.createYUIButton(this, "search-docs-button-top",this.onSearchClick);
			exportButtonTop = Alfresco.util.createYUIButton(this, "export-docsList-button-top",this.onExportClick);
			clearButtonTop = Alfresco.util.createYUIButton(this, "clear-docsList-button-top",this.onClearClick);
		},

		renderFormTemplate: function renderFormTemplate(custom_type) {
			var formId = this.id + "-metadata-form-qmssearch";
			
			// load the form component for the appropriate type
			var formUrl = YAHOO.lang.substitute(Alfresco.constants.URL_SERVICECONTEXT + "components/form?itemKind=type&formId={formId}&itemId={itemId}&mode=create&showSubmitButton=false&showCancelButton=false",
			{
				itemId: custom_type,
				formId: "qmsSearchReport"
			});
			var formData =
			{
				htmlid: formId
			};
			Alfresco.util.Ajax.request(
			{
				url: formUrl,
				dataObj: formData,
				responseContentType: Alfresco.util.Ajax.JSON,
				successCallback:
				{
					fn: function onFormTemplateLoaded(response)
					{
						this.metadataForm.innerHTML = response.serverResponse.responseText;	
						this.form = new Alfresco.forms.Form(formId + '-form');
						this.form.setShowSubmitStateDynamically(true, true);
						this.form.init();
					},
					scope: this
				},
				failureMessage: "Could not load form component '" + formUrl + "'.",
				scope: this,
				execScripts: true
			});	
		},

		onSearchClick : function onSearchClick(p_oEvent){
		   
			var pcNullCheck =  document.querySelector('[id$="form-qmssearch_prop_bhqms_product_company"]');
			if(pcNullCheck != null && pcNullCheck != "" && pcNullCheck != "null" && pcNullCheck != "undefined"){
				var pcCheckValue = Dom.get(pcNullCheck.id).value;
				if(pcCheckValue == null || pcCheckValue == "" || pcCheckValue == "null" || pcCheckValue == "undefined"){
					Alfresco.util.PopupManager.displayMessage(
						{
						   text: this.msg("Please select Product Company before click on Search")
						});
					return;
				}
			}
			
			var bh_publish_date_from = "",
				bh_publish_date_to = "",
				bh_expiry_date_from="",
				bh_expiry_date_to="",
				bh_effective_date_from="",
				bh_effective_date_to="",
				bh_name="",
				bh_docReference="",
				bh_product_company="",
				bh_product_line="",
				bh_sub_product_line="",
				bh_function="",
				bh_sub_function="",
				bh_site="",
				bh_docType="",
				bh_isoElement="",
				bh_userRole="",
				bh_process="",
				bh_subProcess="",
				bh_contentCategory="",
				bh_language="",
				bh_document_author="",
				bh_document_admin="",
				bh_functional_owner="",
				bh_document_state="",
				bh_dctm_id="";
				
			var querySelectFrom =  document.querySelector('[id$="form-qmssearch_prop_bhqms_published_date-cntrl-date-from"]');
			if(querySelectFrom != null && querySelectFrom!="" && querySelectFrom!="null" && querySelectFrom!="undefined"){
				bh_publish_date_from = Dom.get(querySelectFrom.id).value;
			}
			//alert("bh_publish_date_from ::"+bh_publish_date_from);
			var querySelectTo =  document.querySelector('[id$="form-qmssearch_prop_bhqms_published_date-cntrl-date-to"]');
			if(querySelectTo != null && querySelectTo!="" && querySelectTo!="null" && querySelectTo!="undefined"){
				bh_publish_date_to = Dom.get(querySelectTo.id).value;
			}
		//	alert("bh_publish_date_to ::"+bh_publish_date_to);
		
			var querySelectExpFrom =  document.querySelector('[id$="form-qmssearch_prop_bhqms_expiry_date-cntrl-date-from"]');
			if(querySelectExpFrom != null && querySelectExpFrom!="" && querySelectExpFrom!="null" && querySelectExpFrom!="undefined"){
				bh_expiry_date_from = Dom.get(querySelectExpFrom.id).value;
			}
			//alert("bh_expiry_date_from ::"+bh_expiry_date_from);
			var querySelectExpTo =  document.querySelector('[id$="form-qmssearch_prop_bhqms_expiry_date-cntrl-date-to"]');
			if(querySelectExpTo!= null && querySelectExpTo!="" && querySelectExpTo!="null" && querySelectExpTo!="undefined"){
				bh_expiry_date_to = Dom.get(querySelectExpTo.id).value;
			}
		//	alert("bh_expiry_date_to ::"+bh_expiry_date_to);
			var querySelectEffFrom =  document.querySelector('[id$="form-qmssearch_prop_bhqms_effective_date-cntrl-date-from"]');
			if(querySelectEffFrom != null && querySelectEffFrom!="" && querySelectEffFrom!="null" && querySelectEffFrom!="undefined"){
				bh_effective_date_from = Dom.get(querySelectEffFrom.id).value;
			}
			//alert("bh_effective_date_from ::"+bh_effective_date_from);
			var querySelectEffTo =  document.querySelector('[id$="form-qmssearch_prop_bhqms_effective_date-cntrl-date-to"]');
			if(querySelectEffTo!= null && querySelectEffTo!="" && querySelectEffTo!="null" && querySelectEffTo!="undefined"){
				bh_effective_date_to = Dom.get(querySelectEffTo.id).value;
			}
			//alert("bh_effective_date_to ::"+bh_effective_date_to);
			
			var queryName =  document.querySelector('[id$="form-qmssearch_prop_cm_name"]');
			if(queryName!= null && queryName!="" && queryName!="null" && queryName!="undefined"){
				bh_name = Dom.get(queryName.id).value;
				bh_name = escape(bh_name);
			}
			//alert("bh_name ::"+bh_name);
			
			var querydocReference =  document.querySelector('[id$="form-qmssearch_prop_bhqms_reference"]');
			if(querydocReference!= null && querydocReference!="" && querydocReference!="null" && querydocReference!="undefined"){
				bh_docReference = Dom.get(querydocReference.id).value;
				bh_docReference = escape(bh_docReference);
			}
		//	alert("bh_docReference ::"+bh_docReference);
			
			var queryProductCompany =  document.querySelector('[id$="form-qmssearch_prop_bhqms_product_company"]');
			//alert("&&&&& "+queryProductCompany)
			if(queryProductCompany!= null && queryProductCompany!="" && queryProductCompany!="null" && queryProductCompany!="undefined"){
				bh_product_company = Dom.get(queryProductCompany.id).value;
				bh_product_company = escape(bh_product_company);
			}
			
		   // alert("bh_product_company ::"+bh_product_company);
			var queryProductLine =  document.querySelector('[id$="form-qmssearch_prop_bhqms_product_line"]');
			//alert("&&&&& "+queryProductCompany)
			if(queryProductLine!= null && queryProductLine!="" && queryProductLine!="null" && queryProductLine!="undefined"){
				bh_product_line = Dom.get(queryProductLine.id).value;
				bh_product_line = escape(bh_product_line);
			}
			
			//alert("bh_product_line ::"+bh_product_line);
			var querySubProductLine =  document.querySelector('[id$="form-qmssearch_prop_bhqms_sub_product_line"]');
			if(querySubProductLine!= null && querySubProductLine!="" && querySubProductLine!="null" && querySubProductLine!="undefined"){
				bh_sub_product_line = Dom.get(querySubProductLine.id).value;
				bh_sub_product_line = escape(bh_sub_product_line);
			}
			
		//	alert("bh_sub_product_line ::"+bh_sub_product_line);
			var queryFunction =  document.querySelector('[id$="form-qmssearch_prop_bhqms_function"]');
			if(queryFunction!= null && queryFunction!="" && queryFunction!="null" && queryFunction!="undefined"){
				bh_function = Dom.get(queryFunction.id).value;
				bh_function = escape(bh_function);
			}
			
			//alert("bh_function ::"+bh_function);
			var querySubFunction =  document.querySelector('[id$="form-qmssearch_prop_bhqms_sub_function"]');
			if(querySubFunction!= null && querySubFunction!="" && querySubFunction!="null" && querySubFunction!="undefined"){
				bh_sub_function = Dom.get(querySubFunction.id).value;
				bh_sub_function = escape(bh_sub_function);
			}
			
			//alert("bh_sub_function ::"+bh_sub_function);
			var querySite =  document.querySelector('[id$="form-qmssearch_prop_bhqms_site"]');
			if(querySite!= null && querySite!="" && querySite!="null" && querySite!="undefined"){
				bh_site = Dom.get(querySite.id).value;
				bh_site = escape(bh_site);
			}
	       // alert("bh_site ::"+bh_site);
			
             var querydocType =  document.querySelector('[id$="form-qmssearch_prop_bhqms_document_type"]');
			if(querydocType!= null && querydocType!="" && querydocType!="null" && querydocType!="undefined"){
				bh_docType = Dom.get(querydocType.id).value;
				bh_docType = escape(bh_docType);
			}
	      //  alert("bh_docType ::"+bh_docType);	
             
            var queryIsoElement =  document.querySelector('[id$="form-qmssearch_prop_bhqms_iso_element"]');
			if(queryIsoElement!= null && queryIsoElement!="" && queryIsoElement!="null" && queryIsoElement!="undefined"){
				bh_isoElement = Dom.get(queryIsoElement.id).value;
				bh_isoElement = escape(bh_isoElement);
			}
	        //alert("bh_isoElement ::"+bh_isoElement);	
			
            var queryUserRole =  document.querySelector('[id$="form-qmssearch_prop_bhqms_user_role"]');
			if(queryUserRole!= null && queryUserRole!="" && queryUserRole!="null" && queryUserRole!="undefined"){
				bh_userRole = Dom.get(queryUserRole.id).value;
				bh_userRole = escape(bh_userRole);
			}
	       // alert("bh_userRole ::"+bh_userRole);	

            var queryProcess =  document.querySelector('[id$="form-qmssearch_prop_bhqms_process"]');
			if(queryProcess!= null && queryProcess!="" && queryProcess!="null" && queryProcess!="undefined"){
				bh_process = Dom.get(queryProcess.id).value;
				bh_process = escape(bh_process);
			}
	       // alert("bh_process ::"+bh_process);	
             
             var querySubProcess =  document.querySelector('[id$="form-qmssearch_prop_bhqms_sub_process"]');
			if(querySubProcess!= null && querySubProcess!="" && querySubProcess!="null" && querySubProcess!="undefined"){
				bh_subProcess = Dom.get(querySubProcess.id).value;
				bh_subProcess = escape(bh_subProcess);
			}
	       // alert("bh_subProcess ::"+bh_subProcess);	
			
           var queryContentCategory =  document.querySelector('[id$="form-qmssearch_prop_bhqms_content_category"]');
			if(queryContentCategory!= null && queryContentCategory!="" && queryContentCategory!="null" && queryContentCategory!="undefined"){
				bh_contentCategory = Dom.get(queryContentCategory.id).value;
				bh_contentCategory = escape(bh_contentCategory);
			}
	       // alert("bh_contentCategory ::"+bh_contentCategory);
			
             var queryLanguage =  document.querySelector('[id$="form-qmssearch_prop_bhqms_language_ode"]');
			if(queryLanguage!= null && queryLanguage!="" && queryLanguage!="null" && queryLanguage!="undefined"){
				bh_language = Dom.get(queryLanguage.id).value;
				bh_language = escape(bh_language);
			}
	      //  alert("bh_language ::"+bh_language);	
			
			
			var queryDocumentAuthor =  document.querySelector('[id$="form-qmssearch_assoc_bhqms_document_author"]');
			if(queryDocumentAuthor!= null && queryDocumentAuthor!="" && queryDocumentAuthor!="null" && queryDocumentAuthor!="undefined"){
				bh_document_author = Dom.get(queryDocumentAuthor.id).value;
				bh_document_author = escape(bh_document_author);
			}
			
			//alert("bh_document_author ::"+bh_document_author);
			var queryDocumentAdmin =  document.querySelector('[id$="form-qmssearch_assoc_bhqms_document_admin"]');
			if(queryDocumentAdmin!= null && queryDocumentAdmin!="" && queryDocumentAdmin!="null" && queryDocumentAdmin!="undefined"){
				bh_document_admin = Dom.get(queryDocumentAdmin.id).value;
				bh_document_admin = escape(bh_document_admin);
			}
			
			//alert("bh_document_admin ::"+bh_document_admin);
			var queryFunctionOwner =  document.querySelector('[id$="form-qmssearch_assoc_bhqms_functional_owner"]');
			if(queryFunctionOwner!= null && queryFunctionOwner!="" && queryFunctionOwner!="null" && queryFunctionOwner!="undefined"){
				bh_functional_owner = Dom.get(queryFunctionOwner.id).value;
				bh_functional_owner = escape(bh_functional_owner);
			}
			//alert("bh_functional_owner ::"+bh_functional_owner);
			var queryDocumentState =  document.querySelector('[id$="form-qmssearch_prop_bhqms_document_state"]');
			if(queryDocumentState!= null && queryDocumentState!="" && queryDocumentState!="null" && queryDocumentState!="undefined"){
				bh_document_state = Dom.get(queryDocumentState.id).value;
				bh_document_state = escape(bh_document_state);
			}
			
			//alert("bh_document_state ::"+bh_document_state);
			
			var queryDCTMId =  document.querySelector('[id$="form-qmssearch_prop_bhqms_dctm_object_id"]');
			if(queryDCTMId!= null && queryDCTMId!="" && queryDCTMId!="null" && queryDCTMId!="undefined"){
				bh_dctm_id = Dom.get(queryDCTMId.id).value;
				bh_dctm_id = escape(bh_dctm_id);
			}
		
			  document.getElementById("loading-container").style.display='block';
			
			//alert("bh_dctm_id ::"+bh_dctm_id);
			var url = YAHOO.lang.substitute(Alfresco.constants.PROXY_URI+"/qmsAdvancedSearch?publishTo={publishTo}&publishFrom={publishFrom}&bhExportExcel={bhExportExcel}&expiryTo={expiryTo}&expiryFrom={expiryFrom}&effectiveTo={effectiveTo}&effectiveFrom={effectiveFrom}&name={name}&docReference={docReference}&productCompany={productCompany}&productLine={productLine}&subProductLine={subProductLine}&bhFunction={bhFunction}&subFunction={subFunction}&site={site}&docType={docType}&isoElement={isoElement}&userRole={userRole}&process={process}&subProcess={subProcess}&contentCategory={contentCategory}&language={language}&docAdmin={docAdmin}&docAuthor={docAuthor}&funOwner={funOwner}&docState={docState}&dctmId={dctmId}",
			{
				publishTo:bh_publish_date_to,
				publishFrom:bh_publish_date_from,
				bhExportExcel:'false',
				expiryTo:bh_expiry_date_to,
				expiryFrom:bh_expiry_date_from,
				effectiveTo:bh_effective_date_to,
				effectiveFrom:bh_effective_date_from,
				name:bh_name,
				docReference:bh_docReference,
				productCompany:bh_product_company,
				productLine:bh_product_line,
				subProductLine:bh_sub_product_line,
				bhFunction:bh_function,
				subFunction:bh_sub_function,
				site:bh_site,
				docType:bh_docType,
				isoElement:bh_isoElement,
				userRole:bh_userRole,
				process:bh_process,
				subProcess:bh_subProcess,
				contentCategory:bh_contentCategory,
				language:bh_language,
				docAdmin:bh_document_admin,
				docAuthor:bh_document_author,
				funOwner:bh_functional_owner,
				docState:bh_document_state,
				dctmId:bh_dctm_id
			});
			
			Alfresco.util.Ajax.jsonGet(
			{
			   url: url,
			   successCallback:
			   {
					fn: function onFormTemplateLoaded(response)
					{
						  document.getElementById("loading-container").style.display='none';
						 var searchDocs = response.json.resultSet;
						YAHOO.util.Dom.get("list-docs").innerHTML="";
						this.showAllSearchDocuments(searchDocs);
					},
					scope: this
			   },
			   failureCallback:
			   {
					fn: function(o)
					{
						var obj = YAHOO.lang.JSON.parse(o.serverResponse.responseText);
						Alfresco.util.PopupManager.displayPrompt(
						{
							title: "Failure",
							text: obj.message
						});
					},
					scope: this
				}
			});
		},
		
		showAllSearchDocuments : function showAllSearchDocuments(searchDocs)
		{
			//alert(searchDocs.length);
			if(searchDocs.length == 0)
			{
				YAHOO.util.Dom.get("list-docs").innerHTML = "No documents found to be displayed with the above search criteria.";
				return;
			}
			for(var i=0; i<searchDocs.length; i++)
			{
				var obj = JSON.parse(JSON.stringify(searchDocs[i]));
				var docLink = "/share/page/site/bh-qms-documents/document-details?nodeRef="+obj.nodeRef;
				var linkObjectName = "<a href="+docLink+" target=\"_blank\" style=color:blue;><u>"+obj.name+"</u></a>";
				var objFA= {cm_name:linkObjectName,bhqms_reference:obj.reference,bhqms_publish_revision:obj.revisionNo,bhqms_document_state:obj.docState,bhqms_product_company:obj.productCompany,bhqms_product_line:obj.productLine,bhqms_sub_product_line:obj.subProductLine,bhqms_site:obj.site,bhqms_function:obj.bhFunction,bhqms_sub_function:obj.subFunction,bhqms_document_type:obj.docType};
				filteredData.push(objFA);
				filteredDataIds.add(obj.nodeRef);
			}
			this.setSearchDocsListElement(filteredData);
			filteredData=[];
		},
		setSearchDocsListElement : function setSearchDocsListElement(filteredData)
		{
			YAHOO.example.Data = {
				filteredDataTD: filteredData
			}
			filteredData =[];
			this.SearchDocListDiv = YAHOO.util.Dom.get("list-docs");
			this.SearchDocListDiv.innerHTML = "QMS Search Results-1";
			var columns = null;
			columns = [
						{key :'cm_name',label : "Document Name", sortable:true},
						{key :'bhqms_reference',label : "Document Reference", sortable:true},
						{key :'bhqms_publish_revision',label : "Revision No", sortable:true},
						{key :'bhqms_document_state',label : "Document State", sortable:true},
						{key :'bhqms_product_company',label : "Product Company", sortable:true},
						{key :'bhqms_product_line',label : "Product Line", sortable:true},
						{key :'bhqms_sub_product_line',label : "Subproduct Line", sortable:true},
						{key :'bhqms_site',label : "Site", sortable:true},
						{key :'bhqms_function',label : "Function", sortable:true},
						{key :'bhqms_sub_function',label : "Sub/Issuing Function", sortable:true},
						{key :'bhqms_document_type',label : "Document Type", sortable:true},
						 						
					  ];
			var myDataSource = new YAHOO.util.DataSource(YAHOO.example.Data.filteredDataTD);
			myDataSource.responseType = YAHOO.util.DataSource.TYPE_JSARRAY;
			console.log("my datasource.."+myDataSource);
			myDataSource.responseSchema = {
				fields: ["cm_name","bhqms_reference","bhqms_publish_revision","bhqms_document_state","bhqms_product_company","bhqms_product_line","bhqms_sub_product_line","bhqms_site","bhqms_function","bhqms_sub_function","bhqms_document_type"]
			};
			myConfigs = {
				paginator : new YAHOO.widget.Paginator({
					rowsPerPage: 100
				})
			};
			//FTL control of datatabel
			table = new YAHOO.widget.DataTable("list-docs",columns,myDataSource,myConfigs);
		},
		
		onExportClick : function onExportClick(p_oEvent){ 
			var excelArray = [];
			var filteredDataIdsArray=Array.from(filteredDataIds);
			
			if((filteredDataIdsArray.length===0)){
				Alfresco.util.PopupManager.displayMessage(
					{
					   text: this.msg("No records found to be Exported, please click on Search before Exporting")
					});
				return;
			}
			
			for(var i=0; i<filteredDataIdsArray.length; i++)
			{
				var wfid = filteredDataIdsArray[i];
				excelArray.push(wfid);
			}
			filteredDataIdsArray = [];


			var bh_publish_date_from = "",
				bh_publish_date_to = "",
				bh_expiry_date_from="",
				bh_expiry_date_to="",
				bh_effective_date_from="",
				bh_effective_date_to="",
				bh_name="",
				bh_docReference="",
				bh_product_company="",
				bh_product_line="",
				bh_sub_product_line="",
				bh_function="",
				bh_sub_function="",
				bh_site="",
				bh_docType="",
				bh_isoElement="",
				bh_userRole="",
				bh_process="",
				bh_subProcess="",
				bh_contentCategory="",
				bh_language="",
				bh_document_author="",
				bh_document_admin="",
				bh_functional_owner="",
				bh_document_state="",
				bh_dctm_id="";
				
			var querySelectFrom =  document.querySelector('[id$="form-qmssearch_prop_bhqms_published_date-cntrl-date-from"]');
			if(querySelectFrom != null && querySelectFrom!="" && querySelectFrom!="null" && querySelectFrom!="undefined"){
				bh_publish_date_from = Dom.get(querySelectFrom.id).value;
			}
			//alert("bh_publish_date_from ::"+bh_publish_date_from);
			var querySelectTo =  document.querySelector('[id$="form-qmssearch_prop_bhqms_published_date-cntrl-date-to"]');
			if(querySelectTo != null && querySelectTo!="" && querySelectTo!="null" && querySelectTo!="undefined"){
				bh_publish_date_to = Dom.get(querySelectTo.id).value;
			}
		//	alert("bh_publish_date_to ::"+bh_publish_date_to);
		
			var querySelectExpFrom =  document.querySelector('[id$="form-qmssearch_prop_bhqms_expiry_date-cntrl-date-from"]');
			if(querySelectExpFrom != null && querySelectExpFrom!="" && querySelectExpFrom!="null" && querySelectExpFrom!="undefined"){
				bh_expiry_date_from = Dom.get(querySelectExpFrom.id).value;
			}
			//alert("bh_expiry_date_from ::"+bh_expiry_date_from);
			var querySelectExpTo =  document.querySelector('[id$="form-qmssearch_prop_bhqms_expiry_date-cntrl-date-to"]');
			if(querySelectExpTo!= null && querySelectExpTo!="" && querySelectExpTo!="null" && querySelectExpTo!="undefined"){
				bh_expiry_date_to = Dom.get(querySelectExpTo.id).value;
			}
		//	alert("bh_expiry_date_to ::"+bh_expiry_date_to);
			var querySelectEffFrom =  document.querySelector('[id$="form-qmssearch_prop_bhqms_effective_date-cntrl-date-from"]');
			if(querySelectEffFrom != null && querySelectEffFrom!="" && querySelectEffFrom!="null" && querySelectEffFrom!="undefined"){
				bh_effective_date_from = Dom.get(querySelectEffFrom.id).value;
			}
			//alert("bh_effective_date_from ::"+bh_effective_date_from);
			var querySelectEffTo =  document.querySelector('[id$="form-qmssearch_prop_bhqms_effective_date-cntrl-date-to"]');
			if(querySelectEffTo!= null && querySelectEffTo!="" && querySelectEffTo!="null" && querySelectEffTo!="undefined"){
				bh_effective_date_to = Dom.get(querySelectEffTo.id).value;
			}
			//alert("bh_effective_date_to ::"+bh_effective_date_to);
			
			var queryName =  document.querySelector('[id$="form-qmssearch_prop_cm_name"]');
			if(queryName!= null && queryName!="" && queryName!="null" && queryName!="undefined"){
				bh_name = Dom.get(queryName.id).value;
				bh_name = escape(bh_name);
			}
			//alert("bh_name ::"+bh_name);
			
			var querydocReference =  document.querySelector('[id$="form-qmssearch_prop_bhqms_reference"]');
			if(querydocReference!= null && querydocReference!="" && querydocReference!="null" && querydocReference!="undefined"){
				bh_docReference = Dom.get(querydocReference.id).value;
				bh_docReference = escape(bh_docReference);
			}
		//	alert("bh_docReference ::"+bh_docReference);
			
			var queryProductCompany =  document.querySelector('[id$="form-qmssearch_prop_bhqms_product_company"]');
			//alert("&&&&& "+queryProductCompany)
			if(queryProductCompany!= null && queryProductCompany!="" && queryProductCompany!="null" && queryProductCompany!="undefined"){
				bh_product_company = Dom.get(queryProductCompany.id).value;
				bh_product_company = escape(bh_product_company);
			}
			
		   // alert("bh_product_company ::"+bh_product_company);
			var queryProductLine =  document.querySelector('[id$="form-qmssearch_prop_bhqms_product_line"]');
			//alert("&&&&& "+queryProductCompany)
			if(queryProductLine!= null && queryProductLine!="" && queryProductLine!="null" && queryProductLine!="undefined"){
				bh_product_line = Dom.get(queryProductLine.id).value;
				bh_product_line = escape(bh_product_line);
			}
			
			//alert("bh_product_line ::"+bh_product_line);
			var querySubProductLine =  document.querySelector('[id$="form-qmssearch_prop_bhqms_sub_product_line"]');
			if(querySubProductLine!= null && querySubProductLine!="" && querySubProductLine!="null" && querySubProductLine!="undefined"){
				bh_sub_product_line = Dom.get(querySubProductLine.id).value;
				bh_sub_product_line = escape(bh_sub_product_line);
			}
			
		//	alert("bh_sub_product_line ::"+bh_sub_product_line);
			var queryFunction =  document.querySelector('[id$="form-qmssearch_prop_bhqms_function"]');
			if(queryFunction!= null && queryFunction!="" && queryFunction!="null" && queryFunction!="undefined"){
				bh_function = Dom.get(queryFunction.id).value;
				bh_function = escape(bh_function);
			}
			
			//alert("bh_function ::"+bh_function);
			var querySubFunction =  document.querySelector('[id$="form-qmssearch_prop_bhqms_sub_function"]');
			if(querySubFunction!= null && querySubFunction!="" && querySubFunction!="null" && querySubFunction!="undefined"){
				bh_sub_function = Dom.get(querySubFunction.id).value;
				bh_sub_function = escape(bh_sub_function);
			}
			
			//alert("bh_sub_function ::"+bh_sub_function);
			var querySite =  document.querySelector('[id$="form-qmssearch_prop_bhqms_site"]');
			if(querySite!= null && querySite!="" && querySite!="null" && querySite!="undefined"){
				bh_site = Dom.get(querySite.id).value;
				bh_site = escape(bh_site);
			}
	       // alert("bh_site ::"+bh_site);
			
             var querydocType =  document.querySelector('[id$="form-qmssearch_prop_bhqms_document_type"]');
			if(querydocType!= null && querydocType!="" && querydocType!="null" && querydocType!="undefined"){
				bh_docType = Dom.get(querydocType.id).value;
				bh_docType = escape(bh_docType);
			}
	      //  alert("bh_docType ::"+bh_docType);	
             
            var queryIsoElement =  document.querySelector('[id$="form-qmssearch_prop_bhqms_iso_element"]');
			if(queryIsoElement!= null && queryIsoElement!="" && queryIsoElement!="null" && queryIsoElement!="undefined"){
				bh_isoElement = Dom.get(queryIsoElement.id).value;
				bh_isoElement = escape(bh_isoElement);
			}
	        //alert("bh_isoElement ::"+bh_isoElement);	
			
            var queryUserRole =  document.querySelector('[id$="form-qmssearch_prop_bhqms_user_role"]');
			if(queryUserRole!= null && queryUserRole!="" && queryUserRole!="null" && queryUserRole!="undefined"){
				bh_userRole = Dom.get(queryUserRole.id).value;
				bh_userRole = escape(bh_userRole);
			}
	       // alert("bh_userRole ::"+bh_userRole);	

            var queryProcess =  document.querySelector('[id$="form-qmssearch_prop_bhqms_process"]');
			if(queryProcess!= null && queryProcess!="" && queryProcess!="null" && queryProcess!="undefined"){
				bh_process = Dom.get(queryProcess.id).value;
				bh_process = escape(bh_process);
			}
	       // alert("bh_process ::"+bh_process);	
             
             var querySubProcess =  document.querySelector('[id$="form-qmssearch_prop_bhqms_sub_process"]');
			if(querySubProcess!= null && querySubProcess!="" && querySubProcess!="null" && querySubProcess!="undefined"){
				bh_subProcess = Dom.get(querySubProcess.id).value;
				bh_subProcess = escape(bh_subProcess);
			}
	       // alert("bh_subProcess ::"+bh_subProcess);	
			
           var queryContentCategory =  document.querySelector('[id$="form-qmssearch_prop_bhqms_content_category"]');
			if(queryContentCategory!= null && queryContentCategory!="" && queryContentCategory!="null" && queryContentCategory!="undefined"){
				bh_contentCategory = Dom.get(queryContentCategory.id).value;
				bh_contentCategory = escape(bh_contentCategory);
			}
	       // alert("bh_contentCategory ::"+bh_contentCategory);
			
             var queryLanguage =  document.querySelector('[id$="form-qmssearch_prop_bhqms_language_ode"]');
			if(queryLanguage!= null && queryLanguage!="" && queryLanguage!="null" && queryLanguage!="undefined"){
				bh_language = Dom.get(queryLanguage.id).value;
				bh_language = escape(bh_language);
			}
	      //  alert("bh_language ::"+bh_language);	
			
			
			var queryDocumentAuthor =  document.querySelector('[id$="form-qmssearch_assoc_bhqms_document_author"]');
			if(queryDocumentAuthor!= null && queryDocumentAuthor!="" && queryDocumentAuthor!="null" && queryDocumentAuthor!="undefined"){
				bh_document_author = Dom.get(queryDocumentAuthor.id).value;
				bh_document_author = escape(bh_document_author);
			}
			
			//alert("bh_document_author ::"+bh_document_author);
			var queryDocumentAdmin =  document.querySelector('[id$="form-qmssearch_assoc_bhqms_document_admin"]');
			if(queryDocumentAdmin!= null && queryDocumentAdmin!="" && queryDocumentAdmin!="null" && queryDocumentAdmin!="undefined"){
				bh_document_admin = Dom.get(queryDocumentAdmin.id).value;
				bh_document_admin = escape(bh_document_admin);
			}
			
			//alert("bh_document_admin ::"+bh_document_admin);
			var queryFunctionOwner =  document.querySelector('[id$="form-qmssearch_assoc_bhqms_functional_owner"]');
			if(queryFunctionOwner!= null && queryFunctionOwner!="" && queryFunctionOwner!="null" && queryFunctionOwner!="undefined"){
				bh_functional_owner = Dom.get(queryFunctionOwner.id).value;
				bh_functional_owner = escape(bh_functional_owner);
			}
			//alert("bh_functional_owner ::"+bh_functional_owner);
			var queryDocumentState =  document.querySelector('[id$="form-qmssearch_prop_bhqms_document_state"]');
			if(queryDocumentState!= null && queryDocumentState!="" && queryDocumentState!="null" && queryDocumentState!="undefined"){
				bh_document_state = Dom.get(queryDocumentState.id).value;
				bh_document_state = escape(bh_document_state);
			}
			
			//alert("bh_document_state ::"+bh_document_state);
			
			var queryDCTMId =  document.querySelector('[id$="form-qmssearch_prop_bhqms_dctm_object_id"]');
			if(queryDCTMId!= null && queryDCTMId!="" && queryDCTMId!="null" && queryDCTMId!="undefined"){
				bh_dctm_id = Dom.get(queryDCTMId.id).value;
				bh_dctm_id = escape(bh_dctm_id);
			}
			
			//alert("bh_dctm_id ::"+bh_dctm_id);
			
			var url = YAHOO.lang.substitute(Alfresco.constants.PROXY_URI+"/downloadReport?typeOfReport={typeOfReport}&publishTo={publishTo}&publishFrom={publishFrom}&bhExportExcel={bhExportExcel}&expiryTo={expiryTo}&expiryFrom={expiryFrom}&effectiveTo={effectiveTo}&effectiveFrom={effectiveFrom}&name={name}&docReference={docReference}&productCompany={productCompany}&productLine={productLine}&subProductLine={subProductLine}&bhFunction={bhFunction}&subFunction={subFunction}&site={site}&docType={docType}&isoElement={isoElement}&userRole={userRole}&process={process}&subProcess={subProcess}&contentCategory={contentCategory}&language={language}&docAdmin={docAdmin}&docAuthor={docAuthor}&funOwner={funOwner}&docState={docState}&dctmId={dctmId}",
			{
				typeOfReport: 'QMS Search Results',
				publishTo:bh_publish_date_to,
				publishFrom:bh_publish_date_from,
				bhExportExcel:'true',
				expiryTo:bh_expiry_date_to,
				expiryFrom:bh_expiry_date_from,
				effectiveTo:bh_effective_date_to,
				effectiveFrom:bh_effective_date_from,
				name:bh_name,
				docReference:bh_docReference,
				productCompany:bh_product_company,
				productLine:bh_product_line,
				subProductLine:bh_sub_product_line,
				bhFunction:bh_function,
				subFunction:bh_sub_function,
				site:bh_site,
				docType:bh_docType,
				isoElement:bh_isoElement,
				userRole:bh_userRole,
				process:bh_process,
				subProcess:bh_subProcess,
				contentCategory:bh_contentCategory,
				language:bh_language,
				docAdmin:bh_document_admin,
				docAuthor:bh_document_author,
				funOwner:bh_functional_owner,
				docState:bh_document_state,
				dctmId:bh_dctm_id
			});
			
			window.location.href=url;
		},
		
		onClearClick : function onClearClick(p_oEvent){ 
			
			var querySelectFrom =  document.querySelector('[id$="form-qmssearch_prop_bhqms_published_date-cntrl-date-from"]');
			if(querySelectFrom != null && querySelectFrom!="" && querySelectFrom!="null" && querySelectFrom!="undefined"){
				Dom.get(querySelectFrom.id).value = "";
			}
			var querySelectTo =  document.querySelector('[id$="form-qmssearch_prop_bhqms_published_date-cntrl-date-to"]');
			if(querySelectTo != null && querySelectTo!="" && querySelectTo!="null" && querySelectTo!="undefined"){
				Dom.get(querySelectTo.id).value = "";
			}
			var querySelectExpFrom =  document.querySelector('[id$="form-qmssearch_prop_bhqms_expiry_date-cntrl-date-from"]');
			if(querySelectExpFrom != null && querySelectExpFrom!="" && querySelectExpFrom!="null" && querySelectExpFrom!="undefined"){
				Dom.get(querySelectExpFrom.id).value = "";
			}
			var querySelectExpTo =  document.querySelector('[id$="form-qmssearch_prop_bhqms_expiry_date-cntrl-date-to"]');
			if(querySelectExpTo!= null && querySelectExpTo!="" && querySelectExpTo!="null" && querySelectExpTo!="undefined"){
				Dom.get(querySelectExpTo.id).value = "";
			}
			var querySelectEffFrom =  document.querySelector('[id$="form-qmssearch_prop_bhqms_effective_date-cntrl-date-from"]');
			if(querySelectEffFrom != null && querySelectEffFrom!="" && querySelectEffFrom!="null" && querySelectEffFrom!="undefined"){
				Dom.get(querySelectEffFrom.id).value = "";
			}
			var querySelectEffTo =  document.querySelector('[id$="form-qmssearch_prop_bhqms_effective_date-cntrl-date-to"]');
			if(querySelectEffTo!= null && querySelectEffTo!="" && querySelectEffTo!="null" && querySelectEffTo!="undefined"){
				Dom.get(querySelectEffTo.id).value = "";
			}
			var queryName =  document.querySelector('[id$="form-qmssearch_prop_cm_name"]');
			if(queryName!= null && queryName!="" && queryName!="null" && queryName!="undefined"){
				Dom.get(queryName.id).value = "";
			}
			var querydocReference =  document.querySelector('[id$="form-qmssearch_prop_bhqms_reference"]');
			if(querydocReference!= null && querydocReference!="" && querydocReference!="null" && querydocReference!="undefined"){
				Dom.get(querydocReference.id).value = "";
			}
			var queryProductCompany =  document.querySelector('[id$="form-qmssearch_prop_bhqms_product_company"]');
			if(queryProductCompany!= null && queryProductCompany!="" && queryProductCompany!="null" && queryProductCompany!="undefined"){
				Dom.get(queryProductCompany.id).value = "";
			}
			var queryProductLine =  document.querySelector('[id$="form-qmssearch_prop_bhqms_product_line"]');
			if(queryProductLine!= null && queryProductLine!="" && queryProductLine!="null" && queryProductLine!="undefined"){
				this.clearMultiFieldValues(queryProductLine.id);
			}
			var querySubProductLine =  document.querySelector('[id$="form-qmssearch_prop_bhqms_sub_product_line"]');
			if(querySubProductLine!= null && querySubProductLine!="" && querySubProductLine!="null" && querySubProductLine!="undefined"){
				this.clearMultiFieldValues(querySubProductLine.id);
			}
			var queryFunction =  document.querySelector('[id$="form-qmssearch_prop_bhqms_function"]');
			if(queryFunction!= null && queryFunction!="" && queryFunction!="null" && queryFunction!="undefined"){
				this.clearMultiFieldValues(queryFunction.id);
			}
			var querySubFunction =  document.querySelector('[id$="form-qmssearch_prop_bhqms_sub_function"]');
			if(querySubFunction!= null && querySubFunction!="" && querySubFunction!="null" && querySubFunction!="undefined"){
				Dom.get(querySubFunction.id).value = "";
			}
			var querySite =  document.querySelector('[id$="form-qmssearch_prop_bhqms_site"]');
			if(querySite!= null && querySite!="" && querySite!="null" && querySite!="undefined"){
				this.clearMultiFieldValues(querySite.id);
			}
			var querydocType =  document.querySelector('[id$="form-qmssearch_prop_bhqms_document_type"]');
			if(querydocType!= null && querydocType!="" && querydocType!="null" && querydocType!="undefined"){
				Dom.get(querydocType.id).value = "";
			}
			var queryIsoElement =  document.querySelector('[id$="form-qmssearch_prop_bhqms_iso_element"]');
			if(queryIsoElement!= null && queryIsoElement!="" && queryIsoElement!="null" && queryIsoElement!="undefined"){
				this.clearMultiFieldValues(queryIsoElement.id);
			}
	        var queryUserRole =  document.querySelector('[id$="form-qmssearch_prop_bhqms_user_role"]');
			if(queryUserRole!= null && queryUserRole!="" && queryUserRole!="null" && queryUserRole!="undefined"){
				this.clearMultiFieldValues(queryUserRole.id);
			}
			var queryProcess =  document.querySelector('[id$="form-qmssearch_prop_bhqms_process"]');
			if(queryProcess!= null && queryProcess!="" && queryProcess!="null" && queryProcess!="undefined"){
				this.clearMultiFieldValues(queryProcess.id);
			}
	        var querySubProcess =  document.querySelector('[id$="form-qmssearch_prop_bhqms_sub_process"]');
			if(querySubProcess!= null && querySubProcess!="" && querySubProcess!="null" && querySubProcess!="undefined"){
				this.clearMultiFieldValues(querySubProcess.id);
			}
			var queryContentCategory =  document.querySelector('[id$="form-qmssearch_prop_bhqms_content_category"]');
			if(queryContentCategory!= null && queryContentCategory!="" && queryContentCategory!="null" && queryContentCategory!="undefined"){
				Dom.get(queryContentCategory.id).value = "";
			}
			var queryLanguage =  document.querySelector('[id$="form-qmssearch_prop_bhqms_language_code"]');
			if(queryLanguage!= null && queryLanguage!="" && queryLanguage!="null" && queryLanguage!="undefined"){
				Dom.get(queryLanguage.id).value = "";
			}
			var queryDocumentAuthor =  document.querySelector('[id$="form-qmssearch_assoc_bhqms_document_author"]');
			if(queryDocumentAuthor!= null && queryDocumentAuthor!="" && queryDocumentAuthor!="null" && queryDocumentAuthor!="undefined"){
				Dom.get(queryDocumentAuthor.id).value = "";
				Dom.get(queryDocumentAuthor.id+"-cntrl-currentValueDisplay").innerHTML = "";
			}
			var queryDocumentAdmin =  document.querySelector('[id$="form-qmssearch_assoc_bhqms_document_admin"]');
			if(queryDocumentAdmin!= null && queryDocumentAdmin!="" && queryDocumentAdmin!="null" && queryDocumentAdmin!="undefined"){
				Dom.get(queryDocumentAdmin.id).value = "";
				Dom.get(queryDocumentAdmin.id+"-cntrl-currentValueDisplay").innerHTML = "";
			}
			var queryFunctionOwner =  document.querySelector('[id$="form-qmssearch_assoc_bhqms_functional_owner"]');
			if(queryFunctionOwner!= null && queryFunctionOwner!="" && queryFunctionOwner!="null" && queryFunctionOwner!="undefined"){
				Dom.get(queryFunctionOwner.id).value = "";
				Dom.get(queryFunctionOwner.id+"-cntrl-currentValueDisplay").innerHTML = "";
			}
			var queryDocumentState =  document.querySelector('[id$="form-qmssearch_prop_bhqms_document_state"]');
			if(queryDocumentState!= null && queryDocumentState!="" && queryDocumentState!="null" && queryDocumentState!="undefined"){
				Dom.get(queryDocumentState.id).value = "";
			}
			var queryDCTMId =  document.querySelector('[id$="form-qmssearch_prop_bhqms_dctm_object_id"]');
			if(queryDCTMId!= null && queryDCTMId!="" && queryDCTMId!="null" && queryDCTMId!="undefined"){
				Dom.get(queryDCTMId.id).value = "";
			}
		},
		
		clearMultiFieldValues : function clearMultiFieldValues(elementId){
			var entries = Dom.get(elementId+"-entry");
			var entryLength = entries.options.length;
			for(var count=1; count<entryLength; count++){
				entries.options[1] = null;
			}
			
			Dom.get(elementId).value = "";
			Dom.get(elementId+"-textarea").value = "";
		}
		
	});
})();