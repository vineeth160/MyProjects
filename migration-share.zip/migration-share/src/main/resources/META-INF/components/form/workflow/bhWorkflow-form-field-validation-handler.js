var BakerhughesWorkflow = {};
BakerhughesWorkflow.forms = {};
BakerhughesWorkflow.forms.validation = {};
BakerhughesWorkflow.forms.validation.fields = {};

// To validate Publisher Assignee whenever this filed needs to be hidden
BakerhughesWorkflow.forms.validation.fields.publisher = function workflowFields(field, args, event, form, silent, message) {
	var valid = true;
	var formId = form.formId;
	var isAutoPublishId = document.querySelector('[id$="_prop_bhwf_bh_auto_publish"]').id;
	var isAutoPublish = document.getElementById(isAutoPublishId).value;
	
	var assignee = field.value;
	//console.log("isAutoPublish");
	//console.log(isAutoPublish);
	//console.log("assignee value");
	//console.log(assignee);
	if(isAutoPublish == "NO" && (assignee=="" || assignee==null || assignee=="null")){
		valid = false;
	}
	//console.log(valid);
	return valid;
}


BakerhughesWorkflow.forms.validation.fields.publisherAdminReview = function workflowFields(field, args, event, form, silent, message) {
	var valid = true;
	var formId = form.formId;
	var isAutoPublishId = document.querySelector('[id$="_prop_bhwf_bh_auto_publish"]').id;
	var isAutoPublish = document.getElementById(isAutoPublishId).value;
	var wfActionsId = document.querySelector('[id$="_prop_bhwf_wf_actions"]').id;
	var wfActions = document.getElementById(wfActionsId).value;
	
	var assignee = field.value;
	//console.log("isAutoPublish");
	//console.log(isAutoPublish);
	//console.log("assignee value");
	//console.log(assignee);
	if(isAutoPublish == "NO" && (assignee=="" || assignee==null || assignee=="null")){
		if(wfActions == "Send to SME")
			valid = true;
		else
			valid = false;
	}
	//console.log(valid);
	return valid;
}

// To validate Reviewer Assignee whenever this filed needs to be hidden
BakerhughesWorkflow.forms.validation.fields.primaryReviewer = function workflowFields(field, args, event, form, silent, message) {
	var valid = true;
	var formId = form.formId;
	var wfActionsId = document.querySelector('[id$="_prop_bhwf_wf_actions"]').id;
	var wfActions = document.getElementById(wfActionsId).value;
	var assignee = field.value;
	//console.log("wfActions");
	//console.log("assignee value");
	//console.log(assignee);
	if((wfActions == "Approve" || wfActions == "Send to Reviewer") && (assignee=="" || assignee==null || assignee=="null")){
		valid = false;
	}
	//console.log(valid);
	return valid;
}

// To validate Approver Assignee whenever this filed needs to be hidden
BakerhughesWorkflow.forms.validation.fields.primaryApprover = function workflowFields(field, args, event, form, silent, message) {
	var valid = true;
	var formId = form.formId;
	var wfActionsId = document.querySelector('[id$="_prop_bhwf_wf_actions"]').id;
	var wfActions = document.getElementById(wfActionsId).value;
	var assignee = field.value;
	//console.log("wfActions");
	//console.log("assignee value");
	//console.log(assignee);
	if((wfActions == "Approve" || wfActions == "Send to Reviewer") && (assignee=="" || assignee==null || assignee=="null")){
		valid = false;
	}
	//console.log(valid);
	return valid;
}

// To validate SME Assignee whenever this filed needs to be hidden
BakerhughesWorkflow.forms.validation.fields.sme = function workflowFields(field, args, event, form, silent, message) {
	var valid = true;
	var formId = form.formId;
	var wfActionsId = document.querySelector('[id$="_prop_bhwf_wf_actions"]').id;
	var wfActions = document.getElementById(wfActionsId).value;
	var assignee = field.value;
	//console.log("wfActions");
	//console.log("assignee value");
	//console.log(assignee);
	if(wfActions == "Send to SME" && (assignee=="" || assignee==null || assignee=="null")){
		valid = false;
	}
	//console.log(valid);
	return valid;
}

// To validate Archival Assignee whenever this field needs to be hidden
BakerhughesWorkflow.forms.validation.fields.archival = function workflowFields(field, args, event, form, silent, message) {
	var valid = true;
	var formId = form.formId;
	var assignee = field.value;
	var pcId = document.querySelector('[id$="_prop_bhwf_bh_product_company"]').id;
	if(pcId!=null && pcId!="" && pcId!="null" && pcId!="undefined"){
		var pcValue = document.getElementById(pcId).value;
		if(assignee==null && pcValue == "BH-OFS Oilfield Services")
			valid = false;
	}
	//console.log("assignee value");
	//console.log(assignee);
	//console.log(valid);
	return valid;
}

// To validate Archival Approver Assignee whenever this filed needs to be hidden
BakerhughesWorkflow.forms.validation.fields.archivalApprover = function workflowFields(field, args, event, form, silent, message) {
	var valid = true;
	var formId = form.formId;
	var assignee = field.value;
	var pcId = document.querySelector('[id$="_prop_bhwf_bh_product_company"]').id;
	if(pcId!=null && pcId!="" && pcId!="null" && pcId!="undefined"){
		var pcValue = document.getElementById(pcId).value;
		if(assignee==null && pcValue != "BH-OFS Oilfield Services")
			valid = false;
	}
	//console.log(valid);
	return valid;
}

// To validate Evidence Document whenever this filed needs to be hidden
BakerhughesWorkflow.forms.validation.fields.evidence = function workflowFields(field, args, event, form, silent, message) {
	var valid = false;
	var formId = form.formId;
	var documentType = document.querySelector('[id$="_prop_bhwf_document_type"]').id;
	var documentTypeValue = document.getElementById(documentType).value;
	//console.log("evidence value");
	//console.log(field.value);
	if(documentTypeValue == "Record" || documentTypeValue == "External Document" || (field.value!="" && field.value!=null))
		valid = true;
	
	return valid;
}

// To validate Evidence Document whenever this filed needs to be hidden
BakerhughesWorkflow.forms.validation.fields.evidenceAdminReview = function workflowFields(field, args, event, form, silent, message) {
	var valid = true;
	var formId = form.formId;
	var documentType = document.querySelector('[id$="_prop_bhwf_document_type"]').id;
	var documentTypeValue = document.getElementById(documentType).value;
	var wfActionsId = document.querySelector('[id$="_prop_bhwf_wf_actions"]').id;
	var wfActions = document.getElementById(wfActionsId).value;
	//console.log("evidence value");
	//console.log(field.value);
	if((documentTypeValue != "Record" || documentTypeValue != "External Document") && (field.value=="" || field.value==null || field.value=="null")){
		if(wfActions == "Send to Publisher"){
			valid = false;
		}
	}
	
	return valid;
}


// To validate Revision Change Type(Major/Minor) whenever this filed needs to be hidden
BakerhughesWorkflow.forms.validation.fields.revisionType = function workflowFields(field, args, event, form, silent, message) {
	var valid = true;
	var formId = form.formId;
	var requestType = document.querySelector('[id$="prop_bhwf_bh_request_type"]').id;
	var requestTypeValue = document.getElementById(requestType).value;
	//console.log("requestTypeValue :: "+requestTypeValue);
	//console.log(field.value);
	if(requestTypeValue != "NDR" && (field.value=="" || field.value==null || field.value=="null")){
			valid = false;
	}
	
	return valid;
}

// To validate Legal Archival Assignee whenever this filed needs to be hidden
BakerhughesWorkflow.forms.validation.fields.legalPackageItem = function workflowFields(field, args, event, form, silent, message) {
	var valid = true;
	var formId = form.formId;
	var copyTypeId = document.querySelector('[id$="_prop_bhwflegal_og_copy_type"]').id;
	var copyTypeValue = document.getElementById(copyTypeId).value;
	
	var assignee = field.value;
	//console.log("isAutoPublish");
	//console.log(isAutoPublish);
	//console.log("assignee value");
	//console.log(assignee);
	if(copyTypeValue == "Soft Copy" && (assignee=="" || assignee==null || assignee=="null")){
		valid = false;
	}
	//console.log(valid);
	return valid;
}

//To validate Package item based on WF actions
BakerhughesWorkflow.forms.validation.fields.whenReject = function workflowFields(field, args, event, form, silent, message) {
	var valid = true;
	var formId = form.formId;
	var wfActionsId = document.querySelector('[id$="_prop_bhwflegal_og_archive_outcome"]').id;
	var wfActionsValue = document.getElementById(wfActionsId).value;
	
	var packageitem = field.value;
	//console.log("isAutoPublish");
	//console.log(isAutoPublish);
	//console.log("assignee value");
	//console.log(assignee);
	if(wfActionsValue == "Archive" && (packageitem=="" || packageitem==null || packageitem=="null")){
		valid = false;
	}
	//console.log(valid);
	return valid;
}