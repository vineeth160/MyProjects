/**
 * EvidenceAttachmentControl component.
 * 
 * evidenceAttachment.js, 5th May 2020
 *
 * It uses to upload a evidence document as an attachment whenever document should be published without review process by Admins
 * 
 * @namespace BH
 * @class Alfresco.EvidenceAttachmentControl
 */
(function()
{
	/**
	 * YUI Library aliases
	 */
	var Dom = YAHOO.util.Dom,
	Event = YAHOO.util.Event;

	/**
	 * Alfresco Slingshot aliases
	 */
	var $html = Alfresco.util.encodeHTML,
	$hasEventInterest = Alfresco.util.hasEventInterest;

	/**
	 * EvidenceAttachmentControl constructor.
	 * 
	 * @param {String} htmlId The HTML id of the control element
	 * @return {Alfresco.EvidenceAttachmentControl} The new EvidenceAttachmentControl instance
	 * @constructor
	 */
	Alfresco.EvidenceAttachmentControl = function(htmlId)
	{
		Alfresco.EvidenceAttachmentControl.superclass.constructor.call(this, "Alfresco.EvidenceAttachmentControl", htmlId, ["button", "container", "cookie"]);
		this.fileUpload = null;
		YAHOO.Bubbling.on("removeListItem", this.onRemoveListItem, this);
		return this;
	};

	YAHOO.extend(Alfresco.EvidenceAttachmentControl, Alfresco.component.Base,
	{
		/**
		 * Object container for initialization options
		 *
		 * @property options
		 * @type object
		 */
		options:
		{

			/**
			 * current nodeRef
			 * 
			 * @property nodeRef
			 * @type object
			 */
			nodeRef: null,

			/**
			 * object picker
			 * @property picker
			 * @type Alfresco.ObjectFinder
			 */
			objectFinder: null,
			/**
			 * @property site
			 * @type String
			 */
			dlg: null,
			isDataList:false,
			site:"",
			listItemActions: [ ]
		},

		/**
		 * Fired by YUI when parent element is available for scripting.
		 * Component initialisation, including instantiation of YUI widgets and event listener binding.
		 *
		 * @method onReady
		 */
		onReady: function EvidenceAttachmentControl_onReady()
		{
			this.widgets.uploadAttachment = Alfresco.util.createYUIButton(this, "button2", this.onUploadEvidenceAttachment,
			{
				disabled: false
			});   
			if (this.options.allowRemoveAction && this.options.displayMode == "list")
			{
				this.options.listItemActions.push(
				{
					name: "remove-list-item",
					event: "removeListItem",
					label: "form.control.object-picker.remove-item"
				});
			}
		},
		
		/**
		 * onUploadEvidenceAttachment 
		 * Upload Evidence button click handler, which helps to upload a Evidence attachment to a WF package item when there is Direct publish
		 *
		 * @method onUploadEvidenceAttachment
		 * @param e {object} DomEvent
		 * @param p_obj {object} Object passed back from addListener method
		 */
		onUploadEvidenceAttachment: function EvidenceAttachmentControl_onUploadEvidenceAttachment(e, p_obj)
		{
			if (!this.widgets.destinationDialog)
			{

				if(this.options.objectFinder.widgets.currentValuesDataTable.getRecordSet().getLength()==0)
				{
					if (this.fileUpload === null)
					{
						this.fileUpload = Alfresco.getFileUploadInstance(); 
					}
					//var bhProductCompany = document.getElementById("bhProductCompany").value;
					//var bhParentNoderef = document.getElementById("bhParentNoderef").value;
					var bhProductCompany = Dom.get("bhProductCompany").value;
					var bhParentNoderef = Dom.get("bhParentNoderef").value;
					
					// Show uploader for multiple files
					var multiUploadConfig =
					{
						isEvidence: "Yes",
						siteId: this.options.site,
						containerId: "documentLibrary",
						bhContentType: this.options.objectFinder.options.bhContentType,
						bhProductCompany: bhProductCompany,
						bhParentNoderef: bhParentNoderef,
						uploadDirectory: "/",
						filter: [],
						mode: this.fileUpload.MODE_SINGLE_UPLOAD,
						thumbnails: "doclib",
						onFileUploadComplete:
						{
							fn: this.onFileUploadComplete,
							scope: this,
						}
							
					};
					this.fileUpload.show(multiUploadConfig);
				}
			}
		},


		/**
		 * _adjustCurrentValues event handler
		 *
		 * @method _adjustCurrentValues
		 * @param {items} containing all uploaded evidence attachment nodes
		 */

		_adjustCurrentValues: function ObjectFinder__adjustCurrentValues(items)
		{
			var addedItems = this.options.objectFinder.getSelectedItems(),
			removedItems = this.options.objectFinder.getRemovedItems(),
			selectedItems = this.options.objectFinder.getSelectedItems();
			var len = items.length
			for(var i=0;i<len;i++)
			{
				addedItems.push(items[i].nodeRef);
				selectedItems.push(items[i].nodeRef);
				this.options.objectFinder.selectedItems[items[i].nodeRef] = items[i];
			}
			if (this.options.objectFinder.options.maintainAddedRemovedItems)
			{
				Dom.get(this.options.objectFinder.id + "-added").value = addedItems.toString();
				Dom.get(this.options.objectFinder.id + "-removed").value = removedItems.toString();
			}
			Dom.get(this.options.objectFinder.currentValueHtmlId).value = selectedItems.toString();

			// inform the forms runtime that the control value has been updated (if field is mandatory)
			if (this.options.objectFinder.options.mandatory)
			{
				YAHOO.Bubbling.fire("mandatoryControlValueUpdated", this.options.objectFinder);
			}

			YAHOO.Bubbling.fire("formValueChanged",
			{
				eventGroup: this.options.objectFinder,
				addedItems: addedItems,
				removedItems: removedItems,
				selectedItems: selectedItems,
				selectedItemsMetaData: Alfresco.util.deepCopy(this.options.objectFinder.selectedItems)
			});
		},
		
		
		/**
		 * onFileUploadComplete 
		 * onFileUploadComplete, will be triggered upon successful upload of evidence attachment
		 *
		 * @method onUploadEvidenceAttachment
		 * @param {complete, obj} 
		 */
		onFileUploadComplete: function DLTB_onFileUploadComplete(complete,obj)
		{
			var item, link,node;
			var items=[];
			var displayValue = "";
			var success = complete.successful.length;
			for (var i = 0; i < success; i++)
			{
				item=complete.successful[i];
				item.description=item.name;
				item.name=item.fileName;
				item.type=this.options.objectFinder.options.itemType;
				items.push(item);
			}

			// Disable Upload evidence button to allow only single attachment selection starts...
			/* this.widgets.uploadAttachment = Alfresco.util.createYUIButton(this, "button2", null,
					{
				disabled: true
					}); */
			// Disable Upload evidence button to allow only single attachment selection ends...
			this._adjustCurrentValues(items);
			for (var i = 0; i < success; i++)
			{
				item=items[i];
				if (this.options.objectFinder.options.showLinkToTarget && this.options.objectFinder.options.targetLinkTemplate !== null)
				{
					if (this.options.objectFinder.options.displayMode == "items")
					{
						link = null;
						if (YAHOO.lang.isFunction(this.options.objectFinder.options.targetLinkTemplate))
						{
							link = this.options.objectFinder.options.targetLinkTemplate.call(this.options.objectFinder, item);
						}
						else
						{
							//Discard template, build link from scratch
							var linkTemplate = (item.site) ? Alfresco.constants.URL_PAGECONTEXT + "site/{site}/document-details?nodeRef={nodeRef}" : Alfresco.constants.URL_PAGECONTEXT + "document-details?nodeRef={nodeRef}";
							link = YAHOO.lang.substitute(linkTemplate,
							{
								nodeRef : item.nodeRef,
								site : item.site
							});
						}
						displayValue += this.options.objectFinder.options.objectRenderer.renderItem(item, 16, "<div>{icon} <a href='" + link + "'>{name}</a></div>");
					}
					else if (this.options.objectFinder.options.displayMode == "list")
					{
						this.options.objectFinder.widgets.currentValuesDataTable.addRow(item);
					}
				}
				else
				{
					if (this.options.objectFinder.options.displayMode == "items")
					{
						if (item.type === "tag")
						{
							displayValue += this.options.objectFinder.options.objectRenderer.renderItem(item, null, "<div class='itemtype-tag'>{name}</div>");
						}
						else
						{
							displayValue += this.options.objectFinder.options.objectRenderer.renderItem(item, 16, "<div class='itemtype-" + $html(item.type) + "'>{icon} {name}</div>");
						}
					}
					else if (this.options.objectFinder.options.displayMode == "list")
					{
						this.options.objectFinder.widgets.currentValuesDataTable.addRow(item);
					}
				}
			}

			if (this.options.objectFinder.options.displayMode == "items")
			{
				Dom.get(this.options.objectFinder.id + "-currentValueDisplay").innerHTML += displayValue;
			}
			this._enableEvidenceActions();
		},

		
		/**
	    * onRemoveListItem.
	    *
		* Added to remove file from Evidence attachments starts...
	    * @method _enableEvidenceActions
	    * @private
	    */
		onRemoveListItem: function ObjectFinder_onRemoveListItem(event, args)
		{
			//alert("onRemoveListItem");
			/*this.widgets.uploadAttachment.get("classList").remove("yui-button-disabled");
			this.widgets.uploadAttachment.get("classList").remove("yui-push-button-disabled");
			this.widgets.uploadAttachment = Alfresco.util.createYUIButton(this, "button2", this.onUploadEvidenceAttachment,
					{
				disabled: false
					}); */

			if ($hasEventInterest(this, args))
			{
				var data = args[1].value,
				rowId = args[1].rowId;
				this.widgets.currentValuesDataTable.deleteRow(rowId);
				delete this.selectedItems[data.nodeRef];
				this.singleSelectedItem = null;
				this._adjustCurrentValues();
			}
			this._enableEvidenceActions();
			
		},
		
		
		/**
	    * Determines whether the picker is in 'authority' mode.
	    *
	    * @method _enableEvidenceActions
	    * @private
	    */
	    _enableEvidenceActions: function ObjectFinder__enableEvidenceActions()
	    {
			if (this.widgets.uploadAttachment)
			{
				// Enable the add button
				//this.widgets.uploadAttachment.set("disabled", false);
				if(this.options.objectFinder.widgets.currentValuesDataTable.getRecordSet().getLength()===1){
					this.widgets.uploadAttachment.set("disabled", true);
				} else{
					this.widgets.uploadAttachment.set("disabled", false);
				}
			}
	    }
	});
})();