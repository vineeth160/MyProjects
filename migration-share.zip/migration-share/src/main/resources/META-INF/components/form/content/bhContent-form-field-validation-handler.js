var Bakerhughes = {};
Bakerhughes.forms = {};
Bakerhughes.forms.validation = {};
Bakerhughes.forms.validation.content = {};
Bakerhughes.forms.validation.content.fields = {};
(function()
{
	// To validate duplication of Document Reference field
	Bakerhughes.forms.validation.content.fields.reference = function validateReferenceForm(field, args, event, form, silent, message) {
		var valid = true;
		var isDuplicateReference = "";
		var formId = form.formId;
		var nodeRef = document.getElementById(formId).action;
		//console.log(document.getElementById(formId));
		//console.log(field.value);
		//console.log("nodeRef :: "+nodeRef);
		if(nodeRef.includes("/SpacesStore/")){
			nodeRef = nodeRef.split("/SpacesStore/")[1].split("/")[0];
			//console.log("nodeRef Split :: "+nodeRef);
		} else{
			nodeRef = "notApplicable";
		}
		//console.log("nodeRef :: "+nodeRef);
		/* 
		console.log("from form");
		console.log(form.ajaxSubmitHandlers.successCallback.scope.options.defaultUrl);
		if(nodeRef == null || nodeRef == ""){
			nodeRef = form.ajaxSubmitHandlers.successCallback.scope.options.defaultUrl;
		} */
		var referenceNo = field.value;
		isDuplicateReference = validateReference(referenceNo, nodeRef);
		if(isDuplicateReference == "YES")
			valid = false;
		return valid;
	}
	function validateReference(referenceNo, nodeRef){
		var isDuplicateReference = "";
		var webscriptURL = Alfresco.constants.PROXY_URI + "com/bh/content/metadata/validation?referenceNo="+referenceNo+"&nodeRef="+nodeRef;
		jQuery.ajax({
		url: webscriptURL,
		type: "get",
		dataType: "json",
		async: false,
		success: function (response){
				isDuplicateReference = response.isDuplicateReference;
			},
		failure: function (response) {
				console.log("Document Reference Validation webscript has been failed to execute, com/bh/content/metadata/validation?referenceNo="+referenceNo);
			},
		}, this);
		return isDuplicateReference;
	}
	
	
	// To validate Document URL Address field based on Content Category field value(Document/URL)
	Bakerhughes.forms.validation.content.fields.url = function validateURLField(field, args, event, form, silent, message) {
		var valid = true;
		var formId = form.formId;
		var nodeRef = document.getElementById(formId).action;
		//console.log(document.getElementById(formId));
		//console.log("field.name "+field.name);
		//console.log("field.value "+field.value);
		//var bhContentCategory = formId.split("-form")[0]+"_prop_bhqms_content_category";
		//var bhContentCategory = "";
		/*if(formId.includes("-form-form")){
			bhContentCategory = formId.split("-form")[0]+"-form_prop_bhqms_content_category";
		} else{
			bhContentCategory = formId.split("-form")[0]+"_prop_bhqms_content_category";
		}*/
		var querySelect =  document.querySelector('[id$="_prop_bhqms_content_category"]');
		if(querySelect != null && querySelect!="" && querySelect!="null" && querySelect!="undefined" && querySelect!=undefined){
			var bhContentCategoryId = querySelect.id;
			//console.log(" bhContentCategoryId :: "+bhContentCategoryId);
			//alfresco-bhCustomUpload-instance-metadata-form_prop_bhqms_content_category
			var bhContentCategoryValue = "";
			if(document.getElementById(bhContentCategoryId) !=null && document.getElementById(bhContentCategoryId)!=""
				&& document.getElementById(bhContentCategoryId)!="undefined" && document.getElementById(bhContentCategoryId)!=undefined)
				bhContentCategoryValue = document.getElementById(bhContentCategoryId).value;
			
			if(bhContentCategoryValue=="URL"){
				if(field.value=="" || field.value==null || field.value=="null")
					valid=false;
			}
		}
		
		return valid;
	}
	
	// To validate User Role field based on PC (Need only for TPS as mandatory and hiding for others)
	Bakerhughes.forms.validation.content.fields.userRole = function validateUserRole(field, args, event, form, silent, message) {
		var valid = true;
		var formId = form.formId;
		var nodeRef = document.getElementById(formId).action;
		//console.log(document.getElementById(formId));
		//console.log(field.value);
		
		var querySelect =  document.querySelector('[id$="_prop_bhqms_product_company"]');
		if(querySelect != null && querySelect!="" && querySelect!="null" && querySelect!="undefined" && querySelect!=undefined){
			var bhProductCompanyId = querySelect.id;
			//console.log(" bhProductCompanyId :: "+bhProductCompanyId);
			//alfresco-bhCustomUpload-instance-metadata-form_prop_bhqms_content_category
			var bhProductCompanyValue = "";
			if(document.getElementById(bhProductCompanyId) !=null && document.getElementById(bhProductCompanyId)!=""
				&& document.getElementById(bhProductCompanyId)!="undefined" && document.getElementById(bhProductCompanyId)!=undefined)
				bhProductCompanyValue = document.getElementById(bhProductCompanyId).value;
			
			if(bhProductCompanyValue=="BH-TPS Turbomachinery & Process Solutions"){
				if(field.value=="" || field.value==null || field.value=="null")
					valid=false;
			}
		}
		//console.log("nodeRef :: "+nodeRef);
		return valid;
	}
	
	// To validate Product Line field based on PC (Not necessary for GE-Global hence hiding and making non mandatory for Global)
	Bakerhughes.forms.validation.content.fields.productLine = function validatePL(field, args, event, form, silent, message) {
		var valid = true;
		var formId = form.formId;
		var nodeRef = document.getElementById(formId).action;
		//console.log(document.getElementById(formId));
		//console.log(field.value);
		
		var querySelect =  document.querySelector('[id$="_prop_bhqms_product_company"]');
		if(querySelect != null && querySelect!="" && querySelect!="null" && querySelect!="undefined" && querySelect!=undefined){
			var bhProductCompanyId = querySelect.id;
			//console.log(" bhProductCompanyId :: "+bhProductCompanyId);
			//alfresco-bhCustomUpload-instance-metadata-form_prop_bhqms_content_category
			var bhProductCompanyValue = "";
			if(document.getElementById(bhProductCompanyId) !=null && document.getElementById(bhProductCompanyId)!=""
				&& document.getElementById(bhProductCompanyId)!="undefined" && document.getElementById(bhProductCompanyId)!=undefined)
				bhProductCompanyValue = document.getElementById(bhProductCompanyId).value;
			
			if(field.value=="" || field.value==null || field.value=="null"){
				if(!(bhProductCompanyValue=="BH-Global"))	
					valid=false;
			}
		}
		//console.log("nodeRef :: "+nodeRef);
		return valid;
	}
	
	// To validate Sub Product Line field based on PC (is only mandatory for TPS and validating the same)
	Bakerhughes.forms.validation.content.fields.subProductLine = function validateSPL(field, args, event, form, silent, message) {
		var valid = true;
		var formId = form.formId;
		var nodeRef = document.getElementById(formId).action;
		//console.log(document.getElementById(formId));
		//console.log(field.value);
		
		var querySelect =  document.querySelector('[id$="_prop_bhqms_product_company"]');
		if(querySelect != null && querySelect!="" && querySelect!="null" && querySelect!="undefined" && querySelect!=undefined){
			var bhProductCompanyId = querySelect.id;
			//console.log(" bhProductCompanyId :: "+bhProductCompanyId);
			//alfresco-bhCustomUpload-instance-metadata-form_prop_bhqms_content_category
			var bhProductCompanyValue = "";
			if(document.getElementById(bhProductCompanyId) !=null && document.getElementById(bhProductCompanyId)!=""
				&& document.getElementById(bhProductCompanyId)!="undefined" && document.getElementById(bhProductCompanyId)!=undefined)
				bhProductCompanyValue = document.getElementById(bhProductCompanyId).value;
			
			if(bhProductCompanyValue=="BH-TPS Turbomachinery & Process Solutions" && (field.value=="" || field.value==null || field.value=="null")){
				valid = false;
			}
		}
		//console.log("nodeRef :: "+nodeRef);
		return valid;
	}
	
	// To validate Site field based on PC (Not necessary for GE-Global hence hiding and making non mandatory for Global)
	Bakerhughes.forms.validation.content.fields.site = function validateSite(field, args, event, form, silent, message) {
		var valid = true;
		var formId = form.formId;
		var nodeRef = document.getElementById(formId).action;
		//console.log(document.getElementById(formId));
		//console.log(field.value);
		
		var querySelect =  document.querySelector('[id$="_prop_bhqms_product_company"]');
		if(querySelect != null && querySelect!="" && querySelect!="null" && querySelect!="undefined" && querySelect!=undefined){
			var bhProductCompanyId = querySelect.id;
			//console.log(" bhProductCompanyId :: "+bhProductCompanyId);
			//alfresco-bhCustomUpload-instance-metadata-form_prop_bhqms_content_category
			var bhProductCompanyValue = "";
			if(document.getElementById(bhProductCompanyId) !=null && document.getElementById(bhProductCompanyId)!=""
				&& document.getElementById(bhProductCompanyId)!="undefined" && document.getElementById(bhProductCompanyId)!=undefined)
				bhProductCompanyValue = document.getElementById(bhProductCompanyId).value;
			
			if(field.value=="" || field.value==null || field.value=="null"){
				if(!(bhProductCompanyValue=="BH-Global"))	
					valid=false;
			}
		}
		//console.log("nodeRef :: "+nodeRef);
		return valid;
	}

	// To validate Sub Function field based on PC (is only mandatory for TPS and validating the same)
	Bakerhughes.forms.validation.content.fields.subFunction = function validateSubFunction(field, args, event, form, silent, message) {
		var valid = true;
		var formId = form.formId;
		var nodeRef = document.getElementById(formId).action;
		//console.log(document.getElementById(formId));
		//console.log(field.value);
		
		var querySelect =  document.querySelector('[id$="_prop_bhqms_product_company"]');
		if(querySelect != null && querySelect!="" && querySelect!="null" && querySelect!="undefined" && querySelect!=undefined){
			var bhProductCompanyId = querySelect.id;
			//console.log(" bhProductCompanyId :: "+bhProductCompanyId);
			//alfresco-bhCustomUpload-instance-metadata-form_prop_bhqms_content_category
			var bhProductCompanyValue = "";
			if(document.getElementById(bhProductCompanyId) !=null && document.getElementById(bhProductCompanyId)!=""
				&& document.getElementById(bhProductCompanyId)!="undefined" && document.getElementById(bhProductCompanyId)!=undefined)
				bhProductCompanyValue = document.getElementById(bhProductCompanyId).value;
			
			if(bhProductCompanyValue=="BH-TPS Turbomachinery & Process Solutions" && (field.value=="" || field.value==null || field.value=="null")){
				valid = false;
			}
		}
		//console.log("nodeRef :: "+nodeRef);
		return valid;
	}
	
	
	// To validate Expiry Date field based on PC (is only mandatory for DS and validating the same)
	Bakerhughes.forms.validation.content.fields.expiryDate = function validateSubFunction(field, args, event, form, silent, message) {
		var valid = true;
		var formId = form.formId;
		var nodeRef = document.getElementById(formId).action;
		//console.log(document.getElementById(formId));
		//console.log(field.value);
		
		var querySelect =  document.querySelector('[id$="_prop_bhqms_product_company"]');
		if(querySelect != null && querySelect!="" && querySelect!="null" && querySelect!="undefined" && querySelect!=undefined){
			var bhProductCompanyId = querySelect.id;
			//console.log(" bhProductCompanyId :: "+bhProductCompanyId);
			//alfresco-bhCustomUpload-instance-metadata-form_prop_bhqms_content_category
			var bhProductCompanyValue = "";
			if(document.getElementById(bhProductCompanyId) !=null && document.getElementById(bhProductCompanyId)!=""
				&& document.getElementById(bhProductCompanyId)!="undefined" && document.getElementById(bhProductCompanyId)!=undefined)
				bhProductCompanyValue = document.getElementById(bhProductCompanyId).value;
			
			if(bhProductCompanyValue=="BH-DS Digital Solutions" && (field.value=="" || field.value==null || field.value=="null")){
				valid = false;
			}
		}
		//console.log("nodeRef :: "+nodeRef);
		return valid;
	}
	
	// To validate Language field based on PC (is non mandatory for TPS and validating the same)
	Bakerhughes.forms.validation.content.fields.language = function validateSubFunction(field, args, event, form, silent, message) {
		var valid = true;
		var formId = form.formId;
		var nodeRef = document.getElementById(formId).action;
		//console.log(document.getElementById(formId));
		//console.log(field.value);
		
		var querySelect =  document.querySelector('[id$="_prop_bhqms_product_company"]');
		if(querySelect != null && querySelect!="" && querySelect!="null" && querySelect!="undefined" && querySelect!=undefined){
			var bhProductCompanyId = querySelect.id;
			//console.log(" bhProductCompanyId :: "+bhProductCompanyId);
			//alfresco-bhCustomUpload-instance-metadata-form_prop_bhqms_content_category
			var bhProductCompanyValue = "";
			if(document.getElementById(bhProductCompanyId) !=null && document.getElementById(bhProductCompanyId)!=""
				&& document.getElementById(bhProductCompanyId)!="undefined" && document.getElementById(bhProductCompanyId)!=undefined)
				bhProductCompanyValue = document.getElementById(bhProductCompanyId).value;
			if(bhProductCompanyValue!="BH-TPS Turbomachinery & Process Solutions"){
				if(field.value=="" || field.value==null || field.value=="null"){
					valid = false;
				}
			}
		}
		//console.log("nodeRef :: "+nodeRef);
		return valid;
	}
	
})();