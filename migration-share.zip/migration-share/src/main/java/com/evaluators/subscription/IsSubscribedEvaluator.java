package com.evaluators.subscription;

import org.alfresco.web.evaluator.BaseEvaluator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.simple.JSONObject;
import org.springframework.extensions.surf.RequestContext;
import org.springframework.extensions.surf.exception.ConnectorServiceException;
import org.springframework.extensions.surf.support.ThreadLocalRequestContext;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.connector.Connector;
import org.springframework.extensions.webscripts.connector.ConnectorService;
import org.springframework.extensions.webscripts.connector.Response;

public class IsSubscribedEvaluator extends BaseEvaluator {
	
	private static final Log logger = LogFactory.getLog(IsSubscribedEvaluator.class);

	@Override
	public boolean evaluate(JSONObject jsonObject) {
		boolean subscribed = false;
		JSONObject node = (JSONObject) jsonObject.get("node");
		String nodeRef = (String) node.get("nodeRef");
		logger.debug("nodeRef is...."+nodeRef);
		RequestContext ctx = ThreadLocalRequestContext.getRequestContext();
		ConnectorService connectorService = ctx.getServiceRegistry().getConnectorService();
		logger.debug("user is..."+ctx.getUserId());
		try {
			Connector connector = connectorService.getConnector("alfresco", ctx.getUserId(), org.springframework.extensions.surf.ServletUtil.getSession());
			Response response = connector.call("/com/bh/isSubscribed?userName="+ctx.getUserId()+"&nodeRef="+nodeRef);
			if (response.getStatus().getCode() == Status.STATUS_OK) {
				org.json.JSONObject json = new org.json.JSONObject(response.getResponse());
				String subscribedValue = json.optString("subscribed");
				if(subscribedValue!=null && subscribedValue.equalsIgnoreCase("true"))
				{
					subscribed=true;
				}
			} 
		} catch (ConnectorServiceException  e) {
			throw new WebScriptException(Status.STATUS_INTERNAL_SERVER_ERROR, "Failed to execute request.");
		}
		logger.debug("subscribed ....."+subscribed);

		return subscribed;
	}

}
