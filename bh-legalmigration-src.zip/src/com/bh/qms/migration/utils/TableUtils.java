package com.bh.qms.migration.utils;

import java.io.File;
import java.io.FileInputStream;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.methods.multipart.ByteArrayPartSource;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.StringPart;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;


import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;


public class TableUtils {

	public static final String authorization = "Basic YmhtaWdyYXRpb246YmhtaWdyYXRpb24=";
	
	public static final String urlHost = "https://bhuat.alfrescocloud.com/";

	public static final String createNodeURL = "alfresco/api/-default-/public/alfresco/versions/1/nodes/";

	public static final boolean isProxyNeeded = true;
	
	public static final String proxyHostName = "PITC-Zscaler-Americas-Alpharetta3PR.proxy.corporate.ge.com";
	
	
	 public void documtmToMap(IDfSession session) {
	    	
	    	
	    	IDfCollection rows =null;
	    	
//	    	int i=0;
	    	
	    	boolean isMultipart =true;
	    	
	//    	Map<Integer,String> data =new HashMap<Integer,String>();
	    	
	    	IDfQuery getQuery =new DfQuery();
	    	
	    	getQuery.setDQL("SELECT version_object_id, parent_object_id ,alfresco_folder_node_id, alfresco_document_node_id, version_in_documentum, version_in_alfrasco, update_properties_detailes FROM MigrationOutputTable");
	    	
	    	try {
	    		
			rows =getQuery.execute(session, 0);
			
			File file = new File("D:\\gegdc\\PJ669694\\Documentum Alfrasco Migration\\TestFile.txt");
			
			FileInputStream fileInputStream = new FileInputStream(file);
			
			while(rows.next()) {
				
				
				// to Json object 
//				JSONObject json = new JSONObject();
//				
//				json.put("versionObjectId", rows.getString("version_object_id"));
//				json.put("parentObjectId", rows.getString("parent_object_id"));
//				json.put("alfrascoFolderNodeId",  rows.getString("alfresco_folder_node_id"));
//				json.put("alfrascoDocuNodeId", rows.getString("alfresco_document_node_id"));
//				json.put("versionInDocumentum", rows.getString("version_in_documentum"));
//				json.put("versionInAlfrasco", rows.getString("version_in_alfrasco"));
//				json.put("updatePropertiesDetailes", rows.getString("update_properties_detailes"));
				
				
				HashMap<String,String> params = new HashMap<String,String>();
				params.put("versionObjectId", rows.getString("version_object_id"));
				params.put("parentObjectId", rows.getString("parent_object_id"));
				params.put("alfrascoFolderNodeId",  rows.getString("alfresco_folder_node_id"));
				params.put("alfrascoDocuNodeId", rows.getString("alfresco_document_node_id"));
				params.put("versionInDocumentum", rows.getString("version_in_documentum"));
				params.put("versionInAlfrasco", rows.getString("version_in_alfrasco"));
				params.put("updatePropertiesDetailes", rows.getString("update_properties_detailes"));
			
				JSONObject json = new JSONObject(params);
				
				String test =json.toString();
				
		
			byte[] bytes=IOUtils.toByteArray(fileInputStream);
				
			Part[] part = {
					 new FilePart("filedata",  new ByteArrayPartSource("TestFile", bytes), "text/plain", null),
					 new StringPart("version_object_id",rows.getString("version_object_id")),
					 new StringPart("parent_object_id",rows.getString("parent_object_id")),
					 new StringPart("alfresco_folder_node_id",rows.getString("alfresco_folder_node_id")),
					 new StringPart("alfresco_document_node_id",rows.getString("alfresco_document_node_id")),
					 new StringPart("version_in_documentum",rows.getString("version_in_documentum")),
					 new StringPart("version_in_alfrasco", rows.getString("version_in_alfrasco")),
					 new StringPart("update_properties_detailes",rows.getString("update_properties_detailes"))
					};
			
//	    	data.put(i, test);
	    	
	    	tableToAlfrasco(test, part, isMultipart);
	    	
	    		}
			} catch (Exception e) {
			
				e.printStackTrace();
			}
	    	
	    	
	    }
	 
	 public void excelToMap() {
		 
		 String inputExcelPath="D:\\gegdc\\PJ669694\\Documentum Alfrasco Migration\\testExcel.xlsx";
		 
		 Map<String,String> rows =new HashMap<String, String>();
		 
		 boolean isMultipart=true;
		 
		 XSSFWorkbook workBook = null;
		 
		 Row row;
		 
		 try {
			 
			FileInputStream fileInputStream = new FileInputStream( new File("D:\\gegdc\\PJ669694\\Documentum Alfrasco Migration\\TestFile.txt"));	 
		 
			workBook = new XSSFWorkbook(new FileInputStream(new File(inputExcelPath)));
			
			Sheet sheet = workBook.getSheetAt(0);
			
			Row firstRow =sheet.getRow(0);
			
			HashMap<String, String> params =new HashMap<String, String>();
			
			if (sheet.getPhysicalNumberOfRows()!=0) {
			 
			 for(int rowIndex=1; rowIndex < sheet.getPhysicalNumberOfRows(); rowIndex++ ) {
				 				 
				row = sheet.getRow(rowIndex);
				
				params.clear();
				 
				for(int cellIndex = 0; cellIndex < firstRow.getPhysicalNumberOfCells(); cellIndex++) {
						
					params.put(getStringCellValueForGivenIndex(firstRow,cellIndex), getStringCellValueForGivenIndex(row,cellIndex));
						
				}
				 
//					JSONObject json = new JSONObject();
//					
//					json.put("versionObjectId", rows.get("version_object_id"));
//					json.put("parentObjectId", rows.get("parent_object_id"));
//					json.put("alfrascoFolderNodeId",  rows.get("alfresco_folder_node_id"));
//					json.put("alfrascoDocuNodeId", rows.get("alfresco_document_node_id"));
//					json.put("versionInDocumentum", rows.get("version_in_documentum"));
//					json.put("versionInAlfrasco", rows.get("version_in_alfrasco"));
//					json.put("updatePropertiesDetailes", rows.get("update_properties_detailes"));
				 
				
//				 params.put("versionObjectId", rows.get("version_object_id"));
//				 params.put("parentObjectId", rows.get("parent_object_id"));
//				 params.put("alfrascoFolderNodeId",  rows.get("alfresco_folder_node_id"));
//				 params.put("alfrascoDocuNodeId", rows.get("alfresco_document_node_id"));
//				 params.put("versionInDocumentum", rows.get("version_in_documentum"));
//				 params.put("versionInAlfrasco", rows.get("version_in_alfrasco"));
//				 params.put("updatePropertiesDetailes", rows.get("update_properties_detailes"));
				 
				 JSONObject json = new JSONObject(params);
				
				 String test =json.toString();
					
				byte[] bytes=IOUtils.toByteArray(fileInputStream);
					
				Part[] part = {
						 new FilePart("filedata",  new ByteArrayPartSource("TestFile", bytes), "text/plain", null),
						 new StringPart("version_object_id",rows.get("version_object_id")),
						 new StringPart("parent_object_id",rows.get("parent_object_id")),
						 new StringPart("alfresco_folder_node_id",rows.get("alfresco_folder_node_id")),
						 new StringPart("alfresco_document_node_id",rows.get("alfresco_document_node_id")),
						 new StringPart("version_in_documentum",rows.get("version_in_documentum")),
						 new StringPart("version_in_alfrasco", rows.get("version_in_alfrasco")),
						 new StringPart("update_properties_detailes",rows.get("update_properties_detailes"))
						};
						    	
		    	tableToAlfrasco(test, part, isMultipart);

			 }
		 }
		 else {
			 System.out.println("excel file is empty");
		 }
		 }
		 catch(Exception e) {
			 e.printStackTrace();
		 }
		 
	 }
	 
	 public void tableToAlfrasco(String test, Part[] part, boolean isMultipart){
			
			// ObjectMapper mapper =new ObjectMapper();
			
			// JSONObject jsobj =  mapper.writeValueAsString(obj);
			
			String url = urlHost + createNodeURL  +"1234567"+"/children";
			
			HttpClient httpClient = new HttpClient();
			
	        HostConfiguration hc = new HostConfiguration();
	        
	        if(isProxyNeeded) {
	        	
	        	hc.setProxy(proxyHostName, 80);
	        	
	        } 
	        
	        httpClient.setHostConfiguration(hc);
			
			PostMethod postMethod = new PostMethod(url);
			
			postMethod.setRequestHeader("Authorization", authorization);
					
			try {
				
			//	String jsonString =jsobj.toString();
				
				if(isMultipart) {
					
					postMethod.setRequestEntity(new MultipartRequestEntity(part, postMethod.getParams()));
				}
				else {
					
					postMethod.setRequestEntity(new StringRequestEntity(test));
				}
				
				
				
				httpClient.executeMethod(postMethod);
				
				if(postMethod.getStatusCode()==HttpStatus.SC_OK) {
					
					System.out.println("table updated successfully.");
				}
				else {
					System.out.println("Error occured.");

				}
							
			}
			catch(Exception e) {
				
				e.printStackTrace();
			}
		}

	 
	
		
	public String getStringCellValueForGivenIndex(Row row, int cellIndex) {
			
			String cellValue = null;
			
			Cell cell = row.getCell(cellIndex);
			
			if(cell != null) {
				
				if(cell.getCellType() == Cell.CELL_TYPE_STRING) {
					
					cellValue = cell.getStringCellValue();
					
					if(cellValue != null) {
						
						cellValue = cellValue.trim();
						
					}
					
				}else {
					
					cell.setCellType(Cell.CELL_TYPE_STRING);
					
					cellValue = cell.getStringCellValue();
					
	                if(cellValue != null) {
						
						cellValue = cellValue.trim();
						
					}
					
				}
				
			}
			
			return cellValue;
			
		}
		
	public int getNoOfRowsInExcel(String inputExcelPath) {
			
			int rowsCount=0;
			
			XSSFWorkbook workBook = null;
			
			try {
				
				workBook = new XSSFWorkbook(new FileInputStream(new File(inputExcelPath)));
				
				Sheet sheet = workBook.getSheetAt(0);
				
				rowsCount=sheet.getPhysicalNumberOfRows();
				}
			catch(Exception e) {
				
				e.printStackTrace();
			}
		
	 return rowsCount;
	}
	
//	 public Map<String, String> readExcelSheetAndReturnMap(String inputExcelPath, int rowIndex) {
//	
//	Map<String, String> mapValues = new HashMap<String, String>();
//	
//	XSSFWorkbook workBook = null;
//	
//	try {
//		
//		workBook = new XSSFWorkbook(new FileInputStream(new File(inputExcelPath)));
//		
//		Sheet sheet = workBook.getSheetAt(0);
//		
//		Row firstRow =sheet.getRow(0);
//		
//		Row row = sheet.getRow(rowIndex);
//		
//		for(int cellIndex = 0; cellIndex < firstRow.getPhysicalNumberOfCells(); cellIndex++) {
//			
//			mapValues.put(getStringCellValueForGivenIndex(firstRow,cellIndex), getStringCellValueForGivenIndex(row,cellIndex));
//			
//		}
//		
//	} catch (IOException e) {
//		
//		e.printStackTrace();
//		
//	}finally {
//		
//		if(workBook != null) {
//			
//			try {
//				
//				workBook.close();
//				
//			} catch (IOException e) {
//				
//				e.printStackTrace();
//				
//			}
//			
//		}
//		
//	}
//	
//	return mapValues;
//	
//}
//
}
