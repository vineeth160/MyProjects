package com.bh.qms.migration.utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.URIException;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.methods.multipart.ByteArrayPartSource;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.StringPart;
import org.apache.commons.httpclient.util.URIUtil;
import org.apache.commons.io.IOUtils;
import org.apache.poi.sl.usermodel.ObjectMetaData;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;

// import com.fasterxml.jackson.databind.ObjectMapper;

public class AlfrescoRestUtils {
	
	//public static final String urlHost = "https://bh.alfrescocloud.com/";
	
	public static final String urlHost = "https://bhqmsdev.alfrescocloud.com/";
	
	//public static final String urlHost = "https://bhuat.alfrescocloud.com/";
	
	//public static final String urlHost = "http://localhost:8080/";
	
	public static final String getNodeURL = "alfresco/api/-default-/public/alfresco/versions/1/nodes/-root-";
	
	public static final String createNodeURL = "alfresco/api/-default-/public/alfresco/versions/1/nodes/";
	
	public static final String siteName = "bh-legal-documents";
		
	//public static final String siteName = "my-site";
	
	public static final String documentLibraryContainerPath = "Sites/"+siteName+"/documentLibrary";
	
	//public static final String documentLibraryContainerPath = "Sites/"+siteName+"/documentLibrary/QMS Documents Physical Structure/BH Migration Documents";
	
	//public static final String documentLibraryContainerPath = "Sites/"+siteName+"/documentLibrary/Migration - QMS Documents Physical Structure";
	
	public static final String[] multivaluedAttributes = {"bh:bh_product_line","bh:bh_sub_product_line","bh:bh_site","bh:bh_function","bh:bh_process","bh:bh_sub_process","bh:bh_iso_element"};
	
	public static final String authorization = "Basic YmhkZXYyOmJoZGV2Mg==";
	
	//public static final String authorization = "Basic YWRtaW46YWRtaW4=";
	
	//public static final String authorization = "Basic YmhtaWdyYXRpb246YmhtaWdyYXRpb24=";
	
	public static final boolean isProxyNeeded = true;
	
	public static final String proxyHostName = "PITC-Zscaler-Americas-Alpharetta3PR.proxy.corporate.ge.com";
	
	//public static final String proxyHostName = "10.114.22.12";	
	
	public String generateFolderPath(String folderPath) {
		
		String parentId = getDocumentLibraryId();
		
		//System.out.println("Parent Id : : : : "+parentId);
		
		String relativePath = documentLibraryContainerPath;
		
		String[] folderPathArray = folderPath.split("/");
		
		for(String strFolderPath : folderPathArray) {
			
			if(strFolderPath != null) {

				//System.out.println("Folder Name : : : "+strFolderPath);
				
				relativePath = relativePath + "/" +strFolderPath;
				
				if(parentId != null) {
					
					parentId = createFolderPathIfNotExist(relativePath, parentId, strFolderPath);
					
				}
				
			}
			
		}
		
		return parentId;
		
	}
	
	public String getUniqueName(String folderId, String name) {		

		String fileNameAfterRemovingExtension = null;
		
		String fileExtension = null;
						
		int dotIndex = name.lastIndexOf(".");
		
		if(dotIndex > 0){
			
			fileNameAfterRemovingExtension = name.substring(0, dotIndex);
			
			fileExtension = name.substring(dotIndex);
						
		}
		
		if(getCount(folderId, name) == 0){
			
			return name;
			
		}else{
			
			for(int index = 1; index < 30 ; index++){
				
				name = String.format("%s%d%s", fileNameAfterRemovingExtension.concat("_"), index, fileExtension);
				
				if(getCount(folderId, name) == 0){
					
					return name;
					
				}
				
			}
			
		}
				
		return name;
		
	}
	
	
	@SuppressWarnings("unchecked")
	public String linkDocument(String folderId, String documentId, String name) {
		
		String createdNodeId = null;
				
		String url = urlHost + createNodeURL + folderId +"/children";
		
		HttpClient httpClient = new HttpClient();
		
        HostConfiguration hc = new HostConfiguration();
        
        if(isProxyNeeded) {
        	
        	hc.setProxy(proxyHostName, 80);
        	
        }
                
        httpClient.setHostConfiguration(hc);
		
		PostMethod postMethod = new PostMethod(url);
		
		postMethod.setRequestHeader("Authorization", authorization);
		
		JSONObject jsonObject = new JSONObject();
		
		jsonObject.put("nodeType", "app:filelink");
		
		jsonObject.put("name", name+".url");
		
		JSONObject propertiesObject = new JSONObject();
		
		propertiesObject.put("cm:destination", documentId);
		
		propertiesObject.put("cm:title", name+".url");
		
		jsonObject.put("properties", propertiesObject);
		
		RequestEntity requestEntity;
				
		try {
			
			requestEntity = new StringRequestEntity(jsonObject.toString(),"application/json","utf-8");

			postMethod.setRequestEntity(requestEntity);
			
			httpClient.executeMethod(postMethod);
			
            int statusCode = postMethod.getStatusCode();
            			
			if(statusCode == HttpStatus.SC_CREATED) {
				
                 if(postMethod.getResponseBodyAsString() != null) {
					
					JSONObject responseJSONObject = (JSONObject) JSONValue.parse(postMethod.getResponseBodyAsString());
					
					if(responseJSONObject.get("entry") != null) {
						
						if(responseJSONObject.get("entry") instanceof JSONObject) {
							
							JSONObject entityJSONObject = (JSONObject) responseJSONObject.get("entry");
							
							if(entityJSONObject.get("id") != null) {
								
								if(entityJSONObject.get("id") instanceof String) {
									
									createdNodeId = (String) entityJSONObject.get("id");
									
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(postMethod != null) {
				
				postMethod.releaseConnection();
				
			}
			
		}
		
		return createdNodeId;
		
	}
	
	@SuppressWarnings("unchecked")
	public long getCount(String folderId, String name) {

		String apiURL = urlHost + "alfresco/api/-default-/public/search/versions/1/search";
		
		long count = 0;
		
		JSONObject jsonObject = new JSONObject();
		
		JSONObject queryObject = new JSONObject();
		
		queryObject.put("language", "afts");
				
		queryObject.put("query", "=PARENT:'workspace://SpacesStore/"+folderId+"' AND cm:name:'"+name+"'");
				
		jsonObject.put("query", queryObject);
		
		JSONObject pagingObject = new JSONObject();
		
		pagingObject.put("maxItems", "5000");
		
		jsonObject.put("paging", pagingObject);
		
		HttpClient client = new HttpClient();
		
        HostConfiguration hc = new HostConfiguration();
        
        //hc.setProxy("PITC-Zscaler-Americas-Alpharetta3PR.proxy.corporate.ge.com", 80);
        
        client.setHostConfiguration(hc);
		
		PostMethod mPost = new PostMethod(apiURL);
		
		RequestEntity requestEntity;
		
		try {
			
			requestEntity = new StringRequestEntity(queryObject.toString(),"application/json","utf-8");

			mPost.setRequestEntity(requestEntity);

			mPost.setRequestHeader("Authorization", authorization);
			
			client.executeMethod(mPost);
			
			if(mPost.getStatusCode() == HttpStatus.SC_OK) {

				JSONObject responseJSONObject = (JSONObject) JSONValue.parse(mPost.getResponseBodyAsString());

				if(responseJSONObject.containsKey("list")) {
					
					JSONObject listJsonObject = (JSONObject) responseJSONObject.get("list");
					
					if(listJsonObject.containsKey("pagination")) {

						JSONObject paginationJsonObject = (JSONObject) listJsonObject.get("pagination");
						
						count = (long) paginationJsonObject.get("count");
						
					}
					
				}
				
			}
			
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			mPost.releaseConnection();
			
		}
						
		return count;
		
	}
	
	public String getDocumentLibraryId() {	
		
		String id = null;
		
		String relativePath = documentLibraryContainerPath;
		
        try {
			
			relativePath = URIUtil.encodeAll(relativePath);
			
		} catch (URIException e1) {
			
			e1.printStackTrace();
			
		}
        
       

		String url = urlHost + getNodeURL +"?relativePath="+relativePath;
		
		//System.out.println(url);
				
        HttpClient httpClient = new HttpClient();       
        
        HostConfiguration hc = new HostConfiguration();
        
        //hc.setProxy("proxy-src.research.ge.com", 8080);
        
        if(isProxyNeeded) {
        	
        	hc.setProxy(proxyHostName, 80);
        	
        }
        
        //hc.setProxy("10.114.22.12", 80);
        
        //hc.setHost("bhqmsdev.alfrescocloud.com", 443);
        
        httpClient.setHostConfiguration(hc);
		
		GetMethod getMethod = new GetMethod(url);
		
		getMethod.setRequestHeader("Authorization", authorization);
		
		getMethod.setRequestHeader("postman-token", "19b0363e-90ac-de80-aa29-f1abe545c3d7");
		
		try {
			
			httpClient.executeMethod(getMethod);
			
			int statusCode = getMethod.getStatusCode();
			
			if(statusCode == HttpStatus.SC_OK) {
				
				if(getMethod.getResponseBodyAsString() != null) {
					
					JSONObject responseJSONObject = (JSONObject) JSONValue.parse(getMethod.getResponseBodyAsString());
					
					if(responseJSONObject.get("entry") != null) {
						
						if(responseJSONObject.get("entry") instanceof JSONObject) {
							
							JSONObject entityJSONObject = (JSONObject) responseJSONObject.get("entry");
							
							if(entityJSONObject.get("id") != null) {
								
								if(entityJSONObject.get("id") instanceof String) {
									
									id = (String) entityJSONObject.get("id");
									
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(getMethod != null) {
				
				getMethod.releaseConnection();
				
			}
			
		}
		
		return id;
		
	}
	
	
	public String createFolder(String nodeId, String folderName) {
		
		String createdNodeId = null;
		
		String url = urlHost + createNodeURL + nodeId +"/children";
		
		//sSystem.out.println("URL : : : "+url);
		
		HttpClient httpClient = new HttpClient();
		
        HostConfiguration hc = new HostConfiguration();
        
        //hc.setProxy("proxy-src.research.ge.com", 8080);
        
        if(isProxyNeeded) {
        	
        	hc.setProxy(proxyHostName, 80);
        	
        }
        
        //hc.setProxy("10.114.22.12", 80);
        
        //hc.setHost("bhqmsdev.alfrescocloud.com", 443);
        
        httpClient.setHostConfiguration(hc);
		
		PostMethod postMethod = new PostMethod(url);
		
		postMethod.setRequestHeader("Authorization", authorization);
		
		//postMethod.setRequestBody("{\"name\":\""+folderName+"\",\"nodeType\":\"cm:folder\"}");
		
		try {
			
			StringRequestEntity requestEntity = new StringRequestEntity("{\"name\":\""+folderName+"\",\"nodeType\":\"cm:folder\"}", "application/json", "UTF-8");
			
			postMethod.setRequestEntity(requestEntity);
			
			httpClient.executeMethod(postMethod);
			
			//System.out.println("Status Code in create Document : : : "+postMethod.getStatusCode());
			
			int statusCode = postMethod.getStatusCode();
			
			if(statusCode == HttpStatus.SC_CREATED) {
				
                 if(postMethod.getResponseBodyAsString() != null) {
					
					JSONObject responseJSONObject = (JSONObject) JSONValue.parse(postMethod.getResponseBodyAsString());
					
					if(responseJSONObject.get("entry") != null) {
						
						if(responseJSONObject.get("entry") instanceof JSONObject) {
							
							JSONObject entityJSONObject = (JSONObject) responseJSONObject.get("entry");
							
							if(entityJSONObject.get("id") != null) {
								
								if(entityJSONObject.get("id") instanceof String) {
									
									createdNodeId = (String) entityJSONObject.get("id");
									
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(postMethod != null) {
				
				postMethod.releaseConnection();
				
			}
			
		}
		
		return createdNodeId;
		
	}
	
	public String createFolderPathIfNotExist(String relativePath, String id, String folderName)  {
		
		String nodeId = null;
		
		try {
			
			relativePath = URIUtil.encodeAll(relativePath);
			
		} catch (URIException e1) {
			
			e1.printStackTrace();
			
		}
		
		String url = urlHost + getNodeURL +"?relativePath="+relativePath;
		
		//url = URLEncoder.encode(url);
		
		HttpClient httpClient = new HttpClient();
		
        HostConfiguration hc = new HostConfiguration();
        
        //hc.setProxy("proxy-src.research.ge.com", 8080);
        
        if(isProxyNeeded) {
        	
        	hc.setProxy(proxyHostName, 80);
        	
        }
                
        //hc.setProxy("10.114.22.12", 80);
        
        //hc.setHost("bhqmsdev.alfrescocloud.com", 443);
        
        httpClient.setHostConfiguration(hc);
		
		GetMethod getMethod = new GetMethod(url);
		
		getMethod.setRequestHeader("Authorization", authorization);
		
		try {
			
			httpClient.executeMethod(getMethod);
			
			int statusCode = getMethod.getStatusCode();
			
			//System.out.println("Satuggg code : : : "+statusCode);
			
			if(statusCode == HttpStatus.SC_OK) {
				
				if(getMethod.getResponseBodyAsString() != null) {
					
					JSONObject responseJSONObject = (JSONObject) JSONValue.parse(getMethod.getResponseBodyAsString());
					
					if(responseJSONObject.get("entry") != null) {
						
						if(responseJSONObject.get("entry") instanceof JSONObject) {
							
							JSONObject entityJSONObject = (JSONObject) responseJSONObject.get("entry");
							
							if(entityJSONObject.get("id") != null) {
								
								if(entityJSONObject.get("id") instanceof String) {
									
									nodeId = (String) entityJSONObject.get("id");
									
								}
								
							}
							
						}
						
					}
					
				}
				
			}else if(statusCode == HttpStatus.SC_NOT_FOUND){
				
				nodeId = createFolder(id, folderName);
				
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(getMethod != null) {
				
				getMethod.releaseConnection();
				
			}
			
		}
		
		return nodeId;
		
	}
	
	
    public String createFolderPathIfNotExist(String id, String folderName)  {
		
		String nodeId = null;
		
		String url = urlHost + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" +id+"?relativePath="+folderName;
		
		//url = URLEncoder.encode(url);
		
		HttpClient httpClient = new HttpClient();
		
        HostConfiguration hc = new HostConfiguration();
        
        //hc.setProxy("proxy-src.research.ge.com", 8080);
        
        if(isProxyNeeded) {
        	
        	hc.setProxy(proxyHostName, 80);
        	
        }
                
        //hc.setProxy("10.114.22.12", 80);
        
        //hc.setHost("bhqmsdev.alfrescocloud.com", 443);
        
        httpClient.setHostConfiguration(hc);
		
		GetMethod getMethod = new GetMethod(url);
		
		getMethod.setRequestHeader("Authorization", authorization);
		
		try {
			
			httpClient.executeMethod(getMethod);
			
			int statusCode = getMethod.getStatusCode();
			
			//System.out.println("Satuggg code : : : "+statusCode);
			
			if(statusCode == HttpStatus.SC_OK) {
				
				if(getMethod.getResponseBodyAsString() != null) {
					
					JSONObject responseJSONObject = (JSONObject) JSONValue.parse(getMethod.getResponseBodyAsString());
					
					if(responseJSONObject.get("entry") != null) {
						
						if(responseJSONObject.get("entry") instanceof JSONObject) {
							
							JSONObject entityJSONObject = (JSONObject) responseJSONObject.get("entry");
							
							if(entityJSONObject.get("id") != null) {
								
								if(entityJSONObject.get("id") instanceof String) {
									
									nodeId = (String) entityJSONObject.get("id");
									
								}
								
							}
							
						}
						
					}
					
				}
				
			}else if(statusCode == HttpStatus.SC_NOT_FOUND){
				
				nodeId = createFolder(id, folderName);
				
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(getMethod != null) {
				
				getMethod.releaseConnection();
				
			}
			
		}
		
		return nodeId;
		
	}
    
    public String createAssociation(String sourceId, String associationNodeId, String associationType) {
    	
    	String response = null;
		
    	String url = urlHost + createNodeURL + sourceId +"/targets";
    	
		HttpClient httpClient = new HttpClient();
		
        HostConfiguration hc = new HostConfiguration();

        if(isProxyNeeded) {
        	
        	hc.setProxy(proxyHostName, 80);
        	
        }
        
        httpClient.setHostConfiguration(hc);
		
		PostMethod postMethod = new PostMethod(url);
		
		postMethod.setRequestHeader("Authorization", authorization);
		
		try {
			
			StringRequestEntity requestEntity = new StringRequestEntity("{\"targetId\":\""+associationNodeId+"\", \"assocType\":\""+associationType+"\"}", "application/json", "UTF-8");
			
			postMethod.setRequestEntity(requestEntity);
			
			httpClient.executeMethod(postMethod);
			
	        int statusCode = postMethod.getStatusCode();
	        
	        //System.out.println("Status Code : : : "+statusCode);

			if(statusCode == HttpStatus.SC_CREATED) {
				
				response = postMethod.getResponseBodyAsString();
				
			}
			
		} catch (IOException e) {

			e.printStackTrace();
			
		}
		
		return response;
		
	}
    
    public String copyDocument(String documentNodeId, String folderId) {
    	
    	String copiedNodeId = null;
    	
    	String url = urlHost + createNodeURL + documentNodeId +"/copy";
    	
		HttpClient httpClient = new HttpClient();
		
        HostConfiguration hc = new HostConfiguration();

        if(isProxyNeeded) {
        	
        	hc.setProxy(proxyHostName, 80);
        	
        }
        
        httpClient.setHostConfiguration(hc);
		
		PostMethod postMethod = new PostMethod(url);
		
		postMethod.setRequestHeader("Authorization", authorization);
		
		try {
			
			StringRequestEntity requestEntity = new StringRequestEntity("{\"targetParentId\":\""+folderId+"\"}", "application/json", "UTF-8");
			
			postMethod.setRequestEntity(requestEntity);
			
			httpClient.executeMethod(postMethod);
			
            int statusCode = postMethod.getStatusCode();
            
            System.out.println("Status Code : : : "+statusCode);
			
			if(statusCode == HttpStatus.SC_CREATED) {
				
                 if(postMethod.getResponseBodyAsString() != null) {
					
					JSONObject responseJSONObject = (JSONObject) JSONValue.parse(postMethod.getResponseBodyAsString());
					
					if(responseJSONObject.get("entry") != null) {
						
						if(responseJSONObject.get("entry") instanceof JSONObject) {
							
							JSONObject entityJSONObject = (JSONObject) responseJSONObject.get("entry");
							
							if(entityJSONObject.get("id") != null) {
								
								if(entityJSONObject.get("id") instanceof String) {
									
									copiedNodeId = (String) entityJSONObject.get("id");
									
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(postMethod != null) {
				
				postMethod.releaseConnection();
				
			}
			
		}
		
    	
    	return copiedNodeId;
    	
    }
	
	public String createDocument(byte[] bytes, String contentType, Map<String, String> metadataMap, String nodeId) {
		
		String createdNodeId = null;
		
		//String nodeId = getDocumentLibraryId();
		
		String url = urlHost + createNodeURL + nodeId +"/children";
		
		HttpClient httpClient = new HttpClient();
		
        HostConfiguration hc = new HostConfiguration();
        
        //hc.setProxy("proxy-src.research.ge.com", 8080);

        if(isProxyNeeded) {
        	
        	hc.setProxy(proxyHostName, 80);
        	
        }
                
        //hc.setProxy("10.114.22.12", 80);
        
        //hc.setHost("bhqmsdev.alfrescocloud.com", 443);
        
        httpClient.setHostConfiguration(hc);
		
		PostMethod postMethod = new PostMethod(url);
		
		postMethod.setRequestHeader("Authorization", authorization);
		
		//System.out.println("Metadata Map Size : : : "+metadataMap.size());
		
		List<Part> partsArrayList = new ArrayList<Part>();
		
		List<String> multiValuedAttributeList = Arrays.asList(multivaluedAttributes);
		
		for(Map.Entry<String, String> mapEntry : metadataMap.entrySet()) {
			
			if(multiValuedAttributeList.contains(mapEntry.getKey())){
				
				if(mapEntry.getValue().contains(",")) {
					
					String[] attributeValues = mapEntry.getValue().split(",");
					
					for(String attributeValue : attributeValues) {
						
						partsArrayList.add(new StringPart(mapEntry.getKey(), attributeValue));
						
					}
					
					//partsArrayList.add(new StringPart(mapEntry.getKey(), mapEntry.getValue()));
					
				}else {
					
					partsArrayList.add(new StringPart(mapEntry.getKey(), mapEntry.getValue()));
					
				}
				
			}else {
				
				if(mapEntry.getKey() != null && mapEntry.getValue() != null) {
					
					if(mapEntry.getKey().equalsIgnoreCase("cm:name")) {
						
						partsArrayList.add(new StringPart("name", mapEntry.getValue(), "UTF-8"));
						
					}else {
						
						partsArrayList.add(new StringPart(mapEntry.getKey(), mapEntry.getValue()));
						
					}
					
				}
				
			}
			
		}
		
		//partsArrayList.add(new StringPart("name", "Test_From_Client.txt"));
		
		//partsArrayList.add(new StringPart("nodeType", "bh:iso_qty_manual"));
		
		partsArrayList.add(new FilePart("fileData", new ByteArrayPartSource("Test", bytes), contentType, null));
		
		//System.out.println("Parts Size : : : : : ######## "+partsArrayList.size());
		
		Part[] parts = partsArrayList.toArray(new Part[0]);
		
		//System.out.println("Parts Length : : : : "+parts.length);
		
		postMethod.setRequestEntity(new MultipartRequestEntity(parts, postMethod.getParams()));
		
		try {
			
			httpClient.executeMethod(postMethod);
			
			//System.out.println("Status Code : : : "+postMethod.getStatusCode());
			
			//System.out.println("Response Body : : : "+postMethod.getResponseBodyAsString());
			
            int statusCode = postMethod.getStatusCode();
            
            //System.out.println("Create Node : : : : @@@@@@@@@@@@@@ "+postMethod.getResponseBodyAsString());
			
			if(statusCode == HttpStatus.SC_CREATED) {
				
                 if(postMethod.getResponseBodyAsString() != null) {
					
					JSONObject responseJSONObject = (JSONObject) JSONValue.parse(postMethod.getResponseBodyAsString());
					
					if(responseJSONObject.get("entry") != null) {
						
						if(responseJSONObject.get("entry") instanceof JSONObject) {
							
							JSONObject entityJSONObject = (JSONObject) responseJSONObject.get("entry");
							
							if(entityJSONObject.get("id") != null) {
								
								if(entityJSONObject.get("id") instanceof String) {
									
									createdNodeId = (String) entityJSONObject.get("id");
									
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(postMethod != null) {
				
				postMethod.releaseConnection();
				
			}
			
		}
		
		return createdNodeId;
		
	}
	
	public void createDocumentExtractedFromDocumentum(IDfSession session, TreeMap<String, String> versionNameAndIdMap, Map<String, String> metadataMap) {
		
		int index = 0;
		
		for(Map.Entry<String, String> mapEntry : versionNameAndIdMap.entrySet()) {
			
			if(index == 0) {
				
				try {
					
					IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(mapEntry.getValue()));
					
					byte[] bytes = IOUtils.toByteArray(sysObject.getContent());
					
					//createDocument(bytes, sysObject.getContentType(), metadataMap);
					
				} catch (DfException | IOException e) {
					
					e.printStackTrace();
					
				}
				
			}
			
		}
		
	}
	
	
	public String updateDocumentContent(String nodeId, InputStream inputStream, boolean isMajorVersion) {
		
		String versionLabel = null;
		
		String url = urlHost + createNodeURL + nodeId +"/content?majorVersion="+isMajorVersion;
		
		HttpClient httpClient = new HttpClient();
		
        HostConfiguration hc = new HostConfiguration();
        
        //hc.setProxy("proxy-src.research.ge.com", 8080);

        if(isProxyNeeded) {
        	
        	hc.setProxy(proxyHostName, 80);
        	
        }
                
        //hc.setProxy("10.114.22.12", 80);
        
        //hc.setHost("bhqmsdev.alfrescocloud.com", 443);
        
        httpClient.setHostConfiguration(hc);
		
		PutMethod putMethod = new PutMethod(url);
		
		putMethod.setRequestHeader("Authorization", authorization);
		
		putMethod.setRequestHeader("Content-Type", "application/octet-stream");
		
		InputStreamRequestEntity requestEntity = new InputStreamRequestEntity(inputStream);
		
		putMethod.setRequestEntity(requestEntity);
		
		try {
			
			httpClient.executeMethod(putMethod);
			
			//System.out.println("Status Code : : : "+putMethod.getStatusCode());
			
			int statusCode = putMethod.getStatusCode();
			
			if(statusCode == HttpStatus.SC_OK) {
				
				if(putMethod.getResponseBodyAsString() != null) {
					
                    JSONObject responseJSONObject = (JSONObject) JSONValue.parse(putMethod.getResponseBodyAsString());
					
					if(responseJSONObject.get("entry") != null) {
						
						if(responseJSONObject.get("entry") instanceof JSONObject) {
							
							JSONObject entityJSONObject = (JSONObject) responseJSONObject.get("entry");
							
							if(entityJSONObject.get("properties") != null) {
								
								if(entityJSONObject.get("properties") instanceof JSONObject) {
									
									JSONObject propertiesJSONObject = (JSONObject) entityJSONObject.get("properties");
									
									if(propertiesJSONObject.get("cm:versionLabel") != null) {
										
										if(propertiesJSONObject.get("cm:versionLabel") instanceof String) {
											
											versionLabel = (String) propertiesJSONObject.get("cm:versionLabel");
											
										}
										
									}
									
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
			System.out.println(putMethod.getResponseBodyAsString());
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(putMethod != null) {
				
				putMethod.releaseConnection();
				
			}
			
		}
		
		return versionLabel;
		
	}
	
	

	@SuppressWarnings("unchecked")
	public String updateNode(String nodeId, Map<String, String> xmlMetadata) {
		
		String strResponse = null;
		
		String url = urlHost + createNodeURL + nodeId;
		
		HttpClient httpClient = new HttpClient();
		
        HostConfiguration hc = new HostConfiguration();
        
        //hc.setProxy("proxy-src.research.ge.com", 8080);

        if(isProxyNeeded) {
        	
        	hc.setProxy(proxyHostName, 80);
        	
        }
                
        //hc.setProxy("10.114.22.12", 80);
        
        //hc.setHost("bhqmsdev.alfrescocloud.com", 443);
        
        httpClient.setHostConfiguration(hc);
		
		PutMethod putMethod = new PutMethod(url);
		
		putMethod.setRequestHeader("Authorization", authorization);
		
		putMethod.setRequestHeader("Content-Type", "application/json");
		
		List<String> multiValuedAttributeList = Arrays.asList(multivaluedAttributes);
		
		JSONObject propertiesJsonObject = new JSONObject();
		
		xmlMetadata.remove("nodeType");
		
		for(Map.Entry<String, String> mapEntry : xmlMetadata.entrySet()) {
			
			if(multiValuedAttributeList.contains(mapEntry.getKey())){
				
				if(mapEntry.getValue() != null) {
					
					JSONArray jsonArray = new JSONArray();
					
					String[] attributeValues = mapEntry.getValue().split(",");
					
					for(String attributeValue : attributeValues) {
						
						jsonArray.add(attributeValue);
						
					}
					
					propertiesJsonObject.put(mapEntry.getKey(), jsonArray);
					
				}
				
			}else {
				
				propertiesJsonObject.put(mapEntry.getKey(), mapEntry.getValue());
				
			}
			
		}
		
		//propertiesJsonObject.put("bh:bh_product_company", "PC From update Client");
		
		JSONObject jsonObject = new JSONObject();
		
		jsonObject.put("properties", propertiesJsonObject);
		
		try {
			
			//System.out.println("Request JSON String ################ "+jsonObject.toString());
			
			StringRequestEntity requestEntity = new StringRequestEntity(jsonObject.toString(), "application/json", "UTF-8");
			
			putMethod.setRequestEntity(requestEntity);
			
			httpClient.executeMethod(putMethod);
			
			//System.out.println("Status Code in update Node : : : "+putMethod.getStatusCode());
			
			//System.out.println("response : : : "+putMethod.getResponseBodyAsString());
			
			strResponse = putMethod.getResponseBodyAsString();
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(putMethod != null) {
				
				putMethod.releaseConnection();
				
			}
			
		}
		
		return strResponse;
		
	}
	
	public long getNumberOfFiles(String nodeId) {
		
		long numberOfItems = 0;
		
		String url = urlHost + createNodeURL + nodeId +"/children?maxItems=1";
		
		HttpClient httpClient = new HttpClient();
		
        HostConfiguration hc = new HostConfiguration();
        
        //hc.setProxy("proxy-src.research.ge.com", 8080);

        if(isProxyNeeded) {
        	
        	hc.setProxy(proxyHostName, 80);
        	
        }
                
        //hc.setProxy("10.114.22.12", 80);
        
        //hc.setHost("bhqmsdev.alfrescocloud.com", 443);
        
        httpClient.setHostConfiguration(hc);
		
		GetMethod getMethod = new GetMethod(url);
		
		getMethod.setRequestHeader("Authorization", authorization);
		
		try {
			
			httpClient.executeMethod(getMethod);
			
			int statusCode = getMethod.getStatusCode();
			
			if(statusCode == HttpStatus.SC_OK) {
				
               if(getMethod.getResponseBodyAsString() != null) {
					
					JSONObject responseJSONObject = (JSONObject) JSONValue.parse(getMethod.getResponseBodyAsString());
					
					if(responseJSONObject.get("list") != null) {
						
						if(responseJSONObject.get("list") instanceof JSONObject) {
							
							JSONObject listJSONObject = (JSONObject) responseJSONObject.get("list");
							
							if(listJSONObject.get("pagination") != null) {
								
								if(listJSONObject.get("pagination") instanceof JSONObject) {
									
									JSONObject paginationJSONObject = (JSONObject) listJSONObject.get("pagination");
									
									if(paginationJSONObject.get("totalItems") != null) {
										
										numberOfItems = (long) paginationJSONObject.get("totalItems");
										
									}
									
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(getMethod != null) {
				
				getMethod.releaseConnection();
				
			}
			
		}
		
		return numberOfItems;
		
	}
	
	
	
	public String generateFolderPath(String productCompanyName, String versionLabel) {
		
		String folderName = "Folder";
		
		//String fullPath = documentLibraryContainerPath+"/"+productCompanyName+"/"+versionLabel;
		
		String fullPath = productCompanyName+"/"+versionLabel;
		
		String folderNodeId = generateFolderPath(fullPath+"/"+folderName);
		
		long numberOfItems = getNumberOfFiles(folderNodeId);
		
		if(numberOfItems > 1000) {
			
			for (int i = 0; i < Long.MAX_VALUE; i++) {
		    	
				folderName = String.format("%s%d", folderName.concat("_"), i);
				
				folderNodeId = generateFolderPath(fullPath+"/"+folderName);
				
				numberOfItems = getNumberOfFiles(folderNodeId);
				
				if(numberOfItems <= 1000) {
					
					return folderNodeId;
					
				}
		        
		    }
			
		}	
		
		return folderNodeId;
		
	}
	
	public static void main(String []args) throws FileNotFoundException, NoSuchAlgorithmException, KeyManagementException {
		
		TrustManager[] tm = new TrustManager[] {
				new X509TrustManager() {
					
					@Override
					public X509Certificate[] getAcceptedIssuers() {
						// TODO Auto-generated method stub
						return null;
					}
					
					@Override
					public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
						// TODO Auto-generated method stub
						
					}
				}
		};
		
		javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance("SSL");
		
		sc.init(null, tm, new SecureRandom());
		
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		
		AlfrescoRestUtils a = new AlfrescoRestUtils();
		
		//a.generateFolderPath("BH-GE Legacy Global");
		
		System.out.println("Dlibrary : : "+a.getDocumentLibraryId());
		
		//a.updateDocumentContent("d9bfdb5e-658b-4bc3-8f95-92ce9aa5bd76", new FileInputStream(new File("D:\\gegdc\\KR427812\\WebServicesTestFiles\\response123.pdf")));
		
		//a.updateNode("d9bfdb5e-658b-4bc3-8f95-92ce9aa5bd76", null);
		
		//a.getNumberOfFiles("d9bfdb5e-658b-4bc3-8f95-92ce9aa5bd76");
		
	}
	
}
