package com.bh.qms.migration.utils;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.TreeSet;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfAttr;
import com.documentum.fc.common.IDfTime;

public class DFCUtils {
	
	public Path findFileName(String dir, final String baseName,
		    final String extension){
		
		Path ret =Paths.get(dir, String.format("%s.%s", baseName, extension));
	    
	    if (!Files.exists(ret)){
	        return ret;
	    }
	    
	    for (int i = 0; i < Integer.MAX_VALUE; i++) {
	    	
	    	ret = Paths.get(dir, String.format("%s%d.%s", baseName.concat("_"), i, extension));
	    	
	        if (!Files.exists(ret)){
	            return ret;
	        }
	        
	    }
	    
	    return ret;
			    
	}
	
	public void insertRow(IDfSession session, String versionId,String objectId, String folderNodeId, String documentNodeId
			,String versionInDocumentum, String versionInalfresco, String updateResponse) {
		
		String query = "INSERT INTO dm_dbo.BH_ALFRESCO_MIGRATION_LOG (version_object_id,object_id,alfresco_folder_node_id,alfresco_document_node_id,"
				+ "version_in_documentum,version_in_alfresco,update_property_details) VALUES('"+versionId+"','"+objectId+"','"+folderNodeId+"','"+documentNodeId+
				"','"+versionInDocumentum+"','"+versionInDocumentum+"','"+updateResponse+"')";
		
		IDfQuery queryObject = new DfQuery();
		
		queryObject.setDQL(query);
		
		try {
			
			queryObject.execute(session, IDfQuery.DF_EXEC_QUERY);
			
		} catch (DfException e) {
			
			e.printStackTrace();
			
		}
		
	}
	
	public List<String> getObjectIdListForGivenTypeAndInFolder(IDfSession session, String objectType, String folderPath) throws DfException {
		
		List<String> objectIdsList = new ArrayList<String>();
		
		IDfQuery query = new DfQuery();
		
		query.setDQL("select r_object_id from "+objectType+" (all) where folder('"+folderPath+"',descend)");
		
		IDfCollection collection = query.execute(session, 0);
		
		while(collection.next()) {
			
			objectIdsList.add(collection.getString("r_object_id"));
			
		}
		
		return objectIdsList;
		
	}
	
	private String getOsFileName(String fileName) {
		
		fileName = fileName.replace('/', ' ');
		
		fileName = fileName.replace(':', ' ');
		
		fileName = fileName.replace('"', ' ');
		
		fileName = fileName.replace('<', ' ');
		
		fileName = fileName.replace('>', ' ');
		
		fileName = fileName.replace('?', ' ');
		
		fileName = fileName.replace('*', ' ');
		
		fileName = fileName.replace('|', ' ');
		
		fileName = fileName.replace('\\', ' ');
		
		return fileName;
		
	}
	
	public String getFilePath(IDfSession session, IDfSysObject sysObject, String fileDir) throws DfException {
		
		String contentType = sysObject.getString("a_content_type");
		
		//String objectName = getOsFileName(sysObject.getObjectName());
		
		//String objectName = getOsFileName(sysObject.getString("r_object_id"));
		
		String objectName = getOsFileName(sysObject.getString("i_chronicle_id"));
		
		String desPath = fileDir+objectName+"."+session.getFormat(contentType).getDOSExtension();
		
		//File file=new File(desPath);
		 
		/*if(file.exists()){
			
     		Path modifiedpath= findFileName(fileDir, objectName, session.getFormat(contentType).getDOSExtension());
     		
     		desPath=modifiedpath.toString();
     		
		}*/
		
		return desPath;
		
	}
	
	public String downloadDocumentContent(IDfSession session, String objectId, String downloadPath, boolean isRenditionRequired){
		
		String documentDownloadStatus = null;
		
		IDfCollection renditionsColl = null;
		
		String format = null;
		
		String dosExtension = null;
		
		try {			

			IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(objectId));
			
			String contentType = sysObject.getString("a_content_type");
			
			String objectName = getOsFileName(sysObject.getObjectName());
			
			String desPath = downloadPath+objectName+"."+session.getFormat(contentType).getDOSExtension();
			
			File file=new File(desPath);
			 
			if(file.exists()){
				
         		Path modifiedpath= findFileName(downloadPath, objectName, session.getFormat(contentType).getDOSExtension());
         		
         		desPath=modifiedpath.toString();
         		
			}
			 
			sysObject.getFile(desPath);
			
			System.out.println(downloadPath+sysObject.getObjectName()+"."+session.getFormat(contentType).getDOSExtension());
			
			if(isRenditionRequired) {
				
				IDfQuery query = new DfQuery();
				
				query.setDQL("select rendition,full_format from dmr_content where any parent_id='"+objectId+"' and rendition = 2");
				
				renditionsColl = query.execute(session, 0);
				
				while (renditionsColl.next()) 
				{ 
					format = renditionsColl.getString("full_format");
					
					dosExtension = session.getFormat(format).getDOSExtension();
					
					String renDesPath = downloadPath+objectName+" (rendered version)."+dosExtension;
					
					File fileRen=new File(renDesPath);
					
					if(fileRen.exists()){
						
		         		Path modifiedpath1= findFileName(downloadPath,objectName+" (rendered version)", dosExtension);
		         		
		         		renDesPath=modifiedpath1.toString();
		         		
					}
					
					sysObject.getFileEx(renDesPath,format,0,false);
					
				}
				
			}
			
			documentDownloadStatus = "success";
			
			System.out.println("Status :"+documentDownloadStatus);
			
			System.out.println("Document downloaded : "+objectId);

		} catch (Exception e) {
			
			documentDownloadStatus = "Failure"+e.getMessage();
			
			System.out.println("Status :"+documentDownloadStatus);
			
		}
		
		return documentDownloadStatus;
		
	}
	
    public String downloadDocumentContent(IDfSession session, IDfSysObject sysObject, String objectId, String downloadPath, boolean isRenditionRequired){
		
		String documentDownloadStatus = null;
		
		IDfCollection renditionsColl = null;
		
		String format = null;
		
		String dosExtension = null;
		
		try {			

			//IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(objectId));
			
/*			String contentType = sysObject.getString("a_content_type");
			
			String objectName = getOsFileName(sysObject.getObjectName());
			
			String desPath = downloadPath+objectName+"."+session.getFormat(contentType).getDOSExtension();
			
			File file=new File(desPath);
			 
			if(file.exists()){
				
         		Path modifiedpath= findFileName(downloadPath, objectName, session.getFormat(contentType).getDOSExtension());
         		
         		desPath=modifiedpath.toString();
         		
			}*/
			
			//String desPath = getFilePath(session, sysObject, downloadPath);
			 
			sysObject.getFile(downloadPath);
			
			String objectName = getOsFileName(sysObject.getObjectName());
			
			if(isRenditionRequired) {
				
				IDfQuery query = new DfQuery();
				
				query.setDQL("select rendition,full_format from dmr_content where any parent_id='"+objectId+"' and rendition = 2");
				
				renditionsColl = query.execute(session, 0);
				
				while (renditionsColl.next()) 
				{ 
					format = renditionsColl.getString("full_format");
					
					dosExtension = session.getFormat(format).getDOSExtension();
					
					String renDesPath = downloadPath+objectName+" (rendered version)."+dosExtension;
					
					File fileRen=new File(renDesPath);
					
					if(fileRen.exists()){
						
		         		Path modifiedpath1= findFileName(downloadPath,objectName+" (rendered version)", dosExtension);
		         		
		         		renDesPath=modifiedpath1.toString();
		         		
					}
					
					sysObject.getFileEx(renDesPath,format,0,false);
					
				}
				
			}
			
			documentDownloadStatus = "success";
			
			System.out.println("Status :"+documentDownloadStatus);
			
			System.out.println("Document downloaded : "+objectId);

		} catch (Exception e) {
			
			documentDownloadStatus = "Failure"+e.getMessage();
			
			System.out.println("Status :"+documentDownloadStatus);
			
		}
		
		return documentDownloadStatus;
		
	}
	
	public String downloadDocumentContentAndRespectivePropertiesXML(IDfSession session, String objectId, String downloadPath, boolean isRenditionRequired){
		
		String documentDownloadStatus = null;
		
		IDfCollection renditionsColl = null;
		
		String format = null;
		
		String dosExtension = null;
		
		try {			

			IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(objectId));
			
			String contentType = sysObject.getString("a_content_type");
			
			String objectName = getOsFileName(sysObject.getObjectName());
			
			String desPath = downloadPath+objectName+"."+session.getFormat(contentType).getDOSExtension();
			
			File file=new File(desPath);
			 
			if(file.exists()){
				
         		Path modifiedpath= findFileName(downloadPath, objectName, session.getFormat(contentType).getDOSExtension());
         		
         		desPath=modifiedpath.toString();
         		
			}
			 
			sysObject.getFile(desPath);
			
			System.out.println(downloadPath+sysObject.getObjectName()+"."+session.getFormat(contentType).getDOSExtension());
			
			if(isRenditionRequired) {
				
				IDfQuery query = new DfQuery();
				
				query.setDQL("select rendition,full_format from dmr_content where any parent_id='"+objectId+"' and rendition = 2");
				
				renditionsColl = query.execute(session, 0);
				
				while (renditionsColl.next()) 
				{ 
					format = renditionsColl.getString("full_format");
					
					dosExtension = session.getFormat(format).getDOSExtension();
					
					String renDesPath = downloadPath+objectName+" (rendered version)."+dosExtension;
					
					File fileRen=new File(renDesPath);
					
					if(fileRen.exists()){
						
		         		Path modifiedpath1= findFileName(downloadPath,objectName+" (rendered version)", dosExtension);
		         		
		         		renDesPath=modifiedpath1.toString();
		         		
					}
					
					sysObject.getFileEx(renDesPath,format,0,false);
					
				}
				
			}
			
			documentDownloadStatus = "success";
			
			System.out.println("Status :"+documentDownloadStatus);
			
			System.out.println("Document downloaded : "+objectId);

		} catch (Exception e) {
			
			documentDownloadStatus = "Failure"+e.getMessage();
			
			System.out.println("Status :"+documentDownloadStatus);
			
		}
		
		return documentDownloadStatus;
		
	}
	
	public String getPrimaryFolderPath(String objectId, IDfSession session) throws DfException {
		
		String primaryFolderPath = null;
		
		IDfQuery query = new DfQuery();
		
		query.setDQL("select r_folder_path from dm_folder_r where r_object_id IN "
				+ "(select i_folder_id from dm_sysobject_r where i_position = -1 and r_object_id = '"+objectId+"') and i_position = -1");
		
		IDfCollection collection = query.execute(session, 0);
		
		while(collection.next()) {
			
			primaryFolderPath = collection.getString("r_folder_path");
			
		}
		
		return primaryFolderPath;
		
	}
	
	public String getVersionName(String objectId, IDfSession session) throws DfException {
		
		String versionName = null;
		
		IDfQuery query = new DfQuery();
		
		query.setDQL("select r_version_label from dm_sysobject_r where r_object_id = '"+objectId+"' and i_position = -1");
		
		IDfCollection collection = query.execute(session, 0);
		
		while(collection.next()) {
			
			versionName = collection.getString("r_version_label");
			
		}
		
		return versionName;
		
	}
	

	public String getVersionLabel(String objectId, IDfSession session, IDfSysObject sysObject) throws DfException {
		
		String versionlabel = null;
					
			int currentState = sysObject.getInt("r_current_state");
			
			if(currentState == 0 || currentState == 1 || currentState == 2) {
				
				versionlabel = "Draft";
				
			}else if(currentState == 3) {
				
				versionlabel = "Published";
				
			}else if(currentState == 4) {
				
				versionlabel = "Archived";
				
			}else {
				
				versionlabel = "Draft";
				
			}
		
		return versionlabel;
		
	}
	

	/*public String getVersionLabel(String objectId, IDfSession session, IDfSysObject sysObject) throws DfException {
		
		String versionlabel = null;
		
		IDfQuery query = new DfQuery();
		
		query.setDQL("select r_version_label from dm_sysobject_r where r_object_id = '"+objectId+"' and i_position = -3");
		
		IDfCollection collection = query.execute(session, 0);
		
		while(collection.next()) {
			
			versionlabel = collection.getString("r_version_label");
			
		}
		
		if(versionlabel != null) {
			
			if(versionlabel.equalsIgnoreCase("Draft") || versionlabel.equalsIgnoreCase("Under Approval") || versionlabel.equalsIgnoreCase("Approved")) {
				
				versionlabel = "Draft";
				
			}else if(versionlabel.equalsIgnoreCase("Published")) {
				
				versionlabel = "Published";
				
			}else if(versionlabel.equalsIgnoreCase("Archived")) {
				
				versionlabel = "Archived";
				
			}
			
		}else {
			
			int currentState = sysObject.getInt("r_current_state");
			
			if(currentState == 0 || currentState == 1 || currentState == 2) {
				
				versionlabel = "Draft";
				
			}else if(currentState == 3) {
				
				versionlabel = "Published";
				
			}else if(currentState == 4) {
				
				versionlabel = "Archived";
				
			}
			
		}
		
		return versionlabel;
		
	}*/
	
	public int getFolderPriority(String folderPath) {
		
		int priorityValue = 0;
		
		Map<String, Integer> folderPriorityMap = QMSMetaDataUtils.getFolderPriorityMap();
		
		for(Map.Entry<String, Integer> folderPriorityEntry : folderPriorityMap.entrySet()) {
			
			if(folderPath.contains(folderPriorityEntry.getKey())) {
				
				priorityValue = folderPriorityEntry.getValue();
				
				return priorityValue;
				
			}
			
		}
		
		return priorityValue;
		
	}
	
	
	public Path findFolderName(String dir, final String folderName){
		
		Path ret =Paths.get(dir, String.format("%s", folderName));
	    
	    if (!Files.exists(ret)){
	        return ret;
	    }else {
        	
        	int numberOfFiles = ret.toFile().listFiles().length;
        	
        	if(numberOfFiles <= 1000) {
        		
        		return ret;
        		
        	}
        	
        }
	    
	    for (int i = 0; i < Integer.MAX_VALUE; i++) {
	    	
	    	ret = Paths.get(dir, String.format("%s%d", folderName.concat("_"), i));
	    	
	        if (!Files.exists(ret)){
	            return ret;
	        }else {
	        	
	        	int numberOfFiles = ret.toFile().listFiles().length;
	        	
	        	if(numberOfFiles <= 1000) {
	        		
	        		return ret;
	        		
	        	}
	        	
	        }
	        
	    }
	    
	    return ret;
			    
	}
	
	public void makeDirectoryIfNotExist(String filePath) {
		
		File file = new File(filePath);
		
		if(!file.exists()) {
			
			file.mkdirs();
			
		}
		
	}
	
	public String generateFullFolderPath(String destinationFolderPath, String productCompany, String versionLabel) {
		
		String finalDestinationPath = destinationFolderPath + "/" + productCompany + "/" + versionLabel + "/";
		
		//System.out.println("Final Destination Path : : : "+finalDestinationPath);
		
		File DestinationFilePath = new File(finalDestinationPath);
		
		if(!DestinationFilePath.exists()) {
			
			DestinationFilePath.mkdirs();
			
		}
		
		if(DestinationFilePath.isDirectory()) {
			
			finalDestinationPath = findFolderName(finalDestinationPath,"Folder").toString()+"/";
			
			makeDirectoryIfNotExist(finalDestinationPath);
			
		}
		
		return finalDestinationPath;
		
	}
	
	public Map<String, String> consolidateMetadataMap(Map<String, String> metadataMap, Map<String, String> xmlMetadata) {
		
		if(metadataMap != null && xmlMetadata != null) {
			
			for(Map.Entry<String, String> mapEntry : metadataMap.entrySet()) {
				
	            String mapKey = mapEntry.getKey();
				
				String mapValue = mapEntry.getValue();
				
				if(xmlMetadata.containsKey(mapKey)){
					
					xmlMetadata.replace(mapKey, xmlMetadata.get(mapKey), mapValue);
					
				}else {
					
					xmlMetadata.put(mapKey, mapValue);
					
				}
				
			}
			
		}
		
		return xmlMetadata;
				
	}
	
	public Map<String, String> changeFunctionValueIfRequired(Map<String, String> metadataMap, String folderPath) {
		
		final String functionName = "bh:bh_function";
		
		final String subFunctionName = "bh:bh_sub_function";
		
		if(folderPath != null && metadataMap != null) {
			
			if(folderPath.contains("/QMS/Oil and Gas QMS/00. BHGE Level 1 Global Documents")) {
				
				String functionValue = metadataMap.get(functionName);
				
				if(functionValue != null) {
					
					if(functionValue.equalsIgnoreCase("Logistics")) {
						
						metadataMap.replace(functionName, functionValue, "Supply Chain");
						
						if(metadataMap.get(subFunctionName) != null) {
							
							metadataMap.replace(subFunctionName, metadataMap.get(subFunctionName), "Logistics");
							
						}else {
							
							metadataMap.put(subFunctionName, "Logistics");
							
						}
						
					}else if(functionValue.equalsIgnoreCase("Manufacturing")){
						
						metadataMap.replace(functionName, functionValue, "Supply Chain");
						
						if(metadataMap.get(subFunctionName) != null) {
							
							metadataMap.replace(subFunctionName, metadataMap.get(subFunctionName), "Manufacturing");
							
						}else {
							
							metadataMap.put(subFunctionName, "Manufacturing");
							
						}
						
					}else if(functionValue.equalsIgnoreCase("Security")){
						
						metadataMap.replace(functionName, functionValue, "HSE");
						
						if(metadataMap.get(subFunctionName) != null) {
							
							metadataMap.replace(subFunctionName, metadataMap.get(subFunctionName), "Security");
							
						}else {
							
							metadataMap.put(subFunctionName, "Security");
							
						}
						
					}else if(functionValue.equalsIgnoreCase("Sourcing")){
						
						metadataMap.replace(functionName, functionValue, "Supply Chain");
						
						if(metadataMap.get(subFunctionName) != null) {
							
							metadataMap.replace(subFunctionName, metadataMap.get(subFunctionName), "Sourcing");
							
						}else {
							
							metadataMap.put(subFunctionName, "Sourcing");
							
						}
						
					}
					
				}
				
			}
			
		}
		
		return metadataMap;
		
	}
	
	
	public Map<String, String> updateDSValues(String folderPath, Map<String, Map<String, String>> folderPathPropertyMap, Map<String, String> documentumAndAlfrescoPropertiesMap,
			Map<String, String> metadataMap) {
		
		if(folderPathPropertyMap.containsKey(folderPath)) {
			
			Map<String, String> valuesMap = folderPathPropertyMap.get(folderPath);
			
			for(Map.Entry<String, String> mapEntry : valuesMap.entrySet()) {
				
				String mapKey = mapEntry.getKey();
				
				String mapValue = mapEntry.getValue();
				
				if(mapValue != null && (!mapValue.equalsIgnoreCase("")) && mapKey != null) {
					
					if(metadataMap.containsKey(documentumAndAlfrescoPropertiesMap.get(mapKey))){
						
						metadataMap.replace(documentumAndAlfrescoPropertiesMap.get(mapKey), metadataMap.get(documentumAndAlfrescoPropertiesMap.get(mapKey)), mapValue);
						
					}else {
						
						metadataMap.put(documentumAndAlfrescoPropertiesMap.get(mapKey), mapValue);
						
					}
					
				}
				
			}
			
		}
		
		return metadataMap;
		
	}
	
	public Map<String, String> updateValuesAsPerObjectId(IDfSession session, IDfSysObject sysObject, Map<String, Map<String, String>> objectIdPropertyMap,
			Map<String, Map<String, String>> propertyMap, List<String> versionIdList, Map<String, String> metadataMap) throws DfException {
		
        boolean isTypePropertiesExist = false;
		
		String objectTypeName = sysObject.getTypeName();
		
		if(propertyMap.get(objectTypeName) != null) {
			
			isTypePropertiesExist = true;
			
		}
		
		if(isTypePropertiesExist && objectIdPropertyMap != null) {
			
			Map<String, String> documentumAndAlfrescoPropertiesMap = propertyMap.get(objectTypeName);
			
			for(String objectId : versionIdList) {
				
				if(objectIdPropertyMap.containsKey(objectId)) {
					
					Map<String, String> valuesMap = objectIdPropertyMap.get(objectId);
					
					for(Map.Entry<String, String> mapEntry : valuesMap.entrySet()) {
						
						String mapKey = mapEntry.getKey();
						
						String mapValue = mapEntry.getValue();
						
						if(mapValue != null && (!mapValue.equalsIgnoreCase("")) && mapKey != null) {
							
							if(metadataMap.containsKey(documentumAndAlfrescoPropertiesMap.get(mapKey))){
								
								metadataMap.replace(documentumAndAlfrescoPropertiesMap.get(mapKey), metadataMap.get(documentumAndAlfrescoPropertiesMap.get(mapKey)), mapValue);
								
							}else {
								
								metadataMap.put(documentumAndAlfrescoPropertiesMap.get(mapKey), mapValue);
								
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
		return metadataMap;
		
	}
	
	public Map<String, String> extractProductCompanyMetadataMap(IDfSession session, IDfSysObject sysObject, String folderPath, Map<String, Map<String, String>> folderPathPropertyMap,
			Map<String, Map<String, String>> propertyMap) throws DfException {
		
		String productCompanyName = null;
		
		String functionName = null;
		
		boolean isTypePropertiesExist = false;
		
		Map<String, String> metadataMap = new HashMap<String, String>();
		
		String objectTypeName = sysObject.getTypeName();
		
		if(propertyMap.get(objectTypeName) != null) {
			
			isTypePropertiesExist = true;
			
		}
		
		if(isTypePropertiesExist && folderPathPropertyMap != null) {
			
			Map<String, String> documentumAndAlfrescoPropertiesMap = propertyMap.get(objectTypeName);
			
			if(folderPath.contains("/QMS/Oil and Gas QMS/00. BHGE Level 1 Global Documents")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalBHProductCompanyName);
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/01. O&G Global QMS Documents")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}
				
                if(functionName != null) {
					
					metadataMap.put(functionName, "Quality");
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/02. O&G Global Quality")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}
				
                if(functionName != null) {
					
					metadataMap.put(functionName, "Quality");
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/03. O&G Surface")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.ofsProductCompanyName);
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/05. O&G Digital Solutions")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.dsProductCompanyName);
					
				}
				
				metadataMap = updateDSValues(folderPath, folderPathPropertyMap, documentumAndAlfrescoPropertiesMap, metadataMap);
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/07. Oilfield Equipment")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.ofeProductCompanyName);
					
				}
				
			}else/* if(folderPath.contains("/QMS/Oil and Gas QMS/08. O&G Turbomachinery & Process Solutions (TPS)")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.tpsProductCompanyName);
					
				}
				
			}else */if(folderPath.contains("/QMS/Oil and Gas QMS/09. O&G Global EHS")) {
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}
				
                if(functionName != null) {
					
					metadataMap.put(functionName, "Health, Safety & Environment");
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/10. O&G Engineering")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}
				
                if(functionName != null) {
					
					metadataMap.put(functionName, "Engineering/Technology");
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/11. O&G Finance")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}

                if(functionName != null) {
					
					metadataMap.put(functionName, "Finance");
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/12. O&G Human Resources")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}

                if(functionName != null) {
					
					metadataMap.put(functionName, "Human Resources");
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/13. O&G Legal")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}

                if(functionName != null) {
					
					metadataMap.put(functionName, "Legal");
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/14. O&G Logistcs")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}

                if(functionName != null) {
					
					metadataMap.put(functionName, "Logistics");
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/15. O&G Marketing")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}

                if(functionName != null) {
					
					metadataMap.put(functionName, "Marketing");
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/16. O&G Operations")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}

                if(functionName != null) {
					
					metadataMap.put(functionName, "Operations");
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/17. O&G Information Technology")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}

                if(functionName != null) {
					
					metadataMap.put(functionName, "Digital Technology");
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/18. O&G Commercial Operations")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}

                if(functionName != null) {
					
					metadataMap.put(functionName, "Commercial Operations");
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/19. Oilfield Service")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.ofsProductCompanyName);
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/20. Regions")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.ofsProductCompanyName);
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/GE QMS Documentum Reports")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}
				

                if(functionName != null) {
					
					metadataMap.put(functionName, "Doc Stats");
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/O&G Test Folder")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}
				
                if(functionName != null) {
					
					metadataMap.put(functionName, "test");
					
				}
				
			}else if(folderPath.contains("/QMS/Oil and Gas QMS/zFiles Archived")) {
				
				productCompanyName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.productCompanyAttributeName);
				
				functionName = documentumAndAlfrescoPropertiesMap.get(QMSMetaDataUtils.functionAttributeName);
				
				if(productCompanyName != null) {
					
					metadataMap.put(productCompanyName, QMSMetaDataUtils.globalProductCompanyName);
					
				}
				

                if(functionName != null) {
					
					metadataMap.put(functionName, "zArchive");
					
				}
				
			}
			
		}
		
		return metadataMap;
		
	}
	
/*	public String getFolderPath(IDfSession session, IDfSysObject sysObject) throws DfException {
		
		String folderPath = null;
		
		int folderPriority = 0;
		
		int folderIdCount = sysObject.getValueCount("i_folder_id");
		
		if(folderIdCount == 1) {
			
			String folderId = sysObject.getRepeatingString("i_folder_id", 0);
			
			IDfFolder folderObject = (IDfFolder) session.getObject(new DfId(folderId));
			
			int folderPathCount = folderObject.getValueCount("r_folder_path");
			
			if(folderPathCount == 1) {
				
				folderPath = folderObject.getRepeatingString("r_folder_path", 0);
				
				if(!folderPath.contains("/QMS/Oil and Gas QMS/")) {
					
					folderPath = null;
					
				}
				
			}else {
				
				String tempFolderPath = null;
				
				int tempPriority = 0;
				
				for(int folderPathIndex = 0; folderPathIndex < folderPathCount; folderPathIndex++) {
					
					tempFolderPath = folderObject.getRepeatingString("r_folder_path", folderPathIndex);
					
					if(tempFolderPath != null) {
						
						if(tempFolderPath.contains("/QMS/Oil and Gas QMS/")) {
							
							tempPriority = getFolderPriority(tempFolderPath);
							
							if(folderPriority > 0) {
								
								if(tempPriority > 0) {
									
									if(tempPriority < folderPriority) {
										
										folderPriority = tempPriority;
										
										folderPath = tempFolderPath;
										
									}
									
								}
								
							}else {
								
								folderPriority = tempPriority;
								
								folderPath = tempFolderPath;
								
							}
							
						}
						
					}
					
				}
				
			}
			
		}else {
			
			String tempFolderPath = null;
			
			int tempPriority = 0;
			
			for(int folderIdIndex = 0; folderIdIndex < folderIdCount; folderIdIndex++) {
				
				String folderId = sysObject.getRepeatingString("i_folder_id", folderIdIndex);
				
				IDfFolder folderObject = (IDfFolder) session.getObject(new DfId(folderId));
				
				int folderPathCount = folderObject.getValueCount("r_folder_path");
				
                for(int folderPathIndex = 0; folderPathIndex < folderPathCount; folderPathIndex++) {
					
					tempFolderPath = folderObject.getRepeatingString("r_folder_path", folderPathIndex);
					
					if(tempFolderPath != null) {
						
						if(tempFolderPath.contains("/QMS/Oil and Gas QMS/")) {
							
							tempPriority = getFolderPriority(tempFolderPath);
							
							if(folderPriority > 0) {
								
								if(tempPriority > 0) {
									
									if(tempPriority < folderPriority) {
										
										folderPriority = tempPriority;
										
										folderPath = tempFolderPath;
										
									}
									
								}
								
							}else {
								
								folderPriority = tempPriority;
								
								folderPath = tempFolderPath;
								
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
		return folderPath;
		
	}
*/	
	
	public String getFolderPath(IDfSession session, IDfSysObject sysObject, String strDocumentPC) throws DfException {
		
		String folderPath = null;
		
		int folderPriority = 0;
		
		int folderIdCount = sysObject.getValueCount("i_folder_id");
		
		if(folderIdCount == 1) {
			
			String folderId = sysObject.getRepeatingString("i_folder_id", 0);
			
			IDfFolder folderObject = (IDfFolder) session.getObject(new DfId(folderId));
			
			int folderPathCount = folderObject.getValueCount("r_folder_path");
			
			if(folderPathCount == 1) {
				
				folderPath = folderObject.getRepeatingString("r_folder_path", 0);
				
				if(!folderPath.contains("/QMS/Oil and Gas QMS/")) {
					
					folderPath = null;
					
				}
				
			}else {
				
				String tempFolderPath = null;
				
				int tempPriority = 0;
				
				for(int folderPathIndex = 0; folderPathIndex < folderPathCount; folderPathIndex++) {
					
					tempFolderPath = folderObject.getRepeatingString("r_folder_path", folderPathIndex);
					
					if(tempFolderPath != null) {
						
						if(strDocumentPC != null) {
							
							if(strDocumentPC.equalsIgnoreCase("TPS")) {
								
								if(tempFolderPath.contains("/QMS/Oil and Gas QMS/08. O&G Turbomachinery & Process Solutions (TPS)")) {
									
									folderPath = tempFolderPath;
									
								}
								
							}else if(strDocumentPC.equalsIgnoreCase("NO TPS")) {
								
								if(!tempFolderPath.contains("/QMS/Oil and Gas QMS/08. O&G Turbomachinery & Process Solutions (TPS)")) {

									if(tempFolderPath.contains("/QMS/Oil and Gas QMS/")) {
										
										tempPriority = getFolderPriority(tempFolderPath);
										
										if(folderPriority > 0) {
											
											if(tempPriority > 0) {
												
												if(tempPriority < folderPriority) {
													
													folderPriority = tempPriority;
													
													folderPath = tempFolderPath;
													
												}
												
											}
											
										}else {
											
											folderPriority = tempPriority;
											
											folderPath = tempFolderPath;
											
										}
										
									}
									
								}
								
							}
							
						}else {
							
							if(tempFolderPath.contains("/QMS/Oil and Gas QMS/")) {
								
								tempPriority = getFolderPriority(tempFolderPath);
								
								if(folderPriority > 0) {
									
									if(tempPriority > 0) {
										
										if(tempPriority < folderPriority) {
											
											folderPriority = tempPriority;
											
											folderPath = tempFolderPath;
											
										}
										
									}
									
								}else {
									
									folderPriority = tempPriority;
									
									folderPath = tempFolderPath;
									
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		}else {
			
			String tempFolderPath = null;
			
			int tempPriority = 0;
			
			for(int folderIdIndex = 0; folderIdIndex < folderIdCount; folderIdIndex++) {
				
				String folderId = sysObject.getRepeatingString("i_folder_id", folderIdIndex);
				
				IDfFolder folderObject = (IDfFolder) session.getObject(new DfId(folderId));
				
				int folderPathCount = folderObject.getValueCount("r_folder_path");
				
                for(int folderPathIndex = 0; folderPathIndex < folderPathCount; folderPathIndex++) {
					
					tempFolderPath = folderObject.getRepeatingString("r_folder_path", folderPathIndex);
					
					if(tempFolderPath != null) {
						
						if(strDocumentPC != null) {
							
							if(strDocumentPC.equalsIgnoreCase("TPS")) {
								
								if(tempFolderPath.contains("/QMS/Oil and Gas QMS/08. O&G Turbomachinery & Process Solutions (TPS)")) {
									
									folderPath = tempFolderPath;
									
								}
								
							}else if(strDocumentPC.equalsIgnoreCase("NO TPS")) {
								
								if(!tempFolderPath.contains("/QMS/Oil and Gas QMS/08. O&G Turbomachinery & Process Solutions (TPS)")) {

									if(tempFolderPath.contains("/QMS/Oil and Gas QMS/")) {
										
										tempPriority = getFolderPriority(tempFolderPath);
										
										if(folderPriority > 0) {
											
											if(tempPriority > 0) {
												
												if(tempPriority < folderPriority) {
													
													folderPriority = tempPriority;
													
													folderPath = tempFolderPath;
													
												}
												
											}
											
										}else {
											
											folderPriority = tempPriority;
											
											folderPath = tempFolderPath;
											
										}
										
									}
									
								}
								
							}
							
						}else {
							
							if(tempFolderPath.contains("/QMS/Oil and Gas QMS/")) {
								
								tempPriority = getFolderPriority(tempFolderPath);
								
								if(folderPriority > 0) {
									
									if(tempPriority > 0) {
										
										if(tempPriority < folderPriority) {
											
											folderPriority = tempPriority;
											
											folderPath = tempFolderPath;
											
										}
										
									}
									
								}else {
									
									folderPriority = tempPriority;
									
									folderPath = tempFolderPath;
									
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
		return folderPath;
		
	}
	

	public List<String> getFolderPath(IDfSession session, IDfSysObject sysObject) throws DfException {
		
		List<String> folderPathList = new ArrayList<String>();
		
		String folderPath = null;
		
		int folderIdCount = sysObject.getValueCount("i_folder_id");
		
		if(folderIdCount == 1) {
			
			String folderId = sysObject.getRepeatingString("i_folder_id", 0);
			
			IDfFolder folderObject = (IDfFolder) session.getObject(new DfId(folderId));
			
			int folderPathCount = folderObject.getValueCount("r_folder_path");
			
			if(folderPathCount == 1) {
				
				folderPath = folderObject.getRepeatingString("r_folder_path", 0);
				
				folderPathList.add(folderPath);
				
			}else {
				
				String tempFolderPath = null;
				
				for(int folderPathIndex = 0; folderPathIndex < folderPathCount; folderPathIndex++) {
					
					tempFolderPath = folderObject.getRepeatingString("r_folder_path", folderPathIndex);
							
					folderPathList.add(tempFolderPath);
					
				}
				
			}
			
		}else {
			
			String tempFolderPath = null;
			
			for(int folderIdIndex = 0; folderIdIndex < folderIdCount; folderIdIndex++) {
				
				String folderId = sysObject.getRepeatingString("i_folder_id", folderIdIndex);
				
				IDfFolder folderObject = (IDfFolder) session.getObject(new DfId(folderId));
				
				int folderPathCount = folderObject.getValueCount("r_folder_path");
				
                for(int folderPathIndex = 0; folderPathIndex < folderPathCount; folderPathIndex++) {
					
					tempFolderPath = folderObject.getRepeatingString("r_folder_path", folderPathIndex);
					
					folderPathList.add(tempFolderPath);
					
				}
				
			}
			
		}
		
		return folderPathList;
		
	}

	public List<String> getAllVersions(IDfSession session, IDfSysObject sysObject, String strType) throws DfException {
		
		List<String> versionIdList = new ArrayList<String>();
		
		String chronicleId = sysObject.getString("i_chronicle_id");
		
        IDfQuery query = new DfQuery();
		
		query.setDQL("select r_object_id from "+strType+" (all) where i_chronicle_id = '"+chronicleId+"'");
		
		IDfCollection collection = query.execute(session, 0);
		
		while(collection.next()) {
			
			if(collection.getString("r_object_id") != null) {
				
				versionIdList.add(collection.getString("r_object_id"));
				
			}
			
		}
		
		return versionIdList;
		
	}

    public TreeMap<String, String> getVersionAndObjectIdMapDesc(IDfSession session, List<String> versionIdList) throws DfException {
		
		//TreeMap<String, String> versionNameAndIdMap = new TreeMap<String, String>();
		
		TreeMap<String, String> versionNameAndIdMap = new TreeMap<String, String>(new Comparator<String>() {
			
			public int getBeforeDotValue(String object1) {
				
				int beforeDotValue = 0;
				
				if(object1 != null) {
					
					if(object1.contains(".")) {
						
						if(object1.indexOf(".") > 0) {
							
							String strbeforeDotValue = object1.substring(0,object1.indexOf("."));
							
							//System.out.println("Before Dot : : : "+strbeforeDotValue);
							
							beforeDotValue = Integer.parseInt(strbeforeDotValue);
							
						}
						
					}
					
				}
				
				return beforeDotValue;
				
			}
			

			public int getAfterDotValue(String object1) {
				
				int afterDotValue = 0;
				
				if(object1 != null) {
					
					if(object1.contains(".")) {
						
						if(object1.indexOf(".") > 0) {
							
							String strafterDotValue = object1.substring(object1.indexOf(".")+1);
							
							//System.out.println("After Dot : : : "+strafterDotValue);
							
							afterDotValue = Integer.parseInt(strafterDotValue);
							
						}
						
					}
					
				}
				
				return afterDotValue;
				
			}

			@Override
			public int compare(String object1, String object2) {
				
				int object1BeforeDotValue = getBeforeDotValue(object1);
				
				int object1AfterDotValue = getAfterDotValue(object1);
				
				int object2BeforeDotValue = getBeforeDotValue(object2);
				
				int object2AfterDotValue = getAfterDotValue(object2);
				
				if((object1BeforeDotValue == object2BeforeDotValue) && (object1AfterDotValue < object2AfterDotValue)) {
					
					return 1;
					
				}else if((object1BeforeDotValue < object2BeforeDotValue) && (object1AfterDotValue == object2AfterDotValue)) {
					
					return 1;
					
				}else if((object1BeforeDotValue == object2BeforeDotValue) && (object1AfterDotValue > object2AfterDotValue)) {
					
					return -1;
					
				}else if((object1BeforeDotValue > object2BeforeDotValue) && (object1AfterDotValue == object2AfterDotValue)) {
					
					return -1;
					
				}
				
				//System.out.println(object1);
				
				return 0;
			}
		});
		
		for(String versionId : versionIdList) {
			
			String versionName = getVersionName(versionId, session);
			
			if(versionName != null) {
				
				versionNameAndIdMap.put(versionName, versionId);
				
			}else {
				
				return null;
				
			}
			
		}
		
		return versionNameAndIdMap;
		
	}

	
    public TreeMap<String, String> getVersionAndObjectIdMap(IDfSession session, List<String> versionIdList) throws DfException {
		
		//TreeMap<String, String> versionNameAndIdMap = new TreeMap<String, String>();
		
		TreeMap<String, String> versionNameAndIdMap = new TreeMap<String, String>(new Comparator<String>() {
			
			public int getBeforeDotValue(String object1) {
				
				int beforeDotValue = 0;
				
				if(object1 != null) {
					
					if(object1.contains(".")) {
						
						if(object1.indexOf(".") > 0) {
							
							String strbeforeDotValue = object1.substring(0,object1.indexOf("."));
							
							//System.out.println("Before Dot : : : "+strbeforeDotValue);
							
							beforeDotValue = Integer.parseInt(strbeforeDotValue);
							
						}
						
					}
					
				}
				
				return beforeDotValue;
				
			}
			

			public int getAfterDotValue(String object1) {
				
				int afterDotValue = 0;
				
				if(object1 != null) {
					
					if(object1.contains(".")) {
						
						if(object1.indexOf(".") > 0) {// object1.indexOf(".") < object1.length()
							
							String strafterDotValue = object1.substring(object1.indexOf(".")+1);
							
							//System.out.println("After Dot : : : "+strafterDotValue);
							
							afterDotValue = Integer.parseInt(strafterDotValue);
							
						}
						
					}
					
				}
				
				return afterDotValue;
				
			}

			@Override
			public int compare(String object1, String object2) {
				
				int object1BeforeDotValue = getBeforeDotValue(object1);
				
				int object1AfterDotValue = getAfterDotValue(object1);
				
				int object2BeforeDotValue = getBeforeDotValue(object2);
				
				int object2AfterDotValue = getAfterDotValue(object2);
				
				if((object1BeforeDotValue == object2BeforeDotValue) && (object1AfterDotValue < object2AfterDotValue)) {
					
					return -1;
					
				}else if((object1BeforeDotValue < object2BeforeDotValue) && (object1AfterDotValue == object2AfterDotValue)) {
					
					return -1;
					
				}else if((object1BeforeDotValue == object2BeforeDotValue) && (object1AfterDotValue > object2AfterDotValue)) {
					
					return 1;
					
				}else if((object1BeforeDotValue > object2BeforeDotValue) && (object1AfterDotValue == object2AfterDotValue)) {
					
					return 1;
					
				}
				
				//System.out.println(object1);
				
				return 0;
			}
		});
		
		for(String versionId : versionIdList) {
			
			String versionName = getVersionName(versionId, session);
			
			if(versionName != null) {
				
				versionNameAndIdMap.put(versionName, versionId);
				
			}else {
				
				return null;
				
			}
			
		}
		
		return versionNameAndIdMap;
		
	}
	
	/*public TreeMap<Float, String> getVersionAndObjectIdMap(IDfSession session, List<String> versionIdList) throws DfException {
		
		TreeMap<Float, String> versionNameAndIdMap = new TreeMap<Float, String>(new Comparator<Float, String>() {
			
		});
		
		for(String versionId : versionIdList) {
			
			String versionName = getVersionName(versionId, session);
			
			if(versionName != null) {
				
				Float version = Float.parseFloat(versionName);
				
				if(version != null) {
					
					versionNameAndIdMap.put(version, versionId);
					
				}
				
			}else {
				
				return null;
				
			}
			
		}
		
		return versionNameAndIdMap;
		
	}*/
	
	public String validateAndUpdateValueIfRequired(String attributeName, String attributeValue, Map<String, Map<String, String>> propertyValueMap) {
		
		if(propertyValueMap.get(attributeName) != null) {
			
			Map<String, String> valuesMap = propertyValueMap.get(attributeName);
			
			if(valuesMap.get(attributeValue) != null) {
				
				attributeValue = valuesMap.get(attributeValue);
				
			}
			
		}
		
		return attributeValue;
		
	}
	
    public Map<String, String> extractNewMetadataMap(IDfSession session, IDfSysObject sysObject, String objectId, String docTypeName
    		, Map<String, String> propertyMap) {
				
		Map<String, String> xmlMetadata = new HashMap<String, String>();
		
		boolean isTypeExist = false;
		
		boolean isTypePropertiesExist = false;
		
		try {
			
			String objectTypeName = sysObject.getTypeName();
			
//			if(objectTypeName != null) {
				
//				Set<String> documentumTypeSet = typeMap.keySet();
//				
//				Iterator<String> iterator = documentumTypeSet.iterator();
				
//				while(iterator.hasNext()) {
//					
//					String documentumTypeName = iterator.next();
//					
//					if(objectTypeName.equalsIgnoreCase(documentumTypeName)) {
//						
//						//xmlMetadata.put("type", typeMap.get(documentumTypeName));
//						
//						xmlMetadata.put("nodeType", typeMap.get(documentumTypeName));
//						
//						isTypeExist = true;
//						
//						break;
//						
//					}
//					
//				}
				
				
	//		}
			
//			if(propertyMap.get(objectTypeName) != null) {
//				
//				isTypePropertiesExist = true;
//				
//			}
			xmlMetadata.put("nodeType", docTypeName);
			
//			if(isTypeExist && isTypePropertiesExist) {
				
				//Map<String, String> documentumAndAlfrescoPropertiesMap = QMSMetaDataUtils.getDocumentumAndAlfrescopropertiesMao();
				
				// Map<String, String> documentumAndAlfrescoPropertiesMap = propertyMap.get(objectTypeName);
				
				for(Map.Entry<String, String> propertyEntry : propertyMap.entrySet()) {
					
					String mapKey = propertyEntry.getKey();
					
					String mapValue = propertyEntry.getValue();
					
					if("document_type".equalsIgnoreCase(mapKey)) {

						for(int attributeIndex = 0; attributeIndex < sysObject.getAttrCount(); attributeIndex++) {
							
							IDfAttr attributeObject = sysObject.getAttr(attributeIndex);
							
							String attributeName = attributeObject.getName();
							
							if(attributeName != null && "".equalsIgnoreCase(attributeName)) {
								
								if(attributeName.contains("document_type")) {
									
									mapKey = attributeName;
									
								}
								
							}
							
						}
						
					}
					
					if(sysObject.hasAttr(mapKey)) {
						
						if(sysObject.getAttrDataType(mapKey) == IDfAttr.DM_STRING) {
							
							if(sysObject.isAttrRepeating(mapKey)) {
								
								int attributeIndexCount = sysObject.getValueCount(mapKey);
								
								StringBuilder stringBuilder = new StringBuilder();
								
								for(int attributeIndex = 0; attributeIndex < attributeIndexCount; attributeIndex++) {
									
									String attributeValue = sysObject.getRepeatingString(mapKey, attributeIndex);	
									
								// 	attributeValue = validateAndUpdateValueIfRequired(mapKey,attributeValue,propertyValueMap);
									
									if(attributeValue != null) {
										
										if(!attributeValue.equalsIgnoreCase("")) {
											
											if(mapKey.equalsIgnoreCase("g_sub_process")) {
												
												if(attributeValue.contains("-")) {
													
													if(attributeValue.indexOf("-") >= 0) {
														
														attributeValue = attributeValue.substring(attributeValue.indexOf("-")+2);
														
													}
													
												}
												
											}
											
											stringBuilder.append(attributeValue);
											
											if(attributeIndex < attributeIndexCount -1) {
												
												stringBuilder.append(",");
												
											}
											
										}
										
									}
									
								}
								
								xmlMetadata.put(mapValue, stringBuilder.toString());
								
							}else {
								
								// String attributeValue = validateAndUpdateValueIfRequired(mapKey,sysObject.getString(mapKey),propertyValueMap);
								String attributeValue = sysObject.getString(mapKey);
								if(attributeValue != null) {
									
									if (!attributeValue.equalsIgnoreCase("")) {
										
										if(mapKey.equalsIgnoreCase("object_name")) {
											
											attributeValue = getOsFileName(attributeValue);
											
											String contentType = sysObject.getString("a_content_type");
											
											if(contentType != null) {
												
												if(session.getFormat(contentType) != null) {
													
													String dosExtension = session.getFormat(contentType).getDOSExtension();
													
													if(dosExtension != null) {
														
														attributeValue = attributeValue +"."+dosExtension;
														
													}
													
												}
									
											}
											
											xmlMetadata.put(mapValue, attributeValue);
											
										}else {
											
											xmlMetadata.put(mapValue, attributeValue);
											
										}
										
									}
									
								}
								
							}
							
						}else if(sysObject.getAttrDataType(mapKey) == IDfAttr.DM_TIME){
							
							IDfAttr idfAttr = sysObject.getAttr(sysObject.findAttrIndex(mapKey));

							if(idfAttr.isRepeating()) {
								
								int attributeIndexCount = sysObject.getValueCount(mapKey);
								// ** 
								if(attributeIndexCount > 1) {
									
									StringBuilder stringBuilder = new StringBuilder();
									
									for(int attributeIndex = 0; attributeIndex < attributeIndexCount; attributeIndex++) {
										
										IDfTime idfTime = sysObject.getRepeatingTime(mapKey, attributeIndex);
										
										TimeZone tz = TimeZone.getTimeZone("UTC");
										
										DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
										
										df.setTimeZone(tz);
										
										if(idfTime != null) {
											
											if(idfTime.getDate() != null) {
												
												stringBuilder.append(df.format(idfTime.getDate()));
												
												if(attributeIndex < attributeIndexCount -1) {
													
													stringBuilder.append(",");
													
												}
												
											}
											
										}
										
									}
									
									xmlMetadata.put(mapValue, stringBuilder.toString());
									
								}else {
									
									IDfTime idfTime = sysObject.getTime(mapKey);
									
									TimeZone tz = TimeZone.getTimeZone("UTC");
									
									DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
									
									df.setTimeZone(tz);
									
									if(idfTime != null) {
										
										if(idfTime.getDate() != null) {
											
											xmlMetadata.put(mapValue, df.format(idfTime.getDate()));
											
										}
										
									}
									
								}
								
							}else {
								
								IDfTime idfTime = sysObject.getTime(mapKey);
								
								TimeZone tz = TimeZone.getTimeZone("UTC");
								
								DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
								
								df.setTimeZone(tz);
								
								if(idfTime != null) {
									
									if(idfTime.getDate() != null) {
										
										xmlMetadata.put(mapValue, df.format(idfTime.getDate()));
										
									}
									
								}
								
							}
							
						}else if(sysObject.getAttrDataType(mapKey) == IDfAttr.DM_BOOLEAN) {
													
								String attributeValue = Boolean.toString(sysObject.getBoolean(mapKey));
								
								xmlMetadata.put(mapValue, attributeValue);
							
						}else if(sysObject.getAttrDataType(mapKey) == IDfAttr.DM_ID) {

							IDfAttr idfAttr = sysObject.getAttr(sysObject.findAttrIndex(mapKey));
							
							if(idfAttr.isRepeating()) {
								
								int attributeIndexCount = sysObject.getValueCount(mapKey);
								
								if(attributeIndexCount > 1) {
									
									StringBuilder stringBuilder = new StringBuilder();
									
									for(int attributeIndex = 0; attributeIndex < attributeIndexCount; attributeIndex++) {
										
										if(sysObject.getRepeatingId(mapKey, attributeIndex) != null) {
											
											stringBuilder.append(sysObject.getRepeatingId(mapKey, attributeIndex).getId());
											
											if(attributeIndex < attributeIndexCount -1) {
												
												stringBuilder.append(",");
												
											}
											
										}
										
									}
											
								}else {
									
									if(sysObject.getId(mapKey) != null) {
										
										xmlMetadata.put(mapValue, sysObject.getId(mapKey).getId());
										
									}
								}
								
							}else {
								
								if(sysObject.getId(mapKey) != null) {
									
									xmlMetadata.put(mapValue, sysObject.getId(mapKey).getId());
									
								}
								
							}
							
							
						}else if(sysObject.getAttrDataType(mapKey) == IDfAttr.DM_INTEGER) {
							
							IDfAttr idfAttr = sysObject.getAttr(sysObject.findAttrIndex(mapKey));
							
							if(idfAttr.isRepeating()) {
								
								int attributeIndexCount = sysObject.getValueCount(mapKey);
								
								if(attributeIndexCount > 1) {

									StringBuilder stringBuilder = new StringBuilder();
									
									for(int attributeIndex = 0; attributeIndex < attributeIndexCount; attributeIndex++) {
										
										stringBuilder.append(Integer.toString(sysObject.getRepeatingInt(mapKey, attributeIndex)));
										
										if(attributeIndex < attributeIndexCount-1) {
											
											stringBuilder.append(",");
											
										}
										
									}
									
									xmlMetadata.put(mapValue, stringBuilder.toString());							
									
								}else {
									
									String attributeValue = Integer.toString(sysObject.getInt(mapKey));
									
									xmlMetadata.put(mapValue, attributeValue);
									
								}
								
							}else {

								String attributeValue = Integer.toString(sysObject.getInt(mapKey));
								
								if("g_content_category".equalsIgnoreCase(mapKey)) {
									
									if(sysObject.getInt(mapKey) == 1) {
										
										attributeValue = "Document";
										
									}else if(sysObject.getInt(mapKey) == 2) {
										
										attributeValue = "URL";
										
									}
									
								}
								
								xmlMetadata.put(mapValue, attributeValue);
								
							}
							
							
						}else if(sysObject.getAttrDataType(mapKey) == IDfAttr.DM_DOUBLE) {
							
							IDfAttr idfAttr = sysObject.getAttr(sysObject.findAttrIndex(mapKey));
							
							if(idfAttr.isRepeating()) {
								
								int attributeIndexCount = sysObject.getValueCount(mapKey);
								
								if(attributeIndexCount > 1) {
									
									StringBuilder stringBuilder = new StringBuilder();

									for(int attributeIndex = 0; attributeIndex < attributeIndexCount; attributeIndex++) {
										
										stringBuilder.append(Double.toString(sysObject.getRepeatingDouble(mapKey, attributeIndex)));
										
										if(attributeIndex < attributeIndexCount-1) {
											
											stringBuilder.append(",");
											
										}
										
									}
									
									xmlMetadata.put(mapValue, stringBuilder.toString());
									
								}else {
									
									String attributeValue = Double.toString(sysObject.getDouble(mapKey));
									
									xmlMetadata.put(mapValue, attributeValue);
									
								}
								
							}else {

								String attributeValue = Double.toString(sysObject.getDouble(mapKey));
								
								xmlMetadata.put(mapValue, attributeValue);
								
							}
							
						}else {

							IDfAttr idfAttr = sysObject.getAttr(sysObject.findAttrIndex(mapKey));
							
							if(idfAttr.isRepeating()) {
								
								xmlMetadata.put(mapValue, sysObject.getAllRepeatingStrings(mapKey, ","));
								
							}else {
								
								xmlMetadata.put(mapValue, sysObject.getString(mapKey));
								
							}
							
						}
						
					}
									
				}
				
	//		}
//			else {
//				
//				xmlMetadata = null;
//				
//				System.out.println("This Object type details are not provided in input excel");
//				
//			}
			
						
		} catch (DfException e) {
			
			e.printStackTrace();
			
		}
		
		return xmlMetadata;
		
	}
    
    public void createTableIfRequiredAndInsertData(IDfSession session,  String versionId,String objectId, String folderNodeId, String documentNodeId,
			String versionInDocumentum, String versionInAlfresco, String updateMetadataResponse ) {
		
//		if(!isTableCreated) {
//			IDfQuery createQuery = new DfQuery();
//			
//			createQuery.setDQL("REGISTER TABLE "+tableName+" (version_object_id INT, parent_object_id INT,alfresco_folder_node_id INT, alfresco_document_node_id INT, version_in_documentum INT, version_in_alfrasco INT, update_properties_detailes CHAR (50))");
//			
//			try{
//				createQuery.execute(session, 0);
//			}
//			catch(Exception e) {
//				e.printStackTrace();
//			}
//		}
		
		IDfQuery insertQuery =new DfQuery();
		
		insertQuery.setDQL("INSERT INTO migratinTable (version_object_id, parent_object_id ,alfresco_folder_node_id, alfresco_document_node_id, version_in_documentum, version_in_alfrasco, update_properties_detailes) "
				+ "values('"+versionId+"','"+ objectId+"','"+ folderNodeId+"','"+ documentNodeId+"','"+ versionInDocumentum+"','"+ versionInAlfresco+"','"+updateMetadataResponse+"' )");
		
		try {
			
			insertQuery.execute(session, 0);
		} catch (DfException e) {
			
			e.printStackTrace();
		}
	}
    
    public String getObjectIdByAncestorId(IDfSession session, String ancestorId) {
    	
    	IDfQuery objectId =new DfQuery();
    	
    	String rObjectId =null;
    	
    	// String rVersionLabel = null;
    	    	
    	objectId.setDQL("SELECT r_object_id FROM dm_document  (all ) WHERE i_antecedent_id='"+ancestorId+"'");
    	
    	// Map <String, String  >result = new HashMap<String, String>();
    	
    	IDfCollection  collection =null;
    	try {
    		
			collection = objectId.execute(session, 0);
			
			rObjectId = collection.getString("r_object_id");
			
//			rVersionLabel = collection.getString("r_version_label"); // remove
//			
//			if((rObjectId!=null)&&(rVersionLabel!=null)&&(!"".equals(rObjectId))&&(!"".equals(rVersionLabel))){
//				
//				result.put("rObjectId", rObjectId);
//				
//				result.put("rVersionLabel", rVersionLabel  ); // remove
//				
//				result.put("isValid", "valid");			
//				
//			}
						
		} catch (DfException e) {
			
			// result.put("isValid", "notValid");	
			
			e.printStackTrace();
			
		}
    	
    	return rObjectId;
    	
    	
    }
    
   

}
