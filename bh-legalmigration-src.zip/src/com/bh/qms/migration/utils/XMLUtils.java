package com.bh.qms.migration.utils;

import java.io.FileOutputStream;
import java.io.StringWriter;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class XMLUtils {
	
	public Element createElementsWithMap(Map<String, String> attributesMap, String newElementName, String attributeName,
			Element parentElement, Document document) {
		
		for(Map.Entry<String, String> mapEntry : attributesMap.entrySet()) {
			
			Element element = document.createElement(newElementName);
			
			element.setAttribute(attributeName, mapEntry.getKey());
			
			element.appendChild(document.createTextNode(mapEntry.getValue()));
			
			parentElement.appendChild(element);
			
		}
		
		return parentElement;
		
	}
	
	public String saveXml(Map<String, String> attributesMap, String filePath) {
		
		/*attributesMap = new HashMap<String, String>();
		
		attributesMap.put("test1","testValue1");
		
		attributesMap.put("test2","testValue2");*/
		
		StringWriter stringWriter = new StringWriter();
		
		String xmlCreationStatus = "started";
		
		Document document;
		
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		
		try {
			
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			
			document = documentBuilder.newDocument();
			
			Element propertiesElement = document.createElement("properties");
			
			if(attributesMap != null) {
				
				propertiesElement = createElementsWithMap(attributesMap, "entry", "key", propertiesElement, document);
				
			}else {
				
				xmlCreationStatus = "success : : metadata map null";
				
			}
			
			document.appendChild(propertiesElement);
			
			Transformer xmlTransformer = TransformerFactory.newInstance().newTransformer();
			
			xmlTransformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "http://java.sun.com/dtd/properties.dtd");
			
			xmlTransformer.transform(new DOMSource(document), new StreamResult(new FileOutputStream(filePath)));
			
			xmlTransformer.transform(new DOMSource(document), new StreamResult(stringWriter));
			
			if(xmlCreationStatus.equalsIgnoreCase("started")) {
				
				xmlCreationStatus = "success : : : : "+stringWriter.toString();
				
			}
			
		} catch (Exception e) {
			
			xmlCreationStatus = "failure : : "+e.getMessage();
			
			e.printStackTrace();
			
		}
		
		return xmlCreationStatus;
		
	}

}
