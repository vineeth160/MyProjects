package com.bh.qms.migration.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigUtil {
	
	private static Properties configMap;

	public static Properties getConfigMap(String filePath) {
		
		File propertiesFile = new File(filePath);
		
		InputStream inputStream = null;
		
		try {
			
			inputStream = new FileInputStream(propertiesFile);
			
			configMap = new Properties();
			
			configMap.load(inputStream);
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}
		
		return configMap;
		
	}

	public static void setConfigMap(Properties configMap) {
			
		ConfigUtil.configMap = configMap;
		
	}
	

	public static void main(String[] args) {
		
		getConfigMap(args[0]);
		
	}

}
