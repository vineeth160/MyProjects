package com.bh.qms.migration.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.swing.text.StyledEditorKit.BoldAction;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;

public class ExcelUtils {
	
	public String getStringCellValueForGivenIndex(Row row, int cellIndex) {
		
		String cellValue = null;
		
		Cell cell = row.getCell(cellIndex);
		
		if(cell != null) {
			
			if(cell.getCellType() == Cell.CELL_TYPE_STRING) {
				
				cellValue = cell.getStringCellValue();
				
				if(cellValue != null) {
					
					cellValue = cellValue.trim();
					
				}
				
			}else {
				
				cell.setCellType(Cell.CELL_TYPE_STRING);
				
				cellValue = cell.getStringCellValue();
				
                if(cellValue != null) {
					
					cellValue = cellValue.trim();
					
				}
				
			}
			
		}
		
		return cellValue;
		
	}
	
	public Map<String, String> readExcelSheetAndReturnMapWithTwoColumns(String inputExcelPath, int sheetIndex) {
		
		Map<String, String> mapValues = new HashMap<String, String>();
		
		XSSFWorkbook workBook = null;
		
		try {
			
			workBook = new XSSFWorkbook(new FileInputStream(new File(inputExcelPath)));
			
			Sheet sheet = workBook.getSheetAt(sheetIndex);
			
			for(int rowIndex = 1; rowIndex < sheet.getPhysicalNumberOfRows(); rowIndex++) {
				
				Row row = sheet.getRow(rowIndex);
				
				mapValues.put(getStringCellValueForGivenIndex(row,0), getStringCellValueForGivenIndex(row,1));
				
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(workBook != null) {
				
				try {
					
					workBook.close();
					
				} catch (IOException e) {
					
					e.printStackTrace();
					
				}
				
			}
			
		}
		
		return mapValues;
		
	}
	
	public Map<String, Map<String, String>> readExcelSheetAndReturnMapWithThreeColumns(String inputExcelPath, int sheetIndex) {
		
		Map<String, Map<String, String>> mapValues = new HashMap<String, Map<String, String>>();
		
		XSSFWorkbook workBook = null;
		
		try {
			
			workBook = new XSSFWorkbook(new FileInputStream(new File(inputExcelPath)));
			
			Sheet sheet = workBook.getSheetAt(sheetIndex);
			
			for(int rowIndex = 1; rowIndex < sheet.getPhysicalNumberOfRows(); rowIndex++) {
				
				Row row = sheet.getRow(rowIndex);
				
				String firstIndexString = getStringCellValueForGivenIndex(row,0);
				
				if(firstIndexString != null) {
					
					if(mapValues.keySet().contains(firstIndexString)){
						
						Map<String, String> innerMap = mapValues.get(firstIndexString);
						
						innerMap.put(getStringCellValueForGivenIndex(row,1), getStringCellValueForGivenIndex(row,2));
						
						mapValues.replace(firstIndexString, mapValues.get(firstIndexString), innerMap);
						
					}else {
						
						Map<String, String> innerMap = new HashMap<String, String>();
						
						innerMap.put(getStringCellValueForGivenIndex(row,1), getStringCellValueForGivenIndex(row,2));
						
						mapValues.put(firstIndexString, innerMap);
						
					}
					
				}
			
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(workBook != null) {
				
				try {
					
					workBook.close();
					
				} catch (IOException e) {
					
					e.printStackTrace();
					
				}
				
			}
			
		}
		
		return mapValues;
		
	}
	
	
	public Map<String, Map<String, String>> readExcelSheetAndReturnMapFromColumns(String inputExcelPath, int sheetIndex) {
		
		Map<String, Map<String, String>> mapValues = new HashMap<String, Map<String, String>>();
		
		Map<Integer, String> indexHeadermap = new HashMap<Integer, String>();
		
		XSSFWorkbook workBook = null;
		
		try {
			
			workBook = new XSSFWorkbook(new FileInputStream(new File(inputExcelPath)));
			
			Sheet sheet = workBook.getSheetAt(sheetIndex);
			
			Row firstRow = sheet.getRow(0);
			
			for(int firstRowCellIndex = 0; firstRowCellIndex < firstRow.getPhysicalNumberOfCells(); firstRowCellIndex++) {
				
				indexHeadermap.put(firstRowCellIndex, getStringCellValueForGivenIndex(firstRow, firstRowCellIndex));
				
			}
			
			for(int rowIndex = 1; rowIndex < sheet.getPhysicalNumberOfRows(); rowIndex++) {
				
				Row row = sheet.getRow(rowIndex);
				
				String folderPath = null;
				
				Map<String, String> valuesMap = new HashMap<String, String>();
				
				for(int cellIndex = 0; cellIndex < firstRow.getPhysicalNumberOfCells(); cellIndex++) {
					
					if(cellIndex == 0) {
						
						folderPath = getStringCellValueForGivenIndex(row, cellIndex);
						
					}else {
						
						valuesMap.put(indexHeadermap.get(cellIndex), getStringCellValueForGivenIndex(row, cellIndex));
						
					}
					
				}
				
				mapValues.put(folderPath, valuesMap);
			
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(workBook != null) {
				
				try {
					
					workBook.close();
					
				} catch (IOException e) {
					
					e.printStackTrace();
					
				}
				
			}
			
		}
		
		return mapValues;
		
	}
	
	public void createExcel(String outputExcelPath) {
		
        XSSFWorkbook workBook = null;
        
        FileOutputStream fileOutputStream = null;
		
		try {
			
			File file = new File(outputExcelPath);
			
			fileOutputStream = new FileOutputStream(file);
			
			workBook = new XSSFWorkbook();
					
			Sheet sheet = workBook.createSheet();		
				
			Row row = sheet.createRow(0);
			
			row.createCell(0).setCellValue("object Id");
				
			workBook.write(fileOutputStream);
			
			System.out.println("Excel created Successfully");
			
		} catch (IOException | EncryptedDocumentException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(fileOutputStream != null) {
				
				try {
					
					fileOutputStream.close();
					
				} catch (IOException e) {
					
					e.printStackTrace();
					
				}
				
			}
			
			if(workBook != null) {
				
				try {
					
					workBook.close();
					
				} catch (IOException e) {
					
					e.printStackTrace();
					
				}
				
			}
			
		}
		
	}
		

	public void updateExcelforLegal(String outputExcelPath, String versionId,String objectId, String folderNodeId, String documentNodeId
			,String versionInDocumentum, String versionInalfresco, String updateResponse) {
		
        XSSFWorkbook workBook = null;
        
        FileOutputStream fileOutputStream = null;
		
		try {
			
			File file = new File(outputExcelPath);
			
			if(file.exists()) {
				
				workBook = new XSSFWorkbook(new FileInputStream(new File(outputExcelPath)));
				
			}else {
				
				workBook = new XSSFWorkbook();
				
			}
			
			int numberOfSheets = workBook.getNumberOfSheets();
			
			if(numberOfSheets >= 1) {
				
				Sheet sheet = workBook.getSheetAt(0);
				
				int rowIndex = sheet.getPhysicalNumberOfRows();
				
				Row row = sheet.createRow(rowIndex);
				
				row.createCell(0).setCellValue(versionId);
				
                row.createCell(1).setCellValue(objectId);
				
				row.createCell(2).setCellValue(folderNodeId);
				
				row.createCell(3).setCellValue(documentNodeId);
				
				row.createCell(4).setCellValue(versionInDocumentum);
				
				row.createCell(5).setCellValue(versionInalfresco);

				row.createCell(6).setCellValue(updateResponse);
				
			}else {
				
				Sheet sheet = workBook.createSheet();		
				
				Row row = sheet.createRow(0);
				
				row.createCell(0).setCellValue("Version Object Id");
				
				row.createCell(1).setCellValue("Parent Object Id");
				
				row.createCell(2).setCellValue("Alfresco Folder Id");
				
				row.createCell(3).setCellValue("Alfresco Document Id");
				
				row.createCell(4).setCellValue("Documentum Version");
				
				row.createCell(5).setCellValue("Alfresco Version");

				row.createCell(6).setCellValue("Update Response");
				
				Row firstRow = sheet.createRow(1);
				
				firstRow.createCell(0).setCellValue(versionId);
				
				firstRow.createCell(1).setCellValue(objectId);
				
				firstRow.createCell(2).setCellValue(folderNodeId);
				
				firstRow.createCell(3).setCellValue(documentNodeId);
				
				firstRow.createCell(4).setCellValue(versionInDocumentum);
				
				firstRow.createCell(5).setCellValue(versionInalfresco);

				firstRow.createCell(6).setCellValue(updateResponse);
				
			}
			
			fileOutputStream = new FileOutputStream(file);
			
			workBook.write(fileOutputStream);
			
		} catch (IOException | EncryptedDocumentException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(fileOutputStream != null) {
				
				try {
					
					fileOutputStream.close();
					
				} catch (IOException e) {
					
					e.printStackTrace();
					
				}
				
			}
			
			if(workBook != null) {
				
				try {
					
					workBook.close();
					
				} catch (IOException e) {
					
					e.printStackTrace();
					
				}
				
			}
			
		}
		
	}
	
	
	
	public void updateExcel(String outputExcelPath, String versionId,String objectId, String documentFilePath, String propertiesXMLFilePath
			,String documentDownloadStatus, String createXMLStatus) {
		
        XSSFWorkbook workBook = null;
        
        FileOutputStream fileOutputStream = null;
		
		try {
			
			File file = new File(outputExcelPath);
			
			if(file.exists()) {
				
				workBook = new XSSFWorkbook(new FileInputStream(new File(outputExcelPath)));
				
			}else {
				
				workBook = new XSSFWorkbook();
				
			}
			
			int numberOfSheets = workBook.getNumberOfSheets();
			
			if(numberOfSheets >= 1) {
				
				Sheet sheet = workBook.getSheetAt(0);
				
				int rowIndex = sheet.getPhysicalNumberOfRows();
				
				Row row = sheet.createRow(rowIndex);
				
				row.createCell(0).setCellValue(versionId);
				
                row.createCell(1).setCellValue(objectId);
				
				row.createCell(2).setCellValue(documentFilePath);
				
				row.createCell(3).setCellValue(propertiesXMLFilePath);
				
				row.createCell(4).setCellValue(documentDownloadStatus);
				
				row.createCell(5).setCellValue(createXMLStatus);
				
			}else {
				
				Sheet sheet = workBook.createSheet();		
				
				Row row = sheet.createRow(0);
				
				row.createCell(0).setCellValue("Version Object Id");
				
				row.createCell(1).setCellValue("Parent Object Id");
				
				row.createCell(2).setCellValue("Document FilePath");
				
				row.createCell(3).setCellValue("XML File Path");
				
				row.createCell(4).setCellValue("Document Download status");
				
				row.createCell(5).setCellValue("XML Creation Status");
				
				Row firstRow = sheet.createRow(1);
				
				firstRow.createCell(0).setCellValue(versionId);
				
				firstRow.createCell(1).setCellValue(objectId);
				
				firstRow.createCell(2).setCellValue(documentFilePath);
				
				firstRow.createCell(3).setCellValue(propertiesXMLFilePath);
				
				firstRow.createCell(4).setCellValue(documentDownloadStatus);
				
				firstRow.createCell(5).setCellValue(createXMLStatus);
				
			}
			
			fileOutputStream = new FileOutputStream(file);
			
			workBook.write(fileOutputStream);
			
		} catch (IOException | EncryptedDocumentException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(fileOutputStream != null) {
				
				try {
					
					fileOutputStream.close();
					
				} catch (IOException e) {
					
					e.printStackTrace();
					
				}
				
			}
			
			if(workBook != null) {
				
				try {
					
					workBook.close();
					
				} catch (IOException e) {
					
					e.printStackTrace();
					
				}
				
			}
			
		}
		
	}
	
	public void updateExcel(String outputExcelPath, String versionId,String objectId, String folderNodeId, String documentNodeId,
			String versionInDocumentum, String versionInAlfresco, String updateMetadataResponse, IDfSession session) {
		
        XSSFWorkbook workBook = null;
        
        FileOutputStream fileOutputStream = null;
       //  boolean isTableCreated=false;
		
		try {
			
			File file = new File(outputExcelPath);
			
			if(file.exists()) {
				
				workBook = new XSSFWorkbook(new FileInputStream(new File(outputExcelPath)));
				
			}else {
				
				workBook = new XSSFWorkbook();
				
			}
			
			int numberOfSheets = workBook.getNumberOfSheets();
			
			if(numberOfSheets >= 1) {
				// isTableCreated=true;
				Sheet sheet = workBook.getSheetAt(0);
				
				int rowIndex = sheet.getPhysicalNumberOfRows();
				
				Row row = sheet.createRow(rowIndex);
				
				row.createCell(0).setCellValue(versionId);
				
                row.createCell(1).setCellValue(objectId);
				
				row.createCell(2).setCellValue(folderNodeId);
				
				row.createCell(3).setCellValue(documentNodeId);
				
				row.createCell(4).setCellValue(versionInDocumentum);
				
				row.createCell(5).setCellValue(versionInAlfresco);

//				row.createCell(6).setCellValue(documentState);1
				
				row.createCell(6).setCellValue(updateMetadataResponse);

//				row.createCell(8).setCellValue(publishedFolderNodeId);
//
//				row.createCell(9).setCellValue(publishedDocumentNodeId);
//
//				row.createCell(10).setCellValue(associationStatus);
//				
//				row.createCell(11).setCellValue(copiedDocumentUpdateStatus);
//				
//				row.createCell(12).setCellValue(sourceDocumentUpdateStatus);
				
				
			}else {
				
				// isTableCreated=false;
				
				Sheet sheet = workBook.createSheet();		
				
				Row row = sheet.createRow(0);
				
				row.createCell(0).setCellValue("Version Object Id");
				
				row.createCell(1).setCellValue("Parent Object Id");
				
				row.createCell(2).setCellValue("Alfresco Folder Node Id");
				
				row.createCell(3).setCellValue("Alfresco Document Node Id");
				
				row.createCell(4).setCellValue("Version In Documentum");
				
				row.createCell(5).setCellValue("Version in Alfresco");
				
//				row.createCell(6).setCellValue("Document State");
				
				row.createCell(6).setCellValue("Update Properties Details");
				
//				row.createCell(8).setCellValue("Published Folder Node Id");
//				
//				row.createCell(9).setCellValue("Published Document Node Id");
//				
//				row.createCell(10).setCellValue("Association Response");
//				
//				row.createCell(11).setCellValue("Copied update Status");
//
//				row.createCell(12).setCellValue("Source Document update Status");
				
				Row firstRow = sheet.createRow(1);
				
				firstRow.createCell(0).setCellValue(versionId);
				
				firstRow.createCell(1).setCellValue(objectId);
				
				firstRow.createCell(2).setCellValue(folderNodeId);
				
				firstRow.createCell(3).setCellValue(documentNodeId);
				
				firstRow.createCell(4).setCellValue(versionInDocumentum);
				
				firstRow.createCell(5).setCellValue(versionInAlfresco);
				
//				firstRow.createCell(6).setCellValue(documentState);
				
				firstRow.createCell(6).setCellValue(updateMetadataResponse);

//				firstRow.createCell(8).setCellValue(publishedFolderNodeId);
//
//				firstRow.createCell(9).setCellValue(publishedDocumentNodeId);
//
//				firstRow.createCell(10).setCellValue(associationStatus);
//
//				firstRow.createCell(11).setCellValue(copiedDocumentUpdateStatus);
//
//				firstRow.createCell(12).setCellValue(sourceDocumentUpdateStatus);
				
//				
				
			}

			fileOutputStream = new FileOutputStream(file);
			
			workBook.write(fileOutputStream);
			
		} catch (IOException | EncryptedDocumentException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(fileOutputStream != null) {
				
				try {
					
					fileOutputStream.close();
					
				} catch (IOException e) {
					
					e.printStackTrace();
					
				}
				
			}
			
			if(workBook != null) {
				
				try {
					
					workBook.close();
					
				} catch (IOException e) {
					
					e.printStackTrace();
					
				}
				
			}
			
		}
		
	}
	
	
	
	public int getNumberOfSheets(String inputExcelPath) {
		
		int numberOfSheets = 0;
		
		XSSFWorkbook workBook = null;
		
		try {
			
			workBook = new XSSFWorkbook(new FileInputStream(new File(inputExcelPath)));
			
			numberOfSheets = workBook.getNumberOfSheets();
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}
		
		return numberOfSheets;
		
	}

}
