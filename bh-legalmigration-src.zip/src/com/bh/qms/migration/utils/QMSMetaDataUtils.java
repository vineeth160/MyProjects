package com.bh.qms.migration.utils;

import java.util.HashMap;
import java.util.Map;

public class QMSMetaDataUtils {
	
	public static final String productCompanyAttributeName = "productCompany";
	
	public static final String functionAttributeName = "g_function";
	
	public static final String globalBHProductCompanyName = "BH-Global";
	
	public static final String globalProductCompanyName = "BH-GE Legacy Global";
	
	public static final String ofsProductCompanyName = "BH-OFS Oilfield Services";
	
	public static final String ofeProductCompanyName = "BH-OFE Oilfield Equipment";
	
	public static final String dsProductCompanyName = "BH-DS Digital Solutions";
	
	public static final String tpsProductCompanyName = "BH-TPS Turbomachinery & Process Solutions";
	
	public static Map<String, String> getDocumentumAndAlfrescopropertiesMao() {
		
		Map<String, String> valuesMap = new HashMap<String, String>();
		
		valuesMap.put("object_name", "cm:name");
		
		valuesMap.put("title", "cm:title");
		
		valuesMap.put("r_creation_date", "cm:created");
		
		return valuesMap;
		
	}
	
	public static Map<String, String> getFunctionModificationsMao() {
		
		Map<String, String> valuesMap = new HashMap<String, String>();
		
		valuesMap.put("Environment Health & Safety", "Health, Safety & Environment");
		
		valuesMap.put("Information Technology", "Digital Technology");
		
		valuesMap.put("Logistics", "Material Management");
		
		return valuesMap;
		
	}
	
	public static Map<String, Integer> getFolderPriorityMap(){
		
        Map<String, Integer> valuesMap = new HashMap<String, Integer>();
		
		valuesMap.put("/QMS/Oil and Gas QMS/00. BHGE Level 1 Global Documents", 1);
		
		valuesMap.put("/QMS/Oil and Gas QMS/01. O&G Global QMS Documents", 2);
		
		valuesMap.put("/QMS/Oil and Gas QMS/GE QMS Documentum Reports", 3);
		
		valuesMap.put("/QMS/Oil and Gas QMS/09. O&G Global EHS", 4);
		
		valuesMap.put("/QMS/Oil and Gas QMS/11. O&G Finance", 5);
		
		valuesMap.put("/QMS/Oil and Gas QMS/12. O&G Human Resources", 6);
		
		valuesMap.put("/QMS/Oil and Gas QMS/13. O&G Legal", 7);
		
		valuesMap.put("/QMS/Oil and Gas QMS/14. O&G Logistcs", 8);
		
		valuesMap.put("/QMS/Oil and Gas QMS/15. O&G Marketing", 9);
		
		valuesMap.put("/QMS/Oil and Gas QMS/17. O&G Information Technology", 10);
		
		valuesMap.put("/QMS/Oil and Gas QMS/18. O&G Commercial Operations", 11);
		
		valuesMap.put("/QMS/Oil and Gas QMS/19. Oilfield Service", 12);
		
		valuesMap.put("/QMS/Oil and Gas QMS/05. O&G Digital Solutions", 13);
		
		valuesMap.put("/QMS/Oil and Gas QMS/08. O&G Turbomachinery & Process Solutions (TPS)", 14);
		
		valuesMap.put("/QMS/Oil and Gas QMS/10. O&G Engineering", 15);
		
		valuesMap.put("/QMS/Oil and Gas QMS/16. O&G Operations", 16);
		
		valuesMap.put("/QMS/Oil and Gas QMS/03. O&G Surface", 17);
		
		valuesMap.put("/QMS/Oil and Gas QMS/07. Oilfield Equipment", 18);
		
		valuesMap.put("/QMS/Oil and Gas QMS/02. O&G Global Quality", 19);
		
		valuesMap.put("/QMS/Oil and Gas QMS/20. Regions", 20);
		
		valuesMap.put("/QMS/Oil and Gas QMS/O&G Test Folder", 21);
		
		valuesMap.put("/QMS/Oil and Gas QMS/zFiles Archived", 21);
		
		return valuesMap;		
		
	}
	
	public static Map<String, String> getUserRoleModificationsMao() {
		
		Map<String, String> valuesMap = new HashMap<String, String>();
		
		valuesMap.put("AME Advance Materials Engineer", "Advanced Manufacturing Engineer (AME)");
		
		valuesMap.put("Calibration Specialist", "Calibration Operator");
		
		valuesMap.put("Customer Service Specialist, QMS Lead", "Customer Service Center (CSC) Manager");
		
		valuesMap.put("Design Engineer", "Design Engineer (DE)");
		
		valuesMap.put("EHS Manager", "HSE Manager");
		
		valuesMap.put("Instrument Mechanic", "Instrument Engineer");
				
		valuesMap.put("Materials Engineer", "Materials Manager");
		
		valuesMap.put("NDT Level III", "Non Destructive Test (NDT) Level III");
		
		valuesMap.put("Operations Leader", "Operations Manager");
		
		valuesMap.put("Plant Welding Engineer", "Welding Engineer");
		
		valuesMap.put("PQE", "Process Quality Engineer (PQE)");

		valuesMap.put("Project Manager", "Project Manager (PM)");

		valuesMap.put("QMS Leader", "QMS Manager");

		valuesMap.put("Quality Assurance Manager", "Quality Assurance (QA) Manager");

		valuesMap.put("Quality Control Engineer", "Quality Control (QC) Inspector/Manager");

		valuesMap.put("Repair and Rework Engineer", "Repair Engineer");

		valuesMap.put("Safety Leader", "Safety Engineer");

		valuesMap.put("Shipping Clerk", "Shipping Manager");
		
		valuesMap.put("Supplier Quality Manager", "Supplier Quality Manager (SQM)");
		
		valuesMap.put("Inspector", "Supplier Inspector");

		valuesMap.put("Quality Technical Leader", "Technical Leader");

		valuesMap.put("Tooling Specialist", "Tooling Manager");

		valuesMap.put("Training Specialist", "Training Instructor");

		valuesMap.put("Welding Specialist", "Welding Engineer");

		valuesMap.put("Shipping Clerk", "Shipping Manager");
		
		return valuesMap;
		
	}

}
