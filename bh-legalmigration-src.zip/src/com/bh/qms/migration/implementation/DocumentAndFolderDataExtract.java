package com.bh.qms.migration.implementation;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.bh.qms.migration.constants.ConfigurationConstants;
import com.bh.qms.migration.constants.QMSRepoConstants;
import com.bh.qms.migration.utils.DFCUtils;
import com.bh.qms.migration.utils.XMLUtils;
import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.fc.tools.RegistryPasswordUtils;

public class DocumentAndFolderDataExtract {
	
	private static IDfSessionManager sessionMgr =null;
	
	private static IDfSession session = null;
	
	private DFCUtils dfcUtils;
	
	@SuppressWarnings("unused")
	private XMLUtils xmlUtils;
	
	public DocumentAndFolderDataExtract() {
		
		dfcUtils = new DFCUtils();
		
		xmlUtils = new XMLUtils();
		
	}
	
    public static IDfSession getDfSession(String docbaseName,String userName,String password) throws DfException{
		
		IDfClientX clientx = new DfClientX();
		
		IDfLoginInfo loginInfo= clientx.getLoginInfo();
		
		loginInfo.setUser(userName);
		
		loginInfo.setPassword(RegistryPasswordUtils.decrypt(password));
		    
		IDfClient client;
		
		try {
			
			client = clientx.getLocalClient();
			
			sessionMgr = client.newSessionManager();
			
			sessionMgr.setIdentity(docbaseName,loginInfo);
			
			session = sessionMgr.getSession(docbaseName);
			
			if(session != null) {
				
				System.out.println("Documentum Session Created Successfully");
				
			}
			
		} catch (DfException e) {
			
			System.err.println("Error while creating a Documentum Session : : ");
			
			e.printStackTrace();
			
		}   
		
		return session;
			
	}
    
	public static void releaseSession() {
		
		if(session != null) {
			
			sessionMgr.release(session);
			
			System.out.println("Documentum Session Release Successfully : : ");
			
		}
		
	}

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {
		
		List<String> objectIdsList;
		
		DocumentAndFolderDataExtract dfdObject = new DocumentAndFolderDataExtract();
		
		XSSFWorkbook wb = new XSSFWorkbook();
		
		Sheet sheet = wb.createSheet("BH Data");
		
		Row headerrow = sheet.createRow(0);
		
		headerrow.createCell(0).setCellValue("r_object_id");
		
		headerrow.createCell(1).setCellValue("Folder Path");
		
        try {
			
			getDfSession(ConfigurationConstants.DOCBASE_NAME, ConfigurationConstants.DOCBASE_USER_NAME, "");
			
			if(session != null) {

				objectIdsList = dfdObject.dfcUtils.getObjectIdListForGivenTypeAndInFolder(session, QMSRepoConstants.OG_OBJECT_TYPE, 
						QMSRepoConstants.OIL_AND_GAS_FOLDER_PATH);
				
				System.out.println("Object List soze : : : "+objectIdsList.size());
				
				int index = 1;
				
				for(String objectId : objectIdsList) {
					
					StringBuilder sb = new StringBuilder();
					
					Row row = sheet.createRow(index++);
					
					row.createCell(0).setCellValue(objectId);
					
					IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(objectId));
					
					int numberOfFolderIds = sysObject.getValueCount("i_folder_id");
					
					for(int folderIdIndex = 0; folderIdIndex < numberOfFolderIds; folderIdIndex++) {
						
						String folderId = sysObject.getString("i_folder_id");
						
						IDfSysObject folderObject = (IDfSysObject) session.getObject(new DfId(folderId));
						
						sb.append(folderObject.getAllRepeatingStrings("r_folder_path", "|"));
						
						if(folderIdIndex < numberOfFolderIds-1) {
							
							sb.append("|");
							
						}
						
					}
					
					row.createCell(1).setCellValue(sb.toString());
					
					System.out.println("Completed Rows : : : "+index);
					
				}
				
			}else {
				
				System.out.println("Documentum Session is null : : : ");
				
			}
			
		}catch(Exception e) {
			
			System.err.println("Error In Main() Method : : : ");
			
			e.printStackTrace();
			
		}finally {
			
			releaseSession();
			
		}
        
		FileOutputStream out_file= new FileOutputStream(new File("D:\\GEGDC\\KR427812\\EDMS Daily Tickets Reports\\BH Data.xlsx"));
		
		wb.write(out_file);
		
		out_file.close();

	}

}
