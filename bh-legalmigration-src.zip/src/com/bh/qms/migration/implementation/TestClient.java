package com.bh.qms.migration.implementation;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.ProxyClient;

public class TestClient {

	public static void main(String[] args) throws IOException {
		
/*		OkHttpClient client = new OkHttpClient();

		MediaType mediaType = MediaType.parse("application/json");
		RequestBody body = RequestBody.create(mediaType, "{\n\"name\":\"Test_From_PostMan\",\n\"nodeType\":\"cm:folder\",\n\"relativePath\":\"Sites/my-site/documentLibrary/Test_1/Test_2\"\n}");
		Request request = new Request.Builder()
		  .url("https://bhqmsdev.alfrescocloud.com/alfresco/api/-default-/public/alfresco/versions/1/nodes/-root-?relativePath=Sites%2Fbh-qms-documents%2FdocumentLibrary")
		  .get()
		  .addHeader("authorization", "Basic YmhkZXYyOmJoZGV2Mg==")
		  .addHeader("content-type", "application/json")
		  .addHeader("cache-control", "no-cache")
		  .addHeader("postman-token", "19b0363e-90ac-de80-aa29-f1abe545c3d7")
		  .build();

		Response response = client.newCall(request).execute();*/
		
		HttpClient client = new DefaultHttpClient();
		
		HttpGet get = new HttpGet("https://bhqmsdev.alfrescocloud.com/alfresco/api/-default-/public/alfresco/versions/1/nodes/-root-?relativePath=Sites%2Fbh-qms-documents%2FdocumentLibrary");
	
		get.setHeader("authorization", "Basic YmhkZXYyOmJoZGV2Mg==");
		
		get.setHeader("content-type", "application/json");
		
		ProxyClient client1 = new ProxyClient();
		
		HttpResponse response = client.execute(get);
		
		System.out.println("Status Code : : : "+response.getStatusLine().getStatusCode());
		

	}

}
