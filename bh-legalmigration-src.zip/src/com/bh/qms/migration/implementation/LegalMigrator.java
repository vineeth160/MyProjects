package com.bh.qms.migration.implementation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import org.apache.commons.io.IOUtils;

import com.bh.qms.migration.constants.ConfigurationConstants;
import com.bh.qms.migration.constants.QMSRepoConstants;
import com.bh.qms.migration.utils.AlfrescoRestUtils;
import com.bh.qms.migration.utils.DFCUtils;
import com.bh.qms.migration.utils.ExcelUtils;
import com.bh.qms.migration.utils.XMLUtils;
import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.fc.impl.security.action.GetenvAction;
import com.documentum.fc.tools.RegistryPasswordUtils;

public class LegalMigrator {
	
	private static IDfSessionManager sessionMgr =null;
	
	private static IDfSession session = null;
	
	private DFCUtils dfcUtils;
	
	private XMLUtils xmlUtils;
	
	private ExcelUtils excelUtils;
	
	private AlfrescoRestUtils alfrescoRestUtils;
	
	private Properties properties;
	
	public LegalMigrator() {
		
		dfcUtils = new DFCUtils();
		
		xmlUtils = new XMLUtils();
		
		excelUtils = new ExcelUtils();
		
		alfrescoRestUtils = new AlfrescoRestUtils();
		
	}
	
	public static IDfSession getDfSession(String docbaseName,String userName,String password) throws DfException{
		
		DfLogger.info("INFO", " In Main : : getDfSession() : : Started ", null, null);
		
		IDfClientX clientx = new DfClientX();
		
		IDfLoginInfo loginInfo= clientx.getLoginInfo();
		
		loginInfo.setUser(userName);
		
		loginInfo.setPassword(RegistryPasswordUtils.decrypt(password));
		    
		IDfClient client;
		
		try {
			
			client = clientx.getLocalClient();
			
			sessionMgr = client.newSessionManager();
			
			sessionMgr.setIdentity(docbaseName,loginInfo);
			
			session = sessionMgr.getSession(docbaseName);
			
			if(session != null) {
				
				System.out.println("Documentum Session Created Successfully");
				
				DfLogger.info("INFO", " In Main : : getDfSession() : : Documentum Session Created Successfully ", null, null);
				
			}
			
		} catch (DfException e) {
			
			System.err.println("Error while creating a Documentum Session : : ");
			
			DfLogger.error("ERROR", " In Main : : getDfSession() : : Error while creating a Documentum Session : : "+e.getMessage(), null, null);
			
			e.printStackTrace();
			
		}   
		
		DfLogger.info("INFO", " In Main : : getDfSession() : : Completed ", null, null);
		
		return session;
			
	}
	
	public static void releaseSession() {
		
		DfLogger.info("INFO", " In Main : : releaseSession() : : Started ", null, null);
		
		if(session != null) {
			
			sessionMgr.release(session);
			
			System.out.println("Documentum Session Release Successfully : : ");
			
			DfLogger.info("INFO", " In Main : : releaseSession() : : Documentum Session Release Successfully ", null, null);
			
		}
		
		DfLogger.info("INFO", " In Main : : releaseSession() : : Completed ", null, null);
		
	}
	
	public String getFinalFilePath(String filePath, String versionName) {
		
		if (versionName.contains(".0")) {
			
			int commaIndex = versionName.indexOf(".");
			
			if(commaIndex > 0) {
				
				versionName = versionName.substring(0,versionName.indexOf("."));
				
			}
			
		}
		
		filePath = filePath + ".v" + versionName;
		
		return filePath;
		
	}
	
	
    public void execute_bkp(IDfSession session, List<String> objectIdsList, Properties properties) {
		
		DfLogger.info("INFO", " In Main : : execute() : : Started ", null, null);
		
		String migrationdestinationPath = (String) properties.get("migrationfolderpath");
		
		String inputExcelFilePath = (String) properties.get("inputexcelfilepath");
		
		String outputFilePath = "D:\\gegdc\\KR427812\\WIP\\AlfrescoUpload\\outputfiles\\";
		
		File file = new File(outputFilePath);
		
		if(!file.exists()) {
			
			file.mkdirs();
			
		}
		
		String outputExcelFilePath = outputFilePath + "MigrationOutputFile.xlsx";
		
		File excelFile = new File(outputExcelFilePath);
		
		if(excelFile.exists()) {
			
			String excelFileName = excelFile.getName();
			
			if(excelFileName != null) {
				
				if(excelFileName.contains(".")) {
					
					String extension = excelFileName.substring(excelFileName.lastIndexOf("."));
					
					String name = excelFileName.substring(0,excelFileName.lastIndexOf("."));
					
					outputExcelFilePath = dfcUtils.findFileName(outputFilePath, name, extension).toString();
					
				}
								
			}
			
		}
		
		int numberOfSheets = excelUtils.getNumberOfSheets(inputExcelFilePath);
		
		Map<String, Map<String, String>> folderPathPropertyMap = null;
		
		Map<String, Map<String, String>> objectIdPropertyMap = null;
		
		Map<String, String> typeMap = excelUtils.readExcelSheetAndReturnMapWithTwoColumns(
				inputExcelFilePath, 0);
		
		Map<String, Map<String, String>> propertyMap = excelUtils.readExcelSheetAndReturnMapWithThreeColumns(
				inputExcelFilePath, 1);
		
		Map<String, Map<String, String>> propertyValueMap = excelUtils.readExcelSheetAndReturnMapWithThreeColumns(
				inputExcelFilePath, 2);
		
		if(numberOfSheets > 3) {
			
			folderPathPropertyMap = excelUtils.readExcelSheetAndReturnMapFromColumns(inputExcelFilePath, 3);
			
		}
		
        if(numberOfSheets > 4) {
			
        	objectIdPropertyMap = excelUtils.readExcelSheetAndReturnMapFromColumns(inputExcelFilePath, 4);
			
		}
		
		for(String objectId : objectIdsList) {
			
			DfLogger.info("INFO", " In Main : : execute() : :  Object id : : "+objectId, null, null);
			
			IDfSysObject sysObject;
			
			if(objectId != null) {
				
				try {
					
					sysObject = (IDfSysObject) session.getObject(new DfId(objectId));
					
					if(sysObject != null) {
						
						String productCompanyName = null;
						
						List<String> versionIdList = dfcUtils.getAllVersions(session, sysObject, QMSRepoConstants.OG_OBJECT_TYPE);
						
						//TreeMap<String, String> versionNameAndIdMap = dfcUtils.getVersionAndObjectIdMap(session, versionIdList);
						
						/*for(Map.Entry<String, String> mapEntry : versionNameAndIdMap.entrySet()) {
							
							System.out.println("version Name : : ###### : "+mapEntry.getKey());
							
							System.out.println("version Id : : ###### : "+mapEntry.getValue());
							
						}*/
						
						String ObjectIdValues = String.join(",", versionIdList);
						
						String folderPath = dfcUtils.getFolderPath(session, sysObject, null);
						
						Map<String, String> metadataMap = dfcUtils.extractProductCompanyMetadataMap(session, sysObject, folderPath, folderPathPropertyMap, propertyMap);
						
						if(objectIdPropertyMap != null) {
							
							metadataMap = dfcUtils.updateValuesAsPerObjectId(session, sysObject, objectIdPropertyMap, propertyMap, versionIdList, metadataMap);
							
						}
						
						String parentVersionLabel = dfcUtils.getVersionLabel(objectId, session, sysObject);
						
						System.out.println("FolderPath : : : "+folderPath);
						
						DfLogger.info("INFO", " In Main : : execute() : :  Version Label : : "+parentVersionLabel, null, null);
						
						DfLogger.info("INFO", " In Main : : execute() : :  Version Count : : "+versionIdList.size(), null, null);
						
						for(String versionId : versionIdList) {
							
							IDfSysObject versionSysObject = (IDfSysObject) session.getObject(new DfId(versionId));
							
							if(versionSysObject != null) {
								
							//	Map<String, String> xmlMetadata = dfcUtils.extractNewMetadataMap(session, versionSysObject, objectId, typeMap, propertyMap, propertyValueMap);
								Map<String, String> xmlMetadata=null;
								xmlMetadata = dfcUtils.consolidateMetadataMap(metadataMap, xmlMetadata);
								
								if(xmlMetadata != null) {
									
									productCompanyName = xmlMetadata.get("bh:bh_product_company");
									
									if(productCompanyName != null) {
										
										String versionName = dfcUtils.getVersionName(versionId, session);
										
										String versionLabel = dfcUtils.getVersionLabel(versionId, session, versionSysObject);
										
										String finalDestinationPath = dfcUtils.generateFullFolderPath(migrationdestinationPath, productCompanyName, parentVersionLabel);
										
										xmlMetadata.put("bh:bh_document_state", versionLabel);
										
										xmlMetadata.put("bh:bh_dctm_object_id", ObjectIdValues);
										
										String documentFilePath = dfcUtils.getFilePath(session, versionSysObject, finalDestinationPath);
										
										String propertiesXMLFilePath = documentFilePath+".metadata.properties.xml";
										
										documentFilePath = getFinalFilePath(documentFilePath, versionName);
										
										DfLogger.info("INFO", " In Main : : execute() : :  documentFilePath : : "+documentFilePath, null, null);
										
										propertiesXMLFilePath = getFinalFilePath(propertiesXMLFilePath, versionName);
										
										DfLogger.info("INFO", " In Main : : execute() : :  propertiesXMLFilePath : : "+propertiesXMLFilePath, null, null);
										
										String documentDownloadStatus = dfcUtils.downloadDocumentContent(session, versionSysObject, versionId, documentFilePath, false);
										
										String createXMLStatus = xmlUtils.saveXml(xmlMetadata, propertiesXMLFilePath);
										
										System.out.println("Document Creation Status : : : "+documentDownloadStatus);
										
										DfLogger.info("INFO", " In Main : : execute() : :  Document Creation Status : : "+documentDownloadStatus, null, null);
										
										System.out.println("XML Creation Status : : : : "+createXMLStatus);
										
										DfLogger.info("INFO", " In Main : : execute() : : XML Creation Status  : : "+createXMLStatus, null, null);
										
										excelUtils.updateExcel(outputExcelFilePath, versionId, objectId, documentFilePath, propertiesXMLFilePath, documentDownloadStatus, 
												createXMLStatus);
										
									}else {
										
										DfLogger.error("ERROR", " In Main : : execute() : : productCompanyName is null ", null, null);
										
										excelUtils.updateExcel(outputExcelFilePath, versionId, objectId, null, null, "productCompany is null", 
												"productCompany is null");
										
									}
									
								}else {
									
									excelUtils.updateExcel(outputExcelFilePath, versionId, objectId, null, null, "xmlMetadata is null", 
											"xmlMetadata is null");
									
									DfLogger.info("INFO", " In Main : : execute() : : xmlMetadata is null ", null, null);
									
								}
								
							}
							
							if(sysObject.hasPermission("write", "dmadmin")) {
								
								sysObject.setString("g_test", "Pulled");
								
								sysObject.save();
								
							}else {
								
								DfLogger.error("ERROR", " In Main : : execute() : : User don't have permissions to update : : ", null, null);
								
							}
							
						}
						
					}
					
				} catch (DfException e) {
					
					excelUtils.updateExcel(outputExcelFilePath, "in error", objectId, null, null, e.getMessage(), 
							e.getMessage());
					
					DfLogger.error("ERROR", " In Main : : execute() : : Error in executing : :  "+e.getMessage(), null, null);
					
					e.printStackTrace();
					
				}
				
			}else {
				
				System.out.println("Given ObjectId is null");
				
				DfLogger.info("INFO", " In Main : : execute() : :  Given ObjectId is null ", null, null);
				
			}
			
		}
		
		DfLogger.info("INFO", " In Main : : execute() : : Completed ", null, null);
		
	}
    
    
    public String getDocumentPC(List<String> versionIdList, Map<String, String> tpsDocuemntList) {
    	
    	String strDocumentPC = null;
    	
    	for(String versionId : versionIdList) {
    		
    		String tpsValue = tpsDocuemntList.get(versionId);
    		
    		if(tpsValue != null) {
        			
        			strDocumentPC = tpsValue;
    			
    		}
    		
    	}
    	
    	return strDocumentPC;
    	
    }
    
    public String getPublishedVersion(TreeMap<String, String> versionAndObjectIdMap, IDfSession session) throws DfException {
    	
    	String publishedObjectId = null;

		for(Map.Entry<String, String> mapEntry : versionAndObjectIdMap.entrySet()) {
			
			String mapKey = mapEntry.getKey();
			
			String mapValue = mapEntry.getValue();
			
			IDfSysObject sysObject = (IDfSysObject) session.getObject(new DfId(mapValue));
			
			String versionLabel = dfcUtils.getVersionLabel(mapValue, session, sysObject);
			
			if(versionLabel != null) {
				
				if(versionLabel.equalsIgnoreCase("Published")) {
					
					publishedObjectId = mapValue;
					
					return publishedObjectId;
					
				}
				
			}
			
		}
		
		return publishedObjectId;
    	
    }
	
	
	public void execute(IDfSession session, List<String> objectIdsList, Properties properties) {
		
		DfLogger.info("INFO", " In Main : : execute() : : Started ", null, null);
		
		//Instant FirstStepStartInstance = Instant.now();
		
		String migrationdestinationPath = (String) properties.get("migrationfolderpath");
		
		String inputExcelFilePath = (String) properties.get("inputexcelfilepath");
		
		String outputFilePath = (String) properties.get("outputFilePath");
		
		File file = new File(outputFilePath);
		
		if(!file.exists()) {
			
			file.mkdirs();
			
		}
		
		String outputExcelFilePath = outputFilePath + "MigrationOutputFile.xlsx";
		
		File excelFile = new File(outputExcelFilePath);
		
		if(excelFile.exists()) {
			
			String excelFileName = excelFile.getName();
			
			if(excelFileName != null) {
				
				if(excelFileName.contains(".")) {
					
					String extension = excelFileName.substring(excelFileName.lastIndexOf("."));
					
					String name = excelFileName.substring(0,excelFileName.lastIndexOf("."));
					
					outputExcelFilePath = dfcUtils.findFileName(outputFilePath, name, extension).toString();
					
				}
								
			}
			
		}
		
		// int numberOfSheets = excelUtils.getNumberOfSheets(inputExcelFilePath);
		
//		Map<String, String> typeMap = excelUtils.readExcelSheetAndReturnMapWithTwoColumns(
//				inputExcelFilePath, 0);
		
		Map<String, String> propertyMap = excelUtils.readExcelSheetAndReturnMapWithTwoColumns(
				inputExcelFilePath, 0);
		
//		Map<String, Map<String, String>> propertyValueMap = excelUtils.readExcelSheetAndReturnMapWithThreeColumns(
//				inputExcelFilePath, 2);
		
		for(String objectId : objectIdsList) {
			
			DfLogger.info("INFO", " In Main : : execute() : :  Object id : : "+objectId, null, null);
			
			IDfSysObject sysObject;
			
			if(objectId != null) {
				
				try {
					
					sysObject = (IDfSysObject) session.getObject(new DfId(objectId));
					
					if(sysObject != null) {
						
						List<String> versionIdList = dfcUtils.getAllVersions(session, sysObject, "dm_document");
						
						//TreeMap<String, String> versionNameAndIdMap = dfcUtils.getVersionAndObjectIdMap(session, versionIdList);
						
						String ObjectIdValues = String.join(",", versionIdList);
						
						List<String> folderPathList = dfcUtils.getFolderPath(session, sysObject);
						
						//String parentVersionLabel = dfcUtils.getVersionLabel(objectId, session, sysObject);
						
						//DfLogger.info("INFO", " In Main : : execute() : :  Version Label : : "+parentVersionLabel, null, null);
						
						DfLogger.info("INFO", " In Main : : execute() : :  Version Count : : "+versionIdList.size(), null, null);
						
						String documentNodeId = null;
						
						String updateResponse = null;
						
						String alfrescoVersionLabel = null;
						
						String objectIdRef =  sysObject.getString("i_chronicle_id");
						
						String iAncestorId = objectIdRef;
						
						String version;
						
						Map<String ,String> objectIdAndVersion=null;
						
						boolean isValid=false;
						
						int objectCount=0;
						
//						for(Map.Entry<String, String> mapEntry : versionNameAndIdMap.entrySet()) {
						
						do{	
							
							IDfSysObject versionSysObject = (IDfSysObject) session.getObject(new DfId(objectIdRef));
							
							 version = dfcUtils.getVersionName(objectIdRef, session);
							
							if(versionSysObject != null) {
								
								Map<String, String> xmlMetadata = dfcUtils.extractNewMetadataMap(session, versionSysObject, objectId, "bhlegal:document", propertyMap);
								
								if(xmlMetadata != null) {
									
									xmlMetadata.put("bhlegal:og_legal_entity", "Nuovo Pignone");

									xmlMetadata.put("bhlegal:og_legal_entity", "og_copy_type");

									xmlMetadata.put("bhlegal:dctm_object_id", ObjectIdValues);
									
									//String versionLabel = dfcUtils.getVersionLabel(mapEntry.getValue(), session, versionSysObject);
									
									int folderIndex = 0;
									
									for(String folderPath : folderPathList) {

										String folderNodeId = alfrescoRestUtils.generateFolderPath(folderPath);
																				
										String uniqueName = alfrescoRestUtils.getUniqueName(folderNodeId, xmlMetadata.get("cm:name"));
										
										if(uniqueName != null && !"".equalsIgnoreCase(uniqueName)) {
											
											if(xmlMetadata.containsKey("cm:name")) {
												
												xmlMetadata.replace("cm:name", xmlMetadata.get("cm:name"), uniqueName);
												
											}
											
										}
										
										
										if(folderIndex > 0) {
											
											String linkedNodeId = "Link : "+alfrescoRestUtils.linkDocument(folderNodeId, documentNodeId, xmlMetadata.get("cm:name"));
											
											excelUtils.updateExcelforLegal(outputExcelFilePath, iAncestorId, objectId, folderNodeId, linkedNodeId, version, "linkedDoc", null);
											
											dfcUtils.insertRow(session, iAncestorId, objectId, folderNodeId, linkedNodeId, version, "linkedDoc", null);
											
											continue;
											
										}
										
										byte[] bytes;
										
										try {
											
											if(version.equalsIgnoreCase("1.0")) {
												
												bytes = IOUtils.toByteArray(versionSysObject.getContent());
																								
												alfrescoVersionLabel = "1.0";
												
												documentNodeId = alfrescoRestUtils.createDocument(bytes, versionSysObject.getContentType(), xmlMetadata, folderNodeId);
												
												updateResponse = alfrescoRestUtils.updateNode(documentNodeId, xmlMetadata);
												
												excelUtils.updateExcelforLegal(outputExcelFilePath, iAncestorId, objectId, folderNodeId, documentNodeId, version,
														"1.0", updateResponse);

												dfcUtils.insertRow(session, iAncestorId, objectId, folderNodeId, documentNodeId, version,
														"1.0", updateResponse);
												
											}else {
												
												if(documentNodeId != null) {
													
													boolean isMajorVersion = false;
													
													if(version.toString().contains(".0")) {
														
														isMajorVersion = true;
														
													}
													
													alfrescoVersionLabel = alfrescoRestUtils.updateDocumentContent(documentNodeId, versionSysObject.getContent(),isMajorVersion);
													
													updateResponse = alfrescoRestUtils.updateNode(documentNodeId, xmlMetadata);

													excelUtils.updateExcelforLegal(outputExcelFilePath, iAncestorId, objectId, folderNodeId, documentNodeId, version,
															alfrescoVersionLabel, updateResponse);
													
													dfcUtils.insertRow(session, iAncestorId, objectId, folderNodeId, documentNodeId, version,
															alfrescoVersionLabel, updateResponse);
														
												}
												
											}
											
										} catch (IOException e) {

											excelUtils.updateExcelforLegal(outputExcelFilePath, iAncestorId, objectId, folderNodeId, documentNodeId, version,
													alfrescoVersionLabel, e.getMessage());

											dfcUtils.insertRow(session, iAncestorId, objectId, folderNodeId, documentNodeId, version,
													alfrescoVersionLabel, e.getMessage());
											
											e.printStackTrace();
											
										}
										
										folderIndex++;
										
									}
									
								}else {
									
									DfLogger.info("INFO", " In Main : : execute() : : xmlMetadata is null ", null, null);

									excelUtils.updateExcelforLegal(outputExcelFilePath, iAncestorId, objectId, null, documentNodeId, version,
											alfrescoVersionLabel, "XML Metadata is null");
									

									dfcUtils.insertRow(session, iAncestorId, objectId, null, documentNodeId, version,
											alfrescoVersionLabel, "XML Metadata is null");
									
								}
								
								objectIdRef = dfcUtils.getObjectIdByAncestorId(session, iAncestorId);
								
								iAncestorId = objectIdRef;
								
								objectCount++;
								
//								if("valid".equals(objectIdAndVersion.get("isValid"))) {
//									
//									iAncestorId = objectIdAndVersion.get("rObjectId");
//									
//									objectIdRef = iAncestorId;
//														
//									isValid=true;
//									
//									objectCount++;
//									
//								}
//								else {
//									isValid =false;
//								}
								
							}
							
						}while((objectIdRef!=null)&&(!"".equals(objectIdRef))&&objectCount<30);
						
					}
					
				} catch (Exception e) {

					excelUtils.updateExcelforLegal(outputExcelFilePath, null, objectId, null, null, null,
							null, e.getMessage());
					

					dfcUtils.insertRow(session, null, objectId, null, null, null,
							null, e.getMessage());
					
					DfLogger.error("ERROR", " In Main : : execute() : : Error in executing : :  "+e.getMessage(), null, null);
					
					e.printStackTrace();
					
				}
				
			}else {
				
				System.out.println("Given ObjectId is null");
				
				DfLogger.info("INFO", " In Main : : execute() : :  Given ObjectId is null ", null, null);
				
			}
			
		}
		
		DfLogger.info("INFO", " In Main : : execute() : : Completed ", null, null);
		
	}
	
	public void readPropertiesFile(String filePath) {
		
		DfLogger.info("INFO", " In Main : : readPropertiesFile() : : Started ", null, null);
		
		File propertiesFile = new File(filePath);
		
		InputStream inputStream = null;
		
		if(propertiesFile.exists()) {
			
			try {
				
				inputStream = new FileInputStream(propertiesFile);
				
				properties = new Properties();
				
				properties.load(inputStream);
				
			} catch (IOException e) {
				
				DfLogger.error("INFO", " In Main : : readPropertiesFile() : : Error while reading properties file : : "+e.getMessage(), null, null);
				
				e.printStackTrace();
				
			}
			
		}else {
			
			DfLogger.info("INFO", " In Main : : readPropertiesFile() : : Please provide valid properties file ", null, null);
			
			System.out.println("Please provide valid properties file");
			
		}
		
		DfLogger.info("INFO", " In Main : : readPropertiesFile() : : Completed ", null, null);
			
	}
	
	public boolean validateInput(Properties properties) {
		
		DfLogger.info("INFO", " In Main : : validateInput() : : Started ", null, null);
		
		boolean isValidRequest = false;
		
		String migrationFolderPath = (String) properties.get("migrationfolderpath");

		String inputExcelFilePath = (String) properties.get("inputexcelfilepath");

		String environment = (String) properties.get("environment");
		
		DfLogger.info("INFO", " In Main : : validateInput() : : environment : : "+environment, null, null);
		
		DfLogger.info("INFO", " In Main : : validateInput() : : inputExcelFilePath : : "+inputExcelFilePath, null, null);
		
		DfLogger.info("INFO", " In Main : : validateInput() : : migrationFolderPath : : "+migrationFolderPath, null, null);		
		
		if(migrationFolderPath != null && inputExcelFilePath != null && environment != null) {
			
			File inputExcelFile = new File(inputExcelFilePath);
			
			File migrationFolder = new File(migrationFolderPath);
			
			if(environment.equalsIgnoreCase("production") || environment.equalsIgnoreCase("qa")) {
				
				if(inputExcelFile.exists()) {
					
					if(excelUtils.getNumberOfSheets(inputExcelFilePath) >= 1) { // 3 changed to 1
						
						if(migrationFolder.exists()) {
							
							if(migrationFolder.isDirectory()) {
								
								isValidRequest = true;
								
							}
							
						}else {
							
							System.out.println("Please provide valid migrationfolderpath");
							
							DfLogger.info("ERROR", " In Main : : validateInput() : : environment details should be production or qa", null, null);
							
						}
						
					}else {
						
						System.out.println("Excel should contain 3 sheet. Please provide 3 sheet Excel. Sheet 1 is for type mapping, sheet2 is for property mapping and sheet 3 is for property validation");
						
						DfLogger.info("ERROR", " In Main : : validateInput() : : Excel should contain 3 sheet. Please provide 3 sheet Excel. Sheet 1 is for type mapping, sheet2 is for property mapping and sheet 3 is for property validation", null, null);
						
					}
					
				}else {
					
					System.out.println("Please provide valid inputexcelfilepath");
					
					DfLogger.info("ERROR", " In Main : : validateInput() : : Please provide valid inputexcelfilepath", null, null);
					
				}
				
			}else {
				
				System.out.println("environment details should be production or qa");
				
				DfLogger.info("ERROR", " In Main : : validateInput() : : environment details should be production or qa", null, null);
				
			}
			
		}else {
			
			System.out.println("Please provide migrationfolderpath, inputexcelfilepath and environment details in properties file");
			
			DfLogger.info("ERROR", " In Main : : validateInput() : : Please provide migrationfolderpath, inputexcelfilepath and environment details in properties file", null, null);
			
		}
		
		DfLogger.info("INFO", " In Main : : validateInput() : : Completed ", null, null);
		
		return isValidRequest;
		
	}
	
	public List<String> readInputLines(String filepath) throws Exception {
		
		List<String> list = new ArrayList<String>();
		
		InputStream fis = new FileInputStream(filepath);
		
		BufferedReader br = new BufferedReader(new InputStreamReader(fis,
				Charset.forName("UTF-8")));
		
		String line;
		
		while ((line = br.readLine()) != null) {
			
			if (!line.equals("")) {
				
				list.add(line);
				
			}
			
		}
		
		br.close();
		
		return list;
		
	}
	
	
	public static void main(String[] args) {
		
		DfLogger.info("INFO", " In Main : : Migration Started", null, null);
		
		List<String> objectIdsList;
		
		LegalMigrator migrator = new LegalMigrator();
		
		if(args[0] != null) {
			
			migrator.readPropertiesFile(args[0]);
			
			if(migrator.properties != null) {
				
				boolean isValidRequest = migrator.validateInput(migrator.properties);
				
				if(isValidRequest) {
					
					try {
						
						String environment = (String) migrator.properties.get("environment");
						
						if(environment.equalsIgnoreCase("production")) {
							
							getDfSession(ConfigurationConstants.DOCBASE_NAME, ConfigurationConstants.DOCBASE_USER_NAME, 
									ConfigurationConstants.DOCBASE_USER_PASSWORD_PROD);
							
						}else {
							
							getDfSession(ConfigurationConstants.DOCBASE_NAME, ConfigurationConstants.DOCBASE_USER_NAME, 
									ConfigurationConstants.DOCBASE_USER_PASSWORD_QA);
							
						}
						
						if(session != null) {
							
							/* objectIdsList = migrator.dfcUtils.getObjectIdListForGivenTypeAndInFolder(session, QMSRepoConstants.OG_OBJECT_TYPE, 
									QMSRepoConstants.OIL_AND_GAS_FOLDER_PATH);
							*/
							/*objectIdsList = migrator.dfcUtils.getObjectIdListForGivenTypeAndInFolder(session, QMSRepoConstants.OG_OBJECT_TYPE, 
									"/QMS/Oil and Gas QMS/05. O&G Digital Solutions");
							*/
							
							String txtFile = (String) migrator.properties.get("objectIdTextFilePath");
							
							objectIdsList = new ArrayList<String>();
							
							if(txtFile != null) {
								
								objectIdsList = migrator.readInputLines(txtFile);
								
							}
							
							//objectIdsList.add("0900f5ea80720b78");
							
							//objectIdsList.add("0900f5ea805cb735");
							
							//objectIdsList.add("0900f5ea80702653");
							
							//objectIdsList.add("0900f5ea80ac03c8");
							
							migrator.execute(session, objectIdsList, migrator.properties);
							
						}else {
							
							DfLogger.info("ERROR", " In Main : : Documentum Session is null", null, null);
							
							System.out.println("Documentum Session is null ");
							
						}
						
					}catch(Exception e) {
						
						System.err.println("Error In Main() Method : : : ");
						
						DfLogger.error("ERROR", " In Main : : Error In Main() Method"+e.getMessage(), null, null);
						
						e.printStackTrace();
						
					}finally {
						
						releaseSession();
						
					}
					
				}
				
			}else {
				
				DfLogger.info("ERROR", " In Main : : Properties Object is Null", null, null);
				
				System.out.println("Properties Object is Null");
				
			}
			
		}else {
			
			DfLogger.info("ERROR", " In Main : : Please provide properties file in an arguments", null, null);
			
			System.out.println("Please provide properties file in an arguments");
			
		}
		
		DfLogger.info("INFO", " In Main : : Migration Completed", null, null);
		
	}

}
