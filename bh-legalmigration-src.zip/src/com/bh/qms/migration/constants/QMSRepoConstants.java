package com.bh.qms.migration.constants;

public class QMSRepoConstants {
	
	public static final String OIL_AND_GAS_FOLDER_PATH = "/QMS/Oil and Gas QMS";
	
	public static final String OG_OBJECT_TYPE = "iso_document";
	
	public static final String TYPE="bhqms:iso_qty_manual";

}
