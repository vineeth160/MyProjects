package com.bh.qms.migration.constants;

public final class ConfigurationConstants {

	//public static final String DOCBASE_NAME = "GEE_Process_Control";

	public static final String DOCBASE_NAME = "Legal_Aviation";
	
	public static final String DOCBASE_USER_NAME = "dmadmin";
	
	public static final String DOCBASE_USER_PASSWORD_QA = "AAAAEES2VAAVPN3O0mcQVrGe++NLI+mglpYLg9U7rkaI0Kyx";

	public static final String DOCBASE_USER_PASSWORD_PROD = "AAAAELeplpg2VuKmhpmKOVTmNUkMJYu8Xg2tB1ViSLi3tH7x";
	
		
}
