function docPublish(bpmNode, publishType, requestType, revisionChange)
{
	//var node=args.bpmNode;
	var revisionNum = "";
	var docNode = bpmNode;
	logger.log("docNode.."+docNode);
	var len=docNode.properties.content.size;
	if(len>0)
	{
		logger.log("revisionChange :: "+revisionChange);
		logger.log("publishType-1 :: "+publishType);
		if(publishType == "Publish as Source"){
			var publishRevisionAssoc = docNode.assocs["bhqms:revision_association"];
			if(publishRevisionAssoc != undefined && publishRevisionAssoc != null && publishRevisionAssoc != "null" && publishRevisionAssoc != ""){
				var publishRevisionNode=publishRevisionAssoc[0];
					
				var isMajor = true;
				if(revisionChange.includes("Minor"))
					isMajor = false;
				
				if(revisionChange!=null && revisionChange!="" && revisionChange!="undefined" && revisionChange!="null"){
					revisionNum = revisionChange.split("-")[1];
					logger.log("revisionNum Updated :: "+revisionNum);
					if(revisionNum!="" && revisionNum!=null && revisionNum!="undefined"){
						docNode.properties["bhqms:publish_revision"]=revisionNum;
						publishRevisionNode.properties["bhqms:publish_revision"]=revisionNum;
						publishRevisionNode.save();
						publishRevisionNode = upateMetadata(docNode, publishRevisionNode);
					} else{
						docNode.properties["bhqms:publish_revision"]="1.0";
					}
					
					docNode.properties["bhqms:document_state"]="Source Published";
					docNode.save();
					var fileName = docNode.properties["cm:name"];
					if(revisionChange.includes("Same Revision")){
						publishRevisionNode.properties["cm:autoVersion"]=false;
						publishRevisionNode.save();
						sameRevisionPublish.publishAsSameRevision(bpmNode.nodeRef, publishRevisionNode.nodeRef, revisionNum, fileName);
						//upateMetadata(docNode, publishRevisionNode);
					} else{
						publishRevisionNode.properties["cm:autoVersion"]=true;
						publishRevisionNode.save();
						publishRevisionNode = publishRevisionNode.checkout();
						publishRevisionNode.properties.content.write(docNode.properties.content, true, true); 
						publishRevisionNode = publishRevisionNode.checkin("Document Published with Revision", isMajor);
					}
				}
				if(publishRevisionNode.hasAspect("bhqms:under_workflow")){
					publishRevisionNode.removeAspect("bhqms:under_workflow");
					publishRevisionNode.save();
				}
			
			} else{
				var docParentNode = docNode.parent;
				var pubNode=docParentNode.childByNamePath("Published");
				if(pubNode==null && docParentNode.hasPermission('CreateChildren'))
				{
					pubNode=docParentNode.createFolder("Published");
				}
				docNode.properties["bhqms:publish_revision"]="1.0";
				docNode.properties["bhqms:revision_type"] = "Target";
				docNode.save();
				var docCopy = docNode.copy(pubNode);
				docCopy.save();
				if(docCopy.hasAspect("bhqms:under_workflow")){
					docCopy.removeAspect("bhqms:under_workflow");
					docCopy.save();
				}
				docNode.properties["bhqms:document_state"]="Source Published";
				docNode.properties["bhqms:revision_type"] = "Source";
				docNode.save();
				docNode.createAssociation(docCopy,"bhqms:revision_association");
				docCopy.save();
			}
		}
		
		if(publishType == "Publish as PDF"){
			logger.log("publishType-3 :: "+publishType);
			var publishRevisionAssoc = docNode.assocs["bhqms:revision_association"];
			if(publishRevisionAssoc != undefined && publishRevisionAssoc != null && publishRevisionAssoc != "null" && publishRevisionAssoc != ""){
				var publishRevisionNode=publishRevisionAssoc[0];
				var isMajor = true;
				if(revisionChange.includes("Minor"))
					isMajor = false;
				
				
				if(revisionChange!=null && revisionChange!="" && revisionChange!="undefined" && revisionChange!="null"){
					revisionNum = revisionChange.split("-")[1];
					logger.log("revisionNum Updated :: "+revisionNum);
					if(revisionNum!="" && revisionNum!=null && revisionNum!="undefined"){
						docNode.properties["bhqms:publish_revision"]=revisionNum;
						publishRevisionNode.properties["bhqms:publish_revision"]=revisionNum;
						publishRevisionNode.save();
						publishRevisionNode = upateMetadata(docNode, publishRevisionNode);
					} else{
						docNode.properties["bhqms:publish_revision"]="1.0";
					}
					
					docNode.properties["bhqms:document_state"]="Source Published";
					docNode.save();
					
					var transformsDir = docNode.parent.childByNamePath("Transforms");
					if(transformsDir == null){
						transformsDir = docNode.parent.createFolder("Transforms");
					}
					var transformedNode = docNode.transformDocument("application/pdf", transformsDir);
					var fileName = docNode.properties["cm:name"];
					
					if(fileName.includes(".")){
						logger.log(fileName.lastIndexOf("."));
						logger.log(fileName.length);
						var fileExt = fileName.substring(fileName.lastIndexOf("."), fileName.length);
						logger.log("in if fileName...");
						if(!fileName.toUpperCase().endsWith(".PDF")){
							fileName = fileName.replace(fileExt, ".pdf");
							logger.log("New Filename :: "+fileName);
						}
					}
					//publishRevisionNode.properties["cm:name"]=fileName;
					//publishRevisionNode.save();
					if(revisionChange.includes("Same Revision")){
						publishRevisionNode.properties["cm:autoVersion"]=false;
						publishRevisionNode.save();
						sameRevisionPublish.publishAsSameRevision(transformedNode.nodeRef, publishRevisionNode.nodeRef, revisionNum, fileName);
						//upateMetadata(docNode, publishRevisionNode);
					} else{
						publishRevisionNode.properties["cm:autoVersion"]=true;
						publishRevisionNode.save();
						publishRevisionNode = publishRevisionNode.checkout();
						publishRevisionNode.properties.content.write(transformedNode.properties.content, true, true); 
						publishRevisionNode = publishRevisionNode.checkin("Document Published with Revision", isMajor);
					}
					//publishRevisionNode.properties["cm:name"]=fileName;
					//publishRevisionNode.save();
					transformedNode.remove();
				}
				if(publishRevisionNode.hasAspect("bhqms:under_workflow")){
					publishRevisionNode.removeAspect("bhqms:under_workflow");
					publishRevisionNode.save();
				}
				
				
			} else{
				
				var docParentNode = docNode.parent;
				var pubNode=docParentNode.childByNamePath("Published");
				if(pubNode==null && docParentNode.hasPermission('CreateChildren'))
				{
					pubNode=docParentNode.createFolder("Published");
				}
				docNode.properties["bhqms:publish_revision"]="1.0";
				docNode.properties["bhqms:revision_type"] = "Target";
				docNode.save();
				
				var transformedNode = docNode.transformDocument("application/pdf", pubNode);
				docNode.createAssociation(transformedNode,"bhqms:revision_association");
				transformedNode.save();
				
				docNode.properties["bhqms:document_state"]="Source Published";
				docNode.properties["bhqms:revision_type"] = "Source";
				docNode.save();
				
				if(transformedNode.hasAspect("bhqms:under_workflow")){
					transformedNode.removeAspect("bhqms:under_workflow");
					transformedNode.save();
				}
			}
		}
	}
}

function upateMetadata(docNode, publishRevisionNode){
	
	publishRevisionNode.properties["cm:name"] = docNode.properties["cm:name"];
	publishRevisionNode.properties["bhqms:reference"] = docNode.properties["bhqms:reference"];
	publishRevisionNode.properties["bhqms:company"] = docNode.properties["bhqms:company"];
	publishRevisionNode.properties["bhqms:product_company"] = docNode.properties["bhqms:product_company"];
	publishRevisionNode.properties["bhqms:product_line"] = docNode.properties["bhqms:product_line"];
	publishRevisionNode.properties["bhqms:sub_product_line"] = docNode.properties["bhqms:sub_product_line"];
	publishRevisionNode.properties["bhqms:site"] = docNode.properties["bhqms:site"];
	publishRevisionNode.properties["bhqms:function"] = docNode.properties["bhqms:function"];
	publishRevisionNode.properties["bhqms:sub_function"] = docNode.properties["bhqms:sub_function"];
	publishRevisionNode.properties["bhqms:document_type"] = docNode.properties["bhqms:document_type"];
	publishRevisionNode.properties["bhqms:language_code"] = docNode.properties["bhqms:language_code"];
	publishRevisionNode.properties["bhqms:process"] = docNode.properties["bhqms:process"];
	publishRevisionNode.properties["bhqms:sub_process"] = docNode.properties["bhqms:sub_process"];
	publishRevisionNode.properties["bhqms:iso_element"] = docNode.properties["bhqms:iso_element"];
	publishRevisionNode.properties["bhqms:content_category"] = docNode.properties["bhqms:content_category"];
	publishRevisionNode.properties["bhqms:document_url"] = docNode.properties["bhqms:document_url"];
	publishRevisionNode.properties["bhqms:document_state"] = "Published";
	publishRevisionNode.properties["bhqms:published_date"] = docNode.properties["bhqms:published_date"];
	publishRevisionNode.properties["bhqms:effective_date"] = docNode.properties["bhqms:effective_date"];
	publishRevisionNode.properties["bhqms:expiry_date"] = docNode.properties["bhqms:expiry_date"];
	publishRevisionNode.properties["bhqms:user_role"] = docNode.properties["bhqms:user_role"];
	publishRevisionNode.properties["bhqms:workflow_history"] = docNode.properties["bhqms:workflow_history"];
	publishRevisionNode.save();
	
	var functionalAssoc = docNode.assocs["bhqms:functional_owner"];
	var targetFunctionalAssoc = publishRevisionNode.assocs["bhqms:functional_owner"];
	logger.log("functionalAssoc[0] :: "+functionalAssoc);
	if(functionalAssoc != undefined && functionalAssoc != null && functionalAssoc != "null" && functionalAssoc != ""){
		if(targetFunctionalAssoc != undefined && targetFunctionalAssoc != null && targetFunctionalAssoc != "null" && targetFunctionalAssoc != ""){
			publishRevisionNode.removeAssociation(targetFunctionalAssoc[0], "bhqms:functional_owner");
			publishRevisionNode.save();
		}
		publishRevisionNode.createAssociation(functionalAssoc[0], "bhqms:functional_owner");
		publishRevisionNode.save();
	}
	
	var authorAssoc = docNode.assocs["bhqms:document_author"];
	var targetAuthorAssoc = publishRevisionNode.assocs["bhqms:document_author"];
	logger.log("authorAssoc[0] :: "+authorAssoc);
	if(authorAssoc != undefined && authorAssoc != null && authorAssoc != "null" && authorAssoc != ""){
		if(targetAuthorAssoc != undefined && targetAuthorAssoc != null && targetAuthorAssoc != "null" && targetAuthorAssoc != ""){
			publishRevisionNode.removeAssociation(targetAuthorAssoc[0], "bhqms:document_author");
			publishRevisionNode.save();
		}
		publishRevisionNode.createAssociation(authorAssoc[0], "bhqms:document_author");
		publishRevisionNode.save();
	}
	
	var adminAssoc = docNode.assocs["bhqms:document_admin"];
	var targetAdminAssoc = publishRevisionNode.assocs["bhqms:document_admin"];
	logger.log("adminAssoc[0] :: "+adminAssoc);
	if(adminAssoc != undefined && adminAssoc != null && adminAssoc != "null" && adminAssoc != ""){
		if(targetAdminAssoc != undefined && targetAdminAssoc != null && targetAdminAssoc != "null" && targetAdminAssoc != ""){
			publishRevisionNode.removeAssociation(targetAdminAssoc[0], "bhqms:document_admin");
			publishRevisionNode.save();
		}
		publishRevisionNode.createAssociation(adminAssoc[0], "bhqms:document_admin");
		publishRevisionNode.save();
	}
		
	var evidenceAssoc = docNode.assocs["bhqms:evidence_attachment"];
	var targetEvidenceAssoc = publishRevisionNode.assocs["bhqms:evidence_attachment"];
	logger.log("evidenceAssoc[0] :: "+evidenceAssoc);
	if(evidenceAssoc != undefined && evidenceAssoc != null && evidenceAssoc != "null" && evidenceAssoc != ""){
		if(targetEvidenceAssoc != undefined && targetEvidenceAssoc != null && targetEvidenceAssoc != "null" && targetEvidenceAssoc != ""){
			publishRevisionNode.removeAssociation(targetEvidenceAssoc[0], "bhqms:evidence_attachment");
			publishRevisionNode.save();
		}
		publishRevisionNode.createAssociation(evidenceAssoc[0], "bhqms:evidence_attachment");
		publishRevisionNode.save();
	}
	
	publishRevisionNode.properties["bhqms:revision_type"] = "Target";
	publishRevisionNode.save();
	
	return publishRevisionNode;
		
}