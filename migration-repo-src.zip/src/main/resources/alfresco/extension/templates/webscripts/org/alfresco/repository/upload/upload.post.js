function extractMetadata(file)
{
   // Extract metadata - via repository action for now.
   // This should use the MetadataExtracter API to fetch properties, allowing for possible failures.
   var emAction = actions.create("extract-metadata");
   if (emAction != null)
   {
      // Call using readOnly = false, newTransaction = false
      emAction.execute(file, false, false);
   }
}

function exitUpload(statusCode, statusMsg)
{
   status.code = statusCode;
   status.message = statusMsg;
   status.redirect = true;
}

/**
 * Creates an new filename by adding a suffix to existing one in order to avoid duplicates in folder
 * The check that folder already contains the filename should be done before calling this function
 * @param filename - existing filename
 * @param destNode - folder node
 * @returns
 * 
 * Custom upload component for Baker Hughes ALfresco Migration - $001 (5th May 2020)
 * 
 */
function createUniqueNameInFolder(filename, destNode)
{
   var counter = 1,
   tmpFilename,
   dotIndex,
   existingFile;
   do
   {
      dotIndex = filename.lastIndexOf(".");
      if (dotIndex == 0)
      {
         // File didn't have a proper 'name' instead it had just a suffix and started with a ".", create "1.txt"
         tmpFilename = counter + filename;
      }
      else if (dotIndex > 0)
      {
         // Filename contained ".", create "filename-1.txt"
         tmpFilename = filename.substring(0, dotIndex) + "-" + counter + filename.substring(dotIndex);
      }
      else
      {
         // Filename didn't contain a dot at all, create "filename-1"
         tmpFilename = filename + "-" + counter;
      }
      existingFile = destNode.childByNamePath(tmpFilename);
      counter++;
   } while (existingFile !== null);
   return tmpFilename;
}

/**
 * Determines if new filename looks like it was renamed as a result of the user's OS's duplicate file name avoidance.
 * This is particularly a problem for "Edit Offline" functionality where the user's workflow may require multiple
 * download, modification and upload cycles. See MNT-18018 for details.
 *
 * The de-duplication marker manifests itself as a " (1)" appended after the filename, before the extension.
 * @param fileName {string}
 * @param originalFileName {string}
 * @return {boolean}
 *
 * NOTE: duplicated in slingshot/source/web/components/upload/dnd-upload.js to allow client side detection too.
 */
function containsOSDeDupeMarkers(fileName, originalFileName) {
   // Components of RegEx:
   var deDupeMarker = "\\s\\([\\d]+\\)", // single space followed by one or more digits in literal brackets; e.g." (1)", " (2)", " (13)"
      fileExtension = "\\.[A-z\\d]+$"; // a single dot followed by one or more letters or numbers at end of string.  e.g. ".jpg", ".mp3", ".docx"

   // Extract file extension from originalFileName if it exists & remove from original file name.
   var regExMatch = new RegExp(fileExtension).exec(originalFileName),
      originalFileExtension = (regExMatch)? regExMatch[0] : "",
      originalFileNameWithoutExtension = (regExMatch) ? originalFileName.substr(0, regExMatch["index"]) : "";

   var combinedRegEx = new RegExp("^" + escapeRegExp(originalFileNameWithoutExtension) + deDupeMarker + escapeRegExp(originalFileExtension) + "$");

   return combinedRegEx.test(fileName);
}

/**
 * Make user input safe to pass into a RegEx
 *
 * @param string {string}
 * @return {string}
 */
function escapeRegExp(string) {
   return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function main()
{
   try
   {
      var filename = null,
         content = null,
         mimetype = null,
         siteId = null, site = null,
         containerId = null, container = null,
         destination = null,
         destNode = null,
         thumbnailNames = null,
         i;

      // Upload specific
      var uploadDirectory = null,
         createDirectory = false,
         contentType = null,
         aspects = [],
         overwrite = true; // If a filename clashes for a versionable file
		 
	// Custom Upload specific - $001
		var bhDocumentType = null;
		var bhDocumentName = null;
		var documentReference = null;
		var bhProductCompany = null;
		var bhProductLine = null;
		var bhSubPL = null;
		var bhSite = null;
		var bhFunction = null;
		var bhSubFunction = null;
		var bhLanguage = null;
		var bhISOElement = null;
		var bhUserRole = null;
		var bhProcess = null;
		var bhSubProcess = null;
		var bhContentCategory = null;
		var bhExpiry = null;
		var docAuthor = null;
		var docLibNoderef = null;
		var bhContentType = null;
		var uploadTargetNode = null;
		var evidenceParentNoderef = null;
		var isEvidence = null;
		var isLegalPackageItem = null;

		
      // Update specific
      var updateNodeRef = null,
         majorVersion = false,
         updateNameAndMimetype = false,
         description = "";
      
      // Prevents Flash- and IE8-sourced "null" values being set for those parameters where they are invalid.
      // Note: DON'T use a "!==" comparison for "null" here.
      var fnFieldValue = function(p_field)
      {
         return p_field.value.length() > 0 && p_field.value != "null" ? p_field.value : null;
      };

      // allow the locale to be set via an argument
      if (args["lang"] != null)
      {
         utils.setLocale(args["lang"]);
      }

      var uploadConfig = new XML(config.script),
          autoVersion = uploadConfig.autoVersion.toString() == "" ? null : uploadConfig.autoVersion.toString() == "true",
          autoVersionProps = uploadConfig.autoVersionProps.toString() == "" ? null : uploadConfig.autoVersionProps.toString() == "true";

      // Parse file attributes
	  for each (field in formdata.fields)
      {
		 switch (String(field.name).toLowerCase())
         {
            case "filename":
               filename = fnFieldValue(field);
			   break;
            
            case "filedata":
               if (field.isFile)
               {
                  filename = filename ? filename : field.filename;
                  content = field.content;
                  mimetype = field.mimetype;
               }
               break;

            case "siteid":
               siteId = fnFieldValue(field);
               break;

            case "containerid":
               containerId = fnFieldValue(field);
               break;

            case "destination":
               destination = fnFieldValue(field);
               break;

            case "uploaddirectory":
			   uploadDirectory = fnFieldValue(field);
               if ((uploadDirectory !== null) && (uploadDirectory.length() > 0))
               {
                  if (uploadDirectory.charAt(uploadDirectory.length() - 1) != "/")
                  {
                     uploadDirectory = uploadDirectory + "/";
                  }
                  // Remove any leading "/" from the uploadDirectory
                  if (uploadDirectory.charAt(0) == "/")
                  {
                     uploadDirectory = uploadDirectory.substr(1);
                  }
               }
			   break;
			
            case "updatenoderef":
               updateNodeRef = fnFieldValue(field);
               break;

            case "description":
               description = field.value;
               break;

            case "contenttype":
               contentType = field.value;
               break;

            case "aspects":
               aspects = field.value != "-" ? field.value.split(",") : [];
               break;

            case "majorversion":
               majorVersion = field.value == "true";
               break;

            case "overwrite":
               overwrite = field.value == "true";
               break;

            case "thumbnails":
               thumbnailNames = field.value;
               break;
               
            case "updatenameandmimetype":
               updateNameAndMimetype = field.value == "true";
               break;
            
            case "createdirectory":
               createDirectory = field.value == "true";
               break;
			  
            // Custom Upload component starts - $001
            case "doclibnoderef":
                docLibNoderef = field.value;
                break;
 			   
 			case "evidenceparentnoderef":
                evidenceParentNoderef = field.value;
                break;
 			   
 			case "isevidence":
                isEvidence = field.value;
                break;
 			
 			case "islegalpackageitem":
 				isLegalPackageItem = field.value;
                break;
 			
 			case "bhcontenttype":
                bhContentType = field.value;
                break;
 			
			case "bhdocumenttype":
				bhDocumentType = field.value;
				logger.log("bhDocumentType :: "+bhDocumentType);
				break;
			case "bhdocumentname":
				bhDocumentName = field.value;
				logger.log("bhDocumentName :: "+bhDocumentName);
				break;
			case "bhdocumentreference":
				documentReference = field.value;
				logger.log("documentReference :: "+documentReference);
				break;
				
			case "bhproductcompany":
				bhProductCompany = field.value;
				logger.log("bhProductCompany :: "+bhProductCompany);
				break;
			
			case "bhproductline":
				bhProductLine = field.value;
				logger.log("bhProductLine :: "+bhProductLine);
				break;
			
			case "bhsubpl":
				bhSubPL = field.value;
				logger.log("bhSubPL :: "+bhSubPL);
				break;
			
			case "bhsite":
				bhSite = field.value;
				logger.log("bhSite :: "+bhSite);
				break;
			
			case "bhfunction":
				bhFunction = field.value;
				logger.log("bhFunction :: "+bhFunction);
				break;
			
			case "bhsubfunction":
				bhSubFunction = field.value;
				logger.log("bhSubFunction :: "+bhSubFunction);
				break;
			
			case "bhlanguage":
				bhLanguage = field.value;
				logger.log("bhLanguage :: "+bhLanguage);
				break;
			
			case "bhisoelement":
				bhISOElement = field.value;
				logger.log("bhISOElement :: "+bhISOElement);
				break;
			
			case "bhuserrole":
				bhUserRole = field.value;
				logger.log("bhUserRole :: "+bhUserRole);
				break;
			
			case "bhprocess":
				bhProcess = field.value;
				logger.log("bhProcess :: "+bhProcess);
				break;
			
			case "bhsubprocess":
				bhSubProcess = field.value;
				logger.log("bhSubProcess :: "+bhSubProcess);
				break;
			
			case "bhcontentcategory":
				bhContentCategory = field.value;
				logger.log("bhContentCategory :: "+bhContentCategory);
				break;
			
			case "bhexpiry":
				bhExpiry = field.value;
				logger.log("bhExpiry :: "+bhExpiry);
				break;
			case "docauthor":
				docAuthor = field.value;
				logger.log("docAuthor :: "+docAuthor);
				break;
				
			// Custom Upload component ends - $001
				
         }
      }
	  
	  // Custom Upload component starts - $001
	  logger.log("docLibNoderef :: "+docLibNoderef);
	  logger.log("isEvidence :: "+isEvidence);
	  logger.log("isLegalPackageItem :: "+isLegalPackageItem);
	  logger.log("bhContentType :: "+bhContentType);
	  logger.log("bhProductCompany :: "+bhProductCompany);
	  logger.log("evidenceParentNoderef :: "+evidenceParentNoderef);
	  logger.log("siteId :: "+siteId);
	  logger.log("containerId :: "+containerId);
	  
	  if(bhContentType!=null && bhContentType!="undefined"){ 
		if(isEvidence == "Yes"){
		  var evidenceParentNode = search.findNode(evidenceParentNoderef);
		  //logger.log("evidenceParentNode :: "+evidenceParentNode);
		  uploadTargetNode = evidenceParentNode.childByNamePath("Attachments");
		  if(uploadTargetNode == null && evidenceParentNode.hasPermission('CreateChildren')){
				uploadTargetNode = evidenceParentNode.createFolder("Attachments");
		  }
		  bhDocumentName = filename;
		} else if(isLegalPackageItem == "Yes"){
			logger.log("innnnnnn");
			var legalCommOpsNode = roothome.childByNamePath('Company Home/Sites/bh-legal-documents/documentLibrary/Oil and Gas CommOps');
			  logger.log("legalCommOpsNodeRef :: "+legalCommOpsNode);
			  uploadTargetNode = legalCommOpsNode.childByNamePath("Workspace");
			  if(uploadTargetNode == null && legalCommOpsNode.hasPermission('CreateChildren')){
					uploadTargetNode = legalCommOpsNode.createFolder("Workspace");
			  }
			 logger.log("file name"+filename);
			  logger.log("uploadTargetNode"+uploadTargetNode.nodeRef);
			  bhDocumentName = filename;
		} else{
			var fileExt = "";
			logger.log("filename..."+filename);
			if(filename.includes(".")){
				logger.log(filename.lastIndexOf("."));
				logger.log(filename.length);
				fileExt = filename.substring(filename.lastIndexOf("."), filename.length());
				
				logger.log("in if filename...");
			}
			logger.log("fileExt :: "+fileExt.toUpperCase());
			if(bhDocumentName.includes(".")){
				var docExt = bhDocumentName.substring(bhDocumentName.lastIndexOf("."), bhDocumentName.length());
				logger.log(docExt.toUpperCase());
				if(!(fileExt.toUpperCase() == docExt.toUpperCase())){
					bhDocumentName = bhDocumentName+fileExt;
				}
			} else{
				bhDocumentName = bhDocumentName+fileExt;
			}
			uploadTargetNode = bhCreateTragetFolderPath(docLibNoderef, bhProductCompany, bhDocumentName);
			//logger.log("uploadTargetNode :: "+uploadTargetNode);
		}
		logger.log("uploadTargetNode:: "+uploadTargetNode);
	  }
	  // Custom Upload component ends - $001
	  
      // MNT-7213 When alf_data runs out of disk space, Share uploads result in a success message, but the files do not appear
      if (formdata.fields.length == 0)
      {
         exitUpload(404, " No disk space available");
         return;
      }
	  
      // Ensure mandatory file attributes have been located. Need either destination, or site + container or updateNodeRef
	  if ((filename === null || content === null) || (destination === null && (siteId === null || containerId === null) && updateNodeRef === null))
		{
			logger.log("hellooooo");
			exitUpload(400, "Required parameters are missing");
			return;
		}
	  
      /**
       * Site or Non-site?
       */
      if (siteId !== null && siteId.length() > 0)
      {
         /**
          * Site mode.
          * Need valid site and container. Try to create container if it doesn't exist.
          */
         site = siteService.getSiteInfo(siteId);
         if (site === null)
         {
            exitUpload(404, "Site (" + siteId + ") not found.");
            return;
         }

         container = site.getContainer(containerId);
         if (container === null)
         {
            try
            {
               // Create container since it didn't exist
               container = site.createContainer(containerId);
            }
            catch(e)
            {
               // Error could be that it already exists (was created exactly after our previous check) but also something else
               container = site.getContainer(containerId);
               if (container === null)
               {
                  // Container still doesn't exist, then re-throw error
                  throw e;
               }
               // Since the container now exists we can proceed as usual
            }
         }

         if (container === null)
         {
            exitUpload(404, "Component container (" + containerId + ") not found.");
            return;
         }
         
         destNode = container;
      }
      else if (destination !== null)
      {
		  logger.log("destination :: "+destination);
         /**
          * Non-Site mode.
          * Need valid destination nodeRef.
          */
         destNode = search.findNode(destination);
         if (destNode === null)
         {
            exitUpload(404, "Destination (" + destination + ") not found.");
            return;
         }
      }

      /**
       * Update existing or Upload new?
       */
      if (updateNodeRef !== null)
      {
         /**
          * Update existing file specified in updateNodeRef
          */
         var updateNode = search.findNode(updateNodeRef);
         var workingcopy = updateNode.hasAspect("cm:workingcopy");

         if (updateNode === null)
         {
            exitUpload(404, "Node specified by updateNodeRef (" + updateNodeRef + ") not found.");
            return;
         }

         if (updateNameAndMimetype)
         {
             //check to see if name is already used in folder
             var existingFile = updateNode.getParent().childByNamePath(filename),
                 newFilename = filename;
             var existingFileNodeRef = (existingFile !== null) ? String(existingFile.nodeRef) : '',
            	 updateFileNodeRef = String(updateNodeRef);
             if (existingFile !== null && existingFileNodeRef !== updateFileNodeRef)
             {
                 //name it's already used for other than node to update; create a new one
                 newFilename = createUniqueNameInFolder(filename, updateNode.getParent());
             }
            // MNT-18018: Avoid getting stuck in a loop of renamed files when using the Edit Offline functionality
            // Only rename the file if it is not a working copy and it does not contain any OS de-duplication markers
            if (!(workingcopy && containsOSDeDupeMarkers(filename, updateNode.name)))
            {
               //update node name
            	if(updateNode.getType().includes("iso_qty_manual")){
            		logger.log("Keeping file name as is for iso_qty_manual documents");
            	} else{
            		updateNode.setName(newFilename);
            	}
            }
         }

         if (!workingcopy && updateNode.isLocked)
         {
            // We cannot update a locked document (except working copy as per MNT-8736)
            exitUpload(404, "Cannot update locked document '" + updateNodeRef + "', supply a reference to its working copy instead.");
            return;
         }

         if (!workingcopy)
         {
            // Ensure the file is versionable (autoVersion and autoVersionProps read from config)
            if (autoVersion != null && autoVersionProps != null)
            {
                updateNode.ensureVersioningEnabled(autoVersion, autoVersionProps);
            }
            else
            {
                updateNode.ensureVersioningEnabled();
            }

            // It's not a working copy, do a check out to get the actual working copy
			if(updateNode.getType().includes("iso_qty_manual")){
				
				if(updateNode.hasAspect("smf:smartFolderChild")){
					var updateNodeRef = updateNode.properties["smf:actualNodeRef"];
					logger.log("updateNodeRef after :: "+updateNodeRef);
					updateNode = search.findNode(updateNodeRef);
				}
				
				var targetNodeType = updateNode.properties["bhqms:revision_type"];
				if(targetNodeType == "Target"){
					var revisionAssoc = updateNode.sourceAssocs["bhqms:revision_association"];
					if(revisionAssoc != undefined && revisionAssoc != null && revisionAssoc != "null" && revisionAssoc != ""){
						updateNode = revisionAssoc[0];
					}
				}
				updateNode = updateNode.checkoutForUpload();
			}else{
				updateNode = updateNode.checkoutForUpload();
			}
         }

         // Update the working copy content
         updateNode.properties.content.write(content, updateNameAndMimetype, true);
         // check it in again, with supplied version history note
         
         // Extract the metadata
         // (The overwrite policy controls which if any parts of
         //  the document's properties are updated from this)
         extractMetadata(updateNode);
         
         updateNode = updateNode.checkin(description, majorVersion);
         if (aspects.length != 0)
         {
            for (i = 0; i < aspects.length; i++)
            {
               if (!updateNode.hasAspect(aspects[i]))
               {
                  updateNode.addAspect(aspects[i]);
               }
            }
         }
		 
		 logger.log("Versioning...");
		 logger.log("updateNode.getType() :: "+updateNode.getType());
		 if(updateNode.getType().includes("iso_qty_manual")){
			 if(!updateNode.hasAspect("bhqms:under_workflow")){
				updateNode.properties["bhqms:document_state"] = "Draft";
				updateNode.save();
				//updateNode.properties["bhqms:document_admin"]=person.properties.firstName+" "+person.properties.lastName;
			 }
			 var adminAssoc = updateNode.assocs["bhqms:document_admin"];
			 if(adminAssoc != undefined && adminAssoc != null && adminAssoc != "null" && adminAssoc != ""){
			 	updateNode.removeAssociation(adminAssoc[0], "bhqms:document_admin");
				updateNode.save();
			 }
			 updateNode.createAssociation(person, "bhqms:document_admin");
			 person.save();
		 }

         // Record the file details ready for generating the response
         model.document = updateNode;
      }
      else
      {
         /**
          * Upload new file to destNode (calculated earlier) + optional subdirectory
          */
         if (uploadDirectory !== null && uploadDirectory.length > 0)
         {
            var child = destNode.childByNamePath(uploadDirectory);
            if (child === null)
            {
               if (createDirectory)
               {
                  child = destNode.createFolderPath(uploadDirectory);
               }
               else
               {
                  exitUpload(404, "Cannot upload file since upload directory '" + uploadDirectory + "' does not exist.");
                  return;
               }
            }

            // MNT-12565
            while (child.isDocument)
            {
               if (child.parent === null)
               {
                  exitUpload(404, "Cannot upload file. You do not have permissions to access the parent folder for the document.");
                  return;
               }
               child = child.parent;
            }

            destNode = child;
         }

         /**
          * Existing file handling.
          */
         var existingFile = destNode.childByNamePath(filename);
         if (existingFile !== null)
         {
            // File already exists, decide what to do
            if (existingFile.hasAspect("cm:versionable") && overwrite)
            {
               // Upload component was configured to overwrite files if name clashes
               existingFile.properties.content.write(content, false, true);

               // Extract the metadata
               // (The overwrite policy controls which if any parts of
               //  the document's properties are updated from this)
               extractMetadata(existingFile);

               // Record the file details ready for generating the response
               model.document = existingFile;

               // MNT-8745 fix: Do not clean formdata temp files to allow for retries. Temp files will be deleted later when GC call DiskFileItem#finalize() method or by temp file cleaner.
               return;
            }
            else
            {
               // Upload component was configured to find a new unique name for clashing filenames
               filename = createUniqueNameInFolder(filename, destNode);
            }
         }

         /**
          * Create a new file.
          */
         var newFile;
         // Custom Upload component starts - $001
		 //contentType = "bhqms:iso_qty_manual";
		 logger.log("isEvidence :: "+isEvidence);
         if (bhContentType!=null && bhProductCompany!=null && bhContentType!="" && bhProductCompany!=""
		 && bhContentType!="undefined" && bhProductCompany!="undefined" && bhContentType!="null" && bhProductCompany!="null")
         {
			 logger.log(bhContentType);
			 logger.log(bhProductCompany);
			var bhExistingFile = uploadTargetNode.childByNamePath(bhDocumentName);
			if(bhExistingFile != null){
				bhDocumentName = createUniqueNameInFolder(bhDocumentName, uploadTargetNode);
			}
			newFile = uploadTargetNode.createFile(bhDocumentName, bhContentType);
			if(isEvidence == "Yes"){
				if(!newFile.hasAspect("bhqms:evidence_aspect"))
				{
					newFile.addAspect("bhqms:evidence_aspect");
				}
			}
			logger.log("file created successfully...");
         }
         // Custom Upload component ends - $001
         else
         {
			 logger.log("In Drag n drop...");
			if(siteId == "bh-qms-documents"){
				newFile = destNode.createFile(filename, "bhqms:iso_qty_manual");
			}
			else if(siteId == "bh-legal-documents" && uploadTargetNode !=null){
				filename = createUniqueNameInFolder(filename, uploadTargetNode);
			    newFile = uploadTargetNode.createFile(filename, "bhlegal:document");
			}
			else{
				newFile = destNode.createFile(filename);
			}
            
         }
         // Use the appropriate write() method so that the mimetype already guessed from the original filename is
         // maintained - as upload may have been via Flash - which always sends binary mimetype and would overwrite it.
         // Also perform the encoding guess step in the write() method to save an additional Writer operation.
         newFile.properties.content.write(content, false, true);
		 
         // Custom Upload component starts - $001
         newFile.properties["bhqms:document_state"] = "Draft";
		 logger.log("content created");
		 logger.log("bhDocumentType :: "+bhDocumentType);
		 if(bhDocumentType !=null && bhDocumentType!="" && bhDocumentType!="undefined")
			newFile.properties["bhqms:document_type"]=bhDocumentType;
		 /* if(bhDocumentName !=null && bhDocumentName!="" && bhDocumentName!="undefined")
			newFile.properties["cm:name"]=bhDocumentName; */
		 if(documentReference !=null && documentReference!="" && documentReference!="undefined")
			newFile.properties["bhqms:reference"]=documentReference;		 
		 if(bhProductCompany !=null && bhProductCompany!="" && bhProductCompany!="undefined"){
			newFile.properties["bhqms:product_company"]=bhProductCompany;
		 }	
		 logger.log("Before.******************");		 
		 if(bhProductLine !=null && bhProductLine!="" && bhProductLine!="undefined"){
			 logger.log("Hello.....");
			var myList = new Array();
			if(bhProductLine.includes(",")){
				var bhSplit = bhProductLine.split(",");
				for(var i=0; i<bhSplit.length; i++){
					myList.push(bhSplit[i]);
				}
				newFile.properties["bhqms:product_line"]=myList;
			} else{
				newFile.properties["bhqms:product_line"]=bhProductLine;
			}
		 }			
		 if(bhSubPL !=null && bhSubPL!="" && bhSubPL!="undefined"){
			var myList = new Array();
			if(bhSubPL.includes(",")){
				var bhSplit = bhSubPL.split(",");
				for(var i=0; i<bhSplit.length; i++){
					myList.push(bhSplit[i]);
				}
				newFile.properties["bhqms:sub_product_line"]=myList;		 
			} else{
				newFile.properties["bhqms:sub_product_line"]=bhSubPL;		 
			}
		 }
			
		 if(bhSite !=null && bhSite!="" && bhSite!="undefined"){
			var myList = new Array();
			if(bhSite.includes(",")){
				var bhSplit = bhSite.split(",");
				for(var i=0; i<bhSplit.length; i++){
					myList.push(bhSplit[i]);
				}
				newFile.properties["bhqms:site"]=myList;		 
			} else{
				newFile.properties["bhqms:site"]=bhSite;		 
			}
		 }
			
		 if(bhFunction !=null && bhFunction!="" && bhFunction!="undefined"){
			var myList = new Array();
			if(bhFunction.includes(",")){
				var bhSplit = bhFunction.split(",");
				for(var i=0; i<bhSplit.length; i++){
					myList.push(bhSplit[i]);
				}
				newFile.properties["bhqms:function"]=myList;		 
			} else{
				newFile.properties["bhqms:function"]=bhFunction;		 
			}
		 }
			
		 if(bhSubFunction !=null && bhSubFunction!="" && bhSubFunction!="undefined")
			newFile.properties["bhqms:sub_function"]=bhSubFunction;		 
		 if(bhLanguage !=null && bhLanguage!="" && bhLanguage!="undefined")
			newFile.properties["bhqms:language_code"]=bhLanguage;		 
		 if(bhISOElement !=null && bhISOElement!="" && bhISOElement!="undefined"){
			var myList = new Array();
			if(bhISOElement.includes(",")){
				var bhSplit = bhISOElement.split(",");
				for(var i=0; i<bhSplit.length; i++){
					myList.push(bhSplit[i]);
				}
				newFile.properties["bhqms:iso_element"]=myList;		 	 
			} else{
				newFile.properties["bhqms:iso_element"]=bhISOElement;		 
			}
		 }
		 
		 if(bhUserRole !=null && bhUserRole!="" && bhUserRole!="undefined"){
			var myList = new Array();
			if(bhUserRole.includes(",")){
				var bhSplit = bhUserRole.split(",");
				for(var i=0; i<bhSplit.length; i++){
					myList.push(bhSplit[i]);
				}
				newFile.properties["bhqms:user_role"]=myList;		 	 
			} else{
				newFile.properties["bhqms:user_role"]=bhUserRole;		 
			}
		 }
			
		 if(bhProcess !=null && bhProcess!="" && bhProcess!="undefined"){
			var myList = new Array();
			if(bhProcess.includes(",")){
				var bhSplit = bhProcess.split(",");
				for(var i=0; i<bhSplit.length; i++){
					myList.push(bhSplit[i]);
				}
				newFile.properties["bhqms:process"]=myList;		 
			} else{
				newFile.properties["bhqms:process"]=bhProcess;		 
			}
		 }
			
		 if(bhSubProcess !=null && bhSubProcess!="" && bhSubProcess!="undefined"){
			var myList = new Array();
			if(bhSubProcess.includes(",")){
				var bhSplit = bhSubProcess.split(",");
				for(var i=0; i<bhSplit.length; i++){
					myList.push(bhSplit[i]);
				}
				newFile.properties["bhqms:sub_process"]=myList;		 
			} else{
				newFile.properties["bhqms:sub_process"]=bhSubProcess;		 
			}
		 }
			
		 if(bhContentCategory !=null && bhContentCategory!="" && bhContentCategory!="undefined")
			newFile.properties["bhqms:content_category"]=bhContentCategory;
		 if(bhExpiry !=null && bhExpiry!="" && bhExpiry!="undefined")
			newFile.properties["bhqms:expiry_date"]=bhExpiry;

		 newFile.save();
		 logger.log("docAuthor************* :: "+docAuthor);
		 if(docAuthor !=null && docAuthor!="" && docAuthor!="undefined" && docAuthor!=undefined){
			 logger.log("in docAuthor");
			var docAuthorNode = search.findNode(docAuthor);
			
			if(docAuthorNode.hasAspect("smf:smartFolderChild")){
				docAuthorNodeRef = docAuthorNode.properties["smf:actualNodeRef"];
				logger.log("docAuthorNode after :: "+docAuthorNodeRef);
				docAuthorNode = search.findNode(docAuthorNodeRef);
			}
			
			//logger.log("docAuthorNode************* :: "+docAuthorNode);
			newFile.createAssociation(docAuthorNode, "bhqms:document_author");
			docAuthorNode.save();
		 }
		 
		 if(siteId == "bh-qms-documents"){
			 logger.log("in siteId-1")
			 newFile.createAssociation(person, "bhqms:document_admin");
			 logger.log("in siteId-2")
			 person.save();
			 logger.log("in siteId-3")
		 }
		 
		 
		 
		 // Custom Upload component ends - $001
		 
		 
         
         // NOTE: Removal of first request for thumbnails to improve upload performance
         //       Thumbnails are still requested by Share on first render of the doclist image.

         // Additional aspects?
         if (aspects.length > 0)
         {
            for (i = 0; i < aspects.length; i++)
            {
               newFile.addAspect(aspects[i]);
            }
         }

         // Extract the metadata
         extractMetadata(newFile);

         // TODO (THOR-175) - review
         // Ensure the file is versionable (autoVersion and autoVersionProps read from config)
         if (autoVersion != null && autoVersionProps != null)
         {
             newFile.ensureVersioningEnabled(autoVersion, autoVersionProps);
         }
         else
         {
             newFile.ensureVersioningEnabled();
         }

         // Record the file details ready for generating the response
         model.document = newFile;
      }
      // MNT-8745 fix: Do not clean formdata temp files to allow for retries. Temp files will be deleted later when GC call DiskFileItem#finalize() method or by temp file cleaner.
   }
   catch (e)
   {
      // NOTE: Do not clean formdata temp files to allow for retries. It's possible for a temp file
      //       to remain if max retry attempts are made, but this is rare, so leave to usual temp
      //       file cleanup.
      
      // capture exception, annotate it accordingly and re-throw
      if (e.message && e.message.indexOf("AccessDeniedException") != -1)
      {
         e.code = 403;
      }
      else if (e.message && e.message.indexOf("org.alfresco.service.cmr.usage.ContentQuotaException") == 0)
      {
         e.code = 413;
      }
      else if (e.message && e.message.indexOf("org.alfresco.repo.content.ContentLimitViolationException") == 0)
      {
         e.code = 409;
      }
      else
      {
         e.code = 500;
         e.message = "Unexpected error occurred during upload of new content.";      
      }
      throw e;
   }
}


//Custom Upload component, custom function uses to create or decide Target folder location specific to PC starts - $001
function bhCreateTragetFolderPath(docLibNoderef, bhProductCompany, bhDocumentName){
	logger.log("In bhCreateTragetFolderPath");
	var childFolder = null;
	var pcNode = null;
	var targetFolderNode = null;
	var yearNode = null;
	var monthNode = null;
		
	if(docLibNoderef !=null && docLibNoderef!="")
		var docLibNode = search.findNode(docLibNoderef);
	
	logger.log("bhProductCompany :: "+bhProductCompany);
	if(bhProductCompany != null && bhProductCompany != ""){
		const monthNames = ["January", "February", "March", "April", "May", "June", 
		"July", "August", "September", "October", "November", "December"];
		
		var cuttentDate = new Date();
		var currentYear = cuttentDate.getFullYear();
		var currentMonth = monthNames[cuttentDate.getMonth()];
		logger.log("cuttentDate :: "+cuttentDate);
		logger.log("cuttentDate.getFullYear() :: "+currentYear);
		logger.log("cuttentDate.getMonth() :: "+currentMonth);
		var rootFolderName = "QMS Documents Physical Structure";
		var rootFolderNode=docLibNode.childByNamePath(rootFolderName);
		if(rootFolderNode == null && docLibNode.hasPermission('CreateChildren')){
			rootFolderNode = docLibNode.createFolder(rootFolderName);
		}
		
		pcNode = rootFolderNode.childByNamePath(bhProductCompany);
		if(pcNode == null && rootFolderNode.hasPermission('CreateChildren')){
			pcNode = rootFolderNode.createFolder(bhProductCompany);
			yearNode = pcNode.createFolder(currentYear);
			monthNode = yearNode.createFolder(currentMonth);
			targetFolderNode = monthNode.createFolder("Folder-1");
			logger.log("in pcNode created :: "+targetFolderNode);
		} else{
			yearNode = pcNode.childByNamePath(currentYear);
			if(yearNode == null && pcNode.hasPermission('CreateChildren')){
				yearNode = pcNode.createFolder(currentYear);
			}
			monthNode = yearNode.childByNamePath(currentMonth);
			if(monthNode == null && yearNode.hasPermission('CreateChildren')){
				monthNode = yearNode.createFolder(currentMonth);
			}
			var baseFolderLength = monthNode.children.length;
			if(baseFolderLength != 0){
				childFolder = "Folder-"+baseFolderLength;
				targetFolderNode = monthNode.childByNamePath(childFolder);
				if(targetFolderNode == null && monthNode.hasPermission('CreateChildren')){
					targetFolderNode = monthNode.createFolder(childFolder);
				} else{
					var childDocuments = targetFolderNode.children;
					var childDocsCount = childDocuments.length;	
					if(childDocsCount >= 700){
						baseFolderLength = baseFolderLength+1;
						childFolder = "Folder-"+baseFolderLength;
						targetFolderNode = monthNode.childByNamePath(childFolder);
						if(targetFolderNode == null && monthNode.hasPermission('CreateChildren')){
							targetFolderNode = monthNode.createFolder(childFolder);
						}
					}
				}
			} else{
				targetFolderNode = monthNode.createFolder("Folder-1");
			}
			
			var getDocument = targetFolderNode.childByNamePath(bhDocumentName);
				
			if(getDocument != null)
				targetFolderNode = overcomeDocumentDuplication(monthNode, bhDocumentName);
			
		}
	}
	logger.log("sending targetFolderNode :: "+targetFolderNode);
	return targetFolderNode;
}

function overcomeDocumentDuplication(monthNode, bhDocumentName){
	var targetFolderNode = null;
	var childFolders = monthNode.children;
	var childCount = childFolders.length;
	var child = null;		
	for(child in childFolders){
		var childFolder = childFolders[child];
		if(childFolder.children.length < 1000){
			if(childFolder.childByNamePath(bhDocumentName) == null){
				targetFolderNode = childFolder;
				break;
			}
		}
	}
	if(targetFolderNode == null){
		childCount = childCount+1;
		targetFolderNode = monthNode.createFolder("Folder-"+childCount);
	}
	return targetFolderNode;
}
//Custom Upload component, custom function uses to create or decide Target folder location specific to PC ends - $001

main();
