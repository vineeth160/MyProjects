var reference=args.referenceNo;
var formNodeRef=args.nodeRef;
var isDuplicateReference="NO";
logger.log("formNodeRef :: "+formNodeRef);
var assocNoderef = null;

if(formNodeRef != "notApplicable"){
	var formNode = search.findNode("workspace://SpacesStore/"+formNodeRef);
	logger.log("formNode before :: "+formNode);
	if(formNode.hasAspect("smf:smartFolderChild")){
		formNodeRef = formNode.properties["smf:actualNodeRef"];
		logger.log("formNode after :: "+formNodeRef);
		formNode = search.findNode(formNodeRef);
	}
	var assoc = formNode.sourceAssocs["bhqms:revision_association"];
	if(assoc != undefined && assoc != null && assoc != "null" && assoc != ""){
		assocNoderef = assoc[0].nodeRef;
	} else{
		assoc = formNode.assocs["bhqms:revision_association"];
		if(assoc != undefined && assoc != null && assoc != "null" && assoc != ""){
			assocNoderef = assoc[0].nodeRef;
		}
	}
}

var referenceQuery = "TYPE:'bhqms:iso_qty_manual' AND @bhqms:reference:'"+reference+"'";

var queryDef = {
	query: referenceQuery,
	store: "workspace://SpacesStore",
	language: "fts-alfresco",
};
logger.log("isDuplicateReference before :: "+isDuplicateReference);
var referenceQueryResults = search.query(queryDef);

/*if(referenceQueryResults.length>0){
	isDuplicateReference="YES";
}*/
for each(var referenceNode in referenceQueryResults)
{
	logger.log("formNodeRef :: "+formNodeRef);
	logger.log("assocNoderef :: "+assocNoderef);
	var referenceNoderef = referenceNode.nodeRef.toString();
	if(formNodeRef == "notApplicable"){
		isDuplicateReference="YES";
	//} else if(!(referenceNoderef.includes(formNodeRef) || referenceNoderef.includes(assocNoderef))){
	} else if(!(referenceNoderef.includes(formNodeRef) || (assocNoderef!=null && referenceNoderef.includes(assocNoderef)))){
		isDuplicateReference="YES";
	}
}
logger.log("isDuplicateReference after :: "+isDuplicateReference);

model.isDuplicateReference=isDuplicateReference;