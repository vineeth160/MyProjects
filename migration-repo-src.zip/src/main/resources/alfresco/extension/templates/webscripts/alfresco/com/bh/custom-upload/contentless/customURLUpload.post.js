function main()
{
	var formFields = (requestbody.getContent() != null) ? '' + requestbody.getContent() : '';
	var formFieldsObj = JSON.parse(formFields);
	//logger.log("formFields :: "+formFields);
	var bhContentType = formFieldsObj['bhContentType'];
	var docLibNoderef = formFieldsObj['docLibNoderef'];
	var bhDocumentType = formFieldsObj['bhDocType'];
	var bhDocumentName = formFieldsObj['bhDocName'];
	var documentReference = formFieldsObj['bhDocRef'];
	var bhProductCompany = formFieldsObj['bhProductCompany'];
	var bhProductLine = formFieldsObj['bhProductLine'];
	var bhSubPL = formFieldsObj['bhSubPL'];
	var bhSite = formFieldsObj['bhSite'];
	var bhFunction = formFieldsObj['bhFunction'];
	var bhSubFunction = formFieldsObj['bhSubFunction'];
	var bhLanguage = formFieldsObj['bhLanguage'];
	var bhISOElement = formFieldsObj['bhISOElement'];
	var bhProcess = formFieldsObj['bhProcess'];
	var bhSubProcess = formFieldsObj['bhSubProcess'];
	var bhContentCategory = formFieldsObj['bhContentCategory'];
	var bhContentAddress = formFieldsObj['bhContentAddress'];
	var bhEffective = formFieldsObj['bhEffective'];
	var bhExpiry = formFieldsObj['bhExpiry'];
	var docAuthor = formFieldsObj['docAuthor'];
	
	var uploadTargetNode = bhCreateTragetFolderPath(docLibNoderef, bhProductCompany, bhDocumentName);
	
	var newNode = uploadTargetNode.createFile("Test URL Upload",bhContentType);
	if(bhDocumentType !=null && bhDocumentType!="")
		newNode.properties["bhqms:document_type"]=bhDocumentType;
	if(bhDocumentName !=null && bhDocumentName!="")
		newNode.properties["cm:name"]=bhDocumentName;
	if(documentReference !=null && documentReference!="")
		newNode.properties["bhqms:reference"]=documentReference;		 
	if(bhProductCompany !=null && bhProductCompany!="" && bhProductCompany!="undefined"){
		newNode.properties["bhqms:product_company"]=bhProductCompany;
		newNode.properties["bhqms:document_admin"]=person.properties.firstName+" "+person.properties.lastName;
	}	 
	if(bhProductLine !=null && bhProductLine!="" && bhProductLine!="undefined"){
		 logger.log("Hello.....");
		var myList = new Array();
		if(bhProductLine.includes(",")){
			var bhSplit = bhProductLine.split(",");
			for(var i=0; i<bhSplit.length; i++){
				myList.push(bhSplit[i]);
			}
			newNode.properties["bhqms:product_line"]=myList;
		} else{
			newNode.properties["bhqms:product_line"]=bhProductLine;
		}
	 }			
	 if(bhSubPL !=null && bhSubPL!="" && bhSubPL!="undefined"){
		var myList = new Array();
		if(bhSubPL.includes(",")){
			var bhSplit = bhSubPL.split(",");
			for(var i=0; i<bhSplit.length; i++){
				myList.push(bhSplit[i]);
			}
			newNode.properties["bhqms:sub_product_line"]=myList;		 
		} else{
			newNode.properties["bhqms:sub_product_line"]=bhSubPL;		 
		}
	 }
		
	 if(bhSite !=null && bhSite!="" && bhSite!="undefined"){
		var myList = new Array();
		if(bhSite.includes(",")){
			var bhSplit = bhSite.split(",");
			for(var i=0; i<bhSplit.length; i++){
				myList.push(bhSplit[i]);
			}
			newNode.properties["bhqms:site"]=myList;		 
		} else{
			newNode.properties["bhqms:site"]=bhSite;		 
		}
	 }
		
	 if(bhFunction !=null && bhFunction!="" && bhFunction!="undefined"){
		var myList = new Array();
		if(bhFunction.includes(",")){
			var bhSplit = bhFunction.split(",");
			for(var i=0; i<bhSplit.length; i++){
				myList.push(bhSplit[i]);
			}
			newNode.properties["bhqms:function"]=myList;		 
		} else{
			newNode.properties["bhqms:function"]=bhFunction;		 
		}
	 }
		
	 if(bhSubFunction !=null && bhSubFunction!="" && bhSubFunction!="undefined")
		newNode.properties["bhqms:sub_function"]=bhSubFunction;		 
	 if(bhLanguage !=null && bhLanguage!="" && bhLanguage!="undefined")
		newNode.properties["bhqms:language_code"]=bhLanguage;		 
	 if(bhISOElement !=null && bhISOElement!="" && bhISOElement!="undefined"){
		var myList = new Array();
		if(bhISOElement.includes(",")){
			var bhSplit = bhISOElement.split(",");
			for(var i=0; i<bhSplit.length; i++){
				myList.push(bhSplit[i]);
			}
			newNode.properties["bhqms:iso_element"]=myList;		 	 
		} else{
			newNode.properties["bhqms:iso_element"]=bhISOElement;		 
		}
	 }
		
	 if(bhProcess !=null && bhProcess!="" && bhProcess!="undefined"){
		var myList = new Array();
		if(bhProcess.includes(",")){
			var bhSplit = bhProcess.split(",");
			for(var i=0; i<bhSplit.length; i++){
				myList.push(bhSplit[i]);
			}
			newNode.properties["bhqms:process"]=myList;		 
		} else{
			newNode.properties["bhqms:process"]=bhProcess;		 
		}
	 }
		
	 if(bhSubProcess !=null && bhSubProcess!="" && bhSubProcess!="undefined"){
		var myList = new Array();
		if(bhSubProcess.includes(",")){
			var bhSplit = bhSubProcess.split(",");
			for(var i=0; i<bhSplit.length; i++){
				myList.push(bhSplit[i]);
			}
			newNode.properties["bhqms:sub_process"]=myList;		 
		} else{
			newNode.properties["bhqms:sub_process"]=bhSubProcess;		 
		}
	 }		 
	if(bhContentCategory !=null && bhContentCategory!="")
		newNode.properties["bhqms:content_category"]=bhContentCategory;
	if(bhContentAddress !=null && bhContentAddress!="")
		newNode.properties["bhqms:document_url"]=bhContentAddress;
	if(bhEffective !=null && bhEffective!="")
		newNode.properties["bhqms:effective_date"]=bhEffective;		 
	if(bhExpiry !=null && bhExpiry!="")
		newNode.properties["bhqms:expiry_date"]=bhExpiry;
	
	//newNode.mimetype = "text/plain";
	newNode.content = "This is URL Object (Content Category is URL)";
	//newNode.createThumbnail("doclib");
	newNode.properties["cm:versionType"]="MAJOR";
	
	newNode.save();
	
	if(docAuthor !=null && docAuthor!="" && docAuthor!="undefined" && docAuthor!=undefined){
			logger.log("in docAuthor :: "+docAuthor);
			var docAuthorNode = search.findNode(docAuthor);
			
			if(docAuthorNode.hasAspect("smf:smartFolderChild")){
				docAuthorNodeRef = docAuthorNode.properties["smf:actualNodeRef"];
				logger.log("docAuthorNode after :: "+docAuthorNodeRef);
				docAuthorNode = search.findNode(docAuthorNodeRef);
			}
			
			//logger.log("docAuthorNode************* :: "+docAuthorNode);
			newNode.createAssociation(docAuthorNode, "bhqms:document_author");
			docAuthorNode.save();
	}
	
	//logger.log(newNode.getThumbnails());
	//logger.log(newNode.getThumbnailDefinitions().length());
	
	model.type=newNode.id;
}

//Custom Upload component, custom function uses to create or decide Target folder location specific to PC starts - $001
function bhCreateTragetFolderPath(docLibNoderef, bhProductCompany, bhDocumentName){
	var childFolder = null;
	var pcNode = null;
	var targetFolderNode = null;
	var yearNode = null;
	var monthNode = null;
		
	if(docLibNoderef !=null && docLibNoderef!="")
		var docLibNode = search.findNode(docLibNoderef);
	if(bhProductCompany != null && bhProductCompany != ""){
		const monthNames = ["January", "February", "March", "April", "May", "June", 
		"July", "August", "September", "October", "November", "December"];
		
		var cuttentDate = new Date();
		var currentYear = cuttentDate.getFullYear();
		var currentMonth = monthNames[cuttentDate.getMonth()];
		//logger.log("cuttentDate :: "+cuttentDate);
		//logger.log("cuttentDate.getFullYear() :: "+currentYear);
		//logger.log("cuttentDate.getMonth() :: "+currentMonth);
		
		var rootFolderName = "QMS Documents Physical Structure";
		var rootFolderNode=docLibNode.childByNamePath(rootFolderName);
		if(rootFolderNode == null && docLibNode.hasPermission('CreateChildren')){
			rootFolderNode = docLibNode.createFolder(rootFolderName);
		}
		
		pcNode = rootFolderNode.childByNamePath(bhProductCompany);
		if(pcNode == null && rootFolderNode.hasPermission('CreateChildren')){
			pcNode = rootFolderNode.createFolder(bhProductCompany);
			yearNode = pcNode.createFolder(currentYear);
			monthNode = yearNode.createFolder(currentMonth);
			targetFolderNode = monthNode.createFolder("Folder-1");
			//logger.log("in pcNode created :: "+targetFolderNode);
		} else{
			yearNode = pcNode.childByNamePath(currentYear);
			if(yearNode == null && docLibNode.hasPermission('CreateChildren')){
				yearNode = pcNode.createFolder(currentYear);
			}
			monthNode = yearNode.childByNamePath(currentMonth);
			if(monthNode == null && docLibNode.hasPermission('CreateChildren')){
				monthNode = yearNode.createFolder(currentMonth);
			}
			var baseFolderLength = monthNode.children.length;
			if(baseFolderLength != 0){
				childFolder = "Folder-"+baseFolderLength;
				targetFolderNode = monthNode.childByNamePath(childFolder);
				if(targetFolderNode == null && monthNode.hasPermission('CreateChildren')){
					targetFolderNode = monthNode.createFolder(childFolder);
				} else{
					var childDocuments = targetFolderNode.children;
					var childDocsCount = childDocuments.length;	
					if(childDocsCount >= 700){
						baseFolderLength = baseFolderLength+1;
						childFolder = "Folder-"+baseFolderLength;
						targetFolderNode = monthNode.childByNamePath(childFolder);
						if(targetFolderNode == null && monthNode.hasPermission('CreateChildren')){
							targetFolderNode = monthNode.createFolder(childFolder);
						}
					}
				}
			} else{
				targetFolderNode = monthNode.createFolder("Folder-1");
			}
			
			var getDocument = targetFolderNode.childByNamePath(bhDocumentName);
				
			if(getDocument != null)
				targetFolderNode = overcomeDocumentDuplication(monthNode, bhDocumentName);
			
		}
	}
	logger.log("sending targetFolderNode :: "+targetFolderNode);
	return targetFolderNode;
}

function overcomeDocumentDuplication(monthNode, bhDocumentName){
	var targetFolderNode = null;
	var childFolders = monthNode.children;
	var childCount = childFolders.length;
	var child = null;		
	for(child in childFolders){
		var childFolder = childFolders[child];
		if(childFolder.children.length < 1000){
			if(childFolder.childByNamePath(bhDocumentName) == null){
				targetFolderNode = childFolder;
				break;
			}
		}
	}
	if(targetFolderNode == null){
		childCount = childCount+1;
		targetFolderNode = monthNode.createFolder("Folder-"+childCount);
	}
	return targetFolderNode;
}
//Custom Upload component, custom function uses to create or decide Target folder location specific to PC ends - $001

main();