function main(){
	var results = [];
	var argsSearchTerm = args["searchTerm"];
	var argsMaxResults = args['size'];
	var argsType = args['type']

	if (logger.isLoggingEnabled())
	{
	  logger.log("argsSearchTerm = " + argsSearchTerm);
	  logger.log("argsMaxResults = " + argsMaxResults);
	  logger.log("argsType = " + argsType);
	}


	if (argsSearchTerm == null || argsSearchTerm == '' || argsSearchTerm == undefined) {

		status.code = 400;
		status.message = "Search Term Not Available";
		status.redirect = true;
	}	
	else {
		
		try {
			var maxResults = 100;
			if (argsMaxResults != null)
			{
			 maxResults = parseInt(argsMaxResults, 10) || maxResults;
			}
			
			argsSearchTerm = (argsSearchTerm != null && argsSearchTerm.length == 0) ? null : argsSearchTerm ;
			
			if (argsType == "fu")
			 {
				findUsers(argsSearchTerm, maxResults, results);
			 }
			 else if (argsType == "gu")
			 {
				findGroups(argsSearchTerm, maxResults, results);
			 }
			 // To retrieve Employee information from HR System Datalist starts
			 else if (argsType == "hru")
			 {
				findDatalistUsers(argsSearchTerm, maxResults, results);
			 }
			 // To retrieve Employee information from HR System Datalist ends
			 else
			 {
				// combine groups and users
				findGroups(argsSearchTerm, maxResults, results);
				findUsers(argsSearchTerm, maxResults, results);
			 }
			
		} catch(e) {
			var msg = e.message;
			if (logger.isLoggingEnabled())
				logger.log(msg);
			
			status.setCode(500, msg);
			
			return;
		}
		
		if (logger.isLoggingEnabled())
				logger.log(results);
			
		model.results = results;
		// model.argsSearchTerm = argsSearchTerm;
		// model.argsMaxResults = argsMaxResults;
		// model.argsType = argsType;
	}
}

function findUsers(searchTerm, maxResults, results) {
	var groupName="bh_qms_share_admins";
	var group = groups.getGroup(groupName);	
	if(group!=null){
		logger.log("isMemberOfGroup-- GroupName : "+group);
		var qmsAdmins = groups.getGroup(groupName).getAllUsers();
		var personRefs = people.getPeople(searchTerm, maxResults, "lastName", true);
		// create person object for each result
		if (logger.isLoggingEnabled())
			logger.log("found personRefs = " + personRefs);
		
		for each(var personRef in personRefs) {
			logger.log("personRef ="+personRef);
			var isQMSMember = getMatchedUsers(personRef, qmsAdmins);
			logger.log("isQMSMember ="+isQMSMember);
			if(isQMSMember) {
				//filter out  the disabled users
				var daname = (search.findNode(personRef)).properties.userName;
				if(people.isAccountEnabled(daname)) {
					results.push({
						item: createPersonResult(search.findNode(personRef)),
						selectable: true
					});
				}
			}
		}
	}
}

function createPersonResult(node)
{
   var personObject = 
   {
      typeShort: node.typeShort,
      isContainer: false,
      properties: {},
      displayPath: node.displayPath,
      nodeRef: "" + node.nodeRef
   }
   
   // define properties for person
   personObject.properties.userName = node.properties.userName;
   personObject.properties.name = (node.properties.firstName ? node.properties.firstName + " " : "") + 
      (node.properties.lastName ? node.properties.lastName : "") +
         " (" + node.properties.userName + ")";
   personObject.properties.jobtitle = (node.properties.jobtitle ? node.properties.jobtitle  : "");
   
   return personObject;
}

// To retrieve Employee information from HR System Datalist starts
function findDatalistUsers(searchTerm, maxResults, results)
{
	var st = searchTerm.trim();
	var hrQuery = 'TYPE:"bhdl:hrSystemDataListItem" AND @bhdl:employee_status:"Active" AND @bhdl:is_employee_active:true AND ';
	hrQuery += '(';
	hrQuery += '(@bhdl:employee_id:"'+ st + '*" OR @bhdl:employee_sso:"' + st + '*" OR @bhdl:employee_email_id:"' + st + '*")';
	
	if (st.includes(",")) {
		var n1 = st.split(",");
		hrQuery += ' OR (@bhdl:employee_first_name:"' + n1[1].trim() + '*" AND @bhdl:employee_last_name:"' + n1[0].trim() + '*")';
	} else if (st.includes(" ")) {
		var n2 = st.split(" ");
		hrQuery += ' OR (@bhdl:employee_first_name:"' + n2[0].trim() + '*" AND @bhdl:employee_last_name:"' + n2[1].trim() + '*")';
	} else {
		hrQuery += ' OR (@bhdl:employee_first_name:"' + st + '*" OR @bhdl:employee_last_name:"' + st + '*")';
	}
	
	hrQuery+= ')';
	
	/* var hrQueryResults=search.luceneSearch(hrQuery, "@cm:title", true, 100000); */
	var paging = 
	{
		maxItems: 1000,
		skipCount: 0
	};
	var queryDef = {
		query: hrQuery,
		store: "workspace://SpacesStore",
		language: "fts-alfresco",
		page: paging
	};
	var hrQueryResults = search.query(queryDef);
	for each(var hrEmployeeNode in hrQueryResults)
   {
	  results.push(
      {
        item: createHREmployeeResult(hrEmployeeNode),
        selectable: true
      });
   }
}
// To retrieve Employee information from HR System Datalist ends

// To retrieve Employee information from HR System Datalist starts
function createHREmployeeResult(hrEmployeeNode)
{
	var employeeObject = 
   {
      //typeShort: hrEmployeeNode.typeShort,
	  typeShort: "cm:person",
      isContainer: false,
      properties: {},
      displayPath: hrEmployeeNode.displayPath,
      nodeRef: "" + hrEmployeeNode.nodeRef
   }
   
	var hrSSO = hrEmployeeNode.properties["bhdl:employee_sso"];
	var hrFName = hrEmployeeNode.properties["bhdl:employee_first_name"];
	var hrLName = hrEmployeeNode.properties["bhdl:employee_last_name"];
	
   // define hr System properties for employee selection
   employeeObject.properties.userName = hrSSO;
   employeeObject.properties.name = (hrFName ? hrFName + " " : "") + 
      (hrLName ? hrLName : "") +
         " (" + hrSSO + ")";
	employeeObject.properties.employee_business_segment = hrEmployeeNode.properties["bhdl:employee_business_segment"];
	employeeObject.properties.employee_email_id = hrEmployeeNode.properties["bhdl:employee_email_id"];
	employeeObject.properties.employee_first_name = hrEmployeeNode.properties["bhdl:employee_first_name"];
	employeeObject.properties.employee_id = hrEmployeeNode.properties["bhdl:employee_id"];
	employeeObject.properties.employee_job_description = hrEmployeeNode.properties["bhdl:employee_job_description"];
	employeeObject.properties.employee_last_name = hrEmployeeNode.properties["bhdl:employee_last_name"];
	employeeObject.properties.employee_organization = hrEmployeeNode.properties["bhdl:employee_organization"];
	employeeObject.properties.employee_sso = hrEmployeeNode.properties["bhdl:employee_sso"];
	employeeObject.properties.employee_status = hrEmployeeNode.properties["bhdl:employee_status"];
	employeeObject.properties.employee_sub_business = hrEmployeeNode.properties["bhdl:employee_sub_business"];
	employeeObject.properties.is_employee_active = hrEmployeeNode.properties["bhdl:is_employee_active"];
   return employeeObject;
}
// To retrieve Employee information from HR System Datalist ends

function findGroups(searchTerm, maxResults, results)
{
   if (logger.isLoggingEnabled())
      logger.log("Finding groups matching pattern: " + searchTerm);
   
   var paging = utils.createPaging(maxResults, 0);
   var searchResults = groups.getGroupsInZone(searchTerm, "APP.DEFAULT", paging, "displayName");
   for each(var group in searchResults)
   {
      if (logger.isLoggingEnabled())
         logger.log("found group = " + group.fullName);
         
      // add to results
      results.push(
      {
         item: createGroupResult(group.groupNode),
         selectable: true 
      });
   }
   
   // sort the groups by name alphabetically
   if (results.length > 0)
   {
      results.sort(function(a, b)
      {
         return (a.item.properties.name < b.item.properties.name) ? -1 : (a.item.properties.name > b.item.properties.name) ? 1 : 0;
      });
   }
}

function createGroupResult(node)
{
   var groupObject = 
   {
      typeShort: node.typeShort,
      isContainer: false,
      properties: {},
      displayPath: node.displayPath,
      nodeRef: "" + node.nodeRef
   }
   
   // find most appropriate name for the group
   var name = node.properties.name;
   if (node.properties.authorityDisplayName != null && node.properties.authorityDisplayName.length > 0)
   {
      name = node.properties.authorityDisplayName;
   }
   else if (node.properties.authorityName != null && node.properties.authorityName.length > 0)
   {
      var authName = node.properties.authorityName;
      if (authName.indexOf("GROUP_") == 0)
      {
         name = authName.substring(6);
      }
      else
      {
         name = authName;
      }
   }
   
   // set the name
   groupObject.properties.name = name;
   
   return groupObject;
}

function getMatchedUsers(personRef, qmsAdmins){
	for (i=0; i<qmsAdmins.length; i++){
		var qmsPersonRef=qmsAdmins[i].personNodeRef;
		logger.log("qmssPersonRef ::"+qmsPersonRef);
		if(personRef.toString() == qmsPersonRef.toString()){
			return true;
		}
	}
	return false;
}

main();