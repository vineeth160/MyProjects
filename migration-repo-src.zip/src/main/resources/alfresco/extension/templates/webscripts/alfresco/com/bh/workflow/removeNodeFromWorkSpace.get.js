var nodeRef=args.node;
logger.log("nodeRef "+nodeRef);
var node=search.findNode(nodeRef);
var removed ="false";
if(node!=null)
{
if (node.activeWorkflows != null && node.activeWorkflows.length > 0){
for each (wf in node.activeWorkflows )
{
     workflow.getInstance(wf.id).remove();
}
}
//logger.log("parentNode :: "+parentNoderef);
node.remove();
removed ="true";
}
logger.log("removed ::"+removed);
model.removed=removed;
