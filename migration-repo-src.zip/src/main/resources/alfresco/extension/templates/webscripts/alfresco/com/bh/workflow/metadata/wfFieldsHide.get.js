var nodeRef=args.node;

var node=search.findNode(nodeRef);
var formNode = node;
if(formNode.hasAspect("smf:smartFolderChild")){
	formNodeRef = formNode.properties["smf:actualNodeRef"];
	logger.log("formNode after :: "+formNodeRef);
	formNode = search.findNode(formNodeRef);
}
var parentNode=formNode.parent;
var parentNoderef="";
/*if(parentNode != null)
	parentNoderef=parentNode.nodeRef;*/
var productCompany =node.properties["bhqms:product_company"];
var documentType =node.properties["bhqms:document_type"];
var isOFS = "NO";
var isEvidenceRequired = "YES"

if(productCompany != null && productCompany != "" && productCompany == "BH-OFS Oilfield Services"){
	isOFS = "YES";
}
if(documentType != null && documentType != "" && (documentType == "External Document" || documentType == "Record")){
	isEvidenceRequired = "NO";
}
logger.log("documentType :: "+documentType);
logger.log("productCompany :: "+productCompany);
logger.log("isOFS :: "+isOFS);
//logger.log("parentNode :: "+parentNoderef);

model.parentNode=parentNode;
model.productCompany=productCompany;
model.isOFS=isOFS;
model.isEvidenceRequired=isEvidenceRequired;