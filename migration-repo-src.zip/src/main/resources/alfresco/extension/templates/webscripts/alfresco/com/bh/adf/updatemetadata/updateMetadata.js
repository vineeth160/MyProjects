// Extract Uploaded QMS Document
var node = json.get("node");
var documentProperties =  json.get("properties");
documentProperties = JSON.parse(documentProperties);
/* for each (field in formdata.fields) {
	if ( field.name == "node") {
		node = field.value;
	} else if ( field.name == "documentProperties" ) {
		documentProperties = JSON.parse(field.value);
	}
} */

// QMS Document node check
if (node == null || node == '' || node == undefined) {
	// Return Uploaded Document Node Error
	status.code = 400;
	status.message = "QMS Document node cannot be located";
	status.redirect = true;
}	// QMS Document Properties check
else if ( documentProperties == null || documentProperties == '' || documentProperties == undefined ) {
	// Return Document Properties Error
	status.code = 400;
	status.message = "QMS Document properties not available";
	status.redirect = true;
} else {
	
	try {
		// Find Document using node
		var update = search.findNode(node);

		// Iterate document properties and update
		var dpKeys = Object.keys(documentProperties);
		dpKeys.forEach(function(key){
			// Updating Node/Document Properties with uploaded Properties
			var value = documentProperties[key];
			if (value != undefined && value != '' && value != null) {
				logger.log("key : " + key);
				logger.log("value : " + value);
				logger.log("is Date : " + key.toString().includes("date"));
				if ( key.toString().includes("date") ) {
					var ISODate = utils.toISO8601(value);
					logger.log("ISODate  : " + ISODate );
					update.properties[key] = ISODate;
				} else {
					update.properties[key] = value;
				}
			}
		});
		
		//  Save the updated changes
		update.save();
		
		// Updating Author Value
		var authorValue = documentProperties["bhqms:document_author"];
		if (authorValue != undefined && authorValue != '' && authorValue != null) {
			var author = search.findNode(authorValue);
			var a = upload.assocs["bhqms:document_author"];
			if (a != null) {
				upload.removeAssociation(a[0], "bhqms:document_author");
				a[0].save();
			}
			upload.createAssociation(author, "bhqms:document_author");				
			author.save();
		}
		
		model.update = {
			"status" : true,
			"message" : "Metadata updated successfully"
		};
	} catch(e) {
		// Return the error
		status.code = 400;
		status.message = e.message;
		status.redirect = true;
	}
}