var nodeRef = args["nodeRef"];
var pathElements = [];

if (logger.isLoggingEnabled())
{
  logger.log("getPathElements : nodeRef ::: " + nodeRef);
}

function main(){
	
	//logger.log("path ::: " + n.displayPath);
	if (nodeRef == null || nodeRef == '' || nodeRef == undefined) {
		status.setCode(404, "NodeRef Not Available");
		return;
	} else {
		var n = search.findNode(nodeRef);
		
		if (n != null) {
			var data = {};
			data.name = n.properties["cm:name"];
			data.description = n.properties["cm:description"];
			logger.log("getPathElements : Node Name ::: " + data.name);
			logger.log("getPathElements : Node Description ::: " + data.description);
			if (data.name != "Published Documents" && (data.description != undefined && data.description != "Published")) {
				pathElements.push(data);
				getParentData(n, pathElements);				
				pathElements = pathElements.reverse();
			}
			
			logger.log("getPathElements : pathElements ::: " + pathElements);
			model.result = pathElements;
		} else {
			status.setCode(404, nodeRef + " : NodeRef Not Found");
			return;
		}
		
		
	}
}

function getParentData(n, pathElements) {
	var data = {};
	var p = n.parent;
	data.name = p.properties["cm:name"];
	data.description = p.properties["cm:description"];
	
	if (data.name != "Published Documents" && (data.description != undefined && data.description != "Published")) {
		logger.log("getPathElements : Next --->");
		logger.log("getPathElements : Parent Name ::: " + data.name);
		logger.log("getPathElements : Parent Description ::: " + data.description);
		pathElements.push(data);		
		getParentData(p, pathElements);
	}
}

main();