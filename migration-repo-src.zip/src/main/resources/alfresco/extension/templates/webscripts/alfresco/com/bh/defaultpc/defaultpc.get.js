function main() {
	//var userName=args.userName;
	var userName=person.properties.userName;
	logger.log("userName ::"+ userName);
	var user = people.getPerson(userName);
	logger.log("user ::"+ user);
	var userGroups = people.getContainerGroups(user);
	logger.log("userGroups ::"+ userGroups);
	var productCompany =[];
	if (userGroups != null && userGroups.length > 0) {
		logger.log("userGroups not null");
     	for (var i = 0; i < userGroups.length; i++) {
       		var groupName = userGroups[i].properties["cm:authorityName"];
			logger.log("groupName ::"+ groupName);
		      if(groupName =="GROUP_bh_qms_tps_managers" || groupName =="GROUP_bh_qms_tps_contributors")
			  {
				 //logger.log("Array String-1 --> "+productCompany.toString());
				 if(!productCompany.toString().includes("BH-TPS Turbomachinery & Process Solutions")){
					productCompany.push("BH-TPS Turbomachinery & Process Solutions");
				 }
			  }
			  else if(groupName =="GROUP_bh_qms_ds_managers")
			  {
				  productCompany.push("BH-DS Digital Solutions");
				  productCompany.push("BH-DS-ISO & Quality Certifications");
				  
			  }
			   else if(groupName =="GROUP_bh_qms_ofs_managers")
			  {
				  productCompany.push("BH-OFS Oilfield Services");
			  }
			  else if(groupName =="GROUP_bh_qms_global_managers")
			  {
				  productCompany.push("BH-Global");
			  }
       		
     	}
	}
	model.productCompany=productCompany;
}


main();