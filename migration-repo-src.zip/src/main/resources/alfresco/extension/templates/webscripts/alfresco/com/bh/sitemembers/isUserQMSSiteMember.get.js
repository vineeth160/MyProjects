var loggedInUser = person.properties.userName;
var site = siteService.getSite("bh-qms-documents");
var isQMSSiteMember="false";
if(site){
	if(site.isMember(loggedInUser)){
		
		isQMSSiteMember="true";
	}
}

model.isQMSSiteMember=isQMSSiteMember;