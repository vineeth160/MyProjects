function main() {
	// Extract Uploaded QMS Document
	var requestType = null;
	var nodeRef = null;
	var category = null;
	var file = null;
	var url = null;
	var documentProperties = null;
	var workflowProperties = null;
	var assignees = null;
	var user = null;
	for each (field in formdata.fields) {
		if ( field.name == "requestType") {
			requestType = field.value;
		} else if ( field.name == "category") {
			category = field.value;
		} else if ( field.name == "document" && field.isFile ) {
			file = field;
		} else if ( field.name == "url" ) {
			url = field.value;
		} else if ( field.name == "nodeRef" ) {
			nodeRef = field.value;
		} else if ( field.name == "documentProperties" ) {
			documentProperties = JSON.parse(field.value);
		} else if ( field.name == "workflowProperties" ) {
			workflowProperties = JSON.parse(field.value);
		} else if ( field.name == "assignees" ) {
			assignees = JSON.parse(field.value);
		} else if ( field.name == "user" ) {
			user = JSON.parse(field.value);
		}
	}

	// QMS Document Request Type check
	if (requestType == null || requestType == '' || requestType == undefined) {
		// Return Uploaded Document Request Type Error
		status.code = 400;
		status.message = "QMS Document Request Type cannot be located";
		status.redirect = true;
	}	// QMS Document Request Type check
	else if ((requestType == 'NDR' || requestType == 'RDR-NEW' || requestType == 'RDR' || requestType == 'ADR') && (nodeRef == null || nodeRef == '' || nodeRef == undefined)) {
		// Return Uploaded Document Request Type Error
		status.code = 400;
		status.message = "QMS Document Node Id cannot be located";
		status.redirect = true;
	}	// QMS Content Category check
	else if (category == null || category == '' || category == undefined) {
		// Return Uploaded Document Content Category Error
		status.code = 400;
		status.message = "QMS Content Category cannot be located";
		status.redirect = true;
	}	// QMS Document check
	else if (category == "document" && (file == null || file == '' || file == undefined) && requestType != 'ADR') {
		// Return Uploaded Document Error
		status.code = 400;
		status.message = "Uploaded QMS Document cannot be located";
		status.redirect = true;
	}	// QMS Document URL check
	else if ( category == "url" && (url == null || url == '' || url == undefined) && requestType != 'ADR') {
		// Return Document URL Error
		status.code = 400;
		status.message = "QMS Document URL cannot be located";
		status.redirect = true;
	}	// QMS Document Request Properties check
	else if ( documentProperties == null || documentProperties == '' || documentProperties == undefined ) {
		// Return Document Properties Error
		status.code = 400;
		status.message = "QMS Document Request properties not available";
		status.redirect = true;
	}	// Workflow Properties and Assigness check for Request type 'new' and 'RDR'
	else if ((requestType == 'NDR-NEW' || requestType == 'RDR-NEW' || requestType == 'ADR') && (workflowProperties == null || workflowProperties == '' || workflowProperties == undefined)) {
		// Return Workflow Properties Error
		status.code = 400;
		status.message = "Start Workflow properties not available";
		status.redirect = true;
	}	// Start Workflow Assignees check
	else if ( (requestType == 'NDR-NEW' || requestType == 'RDR-NEW' || requestType == 'ADR') && (assignees == null || assignees == '' || assignees == undefined) ) {
		// Return Workflow Assignees Error
		status.code = 400;
		status.message = "Start Workflow Assignees not available";
		status.redirect = true;
	}
	else {
		// Create QMS Document in TO DO location(demo: Company Home)
		
		var upload = null;
		// Find/Create Node/Document with uploaded QMS Document/NodeRef
		if (requestType == 'NDR' || requestType == 'RDR-NEW' || requestType == 'RDR' || requestType == 'ADR') {
			try {
				upload = search.findNode(nodeRef);
			} catch(e) {
				status.code = 400;
				status.message = e.message;
				status.redirect = true;
			}
		} else if (requestType == 'NDR-NEW') {
			try {
				var cmName = documentProperties['cm:name'];
				if ( category == 'document' ) {
					var filename = file.filename;
					logger.log('filename :: ' + filename);
					var dotIndex = filename.lastIndexOf(".");
					logger.log('dotIndex :: ' + dotIndex);
					if (dotIndex >= 0) {
						cmName = cmName + filename.substring(dotIndex);
					}
					documentProperties['cm:name'] = cmName;
				}
				logger.log('cmName :: ' + cmName);
				rootFolder = bhCreateTragetFolderPath(documentProperties['bhqms:product_company'], cmName);
				upload = rootFolder.createFile(cmName, "bhqms:iso_qty_manual");
			} catch(e) {
				status.code = 400;
				status.message = e.message;
				status.redirect = true;
			}
		}
		
		try {
			if (upload != null && upload != undefined && upload != '') {
				if ( category == 'document' && requestType != 'ADR' ) {
					documentProperties['cm:title'] = file.filename;
					try {
						if (requestType == 'RDR-NEW' || requestType == 'RDR') {
							var workingcopy = upload.hasAspect("cm:workingcopy");
							if (!workingcopy && upload.isLocked) {
								status.code = 404;
								status.message = "Cannot update locked document '" + nodeRef + "', supply a reference to its working copy instead.";
								status.redirect = true;
							}
							
							if (!workingcopy) {							
								upload = upload.checkoutForUpload();
							}
						}
						
						// Update Mime-Type Property as per uploaded QMS Document
						upload.properties.content.guessMimetype(file.filename);
					
						// Attach the content of the QMS Document to Node/Document
						upload.properties.content.write(file.content);
						
						if (requestType == 'RDR-NEW' || requestType == 'RDR') {
							upload = upload.checkin("Version updated - RDR", true);
						}
					} catch(e) {
						status.code = 400;
						status.message = e.message;
						status.redirect = true;
					}
				} else if ( category == 'url' && requestType != 'ADR' ) {
					upload.content = "This is URL Object (Content Category is URL)";
					upload.properties["bhqms:document_url"] = url;
				}

				var dpKeys = Object.keys(documentProperties);
				dpKeys.forEach(function(key){
					// Updating Node/Document Properties with QMS Document Request Properties
					var value = documentProperties[key];
					if (value != undefined && value != '' && value != null) {
						if ( key.includes("date") ) {
							var ISODate = utils.toISO8601(value);
							upload.properties[key] = ISODate;
						} else {
							upload.properties[key] = value;
						}
					}
				});
				
				try {
					// Upload QMS Document and save the changes
					upload.save();
					// Updating Author Value
					var authorValue = documentProperties["bhqms:document_author"];
					if (authorValue != undefined && authorValue != '' && authorValue != null) {
						var author = search.findNode(authorValue);
						var a = upload.assocs["bhqms:document_author"];
						if (a != null) {
							upload.removeAssociation(a[0], "bhqms:document_author");
							a[0].save();
						}
						upload.createAssociation(author, "bhqms:document_author");				
						author.save();
					}
					
					// Updating Document admin
					var adminValue = documentProperties["bhqms:document_admin"];
					if (adminValue != undefined && adminValue != '' && adminValue != null) {
						var admin = search.findNode(adminValue);
						var a = upload.assocs["bhqms:document_admin"];
						if (a != null) {
							upload.removeAssociation(a[0], "bhqms:document_admin");
							a[0].save();
						}
						upload.createAssociation(admin, "bhqms:document_admin");				
						admin.save();
					}
				} catch(e) {
					status.code = 400;
					status.message = e.message;
					status.redirect = true;
				}
				
				// Uploaded QMS Document Response
				
				if (requestType == 'NDR-NEW' || requestType == 'RDR-NEW') {
					// Start Workflow Request
					var uploadedNodeRef = upload.nodeRef;
					
					// Uploaded QMS Document NodeRef check
					if ( uploadedNodeRef == null || uploadedNodeRef == '' || uploadedNodeRef == undefined ) {
						status.code = 400;
						status.message = "Error during QMS document upload";
						status.redirect = true;
					} else {
						var node = search.findNode(uploadedNodeRef);

						// Adding Version aspect
						node.addAspect("cm:versionable");
						node.save();
						
						var workflowAction = actions.create("start-workflow");
						workflowAction.parameters.workflowName = "activiti$bhQMSDocumentSubmissionReview";
						
						var workflowPackage = workflow.createPackage();
						workflowPackage.addNode(node);
						
						var futureDate = new Date();
						futureDate.setDate(futureDate.getDate() + 7);
						
						// var parameters = new Array(9); // TO DO parameters length (demo: 9)
						workflowAction.parameters["bpm:workflowDueDate"] = futureDate;
						
						if (user != null && user != undefined && user !== '') {
							workflowAction.parameters["wfSubmitter"] = user.email;
							workflowAction.parameters["wfSubmitterMail"] = user.email;
							workflowAction.parameters["wfSubmitterFirstName"] = user.firstName;
							workflowAction.parameters["wfSubmitterLastName"] = user.lastName;
						}
						
						// Request Type
						workflowAction.parameters["requestType"] = requestType.replace("-NEW", "");
						workflowAction.parameters["bhwf:bh_request_type"] = requestType.replace("-NEW", "");
						
						// Revision Number
						if (requestType == 'NDR-NEW') {
							// workflowAction.parameters["bhwf:bh_temp_revision"] = "1.0";
							// workflowAction.parameters["bhwf_bh_temp_revision"] = "1.0";
						}
						
						// Notification Enable
						workflowAction.parameters["isMailNotifyRequired"] = true;
						
						var wpKeys = Object.keys(workflowProperties);
						wpKeys.forEach(function(key){
							// Appending Workflow Properties
							var value = workflowProperties[key];
							if (value != undefined && value != '' && value != null) {
								workflowAction.parameters[key] = value;
							}
						});				
						
						var aKeys = Object.keys(assignees);
						aKeys.forEach(function(key){
							// Appending Workflow Assigness
							var assignee = assignees[key];
							var assigneeArray = assignee.split(',');
							if (assigneeArray.length > 1) {
								var assigneePersons = new Array();
								var a;
								for(a = 0;a < assigneeArray.length;a++) {
									// assigneePersons.push(people.getPerson(assigneeArray[a]));
									assigneePersons.push(search.findNode(assigneeArray[a]));
								}
								workflowAction.parameters[key] = assigneePersons;
							} else {
								// workflowAction.parameters[key] = assignee != null ? people.getPerson(assignee) : null;
								workflowAction.parameters[key] = assignee != null ? search.findNode(assignee) : null;
							}
							
						});
						
						// Start Workflow Creation Call
						var result = workflowAction.execute(node);
						
						model.id = workflowAction.toString();
					}
				} else if ( requestType == 'ADR') {
					var uploadedNodeRef = upload.nodeRef;
					
					// Uploaded QMS Document NodeRef check
					if ( uploadedNodeRef == null || uploadedNodeRef == '' || uploadedNodeRef == undefined ) {
						status.code = 400;
						status.message = "Error during Archival Document Request - NodeRef";
						status.redirect = true;
					} else {
						var node = search.findNode(uploadedNodeRef);
						
						var workflowAction = actions.create("start-workflow");
						workflowAction.parameters.workflowName = "activiti$bhQMSDocumentArchival";
						
						// Request Type
						workflowAction.parameters["requestType"] = "ADR";
						workflowAction.parameters["bhwf:bh_request_type"] = "ADR";
						
						// isFromLibrary
						workflowAction.parameters["isFromLibrary"] = "YES";
						
						// Notification Enable
						workflowAction.parameters["isMailNotifyRequired"] = true;
						
						if (user != null && user != undefined && user !== '') {
							workflowAction.parameters["wfSubmitter"] = user.email;
							workflowAction.parameters["wfSubmitterMail"] = user.email;
							workflowAction.parameters["wfSubmitterFirstName"] = user.firstName;
							workflowAction.parameters["wfSubmitterLastName"] = user.lastName;
						}
						
						var wpKeys = Object.keys(workflowProperties);
						wpKeys.forEach(function(key){
							// Appending Workflow Properties
							workflowAction.parameters[key] = workflowProperties[key];
						});
						
						var aKeys = Object.keys(assignees);
						aKeys.forEach(function(key){
							// Appending Workflow Assigness
							var assignee = assignees[key];
							var assigneeArray = assignee.split(',');
							if (assigneeArray.length > 1) {
								var assigneePersons = new Array();
								var a;
								for(a = 0;a < assigneeArray.length;a++) {
									assigneePersons.push(search.findNode(assigneeArray[a]));
								}
								workflowAction.parameters[key] = assigneePersons;
							} else {
								workflowAction.parameters[key] = assignee != null ? search.findNode(assignee) : null;
							}
							
						});
						
						var result = workflowAction.execute(node);
						model.id = workflowAction.toString();
					}
				}else {
					// Return Response of Uploaded Document
					//model.id = upload.nodeRef;
					model.id = upload.id;
				}
		
			} else {
				status.code = 404;
				status.message = "Node specified by updateNodeRef (" + nodeRef + ") not found.";
				status.redirect = true;
			}
		} catch (e) {
			status.code = 500;
			status.message = e.message;;
			status.redirect = true;
		}
	}
}

function bhCreateTragetFolderPath(bhProductCompany, bhDocumentName){
	var childFolder = null;
	var pcNode = null;
	var targetFolderNode = null;
	var yearNode = null;
	var monthNode = null;
	var docLibNode = null;
	var docLibNoderef = roothome.childByNamePath('Company Home/Sites/bh-qms-documents/documentLibrary');
	
	if(docLibNoderef !=null && docLibNoderef!="") {
		docLibNode = docLibNoderef;
	} else {
		var site = siteService.getSite("bh-qms-documents");
		var siteNode = site.node;
		for (var i=0;i<siteNode.children.length;i++) {
			var cNode = siteNode.children[i];
			if (cNode.name == 'documentLibrary') {
				docLibNode = cNode;
			}
		}
	}
	
	if(bhProductCompany != null && bhProductCompany != ""){
		const monthNames = ["January", "February", "March", "April", "May", "June", 
		"July", "August", "September", "October", "November", "December"];
		
		var cuttentDate = new Date();
		var currentYear = cuttentDate.getFullYear();
		var currentMonth = monthNames[cuttentDate.getMonth()];
		logger.log("cuttentDate :: "+cuttentDate);
		logger.log("cuttentDate.getFullYear() :: "+currentYear);
		logger.log("cuttentDate.getMonth() :: "+currentMonth);
		var rootFolderName = "QMS Documents Physical Structure";
		var rootFolderNode=docLibNode.childByNamePath(rootFolderName);
		if(rootFolderNode == null && docLibNode.hasPermission('CreateChildren')){
			rootFolderNode = docLibNode.createFolder(rootFolderName);
		}
		
		pcNode = rootFolderNode.childByNamePath(bhProductCompany);
		if(pcNode == null && rootFolderNode.hasPermission('CreateChildren')){
			pcNode = rootFolderNode.createFolder(bhProductCompany);
			yearNode = pcNode.createFolder(currentYear);
			monthNode = yearNode.createFolder(currentMonth);
			targetFolderNode = monthNode.createFolder("Folder-1");
			logger.log("in pcNode created :: "+targetFolderNode);
		} else{
			yearNode = pcNode.childByNamePath(currentYear);
			if(yearNode == null && pcNode.hasPermission('CreateChildren')){
				yearNode = pcNode.createFolder(currentYear);
			}
			monthNode = yearNode.childByNamePath(currentMonth);
			if(monthNode == null && yearNode.hasPermission('CreateChildren')){
				monthNode = yearNode.createFolder(currentMonth);
			}
			var baseFolderLength = monthNode.children.length;
			if(baseFolderLength != 0){
				childFolder = "Folder-"+baseFolderLength;
				targetFolderNode = monthNode.childByNamePath(childFolder);
				if(targetFolderNode == null && monthNode.hasPermission('CreateChildren')){
					targetFolderNode = monthNode.createFolder(childFolder);
				} else{
					var childDocuments = targetFolderNode.children;
					var childDocsCount = childDocuments.length;	
					if(childDocsCount >= 700){
						baseFolderLength = baseFolderLength+1;
						childFolder = "Folder-"+baseFolderLength;
						targetFolderNode = monthNode.childByNamePath(childFolder);
						if(targetFolderNode == null && monthNode.hasPermission('CreateChildren')){
							targetFolderNode = monthNode.createFolder(childFolder);
						}
					}
				}
			} else{
				targetFolderNode = monthNode.createFolder("Folder-1");
			}
			
			var getDocument = targetFolderNode.childByNamePath(bhDocumentName);
				
			if(getDocument != null)
				targetFolderNode = overcomeDocumentDuplication(monthNode, bhDocumentName);
			
		}
	}
	logger.log("sending targetFolderNode :: "+targetFolderNode);
	return targetFolderNode;
}

function overcomeDocumentDuplication(monthNode, bhDocumentName){
	var targetFolderNode = null;
	var childFolders = monthNode.children;
	var childCount = childFolders.length;
	var child = null;		
	for(child in childFolders){
		var childFolder = childFolders[child];
		if(childFolder.children.length < 1000){
			if(childFolder.childByNamePath(bhDocumentName) == null){
				targetFolderNode = childFolder;
				break;
			}
		}
	}
	if(targetFolderNode == null){
		childCount = childCount+1;
		targetFolderNode = monthNode.createFolder("Folder-"+childCount);
	}
	return targetFolderNode;
}

main();