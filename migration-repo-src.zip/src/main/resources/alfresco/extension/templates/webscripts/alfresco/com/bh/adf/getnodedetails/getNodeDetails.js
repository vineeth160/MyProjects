var result = {
	"hasWorkflow" : null,
	"aspects" : null,
	"associations" : null,
	"properties" : null
};

var argsNodeRef = args["nodeRef"];
var argsType = args['type'];
var types = ["hasWorkflow", "aspects", "associations", "properties", "all"];

if (logger.isLoggingEnabled())
{
  logger.log("argsNodeRef = " + argsNodeRef);
  logger.log("argsType = " + argsType);
}

function main(){
	
	if (argsNodeRef == null || argsNodeRef == '' || argsNodeRef == undefined) {
		// status.code = 404;
		// status.message = "NodeRef Not Available";
		// status.redirect = true;
		status.setCode(404, "NodeRef Not Available");
		return;
	} else if (argsType == null || argsType == '' || argsType == undefined) {
		// status.code = 404;
		// status.message = "Type Not Available";
		// status.redirect = true;
		status.setCode(404, argsType + " : Type Not Available");
		return;
	} if (types.indexOf(argsType) == -1) {
		// status.code = 500;
		// status.message = argsType + " : Type Not Applicable, Please contact Administrator";
		// status.redirect = true;
		status.setCode(404, argsType + " : Type Not Applicable, Please contact Administrator");
		return;
	} else {
		
		var node = search.findNode(argsNodeRef);
		
		if (node != null) {
			
			// Check smart node
			var smNode = node.properties["smf:actualNodeRef"];
			// logger.log("smf:actualNodeRef : " + smNode);
			if (smNode != undefined && smNode != null && smNode != '') {
				node = search.findNode(smNode);
			}
			
			// logger.log(node.getTypeShort()); bhdl:hrSystemDataListItem
			var nodeType = node.getTypeShort();
			logger.log("nodeType : " + nodeType);
			try {
				if (argsType == "hasWorkflow" && nodeType == "bhqms:iso_qty_manual") {
					result.hasWorkflow = getHasWorkflow(node);
					logger.log("hasWorkflow : " + result.hasWorkflow);					
				} else if (argsType == "aspects" && nodeType == "bhqms:iso_qty_manual") {
					result.aspects = getAspects(node);
					logger.log("aspects : " + result.aspects);
				} else if (argsType == "associations" && nodeType == "bhqms:iso_qty_manual") {
					result.associations = getAssociations(node);
					logger.log("associations : " + result.associations);
				} else if (argsType == "properties") {
					if (nodeType == "bhqms:iso_qty_manual") {
						result.properties = qmsDocumentData(node);
						logger.log("QMS Properties : " + result.properties);
					} else if (nodeType == "bhdl:hrSystemDataListItem") {
						result.properties = hrData(node);
						logger.log("HR Properties : " + result.properties);
					} else if (nodeType == "cm:person") {
						result.properties = fuData(node);
						logger.log("FU Properties : " + result.properties);
					}
				} else if (argsType == "all") {
					if (nodeType == "bhqms:iso_qty_manual") {
						result.hasWorkflow = getHasWorkflow(node);
						result.aspects = getAspects(node);
						result.associations = getAssociations(node);
						result.properties = qmsDocumentData(node);
					} else if (nodeType == "bhdl:hrSystemDataListItem") {
						result.properties = hrData(node);
					} else if (nodeType == "cm:person") {
						result.properties = fuData(node);
					}
				}				
			} catch(e) {
				var msg = e.message;
				if (logger.isLoggingEnabled())
					logger.log(msg);
				
				status.setCode(500, msg);
				
				return;
			}
			
			if (logger.isLoggingEnabled())
					logger.log(result);
				
			model.nodeData = result;
		} else {
			// status.code = 404;
			// status.message = argsNodeRef + " : NodeRef Not Found";
			// status.redirect = true;
			status.setCode(404, argsNodeRef + " : NodeRef Not Found");
			return;
		}
		
	}
}

function getHasWorkflow(node) {
	var hasWorkflow = false;
	if (node.activeWorkflows.length) {
		hasWorkflow = true;
	} else if (node.aspectsShort.indexOf("bhqms:under_workflow") != -1) {
		hasWorkflow = true;
	} else {
		var s = node.sourceAssocs["bhqms:revision_association"];
		if (s != null) {
			if (s[0].activeWorkflows.length) {
				hasWorkflow = true;
			} else if (s[0].aspectsShort.indexOf("bhqms:under_workflow") != -1) {
				hasWorkflow = true;
			}
		}
		
	}
	return hasWorkflow;
}

function getAspects(node) {
	var aspects = [];
	var s = node.sourceAssocs["bhqms:revision_association"];
	if (s != null) {
		aspects = s[0].aspectsShort;
	} else {
		aspects = node.aspectsShort;
	}
	return aspects;
}

function getAssociations(node) {
	return null;
}

function hrData(node) {
	var hr = {
		typeShort: "cm:person",
		isContainer: false,
		properties: {},
		displayPath: node.displayPath,
		nodeType: node.getTypeShort(),
		nodeRef: "" + node.nodeRef.toString()
	};
   
	var hrSSO = node.properties["bhdl:employee_sso"];
	var hrFName = node.properties["bhdl:employee_first_name"];
	var hrLName = node.properties["bhdl:employee_last_name"];
	
	hr.properties.userName = hrSSO;
	hr.properties.name = (hrFName ? hrFName + " " : "") + (hrLName ? hrLName : "") + " (" + hrSSO + ")";
	hr.properties.employee_business_segment = node.properties["bhdl:employee_business_segment"];
	hr.properties.employee_email_id = node.properties["bhdl:employee_email_id"];
	hr.properties.employee_first_name = node.properties["bhdl:employee_first_name"];
	hr.properties.employee_id = node.properties["bhdl:employee_id"];
	hr.properties.employee_job_description = node.properties["bhdl:employee_job_description"];
	hr.properties.employee_last_name = node.properties["bhdl:employee_last_name"];
	hr.properties.employee_organization = node.properties["bhdl:employee_organization"];
	hr.properties.employee_sso = node.properties["bhdl:employee_sso"];
	hr.properties.employee_status = node.properties["bhdl:employee_status"];
	hr.properties.employee_sub_business = node.properties["bhdl:employee_sub_business"];
	hr.properties.is_employee_active = node.properties["bhdl:is_employee_active"];
	return hr;
}

function fuData(node) {
	var hr = {
		typeShort: "cm:person",
		isContainer: false,
		properties: {},
		displayPath: node.displayPath,
		nodeType: node.getTypeShort(),
		nodeRef: "" + node.nodeRef.toString()
	};
	
	var hrSSO = node.properties["cm:userName"];
	var hrFName = node.properties["cm:firstName"];
	var hrLName = node.properties["cm:lastName"];
	var hrEmail = node.properties["cm:email"];
	var isEnabled = people.isAccountEnabled(hrSSO);
	
	logger.log("hrSSO : " + hrSSO);
	logger.log("hrFName : " + hrFName);
	logger.log("hrLName : " + hrLName);
	logger.log("hrEmail : " + hrEmail);
	logger.log("isEnabled : " + isEnabled);
	
	hr.properties.userName = hrSSO;
	hr.properties.name = (hrFName ? hrFName + " " : "") + (hrLName ? hrLName : "") + " (" + hrSSO + ")";
	hr.properties.employee_email_id = hrEmail;
	hr.properties.employee_first_name = hrFName;
	hr.properties.employee_last_name = hrLName;
	hr.properties.employee_id = hrSSO;
	hr.properties.employee_sso = hrSSO;
	hr.properties.employee_status = isEnabled ? "Active" : "Not Active";
	hr.properties.is_employee_active = isEnabled;
	
	return hr;
}

function qmsDocumentData(node) {
	// QMS Document data
	var d = getProperties(node);
	
	var s = node.sourceAssocs["bhqms:revision_association"];
	if (s != null) {
		var source = getProperties(s[0]);
		
		d["bhqms:revision_association"] = source;
	}
	
	return d;
}

function getProperties(node) {
	var d = {
		name: node.getName(),
		nodeType: node.getTypeShort(),
		createdAt: node.properties["cm:created"] != null ? node.properties["cm:created"].toISOString() : null,
		createdByUser: {
			displayName: people.getPersonFullName(node.properties["cm:creator"]),
			id: node.properties["cm:creator"]
		},
		id: node.id,
		isFile: node.isDocument,
		isFolder: !node.isDocument,
		modifiedAt: node.properties["cm:modified"] != null ? node.properties["cm:modified"].toISOString() : null,
		modifiedByUser: {
			displayName: people.getPersonFullName(node.properties["cm:modifier"]),
			id: node.properties["cm:modifier"]
		},
		parentId: node.parent.id,
		"cm:description": node.properties["cm:description"],
		"cm:title": node.properties["cm:title"],
		"cm:versionLabel": node.properties["cm:versionLabel"],
		"cm:versionType": node.properties["cm:versionType"],
		"bhqms:is_published": node.properties["bhqms:is_published"],
		"bhqms:published_date": node.properties["bhqms:published_date"] != null ? node.properties["bhqms:published_date"].toISOString() : null,
		"bhqms:company": node.properties["bhqms:company"],
		"bhqms:product_company": node.properties["bhqms:product_company"],
		"bhqms:product_line": node.properties["bhqms:product_line"],
		"bhqms:sub_product_line": node.properties["bhqms:sub_product_line"],
		"bhqms:site": node.properties["bhqms:site"],
		"bhqms:function": node.properties["bhqms:function"],
		"bhqms:sub_function": node.properties["bhqms:sub_function"],
		"bhqms:reference": node.properties["bhqms:reference"],
		"bhqms:language_code": node.properties["bhqms:language_code"],
		"bhqms:document_type": node.properties["bhqms:document_type"],
		"bhqms:reason_for_revision": node.properties["bhqms:reason_for_revision"],
		"bhqms:temp_revision": node.properties["bhqms:temp_revision"],
		"bhqms:publish_revision": node.properties["bhqms:publish_revision"],		
		"bhqms:process": node.properties["bhqms:process"],
		"bhqms:sub_process": node.properties["bhqms:sub_process"],
		"bhqms:iso_element": node.properties["bhqms:iso_element"],
		"bhqms:content_category": node.properties["bhqms:content_category"],
		"bhqms:document_url": node.properties["bhqms:document_url"],
		"bhqms:effective_date": node.properties["bhqms:effective_date"] != null ? node.properties["bhqms:effective_date"].toISOString() : null,
		"bhqms:expiry_date": node.properties["bhqms:expiry_date"] != null ? node.properties["bhqms:expiry_date"].toISOString() : null,
		"bhqms:document_state": node.properties["bhqms:document_state"],
		"bhqms:document_submitter": node.properties["bhqms:document_submitter"],
		"bhqms:revision_type": node.properties["bhqms:revision_type"],
		"bhqms:user_role": node.properties["bhqms:user_role"],
		"bhqms:dctm_object_id": node.properties["bhqms:dctm_object_id"],
		"bhqms:publish_revision": node.properties["bhqms:publish_revision"],
		"bhqms:temp_revision": node.properties["bhqms:temp_revision"],
		"bhqms:workflow_history" : node.properties["bhqms:workflow_history"],
		
		"bhqms:evidence_attachment": null,
		"bhqms:document_author": null,
		"bhqms:document_admin": null,
		"bhqms:functional_owner": null,
		"bhqms:revision_association": null
	}
	
	var ea = node.assocs["bhqms:evidence_attachment"];
	if (ea != null) {
		var evidence = {
			name: ea[0].name,
			nodeRef: ea[0].nodeRef.toString()
		};
		d["bhqms:evidence_attachment"] = evidence;
	}
	
	var a = node.assocs["bhqms:document_author"];
	if (a != null) {
		var hrSSO = a[0].properties["bhdl:employee_sso"];
		var hrFName = a[0].properties["bhdl:employee_first_name"];
		var hrLName = a[0].properties["bhdl:employee_last_name"];
		
		var author = {
			name: (hrFName ? hrFName + " " : "") + (hrLName ? hrLName : "") + " (" + hrSSO + ")",
			userName: a[0].nodeRef.toString()
		};
		
		d["bhqms:document_author"] = author;
	}
	
	var da = node.assocs["bhqms:document_admin"];
	if (da != null) {
		var un = da[0].properties["userName"];
		var fName = da[0].properties["firstName"];
		var lName = da[0].properties["lastName"];
		
		var documentAdmin = {
			name: (fName ? fName + " " : "") + (lName ? lName : "") + " (" + un + ")",
			userName: da[0].nodeRef.toString()
		};
		
		d["bhqms:document_admin"] = documentAdmin;
	}
	
	var fo = node.assocs["bhqms:functional_owner"];
	if (fo != null) {
		var hrSSO = fo[0].properties["bhdl:employee_sso"];
		var hrFName = fo[0].properties["bhdl:employee_first_name"];
		var hrLName = fo[0].properties["bhdl:employee_last_name"];
		
		var functionalOwner = {
			name: (hrFName ? hrFName + " " : "") + (hrLName ? hrLName : "") + " (" + hrSSO + ")",
			userName: fo[0].nodeRef.toString()
		};
		
		d["bhqms:functional_owner"] = functionalOwner;
	}
	
	return d;
}

main();