<import resource="classpath:/alfresco/templates/webscripts/org/alfresco/repository/forms/pickerresults.lib.js">

function main()
{
   var count = 0,
      items = [],
      results = [];

   // extract mandatory data from request body
   if (!json.has("items"))
   {
       status.setCode(status.STATUS_BAD_REQUEST, "items parameter is not present");
       return;
   }
   
   // convert the JSONArray object into a native JavaScript array
   var jsonItems = json.get("items"),
      itemValueType = "nodeRef",
      itemValueTypeHint = "",
      numItems = jsonItems.length(),
      item, result;
   
   if (json.has("itemValueType"))
   {
      var jsonValueTypes = json.get("itemValueType").split(";");
      itemValueType = jsonValueTypes[0];
      itemValueTypeHint = (jsonValueTypes.length > 1) ? jsonValueTypes[1] : "";
   }
   
   for (count = 0; count < numItems; count++)
   {
      item = jsonItems.get(count);
      var container = null;
      if (item != "")
      {
		  logger.log("item:;");
         result = null;
		  logger.log("itemValueType"+itemValueType);
         if (itemValueType == "nodeRef")
         {
			 logger.log("itemValueType"+itemValueType);
            result = search.findNode(item);
			logger.log("result is"+result);
            if (result)
            {
               var qnamePaths = result.qnamePath.split("/");
               if ((qnamePaths.length > 4) && (qnamePaths[2] == "st:sites"))
               {
                  container = qnamePaths[4].substr(3);
               }
            }
         }
         else if (itemValueType == "xpath")
         {
            result = search.xpathSearch(itemValueTypeHint.replace("%VALUE%", search.ISO9075Encode(item)))[0];
         }
         
         if (result != null)
         {
            // create a separate object if the node represents a user or group
			logger.log("result sub type"+result);
			logger.log("result sub type"+result.isSubType);
            if (result.isSubType("cm:person"))
            {
               result = createPersonResult(result);
            }
            else if (result.isSubType("cm:authorityContainer"))
            {
               result = createGroupResult(result);
            }
			else if(result.isSubType("bhdl:hrSystemDataListItem"))
            {
				result = createHREmployeeResult(result);
            }
            
            results.push(
            {
               item: result,
               container: container
            });
         }
      }
   }

     logger.log("results::"+results);
   if (logger.isLoggingEnabled())
       logger.log("#items = " + count + ", #results = " + results.length);

   model.results = results;
}

// To retrieve Employee information from HR System Datalist starts
function createHREmployeeResult(hrEmployeeNode)
{
	var employeeObject = 
   {
      //typeShort: hrEmployeeNode.typeShort,
	  typeShort: "cm:person",
      isContainer: false,
      properties: {},
      displayPath: hrEmployeeNode.displayPath,
      nodeRef: "" + hrEmployeeNode.nodeRef
   }
   
	var hrSSO = hrEmployeeNode.properties["bhdl:employee_sso"];
	var hrFName = hrEmployeeNode.properties["bhdl:employee_first_name"];
	var hrLName = hrEmployeeNode.properties["bhdl:employee_last_name"];
	var hrFullName = hrEmployeeNode.properties["bhdl:employee_full_name"];
	//var hrCMName = hrEmployeeNode.properties["cm:name"];
	var hrCMName = hrFullName;
	logger.log("hrSSO"+hrSSO);
   // define hr System properties for employee selection
   employeeObject.properties.userName = hrSSO;
	if(hrCMName!="" && hrCMName!=null && hrCMName!="undefined"){
		employeeObject.properties.name = hrCMName +
				" (" + hrSSO + ")";
	}
	else{
		employeeObject.properties.name = (hrFName ? hrFName + " " : "") + 
			(hrLName ? hrLName : "") +
				" (" + hrSSO + ")";
	}
	return employeeObject;
}

main();
