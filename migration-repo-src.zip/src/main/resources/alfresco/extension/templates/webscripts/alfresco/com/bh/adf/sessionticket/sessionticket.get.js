var ticket = session.ticket;
model.ticket = ticket;