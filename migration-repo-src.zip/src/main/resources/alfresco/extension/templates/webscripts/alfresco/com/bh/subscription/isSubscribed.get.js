function main() {
	var subscribed ="false";
	var nodeRef=args.nodeRef;
	logger.log("nodeRef " + nodeRef);
	var userName=args.userName;
	logger.log("userName " + userName);
	var node=search.findNode(nodeRef);
	
	if(node.hasAspect("smf:smartFolderChild")){
		nodeRef = node.properties["smf:actualNodeRef"];
		logger.log("node after :: "+nodeRef);
		node = search.findNode(nodeRef);
	}
	
	logger.log("node " + node);
	var assocs = "cm:subscribedBy";
	
	for each(assoc in node.assocs[assocs]){
		logger.log("assoc " + assoc.id);
		if (assoc.properties["cm:userName"] == userName){
			logger.log("user already subscribed");
			subscribed = "true";
			break;
		}
	}
	
	logger.log("subscribed is....."+subscribed);
	model.subscribed=subscribed;
}




main();