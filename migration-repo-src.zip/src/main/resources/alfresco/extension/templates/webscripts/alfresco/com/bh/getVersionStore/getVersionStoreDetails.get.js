var versionRef = args.versionRef;
var isMultiple = args.isMultiple;
logger.log("versionRef :: "+versionRef);
if(isMultiple == false || isMultiple=="false"){
	var versionNode = search.findNode(versionRef);
	logger.log("version node:: "+versionNode);

	var docType = versionNode.getType();
	logger.log(docType);
	var publishRevision="";
	var revisionType="";
	if(docType.includes("iso_qty_manual")){
		publishRevision=versionNode.properties["bhqms:publish_revision"];
		revisionType =versionNode.properties["bhqms:revision_type"];

		if(publishRevision==null || publishRevision==undefined || publishRevision=="null")
		{
			publishRevision="";
		}

		if(revisionType==null || revisionType==undefined || revisionType=="null")
		{
			revisiontype="";
		}
	}
	logger.log("publish Revision  No***:: "+publishRevision);
	logger.log("Revisiontype************************************:: "+revisionType);

	model.publishRevision =publishRevision;
	model.revisionType = revisionType;
} else if(isMultiple == true || isMultiple=="true"){
	logger.log("in True");

	var nodeRef =versionRef.replace("versionStore", "workspace");
	logger.log("nodeRef is:: "+nodeRef);	
	var versionNode = search.findNode(nodeRef);
	logger.log("version node:: "+versionNode);
	
	var frozenNode = versionNode.properties["ver2:frozenNodeRef"];
	var versionAndRevisionMap = [];
	var versionHistory = null;
	if(frozenNode.isVersioned){
		versionHistory = frozenNode.getVersionHistory();
	}
	
	for (var version in versionHistory){
		var jsonObj = new java.util.HashMap();
		//JSONObject jsonObj = new JSONObject();
        var versionLabel = versionHistory[version].node.properties["cm:versionLabel"];
		var revisionLabel = versionHistory[version].node.properties["bhqms:publish_revision"];
		var revisionType = versionHistory[version].node.properties["bhqms:revision_type"];
		logger.log("versionLabel - "+version +" :: "+versionLabel+" :: "+revisionType);
		
		//jsonObj.put("versionLabel", versionLabel);
		//jsonObj.put("revisionLabel", revisionLabel);
		jsonObj["versionLabel"] = versionLabel;
		jsonObj["revisionLabel"] = revisionLabel;
		jsonObj["revisionType"] = revisionType;
		versionAndRevisionMap.push(jsonObj);
    }

	/* if (node.isVersioned){
        versionHistory = node.getVersionHistory();
	}
	
	for (var i in versionHistory){
        revisionDates.push(versionHistory[i].createdDate);
    } */
	
	model.versionAndRevisionMap=versionAndRevisionMap;
}

