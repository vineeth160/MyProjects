function main(){
	var reference = args["reference"], nodeRef = args["nodeRef"], isDuplicate = false, assoc = null;
	var referenceQuery = "TYPE:'bhqms:iso_qty_manual' AND @bhqms:reference:'" + reference + "'";
	var queryDef = {
		query: referenceQuery,
		store: "workspace://SpacesStore",
		language: "fts-alfresco",
	};
	var results = search.query(queryDef);
	if (results.length > 0) {
		if(nodeRef != 'undefined' && nodeRef != undefined && nodeRef != null && nodeRef != '') {
			var doc = search.findNode("workspace://SpacesStore/" + nodeRef);
			if (doc != undefined && doc != null) {
				var a = doc.sourceAssocs["bhqms:revision_association"];
				if(a != undefined && a != null){ assoc = assoc[0].nodeRef; }
				else {
					a = doc.assocs["bhqms:revision_association"];
					if(a != undefined && a != null){ assoc = assoc[0].nodeRef; }
				}
				for each(var r in results) {
					var rNodeRef = r.nodeRef.toString();
					if(!(rNodeRef.includes(nodeRef) || (assoc != null && rNodeRef.includes(assoc)))){
						isDuplicate = true;
						break;
					}
				}
			} else { 
				// TO DO : return error
			}
		} else { isDuplicate = true; }
	}
	model.isDuplicate = isDuplicate;
}
main();