var node=args.node;
var nodeRef=search.findNode(node);
var name =nodeRef.properties["cm:name"];
//var name =nodeRef.properties["bhqms:user_comments"];
//var documentAuthor =nodeRef.properties["cm:creator"];
var productCompany =nodeRef.properties["bhqms:product_company"];
//var productLine =nodeRef.properties["bhqms:product_line"];
//var folderSite =nodeRef.properties["bhqms:folder_site"];
var documentType =nodeRef.properties["bhqms:document_type"];
var documentReference =nodeRef.properties["bhqms:reference"];
var documentVersion =nodeRef.properties["cm:versionLabel"];
var docRevisionType =nodeRef.properties["bhqms:revision_type"];
var publishedRevisionNumber = "";
var requestType = "";

if(docRevisionType == "Target"){
	publishedRevisionNumber = nodeRef.properties["bhqms:publish_revision"];
	requestType = "RDR";
} else if(docRevisionType == "Source"){
	var publishedAssoc = nodeRef.assocs["bhqms:revision_association"];
	logger.log("publishedAssoc[0] :: "+publishedAssoc);
	if(publishedAssoc != undefined && publishedAssoc != null && publishedAssoc != "null" && publishedAssoc != ""){
		requestType = "RDR";
		var publishedNode = publishedAssoc[0];
		publishedRevisionNumber = publishedNode.properties["bhqms:publish_revision"];
	} else{
		requestType = "NDR";
		publishedRevisionNumber = "1.0";
	}
}
logger.log("publishedRevisionNumber :: "+publishedRevisionNumber);

if(name == null || name == ""){
	name = "(None)";
}
//if(documentAuthor == null || documentAuthor == ""){
//	documentAuthor = "(None)";
//}
if(productCompany == null || productCompany == ""){
	productCompany = "(None)";
}
//if(productLine == null || productLine == ""){
//	productLine = "(None)";
//}
//if(folderSite == null || folderSite == ""){
//	folderSite = "(None)";
//}
if(documentType == null || documentType == ""){
	documentType = "(None)";
}


//var docFunction ="Test Function";
//if(docFunction !=null && docFunction != ""){
//	docFunction = docFunction.toString();
//}
//logger.log("reasonForRevision :: "+name);
//logger.log("documentAuthor :: "+documentAuthor);
//logger.log("productCompany :: "+productCompany);
//logger.log("productLine :: "+productLine);
//logger.log("folderSite :: "+folderSite);
//logger.log("docFunction :: "+docFunction);
//logger.log("documentType"+documentType);

model.name=name;
model.documentReference=documentReference;
model.documentVersion=documentVersion;
//model.productLine=productLine;
//model.folderSite=folderSite;
//model.docFunction=docFunction;
model.productCompany=productCompany;
model.documentType=documentType;
model.publishedRevisionNumber=publishedRevisionNumber;
model.requestType=requestType;