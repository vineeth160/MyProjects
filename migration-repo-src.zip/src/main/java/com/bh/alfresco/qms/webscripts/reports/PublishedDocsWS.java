package com.bh.alfresco.qms.webscripts.reports;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.model.Repository;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.TempFileProvider;
import org.alfresco.util.UrlUtil;
import org.apache.chemistry.opencmis.commons.impl.json.JSONArray;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.common.usermodel.HyperlinkType;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

public class PublishedDocsWS extends DeclarativeWebScript {

	private String app_model_1_0_uri;

	private static final Log logger = LogFactory.getLog(PublishedDocsWS.class);

	public String getApp_model_1_0_uri() {
		return app_model_1_0_uri;
	}

	public void setApp_model_1_0_uri(String app_model_1_0_uri) {
		this.app_model_1_0_uri = app_model_1_0_uri;
	}

	private ServiceRegistry serviceRegistry;
	private Repository repository;
	private String queryForPublishedocuments;
	private String queryForRequestParameters="";
	//private String fileLocation = "";
	private String bhPublishToDate;
	private String bhPublishFromDate;
	private String bhExpiryToDate;
	private String bhExpiryFromDate;
	private String bhEffectiveToDate;
	private String bhEffectiveFromDate;
	private String bhPC;
	private String bhPL;
	private String bhSPL;
	private String bhFunction;
	private String bhSubFunction;
	private String bhSite;
	private String bhDocAdmin;
	private String bhDocAuthor;
	private String bhDocFunOwner;

	QName PROP_QNAME_REFERENCE_NUMBER = QName.createQName(app_model_1_0_uri, "reference");
	QName PROP_QNAME_DOCUMENT_AUTHOR = QName.createQName(app_model_1_0_uri, "document_author");
	QName PROP_QNAME_DOCUMENT_ADMIN = QName.createQName(app_model_1_0_uri, "document_admin");
	QName PROP_QNAME_FUNCTIONAL_OWNER = QName.createQName(app_model_1_0_uri, "functional_owner");
	QName PROP_QNAME_DOCUMENT_URL = QName.createQName(app_model_1_0_uri, "document_url");
	QName PROP_QNAME_EXPIRY_DATE = QName.createQName(app_model_1_0_uri, "expiry_date");
	QName PROP_QNAME_PUBLISH_DATE = QName.createQName(app_model_1_0_uri, "published_date");
	QName PROP_QNAME_EFFECTIVE_DATE = QName.createQName(app_model_1_0_uri, "effective_date");
	QName PROP_QNAME_DOCUMENT_TYPE = QName.createQName(app_model_1_0_uri, "bhqms:document_type");

	/*
	 * public String getFileLocation() { return fileLocation; }
	 * 
	 * public void setFileLocation(String fileLocation) { this.fileLocation =
	 * fileLocation; }
	 * 
	 * public String getqueryforPublishedocuments() { return
	 * queryforPublishedocuments; }
	 * 
	 * public void setqueryforPublishedocuments(String queryforPublishedocuments) {
	 * this.queryforPublishedocuments = queryforPublishedocuments; }
	 */
	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	/**
	 * 
	 * @param repository
	 */
	public void setRepository(Repository repository) {
		this.repository = repository;
	}

	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {
		Map<String, String> mapOfrparams = new HashMap<String, String>();
		JSONArray mapOfPubDocs = null;

		bhPublishToDate = req.getParameter("bhPublishToDate");
		bhPublishFromDate = req.getParameter("bhPublishFromDate");
		bhExpiryToDate = req.getParameter("bhExpiryToDate");
		bhExpiryFromDate = req.getParameter("bhExpiryFromDate");
		bhEffectiveToDate = req.getParameter("bhEffectiveToDate");
		bhEffectiveFromDate = req.getParameter("bhEffectiveFromDate");
		bhPC = req.getParameter("bhPC");
		bhPL = req.getParameter("bhPL");
		bhSPL = req.getParameter("bhSPL");
		bhFunction = req.getParameter("bhFunction");
		bhSubFunction = req.getParameter("bhSubFunction");
		bhSite = req.getParameter("bhSite");
		bhDocAdmin = req.getParameter("bhDocAdmin");
		bhDocAuthor = req.getParameter("bhDocAuthor");
		bhDocFunOwner = req.getParameter("bhDocFunOwner");

		String alfrescoDate = null;
		Date regularDate = null;
		
		logger.info("bhPublishToDate:" + bhPublishToDate);
		logger.info("bhPublishFromDate:" + bhPublishFromDate);

		DateFormat format = new SimpleDateFormat("dd/mm/yyyy", Locale.ENGLISH);
		DateFormat alfrescoFormat = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
		try {
			if (bhPublishFromDate != null && !bhPublishFromDate.trim().isEmpty()) {
				regularDate = format.parse(bhPublishFromDate);
				alfrescoDate = alfrescoFormat.format(regularDate).toString();
			} else {
				alfrescoDate = "MIN";
			}
			
			mapOfrparams.put("bhPublishFromDate", alfrescoDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		try {
			if (bhPublishToDate != null && !bhPublishToDate.trim().isEmpty()) {
				regularDate = format.parse(bhPublishToDate);
				alfrescoDate = alfrescoFormat.format(regularDate).toString();
			} else {
				alfrescoDate = "MAX";
			}
			mapOfrparams.put("bhPublishToDate", alfrescoDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		try {
			if (bhExpiryFromDate != null && !bhExpiryFromDate.trim().isEmpty()) {
				regularDate = format.parse(bhExpiryFromDate);
				alfrescoDate = alfrescoFormat.format(regularDate).toString();
			} else {
				alfrescoDate = "MIN";
			}
			mapOfrparams.put("bhExpiryFromDate", alfrescoDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		try {
			if (bhExpiryToDate != null && !bhExpiryToDate.trim().isEmpty()) {
				regularDate = format.parse(bhExpiryToDate);
				alfrescoDate = alfrescoFormat.format(regularDate).toString();
			} else {
				alfrescoDate = "MAX";
			}
			mapOfrparams.put("bhExpiryToDate", alfrescoDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		try {
			if (bhEffectiveFromDate != null && !bhEffectiveFromDate.trim().isEmpty()) {
				regularDate = format.parse(bhEffectiveFromDate);
				alfrescoDate = alfrescoFormat.format(regularDate).toString();
			} else {
				alfrescoDate = "MIN";
			}
			mapOfrparams.put("bhEffectiveFromDate", alfrescoDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		try {
			if (bhEffectiveToDate != null && !bhEffectiveToDate.trim().isEmpty()) {
				regularDate = format.parse(bhEffectiveToDate);
				alfrescoDate = alfrescoFormat.format(regularDate).toString();
			} else {
				alfrescoDate = "MAX";
			}
			mapOfrparams.put("bhEffectiveToDate", alfrescoDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		mapOfrparams.put("bhPC", bhPC);
		mapOfrparams.put("bhPL", bhPL);
		mapOfrparams.put("bhSPL", bhSPL);
		mapOfrparams.put("bhFunction", bhFunction);
		mapOfrparams.put("bhSubFunction", bhSubFunction);
		mapOfrparams.put("bhSite", bhSite);
		mapOfrparams.put("bhDocAdmin", bhDocAdmin);
		mapOfrparams.put("bhDocAuthor", bhDocAuthor);
		mapOfrparams.put("bhDocFunOwner", bhDocFunOwner);

		List<NodeRef> nodeResultSet = getPublishedDocumentsList(mapOfrparams);
		try {
			mapOfPubDocs = generateModelForListView(nodeResultSet);
		} catch (JSONException e) {
			e.printStackTrace();
		}
//		String bhExportExcel = req.getParameter("bhExportExcel");
//		if (bhExportExcel.equalsIgnoreCase("true")) {
//			exportToExcel(nodeResultSet);
//		}

		logger.info("mapOfPubDocs :: "+mapOfPubDocs);
		logger.info("mapOfPubDocs :: "+mapOfPubDocs.toString());
		logger.info("mapOfPubDocs.toJSONString() :: "+mapOfPubDocs.toJSONString());

		Map<String, Object> returnMap = new HashMap<String, Object>();
		returnMap.put("mapOfPubDocs", mapOfPubDocs.toJSONString());

		return returnMap;
	}

	public List<NodeRef> getPublishedDocumentsList(Map<String, String> requestParams) {
		List<NodeRef> listNodes = new ArrayList<NodeRef>();
		queryForPublishedocuments = "@bhqms:published_date:[" + requestParams.get("bhPublishFromDate") + " TO "
				+ requestParams.get("bhPublishToDate") + "] AND @bhqms:document_state:\"Published\"";

		if (requestParams.get("bhExpiryFromDate") != null && !requestParams.get("bhExpiryFromDate").isEmpty()
				&& requestParams.get("bhExpiryToDate") != null && !requestParams.get("bhExpiryToDate").isEmpty()) {
			queryForRequestParameters = " AND @bhqms:expiry_date:[" + requestParams.get("bhExpiryFromDate") + " TO "
					+ requestParams.get("bhExpiryToDate") + "]";
		}
		if (requestParams.get("bhEffectiveFromDate") != null && !requestParams.get("bhEffectiveFromDate").isEmpty()
				&& requestParams.get("bhEffectiveToDate") != null && !requestParams.get("bhEffectiveToDate").isEmpty()) {
			queryForRequestParameters += " AND @bhqms:effective_date:[" + requestParams.get("bhEffectiveFromDate")
			+ " TO " + requestParams.get("bhEffectiveToDate") + "]";
		}

		if (requestParams.get("bhPC") != null && !requestParams.get("bhPC").isEmpty()) {
			queryForRequestParameters += " AND @bhqms:product_company:" + "\"" + requestParams.get("bhPC")
			+ "\"";
		}

		if (requestParams.get("bhPL") != null && !requestParams.get("bhPL").isEmpty()) {
			queryForRequestParameters += " AND @bhqms:product_line:" + "\"" + requestParams.get("bhPL")
			+ "\"";
		}
		if (requestParams.get("bhSPL") != null && !requestParams.get("bhSPL").isEmpty()) {
			queryForRequestParameters += " AND @bhqms:sub_product_line:" + "\""
					+ requestParams.get("bhSPL") + "\"";
		}
		if (requestParams.get("bhFunction") != null && !requestParams.get("bhFunction").isEmpty()) {
			queryForRequestParameters += " AND @bhqms:function:" + "\"" + requestParams.get("bhFunction") + "\"";
		}

		if (requestParams.get("bhSubFunction") != null && !requestParams.get("bhSubFunction").isEmpty()) {
			queryForRequestParameters += " AND @bhqms:sub_function:" + "\"" + requestParams.get("bhSubFunction")
			+ "\"";
		}

		if (requestParams.get("bhSite") != null && !requestParams.get("bhSite").isEmpty()) {
			queryForRequestParameters += " AND @bhqms:site:" + "\"" + requestParams.get("bhSite") + "\"";
		}

		if (requestParams.get("bhDocAuthor") != null && !requestParams.get("bhDocAuthor").isEmpty()) {
			queryForRequestParameters += " AND @bhqms:document_author:" + "\"" + requestParams.get("bhDocAuthor")
			+ "\"";
		}

		if (requestParams.get("bhDocAdmin") != null && !requestParams.get("bhDocAdmin").isEmpty()) {
			queryForRequestParameters += " AND @bhqms:document_admin:" + "\"" + requestParams.get("bhDocAdmin")
			+ "\"";
		}

		if (requestParams.get("bhDocFunOwner") != null && !requestParams.get("bhDocFunOwner").isEmpty()) {
			queryForRequestParameters += " AND @bhqms:functional_owner:" + "\""
					+ requestParams.get("bhDocFunOwner") + "\"";
		}

		if (queryForRequestParameters != null && !queryForRequestParameters.trim().isEmpty()) {
			queryForPublishedocuments = queryForPublishedocuments + queryForRequestParameters;
		}

		logger.info("queryforExportDocuments :: "+queryForPublishedocuments);

		ResultSet results=null;
		try {
			results = getResultSet(queryForPublishedocuments.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}

		listNodes = results.getNodeRefs();

		return listNodes;
	}

	public JSONArray generateModelForListView(List<NodeRef> nodeResultSet) throws JSONException {
		JSONArray mapOfResult = new JSONArray();
		for (NodeRef node : nodeResultSet) {

			String nodeName = (String) serviceRegistry.getNodeService().getProperty(node, ContentModel.PROP_NAME);
			String nodeAuthor = (String)serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_DOCUMENT_AUTHOR);
			String nodeAdmin = (String)serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_DOCUMENT_ADMIN);
			String nodeFunctionalOwner = (String)serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_FUNCTIONAL_OWNER);
			String documentUrl = getDocumentPropertiesUrl(node);

			Date publishDate = (Date)serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_PUBLISH_DATE);
			Date expiryDate = (Date)serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_EXPIRY_DATE);
			Date effectiveDate = (Date)serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_EFFECTIVE_DATE);

			String nodePublishDate ="";
			String nodeExpiryDate ="";
			String nodeEffectiveDate ="";
			if(publishDate!=null)
				nodePublishDate = publishDate.toString();
			if(expiryDate!=null)
				nodeExpiryDate = expiryDate.toString();
			if(effectiveDate!=null)
				nodeEffectiveDate = effectiveDate.toString();

			// Map<String, String> nodeMapForListView = new HashMap<String, String>();
			JSONObject nodeMapForListView = new JSONObject();
			nodeMapForListView.put("nodeName", nodeName);
			nodeMapForListView.put("nodePublishDate", nodePublishDate);
			nodeMapForListView.put("documentUrl", documentUrl);
			nodeMapForListView.put("nodeAuthor", nodeAuthor);
			nodeMapForListView.put("nodeAdmin", nodeAdmin);
			nodeMapForListView.put("nodeFunctionalOwner", nodeFunctionalOwner);
			nodeMapForListView.put("nodeExpiryDate", nodeExpiryDate);
			nodeMapForListView.put("nodeEffectiveDate", nodeEffectiveDate);
			nodeMapForListView.put("nodeRef", node.toString());

			mapOfResult.add(nodeMapForListView);

		}
		return mapOfResult;

	}

	public void exportToExcel(List<NodeRef> listNodes) {
		List<Map<String, String>> dataForExcel = new ArrayList<Map<String, String>>();

		for (NodeRef node : listNodes) {

			String nodeName = (String) serviceRegistry.getNodeService().getProperty(node, ContentModel.PROP_NAME);
			String nodeRefernceNumber = (String) serviceRegistry.getNodeService().getProperty(node,
					PROP_QNAME_REFERENCE_NUMBER);
			String nodeDocumentAuthor = (String) serviceRegistry.getNodeService().getProperty(node,
					PROP_QNAME_DOCUMENT_AUTHOR);
			String nodeDocumentAdmin = (String) serviceRegistry.getNodeService().getProperty(node,
					PROP_QNAME_DOCUMENT_ADMIN);
			String nodeFunctionalOwner = (String) serviceRegistry.getNodeService().getProperty(node,
					PROP_QNAME_FUNCTIONAL_OWNER);
			//String nodeDocType = (String) serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_DOCUMENT_TYPE);
			String nodeEffectiveDate = null;
			if (serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_EFFECTIVE_DATE) != null) {
				nodeEffectiveDate = serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_EFFECTIVE_DATE)
						.toString();
			}

			String nodePublishDate = null;
			if (serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_PUBLISH_DATE) != null) {
				nodePublishDate = serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_PUBLISH_DATE)
						.toString();
			}

			String nodeExpiryDate = null;
			if (serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_EXPIRY_DATE) != null) {
				nodeExpiryDate = serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_EXPIRY_DATE).toString();
			}

			String nodeDocumentUrl = getDocumentPropertiesUrl(node);

			Map<String, String> nodeMap = new HashMap<String, String>();
			nodeMap.put("DocumentTitle", nodeName);
			nodeMap.put("ReferenceNumber", nodeRefernceNumber);
			nodeMap.put("Author", nodeDocumentAuthor);
			nodeMap.put("Admin", nodeDocumentAdmin);
			nodeMap.put("FunctionalOwner", nodeFunctionalOwner);
			nodeMap.put("DocumentURL", nodeDocumentUrl);
			nodeMap.put("ExpiryDate", nodeExpiryDate);
			nodeMap.put("PublishDate", nodePublishDate);
			nodeMap.put("EffectiveDate", nodeEffectiveDate);

			dataForExcel.add(nodeMap);

		}

		writeToExcel(dataForExcel);

	}

	public void writeToExcel(List<Map<String, String>> nodeList) {
		String fileName = getFileName();

		File file = TempFileProvider.createTempFile(fileName, "");
		//this.fileLocation = file.getAbsolutePath();

		//File file = new File(this.fileLocation + fileName);

		Workbook workbook = null;
		Sheet sheet = null;

		try {
			if (file.createNewFile()) {

				workbook = new HSSFWorkbook();
				sheet = workbook.createSheet("Published Documents");

				// Header Cell Style
				CellStyle boldStyle = workbook.createCellStyle();
				Font boldFont = workbook.createFont();
				boldFont.setBold(true);
				// boldFont.setColor(IndexedColors.BLUE.getIndex());
				boldStyle.setFont(boldFont);

				// Hedear Data
				String[] headers = new String[] { " DocumentTitle", "ReferenceNumber", "Author", "Admin",
						"FunctionalOwner", "DocumentURL", "ExpiryDate", "PublishDate", "EffectiveDate" };

				// Create Header
				Row row = sheet.createRow(0);

				// Insert Header data
				for (int rn = 0; rn < headers.length; rn++) {
					Cell cell = row.createCell(rn);
					cell.setCellValue(headers[rn]);
					cell.setCellStyle(boldStyle);
				}
			} else {

				workbook = new HSSFWorkbook(new FileInputStream(file));
				sheet = workbook.getSheet("Published Documents");

			}

		} catch (IOException e1) {
			e1.printStackTrace();
		}

		int rowCount = sheet.getLastRowNum();
		// Insert node List
		for (Map<String, String> node : nodeList) {
			Row row = sheet.createRow(++rowCount);
			writeIntoCells(row, node, workbook);
		}
		try {
			FileOutputStream outputStream = new FileOutputStream(file);
			workbook.write(outputStream);
			outputStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void writeIntoCells(Row row, Map<String, String> attributes, Workbook workbook) {
		int cellCount = 0;
		Cell cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("DocumentTitle"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("ReferenceNumber"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("Author"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("Admin"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("FunctionalOwner"));
		cell = row.createCell(cellCount++);
		setDocumentUrlValue(cell, workbook, attributes);
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("ExpiryDate"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("PublishDate"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("EffectiveDate"));
	}

	public void setDocumentUrlValue(Cell cell, Workbook workbook, Map<String, String> attributes) {

		CellStyle hlink_style = workbook.createCellStyle();
		Font hlink_font = workbook.createFont();
		hlink_font.setUnderline(Font.U_SINGLE);
		hlink_font.setColor(IndexedColors.BLUE.getIndex());
		hlink_style.setFont(hlink_font);

		String linkAddress = attributes.get("DocumentURL");
		Hyperlink href = workbook.getCreationHelper().createHyperlink(HyperlinkType.URL);
		href.setAddress(linkAddress);
		cell.setHyperlink(href);
		cell.setCellStyle(hlink_style);
		cell.setCellValue(linkAddress);

	}

	public String getDocumentPropertiesUrl(NodeRef node) {

		String baseUrl = UrlUtil.getShareUrl(serviceRegistry.getSysAdminParams());
		String siteShortName = serviceRegistry.getSiteService().getSiteShortName(node);
		StringBuilder path = new StringBuilder();
		path.append(baseUrl).append("/page/");
		if (siteShortName != null) {
			path.append("site/").append(siteShortName).append("/");
		}

		path.append("document-details?nodeRef=").append(node);

		return path.toString();
	}

	public static String getFileName() {

		String fileName = null;
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		formatter.format(calendar.getTime());
		fileName = "Published Documents Report - " + formatter.format(calendar.getTime()).toString() + ".xls";
		return fileName;
	}


	public ResultSet getResultSet(String query) throws IOException {
		ResultSet results = null;
		if (query != null) {			
			SearchParameters sp = new SearchParameters();
			sp.addStore(this.repository.getRootHome().getStoreRef());
			sp.setLanguage(SearchService.LANGUAGE_FTS_ALFRESCO);
			sp.setMaxItems(Integer.MAX_VALUE);
			sp.setQuery(query);
			results = this.serviceRegistry.getSearchService().query(sp);			
		}
		return results;
	}

}
