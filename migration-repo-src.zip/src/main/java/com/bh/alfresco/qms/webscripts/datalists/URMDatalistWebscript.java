package com.bh.alfresco.qms.webscripts.datalists;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.model.DataListModel;
import org.alfresco.repo.search.impl.lucene.SolrJSONResultSet;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.dictionary.DictionaryService;
import org.alfresco.service.cmr.dictionary.PropertyDefinition;
import org.alfresco.service.cmr.dictionary.TypeDefinition;
import org.alfresco.service.cmr.repository.AssociationRef;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.LimitBy;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.bh.alfresco.qms.constants.BHContentModelConstants;

public class URMDatalistWebscript extends AbstractWebScript{
	
	private static final Log LOGGER = LogFactory.getLog(URMDatalistWebscript.class);
	private static final String CONTAINER_ID_FOR_DATALIST = "datalists";
		
    private ServiceRegistry serviceRegistry;
	
	private NodeService nodeService;
	
	private DictionaryService dictionaryService;
	
	private String outputValues;
	
	private String activeProperty;
	
	private String uName;
	
	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		
		this.serviceRegistry = serviceRegistry;
		
		this.nodeService = serviceRegistry.getNodeService();
		
		this.dictionaryService = serviceRegistry.getDictionaryService();
		
	}
	
	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}
	
	public List<String> getPropertyNamesForGivenType(String dataListType) {
		
		QName typeQName = QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, dataListType);
		
		List<String> propertyNamesList = new ArrayList<String>();
	
		TypeDefinition typeDefinition = dictionaryService.getType(typeQName);
		
		Map<QName,PropertyDefinition> qnamePropertyDefinitionMap = typeDefinition.getProperties();	
		
		Set<QName> set = qnamePropertyDefinitionMap.keySet();
		
		Iterator<QName> iterator = set.iterator();
		
		while(iterator.hasNext()) {
			
			propertyNamesList.add(qnamePropertyDefinitionMap.get(iterator.next()).getName().getLocalName());
			
		}
		
		return propertyNamesList;
				
	}
	
	public List<String> getTitlesForGivenType(String dataListType) {
		
		QName typeQName = QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, dataListType);
		
		List<String> titleList = new ArrayList<String>();
	
		TypeDefinition typeDefinition = dictionaryService.getType(typeQName);
		
		Map<QName,PropertyDefinition> qnamePropertyDefinitionMap = typeDefinition.getProperties();	
		
		Set<QName> set = qnamePropertyDefinitionMap.keySet();
		
		Iterator<QName> iterator = set.iterator();
		
		while(iterator.hasNext()) {
			
			titleList.add(qnamePropertyDefinitionMap.get(iterator.next()).getTitle());
			
		}
				
		return titleList;
		
	}
	
	public boolean isValidRequest(String strSiteName, String dataListType, Set<String> jsonKeySet) {
		
		boolean isValidInput = true;
		
		if(serviceRegistry.getSiteService().getSite(strSiteName) == null) {
			
			isValidInput = false;
			
			return isValidInput;
			
		}
		
		if(dictionaryService.getType(QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, dataListType)) == null) {
			
			isValidInput = false;
			
			return isValidInput;
			
		}
		
		List<String> namesList = getPropertyNamesForGivenType(dataListType);
		
		//Iterator<String> iterator = jsonKeySet.iterator();
		
		LOGGER.info("nameList ::"+ namesList);
		
		for(String jsonKey: jsonKeySet) {
			LOGGER.info("jsonKey :: "+jsonKey);
			if(!(namesList.contains(jsonKey))) {
				isValidInput = false;
				return isValidInput;
			}
		}
		
		/*
		 * while(iterator.hasNext()) {
		 * LOGGER.info("iterator.next() ::"+iterator.next());
		 * if(!(namesList.contains(iterator.next()))) {
		 * 
		 * isValidInput = false;
		 * 
		 * return isValidInput;
		 * 
		 * }
		 * 
		 * }
		 */
		
		return isValidInput;
		
	}
	
	public List<NodeRef> getNodeRefsForGivenSiteAndDatalistTypeOLD(String strSiteName, String dataListType) {
		
		String strDatalistTypeValue = null;
		
		List<NodeRef> nodeRefList = new ArrayList<NodeRef>();
		
		NodeRef datalistContainerNodeRef = serviceRegistry.getSiteService().getContainer(strSiteName, CONTAINER_ID_FOR_DATALIST);
		
		List<ChildAssociationRef> datalistsContainerChildAssociationNodeRefList = nodeService.getChildAssocs(datalistContainerNodeRef);
		
		for(ChildAssociationRef datalistsContainerChildAssociationNodeRef : datalistsContainerChildAssociationNodeRefList) {
			
			NodeRef datalistNodeRef = datalistsContainerChildAssociationNodeRef.getChildRef();
			
			List<ChildAssociationRef> datalistChildAssociationNodeRefList = nodeService.getChildAssocs(datalistNodeRef);
			
			strDatalistTypeValue = (String) nodeService.getProperty(datalistNodeRef, DataListModel.PROP_DATALIST_ITEM_TYPE);
			
			if(strDatalistTypeValue.contains(dataListType)) {
				
				for(ChildAssociationRef datalistChildAssociationNodeRef : datalistChildAssociationNodeRefList) {
					
					if((boolean) nodeService.getProperty(datalistChildAssociationNodeRef.getChildRef(), QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI,
							getActiveProperty()))){
						
						nodeRefList.add(datalistChildAssociationNodeRef.getChildRef());
						
					}
					
				}
				
				break;
				
			}
			
		}
		
		return nodeRefList;
		
	}
	
public List<NodeRef> getNodeRefsForGivenSiteAndDatalistType(String strSiteName, String dataListType) {
	
	    List<NodeRef> matchedNodeRefList = new ArrayList<NodeRef>();
	    SolrJSONResultSet result = null;
		String query="TYPE:'dl:dataList' AND =@dl:dataListItemType:'bhdl:"+dataListType+"'";
		LOGGER.info("#####query :: "+query);
		final SearchParameters params = new SearchParameters();
			params.setLimit(0);
			params.setMaxItems(-1);
			params.setLimitBy(LimitBy.UNLIMITED);
			params.setMaxPermissionChecks(100000);
			params.setMaxPermissionCheckTimeMillis(100000);
		
		params.addStore(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE);
		params.setLanguage(SearchService.LANGUAGE_FTS_ALFRESCO);
		params.setQuery(query);
		ResultSet searchResult = serviceRegistry.getSearchService().query(params);
		
		if (null != searchResult && searchResult.length() > 0) {
			LOGGER.info("#####result :: "+searchResult.length());
			NodeRef dataListItem = searchResult.getNodeRefs().get(0);
			LOGGER.info("#####dataListItem :: "+dataListItem);
			List<ChildAssociationRef> childNodes=serviceRegistry.getNodeService().getChildAssocs(dataListItem);
			for(ChildAssociationRef child:childNodes) {
			  NodeRef node =child.getChildRef();
			  LOGGER.info("#####node :: "+node);
			  matchedNodeRefList.add(node);
			}
		}
		
		return matchedNodeRefList;
	}
	
	public List<NodeRef> validateAndGetValidNodeRefs(List<NodeRef> nodeRefList, String keyName, String keyValue) {
		
		LOGGER.info("#####keyName :: "+keyName);
		LOGGER.info("#####keyValue :: "+keyValue);
		List<NodeRef> nullNodeRefList = new ArrayList<NodeRef>();
		
		List<NodeRef> matchedNodeRefList = new ArrayList<NodeRef>();
		
		boolean isMatched = false;
		
		for(NodeRef nodeRef : nodeRefList) {
			
			String propertyValue = (String) nodeService.getProperty(nodeRef, QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, keyName));
			LOGGER.info("property value ::"+propertyValue);
			if(propertyValue == null || propertyValue.equalsIgnoreCase("") || propertyValue.equalsIgnoreCase("All")) {
				
				nullNodeRefList.add(nodeRef);
				
			//}else if(propertyValue.equalsIgnoreCase(keyValue)) {
			}else if(keyValue.contains(propertyValue)) {
				matchedNodeRefList.add(nodeRef);
				isMatched = true;
			}
		}
		
		if(isMatched) {
			
			return matchedNodeRefList;
			
		}
		
		return nullNodeRefList;
		
	}
	
	@SuppressWarnings("unchecked")
	public String generateOutputJSON(List<NodeRef> nodeRefList, String[] outputValuesArray) {
		
		LOGGER.info("$$$$$nodeRefList :: "+nodeRefList);
		LOGGER.info("$$$$$outputValuesArray :: "+outputValuesArray);
		JSONObject responseObj = new JSONObject();;
		//StringBuilder stringBuilder = new StringBuilder();
		
		//stringBuilder.append("{");
		
		int index = 0;
		
		for(String outputValue : outputValuesArray) {
			LOGGER.info("$$$$$outputValue :: "+outputValue);
			
			
			
			
			
			if(index > 0) {
				
				//stringBuilder.append(",");
				
			}
			
			//stringBuilder.append("\""+outputValue+"\"");
			
			//stringBuilder.append(":");
			
			List<AssociationRef> usersList = null;
			
			if(nodeRefList!=null && nodeRefList.size()>0) {
				usersList = nodeService.getTargetAssocs(nodeRefList.get(0), QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, outputValue));
			}
			
			//stringBuilder.append("\""+nodeService.getProperty(nodeRefList.get(0), QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, outputValue))+"\"");
			if(usersList!=null && usersList.size()>0) {
				
				AssociationRef userAssoc = usersList.get(0);
				//String nameSPacePrefix = userAssoc.getTypeQName().getPrefixString();
				String nameSPaceURI = userAssoc.getTypeQName().getNamespaceURI();
				//LOGGER.info("nameSPacePrefix :: "+nameSPacePrefix);
				LOGGER.info("nameSPaceURI :: "+nameSPaceURI);
				var userSSO = "";
				var fullName = "";
				
				if(outputValue.contains("admin") || outputValue.contains("publish") ) {
					userSSO = (String) nodeService.getProperty(userAssoc.getTargetRef(), ContentModel.PROP_USERNAME);
					fullName = (String) nodeService.getProperty(userAssoc.getTargetRef(), ContentModel.PROP_FIRSTNAME) +" "+
							(String) nodeService.getProperty(userAssoc.getTargetRef(), ContentModel.PROP_LASTNAME);
				} else {
					userSSO = (String) nodeService.getProperty(userAssoc.getTargetRef(), QName.createQName(nameSPaceURI, "employee_sso"));
					fullName = (String) nodeService.getProperty(userAssoc.getTargetRef(), QName.createQName(nameSPaceURI, "employee_full_name"));
				}
				
				JSONObject propsObj = new JSONObject();
				propsObj.put("userName", userSSO);
				propsObj.put("name", fullName);
				
				JSONObject nodeObj = new JSONObject();
				
				nodeObj.put("typeShort", "cm:person");
				nodeObj.put("isContainer", false);
				nodeObj.put("nodeRef", userAssoc.getTargetRef().toString());
				nodeObj.put("properties", propsObj);
				
				LOGGER.info("nodeObj :: \n"+nodeObj);
				//responseObj.put("urm_intake_user", nodeObj);
				responseObj.put(outputValue, nodeObj);
				
				LOGGER.info("responseObj :: \n"+responseObj);
				
				LOGGER.info("responseObj.toString() :: \n"+responseObj.toString());
				
				LOGGER.info("responseObj.toString() :: \n"+responseObj.toJSONString());
				
				//stringBuilder.append("\""+usersList.get(0).getTargetRef()+"\"");
			}
			
			//index++;
			
		}
		
		//stringBuilder.append("}");
		
		//return stringBuilder.toString();
		return responseObj.toString();
		
	}
	
	public String executeAndGetResponseJSON(String strSiteName, String dataListType, Set<String> jsonKeySet, JSONObject jsonObject, String[] outputValuesArray) {
		
		List<NodeRef> nodeRefList = getNodeRefsForGivenSiteAndDatalistType(strSiteName,dataListType);
		LOGGER.info("$$$$$nodeRefList-1 ::"+nodeRefList);
		Iterator<String> iterator = jsonKeySet.iterator();
		
		while(iterator.hasNext()) {
			
			String keyName = iterator.next();
			
			String keyValue = null;
			keyValue = (String) jsonObject.get(keyName);
			
			nodeRefList = validateAndGetValidNodeRefs(nodeRefList, keyName, keyValue);
			
		}
		LOGGER.info("$$$$$nodeRefList-2 ::"+nodeRefList);
		
		return generateOutputJSON(nodeRefList, outputValuesArray);
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		
		String uName = getuName();

		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Void>() {
			@Override
			public Void doWork() throws Exception {
				customExecute(req, res);
				return null;
			}
		}, uName);
		
	}
	
	public void customExecute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		LOGGER.info("In execute method");
		Map<String, String> templateVariables = req.getServiceMatch().getTemplateVars();
		
		String strSiteName = templateVariables.get("site");
		LOGGER.info("strSiteName ::" +strSiteName);
		
		String dataListType = templateVariables.get("datalisttype");
		
		LOGGER.info("dataListType ::" +dataListType);
		//String outputValues = "urm_intake_user,urm_admin_user,urm_reviewer_user";
		
		String outputValues = getOutputValues();
		
		String[] outputValuesArray = outputValues.split(",");
		
		String inputJson = req.getContent().getContent();
		
		JSONParser jsonParser = new JSONParser();
		
		JSONObject reqJsonObject = null;
		JSONObject jsonObject = null;
		
		Set<String> jsonKeySet = null;
		
		boolean isValidRequest = true;
		
		try {
			
			if(inputJson != null) {
				LOGGER.info("input Json not null");
				LOGGER.info("1 - \n"+inputJson);
				inputJson = inputJson.toString();
				LOGGER.info("2 - \n"+inputJson);
			    reqJsonObject = (JSONObject) jsonParser.parse(inputJson);
				LOGGER.info("3 - \n"+reqJsonObject);
				
				jsonObject = reqJsonObject;
				
				String nodeRef=(String) reqJsonObject.get("nodeRef");
				LOGGER.info("nodeRef is ::"+nodeRef);
				if(nodeRef != null && nodeRef != "") {
					NodeRef node=new NodeRef(nodeRef);
					String productCompany=(String)nodeService.getProperty(node, BHContentModelConstants.PC_QNAME);
					List<String> productLine=(List<String>)nodeService.getProperty(node, BHContentModelConstants.PL_QNAME);
					List<String> subProductLine=(List<String>)nodeService.getProperty(node, BHContentModelConstants.SPL_QNAME);
					List<String> pcSite=(List<String>)nodeService.getProperty(node, BHContentModelConstants.SITE_QNAME);
					List<String> function=(List<String>)nodeService.getProperty(node, BHContentModelConstants.FUNCTION_QNAME);
					String subFunction=(String)nodeService.getProperty(node, BHContentModelConstants.SUBFUNCTION_QNAME);
					String documentType=(String)nodeService.getProperty(node, BHContentModelConstants.DT_QNAME);
					
					jsonObject.remove("nodeRef");
					
					if(productCompany != null)
						jsonObject.put("urm_product_company", productCompany.toString());
					if(productLine != null)
						jsonObject.put("urm_product_line", productLine.toString());
					if(subProductLine != null)
						jsonObject.put("urm_sub_product_line", subProductLine.toString());
					if(pcSite != null)	
						jsonObject.put("urm_site", pcSite.toString());
					if(function != null)
						jsonObject.put("urm_function", function.toString());
					if(subFunction != null)
						jsonObject.put("urm_sub_function", subFunction.toString());
					if(documentType != null)
						jsonObject.put("urm_document_type", documentType.toString());
				}
				
				if(jsonObject.keySet().size()>0) {
					LOGGER.info("JSON key set size >0");
					jsonKeySet = jsonObject.keySet();
					
					isValidRequest = isValidRequest(strSiteName, dataListType, jsonKeySet);
					
					if(isValidRequest) {
						LOGGER.info("isValidRequest ::"+isValidRequest);
						String outputJSON =  executeAndGetResponseJSON(strSiteName,dataListType, jsonKeySet, jsonObject, outputValuesArray);
						
						LOGGER.info("outputJSON ::"+outputJSON);
						res.getWriter().write(outputJSON);
						
					}
					
				}
				
			}
			
		} catch (ParseException e) {
			
			e.printStackTrace();
			
		}
	}

	public String getOutputValues() {
		return outputValues;
	}

	public void setOutputValues(String outputValues) {
		this.outputValues = outputValues;
	}

	public String getActiveProperty() {
		return activeProperty;
	}

	public void setActiveProperty(String activeProperty) {
		this.activeProperty = activeProperty;
	}
	
	

}
