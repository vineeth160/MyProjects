package com.bh.alfresco.qms.webscripts.reports;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.admin.SysAdminParams;
import org.alfresco.repo.model.Repository;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchParameters;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.util.UrlUtil;
import org.apache.chemistry.opencmis.commons.impl.json.JSONArray;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.plexus.util.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.bh.alfresco.qms.constants.BHContentModelConstants;

public class QMSReportUtils {

	private static final String[] formats = { "dd/mm/yyyy", "dd-MMM-yyyy", "yyyyMMdd" };

	private static final Log logger = LogFactory.getLog(QMSReportUtils.class);

	//DateFormat alfrescoDateFormat = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
	DateFormat alfrescoDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

	private static final String NAME = "name";
	private static final String DOC_REFERENCE = "docReference";
	private static final String PRODUCT_COMPANY = "productCompany";
	private static final String PRODUCT_LINE = "productLine";
	private static final String SUB_PRODUCT_LINE = "subProductLine";
	private static final String FUNCTION = "bhFunction";
	private static final String SUB_FUNCTION = "subFunction";
	private static final String SITE = "site";
	private static final String DOC_TYPE = "docType";
	private static final String ISO_ELEMENT = "isoElement";
	private static final String USER_ROLE = "userRole";
	private static final String PROCESS = "process";
	private static final String SUB_PROCESS = "subProcess";
	private static final String CONTENT_CATEGORY = "contentCategory";
	private static final String LANGUAGE = "language";
	private static final String DOC_AUTHOR = "docAuthor";
	private static final String DOC_ADMIN = "docAdmin";
	private static final String FUN_OWNER = "funOwner";
	private static final String DOC_STATE = "docState";
	private static final String DCTM_ID = "dctmId";
	private static final String EFFECTIVE_FROM = "effectiveFrom";
	private static final String EFFECTIVE_TO = "effectiveTo";
	private static final String PUBLISH_FROM = "publishFrom";
	private static final String PUBLISH_TO = "publishTo";
	private static final String EXPIRY_FROM = "expiryFrom";
	private static final String EXPIRY_TO = "expiryTo";

	private ServiceRegistry serviceRegistry;
	private Repository repository;
	private SysAdminParams sysAdminParams;


	public SysAdminParams getSysAdminParams() {
		return sysAdminParams;
	}


	public void setSysAdminParams(SysAdminParams sysAdminParams) {
		this.sysAdminParams = sysAdminParams;
	}


	/**
	 * 
	 * @param serviceRegistry
	 */
	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}


	/**
	 * 
	 * @param repository
	 */
	public void setRepository(Repository repository) {
		this.repository = repository;
	}


	/**
	 * 
	 * @param req
	 * @return nodeRefList, based on final query results
	 */
	List<NodeRef> getResultNodes(WebScriptRequest req) {

		List<NodeRef> nodeRefList = null;

		StringBuffer getQueryParam = new StringBuffer("TYPE:\"bhqms:iso_qty_manual\"");

		if(StringUtils.isNotBlank(req.getParameter(NAME))) {
			getQueryParam.append(" AND ");
			getQueryParam.append("(");
			getQueryParam.append("@cm\\:name:\"");
			getQueryParam.append(req.getParameter(NAME));
			getQueryParam.append("\")");
		}

		if(StringUtils.isNotBlank(req.getParameter(DOC_REFERENCE))) {
			getQueryParam = formSingleValueQuery("reference", getQueryParam, req.getParameter(DOC_REFERENCE));
		}

		if(StringUtils.isNotBlank(req.getParameter(PRODUCT_COMPANY))) {
			getQueryParam = formSingleValueQuery("product_company", getQueryParam, req.getParameter(PRODUCT_COMPANY));
		}

		if(StringUtils.isNotBlank(req.getParameter(PRODUCT_LINE))) {
			getQueryParam = formMultiValueQuery("product_line", getQueryParam, req.getParameter(PRODUCT_LINE));
		}

		if(StringUtils.isNotBlank(req.getParameter(SUB_PRODUCT_LINE))) {
			getQueryParam = formMultiValueQuery("sub_product_line", getQueryParam, req.getParameter(SUB_PRODUCT_LINE));
		}

		if(StringUtils.isNotBlank(req.getParameter(SITE))) {
			getQueryParam = formMultiValueQuery("site", getQueryParam, req.getParameter(SITE));
		}

		if(StringUtils.isNotBlank(req.getParameter(FUNCTION))) {
			getQueryParam = formMultiValueQuery("function", getQueryParam, req.getParameter(FUNCTION));
		}

		if(StringUtils.isNotBlank(req.getParameter(SUB_FUNCTION))) {
			getQueryParam = formSingleValueQuery("sub_function", getQueryParam, req.getParameter(SUB_FUNCTION));
		}

		if(StringUtils.isNotBlank(req.getParameter(DOC_TYPE))) {
			getQueryParam = formSingleValueQuery("document_type", getQueryParam, req.getParameter(DOC_TYPE));
		}

		if(StringUtils.isNotBlank(req.getParameter(ISO_ELEMENT))) {
			getQueryParam = formMultiValueQuery("iso_element", getQueryParam, req.getParameter(ISO_ELEMENT));
		}

		if(StringUtils.isNotBlank(req.getParameter(USER_ROLE))) {
			getQueryParam = formMultiValueQuery("user_role", getQueryParam, req.getParameter(USER_ROLE));
		}

		if(StringUtils.isNotBlank(req.getParameter(PROCESS))) {
			getQueryParam = formMultiValueQuery("process", getQueryParam, req.getParameter(PROCESS));
		}

		if(StringUtils.isNotBlank(req.getParameter(SUB_PROCESS))) {
			getQueryParam = formMultiValueQuery("sub_process", getQueryParam, req.getParameter(SUB_PROCESS));
		}

		if(StringUtils.isNotBlank(req.getParameter(CONTENT_CATEGORY))) {
			getQueryParam = formSingleValueQuery("content_category", getQueryParam, req.getParameter(CONTENT_CATEGORY));
		}

		if(StringUtils.isNotBlank(req.getParameter(LANGUAGE))) {
			getQueryParam = formSingleValueQuery("language_code", getQueryParam, req.getParameter(LANGUAGE));
		}

		if(StringUtils.isNotBlank(req.getParameter(DOC_AUTHOR))) {
			getQueryParam = formSingleValueQuery("document_author_noderef", getQueryParam, req.getParameter(DOC_AUTHOR));
		}

		if(StringUtils.isNotBlank(req.getParameter(DOC_ADMIN))) {
			getQueryParam = formSingleValueQuery("document_admin_noderef", getQueryParam, req.getParameter(DOC_ADMIN));
		}

		if(StringUtils.isNotBlank(req.getParameter(FUN_OWNER))) {
			getQueryParam = formSingleValueQuery("functional_owner_noderef", getQueryParam, req.getParameter(FUN_OWNER));
		}

		if(StringUtils.isNotBlank(req.getParameter(DOC_STATE))) {
			getQueryParam = formSingleValueQuery("document_state", getQueryParam, req.getParameter(DOC_STATE));
		}

		if(StringUtils.isNotBlank(req.getParameter(DCTM_ID))) {
			getQueryParam = formSingleValueQuery("dctm_object_id", getQueryParam, req.getParameter(DCTM_ID));
		}

		if(StringUtils.isNotBlank(req.getParameter(EFFECTIVE_FROM)) || StringUtils.isNotBlank(req.getParameter(EFFECTIVE_TO))) {
			getQueryParam = formDateQuery("effective_date", getQueryParam, req.getParameter(EFFECTIVE_FROM), req.getParameter(EFFECTIVE_TO));
		}	

		if(StringUtils.isNotBlank(req.getParameter(EXPIRY_FROM)) || StringUtils.isNotBlank(req.getParameter(EXPIRY_TO))) {
			getQueryParam = formDateQuery("expiry_date", getQueryParam, req.getParameter(EXPIRY_FROM), req.getParameter(EXPIRY_TO));
		}

		if(StringUtils.isNotBlank(req.getParameter(PUBLISH_FROM)) || StringUtils.isNotBlank(req.getParameter(PUBLISH_TO))) {
			getQueryParam = formDateQuery("published_date", getQueryParam, req.getParameter(PUBLISH_FROM), req.getParameter(PUBLISH_TO));
		}

		if(logger.isInfoEnabled()) {
			logger.info("Query :: "+getQueryParam.toString());
		}

		ResultSet results=null;
		try {
			results = getResultSet(getQueryParam.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(results!=null) { 
			nodeRefList = results.getNodeRefs();
			if(logger.isDebugEnabled()) {
				logger.debug("listNodes size :: "+nodeRefList.size());
			}
			if(logger.isInfoEnabled()) {
				logger.info("Fetched records  size for the given criteria :: "+nodeRefList.size());
			}
		}

		return nodeRefList;
	}


	/**
	 * 
	 * @param fieldQName
	 * @param getQueryParam
	 * @param fieldValue
	 * @return multi valued query parameter
	 */
	private StringBuffer formMultiValueQuery(String fieldQName, StringBuffer getQueryParam, String fieldValue) {

		List<String> fieldList = Arrays.asList(fieldValue.split("\\s*,\\s*"));
		getQueryParam.append(fieldList.stream().collect(
				Collectors.joining("' OR =@bhqms\\:"+fieldQName+":'", " AND (=@bhqms\\:"+fieldQName+":'", "')")));

		return getQueryParam;
	}


	/**
	 * 
	 * @param fieldQName
	 * @param getQueryParam
	 * @param fieldValue
	 * @return single valued query parameter
	 */
	private StringBuffer formSingleValueQuery(String fieldQName, StringBuffer getQueryParam, String fieldValue) {
		getQueryParam.append(" AND ");
		getQueryParam.append("(");
		getQueryParam.append("@bhqms\\:"+fieldQName+":\"");
		getQueryParam.append(fieldValue);
		getQueryParam.append("\")");

		return getQueryParam;
	}


	/**
	 * 
	 * @param typeOfDate
	 * @param getQueryParam
	 * @param fromDate
	 * @param toDate
	 * @return query parameter based on from and to date
	 */
	private StringBuffer formDateQuery(String dateFieldQName, StringBuffer getQueryParam, String fromDate, String toDate) {
		String formatedFromDate =null,formatedToDate =null;
		if(StringUtils.isNotBlank(fromDate)) {
			formatedFromDate = getAlfrescoDateString(fromDate);
		} else {
			formatedFromDate = "MIN";
		}
		if(StringUtils.isNotBlank(toDate)) {
			formatedToDate = getAlfrescoDateString(toDate);
		} else {
			formatedToDate = "MAX";
		}
		getQueryParam.append(" AND ");
		getQueryParam.append("(");
		getQueryParam.append("@bhqms\\:"+dateFieldQName+":[");
		getQueryParam.append(formatedFromDate);
		getQueryParam.append(" TO ");
		getQueryParam.append(formatedToDate);
		getQueryParam.append("])");

		if(logger.isDebugEnabled()) {
			logger.debug("Query in formDateQuery :: "+getQueryParam);
		}

		return getQueryParam;
	}

	/**
	 * 
	 * @param fromDate
	 * @return getAlfrescoDateInString
	 */
	
	private String getAlfrescoDateString(String fromDate) {
		DateFormat dateFormat = null;
		for (String strFormat : formats) {
			dateFormat = new SimpleDateFormat(strFormat);
			try {
				Date parseDate = dateFormat.parse(fromDate);
				return alfrescoDateFormat.format(parseDate).toString(); 
			} catch (ParseException e) {
			}
		}
		return null;
	}

	/**
	 * 
	 * @param nodeResultSet
	 * @return Array Properties
	 * @throws JSONException
	 */
	@SuppressWarnings("unchecked")
	public JSONArray generateModelForListView(List<NodeRef> nodeResultSet) throws JSONException {
		JSONArray mapOfResult = new JSONArray();
		for (NodeRef nodeRef : nodeResultSet) {

			String name = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NAME);
			String reference = (String) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_REFERENCE_QNAME);
			String productCompany = (String) serviceRegistry.getNodeService().getProperty(nodeRef,BHContentModelConstants.PC_QNAME);
			List<String> productLine = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PL_QNAME);
			List<String> subProductLine = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef,BHContentModelConstants.SPL_QNAME);
			List<String> function = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.FUNCTION_QNAME);
			List<String> site = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.SITE_QNAME);
			String subFunction = (String) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.SUBFUNCTION_QNAME);
			String docType = (String) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.DT_QNAME);
			List<String> isoElement = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_ISO_ELEMENT_QNAME);
			List<String> userRole = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_USER_ROLE_QNAME);
			List<String> process = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_PROCESS_QNAME);
			List<String> subProcess = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef,BHContentModelConstants.PROP_SUB_PROCESS_QNAME);
			String contentCategory = (String) serviceRegistry.getNodeService().getProperty(nodeRef,BHContentModelConstants.PROP_CONTENT_CATEGORY_QNAME);
			String language = (String) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_LANGUAGE_CODE_QNAME);
			String docState =(String) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_DOCUMENT_STATE_QNAME);
			String revisionNo =(String) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_PR_QNAME);
			String docAuthorNoderef =(String)serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_DOC_AUTHOR_NODEREF);
			String docAdminNoderef =(String)serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_DOC_ADMIN_NODEREF);
			String funOwnerNoderef =(String)serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_FUN_ONWER_NODEREF);
			Date publishedate = (Date)serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_PUBLISHED_DATE_QNAME);
			Date expiryDate = (Date)serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_EXPIRY_DATE_QNAME);
			Date effectiveDate = (Date)serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_EFFECTIVE_DATE_QNAME);

			String nodePublishDate ="";
			String nodeExpiryDate ="";
			String nodeEffectiveDate ="";
			if(publishedate!=null)
				nodePublishDate = publishedate.toString();
			if(expiryDate!=null)
				nodeExpiryDate = expiryDate.toString();
			if(effectiveDate!=null)
				nodeEffectiveDate = effectiveDate.toString();

			// Map<String, String> nodeMapForListView = new HashMap<String, String>();
			JSONObject nodeMapForListView = new JSONObject();

			nodeMapForListView.put("name", name);
			nodeMapForListView.put("reference", reference);
			nodeMapForListView.put("productCompany", productCompany);
			if(productLine!=null && productLine.size()>0) {
				nodeMapForListView.put("productLine", String.join(",", productLine));
			}
			if(subProductLine!=null && subProductLine.size()>0) {
				nodeMapForListView.put("subProductLine",  String.join(",", subProductLine));
			}
			if(function!=null && function.size()>0) {
				nodeMapForListView.put("bhFunction", String.join(",", function));
			}
			if(site!=null && site.size()>0) {
				nodeMapForListView.put("site", String.join(",", site));
			}
			nodeMapForListView.put("subFunction", subFunction);
			nodeMapForListView.put("docType", docType);

			if(isoElement!=null && isoElement.size()>0) {
				nodeMapForListView.put("isoElement", String.join(",", isoElement));
			}
			if(userRole!=null && userRole.size()>0) {
				nodeMapForListView.put("userRole", String.join(",", userRole));
			}
			if(process!=null && process.size()>0) {
				nodeMapForListView.put("process", String.join(",", process));
			}
			if(subProcess!=null && subProcess.size()>0) {
				nodeMapForListView.put("subProcess", String.join(",", subProcess));
			}
			nodeMapForListView.put("contentCategory", contentCategory);
			nodeMapForListView.put("language", language);
			nodeMapForListView.put("docState", docState);
			nodeMapForListView.put("revisionNo", revisionNo);
			nodeMapForListView.put("expiryDate", nodeExpiryDate);
			nodeMapForListView.put("effectiveDate", nodeEffectiveDate);
			nodeMapForListView.put("publishedDate", nodePublishDate);
			nodeMapForListView.put("nodeRef", nodeRef.toString());

			logger.debug("docAuthorNoderef :: "+docAuthorNoderef);
			if(!StringUtils.isBlank(docAuthorNoderef) && !"null".equals(docAuthorNoderef)) {
				NodeRef docAuthorRef =new NodeRef(docAuthorNoderef);
				String docAuthorName =(String)serviceRegistry.getNodeService().getProperty(docAuthorRef, BHContentModelConstants.PROP_FULLNAME);
				logger.debug("docAuthorName :: "+docAuthorName);
				nodeMapForListView.put("docAuthorName", docAuthorName);
			}

			logger.debug("docAdminNoderef :: "+docAdminNoderef);
			if(!StringUtils.isBlank(docAdminNoderef) && !"null".equals(docAdminNoderef)) {
				NodeRef docAdminRef =new NodeRef(docAdminNoderef);
				String docAdminFirstName =(String)serviceRegistry.getNodeService().getProperty(docAdminRef, ContentModel.PROP_FIRSTNAME);
				String docAdminLastName =(String)serviceRegistry.getNodeService().getProperty(docAdminRef, ContentModel.PROP_LASTNAME);
				String docAdminName = docAdminFirstName+" "+docAdminLastName;
				logger.debug("docAdminName :: "+docAdminName);
				nodeMapForListView.put("docAdminName", docAdminName);
			}

			logger.debug("funOwnerNoderef Updated :: "+funOwnerNoderef);
			if(!StringUtils.isBlank(funOwnerNoderef) && !"null".equals(funOwnerNoderef)) {
				logger.debug("funOwnerNoderef Updated :: "+funOwnerNoderef.length());
				NodeRef funOwnerRef =new NodeRef(funOwnerNoderef);
				String funOwnerName =(String)serviceRegistry.getNodeService().getProperty(funOwnerRef, BHContentModelConstants.PROP_FULLNAME);
				logger.debug("funOwnerName :: "+funOwnerName);
				nodeMapForListView.put("funOwnerName", funOwnerName);
			}

			mapOfResult.add(nodeMapForListView);

		}
		
		logger.info("End of getResultNodes() and size of mapOfResult is :: "+mapOfResult.size());
		
		return mapOfResult;

	}


	@SuppressWarnings("unchecked")
	public List<Map<String, String>> dataToGenerateExcel(List<NodeRef> nodeResultSet){
		List<Map<String, String>> dataForExcel = new ArrayList<Map<String, String>>();
		for (NodeRef nodeRef : nodeResultSet) {

			String name = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NAME);
			String reference = (String) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_REFERENCE_QNAME);
			String productCompany = (String) serviceRegistry.getNodeService().getProperty(nodeRef,BHContentModelConstants.PC_QNAME);
			List<String> productLine = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PL_QNAME);
			List<String> subProductLine = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef,BHContentModelConstants.SPL_QNAME);
			List<String> function = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.FUNCTION_QNAME);
			List<String> site = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.SITE_QNAME);
			String subFunction = (String) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.SUBFUNCTION_QNAME);
			String docType = (String) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.DT_QNAME);
			List<String> isoElement = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_ISO_ELEMENT_QNAME);
			List<String> userRole = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_USER_ROLE_QNAME);
			List<String> process = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_PROCESS_QNAME);
			List<String> subProcess = (List<String>) serviceRegistry.getNodeService().getProperty(nodeRef,BHContentModelConstants.PROP_SUB_PROCESS_QNAME);
			String contentCategory = (String) serviceRegistry.getNodeService().getProperty(nodeRef,BHContentModelConstants.PROP_CONTENT_CATEGORY_QNAME);
			String language = (String) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_LANGUAGE_CODE_QNAME);
			String docState =(String) serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_DOCUMENT_STATE_QNAME);
			String docAuthorNoderef =(String)serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_DOC_AUTHOR_NODEREF);
			String docAdminNoderef =(String)serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_DOC_ADMIN_NODEREF);
			String funOwnerNoderef =(String)serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_FUN_ONWER_NODEREF);
			Date publishedate = (Date)serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_PUBLISHED_DATE_QNAME);
			Date expiryDate = (Date)serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_EXPIRY_DATE_QNAME);
			Date effectiveDate = (Date)serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.PROP_EFFECTIVE_DATE_QNAME);

			String nodePublishDate ="";
			String nodeExpiryDate ="";
			String nodeEffectiveDate ="";
			if(publishedate!=null)
				nodePublishDate = publishedate.toString();
			if(expiryDate!=null)
				nodeExpiryDate = expiryDate.toString();
			if(effectiveDate!=null)
				nodeEffectiveDate = effectiveDate.toString();

			Map<String, String> nodeMap = new HashMap<String, String>();

			nodeMap.put("name", name);
			nodeMap.put("reference", reference);
			nodeMap.put("productCompany", productCompany);
			if(productLine!=null && productLine.size()>0) {
				nodeMap.put("productLine", String.join(",", productLine));
			}
			if(subProductLine!=null && subProductLine.size()>0) {
				nodeMap.put("subProductLine",  String.join(",", subProductLine));
			}
			if(function!=null && function.size()>0) {
				nodeMap.put("function", String.join(",", function));
			}
			if(site!=null && site.size()>0) {
				nodeMap.put("site", String.join(",", site));
			}
			nodeMap.put("subFunction", subFunction);
			nodeMap.put("docType", docType);

			if(isoElement!=null && isoElement.size()>0) {
				nodeMap.put("isoElement", String.join(",", isoElement));
			}
			if(userRole!=null && userRole.size()>0) {
				nodeMap.put("userRole", String.join(",", userRole));
			}
			if(process!=null && process.size()>0) {
				nodeMap.put("process", String.join(",", process));
			}
			if(subProcess!=null && subProcess.size()>0) {
				nodeMap.put("subProcess", String.join(",", subProcess));
			}
			nodeMap.put("contentCategory", contentCategory);
			nodeMap.put("language", language);
			nodeMap.put("docState", docState);
			nodeMap.put("expiryDate", nodeExpiryDate);
			nodeMap.put("effectiveDate", nodeEffectiveDate);
			nodeMap.put("publishedDate", nodePublishDate);
			nodeMap.put("nodeRef", nodeRef.toString());

			if(!StringUtils.isBlank(docAuthorNoderef) && !"null".equals(docAuthorNoderef)) {
				NodeRef docAuthorRef =new NodeRef(docAuthorNoderef);
				String docAuthorName =(String)serviceRegistry.getNodeService().getProperty(docAuthorRef, BHContentModelConstants.PROP_FULLNAME);
				nodeMap.put("docAuthorName", docAuthorName);
			}


			if(!StringUtils.isBlank(docAdminNoderef) && !"null".equals(docAdminNoderef)) {
				NodeRef docAdminRef =new NodeRef(docAdminNoderef);
				String docAdminFirstName =(String)serviceRegistry.getNodeService().getProperty(docAdminRef, ContentModel.PROP_FIRSTNAME);
				String docAdminLastName =(String)serviceRegistry.getNodeService().getProperty(docAdminRef, ContentModel.PROP_LASTNAME);
				String docAdminName = docAdminFirstName+" "+docAdminLastName;
				nodeMap.put("docAdminName", docAdminName);
			}

			if(!StringUtils.isBlank(funOwnerNoderef) && !"null".equals(funOwnerNoderef)) {
				NodeRef funOwnerRef =new NodeRef(funOwnerNoderef);
				String funOwnerName =(String)serviceRegistry.getNodeService().getProperty(funOwnerRef, BHContentModelConstants.PROP_FULLNAME);
				nodeMap.put("funOwnerName", funOwnerName);
			}


			dataForExcel.add(nodeMap);

		}

		return dataForExcel;
	}

	/**
	 * 
	 * @param nodeRef
	 * @return path, 
	 */
	public String getDocumentPropertiesUrl(NodeRef nodeRef) {

		//String baseUrl = UrlUtil.getShareUrl(serviceRegistry.getSysAdminParams());
		String baseUrl = UrlUtil.getShareUrl(sysAdminParams);
		String siteShortName = serviceRegistry.getSiteService().getSiteShortName(nodeRef);
		StringBuilder path = new StringBuilder();
		path.append(baseUrl).append("/page/");
		if (siteShortName != null) {
			path.append("site/").append(siteShortName).append("/");
		}

		path.append("document-details?nodeRef=").append(nodeRef);

		return path.toString();
	}


	/**
	 * 
	 * @param query
	 * @return ResultSet object of given query
	 * @throws IOException
	 */
	public ResultSet getResultSet(String query) throws IOException {
		ResultSet results = null;
		if (query != null) {			
			SearchParameters sp = new SearchParameters();
			sp.addStore(this.repository.getRootHome().getStoreRef());
			sp.setLanguage(SearchService.LANGUAGE_FTS_ALFRESCO);
			sp.setMaxItems(Integer.MAX_VALUE);
			sp.setQuery(query);
			results = this.serviceRegistry.getSearchService().query(sp);			
		}
		return results;
	}

}
