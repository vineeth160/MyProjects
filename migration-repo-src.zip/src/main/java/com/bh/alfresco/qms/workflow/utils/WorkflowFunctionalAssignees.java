/**
 *	Alfresco Functional(System) Users information to map each workflow task based on HR System user selection
 *
 *	$001 - Admin and Publisher assignees have been commented below as those were named users within Alfresco
 *	$001 - Commented data can be uncommented and create respective setters and getters if needed
 *
 *	
 * */

package com.bh.alfresco.qms.workflow.utils;

import org.alfresco.repo.jscript.BaseScopableProcessorExtension;

public class WorkflowFunctionalAssignees extends BaseScopableProcessorExtension{
	
	private String bhwf_ADF_TASK_URL;
	private String bhwf_ADF_DOCUMENT_URL;
	private String bhwf_HISTORY_URL;
	
	/** $001 - Admin and Publisher assignees information starts **/
	
	// Admin and Publisher for Oil Field Services
	
	//private String bhwf_OFS_AdminFU;
	//private String bhwf_OFS_PublisherFU;

	// Admin and Publisher for Turbomachinery & Process Solutions
	
	//private String bhwf_TPS_AdminFU;
	//private String bhwf_TPS_PublisherFU;
	
	// Admin and Publisher for Digital Solutions
	
	//private String bhwf_DS_AdminFU;
	//private String bhwf_DS_PublisherFU;
	
	/** $001 - Admin and Publisher assignees information ends **/

	// Functional Users for Oil Field Services Workflows
	private String bhwf_OFS_SubmitterFU;
	private String bhwf_OFS_IntakesFU;
	private String bhwf_OFS_SmeFU;
	private String bhwf_OFS_ReviewerFU;
	private String bhwf_OFS_ApproverFU;
	private String bhwf_OFS_ArchivalFU;
	
	
	// Functional Users for Digital Solutions Workflows
	private String bhwf_DS_SubmitterFU;
	private String bhwf_DS_ReviewerFU;
	private String bhwf_DS_ApproverFU;

	
	// Functional Users for TPS Workflows
	private String bhwf_TPS_SubmitterFU;
	private String bhwf_TPS_ReviewerFU;
	private String bhwf_TPS_ApproverFU;
	
	
	// Functional Users for GLOBAL Workflows
	private String bhwf_GLOBAL_SubmitterFU;
	private String bhwf_GLOBAL_ReviewerFU;
	private String bhwf_GLOBAL_ApproverFU;
	
	
	// Functional Users for Legal Workflows
	private String bhwf_LEGAL_ArchivalFU;

	// Functional Users for LEGAL, Setter and Getter
	public String getBhwf_LEGAL_ArchivalFU() {
		return bhwf_LEGAL_ArchivalFU;
	}

	public void setBhwf_LEGAL_ArchivalFU(String bhwf_LEGAL_ArchivalFU) {
		this.bhwf_LEGAL_ArchivalFU = bhwf_LEGAL_ArchivalFU;
	}

	// Functional Users for OFS, Setter and Getter
	public String getBhwf_OFS_SubmitterFU() {
		return bhwf_OFS_SubmitterFU;
	}

	public void setBhwf_OFS_SubmitterFU(String bhwf_OFS_SubmitterFU) {
		this.bhwf_OFS_SubmitterFU = bhwf_OFS_SubmitterFU;
	}

	public String getBhwf_OFS_IntakesFU() {
		return bhwf_OFS_IntakesFU;
	}

	public void setBhwf_OFS_IntakesFU(String bhwf_OFS_IntakesFU) {
		this.bhwf_OFS_IntakesFU = bhwf_OFS_IntakesFU;
	}

	public String getBhwf_OFS_SmeFU() {
		return bhwf_OFS_SmeFU;
	}

	public void setBhwf_OFS_SmeFU(String bhwf_OFS_SmeFU) {
		this.bhwf_OFS_SmeFU = bhwf_OFS_SmeFU;
	}

	public String getBhwf_OFS_ReviewerFU() {
		return bhwf_OFS_ReviewerFU;
	}

	public void setBhwf_OFS_ReviewerFU(String bhwf_OFS_ReviewerFU) {
		this.bhwf_OFS_ReviewerFU = bhwf_OFS_ReviewerFU;
	}

	public String getBhwf_OFS_ApproverFU() {
		return bhwf_OFS_ApproverFU;
	}

	public void setBhwf_OFS_ApproverFU(String bhwf_OFS_ApproverFU) {
		this.bhwf_OFS_ApproverFU = bhwf_OFS_ApproverFU;
	}

	public String getBhwf_OFS_ArchivalFU() {
		return bhwf_OFS_ArchivalFU;
	}

	public void setBhwf_OFS_ArchivalFU(String bhwf_OFS_ArchivalFU) {
		this.bhwf_OFS_ArchivalFU = bhwf_OFS_ArchivalFU;
	}

	// Functional Users for DS, Setter and Getter
	public String getBhwf_DS_SubmitterFU() {
		return bhwf_DS_SubmitterFU;
	}

	public void setBhwf_DS_SubmitterFU(String bhwf_DS_SubmitterFU) {
		this.bhwf_DS_SubmitterFU = bhwf_DS_SubmitterFU;
	}

	public String getBhwf_DS_ReviewerFU() {
		return bhwf_DS_ReviewerFU;
	}

	public void setBhwf_DS_ReviewerFU(String bhwf_DS_ReviewerFU) {
		this.bhwf_DS_ReviewerFU = bhwf_DS_ReviewerFU;
	}

	public String getBhwf_DS_ApproverFU() {
		return bhwf_DS_ApproverFU;
	}

	public void setBhwf_DS_ApproverFU(String bhwf_DS_ApproverFU) {
		this.bhwf_DS_ApproverFU = bhwf_DS_ApproverFU;
	}

	// Functional Users for TPS, Setter and Getter
	public String getBhwf_TPS_SubmitterFU() {
		return bhwf_TPS_SubmitterFU;
	}

	public void setBhwf_TPS_SubmitterFU(String bhwf_TPS_SubmitterFU) {
		this.bhwf_TPS_SubmitterFU = bhwf_TPS_SubmitterFU;
	}

	public String getBhwf_TPS_ReviewerFU() {
		return bhwf_TPS_ReviewerFU;
	}

	public void setBhwf_TPS_ReviewerFU(String bhwf_TPS_ReviewerFU) {
		this.bhwf_TPS_ReviewerFU = bhwf_TPS_ReviewerFU;
	}

	public String getBhwf_TPS_ApproverFU() {
		return bhwf_TPS_ApproverFU;
	}

	public void setBhwf_TPS_ApproverFU(String bhwf_TPS_ApproverFU) {
		this.bhwf_TPS_ApproverFU = bhwf_TPS_ApproverFU;
	}
	
	// Functional Users for GLOBAL, Setter and Getter
	public String getBhwf_GLOBAL_SubmitterFU() {
		return bhwf_GLOBAL_SubmitterFU;
	}

	public void setBhwf_GLOBAL_SubmitterFU(String bhwf_GLOBAL_SubmitterFU) {
		this.bhwf_GLOBAL_SubmitterFU = bhwf_GLOBAL_SubmitterFU;
	}

	public String getBhwf_GLOBAL_ReviewerFU() {
		return bhwf_GLOBAL_ReviewerFU;
	}

	public void setBhwf_GLOBAL_ReviewerFU(String bhwf_GLOBAL_ReviewerFU) {
		this.bhwf_GLOBAL_ReviewerFU = bhwf_GLOBAL_ReviewerFU;
	}

	public String getBhwf_GLOBAL_ApproverFU() {
		return bhwf_GLOBAL_ApproverFU;
	}

	public void setBhwf_GLOBAL_ApproverFU(String bhwf_GLOBAL_ApproverFU) {
		this.bhwf_GLOBAL_ApproverFU = bhwf_GLOBAL_ApproverFU;
	}

	
	public String getAssignees(String userName) {
		
		if("bhwf_OFS_SubmitterFU".equals(userName))
			userName = bhwf_OFS_SubmitterFU;
		
		if("bhwf_OFS_IntakesFU".equals(userName))
			userName = bhwf_OFS_IntakesFU;
		
		if("bhwf_OFS_SmeFU".equals(userName))
			userName = bhwf_OFS_SmeFU;
		
		if("bhwf_OFS_ReviewerFU".equals(userName))
			userName = bhwf_OFS_ReviewerFU;
		
		if("bhwf_OFS_ApproverFU".equals(userName))
			userName = bhwf_OFS_ApproverFU;
		
		if("bhwf_OFS_ArchivalFU".equals(userName))
			userName = bhwf_OFS_ArchivalFU;
		
		if("bhwf_DS_SubmitterFU".equals(userName))
			userName = bhwf_DS_SubmitterFU;
		
		if("bhwf_DS_ReviewerFU".equals(userName))
			userName = bhwf_DS_ReviewerFU;
		
		if("bhwf_DS_ApproverFU".equals(userName))
			userName = bhwf_DS_ApproverFU;
		
		if("bhwf_TPS_SubmitterFU".equals(userName))
			userName = bhwf_TPS_SubmitterFU;
		
		if("bhwf_TPS_ReviewerFU".equals(userName))
			userName = bhwf_TPS_ReviewerFU;
		
		if("bhwf_TPS_ApproverFU".equals(userName))
			userName = bhwf_TPS_ApproverFU;
		
		if("bhwf_GLOBAL_SubmitterFU".equals(userName))
			userName = bhwf_GLOBAL_SubmitterFU;
		
		if("bhwf_GLOBAL_ReviewerFU".equals(userName))
			userName = bhwf_GLOBAL_ReviewerFU;
		
		if("bhwf_GLOBAL_ApproverFU".equals(userName))
			userName = bhwf_GLOBAL_ApproverFU;
		
		return userName;
	}
	
	
	public String getBhwf_ADF_TASK_URL() {
		return bhwf_ADF_TASK_URL;
	}

	public void setBhwf_ADF_TASK_URL(String bhwf_ADF_TASK_URL) {
		this.bhwf_ADF_TASK_URL = bhwf_ADF_TASK_URL;
	}
	
	public String getBhwf_ADF_DOCUMENT_URL() {
		return bhwf_ADF_DOCUMENT_URL;
	}

	public void setBhwf_ADF_DOCUMENT_URL(String bhwf_ADF_DOCUMENT_URL) {
		this.bhwf_ADF_DOCUMENT_URL = bhwf_ADF_DOCUMENT_URL;
	}
	
	public String getBhwf_HISTORY_URL() {
		return bhwf_HISTORY_URL;
	}

	public void setBhwf_HISTORY_URL(String bhwf_HISTORY_URL) {
		this.bhwf_HISTORY_URL = bhwf_HISTORY_URL;
	}
	
	public String getWorkflowDetails(String adfURL) {
		if(adfURL.equals("adfTaskURL"))
			adfURL = bhwf_ADF_TASK_URL;
		if(adfURL.equals("adfDocumentURL"))
			adfURL = bhwf_ADF_DOCUMENT_URL;
		if(adfURL.equals("wfHistoryURL"))
			adfURL = bhwf_HISTORY_URL;
		
		return adfURL;
	}
}
