package com.bh.alfresco.qms.workflow.utils;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.jscript.BaseScopableProcessorExtension;
import org.alfresco.service.cmr.coci.CheckOutCheckInService;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionService;
import org.alfresco.service.cmr.version.VersionType;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bh.alfresco.qms.constants.BHContentModelConstants;

public class PublishAsSameRevision extends BaseScopableProcessorExtension {
	
	private static Log logger = LogFactory.getLog(PublishAsSameRevision.class);

	private transient NodeService nodeService;
	private transient CheckOutCheckInService checkOutCheckInService;
	private transient ContentService contentService;
	private transient VersionService versionService;
	
	public NodeService getNodeService() {
		return nodeService;
	}
	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}
	public CheckOutCheckInService getCheckOutCheckInService() {
		return checkOutCheckInService;
	}
	public void setCheckOutCheckInService(CheckOutCheckInService checkOutCheckInService) {
		this.checkOutCheckInService = checkOutCheckInService;
	}
	public ContentService getContentService() {
		return contentService;
	}
	public void setContentService(ContentService contentService) {
		this.contentService = contentService;
	}
	public VersionService getVersionService() {
		return versionService;
	}
	public void setVersionService(VersionService versionService) {
		this.versionService = versionService;
	}
	
	public void publishAsSameRevision(String bpmNodeRefString, String publishRevisionRef, String revisionNum, String fileName) throws Exception {
		if(logger.isDebugEnabled()) {
			logger.debug("publishAsSameRevision() method Started IN PublishAsSameRevision");
			logger.debug("bpmNodeRefString :: "+bpmNodeRefString);
		}
		
		NodeRef bpmNodeRef = new NodeRef(bpmNodeRefString);
		NodeRef publishRevisionNodeRef = new NodeRef(publishRevisionRef);
		Boolean isWorkingCopy = nodeService.hasAspect(publishRevisionNodeRef, ContentModel.ASPECT_WORKING_COPY);
		Boolean isLocked = nodeService.hasAspect(publishRevisionNodeRef, ContentModel.ASPECT_LOCKABLE);
		logger.debug("bpmNodeRef :: "+bpmNodeRef);
		logger.debug("publishRevisionNodeRef :: "+publishRevisionNodeRef);
		
		if(Boolean.FALSE == isWorkingCopy && isLocked) {
			throw new Exception("Document is either locked or not a working copy, please check with Administrator");
		} else{
			Version currentVersion = versionService.getCurrentVersion(publishRevisionNodeRef);
			logger.debug("currentVersion ::"+currentVersion);
			boolean isVersioned = versionService.isVersioned(publishRevisionNodeRef);
			int publishVersionSize = versionService.getVersionHistory(publishRevisionNodeRef).getAllVersions().size();
			logger.debug("publishVersionSize :: "+publishVersionSize);
			logger.debug("isVersioned ::"+isVersioned);
			String existingVersionType = currentVersion.getVersionType().toString();
			ContentReader sourceContent = contentService.getReader(bpmNodeRef, ContentModel.PROP_CONTENT);
			logger.debug("existingVersionType :: "+existingVersionType);
//			if(isVersioned && publishVersionSize>1) {
//				versionService.deleteVersion(publishRevisionNodeRef, currentVersion);
//				nodeService.setProperty(publishRevisionNodeRef,BHContentModelConstants.PROP_PR_QNAME, revisionNum);
//				nodeService.setProperty(publishRevisionNodeRef, ContentModel.PROP_NAME, fileName);
//				NodeRef workingNodeRef = checkOutCheckInService.checkout(publishRevisionNodeRef);
//				ContentWriter publishWriter = contentService.getWriter(workingNodeRef, ContentModel.PROP_CONTENT, true);
//				publishWriter.setMimetype(sourceContent.getMimetype());
//				publishWriter.setEncoding("UTF-8");
//				publishWriter.putContent(sourceContent);
//				
//				Map<String, Serializable> properties = new HashMap<String, Serializable>();
//				properties.put(ContentModel.PROP_VERSION_TYPE.getLocalName(), VersionType.valueOf(existingVersionType));
//				//properties.put(ContentModel.PROP_NAME.getLocalName(), fileName);
//				//properties.put(BHContentModelConstants.PROP_PR_QNAME.getLocalName(), revisionNum);
//				
//				checkOutCheckInService.checkin(workingNodeRef, properties);
//				logger.debug("Property Set...");
//				
//			} else {
				/*if (nodeService.hasAspect(publishRevisionNodeRef, ContentModel.ASPECT_VERSIONABLE)) {
                    nodeService.removeAspect(publishRevisionNodeRef, ContentModel.ASPECT_VERSIONABLE);
                }*/
				nodeService.setProperty(publishRevisionNodeRef,ContentModel.PROP_AUTO_VERSION, false);
				nodeService.setProperty(publishRevisionNodeRef,ContentModel.PROP_NAME, fileName);
				ContentWriter publishWriter = contentService.getWriter(publishRevisionNodeRef, ContentModel.PROP_CONTENT, true);
				publishWriter.setMimetype(sourceContent.getMimetype());
				publishWriter.setEncoding("UTF-8");
				publishWriter.putContent(sourceContent);
			//}
			
			if(logger.isDebugEnabled())
				logger.debug("Document revision has been completed without revision change...");
		}
		
	}
}
