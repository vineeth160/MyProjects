package com.bh.alfresco.qms.webscripts.reports;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.admin.SysAdminParams;
import org.alfresco.repo.content.filestore.FileContentWriter;
import org.alfresco.repo.workflow.WorkflowModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.workflow.WorkflowInstance;
import org.alfresco.service.cmr.workflow.WorkflowTask;
import org.alfresco.service.cmr.workflow.WorkflowTaskQuery;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.TempFileProvider;
import org.alfresco.util.UrlUtil;
import org.apache.commons.io.IOUtils;
import org.apache.poi.common.usermodel.HyperlinkType;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;


public class ExportToExcelWS extends AbstractWebScript {

	private ServiceRegistry serviceRegistry;
	private SysAdminParams sysAdminParams;
	private String fileLocation = "..//..//excels//";

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		String idString = null;
		String priorityString = null;

		int i = 0;
		idString = req.getParameter("idString");

		DateFormat alfrescoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.ENGLISH);
		String[] idArray = idString.split(",");
		Map<String,Map<String,Object>> dataForExcelGeneration = new HashMap<String,Map<String,Object>>();
		//Map<String,Object> mapOfWFObjects = new HashMap<String,Object>();
		//List<Map<String, String>> listofTasks = new ArrayList<Map<String, String>>();
		//JSONObject jsonOfWFDetails=new JSONObject();
		
	
		

		for (i = 0; i < idArray.length; i++) {

			WorkflowInstance wfi = serviceRegistry.getWorkflowService().getWorkflowById(idArray[i]);
			
			 	String enddate=null;
			 	Date endDateInAlfresco=null;
			  	String finalenddateformat="none";

			
			    Date startdate=  wfi.getStartDate();
			    DateFormat alfrescoFormatWF = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
			    DateFormat comparingFormat = new SimpleDateFormat("dd/M/yyyy", Locale.ENGLISH);
			    Date startDateInAlfresco=null;
				try {
					startDateInAlfresco = alfrescoFormatWF.parse(startdate.toString());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    String finalstartdateformat=comparingFormat.format(startDateInAlfresco).toString();
			   
			   
			    if(wfi.getEndDate()!=null) {
			     enddate= wfi.getEndDate().toString();
			    
			     try {
			    	 endDateInAlfresco = alfrescoFormatWF.parse(enddate);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			     finalenddateformat=comparingFormat.format(endDateInAlfresco).toString();
			    }
			   
			 
			StringBuilder path = new StringBuilder();
			path.append(UrlUtil.getShareUrl(serviceRegistry.getSysAdminParams())).append("/page/workflow-details?workflowId=");
			String WorkflowDetailsURL=path.append(wfi.getId()).toString();
			JSONObject jsonOfWFDetails=new JSONObject();
					
			try {
				
				 switch (wfi.getPriority()) { 
			        case 1: 
			            priorityString = "High"; 
			            break; 
			        case 2: 
			        	priorityString = "Medium"; 
			            break; 
			        case 3: 
			        	priorityString = "Low"; 
			            break; 
			        default: 
			        	priorityString = "Invalid"; 
			            break; 
			        } 
				
				 
			jsonOfWFDetails.put("wfType", wfi.getDefinition().getTitle());
			//System.out.println("is workflow active::::::"+wfi.isActive());
			jsonOfWFDetails.put("wfStatus", (wfi.isActive()?"Active":"Completed"));
			jsonOfWFDetails.put("wfStartDate", finalstartdateformat);
			jsonOfWFDetails.put("wfEndDate", finalenddateformat);
			jsonOfWFDetails.put("wfDescription", wfi.getDescription().toString());
			jsonOfWFDetails.put("wfPriority",priorityString);
			jsonOfWFDetails.put("wfInitiator", serviceRegistry.getPersonService().getPerson(wfi.getInitiator()).getUserName());
			jsonOfWFDetails.put("wfId",wfi.getId().substring(9));
			jsonOfWFDetails.put("WorkflowDetails",WorkflowDetailsURL);
			}
			catch(JSONException je) {
				je.printStackTrace();
			}
			
			
			List<WorkflowTask> allTasks;
			WorkflowTaskQuery taskQuery = new WorkflowTaskQuery();
			taskQuery.setActive(wfi.isActive());
			taskQuery.setTaskState(null);
			taskQuery.setProcessId(wfi.getId());
			allTasks = serviceRegistry.getWorkflowService().queryTasks(taskQuery, false);
			List<Map<String, String>> listofTasks = new ArrayList<Map<String, String>>();


			for (WorkflowTask wfT : allTasks) {
				
				Map<QName, Serializable> props = wfT.getProperties();
				String taskDef=wfT.getDefinition().getMetadata().getName().getLocalName();
				//String taskDefintion =taskDef.substring(taskDef.lastIndexOf('}'));
				String taskDefintion =taskDef;
				String taskStatus=wfT.getState().toString();
				Date startDate = (Date) props.get(WorkflowModel.PROP_START_DATE);
				String priority = props.get(WorkflowModel.PROP_PRIORITY).toString();
				String id = (String) props.get(WorkflowModel.PROP_TASK_ID);
				String assignedTo = (String) props.get(ContentModel.PROP_OWNER);
				String taskStatusProp = (String) props.get(WorkflowModel.PROP_STATUS);
				
				//System.out.println("taskStatus:::"+taskStatus);
				//System.out.println("taskStatusProp:::::"+taskStatusProp);
	
	
			
	
				Map<String, String> mapOfTaskDetails = new HashMap<String, String>();
				
				
			
				mapOfTaskDetails.put("taskStatus", taskStatusProp);
				mapOfTaskDetails.put("taskstartDate", alfrescoFormat.format(startDate).toString());
				mapOfTaskDetails.put("taskDefintion", taskDefintion);
				mapOfTaskDetails.put("taskid", id);
				mapOfTaskDetails.put("taskpriority", priority);
				mapOfTaskDetails.put("taskOwner",assignedTo);
				listofTasks.add(mapOfTaskDetails);
	
			}
		
			Map<String,Object> mapOfWFObjects = new HashMap<String,Object>();
			mapOfWFObjects.put("wfdetails", jsonOfWFDetails);
			mapOfWFObjects.put("tasksList", listofTasks);
			dataForExcelGeneration.put(wfi.getId(), mapOfWFObjects);
		}
		
	//	System.out.println("size of main map is::+"+dataForExcelGeneration.size());
		try {
			writeToExcel(dataForExcelGeneration);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		File downloadfile = new File(this.fileLocation);

		FileInputStream inputStream = new FileInputStream(downloadfile);
		res.setContentType("application/vnd.ms-excel");
		res.setHeader("Content-disposition", "attachment; filename=" + downloadfile.getName());
		IOUtils.copy(inputStream, res.getOutputStream());

		inputStream.close();

		if (downloadfile.exists()) {
			downloadfile.delete();
		}

	}

	public void writeToExcel(Map<String,Map<String,Object>> dataForExcel) throws JSONException {
		String fileName = getFileName();
		
		File file = TempFileProvider.createTempFile(fileName, ".xls");
		this.fileLocation = file.getAbsolutePath();
		ContentWriter writer = new FileContentWriter(file);
	    writer.setMimetype("application/vnd.ms-excel");


		Workbook workbook = null;
		Sheet sheet = null;
		

		try {
		

				workbook = new HSSFWorkbook();
				sheet = workbook.createSheet("Workflows Report");
			
				CellStyle boldStyle = workbook.createCellStyle();
				Font boldFont = workbook.createFont();
				boldFont.setBold(true);

				boldStyle.setFont(boldFont);

				// Hedear Data
				String[] headers = new String[] { "Type Of Workflow", "Workflow Title", "Workflow Id", "Workflow Start Date", "Workflow Completion Date",
						"Task Id", "Task Type","Task Owner","Task Assigned Date","Task Status",
						"Workflow status","Workflow Priority","WorkflowDetails"};

				// Create Header

				Row row = sheet.createRow(0);
			
				for (int rn = 0; rn < headers.length; rn++) {
					Cell cell = row.createCell(rn);
					cell.setCellValue(headers[rn]);
					cell.setCellStyle(boldStyle);
				}
				
			
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		int rowCount = sheet.getLastRowNum();
		Row row = sheet.createRow(++rowCount);
	
	for (Map.Entry<String,Map<String,Object>> entry : dataForExcel.entrySet()) {
		    Map<String, Object> childMapData = entry.getValue();
		   // System.out.println("workflowid:::"+entry.getKey());
		    JSONObject wfjson=(JSONObject)childMapData.get("wfdetails");
		    List<Map<String, String>> listOfTasks =((List<Map<String, String>>)childMapData.get("tasksList"));
		   // System.out.println("the list of tasks size"+listOfTasks.size());
	
		
		
			for(Map<String,String> task : listOfTasks ) {
			 //   System.out.println("inside the loop !");
				writeIntoCells(row,wfjson,task,workbook);
				 row = sheet.createRow(++rowCount);
			}
		}

		try {
			FileOutputStream outputStream = new FileOutputStream(file);
			workbook.write(outputStream);
			outputStream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	



	public void writeIntoCells(Row row,JSONObject wfDetails, Map<String, String> attributes, Workbook workbook) throws JSONException {
		int cellCount = 0;
		//System.out.println("insde the writeIntoCells");
		Cell cell = row.createCell(cellCount++);
		cell.setCellValue(wfDetails.get("wfType").toString());
		cell = row.createCell(cellCount++);
		cell.setCellValue(wfDetails.get("wfDescription").toString());
		cell = row.createCell(cellCount++);
		cell.setCellValue(wfDetails.get("wfId").toString());
		cell = row.createCell(cellCount++);
		cell.setCellValue(wfDetails.get("wfStartDate").toString());
		cell = row.createCell(cellCount++);
		cell.setCellValue(wfDetails.get("wfEndDate").toString());
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("taskid"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("taskDefintion"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("taskOwner"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("taskstartDate"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("taskStatus"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(wfDetails.get("wfStatus").toString());
		cell = row.createCell(cellCount++);
		cell.setCellValue(wfDetails.get("wfPriority").toString());
		cell = row.createCell(cellCount++);
		setDocumentUrlValue(cell, workbook, wfDetails.get("WorkflowDetails").toString());
		
	}

	public void setDocumentUrlValue(Cell cell, Workbook workbook, String wfDetailsURL) {

		CellStyle hlink_style = workbook.createCellStyle();
		Font hlink_font = workbook.createFont();
		hlink_font.setUnderline(Font.U_SINGLE);
		hlink_font.setColor(IndexedColors.BLUE.getIndex());
		hlink_style.setFont(hlink_font);

		String linkAddress = wfDetailsURL;
		Hyperlink href = workbook.getCreationHelper().createHyperlink(HyperlinkType.URL);
		href.setAddress(linkAddress);
		cell.setHyperlink(href);
		cell.setCellStyle(hlink_style);
		cell.setCellValue(linkAddress);

	}

	public static String getFileName() {

		String fileName = null;
		Calendar calendar = Calendar.getInstance();

		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		formatter.format(calendar.getTime());
		fileName = "WorkFlow Report" + formatter.format(calendar.getTime()).toString();
		// fileName = metadata + " By-" +name + " " + fileName;
		return fileName;
	}

}
