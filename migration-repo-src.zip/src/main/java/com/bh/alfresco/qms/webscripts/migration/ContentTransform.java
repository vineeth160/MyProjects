package com.bh.alfresco.qms.webscripts.migration;



import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.content.MimetypeMap;
import org.alfresco.repo.content.transform.ContentTransformer;
import org.alfresco.service.cmr.model.FileExistsException;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.namespace.QName;
//import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.bh.alfresco.qms.webscripts.utils.ErrorStatus;
import com.documents4j.api.DocumentType;
import com.documents4j.api.IConverter;
import com.documents4j.job.LocalConverter;
import com.google.common.io.Files;

public class ContentTransform extends AbstractWebScript{

	
	public ContentService getContentService() {
		return contentService;
	}

	public void setContentService(ContentService contentService) {
		this.contentService = contentService;
	}

	public NodeService getNodeService() {
		return nodeService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}


	@Autowired
	private ContentService contentService;
	@Autowired
	private NodeService nodeService;
	private Object content;
	private Locale CONTENT_LOCALE;
	private NodeRef pdfNodeRef;
	private NodeRef node;
	private ContentReader text;

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		// TODO Auto-generated method stub
		
	
	//	String nodeRefString = req.getParameter("nodeRefString");
		
		try {
		
			NodeRef nodeRef = null;
			//NodeRef node = new NodeRef(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE,doc);
		
			nodeRef = new NodeRef("workspace://SpacesStore/ff6a3b36-6695-4954-8df2-ed1026a497ab");
			// Read data associated with a content NodeRef (plain text)

			ContentReader reader = contentService.getReader(nodeRef, ContentModel.PROP_CONTENT);
			InputStream originalInputStream = reader.getContentInputStream();
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			final int BUF_SIZE = 1 << 8; //1KiB buffer
			byte[] buffer = new byte[BUF_SIZE];
			int bytesRead = -1;
			while((bytesRead = originalInputStream.read(buffer)) > -1) {
			 outputStream.write(buffer, 0, bytesRead);
			}
			originalInputStream.close();
			byte[] binaryData = outputStream.toByteArray();

			// Writing data to a node's content

			ContentWriter writer = contentService.getWriter(nodeRef, ContentModel.PROP_CONTENT, true);
			writer.putContent(new ByteArrayInputStream((byte[]) content));

			// Writing a file's data to a node's content

			ContentWriter writer1 = contentService.getWriter(nodeRef, ContentModel.PROP_CONTENT, true);
			writer1.setLocale(CONTENT_LOCALE);
			File file = new File("C:\\Users\\VP00501435\\Downloads\\test.pdf");
			writer1.setMimetype("image/bmp");
			writer1.putContent(file);
		
            IConverter converter = LocalConverter.builder().build();
            
            converter.convert(originalInputStream).as(DocumentType.DOCX).to(outputStream).as(DocumentType.PDF).execute();
            outputStream.close();
			
			// Writing a file's data to a node's content


			/**
			 * Creates a new content node setting the content provided.
			 *
			 * @param  parent   the parent node reference
			 * @param  name     the name of the newly created content object
			 * @param  text     the content text to be set on the newly created node
			 * @return NodeRef  node reference to the newly created content node
			 */
			 
			
			
			
		}catch(FileExistsException fee) {
			//ExceptionUtils.printRootCauseStackTrace(fee);
			
		}
		catch(Exception e) {
			System.out.println("exception"+ e);
			
		}
		
	}

	
}