package com.bh.alfresco.qms.webscripts.reports;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.workflow.WorkflowInstance;
import org.alfresco.util.UrlUtil;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.apache.chemistry.opencmis.commons.impl.json.JSONArray;
//import com.github.openjson.JSONArray;

public class WorkFlowSearchWS extends DeclarativeWebScript {
	
	
	
	
	private ServiceRegistry serviceRegistry;
	private String wfStatus;
	private String wfType;
	private String wfStartDate;
	private String wfDescription;
	private String wfPriority;
	private String wfInitiator;

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	
	
	  protected Map<String, Object> executeImpl(
	            WebScriptRequest req, Status status, Cache cache) {
		  
		  
		  wfStatus = req.getParameter("wfStatus");
		  wfType = req.getParameter("wfType");
		  wfStartDate = req.getParameter("wfStartDate");
		  wfDescription = req.getParameter("wfDescription");
		  wfPriority = req.getParameter("wfPriority");
		  wfInitiator = req.getParameter("wfInitiator");
		  
		  Map<String,String> queryMap=new HashMap<String,String>();
	
		  if(wfType!=null && !wfType.isEmpty())
			  queryMap.put("wfType", wfType);
		  if(wfStartDate!=null && !wfStartDate.isEmpty() )
			  queryMap.put("wfStartDate", wfStartDate);
		  if(wfDescription!=null && !wfDescription.isEmpty())
			  queryMap.put("wfDescription", wfDescription);
		  if(wfPriority!=null && !wfPriority.isEmpty())
			  queryMap.put("wfPriority", wfPriority);
		  if(wfInitiator!=null && !wfInitiator.isEmpty())
			  queryMap.put("wfInitiator", wfInitiator);
		  
	//	  System.out.println("the size of query map is ::"+queryMap.size());
		
		  List<WorkflowInstance> workflowsActive =serviceRegistry.getWorkflowService().getActiveWorkflows();
	

		  List<WorkflowInstance> workflowsCompleted =serviceRegistry.getWorkflowService().getCompletedWorkflows();
		 
		   JSONArray setOfSearchedWFArray=null;
		 
			
		  
		  
		  if(wfStatus.equalsIgnoreCase("Pending")) {
		 try {
			// System.out.println("here pending");
			 setOfSearchedWFArray = getSearchedWF(queryMap,workflowsActive);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  }
		  
		  if(wfStatus.equalsIgnoreCase("Completed")) {
		 try {
		//	 System.out.println("here completed");
			 setOfSearchedWFArray = getSearchedWF(queryMap,workflowsCompleted);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  }
		  
		
			  
		
		  
		   Map<String, Object> returnMap = new HashMap<String, Object>();
	       returnMap.put("setOfSearchedWFArray", setOfSearchedWFArray);
	      

	        return returnMap;
	  }
	




	private Map<String, String> getMapOfWorkFlows(WorkflowInstance wfi) {
		  
		  Map<String, String> mapOfWorkflows = new HashMap<String,String>();
		  String enddate=null;
		  Date endDateInAlfresco=null;
		  String finalenddateformat=null;

			//DateFormat alfrescoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.ENGLISH);
		    Date startdate=  wfi.getStartDate();
		    DateFormat alfrescoFormat = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
		    DateFormat comparingFormat = new SimpleDateFormat("dd/M/yyyy", Locale.ENGLISH);
		    Date startDateInAlfresco=null;
			try {
				startDateInAlfresco = alfrescoFormat.parse(startdate.toString());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    String finalstartdateformat=comparingFormat.format(startDateInAlfresco).toString();
		   
		   
		    if(wfi.getEndDate()!=null) {
		     enddate=  wfi.getEndDate().toString();
		    
		     try {
		    	 endDateInAlfresco = alfrescoFormat.parse(enddate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		     finalenddateformat=comparingFormat.format(endDateInAlfresco).toString();
		    }
		   
		
			  
			  mapOfWorkflows.put("wfType", wfi.getDefinition().getTitle());
			  mapOfWorkflows.put("wfStatus", Boolean.toString(wfi.isActive()));
			  mapOfWorkflows.put("wfStartDate", finalstartdateformat);
			  mapOfWorkflows.put("wfEndDate", finalenddateformat);
			  mapOfWorkflows.put("wfDescription", wfi.getDescription().toString());
			  mapOfWorkflows.put("wfPriority", wfi.getPriority().toString());
			  mapOfWorkflows.put("wfInitiator", serviceRegistry.getPersonService().getPerson(wfi.getInitiator()).getUserName());
			  mapOfWorkflows.put("wfId",wfi.getId());
			  
			  
		 
		  
		  
		return mapOfWorkflows;
	}



	public JSONArray getSearchedWF(Map<String,String>queryMap,List<WorkflowInstance> workflowsList) throws JSONException, ParseException{
		boolean isMatched =true;
		Set <String> idSet = new HashSet<String>();
	
		JSONArray mapOfResult = new JSONArray(); 
		  
		  for(WorkflowInstance wfi: workflowsList) {
			  
			 Map<String,String> maptoCompare=getMapOfWorkFlows(wfi);
			 
			
		     for (String name  : queryMap.keySet()) {
		    	// System.out.println("name:::"+name);
		    	// System.out.println("nameQM:::"+queryMap.get(name));
		    	// System.out.println("nameMC:::"+maptoCompare.get(name));
		    	 
		    	 
		    	 
		    	 if(queryMap.get(name).equalsIgnoreCase(maptoCompare.get(name)) || queryMap.get(name).equals(maptoCompare.get(name)) ){
		    		 isMatched =true;
		    	 }
		    	 else {
		    		 isMatched =false;
		    	 	break;
		    	 }
		    	 
		     }
				 if(isMatched) {
					 System.out.println("is matched");
					 JSONObject mapOfWFDetails=new JSONObject();
				 mapOfWFDetails.put("wfType", (maptoCompare.get("wfType")));
				 mapOfWFDetails.put("wfStatus",  maptoCompare.get("wfStatus"));
				 mapOfWFDetails.put("wfStartDate",  maptoCompare.get("wfStartDate"));
				 mapOfWFDetails.put("wfEndDate",  maptoCompare.get("wfEndDate"));
				 mapOfWFDetails.put("id", maptoCompare.get("wfId"));
				 mapOfWFDetails.put("wfDescription",  maptoCompare.get("wfDescription"));
				 mapOfWFDetails.put("wfPriority", maptoCompare.get("wfPriority"));
				 mapOfWFDetails.put("wfInitiator",  maptoCompare.get("wfInitiator"));
				StringBuilder path = new StringBuilder();
				path.append(UrlUtil.getShareUrl(serviceRegistry.getSysAdminParams())).append("/page/workflow-details?workflowId=");
				String WorkflowDetailsURL=path.append(maptoCompare.get("wfId")).toString();
				 mapOfWFDetails.put("wfdetails",  WorkflowDetailsURL);
				
				 mapOfResult.add(mapOfWFDetails);
				 }
				 
			 }
					 
			
			  
		
		  
		  
		  
		  return mapOfResult;
		  
	  }
}
