package com.bh.alfresco.qms.webscripts.datalists;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.dictionary.DataTypeDefinition;
import org.alfresco.service.cmr.dictionary.DictionaryService;
import org.alfresco.service.cmr.dictionary.PropertyDefinition;
import org.alfresco.service.cmr.dictionary.TypeDefinition;
import org.alfresco.service.cmr.repository.ContentIOException;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

//author Ravindhar,K(503100424)

public class ModelTitlesWebScript extends DeclarativeWebScript{
	
	//Adding for Testing
	
	private static final Log logger = LogFactory.getLog(ModelTitlesWebScript.class);
	
	private ServiceRegistry serviceRegistry;
	
	private NodeService nodeService;
	
	private DictionaryService dictionaryService;
	
	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		
		this.serviceRegistry = serviceRegistry;
		
		this.nodeService = serviceRegistry.getNodeService();
		
		this.dictionaryService = serviceRegistry.getDictionaryService();
		
	}
	
	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache){
		
		Map<String,Object> model = new HashMap<String, Object>();
		
		Map<String,String> templateArguments = req.getServiceMatch().getTemplateVars();

		String strTypeName = templateArguments.get("type");
		
		String strNameSpaceURI = req.getParameter("namespaceuri");
		
		logger.info("Name space URI : : : : "+strNameSpaceURI);
		
		logger.info("Data Lsit Type : : : : "+strTypeName);
		
		model.put("type", strTypeName);
		
		model.put("values", getCustomTypePropertiesTitleFromDictionaryService(dictionaryService,strTypeName,strNameSpaceURI));
		
		return model;
		
	}
	
	
	
	public List<String> getCustomTypePropertiesTitleFromDictionaryService(DictionaryService dictionaryService, String strTypeName, String strNameSpaceURI) {
		
		List<String> typeTitles = new ArrayList<String>();
		
		TypeDefinition typeDefinition = dictionaryService.getType(QName.createQName(strNameSpaceURI,strTypeName));
		
		//logger.info("Type Definition : : :  "+typeDefinition);
		
		Map<QName,PropertyDefinition> typeProperties = typeDefinition.getProperties();
		
        Set<QName> set = typeProperties.keySet();
		
		Iterator<QName> i = set.iterator();
		
		while(i.hasNext()) {
			
			QName qname = i.next();
			
			//logger.info("First QName : : : "+typeProperties.get(qname).getDataType().getName());
			
			//logger.info("Second QName : : "+DataTypeDefinition.TEXT);
			
			if(typeProperties.get(qname).getDataType().getName().equals(DataTypeDefinition.TEXT)) {
						
			typeTitles.add(typeProperties.get(qname).getTitle());
			
			}
			
		}
		
		return typeTitles;
		
	}
	
}
