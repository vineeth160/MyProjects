package com.bh.alfresco.qms.workflow.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.ExecutionListener;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.context.Context;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.workflow.activiti.ActivitiConstants;
import org.alfresco.repo.workflow.activiti.ActivitiScriptNode;
import org.alfresco.repo.workflow.activiti.script.DelegateExecutionScriptBase;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class HRSystemAssigneesMap extends DelegateExecutionScriptBase implements ExecutionListener, JavaDelegate{
	
	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	private static final Log logger = LogFactory.getLog(HRSystemAssigneesMap.class);
	private static final String BH_QMS_ADMIN_GROUP = "GROUP_bh_qms_share_admins";
	public static ServiceRegistry serviceRegistry;
	@Override
	public void execute(DelegateExecution execution) throws Exception {
	
		notify(execution);
	}

	@Override
	public void notify(DelegateExecution execution) throws Exception {
		
		serviceRegistry = getServiceRegistry();
		NodeRef packageNoderef = ((ActivitiScriptNode) execution.getVariable("bpm_package")).getNodeRef();
		List<NodeRef> packageContentsList = serviceRegistry.getWorkflowService().getPackageContents(packageNoderef);
		logger.info("packageContentsList.."+packageContentsList);
		String strReviewers = (String) execution.getVariable("bhwf_reviewer_coll");
		logger.info("In Java strReviewers :: "+strReviewers);
		IDSClient idsClient = new IDSClient();
		
		if(strReviewers != null && strReviewers != "undefined" && strReviewers != "") {
			List<String> bhwf_reviewer_coll = Arrays.asList(strReviewers.split(","));
			List<String> bhwf_reviewerFU_coll = new ArrayList<String>();
			execution.setVariable("bhwf_reviewer_coll", bhwf_reviewer_coll);
			logger.info("In Java :: "+execution.getVariable("bhwf_reviewer_coll"));
			
			for(String reviewerMail : bhwf_reviewer_coll) {
				logger.info("reviewer email :: "+reviewerMail);
				String userName_UPN = idsClient.getUserNameFromEmail(reviewerMail);
				logger.info("reviewer userName_UPN in HRSystemAssigneesMap.java : : "+userName_UPN);
				boolean isAdmin = false;
				if(userName_UPN != null && userName_UPN!="") {
					if(serviceRegistry.getPersonService().personExists(userName_UPN)) {
						logger.info("reviewer userName_UPN in HRSystemAssigneesMap.java persionExist : : "+userName_UPN);
						//Set<String> userGroups = serviceRegistry.getAuthorityService().getAuthoritiesForUser(userName_UPN);
						Set<String> userGroups = AuthenticationUtil.runAsSystem((AuthenticationUtil.RunAsWork<Set<String>>)() -> serviceRegistry.getAuthorityService().getAuthoritiesForUser(userName_UPN));
						for(String groupName : userGroups) {
							if(BH_QMS_ADMIN_GROUP.equals(groupName)) {
								logger.info("reviewer userName_UPN exist in groupName : : "+groupName);
								isAdmin = true;
								break;
							}
						}
					}
				}
				if(isAdmin) {
					bhwf_reviewerFU_coll.add(userName_UPN);
				} else {
					bhwf_reviewerFU_coll.add((String) execution.getVariable("bhwfReviewerFU"));
				}
			}
			for(String value:bhwf_reviewerFU_coll) {
				logger.info("Reviewer FU Collection Values :: "+value);
			}
			execution.setVariable("bhwf_reviewerFU_coll", bhwf_reviewerFU_coll);
		}
		String strApprovers = (String) execution.getVariable("bhwf_approver_coll");
		logger.info("In Java strApprovers :: "+strApprovers);
		if(strApprovers != null && strApprovers != "undefined" && strApprovers != "") {
			List<String> bhwf_approver_coll = Arrays.asList(strApprovers.split(","));
			List<String> bhwf_approverFU_coll = new ArrayList<String>();
			execution.setVariable("bhwf_approver_coll", bhwf_approver_coll);
			logger.info("In Java :: "+execution.getVariable("bhwf_approver_coll"));
			
			for(String approverMail : bhwf_approver_coll) {
				logger.info("approver email :: "+approverMail);
				String userName_UPN = idsClient.getUserNameFromEmail(approverMail);
				logger.info("approver userName_UPN in HRSystemAssigneesMap.java : : "+userName_UPN);
				boolean isAdmin = false;
				if(userName_UPN != null && userName_UPN!="") {
					if(serviceRegistry.getPersonService().personExists(userName_UPN)) {
						logger.info("approver userName_UPN in HRSystemAssigneesMap.java persionExist : : "+userName_UPN);
						//Set<String> userGroups = serviceRegistry.getAuthorityService().getAuthoritiesForUser(userName_UPN);
						Set<String> userGroups = AuthenticationUtil.runAsSystem((AuthenticationUtil.RunAsWork<Set<String>>)() -> serviceRegistry.getAuthorityService().getAuthoritiesForUser(userName_UPN));
						for(String groupName : userGroups) {
							if(BH_QMS_ADMIN_GROUP.equals(groupName)) {
								logger.info("approver userName_UPN exist in groupName : : "+groupName);
								isAdmin = true;
								break;
							}
						}
					}
				}
				if(isAdmin) {
					bhwf_approverFU_coll.add(userName_UPN);
				} else {
					bhwf_approverFU_coll.add((String) execution.getVariable("bhwfReviewerFU"));
				}
			}
			for(String value:bhwf_approverFU_coll) {
				logger.info("Approver FU Collection Values :: "+value);
			}
			execution.setVariable("bhwf_approverFU_coll", bhwf_approverFU_coll);
		}
		
		String archivalOwner = (String) execution.getVariable("bhwf_archival_owner");
		if(archivalOwner!=null && archivalOwner != "undefined" && archivalOwner != "") {
			String userName_UPN = idsClient.getUserNameFromEmail(archivalOwner);
			logger.info("archival userName_UPN in HRSystemAssigneesMap.java : : "+userName_UPN);
			
			boolean isAdmin = false;
			if(userName_UPN != null && userName_UPN!="") {
				if(serviceRegistry.getPersonService().personExists(userName_UPN)) {
					logger.info("archival userName_UPN in HRSystemAssigneesMap.java persionExist : : "+userName_UPN);
					//Set<String> userGroups = serviceRegistry.getAuthorityService().getAuthoritiesForUser(userName_UPN);
					Set<String> userGroups = AuthenticationUtil.runAsSystem((AuthenticationUtil.RunAsWork<Set<String>>)() -> serviceRegistry.getAuthorityService().getAuthoritiesForUser(userName_UPN));
					for(String groupName : userGroups) {
						if(BH_QMS_ADMIN_GROUP.equals(groupName)) {
							logger.info("archival userName_UPN exist in groupName : : "+groupName);
							isAdmin = true;
							break;
						}
					}
				}
			}
			if(isAdmin) {
				execution.setVariable("bhwf_ArchivalFU", userName_UPN);
				logger.info("archival assigneeName : : "+execution.getVariable("bhwf_ArchivalFU"));
			}
		}
		
		String smeUser = (String) execution.getVariable("bhwf_sme_user");
		if(smeUser!=null && smeUser != "undefined" && smeUser != "") {
			String userName_UPN = idsClient.getUserNameFromEmail(smeUser);
			logger.info("userName_UPN in HRSystemAssigneesMap.java : : "+userName_UPN);
			
			boolean isAdmin = false;
			if(userName_UPN != null && userName_UPN!="") {
				if(serviceRegistry.getPersonService().personExists(userName_UPN)) {
					//Set<String> userGroups = serviceRegistry.getAuthorityService().getAuthoritiesForUser(userName_UPN);
					Set<String> userGroups = AuthenticationUtil.runAsSystem((AuthenticationUtil.RunAsWork<Set<String>>)() -> serviceRegistry.getAuthorityService().getAuthoritiesForUser(userName_UPN));
					for(String groupName : userGroups) {
						if(BH_QMS_ADMIN_GROUP.equals(groupName)) {
							isAdmin = true;
							break;
						}
					}
				}
			}
			if(isAdmin) {
				execution.setVariable("bhwfIntakesFU", userName_UPN);
				logger.info("SME assigneeName : : "+execution.getVariable("bhwfIntakesFU"));
			}
		}
		
		String intakesUser = (String) execution.getVariable("bhwf_intakes_user");
		if(intakesUser!=null && intakesUser != "undefined" && intakesUser != "") {
			String userName_UPN = idsClient.getUserNameFromEmail(intakesUser);
			logger.info("userName_UPN in HRSystemAssigneesMap.java : : "+userName_UPN);
			
			boolean isAdmin = false;
			if(userName_UPN != null && userName_UPN!="") {	
				if(serviceRegistry.getPersonService().personExists(userName_UPN)) {
					//Set<String> userGroups = serviceRegistry.getAuthorityService().getAuthoritiesForUser(userName_UPN);
					Set<String> userGroups = AuthenticationUtil.runAsSystem((AuthenticationUtil.RunAsWork<Set<String>>)() -> serviceRegistry.getAuthorityService().getAuthoritiesForUser(userName_UPN));
					for(String groupName : userGroups) {
						if(BH_QMS_ADMIN_GROUP.equals(groupName)) {
							isAdmin = true;
							break;
						}
					}
				}
			}
			if(isAdmin) {
				execution.setVariable("bhwfIntakesFU", userName_UPN);
				logger.info("Intakes assigneeName : : "+execution.getVariable("bhwfIntakesFU"));
			}
		}
	}
	
	
	protected ServiceRegistry getServiceRegistry()
	{
		ProcessEngineConfigurationImpl config = Context.getProcessEngineConfiguration();
		if (config != null) 
		{
			// Fetch the registry that is injected in the activiti spring-configuration
			ServiceRegistry registry = (ServiceRegistry) config.getBeans().get(ActivitiConstants.SERVICE_REGISTRY_BEAN_KEY);
			if (registry == null)
			{
				throw new RuntimeException(
						"Service-registry not present in ProcessEngineConfiguration beans, expected ServiceRegistry with key" + 
								ActivitiConstants.SERVICE_REGISTRY_BEAN_KEY);
			}
			return registry;
		}
		throw new IllegalStateException("No ProcessEngineCOnfiguration found in active context");
	}
}
