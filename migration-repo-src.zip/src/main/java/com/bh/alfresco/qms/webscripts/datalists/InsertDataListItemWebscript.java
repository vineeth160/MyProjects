package com.bh.alfresco.qms.webscripts.datalists;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.dictionary.DictionaryService;
import org.alfresco.service.cmr.dictionary.PropertyDefinition;
import org.alfresco.service.cmr.dictionary.TypeDefinition;
import org.alfresco.service.cmr.repository.ContentIOException;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.QName;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * Baker Hughes Company
 * @author Ravindhar,K(503100424)
 * @version 1.0
 *
 * This class is a Declarative web script will read data from excel and insert in dataList
 */

public class InsertDataListItemWebscript extends DeclarativeWebScript{
	
	private static final Log logger = LogFactory.getLog(InsertDataListItemWebscript.class);
	
	private static final String CONTAINER_ID_FOR_DATALIST = "datalists";
	
	private ServiceRegistry serviceRegistry;
	
	private NodeService nodeService;
	
	private DictionaryService dictionaryService;
	
	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		
		this.serviceRegistry = serviceRegistry;
		
		this.nodeService = serviceRegistry.getNodeService();
		
		this.dictionaryService = serviceRegistry.getDictionaryService();
		
	}
	 
	/**
	 * Execution of this web script starts from this method and returns model to FTL
	 */
	@SuppressWarnings("resource")
	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache){
		
		Map<String,Object> model = new HashMap<String, Object>();
		
		Map<String,String> templateArguments = req.getServiceMatch().getTemplateVars();
		
		String strNodeRef = templateArguments.get("noderef");

		String strDataListType = templateArguments.get("type");
		
		String strSiteName = templateArguments.get("site");

		String strListName = templateArguments.get("datalistname");
		
		String nameSpaceURI = req.getParameter("namespaceuri");
		
		QName qnameFromInput = QName.createQName(nameSpaceURI, strDataListType);
		
		//logger.info("Data List name : : : : "+strListName);
		
		//logger.info("Data Lsit Type : : : : "+strDataListType);
		
		//logger.info("Node Ref for imput file : : "+strNodeRef);
		
		NodeRef datalistContainerNodeRef = serviceRegistry.getSiteService().getContainer(strSiteName, CONTAINER_ID_FOR_DATALIST);
		
		//logger.info("Datalist Container for Node Ref : : : : "+datalistContainerNodeRef);
		
		NodeRef dataListNodeRef = nodeService.getChildByName(datalistContainerNodeRef, ContentModel.ASSOC_CONTAINS, strListName);
		
		//logger.info("NodeRef of Datalist : : : : "+dataListNodeRef );
		
		Map<String,QName> titleQNameMap = getCustomTypePropertiesTitleFromDictionaryService(strDataListType, nameSpaceURI);
		
		NodeRef input = new NodeRef("workspace://SpacesStore/"+strNodeRef);
		
		ContentReader reader = serviceRegistry.getContentService().getReader(input, ContentModel.PROP_CONTENT);
		
		XSSFWorkbook wb;
		
		try {
			
			wb = new XSSFWorkbook(reader.getContentInputStream());
			
			XSSFSheet sheet = wb.getSheetAt(0);
			
			List<String> headersList = getHeaders(sheet);
			
			Map<Integer,String> headerIndexMap = getHeadersIndexMap(sheet);
			
			Object[][] excelData;
			
			if(isValidIUnputExcel(headersList,titleQNameMap)) {
				
				excelData = readDataFromExcel(sheet);
				
				createDataListItems(nodeService, dataListNodeRef, qnameFromInput, excelData, headerIndexMap, titleQNameMap, nameSpaceURI);
				
				model.put("msg", "Datalist Items are created successfully");
				
			}else {
				
				model.put("msg", "Given Excel has invalid Values");
				
				return model;
				
			}
			
			
		} catch (ContentIOException | IOException e) {
			
			e.printStackTrace();
			
		}
		
		return model;
		
	}
	
	/**
	 * This Method will create Data List items
	 * @param nodeService
	 * @param dataListNodeRef
	 * @param qnameFromInput
	 * @param excelData
	 * @param headerIndexMap
	 * @param titleQNameMap
	 * @param nameSpaceURI
	 */
	public void createDataListItems(NodeService nodeService, NodeRef dataListNodeRef, QName qnameFromInput, Object[][] excelData, 
			Map<Integer,String> headerIndexMap, Map<String,QName> titleQNameMap, String nameSpaceURI) {
		
		for(Object[] rowData : excelData) {
			
			Map<QName, Serializable> properties = new HashMap<QName, Serializable>();
			
			int cellValue = 0;
			
			for(Object cellData : rowData) {
				
				if(cellData instanceof String) {
					
					properties.put(titleQNameMap.get(headerIndexMap.get(cellValue++)), (String)cellData);
					
				}else if(cellData instanceof Integer) {
					
					properties.put(titleQNameMap.get(headerIndexMap.get(cellValue++)), (int)cellData);
					
				}else if(cellData instanceof Boolean) {
					
					properties.put(titleQNameMap.get(headerIndexMap.get(cellValue++)), (Boolean)cellData);
					
				}
				
			}
			
			logger.info("Node Ref : : : "+nodeService.createNode(dataListNodeRef, ContentModel.ASSOC_CONTAINS, qnameFromInput, qnameFromInput, properties).getChildRef());
			
		}
		
	}
	
	/**
	 * This Method will extract titles for properties and return title QName Map
	 * @param strDataListType
	 * @param nameSpaceURI
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public Map<String,QName> getCustomTypePropertiesTitleFromDictionaryService(String strDataListType, String nameSpaceURI) {
		
		Map<String,QName> titleQNameMap = new HashMap<String,QName>();
		
		TypeDefinition typeDefinition = dictionaryService.getType(QName.createQName(nameSpaceURI,strDataListType));
		
		Map<QName,PropertyDefinition> typeProperties = typeDefinition.getProperties();
		
        Set<QName> set = typeProperties.keySet();
		
		Iterator<QName> iteratior = set.iterator();
		
		while(iteratior.hasNext()) {
			
			QName qname = iteratior.next();
			
			titleQNameMap.put(typeProperties.get(qname).getTitle(), qname);
			
		}
		
		return titleQNameMap;
		
	}
	
	/**
	 * This method will get all Header Details and returns Index and Header Name Map
	 * @param sheet
	 * @return
	 */
	public Map<Integer,String> getHeadersIndexMap(XSSFSheet sheet) {
		
		Map<Integer,String> headersList = new HashMap<Integer,String>();
				
		XSSFRow headers = sheet.getRow(0);
		
		int numberOfCells = headers.getPhysicalNumberOfCells();
		
		for(int cellIndex = 0; cellIndex < numberOfCells; cellIndex++) {
			
			headersList.put(cellIndex,headers.getCell(cellIndex).getStringCellValue());
			
		}
		
		return headersList;
		
	}
	
	
	/**
	 * This Method will get all Headers in sheet and returns List of header names
	 * @param sheet
	 * @return
	 */
	public List<String> getHeaders(XSSFSheet sheet) {
		
		List<String> headersList = new ArrayList<String>();
		
		XSSFRow headers = sheet.getRow(0);
		
		int numberOfCells = headers.getPhysicalNumberOfCells();
		
		for(int cellIndex = 0; cellIndex < numberOfCells; cellIndex++) {
			
			headersList.add(headers.getCell(cellIndex).getStringCellValue());
			
		}
		
		return headersList;
		
	}
	
	/**
	 * This Method will validate whether provided excel is valid or not
	 * @param headersList
	 * @param titleQNameMap
	 * @return
	 */
	public boolean isValidIUnputExcel(List<String> headersList, Map<String, QName> titleQNameMap) {
		
		boolean isValid = false;
		
		Set<String> keys = titleQNameMap.keySet();
		
		for(String header : headersList) {
			
			if(keys.contains(header)) {
				
				isValid = true;
				
			}else {
				
				return false;
				
			}
			
		}
		
		return isValid;
		
	}
	
	/**
	 * This Method will read all data from sheet and return 2D Array object
	 * @param sheet
	 * @return
	 */
	public Object[][] readDataFromExcel(XSSFSheet sheet) {
		
		int numberOfRows = sheet.getPhysicalNumberOfRows();
		
		int numberOfCellsInARow = sheet.getRow(0).getPhysicalNumberOfCells();
		
		Object[][] excelData = new Object[numberOfRows-1][numberOfCellsInARow];
		
		int rowValue = 0;
		
		for(int rowIndex = 1; rowIndex < numberOfRows; rowIndex++) {
			
			int cellValue = 0;
			
			XSSFRow row = sheet.getRow(rowIndex);
			
			for(int cellIndex = 0; cellIndex < numberOfCellsInARow ; cellIndex++) {
				
				XSSFCell cell = row.getCell(cellIndex);
				
				if(cell != null) {
					
					if(cell.getCellType()==CellType.STRING) {
						
						excelData[rowValue][cellValue++] = cell.getStringCellValue();
						
					}else if(cell.getCellType()==CellType.NUMERIC) {
						
						excelData[rowValue][cellValue++] = cell.getNumericCellValue();
						
					}else if(cell.getCellType()==CellType.BOOLEAN) {
						
						excelData[rowValue][cellValue++] = cell.getBooleanCellValue();
						
					}else {
						
						excelData[rowValue][cellValue++] = "Other Type";
						
					}
					
				}else {
					
					excelData[rowValue][cellValue++] = "";
					
				}
				
			}
			
			rowValue++;
			
		}
		
		return excelData;
		
	}	

}
