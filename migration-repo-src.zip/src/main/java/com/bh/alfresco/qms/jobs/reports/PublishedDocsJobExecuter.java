package com.bh.alfresco.qms.jobs.reports;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.content.MimetypeMap;
import org.alfresco.repo.content.filestore.FileContentWriter;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.action.Action;
import org.alfresco.service.cmr.action.ActionService;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.TempFileProvider;
import org.alfresco.util.UrlUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.common.usermodel.HyperlinkType;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class PublishedDocsJobExecuter {
	private static final Log logger = LogFactory.getLog(PublishedDocsJobExecuter.class);

	private String app_model_1_0_uri; // = "http://www.bakerhughes.com/model/qms/content/1.0";

	/*
	 * public String getfileLocation() { return fileLocation; }
	 * 
	 * public void setfileLocation(String fileLocation) { this.fileLocation =
	 * fileLocation; }
	 */

	public String getemailTemplateXpathTPS() {
		return emailTemplateXpathTPS;
	}

	
	
	public String getApp_model_1_0_uri() {
		return app_model_1_0_uri;
	}



	public void setApp_model_1_0_uri(String app_model_1_0_uri) {
		this.app_model_1_0_uri = app_model_1_0_uri;
	}



	public void setemailTemplateXpathTPS(String emailTemplateXpathTPS) {
		this.emailTemplateXpathTPS = emailTemplateXpathTPS;
	}

	public String getemailTemplateXpathDS() {
		return emailTemplateXpathDS;
	}

	public void setemailTemplateXpathDS(String emailTemplateXpathDS) {
		this.emailTemplateXpathDS = emailTemplateXpathDS;
	}

	public String getdocUploadPath() {
		return docUploadPath;
	}

	public void setdocUploadPath(String docUploadPath) {
		this.docUploadPath = docUploadPath;
	}

	public String getqueryforPublishedocuments() {
		return queryforPublishedocuments;
	}

	public void setqueryforPublishedocuments(String queryforPublishedocuments) {
		this.queryforPublishedocuments = queryforPublishedocuments;
	}

	private String fileLocation;
	private String emailTemplateXpathTPS;
	private String emailTemplateXpathDS;
	private String docUploadPath;
	private String queryforPublishedocuments;

	List<String> listAttr = new ArrayList<String>();

	QName PROP_QNAME_REFERENCE_NUMBER = QName.createQName(app_model_1_0_uri, "reference");
	QName PROP_QNAME_DOCUMENT_AUTHOR = QName.createQName(app_model_1_0_uri, "document_author");
	QName PROP_QNAME_DOCUMENT_ADMIN = QName.createQName(app_model_1_0_uri, "document_admin");
	QName PROP_QNAME_FUNCTIONAL_OWNER = QName.createQName(app_model_1_0_uri, "functional_owner");
	QName PROP_QNAME_DOCUMENT_URL = QName.createQName(app_model_1_0_uri, "document_url");
	QName PROP_QNAME_EXPIRY_DATE = QName.createQName(app_model_1_0_uri, "expiry_date");
	QName PROP_QNAME_PUBLISH_DATE = QName.createQName(app_model_1_0_uri, "published_date");
	QName PROP_QNAME_EFFECTIVE_DATE = QName.createQName(app_model_1_0_uri, "effective_date");
	QName PROP_QNAME_DOCUMENT_TYPE = QName.createQName(app_model_1_0_uri, "bhqms:document_type");

	public String FUNCTIONAL_OWNER_METADATA = "Functional Owner";
	public String AUTHOR_METADATA = "Author";
	public String ADMIN_METADATA = "Admin";

	/**
	 * Public API access
	 */
	private ServiceRegistry serviceRegistry;

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	/**
	 * Executer implementation
	 */
	public void execute() {
		String fileName = getFileName();
		List<NodeRef> nodeResultSet = getPublishedDocumentsList();
 
		Map<String, Map<String, NodeRef>> userNamesWithTypes = exportToExcel(nodeResultSet,fileName);
  
		NodeRef nodeToSend = uploadToAlfresco(getFileName(), getNode(docUploadPath));
		for (Map.Entry<String, Map<String, NodeRef>> types : userNamesWithTypes.entrySet()) {

			if (types.getKey().toString() == "DS") {
				sendEmail(nodeToSend, types.getValue(), emailTemplateXpathDS);
			}
			if (types.getKey().toString() == "TPS") {
				sendEmail(nodeToSend, types.getValue(), emailTemplateXpathTPS);
			}
		}

	}

	public List<NodeRef> getPublishedDocumentsList() {
		List<NodeRef> listNodes = new ArrayList<NodeRef>();
		String query = queryforPublishedocuments;
		ResultSet results = serviceRegistry.getSearchService().query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE,
				SearchService.LANGUAGE_LUCENE, query);
		listNodes = results.getNodeRefs();

		return listNodes;
	}

	public Map<String, Map<String, NodeRef>> exportToExcel(List<NodeRef> listNodes, String fileName) {
		List<Map<String, String>> dataForExcel = new ArrayList<Map<String, String>>();
		Map<String, NodeRef> userNames = new HashMap<String, NodeRef>();
		Map<String, Map<String, NodeRef>> userNamesWithType = new HashMap<String, Map<String, NodeRef>>();

		for (NodeRef node : listNodes) {

			String nodeName = (String) serviceRegistry.getNodeService().getProperty(node, ContentModel.PROP_NAME);
			String nodeRefernceNumber = (String) serviceRegistry.getNodeService().getProperty(node,
					PROP_QNAME_REFERENCE_NUMBER);
			String nodeDocumentAuthor = (String) serviceRegistry.getNodeService().getProperty(node,
					PROP_QNAME_DOCUMENT_AUTHOR);
			String nodeDocumentAdmin = (String) serviceRegistry.getNodeService().getProperty(node,
					PROP_QNAME_DOCUMENT_ADMIN);
			String nodeFunctionalOwner = (String) serviceRegistry.getNodeService().getProperty(node,
					PROP_QNAME_FUNCTIONAL_OWNER);
			String nodeDocType = (String) serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_DOCUMENT_TYPE);
			String nodeEffectiveDate = null;
			if (serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_EFFECTIVE_DATE) != null) {
				nodeEffectiveDate = serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_EFFECTIVE_DATE)
						.toString();
			}

			String nodePublishDate = null;
			if (serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_PUBLISH_DATE) != null) {
				nodePublishDate = serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_PUBLISH_DATE)
						.toString();
			}

			String nodeExpiryDate = null;
			if (serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_EXPIRY_DATE) != null) {
				nodeExpiryDate = serviceRegistry.getNodeService().getProperty(node, PROP_QNAME_EXPIRY_DATE).toString();
			}

			String nodeDocumentUrl = getDocumentPropertiesUrl(node);

			Map<String, String> nodeMap = new HashMap<String, String>();
			nodeMap.put("DocumentTitle", nodeName);
			nodeMap.put("ReferenceNumber", nodeRefernceNumber);
			nodeMap.put("Author", nodeDocumentAuthor);
			nodeMap.put("Admin", nodeDocumentAdmin);
			nodeMap.put("FunctionalOwner", nodeFunctionalOwner);
			nodeMap.put("DocumentURL", nodeDocumentUrl);
			nodeMap.put("ExpiryDate", nodeExpiryDate);
			nodeMap.put("PublishDate", nodePublishDate);
			nodeMap.put("EffectiveDate", nodeEffectiveDate);

			dataForExcel.add(nodeMap);

			if (nodeDocType != null && nodeDocType == "DS") {
				if (nodeDocumentAdmin != null) {
					userNames.putAll(getEmailAndPersonNodeMap(nodeDocumentAdmin));
				}
				userNamesWithType.put("DS", userNames);
			} else {

				if (nodeFunctionalOwner != null) {
					userNames.putAll(getEmailAndPersonNodeMap(nodeFunctionalOwner));
				}
				if (nodeDocumentAuthor != null) {
					userNames.putAll(getEmailAndPersonNodeMap(nodeDocumentAuthor));
				}
				if (nodeDocumentAdmin != null) {
					userNames.putAll(getEmailAndPersonNodeMap(nodeDocumentAdmin));
				}

				userNamesWithType.put("TPS", userNames);
			}

		}

		writeToExcel(dataForExcel,fileName);

		return userNamesWithType;
	}

	public void writeToExcel(List<Map<String, String>> nodeList, String fileName) {
		//String fileName = getFileName();

		//File file = new File(this.fileLocation + fileName);
		File file = TempFileProvider.createTempFile(fileName, "");
		this.fileLocation = file.getAbsolutePath();
		ContentWriter writer = new FileContentWriter(file);
	    writer.setMimetype("application/vnd.ms-excel");

		Workbook workbook = null;
		Sheet sheet = null;
		Row row = null;

		try {
			if (file.createNewFile()) {

				workbook = new HSSFWorkbook();
				sheet = workbook.createSheet("Published Documents");

				// Header Cell Style
				CellStyle boldStyle = workbook.createCellStyle();
				Font boldFont = workbook.createFont();
				boldFont.setBold(true);

				boldStyle.setFont(boldFont);

				// Hedear Data
				String[] headers = new String[] { " DocumentTitle", "ReferenceNumber", "Author", "Admin",
						"FunctionalOwner", "DocumentURL", "ExpiryDate", "PublishDate", "EffectiveDate" };

				// Create Header
				row = sheet.createRow(0);

				// Insert Header data
				for (int rn = 0; rn < headers.length; rn++) {
					Cell cell = row.createCell(rn);
					cell.setCellValue(headers[rn]);
					cell.setCellStyle(boldStyle);
				}
			} else {

				workbook = new HSSFWorkbook(new FileInputStream(file));
				sheet = workbook.getSheet("Published Documents");

			}

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		int rowCount = sheet.getLastRowNum();
		// Insert node List
		for (Map node : nodeList) {
			row = sheet.createRow(++rowCount);
			writeIntoCells(row, node, workbook);
		}
		try {
			FileOutputStream outputStream = new FileOutputStream(file);
			workbook.write(outputStream);
			outputStream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void writeIntoCells(Row row, Map<String, String> attributes, Workbook workbook) {
		int cellCount = 0;
		Cell cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("DocumentTitle"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("ReferenceNumber"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("Author"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("Admin"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("FunctionalOwner"));
		cell = row.createCell(cellCount++);
		setDocumentUrlValue(cell, workbook, attributes);
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("ExpiryDate"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("PublishDate"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(attributes.get("EffectiveDate"));
	}

	public void setDocumentUrlValue(Cell cell, Workbook workbook, Map<String, String> attributes) {

		CellStyle hlink_style = workbook.createCellStyle();
		Font hlink_font = workbook.createFont();
		hlink_font.setUnderline(Font.U_SINGLE);
		hlink_font.setColor(IndexedColors.BLUE.getIndex());
		hlink_style.setFont(hlink_font);

		String linkAddress = attributes.get("DocumentURL");
		Hyperlink href = workbook.getCreationHelper().createHyperlink(HyperlinkType.URL);
		href.setAddress(linkAddress);
		cell.setHyperlink(href);
		cell.setCellStyle(hlink_style);
		cell.setCellValue(linkAddress);

	}

	public NodeRef uploadToAlfresco(String fileName, NodeRef uploadNode) {
		File file = new File(this.fileLocation + fileName);

		String name = file.getName();

		Map<QName, Serializable> props = new HashMap<QName, Serializable>(1);
		props.put(ContentModel.PROP_NAME, name);

		// use the node service to create a new node
		NodeRef node = serviceRegistry.getNodeService().createNode(uploadNode, ContentModel.ASSOC_CONTAINS,
				QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, name), ContentModel.TYPE_CONTENT, props)
				.getChildRef();

		// Use the content service to set the content onto the newly created
		// node
		ContentWriter writer = serviceRegistry.getContentService().getWriter(node, ContentModel.PROP_CONTENT, true);
		writer.setMimetype(MimetypeMap.MIMETYPE_EXCEL);
		writer.setEncoding("UTF-8");

		writer.putContent(file);

		return node;
	}

	public String getDocumentPropertiesUrl(NodeRef node) {

		String baseUrl = UrlUtil.getShareUrl(serviceRegistry.getSysAdminParams());
		String siteShortName = serviceRegistry.getSiteService().getSiteShortName(node);
		StringBuilder path = new StringBuilder();
		path.append(baseUrl).append("/page/");
		if (siteShortName != null) {
			path.append("site/").append(siteShortName).append("/");
		}

		path.append("edit-metadata?nodeRef=").append(node);

		return path.toString();
	}

	public String getDocumentDetailsUrl(NodeRef node) {

		String baseUrl = UrlUtil.getShareUrl(serviceRegistry.getSysAdminParams());
		String siteShortName = serviceRegistry.getSiteService().getSiteShortName(node);
		StringBuilder path = new StringBuilder();
		path.append(baseUrl).append("/page/");
		if (siteShortName != null) {
			path.append("site/").append(siteShortName).append("/");
		}

		path.append("document-details?nodeRef=").append(node);

		return path.toString();
	}

	public static String getFileName() {

		String fileName = null;
		Calendar calendar = Calendar.getInstance();

		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		formatter.format(calendar.getTime());
		fileName = "Published Documents Report - " + formatter.format(calendar.getTime()).toString() + ".xls";

		return fileName;
	}

	public void sendEmail(NodeRef documentNode, Map<String, NodeRef> toEmailMap, String emailTemplate) {

		String subject = "firstName" + " lastName" + " has sent you a new content item," + "docName" + ", in the"
				+ " siteName" + " site ";

		for (Map.Entry<String, NodeRef> person : toEmailMap.entrySet()) {

			ActionService actionService = serviceRegistry.getActionService();

			Action mailAction = actionService.createAction(MailActionExecuter.NAME);
			subject = subject.replace("firstName", serviceRegistry.getNodeService()
					.getProperty(person.getValue(), ContentModel.PROP_FIRSTNAME).toString());
			subject = subject.replace("lastName", serviceRegistry.getNodeService()
					.getProperty(person.getValue(), ContentModel.PROP_LASTNAME).toString());
			subject = subject.replace("docName",
					serviceRegistry.getNodeService().getProperty(documentNode, ContentModel.PROP_NAME).toString());
			subject = subject.replace("siteName", serviceRegistry.getSiteService().getSiteShortName(documentNode));

			mailAction.setParameterValue(MailActionExecuter.PARAM_SUBJECT, subject);
			subject = "firstName" + " lastName" + " has sent you a new content item," + "docName" + ", in the"
					+ " siteName" + " site ";

			mailAction.setParameterValue(MailActionExecuter.PARAM_TO, person.getKey().toString());

			mailAction.setParameterValue(MailActionExecuter.PARAM_BCC, "RK00583701@Techmahindra.com");

			mailAction.setParameterValue(MailActionExecuter.PARAM_TEXT, getDocumentDetailsUrl(documentNode));

			//mailAction.setParameterValue(MailActionExecuter.PARAM_NODE, (Serializable) documentNode);

			//mailAction.setParameterValue(MailActionExecuter.PARAM_ATTACHMENT_EXTENSION, "xls");
			
			mailAction.setParameterValue(MailActionExecuter.PARAM_TEMPLATE, getNode(emailTemplate));

			Map<String, Serializable> templateArgs = new HashMap<String, Serializable>();
			templateArgs.put("PARAM_NODE", (Serializable) documentNode);
			templateArgs.put("PARAM_ATTACHMENT_EXTENSION", "xls");
			Map<String, Object> templateModel = new HashMap<String, Object>();
			templateModel.put("args", (Serializable) templateArgs);
			
			templateModel = createEmailTemplateModel(documentNode, person.getValue(), templateModel);
			mailAction.setParameterValue(MailActionExecuter.PARAM_TEMPLATE_MODEL, (Serializable) templateModel);
			
//			mailAction.setParameterValue(MailActionExecuter.PARAM_TEMPLATE_MODEL,
//					(Serializable) createEmailTemplateModel(documentNode, person.getValue()));
			actionService.executeAction(mailAction, null);

		}
		// BEFORE execution add template and file attachment

	}

	public NodeRef getNode(String path) {

		Map<String, Serializable> params = new HashMap<>();
		params.put("query", path);
		NodeRef nodeRef = serviceRegistry.getNodeLocatorService().getNode("xpath", null, params);
		return nodeRef;
	}

	public Map<String, NodeRef> getEmailAndPersonNodeMap(String userName) {
		Map<String, NodeRef> mapPersonNode = new HashMap<String, NodeRef>();
		NodeRef personNode = serviceRegistry.getPersonService().getPerson(userName);
		String emailId = (String) serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_EMAIL);
		if (emailId != null && !emailId.isEmpty()) {
			mapPersonNode.put(emailId, personNode);
		}

		return mapPersonNode;

	}

	public Map<String, Object> createEmailTemplateModel(NodeRef nodeToSend, NodeRef personNode, Map<String, Object> modelMap) {

		//Map<String, Object> modelMap = new HashMap<String, Object>();

		Map<String, Object> firstLastNames = new HashMap<String, Object>();
		firstLastNames.put("firstName",
				serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_FIRSTNAME).toString());
		firstLastNames.put("lastName",
				serviceRegistry.getNodeService().getProperty(personNode, ContentModel.PROP_LASTNAME).toString());

		Map<String, Object> properties = new HashMap<String, Object>();
		properties.put("properties", firstLastNames);

		modelMap.put("person", properties);

		Map<String, Object> document = new HashMap<String, Object>();
		document.put("name",
				serviceRegistry.getNodeService().getProperty(nodeToSend, ContentModel.PROP_NAME).toString());
		document.put("siteShortName", serviceRegistry.getSiteService().getSiteShortName(nodeToSend));
		document.put("documentdetailslink", getDocumentDetailsUrl(nodeToSend));

		modelMap.put("document", document);

		return modelMap;
	}

}