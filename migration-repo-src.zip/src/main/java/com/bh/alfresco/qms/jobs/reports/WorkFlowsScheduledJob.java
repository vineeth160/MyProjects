package com.bh.alfresco.qms.jobs.reports;

import org.alfresco.error.AlfrescoRuntimeException;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.schedule.AbstractScheduledLockedJob;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.StatefulJob;

@SuppressWarnings("deprecation")
public class WorkFlowsScheduledJob extends AbstractScheduledLockedJob implements StatefulJob{

	private static final Log logger = LogFactory.getLog(WorkFlowsScheduledJob.class);

	@Override
	public void executeJob(JobExecutionContext jobContext) throws JobExecutionException {
		// TODO Auto-generated method stub

		JobDataMap jobDataMap = jobContext.getJobDetail().getJobDataMap();

		Object executerObj = jobDataMap.get("jobExecuter");

		if (executerObj == null || !(executerObj instanceof WorkFlowsPendingBH)) {
			throw new AlfrescoRuntimeException(
					"ScheduledJob data must contain valid 'Executer' reference");
		}
		logger.info("calling executer..");

		final WorkFlowsPendingBH jobExecuter = (WorkFlowsPendingBH) executerObj;

		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
			public Object doWork() throws Exception {
				jobExecuter.execute();
				return null;
			}
		}, AuthenticationUtil.getSystemUserName());
	}
}