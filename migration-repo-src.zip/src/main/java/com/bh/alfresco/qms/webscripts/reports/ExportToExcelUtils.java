package com.bh.alfresco.qms.webscripts.reports;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.alfresco.util.TempFileProvider;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.common.usermodel.HyperlinkType;
//import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExportToExcelUtils {

	private static final Log logger = LogFactory.getLog(ExportToExcelUtils.class);

	private String fileLocation = "";

	public File writeToExcel(List<Map<String, String>> dataForExcel, String typeOfReport, String qmsLibraryBaseURL) {

		String fileName = getFileName(typeOfReport);

		logger.info("in writeToExcel() :: fileName :: "+fileName);
		fileName = fileName+"-";
		logger.info("in writeToExcel() :: fileName Updated :: "+fileName);

		File file = TempFileProvider.createTempFile(fileName, ".xlsx");
		this.fileLocation = file.getAbsolutePath();

		logger.info("in writeToExcel() :: this.fileLocation :: "+this.fileLocation);
		Workbook workbook = null;
		Sheet sheet = null;
		try {
			logger.info("createNewFile() :: No");
			//workbook = new XSSFWorkbook(new FileInputStream(file));
			workbook = new XSSFWorkbook();
			if(typeOfReport!=null && typeOfReport !="") {
				sheet = workbook.createSheet(typeOfReport);
				CellStyle boldStyle = workbook.createCellStyle();
				Font boldFont = workbook.createFont();
				boldFont.setBold(true);
				boldStyle.setFont(boldFont);
				// Hedear Data
				String[] headers = new String[] { "DocumentTitle", "Reference Number", "Product Company", "Product Line", "Sub Product Line", "Site",
						"Function", "Sub Function", "Document Type", "ISO Element", "User Role", "Process", "Sub Process", "Content Category", "Language",
						"Document State", "Expiry Date", "Effective Date", "Published Date","Document Author", "Document Admin","Functional Owner", "Library URL" };

				// Create Header
				Row row = sheet.createRow(0);

				// Insert Header data
				for (int rn = 0; rn < headers.length; rn++) {
					Cell cell = row.createCell(rn);
					cell.setCellValue(headers[rn]);
					cell.setCellStyle(boldStyle);
				}
			}

		} catch (Exception e1) {
			e1.printStackTrace();
		}

		int rowCount = sheet.getLastRowNum();
		// Insert node List
		for (Map<String, String> rowData : dataForExcel) {
			Row row = sheet.createRow(++rowCount);
			writeIntoCells(row, rowData, workbook, qmsLibraryBaseURL);
		}
		try {
			FileOutputStream outputStream = new FileOutputStream(file);
			workbook.write(outputStream);
			outputStream.close();
			workbook.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return file;
	}


	public void writeIntoCells(Row row, Map<String, String> rowData, Workbook workbook, String qmsLibraryBaseURL) {
		int cellCount = 0;
		Cell cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("name"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("reference"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("productCompany"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("productLine"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("subProductLine"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("site"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("function"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("subFunction"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("docType"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("isoElement"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("userRole"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("process"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("subProcess"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("contentCategory"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("language"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("docState"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("expiryDate"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("effectiveDate"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("publishedDate"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("docAuthorName"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("docAdminName"));
		cell = row.createCell(cellCount++);
		cell.setCellValue(rowData.get("funOwnerName"));
		cell = row.createCell(cellCount++);
		setDocumentUrlValue(cell, workbook, rowData, qmsLibraryBaseURL);
		
	}


	public void setDocumentUrlValue(Cell cell, Workbook workbook, Map<String, String> attributes, String qmsLibraryBaseURL) {

		CellStyle hlink_style = workbook.createCellStyle();
		Font hlink_font = workbook.createFont();
		hlink_font.setUnderline(Font.U_SINGLE);
		hlink_font.setColor(IndexedColors.BLUE.getIndex());
		hlink_style.setFont(hlink_font);

		String nodeRef = attributes.get("nodeRef");
		if(nodeRef != null && nodeRef!="") {
			nodeRef = nodeRef.substring(nodeRef.lastIndexOf("/")+1);
			String linkAddress = qmsLibraryBaseURL+nodeRef;
			Hyperlink href = workbook.getCreationHelper().createHyperlink(HyperlinkType.URL);
			href.setAddress(linkAddress);
			cell.setHyperlink(href);
			cell.setCellStyle(hlink_style);
			cell.setCellValue(linkAddress);
		}
	}

	public String getFileName(String typeOfReport) {

		String fileName = null;
		Calendar calendar = Calendar.getInstance();

		//SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss");
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		//formatter.format(calendar.getTime());
		fileName = typeOfReport+" Reports - " + formatter.format(calendar.getTime());
		//fileName = typeOfReport+" Reports-";
		// fileName = metadata + " By-" +name + " " + fileName;
		return fileName;
	}
}
