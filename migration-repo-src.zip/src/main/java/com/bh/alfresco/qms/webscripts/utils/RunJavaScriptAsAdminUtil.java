package com.bh.alfresco.qms.webscripts.utils;

import org.alfresco.repo.jscript.BaseScopableProcessorExtension;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.Scriptable;

public class RunJavaScriptAsAdminUtil  extends BaseScopableProcessorExtension{
	
	/**
	 * runAsAdmin uses to execute Javascript API as Administrator
	 * @param func
	 */
	public void runAsAdmin(final Function func) {
        final Context cx = Context.getCurrentContext();
        final Scriptable scope = getScope();
        AuthenticationUtil.runAsSystem(() -> {
            func.call(cx, scope, scope, new Object[] {});
            return null;
        });
    }
}
