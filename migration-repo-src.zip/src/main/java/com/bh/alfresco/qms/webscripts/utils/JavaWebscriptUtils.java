package com.bh.alfresco.qms.webscripts.utils;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.error.AlfrescoRuntimeException;
import org.alfresco.repo.version.Version2Model;
import org.alfresco.repo.version.VersionModel;
import org.alfresco.repo.version.common.VersionUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.dictionary.DictionaryService;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.alfresco.service.cmr.version.VersionService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.bh.alfresco.qms.webscripts.datalists.URMDatalistWebscript;

public class JavaWebscriptUtils extends AbstractWebScript {


	private ServiceRegistry serviceRegistry;
	private NodeService nodeService;
	private DictionaryService dictionaryService;
	private VersionService versionService;
	private static final Log LOGGER = LogFactory.getLog(URMDatalistWebscript.class);

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		LOGGER.info("JavaWebscriptUtils Execute method started...");
		String inputJson = req.getContent().getContent();
		LOGGER.info("request inputJson :: "+inputJson);
		JSONParser jsonParser = new JSONParser();
		if(inputJson != null) {
			try {
				JSONObject reqJsonObject = (JSONObject) jsonParser.parse(inputJson);
				String nodeRef=(String) reqJsonObject.get("nodeRef");
				LOGGER.info("request nodeRef :: "+nodeRef);
				
				
				
			} catch (Exception e) {
				LOGGER.error("Error in execute method...");
			}
		}

	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {

		this.serviceRegistry = serviceRegistry;

		this.nodeService = serviceRegistry.getNodeService();

		this.dictionaryService = serviceRegistry.getDictionaryService();

	}


	/**
	 * Util method to add the version histories of translations as a property of the frozen mlContainer
	 */
	private void addVersionHistoryProperty(Version edition, List<ChildAssociationRef> childAssocRefs)
	{
		List<VersionHistory> translationVersionHistories = new ArrayList<VersionHistory>(childAssocRefs.size());

		for (ChildAssociationRef ref : childAssocRefs)
		{
			NodeRef translation = ref.getChildRef();

			translationVersionHistories.add(versionService.getVersionHistory(translation));
		}

		// properties in which the version histories will be stored
		Map<QName, Serializable> properties = new HashMap<QName, Serializable>();

		// Switch VersionStore depending on configured impl
		if (versionService.getVersionStoreReference().getIdentifier().equals(Version2Model.STORE_ID))
		{
			// V2 version store (eg. workspace://version2Store)

			// add the version history of the translation as property of the Edition
			NodeRef versionNodeRef = VersionUtil.convertNodeRef(edition.getFrozenStateNodeRef());
			this.nodeService.setProperty(versionNodeRef, Version2Model.PROP_QNAME_TRANSLATION_VERSIONS, (Serializable) translationVersionHistories);
		}
		else if (versionService.getVersionStoreReference().getIdentifier().equals(VersionModel.STORE_ID))
		{
			// Deprecated V1 version store (eg. workspace://lightWeightVersionStore)

			// add the version history of the translation as property of the Edition
			properties.put(VersionModel.PROP_QNAME_QNAME, VersionModel.PROP_QNAME_TRANSLATION_VERSIONS);
			properties.put(VersionModel.PROP_QNAME_IS_MULTI_VALUE, true);
			properties.put(VersionModel.PROP_QNAME_MULTI_VALUE, (Serializable) translationVersionHistories);

			// create the versioned property node
			this.nodeService.createNode(
					VersionUtil.convertNodeRef(edition.getFrozenStateNodeRef()),
					VersionModel.CHILD_QNAME_VERSIONED_ATTRIBUTES,
					VersionModel.CHILD_QNAME_VERSIONED_ATTRIBUTES,
					VersionModel.TYPE_QNAME_VERSIONED_PROPERTY,
					properties);
		}
		else
		{
			throw new AlfrescoRuntimeException("Unexpected versionstore: " + versionService.getVersionStoreReference().getIdentifier());
		}
	}	

}
