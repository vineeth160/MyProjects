package com.bh.alfresco.qms.webscripts.migration;

import java.io.IOException;

import org.alfresco.model.ContentModel;
import org.alfresco.service.cmr.coci.CheckOutCheckInService;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.version.VersionService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

public class EmbeddedLinksUpdate extends AbstractWebScript {


	private static Log logger = LogFactory.getLog(EmbeddedLinksUpdate.class);

	private NodeService nodeService;
	private CheckOutCheckInService checkOutCheckInService;
	private ContentService contentService;
	private VersionService versionService;

	public NodeService getNodeService() {
		return nodeService;
	}
	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}
	public CheckOutCheckInService getCheckOutCheckInService() {
		return checkOutCheckInService;
	}
	public void setCheckOutCheckInService(CheckOutCheckInService checkOutCheckInService) {
		this.checkOutCheckInService = checkOutCheckInService;
	}
	public ContentService getContentService() {
		return contentService;
	}
	public void setContentService(ContentService contentService) {
		this.contentService = contentService;
	}
	public VersionService getVersionService() {
		return versionService;
	}
	public void setVersionService(VersionService versionService) {
		this.versionService = versionService;
	}

	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		String strNewNodeRef = req.getParameter("newNodeRef");
		String strSourceNodeRef = req.getParameter("sourceNodeRef");
		String strTargetNodeRef = req.getParameter("targetNodeRef");

		logger.info("strNewNodeRef :: "+strNewNodeRef);
		logger.info("strSourceNodeRef :: "+strSourceNodeRef);
		logger.info("strTargetNodeRef :: "+strTargetNodeRef);
		
		NodeRef newNodeRef =  null;
		NodeRef sourceNodeRef = null;
		NodeRef targetNodeRef = null;

		if(strNewNodeRef!=null && strNewNodeRef!="")
			newNodeRef = new NodeRef(strNewNodeRef);

		if(strSourceNodeRef!=null && strSourceNodeRef!="")
			sourceNodeRef = new NodeRef(strSourceNodeRef);

		if(strTargetNodeRef!=null && strTargetNodeRef!="")
			targetNodeRef = new NodeRef(strTargetNodeRef);
		if(newNodeRef !=null) {
			if(sourceNodeRef!=null) {

				Boolean isSourceWorkingCopy = nodeService.hasAspect(sourceNodeRef, ContentModel.ASPECT_WORKING_COPY);
				Boolean isSourceLocked = nodeService.hasAspect(sourceNodeRef, ContentModel.ASPECT_LOCKABLE);

				if(Boolean.FALSE == isSourceWorkingCopy && isSourceLocked) {
					//throw new Exception("Document is either locked or not a working copy, please check with Administrator");
					throw new WebScriptException("Source Document is either locked or not a working copy, please check with Administartor");
				} else{
					try {
						ContentReader newNodeContent = contentService.getReader(newNodeRef, ContentModel.PROP_CONTENT);
						nodeService.setProperty(sourceNodeRef,ContentModel.PROP_AUTO_VERSION, false);
						ContentWriter sourceWriter = contentService.getWriter(sourceNodeRef, ContentModel.PROP_CONTENT, true);
						sourceWriter.setMimetype(newNodeContent.getMimetype());
						sourceWriter.setEncoding("UTF-8");
						sourceWriter.putContent(newNodeContent);

						logger.info("Source node content has been updated successfully...");
					} catch (Exception e) {
						logger.error("Failed to update Source node content\n"+e);
					}

				}
			}

			if(targetNodeRef!=null) {
				Boolean isTargetWorkingCopy = nodeService.hasAspect(targetNodeRef, ContentModel.ASPECT_WORKING_COPY);
				Boolean isTargetLocked = nodeService.hasAspect(targetNodeRef, ContentModel.ASPECT_LOCKABLE);

				if(Boolean.FALSE == isTargetWorkingCopy && isTargetLocked) {
					//throw new Exception("Document is either locked or not a working copy, please check with Administartor");
					throw new WebScriptException(" Publish Document is either locked or not a working copy, please check with Administartor");
				} else{
					try {
						ContentReader newNodeContent = contentService.getReader(newNodeRef, ContentModel.PROP_CONTENT);
						nodeService.setProperty(targetNodeRef,ContentModel.PROP_AUTO_VERSION, false);
						ContentWriter publishWriter = contentService.getWriter(targetNodeRef, ContentModel.PROP_CONTENT, true);
						publishWriter.setMimetype(newNodeContent.getMimetype());
						publishWriter.setEncoding("UTF-8");
						publishWriter.putContent(newNodeContent);
					    logger.info("Publish node content has been updated successfully...");
					} catch (Exception e) {
						logger.error("Failed to update Publish node content\n"+e);
					}
				}
			}
		}
	}
}
