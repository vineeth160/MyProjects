package com.bh.alfresco.qms.webscripts.datalists;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.dictionary.DictionaryService;
import org.alfresco.service.cmr.dictionary.PropertyDefinition;
import org.alfresco.service.cmr.dictionary.TypeDefinition;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.bh.alfresco.qms.constants.BHContentModelConstants;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class HRSystemDatalistWebscript extends AbstractWebScript{
	
	private static final Log logger = LogFactory.getLog(HRSystemDatalistWebscript.class);
	
    private ServiceRegistry serviceRegistry;
	
	private NodeService nodeService;
	
	private DictionaryService dictionaryService;
	
	private SearchService searchService;
	
	private String searchIn;
	
	private String activeProperty;
	
	private String uName;
	

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		
		this.serviceRegistry = serviceRegistry;
		
		this.nodeService = serviceRegistry.getNodeService();
		
		this.dictionaryService = serviceRegistry.getDictionaryService();
		
		this.searchService = serviceRegistry.getSearchService();
		
	}
	
	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}
	
    public boolean isValidRequest(String strSiteName, String dataListType) {
		
		boolean isValidInput = true;
		
		if(serviceRegistry.getSiteService().getSite(strSiteName) == null) {
			
			isValidInput = false;
			
			return isValidInput;
			
		}
		
		if(dictionaryService.getType(QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, dataListType)) == null) {
			
			isValidInput = false;
			
			return isValidInput;
			
		}
		
		return isValidInput;
		
	}
    
	public Set<QName> getQNamesForGivenType(String dataListType) {
		
		QName typeQName = QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, dataListType);
		
		//List<String> propertyNamesList = new ArrayList<String>();
	
		TypeDefinition typeDefinition = dictionaryService.getType(typeQName);
		
		Map<QName,PropertyDefinition> qnamePropertyDefinitionMap = typeDefinition.getProperties();	
		
		Set<QName> set = qnamePropertyDefinitionMap.keySet();
		
		return set;
				
	}
    
    public String generateQuery(String[] searchInArray, String searchText, String siteName) {
    	
    	boolean pathNeeded = false;
    	
    	StringBuilder sb = new StringBuilder();
    	
    	sb.append("(");
    	
    	int index = 0;
    	
    	for(String searchIn : searchInArray) {
    		
    		if(index > 0) {
    			
    			sb.append(" OR ");
    			
    		}
    		
    		sb.append(BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":");
    		
    		sb.append(searchIn+":");
    		
    		sb.append("'"+searchText+"*'");
    		
    		index++;
    		
    	}
    	
    	sb.append(")");
    	
    	sb.append(" AND ");
    	
    	//sb.append(BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":is_employee_active:'TRUE'");
    	
    	sb.append(BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":"+getActiveProperty()+":'TRUE'");
    	
    	if(pathNeeded) {
    		
    		sb.append(" AND ");
    		
    		sb.append("PATH:\"/app:company_home/st:sites/cm:"+siteName+"/cm:dataLists/*/*\"");
    		
    	}
    	
    	//logger.info("Query : : : "+sb.toString());
    	
    	return sb.toString();
    	
    }
    
    public List<NodeRef> getNodeRefsForGivenInput(String searchText, String[] searchInArray, String siteName) {
    	
    	String[] searchSplitArray = searchText.split("\\s");
    	
    	List<NodeRef> nodeRefList = new ArrayList<NodeRef>();
    	
    	for(String searchValue : searchSplitArray) {
    		
        	ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, 
        			generateQuery(searchInArray, searchValue, siteName));
        	
        	//logger.info("Search Results size : : : : "+searchResults.length());;
        	      	
        	nodeRefList.addAll(searchResults.getNodeRefs());
    		
    	}
    	
    	//logger.info("NodeRef List size : : : "+nodeRefList.size());
    	
    	return nodeRefList;
    	
    }
    
    public String generateOutputJSON(List<NodeRef> nodeRefList,  String dataListType) {
    	
    	Set<QName> qnameSet = getQNamesForGivenType(dataListType);
    	
    	JsonObject jsonObject = new JsonObject();
    	
    	jsonObject.addProperty("total", nodeRefList.size());
    	
    	JsonArray jsonArray = new JsonArray();
    	
    	for(NodeRef nodeRef : nodeRefList) {
    		
    		JsonObject rowJsonObject = new JsonObject();
    		
        	Iterator<QName> iterator = qnameSet.iterator();
        	
        	while(iterator.hasNext()) {
        		
        		QName qname = iterator.next();
        		
        		Object propertyValue = nodeService.getProperty(nodeRef, qname);
        		
        		if(propertyValue instanceof String) {
        			
        			rowJsonObject.addProperty(qname.getLocalName(), (String) nodeService.getProperty(nodeRef, qname));
        			
        		}else if(propertyValue instanceof Boolean) {
        			
        			rowJsonObject.addProperty(qname.getLocalName(), (Boolean) nodeService.getProperty(nodeRef, qname));
        			
        		}      		
        		
        	}
        	
        	jsonArray.add(rowJsonObject);
    		
    	}  	
    	
    	jsonObject.add("values", jsonArray);    
    	
    	return jsonObject.toString();
    	
    }
   
    public String executeAndGenerateOutputJSON(String searchText, String[] searchInArray, String siteName, String dataListType) {
	   
    	List<NodeRef> nodeRefList = getNodeRefsForGivenInput(searchText, searchInArray, siteName);
    	
    	String outputJSONString = generateOutputJSON(nodeRefList, dataListType);
    	
    	return outputJSONString;
	   
    }


	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		
		String uName = getuName();
		
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Void>()
		{
			@Override
			public Void doWork() throws Exception {
				
				Map<String, String> templateVariables = req.getServiceMatch().getTemplateVars();
				
				String strSiteName = templateVariables.get("site");
				
				String dataListType = templateVariables.get("datalisttype");
				
				String searchText = req.getParameter("searchtext");
				
				//String searchIn = "employee_sso,employee_email_id,employee_first_name,employee_last_name";
				
				String searchIn = getSearchIn();
				
				String[] searchInArray = searchIn.split(",");
				
				boolean isValidRequest = isValidRequest(strSiteName, dataListType);
				
				if(isValidRequest) {
					
					String outputJSONString = executeAndGenerateOutputJSON(searchText, searchInArray, strSiteName, dataListType);
					
					res.getWriter().write(outputJSONString);
				}
				return null;
			}
		}, uName);
	}

	public String getSearchIn() {
		return searchIn;
	}

	public void setSearchIn(String searchIn) {
		this.searchIn = searchIn;
	}

	public String getActiveProperty() {
		return activeProperty;
	}

	public void setActiveProperty(String activeProperty) {
		this.activeProperty = activeProperty;
	}
	
	

}
