package com.bh.alfresco.qms.webscripts.reports;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.extensions.surf.util.URLEncoder;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.bh.alfresco.qms.webscripts.utils.ErrorStatus;

public class DownloadFileReport extends AbstractWebScript {

	protected ServiceRegistry registry;

	public void setServiceRegistry(ServiceRegistry registry) {
	this.registry = registry;
	}
	private static final Log logger = LogFactory.getLog(DownloadFileReport.class);
	
	private static final String BH_EXPORT_EXCEL="bhExportExcel";

	private static String qmsLibraryBaseURL;
	
	public static String getQmsLibraryBaseURL() {
		return qmsLibraryBaseURL;
	}

	public static void setQmsLibraryBaseURL(String qmsLibraryBaseURL) {
		DownloadFileReport.qmsLibraryBaseURL = qmsLibraryBaseURL;
	}

	private String typeOfReport;
	
	private QMSReportUtils bhQMSReportUtils;

	private ExportToExcelUtils bhExportToExcelUtils;

	private InputStream inputStream;

	

	public QMSReportUtils getBhQMSReportUtils() {
		return bhQMSReportUtils;
	}

	public void setBhQMSReportUtils(QMSReportUtils bhQMSReportUtils) {
		this.bhQMSReportUtils = bhQMSReportUtils;
	}

	public ExportToExcelUtils getBhExportToExcelUtils() {
		return bhExportToExcelUtils;
	}

	public void setBhExportToExcelUtils(ExportToExcelUtils bhExportToExcelUtils) {
		this.bhExportToExcelUtils = bhExportToExcelUtils;
	}

	//private String fileLocation = "";
	
	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
		
		

		File downloadfile = null;
		String bhExportExcel = req.getParameter(BH_EXPORT_EXCEL);
		
		typeOfReport = req.getParameter("typeOfReport");
		
		if (bhExportExcel.equalsIgnoreCase("true")) {
			
			List<NodeRef> nodeRefList = bhQMSReportUtils.getResultNodes(req);
			
			List<Map<String, String>> dataForExcel;
			dataForExcel = bhQMSReportUtils.dataToGenerateExcel(nodeRefList);
			downloadfile = bhExportToExcelUtils.writeToExcel(dataForExcel, typeOfReport, getQmsLibraryBaseURL());
		}
		//logger.debug("downloadfile :: "+downloadfile);

		
	
		
		res.setContentType("application/vnd.ms-excel");
		res.setHeader("Content-disposition", "attachment; filename=" + downloadfile.getName());
		IOUtils.copy(inputStream, res.getOutputStream());

		inputStream.close();

		if (downloadfile.exists()) {
			downloadfile.delete();
		}

	}
}
