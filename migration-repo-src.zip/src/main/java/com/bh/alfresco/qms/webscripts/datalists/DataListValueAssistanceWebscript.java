package com.bh.alfresco.qms.webscripts.datalists;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.model.DataListModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.dictionary.DictionaryService;
import org.alfresco.service.cmr.repository.AssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.bh.alfresco.qms.constants.BHContentModelConstants;

/**
 * Baker Hughes Company
 * @author Ravindhar,K(503100424)
 * @version 1.0
 * This Class is a declarative web script to retrieve fields data as per field and dataList definition name 
 * (we have hard coded few things. Because it will not change)
 */

public class DataListValueAssistanceWebscript extends DeclarativeWebScript{

	//private static final Log logger = LogFactory.getLog(DataListValueAssistanceWebscript.class);
	
	private static final Log logger = LogFactory.getLog(DataListValueAssistanceWebscript.class);

	private static final String ATTRIBUTE_VALUE_ASSISTANCE_DATALIST_NAME = "attributeValueAssistanceListItem";
	
	private static final String LEGAL_ATTRIBUTE_VALUE_ASSISTANCE_DATALIST_NAME = "legalAttributeValueAssistanceListItem";
	
	private static final String LEGAL_URM_DATALIST_NAME = "legalUserRoleMappingDataListItem";

	private static final String PROCESS_SUBPROCESS_DATALIST_NAME = "processSubProcessListItem";

	private static final String FUNCTION_SUBFUNCTION_DATALIST_NAME = "functionSubFunctionListItem";

	private static final String PRODUCTCOMPANY_DATALIST_NAME = "productCompanyListItem";

	private static final String PRODUCTCOMPANY_PRODUCTLINE_SUB_PRODUCTLINE_DATALIST_NAME = "productCompanyProductlineSubProductLineListItem";

	private static final String PRODUCTCOMPANY_DEPENDENT_ATTRIBUTE_VALUEASSISTANCE_DATALIST_NAME = "productCompanyDependentattributeValueAssistanceListItem";		

	private static final String CONTAINER_ID_FOR_DATALIST = "datalists";

	private String uName;

	private static final String SPLIT_REGEX = "~";

	private String strFieldProcessName;

	private String strFieldSubProcessName;

	private String strFieldFunctionName;

	private String strFieldSubFunctionName;

	private String strFieldProductCompanyName;

	private String strFieldProductLineName;

	private String strFieldSubProductLineName;

	private ServiceRegistry serviceRegistry;

	private NodeService nodeService;

	@SuppressWarnings("unused")
	private DictionaryService dictionaryService;

	private SearchService searchService;

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {

		this.serviceRegistry = serviceRegistry;

		this.nodeService = serviceRegistry.getNodeService();

		this.dictionaryService = serviceRegistry.getDictionaryService();

		this.searchService = serviceRegistry.getSearchService();

	}

	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}


	/**
	 * This Method will validate request input
	 * @param req
	 * @param templateArguments
	 * @param strErrorMessage
	 * @return
	 */
	public String validateRequest(WebScriptRequest req, Map<String,String> templateArguments, String strErrorMessage) {

		String strSiteName = templateArguments.get("site");

		if(serviceRegistry.getSiteService().getSite(strSiteName) == null) {
			logger.debug("Site Name is null");

			strErrorMessage = "Provided Site "+strSiteName+" is does not exist";

		}

		if(!(templateArguments.get("datalistname").equals(ATTRIBUTE_VALUE_ASSISTANCE_DATALIST_NAME) || 
				templateArguments.get("datalistname").equals(LEGAL_ATTRIBUTE_VALUE_ASSISTANCE_DATALIST_NAME) ||
				templateArguments.get("datalistname").equals(LEGAL_URM_DATALIST_NAME) ||
				templateArguments.get("datalistname").equals(PROCESS_SUBPROCESS_DATALIST_NAME) ||
				templateArguments.get("datalistname").equals(FUNCTION_SUBFUNCTION_DATALIST_NAME) ||
				templateArguments.get("datalistname").equals(PRODUCTCOMPANY_DATALIST_NAME) ||
				templateArguments.get("datalistname").equals(PRODUCTCOMPANY_PRODUCTLINE_SUB_PRODUCTLINE_DATALIST_NAME) ||
				templateArguments.get("datalistname").equals(PRODUCTCOMPANY_DEPENDENT_ATTRIBUTE_VALUEASSISTANCE_DATALIST_NAME))) {

			strErrorMessage = "This Webscript is only for datalist types "+ATTRIBUTE_VALUE_ASSISTANCE_DATALIST_NAME+","+PROCESS_SUBPROCESS_DATALIST_NAME	
					+" , "+PRODUCTCOMPANY_DEPENDENT_ATTRIBUTE_VALUEASSISTANCE_DATALIST_NAME+" , "+PRODUCTCOMPANY_DATALIST_NAME
					+" , "+FUNCTION_SUBFUNCTION_DATALIST_NAME+" and "+PRODUCTCOMPANY_PRODUCTLINE_SUB_PRODUCTLINE_DATALIST_NAME;
			
			logger.debug(strErrorMessage);
		}

		return strErrorMessage;

	}

	/**
	 * From this method execution of class starts and returns model to FTL
	 */
	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache){

		String uName = getuName();

		return AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Map<String, Object>>()
		{
			@Override
			public Map<String, Object> doWork() throws Exception {
				Map<String, Object> model = generateModelMap(req, status, cache);
				return model;
			}
		}, uName);
	}

	/**
	 * 
	 * @param req
	 * @param status
	 * @param cache
	 * @return model, having field values based on selection criteria Map<String,Object>
	 */
	private Map<String,Object> generateModelMap(WebScriptRequest req, Status status, Cache cache) {
		Map<String,Object> model = new HashMap<String, Object>();

		List<String> attributeValuesFromDataList = new ArrayList<String>();

		Map<String,String> templateArguments = req.getServiceMatch().getTemplateVars();

		@SuppressWarnings("unused")
		String strDatalistTypeValue = null;

		String strErrorMessage = "NONE";

		String strSiteName = templateArguments.get("site");

		String strField = templateArguments.get("field");

		String strListName = templateArguments.get("datalistname");

		String strProcessParameter = req.getParameter("process");

		String strFunctionParameter = req.getParameter("function");

		String strProductCompanyParameter = req.getParameter("productcompany");

		String strProductLineParameter = req.getParameter("productline");

		model.put("field", strField);

		//logger.info("Start of Datalist webscript value Assistance");

		logger.info("Site Parameter : : : : "+templateArguments.get("site"));

		logger.info("Field Parameter : : : : "+templateArguments.get("field"));

		logger.info("DataList Name Parameter : : : : "+templateArguments.get("datalistname"));

		//logger.info("Process Parameter : : : : : "+req.getParameter("process"));

		//logger.info("Product Company Parameter : : : : : "+req.getParameter("productcompany"));

		//logger.info("Product Line Parameter : : : : : "+req.getParameter("productline"));

		strErrorMessage = validateRequest(req,templateArguments,strErrorMessage);

		logger.info("Error Message : : : "+strErrorMessage);

		if(strErrorMessage.equals("NONE")) {

			NodeRef datalistContainerNodeRef = serviceRegistry.getSiteService().getContainer(strSiteName, CONTAINER_ID_FOR_DATALIST);

			String query = "=PARENT:'"+datalistContainerNodeRef.toString()+"' AND ="+DataListModel.DATALIST_MODEL_PREFIX+":"+DataListModel.PROP_DATALIST_ITEM_TYPE.getLocalName()
			+":'"+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":"+strListName+"'";

			ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, query);

			List<NodeRef> dataListNodeRefs = searchResults.getNodeRefs();

			logger.info("Before For Loop&&&&&&&&&&&&&&&&");
			for(NodeRef dataListNodeRef : dataListNodeRefs) {
				
				logger.info("In For Loop&&&&&&&&&&&&&&&&\n"+dataListNodeRef.toString());

				if(ATTRIBUTE_VALUE_ASSISTANCE_DATALIST_NAME.equals(strListName)) {

					attributeValuesFromDataList = getValuesFromValueAssistanceDataList(dataListNodeRef, strField, attributeValuesFromDataList);

				}else if(LEGAL_ATTRIBUTE_VALUE_ASSISTANCE_DATALIST_NAME.equals(strListName)) {

					attributeValuesFromDataList = getLegalValuesFromValueAssistanceDataList(dataListNodeRef, strField, attributeValuesFromDataList);

				}else if(LEGAL_URM_DATALIST_NAME.equals(strListName)) {

					attributeValuesFromDataList = getLegalValuesFromURMDataList(dataListNodeRef, strField, attributeValuesFromDataList);

				}
				else if(PRODUCTCOMPANY_DATALIST_NAME.equals(strListName)) {

					attributeValuesFromDataList = getValuesFromProductCompanyDatalist(dataListNodeRef, strField, attributeValuesFromDataList);

				}else if(PRODUCTCOMPANY_DEPENDENT_ATTRIBUTE_VALUEASSISTANCE_DATALIST_NAME.equals(strListName)) {

					attributeValuesFromDataList = getValuesFromPCDependentValueAssistanceDataList(dataListNodeRef, strField, attributeValuesFromDataList,
							strProductCompanyParameter);

				}else if(PROCESS_SUBPROCESS_DATALIST_NAME.equals(strListName)) {

					attributeValuesFromDataList = getValuesFromProcessSubProcessDataList(dataListNodeRef, strField, attributeValuesFromDataList,
							strProcessParameter);

				}else if(FUNCTION_SUBFUNCTION_DATALIST_NAME.equals(strListName)) {

					attributeValuesFromDataList = getValuesFromFunctionSubFunctionDataList(dataListNodeRef, strField, attributeValuesFromDataList,
							strFunctionParameter, strProductCompanyParameter);

				}else if(PRODUCTCOMPANY_PRODUCTLINE_SUB_PRODUCTLINE_DATALIST_NAME.equals(strListName)) {

					attributeValuesFromDataList = getValuesFromProductCompanyDataList(dataListNodeRef, strField, attributeValuesFromDataList,
							strProductCompanyParameter, strProductLineParameter);

				}

			}

		}

		if(attributeValuesFromDataList != null) {

			Collections.sort(attributeValuesFromDataList);

		}
		
		logger.info("attributeValuesFromDataList End "+attributeValuesFromDataList);

		model.put("errorMessage", strErrorMessage);

		model.put("values", attributeValuesFromDataList);

		return model;
	}


	/**
	 * This method will retrieves field data from productCompanyDependentattributeValueAssistanceListItem
	 * @param dataListNodeRef
	 * @param strField
	 * @param attributeValuesFromDataList
	 * @param strProductCompanyParameter
	 * @return
	 */
	public List<String> getValuesFromPCDependentValueAssistanceDataList(NodeRef dataListNodeRef, String strField, List<String> attributeValuesFromDataList,
			String strProductCompanyParameter) {

		String query = "=PARENT:'"+dataListNodeRef.toString()+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":pc_attribute_name:'"+
				strField+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":pc_name:'"+
				strProductCompanyParameter+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":is_pc_active:'TRUE'";

		ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, query);

		List<NodeRef> nodeRefList = searchResults.getNodeRefs();

		for(NodeRef nodeRef : nodeRefList) {

			String fieldValue = (String) nodeService.getProperty(nodeRef, QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, "pc_attribute_value"));

			if(!attributeValuesFromDataList.contains(fieldValue)) {

				attributeValuesFromDataList.add(fieldValue);

			}

		}

		return attributeValuesFromDataList;

	}


	/**
	 * This method will retrieve field information from dataList productCompanyListItem
	 * @param dataListNodeRef
	 * @param strField
	 * @param attributeValuesFromDataList
	 * @return
	 */
	public List<String> getValuesFromProductCompanyDatalist(NodeRef dataListNodeRef, String strField, List<String> attributeValuesFromDataList) {

		String query = "=PARENT:'"+dataListNodeRef.toString()+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":is_product_company_active:'TRUE'";

		ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, query);

		List<NodeRef> nodeRefList = searchResults.getNodeRefs();

		for(NodeRef nodeRef : nodeRefList) {

			String fieldValue = (String) nodeService.getProperty(nodeRef, QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, "product_company_freetext_name"));

			if(!attributeValuesFromDataList.contains(fieldValue)) {

				attributeValuesFromDataList.add(fieldValue);

			}

		}

		return attributeValuesFromDataList;

	}

	/**
	 * This method will retrieve field information from dataList attributeValueAssistanceListItem
	 * @param dataListNodeRef
	 * @param strField
	 * @param attributeValuesFromDataList
	 * @return
	 */
	public List<String> getValuesFromValueAssistanceDataList(NodeRef dataListNodeRef, String strField, List<String> attributeValuesFromDataList) {

		String query = "=PARENT:'"+dataListNodeRef.toString()+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":attribute_name:'"+
				strField+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":is_active:'TRUE'";

		ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, query);

		List<NodeRef> nodeRefList = searchResults.getNodeRefs();

		for(NodeRef nodeRef : nodeRefList) {

			String fieldValue = (String) nodeService.getProperty(nodeRef, QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, "attribute_value"));

			if(!attributeValuesFromDataList.contains(fieldValue)) {

				attributeValuesFromDataList.add(fieldValue);

			}

		}

		return attributeValuesFromDataList;

	}
	
	/**
	 * This method will retrieve field information from dataList attributeValueAssistanceListItem
	 * @param dataListNodeRef
	 * @param strField
	 * @param legalAttributeValuesFromDataList
	 * @return
	 */
	public List<String> getLegalValuesFromValueAssistanceDataList(NodeRef dataListNodeRef, String strField, List<String> attributeValuesFromDataList) {

		String query = "=PARENT:'"+dataListNodeRef.toString()+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":legal_attribute_name:'"+
				strField+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":legal_is_active:'TRUE'";

		ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, query);

		List<NodeRef> nodeRefList = searchResults.getNodeRefs();

		for(NodeRef nodeRef : nodeRefList) {

			String fieldValue = (String) nodeService.getProperty(nodeRef, QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, "legal_attribute_value"));

			if(!attributeValuesFromDataList.contains(fieldValue)) {

				attributeValuesFromDataList.add(fieldValue);

			}

		}

		return attributeValuesFromDataList;

	}
	
	/**
	 * 
	 * @param dataListNodeRef
	 * @param strField
	 * @param attributeValuesFromDataList
	 * @return
	 */
	public List<String> getLegalValuesFromURMDataList(NodeRef dataListNodeRef, String strField, List<String> attributeValuesFromDataList) {

		String query = "=PARENT:'"+dataListNodeRef.toString()+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":is_legal_urm_active:'TRUE'";

		ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, query);

		List<NodeRef> nodeRefList = searchResults.getNodeRefs();
		//System.out.println("nodeRefList :: "+nodeRefList.size());

		for(NodeRef nodeRef : nodeRefList) {
			
			System.out.println("nodeRef --- "+nodeRef);

			//String fieldValue = (String) nodeService.getProperty(nodeRef, QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, "legal_archival_owner"));
			
			List<AssociationRef> targetAssocList = nodeService.getTargetAssocs(nodeRef, QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, "legal_archival_owner"));
			
			for(AssociationRef assoc : targetAssocList) {
				//System.out.println(assoc);
				String uName = (String) nodeService.getProperty(assoc.getTargetRef(), ContentModel.PROP_USERNAME);
				//System.out.println("uName -- "+uName);
				String fullName = (String) nodeService.getProperty(assoc.getTargetRef(), ContentModel.PROP_FIRSTNAME)+ " "+
						(String) nodeService.getProperty(assoc.getTargetRef(), ContentModel.PROP_LASTNAME);
				//System.out.println("fullName -- "+fullName);
				attributeValuesFromDataList.add(uName+"@@@"+fullName);
			}
		}

		return attributeValuesFromDataList;

	}

	/**
	 * This method will retrieve field information from dataList functionSubFunctionListItem
	 * @param dataListNodeRef
	 * @param strField
	 * @param attributeValuesFromDataList
	 * @param strFunctionParameter
	 * @param strProductCompanyParameter
	 * @return
	 */
	public List<String> getValuesFromFunctionSubFunctionDataList(NodeRef dataListNodeRef, String strField, 
			List<String> attributeValuesFromDataList, String strFunctionParameter, String strProductCompanyParameter) {

		if(strField.equals(getStrFieldFunctionName())) {

			String query = "=PARENT:'"+dataListNodeRef.toString()+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":product_company_name:'"+
					strProductCompanyParameter+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":is_function_sub_function_active:'TRUE'";

			ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, query);

			List<NodeRef> nodeRefList = searchResults.getNodeRefs();

			for(NodeRef nodeRef : nodeRefList) {

				String fieldValue = (String) nodeService.getProperty(nodeRef, QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, "function_value"));

				if(!attributeValuesFromDataList.contains(fieldValue)) {

					attributeValuesFromDataList.add(fieldValue);

				}

			}

		}else if (strField.equals(getStrFieldSubFunctionName())){

			String functionQuery = getQueryString("function_value", strFunctionParameter);

			String query = "=PARENT:'"+dataListNodeRef.toString()+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":product_company_name:'"+
					strProductCompanyParameter+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":is_function_sub_function_active:'TRUE'"+
					functionQuery;;

					ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, query);

					List<NodeRef> nodeRefList = searchResults.getNodeRefs();

					for(NodeRef nodeRef : nodeRefList) {

						String fieldValue = (String) nodeService.getProperty(nodeRef, QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, "sub_function_value"));

						if(!attributeValuesFromDataList.contains(fieldValue)) {

							attributeValuesFromDataList.add(fieldValue);

						}

					}

		}

		return attributeValuesFromDataList;

	}

	/**
	 * This method will retrieve field information from dataList processSubProcessListItem
	 * @param dataListNodeRef
	 * @param strField
	 * @param attributeValuesFromDataList
	 * @param strProcessParameter
	 * @return
	 */
	public List<String> getValuesFromProcessSubProcessDataList(NodeRef dataListNodeRef, String strField, 
			List<String> attributeValuesFromDataList, String strProcessParameter) {

		if(strField.equals(getStrFieldProcessName())) {

			String query = "=PARENT:'"+dataListNodeRef.toString()+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":is_process_sub_rocess_active:'TRUE'";

			ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, query);

			List<NodeRef> nodeRefList = searchResults.getNodeRefs();

			for(NodeRef nodeRef : nodeRefList) {

				String fieldValue = (String) nodeService.getProperty(nodeRef, QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, "process_value"));

				if(!attributeValuesFromDataList.contains(fieldValue)) {

					attributeValuesFromDataList.add(fieldValue);

				}

			}

		}else if (strField.equals(getStrFieldSubProcessName())){

			String processQuery = getQueryString("process_value", strProcessParameter);

			String query = "=PARENT:'"+dataListNodeRef.toString()+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":is_process_sub_rocess_active:'TRUE'"+
					processQuery;

			ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, query);

			List<NodeRef> nodeRefList = searchResults.getNodeRefs();

			for(NodeRef nodeRef : nodeRefList) {

				String fieldValue = (String) nodeService.getProperty(nodeRef, QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, "sub_process_value"));

				if(!attributeValuesFromDataList.contains(fieldValue)) {

					attributeValuesFromDataList.add(fieldValue);

				}

			}

		}

		return attributeValuesFromDataList;

	}

	/**
	 * This method will retrieve field information from dataList productCompanyProductlineSubProductLineListItem
	 * @param dataListNodeRef
	 * @param strField
	 * @param attributeValuesFromDataList
	 * @param strProductCompanyParameter
	 * @param strProductLineParameter
	 * @return
	 */
	public List<String> getValuesFromProductCompanyDataList(NodeRef dataListNodeRef, String strField,
			List<String> attributeValuesFromDataList, String strProductCompanyParameter, String strProductLineParameter) {

		if(strField.equals(getStrFieldProductCompanyName())) {

			String query = "=PARENT:'"+dataListNodeRef.toString()+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":is_product_company_product_line_sub_product_line_active:'TRUE'";

			ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, query);

			List<NodeRef> nodeRefList = searchResults.getNodeRefs();

			for(NodeRef nodeRef : nodeRefList) {

				String fieldValue = (String) nodeService.getProperty(nodeRef, QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, "product_company_value"));

				if(!attributeValuesFromDataList.contains(fieldValue)) {

					attributeValuesFromDataList.add(fieldValue);

				}

			}

		}else if (strField.equals(getStrFieldProductLineName())){

			String query = "=PARENT:'"+dataListNodeRef.toString()+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":product_company_value:'"+
					strProductCompanyParameter+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":is_product_company_product_line_sub_product_line_active:'TRUE'";

			ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, query);

			List<NodeRef> nodeRefList = searchResults.getNodeRefs();

			for(NodeRef nodeRef : nodeRefList) {

				String fieldValue = (String) nodeService.getProperty(nodeRef, QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, "product_line_value"));

				if(!attributeValuesFromDataList.contains(fieldValue)) {

					attributeValuesFromDataList.add(fieldValue);

				}

			}

		}else {

			String productLineQuery = getQueryString("product_line_value", strProductLineParameter);

			String query = "=PARENT:'"+dataListNodeRef.toString()+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":product_company_value:'"+
					strProductCompanyParameter+"' AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":is_product_company_product_line_sub_product_line_active:'TRUE'"
					+" AND ="+BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":pc_pl_attribute_name:'"+strField+"' "
					+productLineQuery;

			ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, query);

			List<NodeRef> nodeRefList = searchResults.getNodeRefs();

			for(NodeRef nodeRef : nodeRefList) {

				String fieldValue = (String) nodeService.getProperty(nodeRef, QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, "pc_pl_attribute_value"));

				if(!attributeValuesFromDataList.contains(fieldValue)) {

					attributeValuesFromDataList.add(fieldValue);

				}

			}

		}

		return attributeValuesFromDataList;

	}

	/**
	 * This method will build FTS query and return as String
	 * @param attributeName
	 * @param attrbuteValue
	 * @return
	 */
	public String getQueryString(String attributeName, String attrbuteValue) {

		StringBuilder stringBuilder = new StringBuilder();

		if(!StringUtils.isBlank(attrbuteValue)) {

			String[] attributeValueSplitArray = attrbuteValue.split(SPLIT_REGEX);

			if(attributeValueSplitArray != null) {

				int index = 0;

				stringBuilder.append(" AND (");

				for(String attributeSplittedValue : attributeValueSplitArray) {

					if(index > 0) {

						stringBuilder.append(" OR ");

					}

					stringBuilder.append("=");

					stringBuilder.append(BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":"+attributeName+":");

					stringBuilder.append("'"+attributeSplittedValue+"'");

					index++;

				}

				stringBuilder.append(")");

			}
		}
		return stringBuilder.toString();

	}


	public String getStrFieldProcessName() {
		return strFieldProcessName;
	}

	public void setStrFieldProcessName(String strFieldProcessName) {
		this.strFieldProcessName = strFieldProcessName;
	}

	public String getStrFieldSubProcessName() {
		return strFieldSubProcessName;
	}

	public void setStrFieldSubProcessName(String strFieldSubProcessName) {
		this.strFieldSubProcessName = strFieldSubProcessName;
	}

	public String getStrFieldFunctionName() {
		return strFieldFunctionName;
	}

	public void setStrFieldFunctionName(String strFieldFunctionName) {
		this.strFieldFunctionName = strFieldFunctionName;
	}

	public String getStrFieldSubFunctionName() {
		return strFieldSubFunctionName;
	}

	public void setStrFieldSubFunctionName(String strFieldSubFunctionName) {
		this.strFieldSubFunctionName = strFieldSubFunctionName;
	}

	public String getStrFieldProductCompanyName() {
		return strFieldProductCompanyName;
	}

	public void setStrFieldProductCompanyName(String strFieldProductCompanyName) {
		this.strFieldProductCompanyName = strFieldProductCompanyName;
	}

	public String getStrFieldProductLineName() {
		return strFieldProductLineName;
	}

	public void setStrFieldProductLineName(String strFieldProductLineName) {
		this.strFieldProductLineName = strFieldProductLineName;
	}

	public String getStrFieldSubProductLineName() {
		return strFieldSubProductLineName;
	}

	public void setStrFieldSubProductLineName(String strFieldSubProductLineName) {
		this.strFieldSubProductLineName = strFieldSubProductLineName;
	}


}
