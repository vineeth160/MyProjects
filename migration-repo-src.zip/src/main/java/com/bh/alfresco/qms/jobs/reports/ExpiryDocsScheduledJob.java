package com.bh.alfresco.qms.jobs.reports;

import org.alfresco.error.AlfrescoRuntimeException;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.schedule.AbstractScheduledLockedJob;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class ExpiryDocsScheduledJob extends AbstractScheduledLockedJob{

	@Override
	public void executeJob(JobExecutionContext jobContext) throws JobExecutionException {
		JobDataMap jobDataMap = jobContext.getJobDetail().getJobDataMap();
		Object executerObj = jobDataMap.get("jobExecuter");
        if (executerObj == null || !(executerObj instanceof ExpiryDocsJobExecuter)) {
            throw new AlfrescoRuntimeException(
                    "ScheduledJob data must contain valid 'Executer' reference");
        }
        
        final ExpiryDocsJobExecuter jobExecuter = (ExpiryDocsJobExecuter) executerObj;

        AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
            public Object doWork() throws Exception {
                jobExecuter.execute();
                return null;
            }
        }, AuthenticationUtil.getSystemUserName());
 	}
}

