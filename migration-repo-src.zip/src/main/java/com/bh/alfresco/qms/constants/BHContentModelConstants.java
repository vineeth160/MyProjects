package com.bh.alfresco.qms.constants;

import org.alfresco.service.namespace.QName;

public class BHContentModelConstants {

	public final static String BH_DATALISTS_NAMESPACE_PREFIX = "bhdl";

	public final static String BH_DATALISTS_NAMESPACE_URI = "http://www.bakerhughes.com/model/datalist/1.0";

	public final static String BH_DOCUMENTS_NAMESPACE_PREFIX = "bhqms";

	public final static String BH_DOCUMENTS_NAMESPACE_URI = "http://www.bakerhughes.com/model/qms/content/1.0";
	
	public static final QName TD_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "type_of_download");
	public static final QName TYPE_BHQMS = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "document");
	public static final QName PC_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "product_company");
	public static final QName PL_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "product_line");
	public static final QName SPL_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "sub_product_line");
	public static final QName SITE_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "site");
	public static final QName FUNCTION_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "function");
	public static final QName SUBFUNCTION_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "sub_function");
	public static final QName DT_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "document_type");

	public static final QName PROP_PR_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "publish_revision");
	public static final QName PROP_REVISION_TYPE_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "revision_type");
	public static final QName PROP_DOCUMENT_STATE_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "document_state");
	public static final QName PROP_REFERENCE_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "reference");
	public static final QName PROP_LANGUAGE_CODE_QNAME= QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "language_code");
	public static final QName PROP_ISO_ELEMENT_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "iso_element");
	public static final QName PROP_PROCESS_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "process");
	public static final QName PROP_SUB_PROCESS_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "sub_process");
	public static final QName PROP_USER_ROLE_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "user_role");
	public static final QName PROP_CONTENT_CATEGORY_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "content_category");
	public static final QName PROP_EXPIRY_DATE_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "expiry_date");
	public static final QName PROP_EFFECTIVE_DATE_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "effective_date");
	public static final QName PROP_PUBLISHED_DATE_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "published_date");
	
	public static final QName PROP_DOC_AUTHOR_NODEREF = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "document_author_noderef");
	public static final QName PROP_DOC_ADMIN_NODEREF = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "document_admin_noderef");
	public static final QName PROP_FUN_ONWER_NODEREF = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "functional_owner_noderef");
	
	public static final QName PROP_FULLNAME = QName.createQName(BH_DATALISTS_NAMESPACE_URI, "employee_full_name");
	
	public static final QName ASSOC_DOCUMENT_AUTHOR_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "document_author");
	public static final QName ASSOC_DOCUMENT_ADMIN_QNAME = QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "document_admin");
	public static final QName ASSOC_FUNCTIONAL_OWNER_QNAME= QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "functional_owner");
	public static final QName ASSOC_REVISION_QNAME= QName.createQName(BH_DOCUMENTS_NAMESPACE_URI, "revision_association");
	
	// IDS Integration Constants DEV
//	public static final String TOKEN_GENERATION_URL = "https://bhqmsdev.alfrescocloud.com/auth/realms/alfresco/protocol/openid-connect/token";
//	public static final String USER_API_URL = "https://bhqmsdev.alfrescocloud.com/auth/admin/realms/alfresco/users";
//	public static final String IDS_USERNAME = "ids_integration";
//	public static final String IDS_PASSWORD = "ids_integration";

	// IDS Integration Constants UAT
	public static final String TOKEN_GENERATION_URL = "https://bhuat.alfrescocloud.com/auth/realms/alfresco/protocol/openid-connect/token";
	public static final String USER_API_URL = "https://bhuat.alfrescocloud.com/auth/admin/realms/alfresco/users";
	public static final String IDS_USERNAME = "ids_integration";
	public static final String IDS_PASSWORD = "ids_integration";


	// IDS Integration Constants PROD
//	public static final String TOKEN_GENERATION_URL = "https://bh.alfrescocloud.com/auth/realms/alfresco/protocol/openid-connect/token";
//	public static final String USER_API_URL = "https://bh.alfrescocloud.com/auth/admin/realms/alfresco/users";
//	public static final String IDS_USERNAME = "ids_integration";
//	public static final String IDS_PASSWORD = "ids_integration";
}
