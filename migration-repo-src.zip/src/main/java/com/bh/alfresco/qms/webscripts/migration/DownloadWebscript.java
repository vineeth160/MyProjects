package com.bh.alfresco.qms.webscripts.migration;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionHistory;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.AbstractWebScript;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.WebScriptResponse;

import com.bh.alfresco.qms.constants.BHContentModelConstants;
import com.documents4j.api.DocumentType;
import com.documents4j.api.IConverter;
import com.documents4j.job.LocalConverter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.io.Files;
import org.alfresco.service.namespace.QName;

public class DownloadWebscript extends AbstractWebScript {

	
	
//	private static Logger log = Logger.getLogger(CalculateChecksumWS.class);
	ServiceRegistry serviceRegistry;

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
	
	public ContentService getContentService() {
		return contentService;
	}
	public void setContentService(ContentService contentService) {
		this.contentService = contentService;
	}

	private ContentService contentService;
	
	public NodeService getNodeService() {
		return nodeService;
	}
	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}
	private NodeService nodeService;
	
	@Override
	public void execute(WebScriptRequest req, WebScriptResponse res) throws IOException {
       
		String  extension = req.getParameter("extension");
		/*Map<QName, Serializable> props = new HashMap<>();
		JSONObject propValues = new JSONObject(propertiesJson);
		*/		
		/*String mimeType = contentService.getReader(node, ContentModel.PROP_CONTENT).getMimetype().trim();
        System.out.println("mimeType="+mimeType);*/
        
        /*final Map<QName, Serializable> props = new HashMap<QName, Serializable>();
      
        Map<QName, Serializable> nodeProperties = serviceRegistry.getNodeService().getProperties(nodeRef);
        
        
        if (exte != null && paramName.equalsIgnoreCase("modifier") && paramValue != null
                && !paramValue.toString().isEmpty()) {
            props.put(ContentModel.PROP_MODIFIER, paramValue);
        }*/
        
       
        
        
       		
		
		String nodeRefString = req.getParameter("nodeRef");	
		NodeRef nodeRef = null;
		if (null == nodeRefString || "".equals(nodeRefString.trim())) {
		res.setStatus(520);
		res.getWriter().write(520);
		res.getWriter().close();
		return;
		}
		
		

		try {
			 nodeRef = new NodeRef(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, nodeRefString);
			 
			 System.out.println("current node ref..."+nodeRef);
			 			 
		     //Get the name of word document so that we can set it on the pdf document.
		        //String fileName = nodeService.getProperty(nodeRef, ContentModel.PROP_NAME).toString();
		       
		      //  System.out.println("filename....."+ fileName);
		        
		        String docName =(String)serviceRegistry.getNodeService().getProperty(nodeRef,ContentModel.PROP_NAME);
		        
		        System.out.println("docName....."+ docName);
		        
		        String fileExtension = Files.getFileExtension(docName);
		        System.out.println("fileExtension....."+ fileExtension);
		        //String fileExtension = "docx";
		        
		      //  String sourceName = (String) serviceRegistry.getNodeService().getProperty(nodeRef, ContentModel.PROP_NAME);
		        
		  
		        String typeOfDocument =(String)serviceRegistry.getNodeService().getProperty(nodeRef, BHContentModelConstants.TD_QNAME);
		        System.out.println("<<<<typeOfDocument>>>>>"+typeOfDocument);
		  
		 // to convert docx to pdf 
		if (typeOfDocument.equalsIgnoreCase("Download as PDF") && (!fileExtension.equalsIgnoreCase("pdf"))){   
		       // if(fileExtension.equalsIgnoreCase("docx")) {
							 				
		if(serviceRegistry.getFileFolderService().getFileInfo(nodeRef).isFolder()){
		res.setStatus(530);
		res.getWriter().write("Content not a file.");
		res.getWriter().close();
		return; 
		}
		res.setHeader("Content-disposition", "attachment; filename="
		+ URLEncoder.encode((serviceRegistry.getFileFolderService().getFileInfo(nodeRef).getName().substring(0, serviceRegistry.getFileFolderService().getFileInfo(nodeRef).getName().lastIndexOf("."))+".pdf"),"UTF-8").replaceAll("\\+", "%20"));
		
		res.setContentType(serviceRegistry.getContentService()
		.getReader(nodeRef, ContentModel.TYPE_CONTENT)
		.getMimetype());
	
		
		ContentReader contentReader= null;
			
		contentReader = serviceRegistry.getContentService().getReader(nodeRef, ContentModel.PROP_CONTENT);
		
		InputStream docxInputStream = contentReader.getContentInputStream();
      
        IConverter converter = LocalConverter.builder().build();
        
        converter.convert(docxInputStream).as(DocumentType.DOCX).to(res.getOutputStream()).as(DocumentType.PDF).execute();
     
   		return;		
				
		}
		
		//Get the name of pdf document so that we can set it on the pdf document.
		else {						 
		   		       
		if(serviceRegistry.getFileFolderService().getFileInfo(nodeRef).isFolder()){
		res.setStatus(530);
		res.getWriter().write("Content not a file.");
		res.getWriter().close();
		return; 
		}
		
		res.setHeader("Content-disposition", "attachment; filename="
				+ URLEncoder.encode(serviceRegistry.getFileFolderService().getFileInfo(nodeRef).getName(),"UTF-8").replaceAll("\\+", "%20"));
				res.setContentType(serviceRegistry.getContentService()
				.getReader(nodeRef, ContentModel.TYPE_CONTENT)
				.getMimetype());
				serviceRegistry.getContentService()
				.getReader(nodeRef, ContentModel.TYPE_CONTENT)
				.getContent(res.getOutputStream());
				return;			
		}
		} 
		catch (Exception e) {
			res.setStatus(530);
			res.getWriter().write("Unable to download the document.");
			res.getWriter().close();
			e.printStackTrace();
			return;
			}
	}
			
	}
