package com.bh.alfresco.qms.workflow.utils;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.ExecutionListener;
import org.activiti.engine.delegate.JavaDelegate;
import org.alfresco.repo.workflow.activiti.script.DelegateExecutionScriptBase;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class GetWorkflowDetails extends DelegateExecutionScriptBase implements ExecutionListener, JavaDelegate{
	private static final Log logger = LogFactory.getLog(GetWorkflowDetails.class);

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		notify(execution);
	}

	@Override
	public void notify(DelegateExecution execution) throws Exception {
		String workflowId = execution.getId();
		logger.info("workflowId in Java Log:: "+workflowId);
		logger.info("workflowId in Java:: "+workflowId);
		execution.setVariable("bhwf_workflow_id", workflowId);
	}
}
