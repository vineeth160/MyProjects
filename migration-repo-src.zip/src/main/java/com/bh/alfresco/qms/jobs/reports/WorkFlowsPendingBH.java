package com.bh.alfresco.qms.jobs.reports;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.workflow.WorkflowModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.action.Action;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.workflow.WorkflowInstance;
import org.alfresco.service.cmr.workflow.WorkflowTask;
import org.alfresco.service.cmr.workflow.WorkflowTaskQuery;
import org.alfresco.service.cmr.workflow.WorkflowTaskState;
import org.alfresco.service.namespace.QName;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bh.alfresco.qms.constants.BHContentModelConstants;

public class WorkFlowsPendingBH {
	private static final Log logger = LogFactory.getLog(WorkFlowsPendingBH.class);

	private String bhwf_ADF_TASK_URL;
	
	public static final String APP_MODEL_1_0_URI = BHContentModelConstants.BH_DOCUMENTS_NAMESPACE_URI;
	public static final String APP_WF_MODEL_1_0_URI = "http://http://www.bakerhughes.com/model/workflow/1.0";
	List<WorkflowInstance> pendingWorkflows = new ArrayList<WorkflowInstance>();
	Map<String, Object> mapOfTaskDetails = new HashMap<String, Object>();
	Map<String, List<Map<String, Object>>> mapOfTaskDetailsForEveryOwner = new HashMap<String, List<Map<String, Object>>>();
	QName PROP_QNAME_REFERENCE_NUMBER = QName.createQName(APP_MODEL_1_0_URI, "reference");
	QName PROP_QNAME_REASON_FOR_REVISION = QName.createQName(APP_MODEL_1_0_URI, "reason_for_revision");
	QName PROP_QNAME_HR_TASK_OWNER_NAME = QName.createQName(APP_WF_MODEL_1_0_URI, "hr_taskowner_name");
	QName PROP_QNAME_HR_TASK_OWNER_MAIL = QName.createQName(APP_WF_MODEL_1_0_URI, "hr_taskowner_mail");
	QName PROP_QNAME_WF_REQUEST_TYPE = QName.createQName(APP_WF_MODEL_1_0_URI, "request_type");

	private SearchService searchService;
	// should be an XPath
	private String emailTemplate = "/app:company_home/app:dictionary/app:email_templates/app:notify_email_templates/cm:Reports/cm:bh-wfReminder-email.html.ftl";

	private ServiceRegistry serviceRegistry;

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public void execute() {
		Map<String, List<Map<String, Object>>> pendingTasksUserWise = getWorkflowsTask();
		sendEmails(pendingTasksUserWise);
	}

	public Map<String, List<Map<String, Object>>> getWorkflowsTask() {

		logger.info("getWorkflowsTask");
		List<WorkflowInstance> workflowsActive = serviceRegistry.getWorkflowService().getActiveWorkflows();
		logger.info("workflowsActive :: "+workflowsActive);
		//serviceRegistry.getWorkflowService().getCompletedWorkflows();
		for (WorkflowInstance wfi : workflowsActive) {
			boolean pending = isWorkflowPending(wfi.getStartDate());
			logger.info("pending...."+pending);
			if (pending) {
				WorkflowTaskQuery taskQuery = new WorkflowTaskQuery();
				taskQuery.setActive(true);
				taskQuery.setProcessId(wfi.getId());
				taskQuery.setTaskState(WorkflowTaskState.IN_PROGRESS);
				List<WorkflowTask> allTasks = serviceRegistry.getWorkflowService().queryTasks(taskQuery, true);

				logger.info("allTasks :: "+allTasks);
				
				
				
				

				for (WorkflowTask wfT : allTasks) {
					String adfTaskUrl = getBhwf_ADF_TASK_URL();
					
					logger.info("Task Title :: "+wfT.getTitle());
					
					Map<QName, Serializable> props = wfT.getProperties();
					Set<QName> keys = props.keySet();
					for(QName key: keys) {
						logger.info("WF Props - \n"+key+"  ::  "+props.get(key));
					}
					Date startDate = (Date) props.get(WorkflowModel.PROP_START_DATE);
					String taskId = (String) props.get(WorkflowModel.PROP_TASK_ID);
					String hrTaskOwner = (String) props.get(PROP_QNAME_HR_TASK_OWNER_NAME);
					String hrTaskOwnerMail = (String) props.get(PROP_QNAME_HR_TASK_OWNER_MAIL);
					String wfRequestType = (String) props.get(PROP_QNAME_WF_REQUEST_TYPE);
					String assignedTo = "";
					String assignedMail = "";
					if(hrTaskOwner != null && hrTaskOwner != "" && hrTaskOwner != "null") {
						assignedTo = hrTaskOwner;
					} else {
						assignedTo = (String) props.get(ContentModel.PROP_OWNER);
					}
					if(hrTaskOwnerMail != null && hrTaskOwnerMail != "" && hrTaskOwnerMail != "null") {
						assignedMail = hrTaskOwnerMail;
					} else {
						NodeRef userNameNode = serviceRegistry.getPersonService().getPerson(assignedTo);
						assignedMail = (String) serviceRegistry.getNodeService().getProperty(userNameNode, ContentModel.PROP_EMAIL);
					}
					String wfDescription = (String) props.get(WorkflowModel.PROP_DESCRIPTION);
					String taskName = wfT.getTitle();
					NodeRef packages = (NodeRef) props.get(WorkflowModel.ASSOC_PACKAGE);
					List<ChildAssociationRef> existingChildren =null;
					if(packages!=null)
					{
						existingChildren = serviceRegistry.getNodeService().getChildAssocs(packages);
					}
						Map<String, Object> mapOfTaskDetails = new HashMap<String, Object>();
					mapOfTaskDetails.put("startDate", startDate);
					mapOfTaskDetails.put("id", taskId);
					mapOfTaskDetails.put("assignedTo", assignedTo);
					mapOfTaskDetails.put("assignedMail", assignedMail);
					mapOfTaskDetails.put("taskName", taskName);
					mapOfTaskDetails.put("wfDescription", wfDescription);
					mapOfTaskDetails.put("attachedDoc", existingChildren);
					mapOfTaskDetails.put("adfTaskUrl", adfTaskUrl);
					mapOfTaskDetails.put("wfRequestType", wfRequestType);
					
					
					for(String key: mapOfTaskDetails.keySet()) {
						logger.info("mapOfTaskDetails - "+key+" :: "+mapOfTaskDetails.get(key));
					}

					List<Map<String, Object>> taskDetailsList = mapOfTaskDetailsForEveryOwner.get(assignedTo);
					if (taskDetailsList == null) {
						taskDetailsList = new ArrayList<Map<String, Object>>();
					}
					taskDetailsList.add(mapOfTaskDetails);
					mapOfTaskDetailsForEveryOwner.put(assignedTo, taskDetailsList);
				}
			}
		}
		return mapOfTaskDetailsForEveryOwner;
	}

	public boolean isWorkflowPending(Date wfStartDate) {
		Calendar cal = Calendar.getInstance();

		logger.info("wfStartDate :: "+wfStartDate);
		logger.info("cal.getTime() :: "+cal.getTime());
		logger.info("Current vs wfStartDate -1 :: "+cal.getTime().compareTo(wfStartDate));

		cal.add(Calendar.DAY_OF_MONTH, -7);
		Date limitdate = cal.getTime();

		logger.info("Current vs wfStartDate -2 :: "+cal.getTime().compareTo(wfStartDate));

		Calendar calTest = Calendar.getInstance();
		calTest.add(Calendar.DAY_OF_MONTH, -7);
		logger.info("calTest -7 :: "+calTest.getTime());

		if (wfStartDate.compareTo(limitdate) < 0 || wfStartDate.compareTo(limitdate) == 0) {
			return true;
		} else {
			return false;
		}

	}

	public void sendEmails(Map<String, List<Map<String, Object>>> usersTasksMap) {
		for (Map.Entry<String, List<Map<String, Object>>> userMap : usersTasksMap.entrySet()) {
			
			List<Map<String, Object>> userTasks = userMap.getValue();
			for (Map<String, Object> userTask : userTasks) {
				sendEmail(userTask);
			}
		}
	}

	public void sendEmail(Map<String, Object> task) {

		for(String key: task.keySet()) {
			logger.info("sendEmail TaskDetails - "+key+" :: "+task.get(key));
		}
		Action mail = serviceRegistry.getActionService().createAction(MailActionExecuter.NAME);
		@SuppressWarnings("unchecked")
		List<ChildAssociationRef> packageItems = (List<ChildAssociationRef>) task.get("attachedDoc");
		NodeRef packageNode = null;
		for (ChildAssociationRef node : packageItems) {
			packageNode = node.getChildRef();
		}
		
		StoreRef storeRef = new StoreRef(StoreRef.PROTOCOL_WORKSPACE, "SpacesStore");
		
		String documentName = (String) serviceRegistry.getNodeService().getProperty(packageNode, ContentModel.PROP_NAME);
		logger.info("document name :: "+documentName);
		
		mail.setParameterValue(MailActionExecuter.PARAM_TO, (String) task.get("assignedMail"));
		mail.setParameterValue(MailActionExecuter.PARAM_SUBJECT, "Reminder: ISO BH Document under Name: '"+documentName+"' has been sent to you for "+task.get("taskName"));
		
		Map<String, Serializable> templateArgs = new HashMap<String, Serializable>();
		
		
		//templateArgs.put("personName", (String) task.get("assignedTo"));
		//templateArgs.put("documentName", documentName);
		//templateArgs.put("documentRef", (String) serviceRegistry.getNodeService().getProperty(packageNode, PROP_QNAME_REFERENCE_NUMBER));
		//templateArgs.put("versionNumber", (String) serviceRegistry.getNodeService().getProperty(packageNode, PROP_QNAME_REASON_FOR_REVISION));
		
		String taskName = (String) task.get("taskName");
		String adfTaskUrl = (String) task.get("adfTaskUrl");
		String wfRequestType = (String) task.get("wfRequestType");
		String taskId = (String) task.get("id");
		String wfDescription = (String) task.get("wfDescription");
		String requestValue = "";
		if(wfRequestType.equals("NDR"))
			requestValue = "New";
		if(wfRequestType.equals("RDR"))
			requestValue = "Revision";
		if(wfRequestType.equals("ADR"))
			requestValue = "Archival";
		
		templateArgs.put("requestType", wfRequestType);
		templateArgs.put("requestValue", requestValue);
		templateArgs.put("adfTaskUrl", adfTaskUrl+taskId);
		templateArgs.put("taskName", taskName);
		templateArgs.put("taskId", "activiti$"+taskId);
		templateArgs.put("workflowDescription", wfDescription);
		
		if(taskName.contains("Publish") || taskName.contains("Admin")) {
			templateArgs.put("isAdmin", "YES");
		} else {
			templateArgs.put("isAdmin", "NO");
		}
		
		Set<String> keys = templateArgs.keySet();
		for(String key: keys) {
			logger.info("templateArgs - \n"+key+"  ::  "+templateArgs.get(key));
		}
		Map<String, Serializable> templateModel = new HashMap<String, Serializable>();
		templateModel.put("args", (Serializable) templateArgs);
		mail.setParameterValue(MailActionExecuter.PARAM_TEMPLATE_MODEL, (Serializable) templateModel);
		// Getting nodeRef of template
		ResultSet results = searchService.query(storeRef, SearchService.LANGUAGE_XPATH, emailTemplate);
		mail.setParameterValue(MailActionExecuter.PARAM_TEMPLATE, results.getNodeRef(0));
				
		
		mail.setParameterValue(MailActionExecuter.PARAM_IGNORE_SEND_FAILURE, false);
		serviceRegistry.getActionService().executeAction(mail, packageNode);
	}

	public void setSearchService(SearchService search) {
		this.searchService = search;
	}
	
	
	public String getBhwf_ADF_TASK_URL() {
		return bhwf_ADF_TASK_URL;
	}

	public void setBhwf_ADF_TASK_URL(String bhwf_ADF_TASK_URL) {
		this.bhwf_ADF_TASK_URL = bhwf_ADF_TASK_URL;
	}
	
}