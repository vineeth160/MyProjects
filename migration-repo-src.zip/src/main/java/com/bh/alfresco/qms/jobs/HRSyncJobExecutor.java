package com.bh.alfresco.qms.jobs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.alfresco.model.ContentModel;
import org.alfresco.model.DataListModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.dictionary.DictionaryService;
import org.alfresco.service.cmr.dictionary.PropertyDefinition;
import org.alfresco.service.cmr.dictionary.TypeDefinition;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;

import com.bh.alfresco.qms.constants.BHContentModelConstants;

//Author Ravindhar,K(503100424)

public class HRSyncJobExecutor {

	private static final Log logger = LogFactory.getLog(HRSyncJobExecutor.class);

	private static final String CONTAINER_ID_FOR_DATALIST = "datalists";

	private static final String STRING_SPLIT_REGEX = "|";

	private ServiceRegistry serviceRegistry;

	private NodeService nodeService;

	private DictionaryService dictionaryService;

	private SearchService searchService;

	private String siteName;

	private String inputFileUUID;

	private String nameSpacePrefix;

	private String nameSpaceURI;

	private String dataListTypeName;

	private String dataListName;

	private String activePropertyName;

	private String validateWith;
	
	private String dataListTitleName;
	
    private String cmName;
	
	private String cmNameSSO;

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {

		this.serviceRegistry = serviceRegistry;

		this.nodeService = serviceRegistry.getNodeService();

		this.dictionaryService = serviceRegistry.getDictionaryService();

		this.searchService = serviceRegistry.getSearchService();

	}

	@SuppressWarnings("deprecation")
	public Map<String,QName> getCustomTypePropertiesTitleFromDictionaryService(String strDataListType, String nameSpaceURI) {

		Map<String,QName> titleQNameMap = new HashMap<String,QName>();

		TypeDefinition typeDefinition = dictionaryService.getType(QName.createQName(nameSpaceURI,strDataListType));

		Map<QName,PropertyDefinition> typeProperties = typeDefinition.getProperties();

		Set<QName> set = typeProperties.keySet();

		Iterator<QName> i = set.iterator();

		while(i.hasNext()) {

			QName qname = i.next();

			titleQNameMap.put(typeProperties.get(qname).getTitle(), qname);

		}

		return titleQNameMap;

	}

	@SuppressWarnings("deprecation")
	public Map<String,QName> getCustomTypePropertiesTitleLCFromDictionaryService(String strDataListType, String nameSpaceURI) {

		Map<String,QName> titleQNameMap = new HashMap<String,QName>();

		TypeDefinition typeDefinition = dictionaryService.getType(QName.createQName(nameSpaceURI,strDataListType));

		Map<QName,PropertyDefinition> typeProperties = typeDefinition.getProperties();

		Set<QName> set = typeProperties.keySet();

		Iterator<QName> i = set.iterator();

		while(i.hasNext()) {

			QName qname = i.next();

			if(typeProperties.get(qname).getTitle() != null || (!typeProperties.get(qname).getTitle().equals(""))) {

				titleQNameMap.put(typeProperties.get(qname).getTitle().toLowerCase(), qname);

			}else {

				titleQNameMap.put(typeProperties.get(qname).getTitle(), qname);

			}

		}

		return titleQNameMap;

	}

	@SuppressWarnings("deprecation")
	public Map<QName, String> getQNameAndPropertiesMapForGivenType(String strDataListType, String nameSpaceURI) {

		Map<QName, String> qnameAndTitleMap = new HashMap<QName, String>();

		TypeDefinition typeDefinition = dictionaryService.getType(QName.createQName(nameSpaceURI,strDataListType));

		Map<QName,PropertyDefinition> typeProperties = typeDefinition.getProperties();

		Set<QName> set = typeProperties.keySet();

		Iterator<QName> i = set.iterator();

		while(i.hasNext()) {

			QName qname = i.next();

			qnameAndTitleMap.put(qname, typeProperties.get(qname).getTitle());

		}

		return qnameAndTitleMap;

	}

	@SuppressWarnings("deprecation")
	public Map<QName, String> getQNameAndPropertiesLCMapForGivenType(String strDataListType, String nameSpaceURI) {

		Map<QName, String> qnameAndTitleMap = new HashMap<QName, String>();

		TypeDefinition typeDefinition = dictionaryService.getType(QName.createQName(nameSpaceURI,strDataListType));

		Map<QName,PropertyDefinition> typeProperties = typeDefinition.getProperties();

		Set<QName> set = typeProperties.keySet();

		Iterator<QName> i = set.iterator();

		while(i.hasNext()) {

			QName qname = i.next();

			if(typeProperties.get(qname).getTitle() != null || (!typeProperties.get(qname).getTitle().equals(""))) {

				qnameAndTitleMap.put(qname, typeProperties.get(qname).getTitle().toLowerCase());

			}else {

				qnameAndTitleMap.put(qname, typeProperties.get(qname).getTitle());

			}

		}

		return qnameAndTitleMap;

	}

	public List<String> getHeaders(XSSFSheet sheet) {

		List<String> headersList = new ArrayList<String>();

		XSSFRow headers = sheet.getRow(0);

		int numberOfCells = headers.getPhysicalNumberOfCells();

		for(int cellIndex = 0; cellIndex < numberOfCells; cellIndex++) {

			headersList.add(headers.getCell(cellIndex).getStringCellValue());

		}

		return headersList;

	}

	public Map<Integer,String> getIndexHeadersMap(XSSFSheet sheet) {

		Map<Integer,String> headersList = new HashMap<Integer,String>();

		XSSFRow headers = sheet.getRow(0);

		int numberOfCells = headers.getPhysicalNumberOfCells();

		for(int cellIndex = 0; cellIndex < numberOfCells; cellIndex++) {

			headersList.put(cellIndex,headers.getCell(cellIndex).getStringCellValue());

		}

		return headersList;

	}

	@SuppressWarnings("null")
	public Map<Integer,String> getIndexHeadersMapFromtxt(String firstLineIntxt){

		Map<Integer,String> headersList = new HashMap<Integer,String>();

		if(firstLineIntxt != null) {

			int columnIndex = 0;

			do {

				String splittedValue = null;

				if(firstLineIntxt.contains(STRING_SPLIT_REGEX)) {

					splittedValue = firstLineIntxt.substring(0,firstLineIntxt.indexOf(STRING_SPLIT_REGEX));

					if(splittedValue != null || (!splittedValue.equalsIgnoreCase(""))) {

						splittedValue = splittedValue.trim().toLowerCase();

					}

					headersList.put(columnIndex++, splittedValue);

					firstLineIntxt = firstLineIntxt.substring(firstLineIntxt.indexOf(STRING_SPLIT_REGEX)+1);

					if(!firstLineIntxt.contains(STRING_SPLIT_REGEX)) {

						splittedValue = firstLineIntxt;

						if(splittedValue != null || (!splittedValue.equalsIgnoreCase(""))) {

							splittedValue = splittedValue.trim().toLowerCase();

						}

						headersList.put(columnIndex++, splittedValue);

					}

				}

			}while(firstLineIntxt.contains(STRING_SPLIT_REGEX));

			headersList.put(columnIndex++, "is active");

		}

		return headersList;

	}

	@SuppressWarnings("null")
	public Map<String,Integer> getHeadersIndexMapFromtxt(String firstLineIntxt){

		Map<String,Integer> headersList = new HashMap<String,Integer>();

		if(firstLineIntxt != null) {

			int columnIndex = 0;

			do {

				String splittedValue = null;

				if(firstLineIntxt.contains(STRING_SPLIT_REGEX)) {

					splittedValue = firstLineIntxt.substring(0,firstLineIntxt.indexOf(STRING_SPLIT_REGEX));

					if(splittedValue != null || (!splittedValue.equalsIgnoreCase(""))) {

						splittedValue = splittedValue.trim().toLowerCase();

					}

					headersList.put(splittedValue, columnIndex++);

					firstLineIntxt = firstLineIntxt.substring(firstLineIntxt.indexOf(STRING_SPLIT_REGEX)+1);

					if(!firstLineIntxt.contains(STRING_SPLIT_REGEX)) {

						splittedValue = firstLineIntxt;

						if(splittedValue != null || (!splittedValue.equalsIgnoreCase(""))) {

							splittedValue = splittedValue.trim().toLowerCase();

						}

						headersList.put(splittedValue, columnIndex++);

					}

				}

			}while(firstLineIntxt.contains(STRING_SPLIT_REGEX));

			headersList.put("is active", columnIndex++);

		}

		return headersList;

	}


	public Map<String,Integer> getHeadersIndexMap(XSSFSheet sheet) {

		Map<String,Integer> headersList = new HashMap<String,Integer>();

		XSSFRow headers = sheet.getRow(0);

		int numberOfCells = headers.getPhysicalNumberOfCells();

		for(int cellIndex = 0; cellIndex < numberOfCells; cellIndex++) {

			headersList.put(headers.getCell(cellIndex).getStringCellValue(),cellIndex);

		}

		return headersList;

	}


	public boolean isValidIUnputExcel(List<String> headersList,Map<String,QName> titleQNameMap) {

		boolean isValid = false;

		Set<String> keys = titleQNameMap.keySet();

		for(String header : headersList) {

			if(keys.contains(header)) {

				isValid = true;

			}else {

				return false;

			}

		}

		return isValid;

	}

	public boolean isValidInputtxt(Set<String> headersList,Map<String,QName> titleLCQNameMap) {

		boolean isValid = false;

		Set<String> keys = titleLCQNameMap.keySet();

		for(String header : headersList) {

			if(keys.contains(header)) {

				isValid = true;

			}else {

				return false;

			}

		}

		return isValid;

	}

	@SuppressWarnings({ "unused", "null" })
	public List<Map<Integer, String>> readTextFile(BufferedReader bufferedReader) {

		List<Map<Integer, String>> textData = new ArrayList<Map<Integer, String>>();

		String strLine;

		try {

			while((strLine = bufferedReader.readLine()) != null) {

				Map<Integer, String> rowDataMap = new HashMap<Integer, String>();

				int columnIndex = 0;

				do {

					String splittedValue = null;

					if(strLine.contains(STRING_SPLIT_REGEX)) {

						splittedValue = strLine.substring(0,strLine.indexOf(STRING_SPLIT_REGEX));

						if(splittedValue != null || (!"".equals(splittedValue))) {

							rowDataMap.put(columnIndex++, splittedValue.trim());

						}else {

							rowDataMap.put(columnIndex++, splittedValue);

						}

						strLine = strLine.substring(strLine.indexOf(STRING_SPLIT_REGEX)+1);

						if(!strLine.contains(STRING_SPLIT_REGEX)) {

							splittedValue = strLine;

							if(splittedValue != null || (!"".equals(splittedValue))) {

								rowDataMap.put(columnIndex++, splittedValue.trim());

							}else {

								rowDataMap.put(columnIndex++, splittedValue);

							}

						}

					}

				}while(strLine.contains(STRING_SPLIT_REGEX));

				rowDataMap.put(columnIndex++, "TRUE");

				textData.add(rowDataMap);

			}

		} catch (IOException e) {

			e.printStackTrace();

		}

		return textData;

	}


	public Object[][] readDataFromExcel(XSSFSheet sheet) {

		int numberOfRows = sheet.getPhysicalNumberOfRows();

		int numberOfCellsInARow = sheet.getRow(0).getPhysicalNumberOfCells();

		Object[][] excelData = new Object[numberOfRows-1][numberOfCellsInARow];

		int rowValue = 0;

		for(int rowIndex = 1; rowIndex < numberOfRows; rowIndex++) {

			int cellValue = 0;

			XSSFRow row = sheet.getRow(rowIndex);

			for(int cellIndex = 0; cellIndex < numberOfCellsInARow ; cellIndex++) {

				XSSFCell cell = row.getCell(cellIndex);

				if(cell == null) {

					cell = row.createCell(cellIndex);

					cell.setCellType(CellType.STRING);

					cell.setCellValue("");

				}

				if(cell.getCellType()==CellType.STRING) {

					if(cell.getStringCellValue() != null || cell.getStringCellValue() != "") {

						excelData[rowValue][cellValue++] = cell.getStringCellValue().trim();

					}else {

						excelData[rowValue][cellValue++] = cell.getStringCellValue();

					}

				}else if(cell.getCellType()==CellType.NUMERIC) {

					cell.setCellType(CellType.STRING);

					excelData[rowValue][cellValue++] = cell.getStringCellValue();

					//excelData[rowValue][cellValue++] = cell.getNumericCellValue();

				}else if(cell.getCellType()==CellType.BOOLEAN) {

					excelData[rowValue][cellValue++] = cell.getBooleanCellValue();

				}else if(cell.getCellType()==CellType.BLANK) {

					cell.setCellType(CellType.STRING);

					cell.setCellValue("");

					excelData[rowValue][cellValue++] = cell.getStringCellValue();

				}else if(cell.getCellType() == CellType.FORMULA) {

					cell.setCellType(CellType.STRING);

					cell.setCellValue("Contains Formula");

					excelData[rowValue][cellValue++] = cell.getStringCellValue();

				}

			}

			rowValue++;

		}

		return excelData;

	}


	public String getQueryString(Map<String,String> propertiesNamesAndValidateWithMap, Object[] rowData, Map<String,Integer> headersIndexMap) {

		StringBuilder queryBuilder = new StringBuilder();

		int index = 0;

		for (Map.Entry<String, String> entry : propertiesNamesAndValidateWithMap.entrySet()) {

			if(index > 0) {

				queryBuilder.append(" AND ");

			}

			queryBuilder.append("=");

			queryBuilder.append(getNameSpacePrefix()+":");

			String propertyName = entry.getValue();

			queryBuilder.append(propertyName);

			queryBuilder.append(":'");

			String ValidateWithValue = entry.getKey();

			queryBuilder.append(rowData[headersIndexMap.get(ValidateWithValue)]);

			queryBuilder.append("'");

			index++;

		}

		return queryBuilder.toString();

	}

	public String getStringCorrectValue(String value) {

		value = value.replace("'", "''");

		return value;

	}

	public String getQueryStringFortxt(Map<String,String> propertiesNamesAndValidateWithMap, Map<Integer, String> rowData, Map<String,Integer> headersIndexMap) {

		StringBuilder queryBuilder = new StringBuilder();

		int index = 0;

		for (Map.Entry<String, String> entry : propertiesNamesAndValidateWithMap.entrySet()) {

			if(index > 0) {

				queryBuilder.append(" AND ");

			}

			queryBuilder.append("=");

			queryBuilder.append(getNameSpacePrefix()+":");

			String propertyName = entry.getValue();

			queryBuilder.append(propertyName);

			queryBuilder.append(":\"");

			String ValidateWithValue = entry.getKey();

			String rowDataValue = rowData.get(headersIndexMap.get(ValidateWithValue));

			//rowDataValue = getStringCorrectValue(rowDataValue);

			queryBuilder.append(rowDataValue);

			queryBuilder.append("\"");

			index++;

		}

		return queryBuilder.toString();

	}

	public Map<String, NodeRef> getActiveEmployeeSSOs(String nameSpaceURI, QName ssoQName) {

		Map<String, NodeRef> ssoListAndNodeRefMap = new HashMap<String, NodeRef>();

		ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, 
				"=bhdl:is_employee_active:TRUE");

		List<NodeRef> nodeRefList = searchResults.getNodeRefs();

		for(NodeRef nodeRef : nodeRefList) {

			ssoListAndNodeRefMap.put(((String) nodeService.getProperty(nodeRef, ssoQName)), nodeRef);

		}

		logger.info("SSO List : : : : "+ssoListAndNodeRefMap.size());

		logger.info("Active SSO's : : : "+searchResults.length());

		return ssoListAndNodeRefMap;

	}

	public List<NodeRef> getActiveNodeRefs() {

		ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, 
				"="+getNameSpacePrefix()+":"+getActivePropertyName()+":TRUE");

		List<NodeRef> nodeRefList = searchResults.getNodeRefs();

		return nodeRefList;

	}

	@SuppressWarnings("unused")
	public void createDataListItems(String strDataListType, NodeRef dataListNodeRef, QName qnameFromInput, Object[][] excelData,
			Map<Integer,String> indexHeadersMap, Map<String,QName> titleQNameMap, String nameSpaceURI,Map<String,String> propertiesNamesAndValidateWithMap,
			Map<String,Integer> headersIndexMap, String[] validateWithArray) {

		Map<QName, String> qnameAndTitleMap = getQNameAndPropertiesMapForGivenType(strDataListType, nameSpaceURI);

		QName activeQName = QName.createQName(nameSpaceURI,getActivePropertyName());

		List<NodeRef> nodeRefList = getActiveNodeRefs();

		//Map<String, NodeRef> ssoListAndNodeRefMap = getActiveEmployeeSSOs(nameSpaceURI, ssoQName);

		for(Object[] rowData : excelData) {

			Map<QName, Serializable> properties = new HashMap<QName, Serializable>();

			int cellValue = 0;

			boolean isValid = true;

			for(String title : validateWithArray) {

				if(rowData[headersIndexMap.get(title)] == null || rowData[headersIndexMap.get(title)] == "") {

					isValid = false;

				}

			}

			if(isValid) {

				//getQueryString(propertiesNamesAndValidateWithMap, rowData, headersIndexMap);

				ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, 
						getQueryString(propertiesNamesAndValidateWithMap, rowData, headersIndexMap));

				if(searchResults.length() > 0) {

					NodeRef nodeRef = searchResults.getNodeRef(0);

					Map<QName, Serializable> existingNodeProperties = nodeService.getProperties(nodeRef);

					if(nodeRefList.contains(nodeRef)) {

						nodeRefList.remove(nodeRef);

					}

					for(Object cellData : rowData) {

						if(cellData instanceof String) {

							QName propertyQName = titleQNameMap.get(indexHeadersMap.get(cellValue++));

							if(existingNodeProperties.containsKey(propertyQName)) {

								if(((String)cellData) != null || ((String)cellData) != "") {

									if(!(((String)cellData).equals(existingNodeProperties.get(propertyQName)))) {

										existingNodeProperties.replace(propertyQName, existingNodeProperties.get(propertyQName), (String)cellData);

									}

								}else {

									existingNodeProperties.replace(propertyQName, existingNodeProperties.get(propertyQName), null);

								}

							}else {

								existingNodeProperties.put(propertyQName, (String)cellData);

							}

						}else if(cellData instanceof Double) {

							QName propertyQName = titleQNameMap.get(indexHeadersMap.get(cellValue++));

							if(existingNodeProperties.containsKey(propertyQName)) {

								if(((Double)cellData) != null) {

									if(!(((Double)cellData).equals(existingNodeProperties.get(propertyQName)))) {

										existingNodeProperties.replace(propertyQName, existingNodeProperties.get(propertyQName), (Double)cellData);

									}

								}else {

									existingNodeProperties.replace(propertyQName, existingNodeProperties.get(propertyQName), null);

								}

							}else {

								existingNodeProperties.put(propertyQName, (Double)cellData);

							}

						}else if(cellData instanceof Boolean) {

							QName propertyQName = titleQNameMap.get(indexHeadersMap.get(cellValue++));

							if(existingNodeProperties.containsKey(propertyQName)) {

								if(((Boolean)cellData) != null) {

									if(!(((Boolean)cellData).equals(existingNodeProperties.get(propertyQName)))) {

										existingNodeProperties.replace(propertyQName, existingNodeProperties.get(propertyQName), (Boolean)cellData);

									}

								}else {

									existingNodeProperties.replace(propertyQName, existingNodeProperties.get(propertyQName), false);

								}

							}else {

								existingNodeProperties.put(propertyQName, (Boolean)cellData);

							}

						}else {

							cellValue++;

						}

					}

					nodeService.setProperties(nodeRef, existingNodeProperties);

				}else {

					for(Object cellData : rowData) {

						if(cellData instanceof String) {

							properties.put(titleQNameMap.get(indexHeadersMap.get(cellValue++)), (String)cellData);

						}else if(cellData instanceof Double) {

							properties.put(titleQNameMap.get(indexHeadersMap.get(cellValue++)), (Double)cellData);

						}else if(cellData instanceof Boolean) {

							properties.put(titleQNameMap.get(indexHeadersMap.get(cellValue++)), (Boolean)cellData);

						}else {

							properties.put(titleQNameMap.get(indexHeadersMap.get(cellValue++)), "Type Not Mentioned");

						}

					}		

					nodeService.createNode(dataListNodeRef, ContentModel.ASSOC_CONTAINS, qnameFromInput, qnameFromInput, properties).getChildRef();

				}

			}

		}

		if(nodeRefList.size() > 0) {

			for(NodeRef nodeRef : nodeRefList) {

				nodeService.setProperty(nodeRef,activeQName ,"FALSE");

			}

		}

	}
	
	@SuppressWarnings("deprecation")
	public String getTitleFromPropertyName(String propertyName) {
		
		String title = null;

		TypeDefinition typeDefinition = dictionaryService.getType(QName.createQName(nameSpaceURI,dataListTypeName));

		Map<QName,PropertyDefinition> typeProperties = typeDefinition.getProperties();
		
		QName propertyQName = QName.createQName(BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI, propertyName);
		
		if(typeProperties.get(propertyQName).getTitle() != null || (!typeProperties.get(propertyQName).getTitle().equals(""))) {

			title = typeProperties.get(propertyQName).getTitle().toLowerCase();

		}else {

			title = typeProperties.get(propertyQName).getTitle();

		}
		
		return title;
		
	}
	
    private String getOsName(String name) {
    	
    	name = name.replace('/', ' ');
		
    	name = name.replace(':', ' ');
		
    	name = name.replace('"', ' ');
		
    	name = name.replace('<', ' ');
		
    	name = name.replace('>', ' ');
		
    	name = name.replace('?', ' ');
		
    	name = name.replace('*', ' ');
		
    	name = name.replace('|', ' ');
		
    	name = name.replace('\\', ' ');
		
		return name;
	}

	@SuppressWarnings("unused")
	public void createAndUpdateDataListItemsFromtxt(String strDataListType, NodeRef dataListNodeRef, QName qnameFromInput, List<Map<Integer, String>> textData,
			Map<Integer,String> indexHeadersMap, Map<String,QName> titleQNameMap, String nameSpaceURI,Map<String,String> propertiesNamesAndValidateWithMap,
			Map<String,Integer> headersIndexMap, String[] validateWithArray) {

		//Map<QName, String> qnameAndTitleMap = getQNameAndPropertiesMapForGivenType(strDataListType, nameSpaceURI);

		Map<QName, String> qnameAndTitleMap = getQNameAndPropertiesLCMapForGivenType(strDataListType, nameSpaceURI);

		QName activeQName = QName.createQName(nameSpaceURI,getActivePropertyName());

		List<NodeRef> nodeRefList = getActiveNodeRefs();

		//Map<String, NodeRef> ssoListAndNodeRefMap = getActiveEmployeeSSOs(nameSpaceURI, ssoQName);

		for(Map<Integer, String> rowData : textData) {

			Map<QName, Serializable> properties = new HashMap<QName, Serializable>();

			int cellValue = 0;

			boolean isValid = true;

			for(String title : validateWithArray) {

				if(rowData.get(headersIndexMap.get(title)) == null || rowData.get(headersIndexMap.get(title)) == "") {

					isValid = false;

				}

			}

			if(isValid) {

				ResultSet searchResults = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, 
						getQueryStringFortxt(propertiesNamesAndValidateWithMap, rowData, headersIndexMap));


				if(searchResults.length() > 0) {

					NodeRef nodeRef = searchResults.getNodeRef(0);

					Map<QName, Serializable> existingNodeProperties = nodeService.getProperties(nodeRef);

					if(nodeRefList.contains(nodeRef)) {

						nodeRefList.remove(nodeRef);

					}
					
					String fullNameTitle = getTitleFromPropertyName(cmName);
					
					String ssoTitle = getTitleFromPropertyName(cmNameSSO);
					
					String sso = null;
					
					String fullName = null;
					
					if(ssoTitle != null) {
						
						sso = rowData.get(headersIndexMap.get(ssoTitle));
						
					}
					
					if(fullNameTitle != null) {
						
						fullName = rowData.get(headersIndexMap.get(fullNameTitle));
						
						if(fullName != null) {
							
							fullName = getOsName(fullName);
							
						}
						
					}
					

					if(fullName != null && sso != null) {
						
						String cmNameValue = fullName + " (" +sso+ ")";
						
						//logger.info("cName : : : "+cmNameValue);
						
						if(existingNodeProperties.containsKey(ContentModel.PROP_NAME)) {
							
							existingNodeProperties.replace(ContentModel.PROP_NAME, existingNodeProperties.get(ContentModel.PROP_NAME), cmNameValue);
							
						}else {
							
							existingNodeProperties.put(ContentModel.PROP_NAME, cmNameValue);
							
						}
						
					}
					

					for (Map.Entry<Integer, String> entry : rowData.entrySet()) {

						String entryValue = entry.getValue();

						QName propertyQName = titleQNameMap.get(indexHeadersMap.get(entry.getKey()));

						if(existingNodeProperties.containsKey(propertyQName)) {

							if(entryValue != null || entryValue != "") {

								if(propertyQName.getLocalName().equalsIgnoreCase(getActivePropertyName())) {

									if((boolean) existingNodeProperties.get(propertyQName)) {

										existingNodeProperties.replace(propertyQName, existingNodeProperties.get(propertyQName), entryValue);

									}

								}else if(!(entryValue.equals(existingNodeProperties.get(propertyQName)))) {

									existingNodeProperties.replace(propertyQName, existingNodeProperties.get(propertyQName), entryValue);

								}

							}else {

								existingNodeProperties.replace(propertyQName, existingNodeProperties.get(propertyQName), null);

							}

						}else {

							existingNodeProperties.put(propertyQName, entryValue);

						}

					}

					nodeService.setProperties(nodeRef, existingNodeProperties);

				}else {
					
					String fullNameTitle = getTitleFromPropertyName(cmName);
					
					String ssoTitle = getTitleFromPropertyName(cmNameSSO);
					
					String sso = null;
					
					String fullName = null;
					
					if(ssoTitle != null) {
						
						sso = rowData.get(headersIndexMap.get(ssoTitle));
						
					}
					
					if(fullNameTitle != null) {
						
						fullName = rowData.get(headersIndexMap.get(fullNameTitle));
						
						if(fullName != null) {
							
							fullName = getOsName(fullName);
							
						}
						
					}
					

					if(fullName != null && sso != null) {
						
						String cmNameValue = fullName + " (" +sso+ ")";
						
						properties.put(ContentModel.PROP_NAME, cmNameValue);
						
					}

					for (Map.Entry<Integer, String> entry : rowData.entrySet()) {

						properties.put(titleQNameMap.get(indexHeadersMap.get(entry.getKey())), entry.getValue());

					}

					nodeService.createNode(dataListNodeRef, ContentModel.ASSOC_CONTAINS, qnameFromInput, qnameFromInput, properties).getChildRef();

				}

			}

		}

		if(nodeRefList.size() > 0) {

			for(NodeRef nodeRef : nodeRefList) {

				nodeService.setProperty(nodeRef,activeQName ,"FALSE");

			}

		}

	}

	@SuppressWarnings("deprecation")
	public Map<String,String> getPropertiesNameForValidateValues(DictionaryService dictionaryService, QName qnameFromInput, String[] validateWithArray) {

		List<String> validateWithValuesList = Arrays.asList(validateWithArray);

		Map<String,String> propertiesNamesAndValidateWithMap = new HashMap<String,String>();

		TypeDefinition typeDefinition = dictionaryService.getType(qnameFromInput);

		Map<QName,PropertyDefinition> typeProperties = typeDefinition.getProperties();

		Set<QName> set = typeProperties.keySet();

		Iterator<QName> i = set.iterator();

		while(i.hasNext()) {

			QName qname = i.next();

			if(validateWithValuesList.contains(typeProperties.get(qname).getTitle())) {

				propertiesNamesAndValidateWithMap.put(typeProperties.get(qname).getTitle() , typeProperties.get(qname).getName().getLocalName());				

			}

		}

		return propertiesNamesAndValidateWithMap;

	}

	@SuppressWarnings("deprecation")
	public Map<String,String> getPropertiesNameForValidateValuesLC(DictionaryService dictionaryService, QName qnameFromInput, String[] validateWithArray) {

		List<String> validateWithValuesList = Arrays.asList(validateWithArray);

		Map<String,String> propertiesNamesAndValidateWithMap = new HashMap<String,String>();

		TypeDefinition typeDefinition = dictionaryService.getType(qnameFromInput);

		Map<QName,PropertyDefinition> typeProperties = typeDefinition.getProperties();

		Set<QName> set = typeProperties.keySet();

		Iterator<QName> i = set.iterator();

		while(i.hasNext()) {

			QName qname = i.next();

			if(validateWithValuesList.contains(typeProperties.get(qname).getTitle().toLowerCase())) {

				propertiesNamesAndValidateWithMap.put(typeProperties.get(qname).getTitle().toLowerCase() , typeProperties.get(qname).getName().getLocalName());				

			}

		}

		return propertiesNamesAndValidateWithMap;

	}

	public void execute() {

		logger.info("HRSyncJobExcecutor : : execute() : : Job Execution Started");

		logger.info("Scheduled Job started");

		String strSiteName = getSiteName();

		String strdataListName = getDataListName();

		String nameSpaceURI = BHContentModelConstants.BH_DATALISTS_NAMESPACE_URI;

		String strDataListType = getDataListTypeName();

		String strInputFileUUID = getInputFileUUID();

		String strValidateWith = getValidateWith();

		if(strValidateWith != null || (!"".equals(strValidateWith))) {

			strValidateWith = strValidateWith.toLowerCase();

		}

		String[] validateWithArray = strValidateWith.split(",");

		QName qnameFromInput = QName.createQName(nameSpaceURI, strDataListType);

		NodeRef datalistContainerNodeRef = serviceRegistry.getSiteService().getContainer(strSiteName, CONTAINER_ID_FOR_DATALIST);

		NodeRef dataListNodeRef = nodeService.getChildByName(datalistContainerNodeRef, ContentModel.ASSOC_CONTAINS, strdataListName);
		
		if(dataListNodeRef == null) {
			
			Map<QName, Serializable> properties = new HashMap<QName, Serializable>();
			
			properties.put(ContentModel.PROP_NAME, strdataListName);
			
			properties.put(ContentModel.PROP_TITLE, dataListTitleName);
			
			properties.put(DataListModel.PROP_DATALIST_ITEM_TYPE,BHContentModelConstants.BH_DATALISTS_NAMESPACE_PREFIX+":"+strDataListType);
			
			dataListNodeRef = nodeService.createNode(datalistContainerNodeRef, ContentModel.ASSOC_CONTAINS, qnameFromInput,
					QName.createQName(DataListModel.DATALIST_MODEL_1_0_URI, "dataList"), properties).getChildRef();
			
		}

		//Map<String,QName> titleQNameMap = getCustomTypePropertiesTitleFromDictionaryService(strDataListType,nameSpaceURI);

		Map<String,QName> titleLCQNameMap = getCustomTypePropertiesTitleLCFromDictionaryService(strDataListType, nameSpaceURI);

		//Map<String,String> propertiesNamesAndValidateWithMap = getPropertiesNameForValidateValues(dictionaryService, qnameFromInput, validateWithArray);

		Map<String,String> propertiesNamesAndValidateWithMapLC = getPropertiesNameForValidateValuesLC(dictionaryService, qnameFromInput, validateWithArray);

		NodeRef input = new NodeRef("workspace://SpacesStore/"+strInputFileUUID);

		ContentReader reader = serviceRegistry.getContentService().getReader(input, ContentModel.PROP_CONTENT);

		BufferedReader bufferedReader = null;

		String firstLineIntxt;

		try {

			bufferedReader = new BufferedReader(new InputStreamReader(reader.getContentInputStream()));

			firstLineIntxt = bufferedReader.readLine();

			Map<Integer,String> indexHeadersMap = getIndexHeadersMapFromtxt(firstLineIntxt);

			Map<String,Integer> headersIndexMap = getHeadersIndexMapFromtxt(firstLineIntxt);

			if(isValidInputtxt(headersIndexMap.keySet(), titleLCQNameMap)) {

				List<Map<Integer, String>> textData = readTextFile(bufferedReader);

				createAndUpdateDataListItemsFromtxt(strDataListType, dataListNodeRef, qnameFromInput, textData, indexHeadersMap, titleLCQNameMap, nameSpaceURI, 
						propertiesNamesAndValidateWithMapLC,headersIndexMap, validateWithArray);

			}

		} catch (Exception e) {

			e.printStackTrace();

		}finally {

			try {

				bufferedReader.close();

			} catch (IOException e) {

				e.printStackTrace();

			}

		}

		logger.info("scheduled job Done");

	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getInputFileUUID() {
		return inputFileUUID;
	}

	public void setInputFileUUID(String inputFileUUID) {
		this.inputFileUUID = inputFileUUID;
	}

	public String getNameSpacePrefix() {
		return nameSpacePrefix;
	}

	public void setNameSpacePrefix(String nameSpacePrefix) {
		this.nameSpacePrefix = nameSpacePrefix;
	}

	public String getNameSpaceURI() {
		return nameSpaceURI;
	}

	public void setNameSpaceURI(String nameSpaceURI) {
		this.nameSpaceURI = nameSpaceURI;
	}

	public String getDataListTypeName() {
		return dataListTypeName;
	}

	public void setDataListTypeName(String dataListTypeName) {
		this.dataListTypeName = dataListTypeName;
	}

	public String getDataListName() {
		return dataListName;
	}

	public void setDataListName(String dataListName) {
		this.dataListName = dataListName;
	}

	public String getActivePropertyName() {
		return activePropertyName;
	}

	public void setActivePropertyName(String activePropertyName) {
		this.activePropertyName = activePropertyName;
	}

	public String getValidateWith() {
		return validateWith;
	}

	public void setValidateWith(String validateWith) {
		this.validateWith = validateWith;
	}

	public String getDataListTitleName() {
		return dataListTitleName;
	}

	public void setDataListTitleName(String dataListTitleName) {
		this.dataListTitleName = dataListTitleName;
	}

	public String getCmName() {
		return cmName;
	}

	public void setCmName(String cmName) {
		this.cmName = cmName;
	}

	public String getCmNameSSO() {
		return cmNameSSO;
	}

	public void setCmNameSSO(String cmNameSSO) {
		this.cmNameSSO = cmNameSSO;
	}



}
