package com.bh.alfresco.qms.workflow.utils;

import java.io.IOException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import com.bh.alfresco.qms.constants.BHContentModelConstants;	

public class IDSClient {
	
	

	//public static final String TOKEN_GENERATION_CREDENTIALS = "";
	
	private String TOKEN_GENERATION_URL;
	private String USER_API_URL;
	private String IDS_USERNAME;
	private String IDS_PASSWORD;
	
	private static final Log logger = LogFactory.getLog(IDSClient.class);
	
	public String getTOKEN_GENERATION_URL() {
		return TOKEN_GENERATION_URL;
	}

	public void setTOKEN_GENERATION_URL(String tOKEN_GENERATION_URL) {
		TOKEN_GENERATION_URL = tOKEN_GENERATION_URL;
	}

	public String getUSER_API_URL() {
		return USER_API_URL;
	}

	public void setUSER_API_URL(String uSER_API_URL) {
		USER_API_URL = uSER_API_URL;
	}

	public String getIDS_USERNAME() {
		return IDS_USERNAME;
	}

	public void setIDS_USERNAME(String iDS_USERNAME) {
		IDS_USERNAME = iDS_USERNAME;
	}

	public String getIDS_PASSWORD() {
		return IDS_PASSWORD;
	}

	public void setIDS_PASSWORD(String iDS_PASSWORD) {
		IDS_PASSWORD = iDS_PASSWORD;
	}

	public String generateToken() {
		
		String accessToken = null;
		
		HttpClient httpClient = new HttpClient();
		
		//PostMethod postMethod = new PostMethod(getTOKEN_GENERATION_URL());
		PostMethod postMethod = new PostMethod(BHContentModelConstants.TOKEN_GENERATION_URL);
		
		/*HostConfiguration hostConfiguration = new HostConfiguration();
		
		hostConfiguration.setProxy("PITC-Zscaler-Americas-Alpharetta3PR.proxy.corporate.ge.com", 80);
		
		httpClient.setHostConfiguration(hostConfiguration);*/
		
		//postMethod.setRequestHeader("Authorization", "Basic "+TOKEN_GENERATION_CREDENTIALS);
		
		postMethod.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		
		NameValuePair[] requestBody = new NameValuePair[] {
				
				new NameValuePair("grant_type", "password"),
				
				new NameValuePair("client_id", "alfresco"),
				
				new NameValuePair("scope", "openid"),
				
				new NameValuePair("username", BHContentModelConstants.IDS_USERNAME),
				
				new NameValuePair("password", BHContentModelConstants.IDS_PASSWORD)
				
				//new NameValuePair("username", getIDS_USERNAME()),
				
				//new NameValuePair("password", getIDS_PASSWORD())
				
		};
		
		postMethod.setRequestBody(requestBody);
		
		try {
			
			httpClient.executeMethod(postMethod);
			
			int statusCode = postMethod.getStatusCode();
			
			if(statusCode == HttpStatus.SC_OK) {
				
				if(postMethod.getResponseBodyAsString() != null) {
					
					JSONObject responseJSONObject = (JSONObject) JSONValue.parse(postMethod.getResponseBodyAsString());
					
					if(responseJSONObject != null) {
						
						if(responseJSONObject.get("access_token") != null) {
							
							if(responseJSONObject.get("access_token") instanceof String) {
								
								accessToken = (String) responseJSONObject.get("access_token");
								
								//System.out.println("access token : : : "+accessToken);
								
							}
							
						}
						
					}
					
				}
				
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(postMethod != null) {
				
				postMethod.releaseConnection();
				
			}
			
		}
		
		return accessToken;
		
	}
	
	public String getUserNameFromEmail(String email) {
		
		String accessToken = generateToken();
		
		String userName = null;
		
		//String url = getUSER_API_URL() + "?email="+email;
		String url = BHContentModelConstants.USER_API_URL + "?email="+email;
		
        HttpClient httpClient = new HttpClient();

		/*HostConfiguration hostConfiguration = new HostConfiguration();
		
		hostConfiguration.setProxy("PITC-Zscaler-Americas-Alpharetta3PR.proxy.corporate.ge.com", 80);
		
		httpClient.setHostConfiguration(hostConfiguration);*/
		
		GetMethod getMethod = new GetMethod(url);
		
		getMethod.setRequestHeader("Authorization", "Bearer "+accessToken);
		
		try {
			
			httpClient.executeMethod(getMethod);
			
			logger.info("Status Code : : "+getMethod.getStatusCode());
			
			logger.info("Response : : "+getMethod.getResponseBodyAsString());
			
            int statusCode = getMethod.getStatusCode();
			
			if(statusCode == HttpStatus.SC_OK) {
				
				if(getMethod.getResponseBodyAsString() != null) {
					
					if(JSONValue.parse(getMethod.getResponseBodyAsString()) instanceof JSONArray) {
						
						JSONArray responseJSONArray = (JSONArray) JSONValue.parse(getMethod.getResponseBodyAsString());
						
						if(responseJSONArray.size() > 0) {
							
							JSONObject responseJSONObject = (JSONObject) responseJSONArray.get(0);
							
							if(responseJSONObject != null) {
								
								if(responseJSONObject.get("username") != null) {
									
									if(responseJSONObject.get("username") instanceof String) {
										
										userName = (String) responseJSONObject.get("username");
										
										//System.out.println("user name : : : "+accessToken);
										
									}
									
								}
								
							}
							
						}
												
					}
		
				}	
									
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}finally {
			
			if(getMethod != null) {
				
				getMethod.releaseConnection();
				
			}
			
		}
		
		return userName;
		
	}

	/*
	public static void main(String[] args) {
		
		IDSClient idsClient = new IDSClient();
		
		String userName = idsClient.getUserNameFromEmail("suryakumar.rayee@bakerhughes.com");
		
		System.out.println("user name in main : : "+userName);

	}
	*/

}
