package com.bh.alfresco.qms.webscripts.reports;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.chemistry.opencmis.commons.impl.json.JSONArray;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

public class QMSAdvancedSearchWS extends DeclarativeWebScript {

	private static final Log logger = LogFactory.getLog(QMSAdvancedSearchWS.class);

	private QMSReportUtils bhQMSReportUtils;

	public QMSReportUtils getBhQMSReportUtils() {
		return bhQMSReportUtils;
	}

	public void setBhQMSReportUtils(QMSReportUtils bhQMSReportUtils) {
		this.bhQMSReportUtils = bhQMSReportUtils;
	}

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {
		JSONArray mapOfSearchResults = null;
		if(logger.isDebugEnabled()) {
			logger.debug("in executeImpl starts");
			//logger.debug("advSearchProps :: "+mapOfSearchResults);
			//logger.debug("advSearchProps :: "+mapOfSearchResults.toString());
			//logger.debug("advSearchProps.toJSONString() :: "+mapOfSearchResults.toJSONString());
		}
		List<NodeRef> nodeRefList = bhQMSReportUtils.getResultNodes(req);
		try {
			mapOfSearchResults = bhQMSReportUtils.generateModelForListView(nodeRefList);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		if(logger.isDebugEnabled()) {
			logger.debug("in executeImpl ends");
			//logger.debug("advSearchProps :: "+mapOfSearchResults);
			//logger.debug("advSearchProps :: "+mapOfSearchResults.toString());
			//logger.debug("advSearchProps.toJSONString() :: "+mapOfSearchResults.toJSONString());
		}
		Map<String, Object> returnMap = new HashMap<String, Object>();
		returnMap.put("mapOfSearchResults", mapOfSearchResults.toJSONString());

		return returnMap;
	}
}
