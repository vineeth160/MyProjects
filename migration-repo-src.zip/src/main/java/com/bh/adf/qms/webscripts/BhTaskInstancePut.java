package com.bh.adf.qms.webscripts;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.repo.search.impl.QueryParserUtils;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.security.permissions.AccessDeniedException;
import org.alfresco.repo.web.scripts.workflow.AbstractWorkflowWebscript;
import org.alfresco.repo.web.scripts.workflow.WorkflowModelBuilder;
import org.alfresco.service.cmr.dictionary.PropertyDefinition;
import org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter;
import org.alfresco.service.cmr.repository.datatype.TypeConversionException;
import org.alfresco.service.cmr.security.AuthenticationService;
import org.alfresco.service.cmr.workflow.WorkflowException;
import org.alfresco.service.cmr.workflow.WorkflowService;
import org.alfresco.service.cmr.workflow.WorkflowTask;
import org.alfresco.service.namespace.NamespacePrefixResolver;
import org.alfresco.service.namespace.QName;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;

/**
 * 
 * @CustomizedBy Leela Prasad Guvvala
 * @BakerHughes 503184106
 * @TechMahindra GL00640582
 * @UpdatedOn 06-09-2020
 *
 */

public class BhTaskInstancePut extends AbstractWorkflowWebscript {
	
  protected Map<String, Object> buildModel(WorkflowModelBuilder modelBuilder, WebScriptRequest req, Status status, Cache cache) {
    return getWorkflowTask(modelBuilder, req);
  }
  
  private Map<String, Object> getWorkflowTask(WorkflowModelBuilder modelBuilder, WebScriptRequest req) {
	  WorkflowService workflowService = this.workflowService;
	  AuthenticationService authenticationService = this.authenticationService;
	  String uName = getUName();
	  return AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Map<String, Object>>()
	    {
			@Override
			public Map<String, Object> doWork() throws Exception {
				Map<String, String> params = req.getServiceMatch().getTemplateVars();
			    String taskId = params.get("task_instance_id");
			    JSONObject json = null;
			    try {
			      WorkflowTask workflowTask = workflowService.getTaskById(taskId);
			      String currentUser = authenticationService.getCurrentUserName();
			      json = new JSONObject(new JSONTokener(req.getContent().getContent()));
			      workflowTask = workflowService.updateTask(taskId, parseTaskProperties(json, workflowTask), null, null);
			      if (workflowTask == null) {
			        throw new WebScriptException(404, "Failed to find workflow task with id: " + taskId);
			      } else {
			    	  // workflowTask = workflowService.endTask(taskId, null);
			      }
			      Map<String, Object> model = new HashMap<>();
			      model.put("workflowTask", modelBuilder.buildDetailed(workflowTask));
			      return model;
			    } catch (IOException iox) {
			      throw new WebScriptException(400, "Could not read content from request.", iox);
			    } catch (JSONException je) {
			      throw new WebScriptException(400, "Could not parse JSON from request.", je);
			    } catch (AccessDeniedException ade) {
			      throw new WebScriptException(401, "Failed to update workflow task with id: " + taskId, ade);
			    } catch (WorkflowException we) {
			      throw new WebScriptException(401, "Failed to update workflow task with id: " + taskId, we);
			    } 
			}
	    }, "admin");
  }
  
  private Map<QName, Serializable> parseTaskProperties(JSONObject json, WorkflowTask workflowTask) throws JSONException {	  
    Map<QName, Serializable> props = new HashMap<>();
    String[] names = JSONObject.getNames(json);
    if (names != null)
      for (String name : names) {
    	// System.out.println("Property Name : " + name);
        QName key = QName.createQName(name.replaceFirst("_", ":"), (NamespacePrefixResolver)this.namespaceService);
        // System.out.println("Property Name key : " + key);        
        Object jsonValue = json.get(name);
        Serializable value = null;
        if (jsonValue.equals(JSONObject.NULL)) {
          props.put(key, null);
        } else {
          PropertyDefinition prop = this.dictionaryService.getProperty(key);
          // System.out.println("Property : " + prop);
          if (prop != null) {
        	  // System.out.println("Property is Multi value : " + prop.isMultiValued());
        	  // System.out.println("Property type : " + prop.getDataType());
            if (prop.isMultiValued() && jsonValue instanceof JSONArray) {
              value = new ArrayList();
              for (int i = 0; i < ((JSONArray)jsonValue).length(); i++)
                ((List<Serializable>)value).add((Serializable)DefaultTypeConverter.INSTANCE.convert(prop.getDataType(), ((JSONArray)jsonValue).get(i))); 
            } else {
              value = (Serializable)DefaultTypeConverter.INSTANCE.convert(prop.getDataType(), jsonValue);
            } 
          } else if (jsonValue instanceof JSONArray) {
        	  // System.out.println("Property isArray ");
            value = new ArrayList();
            for (int i = 0; i < ((JSONArray)jsonValue).length(); i++) {
            	// Custom properties update - start
            	if (name.equalsIgnoreCase("bhwf_reviewer") || name.equalsIgnoreCase("bhwf_approver")) {
            		try {
            			String v = ((JSONArray)jsonValue).getString(i);
            			Serializable cv = (Serializable)DefaultTypeConverter.INSTANCE.convert(org.alfresco.service.cmr.repository.NodeRef.class, v);
            			((List<Serializable>)value).add(cv);
            		}  catch (TypeConversionException typeConversionException) {}
            		// Custom properties update - end
            	} else {
            		((List<String>)value).add(((JSONArray)jsonValue).getString(i));
            	}
              
            }
          } else if (jsonValue instanceof String) {
        	  // System.out.println("Property isString ");
            Serializable existingValue = (Serializable)workflowTask.getProperties().get(key);
            // System.out.println("Property string existed value : " + existingValue);
            if (existingValue != null) {
              try {
            	  // System.out.println("Property string existed value class : " + existingValue.getClass());
                value = (Serializable)DefaultTypeConverter.INSTANCE.convert(existingValue.getClass(), jsonValue);
                // System.out.println("Property string converted value : " + value);
              } catch (TypeConversionException typeConversionException) {}
            } else {
            	// Custom properties update - start
            	if (name.equalsIgnoreCase("bhwf_intakes") ||
            			name.equalsIgnoreCase("bhwf_sme") ||
            			name.equalsIgnoreCase("bhwf_admin") ||
            			name.equalsIgnoreCase("bhwf_primaryReviewer") ||
            			name.equalsIgnoreCase("bhwf_primaryApprover") ||
            			name.equalsIgnoreCase("bhwf_publisher") ||
            			name.equalsIgnoreCase("bhwf_archival") ||
            			name.equalsIgnoreCase("bhwf_archivalApprover")) {
            		
            		try {
            			value = (Serializable)DefaultTypeConverter.INSTANCE.convert(org.alfresco.service.cmr.repository.NodeRef.class, jsonValue);
            		}  catch (TypeConversionException typeConversionException) {}
            		// Custom properties update - end
            	} else {
            		value = (String)jsonValue;
            	}
            } 
          } else {
            value = (Serializable)jsonValue;
          } 
        }
        // System.out.println("Property final Value : " + value);
        props.put(key, value);
      }  
    return props;
  }
  
  	private String uName;
	
	public String getUName() {
		return this.uName;
	}

	public void setUName(String uName) {
		this.uName = uName;
	}
}
