package com.bh.adf.qms.webscripts;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.alfresco.model.ContentModel;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

/**
 * 
 * @author Leela Prasad Guvvala
 * @BakerHughes 503184106
 * @TechMahindra GL00640582
 * @UpdatedOn 06-09-2020
 *
 */

public class BhTicketPost extends BhAbstractTicket {
	private static Log logger = LogFactory.getLog(BhTicketPost.class);
	
	protected Map<String, Object> buildModel(WebScriptRequest req, Status status, Cache cache) {
		
		Map<String, Object> result = new HashMap<String, Object>();
		String finalTicket = null, finalToken = null;
		/*
		 * String eToken = getExistedToken(req); finalToken = eToken; String eTicket =
		 * getExistedTicket();
		 * 
		 * if (eTicket != null) { if (isValidTicket(eTicket)) { finalTicket = eTicket;
		 * result.put("ticket", finalTicket); result.put("at", finalToken); } else {
		 * result = getExistedTokenTicket(eToken); } } else { result =
		 * getExistedTokenTicket(eToken); }
		 */
		
		//System.out.println("BhTicketPost ::: " + finalTicket);
		//logger.info("BhTicketPost ::: " + finalTicket);

		finalToken = generateToken();
		result.put("ticket", finalTicket);
		result.put("at", finalToken);
		return result;
	}
	
	private Map<String, Object> getNewTicket() {
		Map<String, Object> result = new HashMap<String, Object>();
		String ticket = null;
		String token = generateToken();
		//System.out.println("getNewTicket ::: " + token);
		//logger.info("getNewTicket ::: " + token);
		if (token != null) {
			System.out.println("getNewTicket : token ::: available");
			logger.info("getNewTicket : token ::: available");
			ticket = generateTicket(token);
			System.out.println("getNewTicket ::: " + ticket);
			logger.info("getNewTicket ::: " + ticket);
			if (ticket != null) {
				setTicket(ticket); //Saving new ticket
			}
		} else {
			System.out.println("getNewTicket ::: token not generated");
			logger.info("getNewTicket ::: token not generated");
		}
		
		result.put("ticket", ticket);
		result.put("at", token);
		return result;
	}
	
	private Map<String, Object> getExistedTokenTicket(String eToken) {
		Map<String, Object> result = new HashMap<String, Object>();
		if (eToken != null) {
			System.out.println("getExistedTokenTicket : eToken ::: available");
			logger.info("getExistedTokenTicket : eToken ::: available");
			String ticket = generateTicket(eToken);
			if (ticket != null) {
				System.out.println("getExistedTokenTicket : ticket from eToken ::: " + ticket);
				logger.info("getExistedTokenTicket : ticket from eToken ::: " + ticket);
				if (isValidTicket(ticket)) {
					System.out.println("getExistedTokenTicket : ticket valid ");
					logger.info("getExistedTokenTicket : ticket valid ");
					result.put("ticket", ticket);
					result.put("at", eToken);
					return result;
				} else {
					System.out.println("getExistedTokenTicket : ticket not valid ::: generating new token and ticket ");
					logger.info("getExistedTokenTicket : ticket not valid ::: generating new token and ticket ");
					return getNewTicket();
				}
			} else {
				System.out.println("getExistedTokenTicket : ticket from eToken ::: not available");
				logger.info("getExistedTokenTicket : ticket from eToken ::: not available");
				return getNewTicket();
			}
		} else {
			System.out.println("getExistedTokenTicket : eToken ::: not available");
			logger.info("getExistedTokenTicket : eToken ::: not available");
			return getNewTicket();
		}		
	}
	
	private String getExistedToken(WebScriptRequest req) {
		String at = null;
		try {
			Object o = req.parseContent();
			System.out.println("getExistedToken : o ::: " + o);
			logger.info("getExistedToken : o ::: " + o);
			if (o != null) {
				String os = o.toString();
				System.out.println("getExistedToken : o string ::: " + os);
				logger.info("getExistedToken : o string ::: " + os);
				if (os != null && !os.isBlank() && !os.isEmpty()) {
					JSONObject params = (JSONObject) JSONValue.parse(os);
					System.out.println("getExistedToken : params ::: " + params);
					logger.info("getExistedToken : params ::: " + params);
					if (params != null) {
						at = params.get("at") != null ? params.get("at").toString().trim() : null;
						System.out.println("getExistedToken : access token ::: " + at);
						logger.info("getExistedToken : access token ::: " + at);
					}
				}				
			}			
		} catch(Exception e) {
			System.out.println("getExistedToken : Error ::: " + e.getMessage());
			logger.error("getExistedToken : Error ::: " + e.getMessage());
		}
		
	    return at;
	}
	
	private boolean isValidTicket(String ticket) {
		boolean valid = false;
		HttpClient httpClient = new HttpClient();
		String url = getValidData() + "?alf_ticket=" + ticket;
		System.out.println("isValidTicket : url ::: " + url);
		logger.info("isValidTicket : url ::: " + url);
		GetMethod getMethod = new GetMethod(url);
		
		try {
			httpClient.executeMethod(getMethod);
			int statusCode = getMethod.getStatusCode();
			System.out.println("isValidTicket : statusCode ::: " + statusCode);
			logger.info("isValidTicket : statusCode ::: " + statusCode);
			if(statusCode == HttpStatus.SC_OK) {
				valid = true;
			}
		} catch (IOException e) {
			System.out.println("BHTicket : isValidTicket : Exception ::: " + e.getMessage());
			logger.error("BHTicket : isValidTicket : Exception ::: " + e.getMessage());
		} finally {			
			if(getMethod != null) getMethod.releaseConnection();
		}
		return valid;
	}
	
	private String getExistedTicket() {
		ContentService contentService = this.contentService;
		String uName = getUName();
		System.out.println("getExistedTicket : uName ::: " + uName);
		logger.info("getExistedTicket : uName ::: " + uName);
		return AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<String>()
	    {
			@Override
			public String doWork() throws Exception {
				String ticket = null;
				NodeRef nodeRef = getETicketNodeRef();
				if (nodeRef != null) {
		        	ContentReader reader = contentService.getReader(nodeRef, ContentModel.PROP_CONTENT);
			        if (reader != null) {
			        	ticket = reader.getContentString();
			        }
		        }
				System.out.println("getExistedTicket : ticket ::: " + ticket);
				logger.info("getExistedTicket : ticket ::: " + ticket);
				return ticket;
			}
	    }, uName);
	}
	
	private void setTicket(String ticket) {
		ContentService contentService = this.contentService;
		String uName = getUName();
		System.out.println("setTicket : uName ::: " + uName);
		logger.info("setTicket : uName ::: " + uName);
		AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<>()
	    {
			@Override
			public String doWork() throws Exception {
				NodeRef nodeRef = getETicketNodeRef();
				try {
					if (nodeRef != null) {
						ContentWriter writer = contentService.getWriter(nodeRef, ContentModel.PROP_CONTENT, true);
						writer.putContent(ticket);
					}
				} catch (Exception e) {
					System.out.println("setTicket : Error ::: " + e.getMessage());
					logger.error("setTicket : Error ::: " + e.getMessage());
				}
				return null;
			}
	    }, uName);
	}
	
	private NodeRef getETicketNodeRef() {
		NodeRef nodeRef = null;
		String path = "PATH:\"" + getValidPath() + "\"";
		System.out.println("getETicketNodeRef : path ::: " + path);
		logger.info("getETicketNodeRef : path ::: " + path);
		ResultSet results = null;
		try {
	        StoreRef storeRef = new StoreRef(StoreRef.PROTOCOL_WORKSPACE, "SpacesStore");
	        results = this.searchService.query(storeRef, SearchService.LANGUAGE_FTS_ALFRESCO, path);
	        if (results.length() == 0) {
	        	System.out.println("No results found for path: " + path);
	            logger.info("No results found for path: " + path);
	            return null;
	        } else {
	        	nodeRef = results.getNodeRef(0);
	        	System.out.println("getETicketNodeRef : nodeRef ::: " + nodeRef);
	        	logger.info("getETicketNodeRef : nodeRef ::: " + nodeRef);
	        }
	        	        
		} catch(Exception e) {
			System.out.println("Exception while searching for path : " + path + " ::: "+ e);
	        logger.error("Exception while searching for path : " + path + " ::: "+ e);
	        if (results != null) {
	            results.close();
	        }
	    } finally {
	        if (results != null) {
	            results.close();
	        }
	    }
		return nodeRef;
	}

	private String generateToken() {

		System.out.println("generateToken : url ::: " + getViewData());
		logger.info("generateToken : url ::: " + getViewData());
		String accessToken = null;
		HttpClient httpClient = new HttpClient();
		PostMethod postMethod = new PostMethod(getViewData());

		System.out.println("generateToken : cText ::: " + getCText());
		logger.info("generateToken : cText ::: " + getCText());
		System.out.println("generateToken : sText ::: " + getSText());
		logger.info("generateToken : sText ::: " + getSText());
		String auth = "Basic " + Base64.getEncoder().encodeToString((getCText() + ":" + getSText()).getBytes());
		postMethod.setRequestHeader("Authorization", auth);		
		postMethod.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

		System.out.println("generateToken : gText ::: getGText()");
		NameValuePair[] requestBody = new NameValuePair[] {
				new NameValuePair("grant_type", getGText()),
				new NameValuePair("scope", "openid"),
		};

		postMethod.setRequestBody(requestBody);

		try {

			httpClient.executeMethod(postMethod);
			int statusCode = postMethod.getStatusCode();
			
			System.out.println("generateToken : statusCode ::: " + statusCode);
			logger.info("generateToken : statusCode ::: " + statusCode);
			if (statusCode == HttpStatus.SC_OK) {
				if (postMethod.getResponseBodyAsString() != null) {
					System.out.println("generateToken : postMethod.getResponseBodyAsString() ::: not null");
					logger.info("generateToken : postMethod.getResponseBodyAsString() ::: not null");
					JSONObject responseJSONObject = (JSONObject) JSONValue.parse(postMethod.getResponseBodyAsString());
					
					if (responseJSONObject != null) {
						System.out.println("generateToken : responseJSONObject ::: not null");
						logger.info("generateToken : responseJSONObject ::: not null");
						if (responseJSONObject.get("access_token") != null) {
							System.out.println("generateToken : responseJSONObject.get(\"access_token\") ::: not null");
							logger.info("generateToken : responseJSONObject.get(\"access_token\") ::: not null");
							if (responseJSONObject.get("access_token") instanceof String) {
								System.out.println("generateToken : accessToken ::: available");
								logger.info("generateToken : accessToken ::: available");
								accessToken = (String) responseJSONObject.get("access_token");
							}
						}
					}
				}
			}
		} catch (IOException e) {
			System.out.println("BHTicket : Access_Token ::: " + e.getMessage());
			logger.error("BHTicket : Access_Token ::: " + e.getMessage());
		} finally {
			if (postMethod != null)	postMethod.releaseConnection();
		}

		return accessToken;
	}
	
	private String generateTicket(String accessToken) {
		String ticket = null;
		
		System.out.println("generateTicket : url ::: " + getViewerData());
		logger.info("generateTicket : url ::: " + getViewerData());
		HttpClient httpClient = new HttpClient();
		GetMethod getMethod = new GetMethod(getViewerData());
		
		getMethod.setRequestHeader("Authorization", "Bearer "+accessToken);
		
		try {
			
			httpClient.executeMethod(getMethod);
			int statusCode = getMethod.getStatusCode();
			
			System.out.println("generateTicket : statusCode ::: " + statusCode);
			logger.info("generateTicket : statusCode ::: " + statusCode);
			if(statusCode == HttpStatus.SC_OK) {
				if(getMethod.getResponseBodyAsString() != null) {
					System.out.println("generateTicket : getMethod.getResponseBodyAsString() ::: not null");
					logger.info("generateTicket : getMethod.getResponseBodyAsString() ::: not null");
					JSONObject responseJSONObject = (JSONObject) JSONValue.parse(getMethod.getResponseBodyAsString());
					if (responseJSONObject != null) {
						System.out.println("generateTicket : responseJSONObject ::: not null");
						logger.info("generateTicket : responseJSONObject ::: not null");
						if (responseJSONObject.get("entry") != null) {
							System.out.println("generateTicket : responseJSONObject.get(\"entry\") ::: not null");
							logger.info("generateTicket : responseJSONObject.get(\"entry\") ::: not null");
							JSONObject entry = (JSONObject) responseJSONObject.get("entry");
							
							if (entry.get("id") instanceof String) {
								System.out.println("generateTicket : ticket ::: available");
								logger.info("generateTicket : ticket ::: available");
								ticket = (String) entry.get("id");
							}
						}
					}
				}
			}
			
		} catch (IOException e) {
			System.out.println("BHTicket : Ticket : Exception ::: " + e.getMessage());
			logger.error("BHTicket : Ticket : Exception ::: " + e.getMessage());			
		} finally {			
			if(getMethod != null) getMethod.releaseConnection();
		}
		
		return ticket;
	}

	private String viewData;

	private String cText;

	private String sText;

	private String gText;
	
	private String viewerData;
	
	private String validPath;
	
	private String validData;
	
	private String uName;

	public String getViewData() {
		return viewData;
	}

	public void setViewData(String viewData) {
		this.viewData = viewData;
	}

	public String getCText() {
		return this.cText;
	}

	public void setCText(String cText) {
		this.cText = cText;
	}

	public String getSText() {
		return this.sText;
	}

	public void setSText(String sText) {
		this.sText = sText;
	}

	public String getGText() {
		return this.gText;
	}

	public void setGText(String gText) {
		this.gText = gText;
	}
	
	public String getViewerData() {
		return viewerData;
	}

	public void setViewerData(String viewerData) {
		this.viewerData = viewerData;
	}
	
	public String getValidPath() {
		return this.validPath;
	}

	public void setValidPath(String validPath) {
		this.validPath = validPath;
	}
	
	public String getValidData() {
		return this.validData;
	}

	public void setValidData(String validData) {
		this.validData = validData;
	}
	
	public String getUName() {
		return this.uName;
	}

	public void setUName(String uName) {
		this.uName = uName;
	}
}
