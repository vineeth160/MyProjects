package com.bh.adf.qms.webscripts;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.web.scripts.workflow.AbstractWorkflowWebscript;
import org.alfresco.repo.web.scripts.workflow.WorkflowModelBuilder;
import org.alfresco.service.cmr.workflow.WorkflowInstance;
import org.alfresco.service.cmr.workflow.WorkflowService;
import org.alfresco.service.cmr.workflow.WorkflowTask;
import org.alfresco.service.cmr.workflow.WorkflowTaskQuery;
import org.alfresco.service.cmr.workflow.WorkflowTaskState;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.ModelUtil;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

/**
 * 
 * @CustomizedBy Leela Prasad Guvvala
 * @BakerHughes 503184106
 * @TechMahindra GL00640582
 * @UpdatedOn 06-09-2020
 *
 */

public class BhTasksGet extends AbstractWorkflowWebscript {
	
	public static final String APP_ALFRESCO_MODEL = "http://www.alfresco.org/model/content/1.0";
	public static final String APP_BH_WF_MODEL = "http://http://www.bakerhughes.com/model/workflow/1.0";
	QName PROP_QNAME_HR_TASK_OWNER = QName.createQName(APP_BH_WF_MODEL, "hr_taskowner_sso");
	QName PROP_QNAME_HR_TASK_EMAIL = QName.createQName(APP_BH_WF_MODEL, "hr_taskowner_mail");
	QName PROP_QNAME_OWNER = QName.createQName(APP_ALFRESCO_MODEL, "owner");

	protected Map<String, Object> buildModel(WorkflowModelBuilder modelBuilder, WebScriptRequest req, Status status,
			Cache cache) {
		return getTasks(modelBuilder, req);
	}
	
	private Map<String, Object> getTasks(WorkflowModelBuilder modelBuilder, WebScriptRequest req) {
		WorkflowService workflowService = this.workflowService;
		String uName = getUName();
		return AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Map<String, Object>>()
	    {
			@Override
			public Map<String, Object> doWork() throws Exception {
				ArrayList<Map<String, Object>> results = new ArrayList<>();
				List<WorkflowTask> userTasks = new ArrayList<WorkflowTask>();
				
				String taskUser = getTaskuser(req);
				if (taskUser != null && !taskUser.isBlank() && !taskUser.isEmpty() && !taskUser.equalsIgnoreCase("null") ) {
					taskUser = taskUser.toLowerCase();
				}
				
				int maxItems = 100;
				int skipCount = 0;
				int totalCount = 0;
				// System.out.println("Task user : " + taskUser);
				List<WorkflowInstance> workflowsActive = workflowService.getActiveWorkflows();
				for (WorkflowInstance w : workflowsActive) {
					WorkflowTaskQuery taskQuery = new WorkflowTaskQuery();
					taskQuery.setActive(true);
					taskQuery.setProcessId(w.getId());
					taskQuery.setTaskState(WorkflowTaskState.IN_PROGRESS);
					List<WorkflowTask> allTasks = workflowService.queryTasks(taskQuery, true);

					// System.out.println("allTasks : " + allTasks);
					
					for (WorkflowTask t : allTasks) {
						// System.out.println("TaskId : " + t.getId() + ", Title : " + t.getTitle());
						Map<QName, Serializable> p = t.getProperties();
						String hrTaskOwner = p.get(PROP_QNAME_HR_TASK_EMAIL) != null ?  p.get(PROP_QNAME_HR_TASK_EMAIL).toString().trim().toLowerCase() : null;
						String owner = p.get(PROP_QNAME_OWNER) != null ? p.get(PROP_QNAME_OWNER).toString().trim().toLowerCase() : null;
						
						boolean hasHrTaskOwner = hrTaskOwner != null && !hrTaskOwner.isBlank() && !hrTaskOwner.isEmpty() && !hrTaskOwner.equalsIgnoreCase("null");
						boolean hasOwner = owner != null && !owner.isBlank() && !owner.isBlank() && !owner.equalsIgnoreCase("null");
						
						if (hasHrTaskOwner) {
							if (hrTaskOwner.equalsIgnoreCase(taskUser)) {
								userTasks.add(t);
								totalCount++;
								results.add(modelBuilder.buildSimple(t, null));
								// System.out.println("Actual Task User : SSO = " + hrTaskOwner + ", owner = " + owner);
							}
						} else if (hasOwner && !hasHrTaskOwner) {
							if (owner.equalsIgnoreCase(taskUser)) {
								userTasks.add(t);
								results.add(modelBuilder.buildSimple(t, null));
								totalCount++;
								// System.out.println("Actual Task User : SSO = " + hrTaskOwner + ", owner = " + owner);
							}
						}
						
					}
				}
				
				// System.out.println("User Tasks : " + userTasks);
				Map<String, Object> model = new HashMap<>();
			    model.put("taskInstances", results);
			    if (maxItems != -1 || skipCount != 0)
			      model.put("paging", ModelUtil.buildPaging(totalCount, (maxItems == -1) ? totalCount : maxItems, skipCount)); 
			    return model;
			}
	    }, "admin");
	}
	
	private String getTaskuser(WebScriptRequest req) {
	    String taskUser = req.getParameter("taskUser");
	    if (taskUser != null)
	      try {
	        return taskUser;
	      } catch (Exception exception) {} 
	    return null;
	  }

	private String uName;
	
	public String getUName() {
		return this.uName;
	}
	
	public void setUName(String uName) {
		this.uName = uName;
	}
}
