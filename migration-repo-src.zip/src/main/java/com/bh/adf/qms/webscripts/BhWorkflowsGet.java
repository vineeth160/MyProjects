package com.bh.adf.qms.webscripts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.web.scripts.workflow.AbstractWorkflowWebscript;
import org.alfresco.repo.web.scripts.workflow.WorkflowModelBuilder;
import org.alfresco.repo.workflow.WorkflowModel;
import org.alfresco.service.cmr.workflow.WorkflowDefinition;
import org.alfresco.service.cmr.workflow.WorkflowInstance;
import org.alfresco.service.cmr.workflow.WorkflowInstanceQuery;
import org.alfresco.service.namespace.QName;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.util.StringUtils;

/**
 * 
 * @CustomizedBy Leela Prasad Guvvala
 * @BakerHughes 503184106
 * @TechMahindra GL00640582
 * @UpdatedOn 06-09-2020
 *
 */

public class BhWorkflowsGet extends AbstractWorkflowWebscript {
	public static final String PARAM_STATE = "state";
	public static final String PARAM_INITIATOR = "initiator";
	public static final String PARAM_PRIORITY = "priority";
	public static final String PARAM_DUE_BEFORE = "dueBefore";
	public static final String PARAM_DUE_AFTER = "dueAfter";
	public static final String PARAM_STARTED_BEFORE = "startedBefore";
	public static final String PARAM_STARTED_AFTER = "startedAfter";
	public static final String PARAM_COMPLETED_BEFORE = "completedBefore";
	public static final String PARAM_COMPLETED_AFTER = "completedAfter";
	public static final String PARAM_DEFINITION_NAME = "definitionName";
	public static final String PARAM_DEFINITION_ID = "definitionId";
	public static final String VAR_DEFINITION_ID = "workflow_definition_id";
	public static final QName QNAME_INITIATOR = QName.createQName("", "initiator");

	protected Map<String, Object> buildModel(WorkflowModelBuilder modelBuilder, WebScriptRequest req, Status status,
			Cache cache) {
		String uName = getUName();
		return AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Map<String, Object>>() {
			@Override
			public Map<String, Object> doWork() throws Exception {

				return getWorkflows(modelBuilder, req);
			}
		}, "admin");
	}
	
	private Map<String, Object> getWorkflows(WorkflowModelBuilder modelBuilder, WebScriptRequest req) {
		WorkflowInstanceQuery workflowInstanceQuery = new WorkflowInstanceQuery();
	    Map<String, String> params = req.getServiceMatch().getTemplateVars();
	    WorkflowState state = getState(req);
	    Map<QName, Object> filters = new HashMap<>(9);
	    if (req.getParameter(PARAM_INITIATOR) != null)
	      filters.put(QNAME_INITIATOR, this.personService.getPerson(req.getParameter(PARAM_INITIATOR))); 
	    if (req.getParameter(PARAM_PRIORITY) != null)
	      filters.put(WorkflowModel.PROP_WORKFLOW_PRIORITY, req.getParameter(PARAM_PRIORITY)); 
	    String excludeParam = req.getParameter("exclude");
	    if (excludeParam != null && excludeParam.length() > 0)
	      workflowInstanceQuery.setExcludedDefinitions(Arrays.asList(StringUtils.tokenizeToStringArray(excludeParam, ","))); 
	    Map<WorkflowInstanceQuery.DatePosition, Date> dateParams = new HashMap<>();
	    Date dueBefore = getDateFromRequest(req, PARAM_DUE_BEFORE);
	    if (dueBefore != null)
	      dateParams.put(WorkflowInstanceQuery.DatePosition.BEFORE, dueBefore); 
	    Date dueAfter = getDateFromRequest(req, PARAM_DUE_AFTER);
	    if (dueAfter != null)
	      dateParams.put(WorkflowInstanceQuery.DatePosition.AFTER, dueAfter); 
	    if (dateParams.isEmpty()) {
	      if (req.getParameter(PARAM_DUE_BEFORE) != null || req.getParameter(PARAM_DUE_AFTER) != null)
	        filters.put(WorkflowModel.PROP_WORKFLOW_DUE_DATE, null); 
	    } else {
	      filters.put(WorkflowModel.PROP_WORKFLOW_DUE_DATE, dateParams);
	    } 
	    workflowInstanceQuery.setStartBefore(getDateFromRequest(req, PARAM_STARTED_BEFORE));
	    workflowInstanceQuery.setStartAfter(getDateFromRequest(req, PARAM_STARTED_AFTER));
	    workflowInstanceQuery.setEndBefore(getDateFromRequest(req, PARAM_COMPLETED_BEFORE));
	    workflowInstanceQuery.setEndAfter(getDateFromRequest(req, PARAM_COMPLETED_AFTER));
	    String workflowDefinitionId = params.get(VAR_DEFINITION_ID);
	    if (workflowDefinitionId == null)
	      workflowDefinitionId = req.getParameter(PARAM_DEFINITION_ID); 
	    if (state == null)
	      state = WorkflowState.ACTIVE; 
	    workflowInstanceQuery.setActive(Boolean.valueOf((state == WorkflowState.ACTIVE)));
	    workflowInstanceQuery.setCustomProps(filters);
	    List<WorkflowInstance> workflows = new ArrayList<>();
	    int total = 0;
	    int maxItems = getIntParameter(req, "maxItems", -1);
	    int skipCount = getIntParameter(req, "skipCount", 0);
	    if (workflowDefinitionId == null && req.getParameter(PARAM_DEFINITION_NAME) != null) {
	      int workingSkipCount = skipCount;
	      String definitionName = req.getParameter(PARAM_DEFINITION_NAME);
	      List<WorkflowDefinition> defs = this.workflowService.getAllDefinitionsByName(definitionName);
	      int itemsToQuery = maxItems;
	      for (WorkflowDefinition def : defs) {
	        workflowDefinitionId = def.getId();
	        workflowInstanceQuery.setWorkflowDefinitionId(workflowDefinitionId);
	        if (maxItems < 0 || itemsToQuery > 0)
	          workflows.addAll(this.workflowService.getWorkflows(workflowInstanceQuery, itemsToQuery, workingSkipCount)); 
	        if (maxItems > 0)
	          itemsToQuery = maxItems - workflows.size(); 
	        total += (int)this.workflowService.countWorkflows(workflowInstanceQuery);
	        if (workingSkipCount > 0) {
	          workingSkipCount = skipCount - total;
	          if (workingSkipCount < 0)
	            workingSkipCount = 0; 
	        } 
	      } 
	    } else {
	      if (workflowDefinitionId != null)
	        workflowInstanceQuery.setWorkflowDefinitionId(workflowDefinitionId); 
	      workflows.addAll(this.workflowService.getWorkflows(workflowInstanceQuery, maxItems, skipCount));
	      total = (int)this.workflowService.countWorkflows(workflowInstanceQuery);
	    } 
	    List<Map<String, Object>> results = new ArrayList<>(total);
	    results.addAll(Arrays.asList((Map<String, Object>[])new Map[total]));
	    for (WorkflowInstance workflow : workflows) {
	      results.set(skipCount, modelBuilder.buildSimple(workflow));
	      skipCount++;
	    } 
	    return createResultModel(req, "workflowInstances", results);
	}
	
	private WorkflowState getState(WebScriptRequest req) {
	    String stateName = req.getParameter("state");
	    if (stateName != null)
	      try {
	        return WorkflowState.valueOf(stateName.toUpperCase());
	      } catch (IllegalArgumentException e) {
	        String msg = "Unrecognised State parameter: " + stateName;
	        throw new WebScriptException(400, msg);
	      }  
	    return null;
	  }
	  
	  private enum WorkflowState {
	    ACTIVE, COMPLETED;
	  }
	  
	  private Date getDateFromRequest(WebScriptRequest req, String paramName) {
	    String dateParam = req.getParameter(paramName);
	    if (dateParam != null)
	      if (!"".equals(dateParam) && !"null".equals(dateParam))
	        return getDateParameter(req, paramName);  
	    return null;
	  }
	
	class WorkflowInstanceDueAscComparator implements Comparator<WorkflowInstance> {
	    public int compare(WorkflowInstance o1, WorkflowInstance o2) {
	      Date date1 = o1.getDueDate();
	      Date date2 = o2.getDueDate();
	      long time1 = (date1 == null) ? Long.MAX_VALUE : date1.getTime();
	      long time2 = (date2 == null) ? Long.MAX_VALUE : date2.getTime();
	      long result = time1 - time2;
	      return (result > 0L) ? 1 : ((result < 0L) ? -1 : 0);
	    }
	  }
	
	private String uName;
	
	public String getUName() {
		return this.uName;
	}

	public void setUName(String uName) {
		this.uName = uName;
	}

}
