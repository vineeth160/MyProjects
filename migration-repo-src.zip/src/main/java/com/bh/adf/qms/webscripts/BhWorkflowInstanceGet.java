package com.bh.adf.qms.webscripts;

import java.util.HashMap;
import java.util.Map;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.web.scripts.workflow.AbstractWorkflowWebscript;
import org.alfresco.repo.web.scripts.workflow.WorkflowModelBuilder;
import org.alfresco.service.cmr.workflow.WorkflowInstance;
import org.alfresco.service.cmr.workflow.WorkflowService;
import org.alfresco.service.cmr.workflow.WorkflowTask;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;

/**
 * 
 * @CustomizedBy Leela Prasad Guvvala
 * @BakerHughes 503184106
 * @TechMahindra GL00640582
 * @UpdatedOn 06-09-2020
 *
 */

public class BhWorkflowInstanceGet extends AbstractWorkflowWebscript {
  public static final String PARAM_INCLUDE_TASKS = "includeTasks";
  
  protected Map<String, Object> buildModel(WorkflowModelBuilder modelBuilder, WebScriptRequest req, Status status, Cache cache) {
    
    return getWorkflowInstance(modelBuilder, req, this.workflowService);
  }
  
  private boolean getIncludeTasks(WebScriptRequest req) {
    String includeTasks = req.getParameter("includeTasks");
    if (includeTasks != null)
      try {
        return Boolean.valueOf(includeTasks).booleanValue();
      } catch (Exception exception) {} 
    return false;
  }
  
  private Map<String, Object> getWorkflowInstance(WorkflowModelBuilder modelBuilder, WebScriptRequest req, WorkflowService workflowService) {
	  String uName = getUName();
	  return AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Map<String, Object>>()
	    {

			@Override
			public Map<String, Object> doWork() throws Exception {
				
				Map<String, String> params = req.getServiceMatch().getTemplateVars();
			    String workflowInstanceId = params.get("workflow_instance_id");
			    // System.out.println("lee-bh-workflowInstanceId : " + workflowInstanceId);
			    boolean includeTasks = getIncludeTasks(req);
			    // System.out.println("lee-bh-workflowInstance-includeTasks : " + includeTasks);
			    WorkflowInstance workflowInstance = workflowService.getWorkflowById(workflowInstanceId);
			    // System.out.println("lee-bh-workflowInstance-workflowInstance : " + workflowInstance);
			    if (workflowInstance == null)
			      throw new WebScriptException(404, "Unable to find workflow instance with id: " + workflowInstanceId); 
			    Map<String, Object> model = new HashMap<>();
			    Map<String, Object> result = modelBuilder.buildDetailed(workflowInstance, includeTasks);
			    // System.out.println("lee-bh-workflowInstance-result : " + result);
			    model.put("workflowInstance", result);
				return model;
				
			}
	    }, "admin");
  }
  
  	private String uName;
	
	public String getUName() {
		return this.uName;
	}
	
	public void setUName(String uName) {
		this.uName = uName;
	}
  
}
