package com.bh.adf.qms.webscripts;

import java.util.Map;

import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.AuthenticationService;
import org.alfresco.service.cmr.security.AuthorityService;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

/**
 * 
 * @author Leela Prasad Guvvala
 * @BakerHughes 503184106
 * @TechMahindra GL00640582
 * @UpdatedOn 06-09-2020
 * 
 */

public abstract class BhAbstractTicket extends DeclarativeWebScript {
	
	protected AuthenticationService authenticationService;
	protected AuthorityService authorityService;
	protected SearchService searchService;
	protected NodeService nodeService;
	protected ContentService contentService;
	
	public void setAuthenticationService(AuthenticationService authenticationService)
    {
        this.authenticationService = authenticationService;
    }
	
	public void setAuthorityService(AuthorityService authorityService)
    {
        this.authorityService = authorityService;
    }
	
	public void setSearchService(SearchService searchService)
	{
		this.searchService = searchService;
	}
	
	public void setNodeService(NodeService nodeService)
	{
		this.nodeService = nodeService;
	}
	public void setContentService(ContentService contentService)
	{
		this.contentService = contentService;
	}
	
	@Override
    protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache)
    {
		return buildModel(req, status, cache);
    }
	
	protected abstract Map<String, Object> buildModel(WebScriptRequest req, Status status, Cache cache);

}
