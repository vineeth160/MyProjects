package com.bh.adf.qms.webscripts;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.web.scripts.workflow.AbstractWorkflowWebscript;
import org.alfresco.repo.web.scripts.workflow.WorkflowModelBuilder;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.PersonService;
import org.alfresco.service.cmr.workflow.WorkflowInstance;
import org.alfresco.service.cmr.workflow.WorkflowService;
import org.alfresco.service.cmr.workflow.WorkflowTask;
import org.alfresco.service.namespace.QName;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;

/**
 * 
 * @CustomizedBy Leela Prasad Guvvala
 * @BakerHughes 503184106
 * @TechMahindra GL00640582
 * @UpdatedOn 06-09-2020
 *
 */

public class BhTaskInstanceGet extends AbstractWorkflowWebscript {
  protected Map<String, Object> buildModel(WorkflowModelBuilder modelBuilder, WebScriptRequest req, Status status, Cache cache) {
    
    return getWorkflowTask(modelBuilder, req, this.workflowService, this.nodeService, this.personService);
  }
  
  private Map<String, Object> getWorkflowTask(WorkflowModelBuilder modelBuilder, WebScriptRequest req, WorkflowService workflowService, NodeService nodeService, PersonService personService) {
	  String uName = getUName();
	  return AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Map<String, Object>>()
	    {

			@Override
			public Map<String, Object> doWork() throws Exception {
				Map<String, String> params = req.getServiceMatch().getTemplateVars();
			    String taskId = params.get("task_instance_id");
			    // System.out.println("lee-bh-TaskId : " + taskId);
			    WorkflowTask workflowTask = workflowService.getTaskById(taskId);
			    // System.out.println("lee-bh-workflowTask : " + workflowTask);
			    if (workflowTask == null)
			      throw new WebScriptException(404, "Unable to find workflow task with id: " + taskId); 
			    Map<String, Object> model = new HashMap<>();
			    Map<String, Object> result = modelBuilder.buildDetailed(workflowTask);
			    Map<String, Object> defintion = (Map<String, Object>) result.get("definition");
			    // System.out.println("lee-bh-definitions : " + defintion);
			    
			    Map<String, Object> properties = (Map<String, Object>)result.get("properties");			    
			    Map<String, Object> assignees = getAssignees(properties);			    
			    result.put("assignees", assignees);			    
			   			    
			    List<Map<String, String>> comments = getComments(modelBuilder, result, properties);
			    result.put("comments", comments);
			    // System.out.println("Result : " + result);
			    model.put("workflowTask", result);
				return model;
			}
	    }, "admin");
  }
  
  private Map<String, Object> getAssignees(Map<String, Object> properties) {
	  Map<String, Object> assignees = new HashMap<String, Object>();
	// System.out.println("lee-bh-properties : " + properties);
	
	System.out.println("lee-bh-bhwf_publisher : " + properties.get("bhwf_publisher"));
	System.out.println("lee-bh-bhwf_primaryReviewer : " + properties.get("bhwf_primaryReviewer"));
	System.out.println("lee-bh-bhwf_reviewer : " + properties.get("bhwf_reviewer"));
	System.out.println("lee-bh-bhwf_primaryApprover : " + properties.get("bhwf_primaryApprover"));
	System.out.println("lee-bh-bhwf_approver : " + properties.get("bhwf_approver"));
	System.out.println("lee-bh-bhwf_admin : " + properties.get("bhwf_admin"));
	System.out.println("lee-bh-bhwf_archival : " + properties.get("bhwf_archival"));
	System.out.println("lee-bhwf_archivalApprover : " + properties.get("bhwf_archivalApprover"));
	
	if(properties.get("bhwf_publisher") != null) {
		NodeRef nodeRef = new NodeRef(properties.get("bhwf_publisher").toString());
		// System.out.println("lee-bh-bhwf_publisher-nodeRef : " + personService.getPerson(nodeRef));
		// System.out.println("Publisher Properties - start");
		Map<String, String> user = buildUser(nodeRef);
		if (user.keySet().size() > 0) {
			assignees.put("publisherUser", user);
		} else {
			assignees.put("publisherUser", "");
		}
		// System.out.println("Publisher Properties - end");
	}
	
	if (properties.get("bhwf_primaryReviewer") != null) {
		NodeRef nodeRef = new NodeRef(properties.get("bhwf_primaryReviewer").toString());
		// System.out.println("lee-bh-bhwf_primaryReviewer-nodeRef : " + nodeRef);
		// System.out.println("Primary reviewer Properties - start");
		Map<String, String> user = buildUser(nodeRef);
		if (user.keySet().size() > 0) {
			assignees.put("primaryReviewerUser", user);
		} else {
			assignees.put("primaryReviewerUser", "");
		}
		// System.out.println("Primary reviewer Properties - end");
	}
	
	try {
	    if (properties.get("bhwf_reviewer") != null) {
	    	ArrayList reviewer = (ArrayList) properties.get("bhwf_reviewer");
	    	List<Map<String, String>> users = new ArrayList<>();
	    	for(Object r : reviewer) {
	    		NodeRef nodeRef = new NodeRef(r.toString());
	    		Map<String, String> user = buildUser(nodeRef);
	    		// System.out.println("Reviewers-nodeRef : " + nodeRef);
	    		if (user.keySet().size() > 0) {
	    			users.add(user);
	    		}
	    	}
	    	if (users.size() > 0) {
	    		assignees.put("reviewerUser", users);
	    	} else {
	    		assignees.put("reviewerUser", "");
	    	}
	    } else {
	    	// System.out.println("Reviewers Instance");
	    }
	} catch (Exception e) {
		// System.out.println("Reviewer Exception : " + e);
	}
	
	if (properties.get("bhwf_primaryApprover") != null) {
		NodeRef nodeRef = new NodeRef(properties.get("bhwf_primaryApprover").toString());
		// System.out.println("lee-bh-bhwf_primaryApprover-nodeRef : " + nodeRef);
		// System.out.println("Primary Approver Properties - start");
		Map<String, String> user = buildUser(nodeRef);
		if (user.keySet().size() > 0) {
			assignees.put("primaryApproverUser", user);
		} else {
			assignees.put("primaryApproverUser", "");
		}
		// System.out.println("Primary Approver Properties - end");
	}
	
	try {
	    if (properties.get("bhwf_approver") != null) {
	    	ArrayList approver = (ArrayList) properties.get("bhwf_approver");
	    	List<Map<String, String>> users = new ArrayList<>();
	    	for(Object r : approver) {
	    		NodeRef nodeRef = new NodeRef(r.toString());
	    		Map<String, String> user = buildUser(nodeRef);
	    		// System.out.println("Approvers-nodeRef : " + nodeRef);
	    		if (user.keySet().size() > 0) {
	    			users.add(user);
	    		}
	    	}
	    	if (users.size() > 0) {
	    		assignees.put("approverUser", users);
	    	} else {
	    		assignees.put("approverUser", "");
	    	}
	    } else {
	    	// System.out.println("Approvers Instance");
	    }
	} catch (Exception e) {
		// System.out.println("Approver Exception " + e);
	}
	
	if (properties.get("bhwf_admin") != null) {
		NodeRef nodeRef = new NodeRef(properties.get("bhwf_admin").toString());
		// System.out.println("lee-bh-bhwf_admin-nodeRef : " + personService.getPerson(nodeRef));
		// System.out.println("Admin Properties - start");
		Map<String, String> user = buildUser(nodeRef);
		if (user.keySet().size() > 0) {
			assignees.put("adminUser", user);
		} else {
			assignees.put("adminUser", "");
		}
		// System.out.println("Admin Properties - end");
	}
	
	if (properties.get("bhwf_sme") != null) {
		NodeRef nodeRef = new NodeRef(properties.get("bhwf_sme").toString());
		// System.out.println("lee-bh-bhwf_sme-nodeRef : " + nodeRef);
		// System.out.println("SME Properties - start");
		Map<String, String> user = buildUser(nodeRef);
		if (user.keySet().size() > 0) {
			assignees.put("smeUser", user);
		} else {
			assignees.put("smeUser", "");
		}
		// System.out.println("SME Properties - end");
	}
	
	if (properties.get("bhwf_intakes") != null) {
		NodeRef nodeRef = new NodeRef(properties.get("bhwf_intakes").toString());
		// System.out.println("lee-bh-bhwf_intakes-nodeRef : " + nodeRef);
		// System.out.println("Intakes Properties - start");
		Map<String, String> user = buildUser(nodeRef);
		if (user.keySet().size() > 0) {
			assignees.put("intakesUser", user);
		} else {
			assignees.put("intakesUser", "");
		}
		// System.out.println("Intakes Properties - end");
	}
	
	if (properties.get("bhwf_archival") != null) {
		NodeRef nodeRef = new NodeRef(properties.get("bhwf_archival").toString());
		// System.out.println("Intakes Archival Properties - start");
		Map<String, String> user = buildUser(nodeRef);
		if (user.keySet().size() > 0) {
			assignees.put("intakesArchivalUser", user);
		} else {
			assignees.put("intakesArchivalUser", "");
		}
		// System.out.println("Intakes Archival Properties - end");
	}
	
	if (properties.get("bhwf_archivalApprover") != null) {
		NodeRef nodeRef = new NodeRef(properties.get("bhwf_archivalApprover").toString());
		// System.out.println("lee-bh-bhwf_intakes-nodeRef : " + nodeRef);
		// System.out.println("ADR approver Properties - start");
		Map<String, String> user = buildUser(nodeRef);
		if (user.keySet().size() > 0) {
			assignees.put("adrApproverUser", user);
		} else {
			assignees.put("adrApproverUser", "");
		}
		// System.out.println("ADR Approver Properties - end");
	}
	
	// System.out.println("Assignees : " + assignees);
	return assignees;
  }
  
  private Map<String, String> buildUser(NodeRef nodeRef) {
	  Map<String, String> user = new HashMap<String, String>();
	  user.put("username", nodeRef.toString());
	  Map<QName, Serializable> properties = this.nodeService.getProperties(nodeRef);
	  Iterator iterator = properties.entrySet().iterator();
	  while(iterator.hasNext()) {
		  Map.Entry keyValuePairs = (Map.Entry)iterator.next();
		  String keyValue = keyValuePairs.getKey().toString().trim().toLowerCase();
		  String value = keyValuePairs.getValue().toString().trim();
		  // System.out.println(keyValuePairs.getKey() + " = " + keyValuePairs.getValue());
		  String key = keyValue.substring(keyValue.lastIndexOf("}")+1);
		  // System.out.println("Updated Key : " + key);
		  switch(key) {
			  case "email":
				  user.put("email", value);
				  break;
			  case "employee_email_id":
				  user.put("email", value);
				  break;
			  case "lastname":
				  user.put("lastname", value);
				  break;
			  case "employee_last_name":
				  user.put("lastname", value);
				  break;
			  case "firstname":
				  user.put("firstname", value);
				  break;
			  case "employee_first_name":
				  user.put("firstname", value);
				  break;
			  case "username":
				  user.put("uname", value);
				  break;
			  case "employee_sso":
				  user.put("uname", value);
				  break;
		  }
	  }
	  return user;
  }
  
  private List<Map<String, String>> getComments(WorkflowModelBuilder modelBuilder,Map<String, Object> result,Map<String, Object> properties) {
	  List<Map<String, String>> comments = new ArrayList<>();
	    try {
		    // Workflow instance details
		    Map<String, Object> workflowInstance = (Map<String, Object>) result.get("workflowInstance");
		    String workflowInstanceId = workflowInstance.get("id").toString();
		    // System.out.println("workflowInstanceId : " + workflowInstanceId);
		    WorkflowInstance workflowInstanceDetails = workflowService.getWorkflowById(workflowInstanceId);
		    // System.out.println("workflowInstanceDetails : " + workflowInstanceDetails);
		    if (workflowInstanceDetails == null)
		      throw new WebScriptException(404, "Unable to find workflow instance with id: " + workflowInstanceId);
		    Map<String, Object> workflowResult = modelBuilder.buildDetailed(workflowInstanceDetails, true);
		    // System.out.println("lee-bh-workflowInstance-result : " + workflowResult);
		    
		    ArrayList tasks = (ArrayList) workflowResult.get("tasks");
		    for (Object t: tasks) {
		    	Map<String, Object> task = (Map<String, Object>) t;
		    	String state = task.get("state").toString();
		    	if (state.equalsIgnoreCase("COMPLETED")) {
		    		String taskName = task.get("name").toString();
		    		String tId = task.get("id").toString();
		    		Map<String, Object> taskProperties = (Map<String, Object>) task.get("properties");
		    		String comment = taskProperties.get("bpm_comment") != null ? taskProperties.get("bpm_comment").toString() : null;
		    		String message = workflowResult.get("message") != null ? workflowResult.get("message").toString() : null;
		    		String reason = properties.get("bhwf_bh_reason_for_revision") != null ? properties.get("bhwf_bh_reason_for_revision").toString() : null;
		    		// System.out.println("Completeion date : " + taskProperties.get("bpm_completionDate"));
		    		String completionDate = taskProperties.get("bpm_completionDate") != null ? taskProperties.get("bpm_completionDate").toString() : null;
		    		if (tId.contains("start")) {
		    			Map<String, String> c = new HashMap<String, String>();
		    			c.put("type", taskName);
		    			if (message != null) {
		    				c.put("comment", message);
		    			} else if (reason != null) {
		    				c.put("comment", reason);
		    			} else {
		    				c.put("comment", comment);
		    			}		    			
		    			c.put("action", "yet to integrate");
		    			c.put("date", completionDate);
		    			comments.add(c);
		    		} else {
		    			Map<String, String> c = new HashMap<String, String>();
		    			c.put("type", taskName);
		    			c.put("comment", comment);
		    			c.put("action", "yet to integrate");
		    			c.put("date", completionDate);
		    			comments.add(c);
		    		}				    		
		    	}			    	
		    }
		    // System.out.println("All Comments : " + comments);
		    
	    } catch (Exception e) {
	    	// System.out.println("Workflow details block : " + e);
	    }
	  
	  return comments;
  }
  
  	private String uName;
	
	public String getUName() {
		return this.uName;
	}

	public void setUName(String uName) {
		this.uName = uName;
	}
  
}