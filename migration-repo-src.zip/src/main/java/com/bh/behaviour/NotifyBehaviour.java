package com.bh.behaviour;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.action.executer.MailActionExecuter;
import org.alfresco.repo.node.NodeServicePolicies;
import org.alfresco.repo.policy.Behaviour.NotificationFrequency;
import org.alfresco.repo.policy.JavaBehaviour;
import org.alfresco.repo.policy.PolicyComponent;
import org.alfresco.service.cmr.action.Action;
import org.alfresco.service.cmr.action.ActionService;
import org.alfresco.service.cmr.repository.AssociationRef;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bh.alfresco.qms.constants.BHContentModelConstants;


public class NotifyBehaviour implements NodeServicePolicies.OnUpdateNodePolicy, NodeServicePolicies.OnUpdatePropertiesPolicy {

	private static final Log logger = LogFactory.getLog(NotifyBehaviour.class);
	
	static final String BH_CONTENT_MODEL_1_0_URI = BHContentModelConstants.BH_DOCUMENTS_NAMESPACE_URI;
	static final QName PROP_DOCUMENT_STATE = QName.createQName(BH_CONTENT_MODEL_1_0_URI, "document_state");

	private PolicyComponent policyComponent;
	private NodeService nodeService;
	private SearchService searchService;
	private ActionService actionService;
	private String typeOfChange="";
	// should be an XPath
	private String emailTemplate = "/app:company_home/app:dictionary/cm:BH_QMS_Deployments/cm:Email_Templates/cm:Subscription/cm:bh-documentSubscription-email.html.ftl";

	public static final QName ASPECT_NOTIFY = QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, "subscribable");
	public static final QName PROP_NOTIFY = QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, "subscribedBy");

	public void init() {
		
		policyComponent.bindClassBehaviour(NodeServicePolicies.OnUpdatePropertiesPolicy.QNAME, ASPECT_NOTIFY, new JavaBehaviour(this,
				"onUpdateProperties", NotificationFrequency.TRANSACTION_COMMIT));
	}

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.alfresco.repo.node.NodeServicePolicies.OnUpdatePropertiesPolicy#
	 * onUpdateProperties(org.alfresco.service.cmr.repository.NodeRef,
	 * java.util.Map, java.util.Map)
	 */
	@Override
	public void onUpdateProperties(NodeRef nodeRef, Map<QName, Serializable> before, Map<QName, Serializable> after) {
		logger.info("onUpdateProperties start...");
		Serializable beforeVersion = before.get(ContentModel.PROP_VERSION_LABEL);
		Serializable afterVersion = after.get(ContentModel.PROP_VERSION_LABEL);
		Serializable beforeDocState = before.get(PROP_DOCUMENT_STATE);
		Serializable afterDocState = after.get(PROP_DOCUMENT_STATE);
		if (beforeVersion!=null && beforeVersion!="" && beforeVersion!="undefined" && !beforeVersion.equals(afterVersion)){
			logger.debug("Versions: " + beforeVersion + ", " + afterVersion);
			typeOfChange = "Document New Version has been created";
			onUpdateNode(nodeRef);
		} else if(beforeDocState!=null && beforeDocState!="" && beforeDocState!="undefined" && !beforeDocState.equals(afterDocState) && afterDocState=="Published") {
			typeOfChange = "Document has been Published";
			onUpdateNode(nodeRef);
		} else {
			typeOfChange = "Document metadata/properties have been Updated";
			onUpdateNode(nodeRef);
		}
		
		logger.info("onUpdateProperties end...");
		
		//onUpdateNode(nodeRef);
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see OnUpdateNodePolicy#onUpdateNode
	 * (org.alfresco.service.cmr.repository.NodeRef)
	 */
	@Override
	public void onUpdateNode(NodeRef actionedUponNodeRef) {

		try {
			logger.info("Triggering NotifyBehaviour");
			Action action = actionService.createAction("mail");

			List<Serializable> recipients = new ArrayList<Serializable>();
			List<AssociationRef> assocsList = nodeService.getTargetAssocs(actionedUponNodeRef, PROP_NOTIFY);
			for (AssociationRef associationRef : assocsList) {
				recipients.add(nodeService.getProperty(associationRef.getTargetRef(), ContentModel.PROP_USERNAME));
			}
			logger.info("Recipients to send mail: " + recipients.size());
			if (recipients.size() > 0) {
				action.setParameterValue(MailActionExecuter.PARAM_TO_MANY, (Serializable) recipients);
				action.setParameterValue(MailActionExecuter.PARAM_SUBJECT,
						"ISO BH System Admin Notification(s) for Document Subscription.");
				Map<String, Serializable> templateArgs = new HashMap<String, Serializable>();
				templateArgs.put("typeOfChange", typeOfChange);
				Map<String, Serializable> templateModel = new HashMap<String, Serializable>();
				templateModel.put("args", (Serializable) templateArgs);
				action.setParameterValue(MailActionExecuter.PARAM_TEMPLATE_MODEL, (Serializable) templateModel);
				// Getting nodeRef of template
				ResultSet results = searchService.query(actionedUponNodeRef.getStoreRef(), SearchService.LANGUAGE_XPATH, emailTemplate);
				action.setParameterValue(MailActionExecuter.PARAM_TEMPLATE, results.getNodeRef(0));

				actionService.executeAction(action, actionedUponNodeRef);
				logger.info("Mail sent");
			}
		} catch (InvalidNodeRefException e) {
			logger.error("Error getting NodeRef " + e.getMessage() + e.getCause());
		} catch (Exception e) {
			logger.error("Error firing mail Action " + e.getMessage() + e.getCause());
		}
	}

	
	public void setPolicyComponent(PolicyComponent policyComponent) {
		this.policyComponent = policyComponent;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public void setActionService(ActionService actionService) {
		this.actionService = actionService;
	}

	public void setEmailTemplate(String emailTemplate) {
		this.emailTemplate = emailTemplate;
	}

	public void setSearchService(SearchService search) {
		this.searchService = search;
	}
}