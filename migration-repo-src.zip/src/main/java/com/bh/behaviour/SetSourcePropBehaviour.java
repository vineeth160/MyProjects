package com.bh.behaviour;

import java.io.Serializable;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.node.NodeServicePolicies;
import org.alfresco.repo.policy.Behaviour.NotificationFrequency;
import org.alfresco.repo.policy.JavaBehaviour;
import org.alfresco.repo.policy.PolicyComponent;
import org.alfresco.service.cmr.repository.AssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bh.alfresco.qms.constants.BHContentModelConstants;

public class SetSourcePropBehaviour {

	/** logger */
	private static final Log logger = LogFactory.getLog(SetSourcePropBehaviour.class);

	/** nodeService*/
	private NodeService nodeService;

	/** eventManager*/
	private PolicyComponent eventManager;
	/**
	 * 
	 * @param nodeService
	 */
	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}
	/**
	 * 
	 * @param policyComponent
	 */
	public void setPolicyComponent(PolicyComponent policyComponent) {
		this.eventManager = policyComponent;
	}

	/** REVISION_TYPE    */
	private static final String REVISION_TYPE = "Target";

	/** DOCUMENT_STATE    */
	private static final String DOCUMENT_STATE = "Published";


	/**
	 *  registerHandlers
	 */
	public void registerEventHandlers() {
		eventManager.bindClassBehaviour(NodeServicePolicies.OnUpdatePropertiesPolicy.QNAME, BHContentModelConstants.TYPE_BHQMS,
				new JavaBehaviour(this, "OnUpdateProperties",NotificationFrequency.TRANSACTION_COMMIT));


		eventManager.bindAssociationBehaviour(NodeServicePolicies.
				OnCreateAssociationPolicy.QNAME, BHContentModelConstants.TYPE_BHQMS, new
				JavaBehaviour(this,
						"OnCreateAssociation",NotificationFrequency.TRANSACTION_COMMIT));

		eventManager.bindAssociationBehaviour(NodeServicePolicies.
				OnDeleteAssociationPolicy.QNAME, BHContentModelConstants.TYPE_BHQMS, new
				JavaBehaviour(this,
						"OnDeleteAssociation",NotificationFrequency.TRANSACTION_COMMIT));

	}


	public void OnCreateAssociation(AssociationRef nodeAssocRef) {

		if(logger.isDebugEnabled())
		{
			logger.debug("Calling in OnCreate Association");
			logger.debug("nodeAssocRef :: "+nodeAssocRef);
			logger.debug("nodeAssocn Source :: "+nodeAssocRef.getSourceRef());
			logger.debug("nodeAssocn target :: "+nodeAssocRef.getTargetRef());
		}
		NodeRef parentDocNodeRef = nodeAssocRef.getSourceRef();
		if (!nodeService.exists(parentDocNodeRef)) {
			return;
		}

		String revisionType=(String)nodeService.getProperty(parentDocNodeRef, BHContentModelConstants.PROP_REVISION_TYPE_QNAME);
		String documentState=(String)nodeService.getProperty(parentDocNodeRef, BHContentModelConstants.PROP_DOCUMENT_STATE_QNAME);
		if(logger.isDebugEnabled())
		{
			logger.debug("On Delete Association ::");
			logger.debug("Revision Type :: "+revisionType+"\t documentState :: "+documentState);
		}

		if(REVISION_TYPE.equalsIgnoreCase(revisionType) && DOCUMENT_STATE.equalsIgnoreCase(documentState))
		{
			NodeRef sourceRef =null;
			List<AssociationRef> sourceAssocs=nodeService.getSourceAssocs(parentDocNodeRef,BHContentModelConstants.ASSOC_REVISION_QNAME);
			if(sourceAssocs!=null)
			{
				for(AssociationRef assocRef:sourceAssocs)
				{
					sourceRef =assocRef.getSourceRef();
				}

			}

			if(logger.isDebugEnabled())
			{
				logger.debug("SourceRef ::"+ sourceRef);
			}


			List<AssociationRef> targetDocAuthorAssoc=nodeService.getTargetAssocs(parentDocNodeRef,BHContentModelConstants.ASSOC_DOCUMENT_AUTHOR_QNAME);
			List<AssociationRef> sourceDocAuthorAssoc=nodeService.getTargetAssocs(sourceRef,BHContentModelConstants.ASSOC_DOCUMENT_AUTHOR_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("targetDocAuthorAssoc :: "+targetDocAuthorAssoc+"\t sourceDocAuthorAssoc :: "+sourceDocAuthorAssoc);
			}

			if(targetDocAuthorAssoc!=null  && targetDocAuthorAssoc.size()>0)
			{
				String strSourceAuth =null;
				String strTargetAuth = targetDocAuthorAssoc.get(0).getTargetRef().toString();
				if(sourceDocAuthorAssoc!=null && sourceDocAuthorAssoc.size()>0) {
					strSourceAuth = sourceDocAuthorAssoc.get(0).getTargetRef().toString();
				}

				if(logger.isDebugEnabled())
				{
					logger.debug("strTargetFunOwner :: "+strTargetAuth+"\t strSourceFunOwner :: "+strSourceAuth);
				}

				if(!strTargetAuth.equalsIgnoreCase(strSourceAuth)) {
					if(sourceDocAuthorAssoc!=null && sourceDocAuthorAssoc.size()>0) {
						nodeService.removeAssociation(sourceRef, sourceDocAuthorAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_DOCUMENT_AUTHOR_QNAME);
					}
					nodeService.createAssociation(sourceRef, targetDocAuthorAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_DOCUMENT_AUTHOR_QNAME);
				}
			}

			else
			{
				if(sourceDocAuthorAssoc!=null && sourceDocAuthorAssoc.size()>0) {
					nodeService.removeAssociation(sourceRef, sourceDocAuthorAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_DOCUMENT_AUTHOR_QNAME);
				}
			}

			List<AssociationRef> targetDocAdminAssoc=nodeService.getTargetAssocs(parentDocNodeRef,BHContentModelConstants.ASSOC_DOCUMENT_ADMIN_QNAME);
			List<AssociationRef> sourceDocAdminAssoc=nodeService.getTargetAssocs(sourceRef,BHContentModelConstants.ASSOC_DOCUMENT_ADMIN_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("targetDocAdminAssoc :: "+targetDocAdminAssoc+"\t sourceDocAdminAssoc :: "+sourceDocAdminAssoc);
			}

			if(targetDocAdminAssoc!=null && targetDocAdminAssoc.size()>0)
			{
				String strTargetAdmin = targetDocAdminAssoc.get(0).getTargetRef().toString();
				String strSourceAdmin =null;
				if(sourceDocAdminAssoc!=null && sourceDocAdminAssoc.size()>0)
				{
					strSourceAdmin = sourceDocAdminAssoc.get(0).getTargetRef().toString();
				}

				if(logger.isDebugEnabled())
				{
					logger.debug("strTargetAdmin :: "+strTargetAdmin+"\t strSourceAdmin :: "+strSourceAdmin);
				}

				if(!strTargetAdmin.equalsIgnoreCase(strSourceAdmin)) {

					if(sourceDocAdminAssoc!=null && sourceDocAdminAssoc.size()>0) {
						nodeService.removeAssociation(sourceRef, sourceDocAdminAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_DOCUMENT_ADMIN_QNAME);
					}
					nodeService.createAssociation(sourceRef, targetDocAdminAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_DOCUMENT_ADMIN_QNAME);
				}

			}
			else
			{
				if(sourceDocAdminAssoc!=null && sourceDocAdminAssoc.size()>0) {
					nodeService.removeAssociation(sourceRef, sourceDocAdminAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_DOCUMENT_ADMIN_QNAME);
				}
			}


			List<AssociationRef> targetFunOwnerAssoc=nodeService.getTargetAssocs(parentDocNodeRef,BHContentModelConstants.ASSOC_FUNCTIONAL_OWNER_QNAME);
			List<AssociationRef> sourceFunOwnerAssoc=nodeService.getTargetAssocs(sourceRef,BHContentModelConstants.ASSOC_FUNCTIONAL_OWNER_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("targetFunOwnerAssoc :: "+targetFunOwnerAssoc+"\t sourceFunOwnerAssoc :: "+sourceFunOwnerAssoc);
			}

			if(targetFunOwnerAssoc!=null  && targetFunOwnerAssoc.size()>0)
			{
				String strSourceFunOwner =null;
				String strTargetFunOwner = targetFunOwnerAssoc.get(0).getTargetRef().toString();
				if(sourceFunOwnerAssoc!=null && sourceFunOwnerAssoc.size()>0) {
					strSourceFunOwner = sourceFunOwnerAssoc.get(0).getTargetRef().toString();
				}

				if(logger.isDebugEnabled())
				{
					logger.debug("strTargetFunOwner :: "+strTargetFunOwner+"\t strSourceFunOwner :: "+strSourceFunOwner);
				}

				if(!strTargetFunOwner.equalsIgnoreCase(strSourceFunOwner)) {
					if(sourceFunOwnerAssoc!=null && sourceFunOwnerAssoc.size()>0) {
						nodeService.removeAssociation(sourceRef, sourceFunOwnerAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_FUNCTIONAL_OWNER_QNAME);
					}
					nodeService.createAssociation(sourceRef, targetFunOwnerAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_FUNCTIONAL_OWNER_QNAME);
				}
			}

			else
			{
				if(sourceFunOwnerAssoc!=null && sourceFunOwnerAssoc.size()>0) {
					nodeService.removeAssociation(sourceRef, sourceFunOwnerAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_FUNCTIONAL_OWNER_QNAME);
				}
			}

		}

	}   


	public void OnDeleteAssociation(AssociationRef nodeAssocRef) {

		if(logger.isDebugEnabled())
		{
			logger.debug("Calling in OnDelete Association");
			logger.debug("nodeAssocRef :: "+nodeAssocRef);
			logger.debug("nodeAssocn Source :: "+nodeAssocRef.getSourceRef());
			logger.debug("nodeAssocn target :: "+nodeAssocRef.getTargetRef());
		}
		NodeRef parentDocNodeRef = nodeAssocRef.getSourceRef();
		if (!nodeService.exists(parentDocNodeRef)) {
			return;
		}

		String revisionType=(String)nodeService.getProperty(parentDocNodeRef, BHContentModelConstants.PROP_REVISION_TYPE_QNAME);
		String documentState=(String)nodeService.getProperty(parentDocNodeRef, BHContentModelConstants.PROP_DOCUMENT_STATE_QNAME);
		if(logger.isDebugEnabled())
		{
			logger.debug("On Delete Association ::");
			logger.debug("Revision Type :: "+revisionType+"\t documentState :: "+documentState);
		}

		if(REVISION_TYPE.equalsIgnoreCase(revisionType) && DOCUMENT_STATE.equalsIgnoreCase(documentState))
		{
			NodeRef sourceRef =null;
			List<AssociationRef> sourceAssocs=nodeService.getSourceAssocs(parentDocNodeRef,BHContentModelConstants.ASSOC_REVISION_QNAME);
			if(sourceAssocs!=null)
			{
				for(AssociationRef assocRef:sourceAssocs)
				{
					sourceRef =assocRef.getSourceRef();
				}

			}

			if(logger.isDebugEnabled())
			{
				logger.debug("SourceRef ::"+ sourceRef);
			}


			List<AssociationRef> targetDocAuthorAssoc=nodeService.getTargetAssocs(parentDocNodeRef,BHContentModelConstants.ASSOC_DOCUMENT_AUTHOR_QNAME);
			List<AssociationRef> sourceDocAuthorAssoc=nodeService.getTargetAssocs(sourceRef,BHContentModelConstants.ASSOC_DOCUMENT_AUTHOR_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("targetDocAuthorAssoc :: "+targetDocAuthorAssoc+"\t sourceDocAuthorAssoc :: "+sourceDocAuthorAssoc);
			}


			if(targetDocAuthorAssoc!=null  && targetDocAuthorAssoc.size()>0)
			{
				String strSourceAuth =null;
				String strTargetAuth = targetDocAuthorAssoc.get(0).getTargetRef().toString();
				if(sourceDocAuthorAssoc!=null && sourceDocAuthorAssoc.size()>0) {
					strSourceAuth = sourceDocAuthorAssoc.get(0).getTargetRef().toString();
				}

				if(logger.isDebugEnabled())
				{
					logger.debug("strTargetFunOwner :: "+strTargetAuth+"\t strSourceFunOwner :: "+strSourceAuth);
				}

				if(!strTargetAuth.equalsIgnoreCase(strSourceAuth)) {
					if(sourceDocAuthorAssoc!=null && sourceDocAuthorAssoc.size()>0) {
						nodeService.removeAssociation(sourceRef, sourceDocAuthorAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_DOCUMENT_AUTHOR_QNAME);
					}
					nodeService.createAssociation(sourceRef, targetDocAuthorAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_DOCUMENT_AUTHOR_QNAME);
				}
			}

			else
			{
				if(sourceDocAuthorAssoc!=null && sourceDocAuthorAssoc.size()>0) {
					nodeService.removeAssociation(sourceRef, sourceDocAuthorAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_DOCUMENT_AUTHOR_QNAME);
				}
			}


			List<AssociationRef> targetDocAdminAssoc=nodeService.getTargetAssocs(parentDocNodeRef,BHContentModelConstants.ASSOC_DOCUMENT_ADMIN_QNAME);
			List<AssociationRef> sourceDocAdminAssoc=nodeService.getTargetAssocs(sourceRef,BHContentModelConstants.ASSOC_DOCUMENT_ADMIN_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("targetDocAdminAssoc :: "+targetDocAdminAssoc+"\t sourceDocAdminAssoc :: "+sourceDocAdminAssoc);
			}

			if(targetDocAdminAssoc!=null && targetDocAdminAssoc.size()>0)
			{
				String strTargetAdmin = targetDocAdminAssoc.get(0).getTargetRef().toString();
				String strSourceAdmin =null;
				if(sourceDocAdminAssoc!=null && sourceDocAdminAssoc.size()>0)
				{
					strSourceAdmin = sourceDocAdminAssoc.get(0).getTargetRef().toString();
				}

				if(logger.isDebugEnabled())
				{
					logger.debug("strTargetAdmin :: "+strTargetAdmin+"\t strSourceAdmin :: "+strSourceAdmin);
				}

				if(!strTargetAdmin.equalsIgnoreCase(strSourceAdmin)) {

					if(sourceDocAdminAssoc!=null && sourceDocAdminAssoc.size()>0) {
						nodeService.removeAssociation(sourceRef, sourceDocAdminAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_DOCUMENT_ADMIN_QNAME);
					}
					nodeService.createAssociation(sourceRef, targetDocAdminAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_DOCUMENT_ADMIN_QNAME);
				}

			}
			else
			{
				if(sourceDocAdminAssoc!=null && sourceDocAdminAssoc.size()>0) {
					nodeService.removeAssociation(sourceRef, sourceDocAdminAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_DOCUMENT_ADMIN_QNAME);
				}
			}


			List<AssociationRef> targetFunOwnerAssoc=nodeService.getTargetAssocs(parentDocNodeRef,BHContentModelConstants.ASSOC_FUNCTIONAL_OWNER_QNAME);
			List<AssociationRef> sourceFunOwnerAssoc=nodeService.getTargetAssocs(sourceRef,BHContentModelConstants.ASSOC_FUNCTIONAL_OWNER_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("targetFunOwnerAssoc :: "+targetFunOwnerAssoc+"\t sourceFunOwnerAssoc :: "+sourceFunOwnerAssoc);
			}

			if(targetFunOwnerAssoc!=null  && targetFunOwnerAssoc.size()>0)
			{
				String strSourceFunOwner =null;
				String strTargetFunOwner = targetFunOwnerAssoc.get(0).getTargetRef().toString();
				if(sourceFunOwnerAssoc!=null && sourceFunOwnerAssoc.size()>0) {
					strSourceFunOwner = sourceFunOwnerAssoc.get(0).getTargetRef().toString();
				}

				if(logger.isDebugEnabled())
				{
					logger.debug("strTargetFunOwner :: "+strTargetFunOwner+"\t strSourceFunOwner :: "+strSourceFunOwner);
				}

				if(!strTargetFunOwner.equalsIgnoreCase(strSourceFunOwner)) {
					if(sourceFunOwnerAssoc!=null && sourceFunOwnerAssoc.size()>0) {
						nodeService.removeAssociation(sourceRef, sourceFunOwnerAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_FUNCTIONAL_OWNER_QNAME);
					}
					nodeService.createAssociation(sourceRef, targetFunOwnerAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_FUNCTIONAL_OWNER_QNAME);
				}
			}

			else
			{
				if(sourceFunOwnerAssoc!=null && sourceFunOwnerAssoc.size()>0) {
					nodeService.removeAssociation(sourceRef, sourceFunOwnerAssoc.get(0).getTargetRef(), BHContentModelConstants.ASSOC_FUNCTIONAL_OWNER_QNAME);
				}
			}

		}

	}   

	public void OnUpdateProperties(NodeRef noderef, Map<QName, Serializable> before, Map<QName, Serializable> after) {
		onPublishDocPropUpdate(noderef, before, after);
	}
	private void onPublishDocPropUpdate(NodeRef noderef, Map<QName, Serializable> before, Map<QName, Serializable> after) {
		if (!nodeService.exists(noderef)) {
			return;
		}

		String revisionType=(String)nodeService.getProperty(noderef, BHContentModelConstants.PROP_REVISION_TYPE_QNAME);
		String documentState=(String)nodeService.getProperty(noderef, BHContentModelConstants.PROP_DOCUMENT_STATE_QNAME);
		if(logger.isDebugEnabled())
		{
			logger.debug("Revision Type :: "+revisionType+"\t documentState :: "+documentState);
		}

		if(REVISION_TYPE.equalsIgnoreCase(revisionType) && DOCUMENT_STATE.equalsIgnoreCase(documentState))
		{

			NodeRef sourceRef =null;
			List<AssociationRef> sourceAssocs=nodeService.getSourceAssocs(noderef,BHContentModelConstants.ASSOC_REVISION_QNAME);
			if(sourceAssocs!=null)
			{
				for(AssociationRef assocRef:sourceAssocs)
				{
					sourceRef =assocRef.getSourceRef();
				}

			}

			if(logger.isDebugEnabled())
			{
				logger.debug("SourceRef ::"+ sourceRef);
			}

			String beforeDocName = (String) before.get(ContentModel.PROP_NAME);
			String afterDocName = (String) after.get(ContentModel.PROP_NAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("beforeDocName :: "+beforeDocName+"\t afterDocName :: "+afterDocName);
			}


			if(afterDocName ==null)
			{
				nodeService.removeProperty(sourceRef,ContentModel.PROP_NAME);
			}

			else 
			{
				if(!afterDocName.equalsIgnoreCase(beforeDocName))
				{
					if (nodeService.exists(sourceRef)) {

						nodeService.setProperty(sourceRef, ContentModel.PROP_NAME,afterDocName);

					}
				}
			}


			String beforeDocReference = (String) before.get(BHContentModelConstants.PROP_REFERENCE_QNAME);
			String afterDocReference = (String) after.get(BHContentModelConstants.PROP_REFERENCE_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("beforeDocReference :: "+beforeDocReference+"\t afterDocReference :: "+afterDocReference);
			}


			if(afterDocReference ==null)
			{
				nodeService.removeProperty(sourceRef,BHContentModelConstants.PROP_REFERENCE_QNAME);
			}

			else 
			{
				if(!afterDocReference.equalsIgnoreCase(beforeDocReference))
				{
					if (nodeService.exists(sourceRef)) {

						nodeService.setProperty(sourceRef, BHContentModelConstants.PROP_REFERENCE_QNAME,afterDocReference);

					}
				}
			}

			String beforeProductCompany = (String) before.get(BHContentModelConstants.PC_QNAME);
			String afterProductCompany = (String) after.get(BHContentModelConstants.PC_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("beforeProductCompany :: "+beforeProductCompany+"\t afterProductCompany :: "+afterProductCompany);
			}


			if(afterProductCompany ==null)
			{
				nodeService.removeProperty(sourceRef,BHContentModelConstants.PC_QNAME);
			}

			else 
			{
				if(!afterProductCompany.equalsIgnoreCase(beforeProductCompany))
				{
					if (nodeService.exists(sourceRef)) {

						nodeService.setProperty(sourceRef, BHContentModelConstants.PC_QNAME,afterProductCompany);

					}
				}
			}

			List<String> beforeProductLine = (List<String>)before.get(BHContentModelConstants.PL_QNAME);
			List<String>  afterProductLine =(List<String>) after.get(BHContentModelConstants.PL_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("beforeProductLine :: "+beforeProductLine+"\t afterProductLine :: "+afterProductLine);
			}


			if(afterProductLine != null && afterProductLine.size()>0)
			{
				Collections.sort(afterProductLine);
				if(beforeProductLine!=null && beforeProductLine.size()>0)
				{
					Collections.sort(beforeProductLine);
				}
				if(!afterProductLine.equals(beforeProductLine))
				{
					if (nodeService.exists(sourceRef)) {

						nodeService.setProperty(sourceRef,BHContentModelConstants.PL_QNAME,(Serializable)afterProductLine);

					}
				}
			}
			else
			{
				nodeService.removeProperty(sourceRef, BHContentModelConstants.PL_QNAME);
			}



			List<String> beforeSubProductLine = (List<String>) before.get(BHContentModelConstants.SPL_QNAME);
			List<String>  afterSubProductLine = (List<String>) after.get(BHContentModelConstants.SPL_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("beforeSubProductLine :: "+beforeSubProductLine+"\t afterSubProductLine :: "+afterSubProductLine);
			}

			// Starts
			if(afterSubProductLine != null && afterSubProductLine.size()>0)
			{
				Collections.sort(afterSubProductLine);
				if(beforeSubProductLine!=null && beforeSubProductLine.size()>0)
				{
					Collections.sort(beforeSubProductLine);
				}
				if(!afterSubProductLine.equals(beforeSubProductLine))
				{
					if (nodeService.exists(sourceRef)) {

						nodeService.setProperty(sourceRef,BHContentModelConstants.SPL_QNAME,(Serializable)afterSubProductLine);

					}
				}
			}
			else
			{
				nodeService.removeProperty(sourceRef, BHContentModelConstants.SPL_QNAME);
			}

			//Ends

			List<String> beforeSite = (List<String>) before.get(BHContentModelConstants.SITE_QNAME);
			List<String>  afterSite = (List<String>) after.get(BHContentModelConstants.SITE_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("beforeSite :: "+beforeSite+"\t afterSite :: "+afterSite);
			}


			if(afterSite != null && afterSite.size()>0)
			{
				Collections.sort(afterSite);
				if(beforeSite!=null && beforeSite.size()>0)
				{
					Collections.sort(beforeSite);
				}
				if(!afterSite.equals(beforeSite))
				{
					if (nodeService.exists(sourceRef)) {

						nodeService.setProperty(sourceRef,BHContentModelConstants.SITE_QNAME,(Serializable)afterSite);

					}
				}
			}
			else
			{
				nodeService.removeProperty(sourceRef, BHContentModelConstants.SITE_QNAME);
			}


			List<String> beforeFunction = (List<String>) before.get(BHContentModelConstants.FUNCTION_QNAME);
			List<String>  afterFunction = (List<String>) after.get(BHContentModelConstants.FUNCTION_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("beforeFunction :: "+beforeFunction+"\t afterFunction :: "+afterFunction);
			}

			if(afterFunction != null && afterFunction.size()>0)
			{
				Collections.sort(afterFunction);
				if(beforeFunction!=null && beforeFunction.size()>0)
				{
					Collections.sort(beforeFunction);
				}
				if(!afterFunction.equals(beforeFunction))
				{
					if (nodeService.exists(sourceRef)) {

						nodeService.setProperty(sourceRef,BHContentModelConstants.FUNCTION_QNAME,(Serializable)afterFunction);

					}
				}
			}
			else
			{
				nodeService.removeProperty(sourceRef, BHContentModelConstants.FUNCTION_QNAME);
			}

			String beforeSubFunction = (String)before.get(BHContentModelConstants.SUBFUNCTION_QNAME);
			String  afterSubFunction = (String)after.get(BHContentModelConstants.SUBFUNCTION_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("beforeSubFunction :: "+beforeSubFunction+"\t afterSubFunction :: "+afterSubFunction);
			}

			if(afterSubFunction ==null)
			{
				nodeService.removeProperty(sourceRef,BHContentModelConstants.SUBFUNCTION_QNAME);
			}

			else 
			{
				if(!afterSubFunction.equalsIgnoreCase(beforeSubFunction))
				{
					if (nodeService.exists(sourceRef)) {

						nodeService.setProperty(sourceRef,BHContentModelConstants.SUBFUNCTION_QNAME,afterSubFunction);

					}
				}
			}


			String beforeDocType = (String) before.get(BHContentModelConstants.DT_QNAME);
			String afterDocType = (String) after.get(BHContentModelConstants.DT_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("beforeDocType :: "+beforeDocType+"\t afterDocType :: "+afterDocType);
			}


			if(afterDocType ==null)
			{
				nodeService.removeProperty(sourceRef,BHContentModelConstants.DT_QNAME);
			}

			else 
			{
				if(!afterDocType.equalsIgnoreCase(beforeDocType))
				{
					if (nodeService.exists(sourceRef)) {

						nodeService.setProperty(sourceRef,BHContentModelConstants.DT_QNAME,afterDocType);

					}
				}
			}


			String beforeLanguage = (String) before.get(BHContentModelConstants.PROP_LANGUAGE_CODE_QNAME);
			String afterLanguage = (String) after.get(BHContentModelConstants.PROP_LANGUAGE_CODE_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("beforeLanguage :: "+beforeLanguage+"\t afterLanguage :: "+afterLanguage);
			}


			if(afterLanguage ==null)
			{
				nodeService.removeProperty(sourceRef,BHContentModelConstants.PROP_LANGUAGE_CODE_QNAME);
			}

			else 
			{
				if(!afterLanguage.equalsIgnoreCase(beforeLanguage))
				{
					if (nodeService.exists(sourceRef)) {

						nodeService.setProperty(sourceRef,BHContentModelConstants.PROP_LANGUAGE_CODE_QNAME,afterLanguage);

					}
				}
			}

			List<String> beforeIsoElement = (List<String>) before.get(BHContentModelConstants.PROP_ISO_ELEMENT_QNAME);
			List<String> afterIsoElement = (List<String>) after.get(BHContentModelConstants.PROP_ISO_ELEMENT_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("beforeIsoElement :: "+beforeIsoElement+"\t afterIsoElement :: "+afterIsoElement);
			}



			if(afterIsoElement != null && afterIsoElement.size()>0)
			{
				Collections.sort(afterIsoElement);
				if(beforeIsoElement!=null && beforeIsoElement.size()>0)
				{
					Collections.sort(beforeIsoElement);
				}
				if(!afterIsoElement.equals(beforeIsoElement))
				{
					if (nodeService.exists(sourceRef)) {

						nodeService.setProperty(sourceRef,BHContentModelConstants.PROP_ISO_ELEMENT_QNAME,(Serializable)afterIsoElement);

					}
				}
			}
			else
			{
				nodeService.removeProperty(sourceRef, BHContentModelConstants.PROP_ISO_ELEMENT_QNAME);
			}

			List<String> beforeProcess = (List<String>) before.get(BHContentModelConstants.PROP_PROCESS_QNAME);
			List<String> afterProcess = (List<String>) after.get(BHContentModelConstants.PROP_PROCESS_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("beforeProcess :: "+beforeProcess+"\t afterProcess :: "+afterProcess);
			}



			if(afterProcess != null && afterProcess.size()>0)
			{
				Collections.sort(afterProcess);
				if(beforeProcess!=null && beforeProcess.size()>0)
				{
					Collections.sort(beforeProcess);
				}
				if(!afterProcess.equals(beforeProcess))
				{
					if (nodeService.exists(sourceRef)) {

						nodeService.setProperty(sourceRef,BHContentModelConstants.PROP_PROCESS_QNAME,(Serializable)afterProcess);

					}
				}
			}
			else
			{
				nodeService.removeProperty(sourceRef, BHContentModelConstants.PROP_PROCESS_QNAME);
			}


			List<String> beforeSubProcess = (List<String>) before.get(BHContentModelConstants.PROP_SUB_PROCESS_QNAME);
			List<String> afterSubProcess = (List<String>) after.get(BHContentModelConstants.PROP_SUB_PROCESS_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("beforeSubProcess :: "+beforeSubProcess+"\t afterSubProcess :: "+afterSubProcess);
			}


			if(afterSubProcess != null && afterSubProcess.size()>0)
			{
				Collections.sort(afterSubProcess);
				if(beforeSubProcess!=null && beforeSubProcess.size()>0)
				{
					Collections.sort(beforeSubProcess);
				}
				if(!afterSubProcess.equals(beforeSubProcess))
				{
					if (nodeService.exists(sourceRef)) {

						nodeService.setProperty(sourceRef,BHContentModelConstants.PROP_SUB_PROCESS_QNAME,(Serializable)afterSubProcess);

					}
				}
			}
			else
			{
				nodeService.removeProperty(sourceRef, BHContentModelConstants.PROP_SUB_PROCESS_QNAME);
			}

			Date beforeExpiryDate = (Date)before.get(BHContentModelConstants.PROP_EXPIRY_DATE_QNAME);
			Date afterExpiryDate = (Date) after.get(BHContentModelConstants.PROP_EXPIRY_DATE_QNAME);

			if(logger.isDebugEnabled())
			{
				logger.debug("beforeExpiryDate :: "+beforeExpiryDate+"\t afterExpiryDate :: "+afterExpiryDate);
			}



			if(afterExpiryDate ==null)
			{
				nodeService.removeProperty(sourceRef,BHContentModelConstants.PROP_EXPIRY_DATE_QNAME);
			}

			else 
			{
				if(afterExpiryDate.compareTo(beforeExpiryDate)!=0)
				{
					if (nodeService.exists(sourceRef)) {

						nodeService.setProperty(sourceRef,BHContentModelConstants.PROP_EXPIRY_DATE_QNAME,afterExpiryDate);

					}
				}
			}

		}
	}
}
