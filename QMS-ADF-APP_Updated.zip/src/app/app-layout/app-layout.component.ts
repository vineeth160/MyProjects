import { SidenavLayoutComponent } from '@alfresco/adf-core';
import { Component, Output, EventEmitter, ViewChild, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app-layout.component.html',
  styleUrls: ['./app-layout.component.css']
})
export class AppLayoutComponent {
  @ViewChild('layout')
  layout: SidenavLayoutComponent;

  @Output()
  toggleClicked = new EventEmitter();

  @Input() expandedSidenav = true;

  hideSidenav = false;

  constructor() {
  }

  onExpanded(state: boolean) {
    console.log('onExpanded : ', state);
  }

}
