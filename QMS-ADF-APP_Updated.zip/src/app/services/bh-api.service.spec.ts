import { TestBed } from '@angular/core/testing';

import { BhApiService } from './bh-api.service';

describe('BhApiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BhApiService = TestBed.get(BhApiService);
    expect(service).toBeTruthy();
  });
});
