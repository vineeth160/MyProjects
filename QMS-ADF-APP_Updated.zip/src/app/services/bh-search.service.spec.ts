import { TestBed } from '@angular/core/testing';

import { BhSearchService } from './bh-search.service';

describe('BhSearchService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BhSearchService = TestBed.get(BhSearchService);
    expect(service).toBeTruthy();
  });
});
