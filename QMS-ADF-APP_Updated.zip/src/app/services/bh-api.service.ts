/*!
* @license
* Copyright 2018 Alfresco Software, Ltd.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

import { Injectable } from '@angular/core';
import { RequestOptions, BhWebscriptService } from './bh-webscript.service';
import { from, throwError, Observable, Subject } from 'rxjs';
import { catchError } from 'rxjs/operators';
import {
  NodePaging,
  QueryBody,
  ResultSetPaging,
  SearchRequest,
  AlfrescoApi,
  Node,
  NodeEntry,
  SharedLinkEntry,
  RenditionEntry,
  RenditionPaging,
  RenditionBodyCreate,
  AlfrescoApiConfig} from '@alfresco/js-api';
import { AlfrescoApiService, AppConfigService } from '@alfresco/adf-core';

@Injectable()
export class BhApiService {

  nodeUpdated = new Subject<Node>();

  dataLoaded: Subject<ResultSetPaging> = new Subject();

  constructor(private webscript: BhWebscriptService,
              private appConfig: AppConfigService,
              private apiService: AlfrescoApiService) { }

  getNodeInfo(nodeId: string, opts?: any): Promise<Node> {
    return new Promise((resolve, reject) => {
        this.getNode(nodeId, opts).then(
            (nodeEntry: NodeEntry) => {
                resolve(nodeEntry.entry);
            },
            (error) => {
                reject(error);
            }
        );
    });
  }

  // Customized "getNode" OTB API
  getNode(nodeId: string, opts?: any): Promise<NodeEntry> {

    this.throwIfNotDefined(nodeId, 'nodeId');

    opts = opts || {};
    const bodyParam: null = null;
    const pathParams = {
        'nodeId': nodeId
    };
    const queryParams = {
        'include': this.buildCollectionParam(opts['include'], 'csv'),
        'relativePath': opts['relativePath'],
        'fields': this.buildCollectionParam(opts['fields'], 'csv')
    };
    const headerParams = {};
    const formParams = {};
    const contentTypes = ['application/json'];
    const accepts = ['application/json'];

    const options: RequestOptions = {
      path: '/service/bh/public/alfresco/versions/1/nodes/{nodeId}',
      pathParams: pathParams,
      queryParams: queryParams,
      headerParams: headerParams,
      formParams: formParams,
      bodyParam: bodyParam,
      contentTypes: contentTypes,
      accepts: accepts,
      returnType: NodeEntry
    };

    return this.webscript.get(options);
}

  // Customized "getNodeChildren" OTB API
  getNodeChildren(nodeId: string, opts?: any): Promise<NodePaging> {

    this.throwIfNotDefined(nodeId, 'nodeId');

    opts = opts || {};
    const bodyParam: null = null;
    const pathParams = {
      'nodeId': nodeId
    };
    const queryParams = {
      'skipCount': opts['skipCount'],
      'maxItems': opts['maxItems'],
      'orderBy': this.buildCollectionParam(opts['orderBy'], 'csv'),
      'where': opts['where'],
      'include': this.buildCollectionParam(opts['include'], 'csv'),
      'relativePath': opts['relativePath'],
      'includeSource': opts['includeSource'],
      'fields': this.buildCollectionParam(opts['fields'], 'csv')
    };
    const contentTypes = ['application/json'];
    const accepts = ['application/json'];
    const headerParams = {};
    const formParams = {};

    const options: RequestOptions = {
      path: '/service/bh/public/alfresco/versions/1/nodes/{nodeId}/children',
      pathParams: pathParams,
      queryParams: queryParams,
      headerParams: headerParams,
      formParams: formParams,
      bodyParam: bodyParam,
      contentTypes: contentTypes,
      accepts: accepts
    };

    return this.webscript.get(options);
  }

  buildCollectionParam(param: string[], collectionFormat: string): string | any[] {
    if (!param) {
        return null;
    }

    switch (collectionFormat) {
        case 'csv':
            return param.map(this.paramToString).join(',');
        case 'ssv':
            return param.map(this.paramToString).join(' ');
        case 'tsv':
            return param.map(this.paramToString).join('\t');
        case 'pipes':
            return param.map(this.paramToString).join('|');
        case 'multi':
            // return the array directly as SuperAgent will handle it as expected
            return param.map(this.paramToString);
        default:
            throw new Error('Unknown collection format: ' + collectionFormat);
    }
  }

  paramToString(param: any): string {
    if (param === undefined || param === null) {
        return '';
    }
    if (param instanceof Date) {
        return param.toJSON();
    }
    return param.toString();
  }

  throwIfNotDefined(param: any, name: string) {
    if (param === null || param === undefined) {
        throw new Error(`Missing param '${name}'`);
    }
  }

  // Search API

  /**
   * Performs a search with its parameters supplied by a QueryBody object.
   * @param queryBody Object containing the search parameters
   * @returns List of search results
   */
  searchByQueryBody(queryBody: QueryBody): Observable<ResultSetPaging> {
    const promise = this.search(queryBody);

    promise.then((nodePaging: NodePaging) => {
        this.dataLoaded.next(nodePaging);
    }).catch((err) => this.handleError(err));

    return from(promise);
  }

  /*
  * @param queryBody Generic query API
  * @return Promise<ResultSetPaging>
  */
  search(queryBody: SearchRequest): Promise<ResultSetPaging> {
      this.throwIfNotDefined(queryBody, 'queryBody');

      const postBody = queryBody;
      const pathParams = {};
      const queryParams = {};
      const headerParams = {};
      const formParams = {};
      const contentTypes = ['application/json'];
      const accepts = ['application/json'];

      const options: RequestOptions = {
        path: '/service/bh/public/search/versions/1/search',
        pathParams: pathParams,
        queryParams: queryParams,
        headerParams: headerParams,
        formParams: formParams,
        bodyParam: postBody,
        contentTypes: contentTypes,
        accepts: accepts,
        returnType: ResultSetPaging
      };

      return this.webscript.post(options);
  }

  private handleError(error: any): Observable<any> {
      return throwError(error || 'Server error');
  }

  // Customized "getSharedLink" OTB API
  getSharedLink(sharedId: string, opts?: any): Promise<SharedLinkEntry> {

    this.throwIfNotDefined(sharedId, 'sharedId');

    opts = opts || {};
    const bodyParam: null = null;
    const pathParams = {
        'sharedId': sharedId
    };
    const queryParams = {
        'fields': this.buildCollectionParam(opts['fields'], 'csv')
    };
    const headerParams = {};
    const formParams = {};
    const contentTypes = ['application/json'];
    const accepts = ['application/json'];

    const options: RequestOptions = {
      path: '/service/bh/public/alfresco/versions/1/shared-links/{sharedId}',
      pathParams: pathParams,
      queryParams: queryParams,
      headerParams: headerParams,
      formParams: formParams,
      bodyParam: bodyParam,
      contentTypes: contentTypes,
      accepts: accepts,
      returnType: SharedLinkEntry
    };

    return this.webscript.get(options);
  }

  // Customized "getSharedLinkRendition" OTB API
  getSharedLinkRendition(sharedId: string, renditionId: string): Promise<RenditionEntry> {
    this.throwIfNotDefined(sharedId, 'sharedId');
    this.throwIfNotDefined(renditionId, 'renditionId');

    const bodyParam = null;
    const pathParams = {
        'sharedId': sharedId, 'renditionId': renditionId
    };
    const queryParams = {};
    const headerParams = {};
    const formParams = { };
    const contentTypes = ['application/json'];
    const accepts = ['application/json'];

    const options: RequestOptions = {
      path: '/service/bh/public/alfresco/versions/1/shared-links/{sharedId}/renditions/{renditionId}',
      pathParams: pathParams,
      queryParams: queryParams,
      headerParams: headerParams,
      formParams: formParams,
      bodyParam: bodyParam,
      contentTypes: contentTypes,
      accepts: accepts,
      returnType: RenditionEntry
    };

    return this.webscript.get(options);
  }

  // Customized "createRendition" OTB API
  createRendition(nodeId: string, renditionBodyCreate: RenditionBodyCreate): Promise<any> {
    this.throwIfNotDefined(nodeId, 'nodeId');
    this.throwIfNotDefined(renditionBodyCreate, 'renditionBodyCreate');

    const bodyParam = renditionBodyCreate;
    const pathParams = {
        'nodeId': nodeId
    };
    const queryParams = {};
    const headerParams = {};
    const formParams = {};
    const contentTypes = ['application/json'];
    const accepts = ['application/json'];

    const options: RequestOptions = {
      path: '/service/bh/public/alfresco/versions/1/nodes/{nodeId}/renditions',
      pathParams: pathParams,
      queryParams: queryParams,
      headerParams: headerParams,
      formParams: formParams,
      bodyParam: bodyParam,
      contentTypes: contentTypes,
      accepts: accepts
    };

    return this.webscript.post(options);
  }

  // Customized "getRendition" OTB API
  getRendition(nodeId: string, renditionId: string): Promise<RenditionEntry> {
    this.throwIfNotDefined(nodeId, 'nodeId');
    this.throwIfNotDefined(renditionId, 'renditionId');

    const bodyParam = null;
    const pathParams = {
        'nodeId': nodeId, 'renditionId': renditionId
    };
    const queryParams = {};
    const headerParams = {};
    const formParams = {};
    const contentTypes = ['application/json'];
    const accepts = ['application/json'];

    const options: RequestOptions = {
      path: '/service/bh/public/alfresco/versions/1/nodes/{nodeId}/renditions/{renditionId}',
      pathParams: pathParams,
      queryParams: queryParams,
      headerParams: headerParams,
      formParams: formParams,
      bodyParam: bodyParam,
      contentTypes: contentTypes,
      accepts: accepts,
      returnType: RenditionEntry
    };

    return this.webscript.get(options);
}

  // Customized "getRenditions" OTB API
  getRenditions(nodeId: string, opts?: any): Promise<RenditionPaging> {
    this.throwIfNotDefined(nodeId, 'nodeId');

    opts = opts || {};
    const bodyParam = null;
    const pathParams = {
        'nodeId': nodeId
    };
    const queryParams = {
        'where': opts['where']
    };
    const headerParams = {};
    const formParams = {};
    const contentTypes = ['application/json'];
    const accepts = ['application/json'];

    const options: RequestOptions = {
      path: '/service/bh/public/alfresco/versions/1/nodes/{nodeId}/renditions',
      pathParams: pathParams,
      queryParams: queryParams,
      headerParams: headerParams,
      formParams: formParams,
      bodyParam: bodyParam,
      contentTypes: contentTypes,
      accepts: accepts,
      returnType: RenditionPaging
    };

    return this.webscript.get(options);
}

  // Default API URL
  getBaseUrl() {
    return this.appConfig.get<string>('ecmHost') +
            '/alfresco/service/bh/public/alfresco/versions/1';
  }

  getAlfTicket() {
    // http://localhost:8080/alfresco/s/api/bh-ticket

    const eToken = this.getExistedToken();
    const postBody = {
      'at' : eToken
    };

    const options: RequestOptions = {
      path: '/service/api/bh-ticket',
      formParams: {},
      bodyParam: eToken !== null ? postBody : {},
      contentTypes: ['application/json'],
      accepts: ['application/json']
    };

    return this.webscript.post(options);
  }

  getExistedToken() {
    const token = localStorage.getItem('adf_token');
    if (token !== undefined && token !== null && token !== '') {
      return token;
    } else {
      return null;
    }
  }

  setToken(token: string) {
    if (token !== undefined && token !== null && token !== '') {
      localStorage.setItem('adf_token', token);
    } else {
      localStorage.setItem('adf_token', '');
    }
  }

  getLocalTicket() {
    return this.apiService.getInstance().contentClient.getAlfTicket(undefined);
  }

  // Customized  "getContentUrl" OTB API
  getDefaultContentUrl(nodeId: string, attachment?: boolean, ticket?: string): string {
    return this.apiService.getInstance().content.getContentUrl(nodeId, attachment, ticket);
  }

  getContentUrl(nodeId: string, attachment?: boolean, ticket?: string): string {
    return '/api/-default-/public/alfresco/versions/1' + '/nodes/' + nodeId +
        '/content' +
        '?attachment=' + (attachment ? 'true' : 'false');
  }

  bhGetContentUrl(nodeId: string, attachment?: boolean): string {
    return '/service/bh/public/alfresco/versions/1' + '/nodes/' + nodeId +
        '/content' +
        '?attachment=' + (attachment ? 'true' : 'false');
  }

  // Customized  "getRenditionUrl" OTB API
  getDefaultRenditionUrl(nodeId: string, encoding: string, attachment?: boolean, ticket?: string): string {
    return this.apiService.getInstance().content.getRenditionUrl(nodeId, encoding, attachment, ticket);
  }

  getRenditionUrl(nodeId: string, encoding: string, attachment?: boolean, ticket?: string): string {
    return '/api/-default-/public/alfresco/versions/1' + '/nodes/' + nodeId +
        '/renditions/' + encoding + '/content' +
        '?attachment=' + (attachment ? 'true' : 'false');
  }

  bhGetRenditionUrl(nodeId: string, encoding: string, attachment?: boolean): string {
    return '/service/bh/public/alfresco/versions/1' + '/nodes/' + nodeId +
        '/renditions/' + encoding + '/content' +
        '?attachment=' + (attachment ? 'true' : 'false');
  }

  async bhGetAccessToken(): Promise<any> {
    let token = null;
    await this.getAlfTicket().then(
      (r) => {
        // console.log('Ticket Result : ', r);
        if (r && r.at) {
          console.log('Token : ', r.at);
          this.setToken(r.at);
          token = r.at;
        } else {
          console.log('Token nt available');
        }
      },
      (c) => {
        console.error('Get Alf ticket Error : ', c);
      }
    );

    return token;
  }

  async bhGetBlob(url: string, useToken?: boolean): Promise<Blob> {
    this.throwIfNotDefined(url, 'Content URL');

    const contentTypes = ['application/json'];
    const accepts = ['application/octet-stream', 'application/json'];

    let options: RequestOptions = {
      path: url,
      contentTypes: contentTypes,
      accepts: accepts,
      returnType: 'blob'
    };

    if (useToken) {
      const token = await this.bhGetAccessToken();
      const headerParams = {
        'Authorization':  'Bearer ' + token
      };
      options = {
        ...options,
        headerParams: headerParams
      };
    }

    return this.webscript.get(options);
  }

}
