import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable()
export class BhWorkflowService {

  constructor(private router: Router) { }

  showWorkflowHistory(id: string) {
    this.router.navigate(['/workflow', id]);
  }
}
