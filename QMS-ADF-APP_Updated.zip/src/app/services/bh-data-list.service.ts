import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AlfrescoApiService } from '@alfresco/adf-core';
import { BhWebscriptService, RequestOptions } from './bh-webscript.service';

@Injectable()
export class BhDataListService {

  baseUrl = '/service/bh/qms/datalist/valueassistance/bh-qms-documents/';
  productCompany = this.baseUrl + 'Product%20Company/productCompanyProductlineSubProductLineListItem';
  productLine = this.baseUrl + 'Product%20Line/productCompanyProductlineSubProductLineListItem';
  subProductLine = this.baseUrl + 'Sub%20Product%20Line/productCompanyProductlineSubProductLineListItem';
  site = this.baseUrl + 'Site/productCompanyProductlineSubProductLineListItem';
  function = this.baseUrl + 'Function/functionSubFunctionListItem';
  subFunction = this.baseUrl + 'Sub%20Function/functionSubFunctionListItem';
  language = this.baseUrl + 'Language/attributeValueAssistanceListItem';
  documentType = this.baseUrl + 'Document%20Type/productCompanyDependentattributeValueAssistanceListItem';
  process = this.baseUrl + 'Process/processSubProcessListItem';
  subProcess = this.baseUrl + 'Sub%20Process/processSubProcessListItem';
  userRole = this.baseUrl + 'User%20Role/attributeValueAssistanceListItem';
  isoElement = this.baseUrl + 'ISO%20Element/attributeValueAssistanceListItem';
  contentCategory = this.baseUrl + 'Content%20Category/attributeValueAssistanceListItem';

  constructor(
    private webScript: BhWebscriptService
  ) { }

  getFormData<T = any>(formField: string, form: any): Promise<T> {
    const queryParams = {};
    let path = '';
    switch (formField) {
      case 'productCompany':
        path = this.productCompany;
        break;
      case 'productLine':
        path = this.productLine;
        queryParams['productcompany'] = form['productCompany'];
        break;
      case 'subProductLine':
        path = this.subProductLine;
        queryParams['productcompany'] = form['productCompany'];
        if (form['productLine'] !== undefined && form['productLine'] !== null && form['productLine'] !== '') {
          const productLineValue = Array.isArray(form['productLine']) ? form['productLine'].join('~') : form['productLine'];
          queryParams['productline'] = productLineValue;
        } else {
          queryParams['productline'] = '';
        }
        break;
      case 'site':
        path = this.site;
        queryParams['productcompany'] = form['productCompany'];
        if (form['productLine'] !== undefined && form['productLine'] !== null && form['productLine'] !== '') {
          const productLineValue = Array.isArray(form['productLine']) ? form['productLine'].join('~') : form['productLine'];
          queryParams['productline'] = productLineValue;
        } else {
          queryParams['productline'] = '';
        }
        break;
      case 'function':
        path = this.function;
        queryParams['productcompany'] = form['productCompany'];
        break;
      case 'subFunction':
        path = this.subFunction;
        queryParams['productcompany'] = form['productCompany'];
        if (form['function'] !== undefined && form['function'] !== null && form['function'] !== '') {
          const functionValue = Array.isArray(form['function']) ? form['function'].join('~') : form['function'];
          queryParams['function'] = functionValue;
        } else {
          queryParams['function'] = '';
        }
        break;
      case 'language':
        path = this.language;
        break;
      case 'documentType':
        path = this.documentType;
        queryParams['productcompany'] = form['productCompany'] !== undefined ? form['productCompany'] : form;
        break;
      case 'process':
        path = this.process;
        break;
      case 'subProcess':
        path = this.subProcess;
        if (form['process'] !== undefined && form['process'] !== null && form['process'] !== '') {
          const processValue = Array.isArray(form['process']) ? form['process'].join('~') : form['process'];
          queryParams['process'] = processValue;
        } else {
          queryParams['process'] = '';
        }
        break;
      case 'userRole':
        path = this.userRole;
        break;
      case 'isoElement':
        path = this.isoElement;
        break;
      case 'contentCategory':
        path = this.contentCategory;
        break;
    }
    const options: RequestOptions = <RequestOptions>{
      path: path,
      queryParams: queryParams
    };
    /* this.webScript.get(options).then(
      (response) => {
        return response;
      }
    ); */

    return this.webScript.get(options);
  }

  getUserData<T = any>(user: string): Promise<T> {

    return null;
  }

}
