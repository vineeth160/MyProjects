import { TestBed } from '@angular/core/testing';

import { BhWebscriptService } from './bh-webscript.service';

describe('BhWebscriptService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BhWebscriptService = TestBed.get(BhWebscriptService);
    expect(service).toBeTruthy();
  });
});
