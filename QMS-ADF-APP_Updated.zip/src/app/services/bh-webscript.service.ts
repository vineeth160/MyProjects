import { Injectable } from '@angular/core';
import { AlfrescoApiService } from '@alfresco/adf-core';

export interface RequestOptions {
  path: string;
  httpMethod?: string;
  pathParams?: any;
  queryParams?: any;
  headerParams?: any;
  formParams?: any;
  bodyParam?: any;
  contentTypes?: string[];
  accepts?: string[];
  returnType?: any;
  contextRoot?: string;
  responseType?: string;
}

@Injectable()
export class BhWebscriptService {

  allowedMethod: string[] = ['GET', 'POST', 'PUT', 'DELETE'];

  httpMethods = {
    get: 'GET',
    post: 'POST',
    put: 'PUT',
    del: 'DELETE'
  };

  constructor(private apiService: AlfrescoApiService) {}

  post<T = any>(options: RequestOptions): Promise<T> {

    if (!options.formParams || options.formParams.length < 1) {
      throw new Error('Missing param path/url');
    }

    return this.request({
      ...options,
      httpMethod: this.httpMethods.post
    });
    // return this.apiService.getInstance().contentClient.post<T>(options);
  }

  put<T = any>(options: RequestOptions): Promise<T> {
    return this.request({
      ...options,
      httpMethod: this.httpMethods.put
    });
    // return this.apiService.getInstance().contentClient.put<T>(options);
  }

  get<T = any>(options: RequestOptions): Promise<T> {
    return this.request({
      ...options,
      httpMethod: this.httpMethods.get
    });
    // return this.apiService.getInstance().contentClient.get<T>(options);
  }

  delete<T = void>(options: RequestOptions): Promise<T> {
    return this.request({
      ...options,
      httpMethod: this.httpMethods.del
    });
    // return this.apiService.getInstance().contentClient.delete(options);
  }

  errorMessage(param: string, methodName: string) {
      return `Missing param ${param} in ${methodName}`;
  }

  request<T = any>(options: RequestOptions): Promise<T> {

    if (!options.path) {
      throw new Error('Missing param path/url');
    }

    return this.apiService.getInstance().contentClient.request({
      ...options,
      path: options.path,
      httpMethod: options.httpMethod,
      pathParams: options.pathParams || {},
      queryParams: options.queryParams || [],
      headerParams: options.headerParams || {},
      formParams: options.formParams || {},
      bodyParam: options.bodyParam || null,
      contentTypes: options.contentTypes || ['application/json'],
      accepts: options.accepts || ['application/json', 'text/html'],
      returnType: options.returnType || null,
      contextRoot: options.contextRoot || 'alfresco'
    });
  }

  /* executeWebScript<T = any>(httpMethod: string,
                  scriptPath: string,
                  scriptArgs?: any,
                  contextRoot?: string,
                  servicePath?: string,
                  postBody?: any,
                  formParams?: any,
                  contentTypes?: any,
                  accepts?: any): Promise<any> {
    contextRoot = contextRoot || 'alfresco';
    servicePath = servicePath || 'service';
    postBody = postBody || null;

    if (!httpMethod || this.allowedMethod.indexOf(httpMethod) === -1) {
        throw new Error('method allowed value  GET, POST, PUT and DELETE');
    }

    if (!scriptPath) {
        throw new Error('Missing param scriptPath in executeWebScript');
    }

    const pathParams = {};
    const headerParams = {};
    formParams = formParams || {};

    contentTypes = contentTypes || ['application/json'];
    accepts = ['application/json', 'text/html'];

    return this.apiService.getInstance().contentClient.callApi(
        '/' + servicePath + '/' + scriptPath, httpMethod,
        pathParams, scriptArgs, headerParams, formParams, postBody,
        contentTypes, accepts, null, contextRoot
    );
  } */
}
