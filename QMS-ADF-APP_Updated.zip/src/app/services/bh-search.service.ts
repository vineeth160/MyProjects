import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { ResultSetPaging, GenericFacetResponse } from '@alfresco/js-api';
import { Router } from '@angular/router';
import { queryDef } from '@angular/core/src/view';

@Injectable()
export class BhSearchService {

  constructor(private router: Router) { }

  private facetData = new Subject<GenericFacetResponse[]>();
  private facetQuery = new Subject<string>();
  private advancedSearchQuery = new Subject<string>();

  private advancedSearchParams = new Subject<any>();

  getFacetData(): Observable<GenericFacetResponse[]> {
    return this.facetData.asObservable();
  }

  updateFacetData(data: GenericFacetResponse[]) {
    this.facetData.next(data);
  }

  getFacetQuery(): Observable<string> {
    return this.facetQuery.asObservable();
  }

  updateFacetQuery(query: string) {
    this.facetQuery.next(query);
  }

  getAdvancedSearchQuery(): Observable<string> {
    return this.advancedSearchQuery.asObservable();
  }

  updateAdvancedSearchQuery(query: string) {
    this.advancedSearchQuery.next(query);
  }

  showBasicSearch(queryParams: any): void {
    this.router.navigate(['/search'], queryParams);
  }

  showAdvancedSearch(queryParams: any): void {
    this.router.navigate(['/advanced-search'], queryParams);
  }

  showDocumentViewSearch(id, queryParams: any): void {
    this.router.navigate(['/document-view', id], queryParams);
  }

  getAdvancedSearchParams(): Observable<any> {
    return this.advancedSearchParams.asObservable();
  }

  updateAdvancedSearchParams(queryParams: any) {
    this.advancedSearchParams.next(queryParams);
  }

}
