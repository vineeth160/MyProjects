import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.scss']
})
export class LogoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    const currentUrl = localStorage.getItem('currentUrl');
    if (currentUrl !== null && currentUrl !== undefined && currentUrl !== '') {
      localStorage.setItem('previousUrl', currentUrl);
    }
  }

}
