import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhDocumentPropertiesComponent } from './bh-document-properties.component';

describe('BhDocumentPropertiesComponent', () => {
  let component: BhDocumentPropertiesComponent;
  let fixture: ComponentFixture<BhDocumentPropertiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhDocumentPropertiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhDocumentPropertiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
