import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { AppConfigService, NotificationService } from '@alfresco/adf-core';
import { RequestOptions, BhWebscriptService } from 'app/services/bh-webscript.service';
import { BhWorkflowHistoryComponent } from '../bh-tasks/bh-workflow-history/bh-workflow-history.component';

@Component({
  selector: 'app-bh-document-properties',
  templateUrl: './bh-document-properties.component.html',
  styleUrls: ['./bh-document-properties.component.scss']
})
export class BhDocumentPropertiesComponent implements OnInit {

  params;
  resizeValue = 'fullscreen';
  resizeTooltip = 'Maximize';

  nodeId = '';
  attachmentId = '';
  metadata = [];
  properties: any;
  pc = '';
  cc = '';

  loading = false;
  showViewer = false;

  constructor(private dialogRef: MatDialogRef<BhDocumentPropertiesComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private dialog: MatDialog,
              private appConfig: AppConfigService,
              private webscript: BhWebscriptService,
              private notification: NotificationService) { }

  ngOnInit() {
    console.log('properties data : ', this.data);
    this.nodeId = this.data.id;
    this.pc = this.data.properties ? this.data.properties['bhqms:product_company'] : '';
    this.cc = this.data.properties ? this.data.properties['bhqms:content_category'] : '';
    this.metadata = this.appConfig.get('bh-metadata');

    this.getProperties(this.data.id);
  }

  getProperties(id) {
    this.loading = true;
    const nodeRef = 'workspace://SpacesStore/' + id;
    const queryParams = '?nodeRef=' + nodeRef + '&type=' + 'all';
    const options: RequestOptions = {
      path: '/service/getNodeDetails' + queryParams
    };
    this.webscript.get(options).then(
      (r) => {
        this.loading = false;
        if (r && r.data && r.data.properties) {
          this.properties = r.data.properties;
        } else {
          console.log('Unable to get Properties');
        }
      },
      (c) => {
        this.loading = false;
        console.log('Get Properties Error');
      }
    );
  }

  getValue(p) {
    const v = this.properties ? this.properties[p.name] : '';
    if (v !== undefined && v !== null && v !== '') {
      if (p.multiValued) {
        let mv = '';
        if (Array.isArray(v) && v.length > 0) {
          mv = v.join(', ');
        } else {
          mv = v;
        }
        if (p.dataType === 'd:text') {
          return mv;
        } else if (p.dataType === 'd:date') {
          const d = [];
          if (Array.isArray(v) && v.length > 0) {
            v.forEach(
              (i) => {
                const value = i ? this.getDate(i) : '';
                d.push(value);
              }
            );
          }
          return d.length > 0 ? d.join(', ') : '';
        } else if (p.dataType === 'boolean') {
          return mv;
        } else if (p.dataType === 'cm:person' || p.dataType === 'bhdl:hrSystemDataListItem') {
          const u = [];
          if (Array.isArray(v) && v.length > 0) {
            v.forEach(
              (i) => {
                const value = i && i.name ? i.name : '';
                u.push(value);
              }
            );
          }
          return u.length > 0 ? u.join(', ') : '';
        } else if (p.dataType === 'bhqms:iso_qty_manual') {
          const n = [];
          if (Array.isArray(v) && v.length > 0) {
            v.forEach(
              (i) => {
                const value = i && i.name ? i.name : '';
                n.push(value);
              }
            );
          }
          return n.length > 0 ? n.join(', ') : '';
        } else {
          return mv;
        }
      } else {
        if (p.dataType === 'd:date') {
          return this.getDate(v);
        } else if (p.dataType === 'cm:person' || p.dataType === 'bhdl:hrSystemDataListItem') {
          return v ? v.name : '';
        } else if (p.dataType === 'bhqms:iso_qty_manual') {
          return v ? v : '';
        } else if (p.dataType === 'd:link') {
          return this.getId(v);
        } else {
          return v;
        }
      }
    } else {
      return '';
    }
  }

  getDate(td) {
    const d = Date.parse(td);
    return new Date(d).toLocaleDateString();
  }

  getId(v) {
    const i = v.indexOf('activiti$');
    let id = v.substring(i);
    if (id) {
      id = id.replace('activiti$', '');
    }
    return id;
  }

  /* getLink(d) {

    return '<div style="cursor: pointer;" (click)="onPreview(id)">{{d.name}}</div>';
  } */

  onPreview(nodeRef) {
    const id = nodeRef ? nodeRef.replace('workspace://SpacesStore/', '') : '';
    this.attachmentId = id;
    this.showViewer = true;
  }

  onViewerToggle(event) {
    this.showViewer = event;
  }

  onView(p) {
    const id = this.getValue(p);
    const type = p.name;
    if (id !== undefined && id !== null && id !== '') {
      if (type === 'bhqms:workflow_history') {
        console.log('Workflow History Id : ', id);
        const dialogConfig = new MatDialogConfig();

        dialogConfig.disableClose = true;
        dialogConfig.autoFocus = true;
        dialogConfig.minHeight = '550px';
        dialogConfig.height = '84%';
        dialogConfig.maxHeight = '100%';
        dialogConfig.minWidth = '300px';
        dialogConfig.width = '50%';
        dialogConfig.maxWidth = '100%';
        dialogConfig.panelClass = 'workflow-history';
        dialogConfig.data = {
          id: id
        };
        const dialogRef = this.dialog.open(BhWorkflowHistoryComponent, dialogConfig);
        dialogRef.componentInstance.params = {
          maximize: () => {
            dialogRef.updateSize('100%', '100%');
            // return event;
          },
          resize: () => {
            dialogRef.updateSize('50%', '84%');
          }
        };

        dialogRef.afterClosed().subscribe(
          (val) => {
            console.log('Dialog output : ', val);
          }
        );
      }
    } else {
      this.notification.openSnackMessage('Property value not available', 3000);
    }
  }

  close() {
    this.dialogRef.close();
  }

  onResize(event) {
    const s = event.target.innerHTML;
    if (s === 'fullscreen') {
      this.params.maximize(event);
      this.resizeValue = 'fullscreen_exit';
      this.resizeTooltip = 'Minimize';
    } else {
      this.params.resize(event);
      this.resizeValue = 'fullscreen';
      this.resizeTooltip = 'Maximize';
    }
  }

}
