import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhUserInfoComponent } from './bh-user-info.component';

describe('BhUserInfoComponent', () => {
  let component: BhUserInfoComponent;
  let fixture: ComponentFixture<BhUserInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhUserInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhUserInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
