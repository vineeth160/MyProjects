import { Component, OnInit } from '@angular/core';
import {
  EcmUserService,
  BpmUserService,
  IdentityUserService,
  AuthenticationService,
  AlfrescoApiService,
  PeopleContentService,
  AppConfigService,
  NodesApiService} from '@alfresco/adf-core';
import { PersonEntry, Person } from '@alfresco/js-api';

@Component({
  selector: 'app-bh-user-info',
  templateUrl: './bh-user-info.component.html',
  styleUrls: ['./bh-user-info.component.scss']
})
export class BhUserInfoComponent implements OnInit {

  constructor(
    private ecmUserService: EcmUserService,
    private bpmUserService: BpmUserService,
    private identityUserService: IdentityUserService,
    private authService: AuthenticationService,
    private apiService: AlfrescoApiService,
    private appConfig: AppConfigService,
    private peopleService: PeopleContentService,
    private nodeService: NodesApiService) { }

  ngOnInit() {
    try {
      console.log('ECM User : ', this.apiService.getInstance().getEcmUsername());
      if (this.apiService.getInstance().isEcmLoggedIn()) {
        const p = this.peopleService.getCurrentPerson();
        p.toPromise().then(
          (r: PersonEntry) => {
            console.log('Logged In user Details r : ', r);
            if (r && r.entry) {
              const person: Person = r.entry;
              console.log('ECM User Info : ', person);
            }
          },
          (c) => {
            console.log('Logged In user Details c : ', c);
          }
        );
      } else {
        console.log('Identity User Info : ', this.identityUserService.getCurrentUserInfo());
      }
    } catch (e) {
      console.log('ECM User Error : ', e);
    }

    try {
      console.log('Identity User Info : ', this.identityUserService.getCurrentUserInfo());
    } catch (e) {
      console.log('Identity User Error : ', e);
    }

    try {
      console.log('Auth ECM User : ', this.authService.getEcmUsername());
      console.log('Auth BPM User : ', this.authService.getBpmUsername());
    } catch (e) {
      console.log('Auth User Error : ', e);
    }

    try {
      console.log('BPM User : ', this.apiService.getInstance().getBpmUsername());
    } catch (e) {
      console.log('BPM User Error : ', e);
    }

  }

}
