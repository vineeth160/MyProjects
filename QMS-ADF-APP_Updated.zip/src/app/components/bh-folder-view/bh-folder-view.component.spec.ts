import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhFolderViewComponent } from './bh-folder-view.component';

describe('BhFolderViewComponent', () => {
  let component: BhFolderViewComponent;
  let fixture: ComponentFixture<BhFolderViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhFolderViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhFolderViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

