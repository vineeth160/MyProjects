import { Component, OnInit, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Subject } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { AlfrescoApiService, NotificationService, AppConfigService } from '@alfresco/adf-core';
import { RowFilter, ShareDataRow } from '@alfresco/adf-content-services';
import { PreviewService } from '../../services/preview.service';

import { BhStartWorkflowComponent } from '../bh-start-workflow/bh-start-workflow.component';
import { MatDialog, MatDialogConfig  } from '@angular/material';
import { BhDocumentPropertiesComponent } from '../bh-document-properties/bh-document-properties.component';
import { BhInfoDialogComponent } from 'app/dialog/bh-info-dialog/bh-info-dialog.component';
import { RequestOptions, BhWebscriptService } from 'app/services/bh-webscript.service';

import { BhDocumentListComponent } from '../../components/extended/bh-document-list/bh-document-list.component';
import { ResultNode } from '@alfresco/js-api';
import { BhDocumentLinkComponent } from 'app/dialog/bh-document-link/bh-document-link.component';
import { BhApiService } from 'app/services/bh-api.service';

@Component({
  selector: 'app-bh-folder-view',
  templateUrl: './bh-folder-view.component.html',
  styleUrls: ['./bh-folder-view.component.scss']
})
export class BhFolderViewComponent implements OnInit, AfterViewInit {

  showViewer = false;
  documentId: string;
  nodeId = '';
  rootId = '';
  defaultNodeId = '-root-';
  sizes = [ 25, 50, 100];

  rowFilter: RowFilter;
  showFolders = true;
  showDocuments = false;

  bhLoading = false;

  @ViewChild('documentList')
  documentList: BhDocumentListComponent;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private appConfig: AppConfigService,
              private apiService: BhApiService,
              private changeDetector: ChangeDetectorRef,
              private preview: PreviewService,
              private dialog: MatDialog,
              private notificationService: NotificationService,
              private webscript: BhWebscriptService) {

                this.rowFilter = (row: ShareDataRow) => {
                  const node = row.node.entry;

                  if (node && node.isFolder && this.showFolders) {
                    return true;
                  } else if (node && node.isFile && this.showDocuments) {
                    return true;
                  }

                  return false;
                };

              }

  ngOnInit() {

    this.bhLoading = true;

    this.apiService.getNodeInfo('-root-', {
            includeSource: true,
            include: ['path', 'properties', 'association'],
            relativePath: this.appConfig.get('rootFolder')
        })
        .then(node => {
            // console.log(node);
            this.rootId = node.id;
            // this.changeDetector.detectChanges();
        });

    this.route.params.subscribe(params => {
      // console.log("Params : ", params);
      const id = params.nodeId;

      if (id !== null && id !== '' && id !== undefined) {
        this.apiService.getNodeInfo(id).then(
          node => {
            if (node) {
              this.nodeId = id;
              // console.log("nodeId : ", this.nodeId);
              this.changeDetector.detectChanges();
              // return;
            } else {
              this.nodeId = this.defaultNodeId;
              this.changeDetector.detectChanges();
            }
          }
        );
      } else {
        this.apiService.getNodeInfo('-root-', {
            includeSource: true,
            include: ['path', 'properties', 'association'],
            relativePath: this.appConfig.get('rootFolder')
        })
        .then(node => {
            // console.log(node);
            this.nodeId = node.id;
            // this.changeDetector.detectChanges();
        });
      }
    });

  }

  ngAfterViewInit() {
    // console.log(this.documentList);
  }

  onFolderView(entry) {
    /* this.showFolders = true;
    this.showDocuments = false;
    this.changeDetector.detectChanges(); */
    this.preview.showDocumentList(entry.id);
  }

  onDocumentView(entry) {
    /* this.showFolders = false;
    this.showDocuments = true;
    this.changeDetector.detectChanges(); */
    this.preview.showDocumentListView(entry.id);

    /* let id = entry.id;
    let path = entry.path.name.toString();
    path = path.replace('/Company Home', '');
    path = path + '/' + entry.name;
    path = path.replace('SmartFolders', 'SmartFoldersView');
    this.apiService.getNodeInfo('-root-', {
            includeSource: true,
            include: ['path', 'properties'],
            relativePath: path
        })
        .then(node => {
            id = node.id;
            this.preview.showDocumentListView(id);
        }); */

  }

  showPreview(event) {
    const entry = event.value.entry;
    if (entry && entry.isFile) {
      this.preview.showResource(entry.id);
    }
  }

  myCustomAction(event, type) {
    const entry = event.value.entry;
    console.log('document details : ', entry);
    // alert(`Custom document action for ${entry.name}`);
    if (type === 'revision' || type === 'archive') {
      this.checkNode(event, type);
      // this.openStartWorkflowDialog(event, type);
    } else if (type === 'properties') {
      this.openDocumentProperties(entry);
    } else if (type === 'download') {
      this.notificationService.openSnackMessage(`Downloaded file "${entry.name}" `, 2000);
    } else if (type === 'link') {
      this.openDocumentLink('link', entry);
    } else {
      this.notificationService.openSnackMessage(`Custom document action for "${entry.name}" `, 2000);
    }
  }

  checkNode(event, type) {
    const entry = event.value.entry;
    const nodeRef = 'workspace://SpacesStore/' + entry.id;
    const queryParams = '?nodeRef=' + nodeRef + '&type=' + 'all';
    const options: RequestOptions = {
      path: '/service/getNodeDetails' + queryParams
    };
    this.webscript.get(options).then(
      (r) => {
        if (r && r.data && r.data.properties) {
          const p = r.data.properties;
          const hasWorkflow = r.data.hasWorkflow;
          if (hasWorkflow !== null && hasWorkflow !== undefined && hasWorkflow !== '') {
            if (hasWorkflow) {
              this.openInfoDialog(
                'Information',
                true,
                'Workflow can not be Initiated, selected document is already part of a different workflow!');
            } else {
              this.checkSourceAssociation(p, type);
            }
          } else {
            this.checkSourceAssociation(p, type);
          }
        } else {
          this.openInfoDialog('Error', true, 'Unable to retrieve document details, Please try again later');
        }
      },
      (c) => {
        this.openInfoDialog('Error', true, c);
      }
    );
  }

  checkSourceAssociation(p: any, type: string) {
    let entry = {};
    const a = p['bhqms:revision_association'];
    if (a !== null && a !== undefined && a !== '') {
      const data = this.getDocumentData(a);
      const pr = data['bhqms:publish_revision'];
      if (pr === undefined || pr === null || pr === '' || pr === 'None' ) {
        data['bhqms:publish_revision'] = p['bhqms:publish_revision'];
      }
      entry = data;
    } else {
      entry = this.getDocumentData(p);
    }

    console.log('Parsed properties : ', entry);
    this.openStartWorkflowDialog(entry, type);
  }

  getDocumentData(p: any): any {
    const properties = new Object();
    const keys = Object.keys(p);
    keys.forEach(
      (k) => {
        const v = p[k];
        if (v !== null && v !== undefined && v !== '') {
          properties[k] = v;
        }
      });

    return properties;
  }

  openStartWorkflowDialog(entry, type?) {

    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.minHeight = '550px';
    dialogConfig.height = '84%';
    dialogConfig.maxHeight = '100%';
    dialogConfig.minWidth = '300px';
    dialogConfig.width = '50%';
    dialogConfig.maxWidth = '100%';
    dialogConfig.panelClass = 'start-workflow-dialog';
    dialogConfig.data = { requestType: type, node: entry };

    const dialogRef = this.dialog.open(BhStartWorkflowComponent, dialogConfig);

    dialogRef.componentInstance.params = {
      maximize: () => {
        dialogRef.updateSize('100%', '100%');
        // return event;
      },
      resize: () => {
        dialogRef.updateSize('50%', '84%');
      }
    };

    dialogRef.afterClosed().subscribe(
      val => console.log('Start Work flow Dialog output:', val)
    );

  }

  openDocumentProperties(entry) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.minHeight = '550px';
    dialogConfig.height = '84%';
    dialogConfig.maxHeight = '100%';
    dialogConfig.minWidth = '300px';
    dialogConfig.width = '50%';
    dialogConfig.maxWidth = '100%';
    dialogConfig.panelClass = 'start-workflow-dialog';
    dialogConfig.data = entry;

    const dialogRef = this.dialog.open(BhDocumentPropertiesComponent, dialogConfig);
    dialogRef.componentInstance.params = {
      maximize: () => {
        dialogRef.updateSize('100%', '100%');
        // return event;
      },
      resize: () => {
        dialogRef.updateSize('50%', '84%');
      }
    };
  }

  openDocumentLink(type, entry: ResultNode) {
    const dialogRef = this.dialog.open(BhDocumentLinkComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: {
        node : entry,
        type : type
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

  uploadSuccess(event: any) {
    this.notificationService.openSnackMessage('File uploaded');
    this.documentList.reload();
  }

  onPreview(event) {
    const entry = event.value.entry;
    if (entry && entry.isFile) {
      const type = entry.properties ? entry.properties['bhqms:content_category'] : undefined;
      if (type === 'Document') {
        this.documentId = entry.id;
        this.showViewer = true;
      } else if (type === 'URL') {
        this.openDocumentLink('url', entry);
      }
    }
  }

  onViewerToggle(event) {
    this.documentId = null;
    this.showViewer = event;
  }

  openInfoDialog(title, hasTitle, message) {
    const dialogRef = this.dialog.open(BhInfoDialogComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: { title: title, hasTitle: hasTitle, message: message }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

}
