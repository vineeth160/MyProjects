import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bh-task-form',
  templateUrl: './bh-task-form.component.html',
  styleUrls: ['./bh-task-form.component.scss']
})
export class BhTaskFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
