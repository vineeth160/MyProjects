import { Component, OnInit, ChangeDetectorRef, AfterViewInit, AfterViewChecked } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ActivatedRoute, Router } from '@angular/router';

import { MatDialog, MatDialogConfig } from '@angular/material';

import { WfAdminTaskComponent } from '../..//workflow/wf-admin-task/wf-admin-task.component';
import { WfIntakesTaskComponent } from '../../workflow/wf-intakes-task/wf-intakes-task.component';

import { BhWebscriptService, RequestOptions } from '../../../services/bh-webscript.service';

import { Pagination } from '@alfresco/js-api';
import { BehaviorSubject } from 'rxjs';
import { PaginatedComponent, PaginationModel, RequestPaginationModel, AlfrescoApiService } from '@alfresco/adf-core';
import { BhWorkflowService } from 'app/services/bh-workflow.service';

import { BhWorkflowHistoryComponent } from '../bh-workflow-history/bh-workflow-history.component';
import { PreviewService } from 'app/services/preview.service';

export interface Tasks {
  reason: string;
  startDate: string;
  dueDate: string;
  status: string;
  type: string;
  description: string;
  startedBy: string;
}

export interface TasksNew {
  name: string;
  updated: Date;
}

@Component({
  selector: 'app-bh-my-workflows',
  templateUrl: './bh-my-workflows.component.html',
  styleUrls: ['./bh-my-workflows.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class BhMyWorkflowsComponent implements OnInit, AfterViewInit {

  DEFAULT_PAGINATION: Pagination = {
    count: 0,
    hasMoreItems: false,
    maxItems: 10,
    skipCount: 0,
    totalItems: 0
  };
  pagination: PaginationModel;

  isLoading = false;

  selectedView = 'list';

  tasks = [];

  workflowId: string;

  notes: TasksNew[] = [
    {
      name: 'Vacation Itinerary',
      updated: new Date('2/20/16'),
    },
    {
      name: 'Kitchen Remodel',
      updated: new Date('1/18/16'),
    }
  ];

  expandedElement: TasksNew[] | null;

  displayedColumns: string[] = ['icon', 'reason', 'due', 'started', 'status', 'type', 'description', 'startedBy'];

  displayedColumnsShort: string[] = ['icon', 'reason', 'type', 'due'];

  constructor(private router: Router,
    private route: ActivatedRoute,
    private dialog: MatDialog,
    private webscript: BhWebscriptService,
    private workflow: BhWorkflowService,
    private apiService: AlfrescoApiService,
    private changeDetector: ChangeDetectorRef,
    private preview: PreviewService) {}

  ngOnInit() {

    this.pagination = this.DEFAULT_PAGINATION;

    this.loadWorkflows(this.pagination);

    this.route.params.subscribe(params => {
      const view = params.view;
      const id = params.id;
      if (id !== undefined && id !== '' && id !== null) {
        this.workflowId = id;
      } else if (view !== undefined && view !== '' && view !== null) {
          this.selectedView = view;
      } else {
        this.selectedView = 'list';
      }
    });

  }

  ngAfterViewInit() {
    if (this.workflowId !== undefined && this.workflowId !== '' && this.workflowId !== null) {
      setTimeout(() => this.showHistory(this.workflowId));
    }
  }

  loadWorkflows(p: Pagination) {
    this.isLoading = true;
    const options: RequestOptions = {
      path: '/service/api/workflow-instances?',
      queryParams: {
        initiator: this.apiService.getInstance().getEcmUsername(),
        exclude: 'jbpm$wcmwf:*,jbpm$wf:articleapproval,' +
        'activiti$publishWebContent,jbpm$publishWebContent,' +
        'jbpm$inwf:invitation-nominated,jbpm$imwf:invitation-moderated,' +
        'activiti$activitiInvitationModerated,activiti$activitiInvitationNominated,' +
        'activiti$activitiInvitationNominatedAddDirect,activiti$resetPassword,' +
        'activiti$activitiParallelGroupReview,activiti$activitiParallelReview,' +
        'activiti$activitiReview,activiti$activitiReviewPooled,activiti$activitiAdhoc',
        skipCount: p.skipCount,
        maxItems: p.maxItems
      }
    };
    this.tasks = [];
    this.webscript.get(options).then(
      (r) => {
        this.isLoading = false;
        if (r && r.data) {
          this.tasks = r.data;
        }
      },
      (e) => {
        this.isLoading = false;
        console.log('Workflows data error : ', e);
      }
    );

    // OTB API
    try {
      const option: RequestOptions = {
        path: '/api/-default-/public/workflow/versions/1/processes',
        queryParams: {
          skipCount: p.skipCount,
          maxItems: p.maxItems,
          where: '(startUserId=\'' + this.apiService.getInstance().getEcmUsername() + '\')'
        }
      };
      this.webscript.get(option).then(
        (r) => {
          console.log('Result: ', r);
          this.pagination = r.list.pagination;
        },
        (e) => {
          console.log('Error: ', e);
        }
      );
    } catch (e) {
      console.log('Exception: ', e);
    }
  }

  onShowHistory(id: string) {
    this.workflow.showWorkflowHistory(id);
  }

  showHistory(id) {
    console.log('Workflow History Id : ', id);
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.minHeight = '550px';
    dialogConfig.height = '84%';
    dialogConfig.maxHeight = '100%';
    dialogConfig.minWidth = '300px';
    dialogConfig.width = '50%';
    dialogConfig.maxWidth = '100%';
    dialogConfig.panelClass = 'workflow-history';
    dialogConfig.data = {
      id: this.workflowId
     };
    const dialogRef = this.dialog.open(BhWorkflowHistoryComponent, dialogConfig);
    dialogRef.componentInstance.params = {
      maximize: () => {
        dialogRef.updateSize('100%', '100%');
        // return event;
      },
      resize: () => {
        dialogRef.updateSize('50%', '84%');
      }
    };

    dialogRef.afterClosed().subscribe(
      (val) => {
        console.log('Dialog output : ', val);
        if (val) {
          // this.loadWorkflows(this.pagination);
          this.preview.showWorkflowsList('');
        }
      }
    );
  }

  updatePagination(params: RequestPaginationModel) {
    console.log('pagination params : ', params);
  }

  onNextPage(event) {
    console.log('onNextPage event : ', event);
    this.loadWorkflows(event);
  }

  onPreviousPage(event) {
    console.log('onPreviousPage event : ', event);
    this.loadWorkflows(event);
  }

  onChangePageSize(event) {
    console.log('onChangePageSize event : ', event);
    this.loadWorkflows(event);
  }

  onChangePageNumber(event) {
    console.log('onChangePageNumber event : ', event);
    this.loadWorkflows(event);
  }

}
