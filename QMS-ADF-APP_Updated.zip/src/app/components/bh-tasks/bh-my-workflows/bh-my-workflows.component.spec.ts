import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhMyWorkflowsComponent } from './bh-my-workflows.component';

describe('BhMyWorkflowsComponent', () => {
  let component: BhMyWorkflowsComponent;
  let fixture: ComponentFixture<BhMyWorkflowsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhMyWorkflowsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhMyWorkflowsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
