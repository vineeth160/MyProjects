import { Component, OnInit, Inject, ChangeDetectorRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {FormBuilder, Validators, FormGroup} from '@angular/forms';
import { AlfrescoApiService, AppConfigService, NotificationService } from '@alfresco/adf-core';
import { HttpClient } from '@angular/common/http';
import { MatDialog, MatDialogConfig  } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { BhWebscriptService, RequestOptions } from '../../../services/bh-webscript.service';
import { ConfirmDialogComponent } from '@alfresco/adf-content-services';
import { BhInfoDialogComponent } from '../../../dialog/bh-info-dialog/bh-info-dialog.component';
import { BhApiService } from 'app/services/bh-api.service';

@Component({
  selector: 'app-intakes-task-form',
  templateUrl: './intakes-task-form.component.html',
  styleUrls: ['./intakes-task-form.component.scss']
})
export class IntakesTaskFormComponent implements OnInit {

  form: FormGroup;
  node: any;
  nodeId: string;

  title: string;
  requestType: string;
  reasonLabel: string;
  submitLabel: string;
  params;
  resizeValue = 'fullscreen';
  resizeTooltip = 'Maximize';

  documentName = '';
  description = '(None)';
  modifiedOn: string;

  showViewer = false;

  validationMessages = {
    intakesComments: {
      required: 'Value is required',
      minLength: 'Value must be at least 5 characters long'
    },
    workflowActions: {
      required: 'Action is required'
    }
  };

  constructor(private fb: FormBuilder,
              private apiService: BhApiService,
              private appConfig: AppConfigService,
              private http: HttpClient,
              private dialog: MatDialog,
              private router: Router,
              private route: ActivatedRoute,
              private webscript: BhWebscriptService
              ) {

                this.form = fb.group({
                  documentName: [''],
                  documentReferenceNumber: [''],
                  documentRevisionNumber: [''],
                  reasonForRevision: [''],
                  intakesComments: ['', [Validators.required, Validators.minLength(5)]],
                  workflowActions: ['', Validators.required]
                });

               }

  ngOnInit() {
    this.title = 'Workflow Intakes Task | QMS Document Request';
    this.requestType = '';
    this.reasonLabel = 'Reason for Revision';
    this.submitLabel = 'Submit';
    let taskId = '';

    this.route.params.subscribe(params => {
      taskId = params.taskId;
      if (taskId !== null && taskId !== '' && taskId !== undefined) {
        const options: RequestOptions = <RequestOptions>{
          path: '/service/api/task-instances/activiti$' + taskId
        };
        this.webscript.get(options).then(
          (wp) => {
            let nodeRef: string = wp.data.properties['bpm_package'];
            nodeRef = nodeRef.substring(nodeRef.lastIndexOf('/') + 1 );
            const reason = wp.data.properties['bpm_description'];
            this.apiService.getNodeChildren(nodeRef).then(
              (r) => {
                console.log('child result : ', r.list.entries);
                if ( r.list.entries.length > 0 ) {
                  const id = r.list.entries[0].entry.id;
                  console.log('child id : ', id);
                  this.nodeId = id;
                  const opts = {
                    include: ['path', 'properties', 'allowableOperations', 'permissions', 'aspectNames', 'association'],
                    includeSource: true
                  };
                  this.apiService.getNodeInfo(id, opts).then(
                    (result) => {
                      console.log('node data : ', result);
                      this.node = result;
                      this.form.controls.documentName.setValue(result.name);
                      this.form.controls.documentReferenceNumber.setValue(result.properties['bhqms:reference']);
                      this.form.controls.documentRevisionNumber.setValue(result.properties['cm:versionLabel']);
                      const docReason = result.properties['bhqms:reason_for_revision'];
                      this.form.controls.reasonForRevision.setValue(docReason ? docReason : reason);
                      this.documentName = result.name;
                      this.description = result.properties['cm:description'];
                      this.modifiedOn = result.modifiedAt.toLocaleDateString();
                    }
                  );
                }
              }
            );
          },
          (e) => {
            this.openInfoDialog('Error', false, e.message);
          }
        );
      } else {
        this.openInfoDialog('Error', false, 'Task Id not available, Please check the url once');
      }
    });
  }

  submitForm() {
    if (this.form.invalid || this.form.pending) {
      this.openInfoDialog(null, false, 'Fill the form with all mandatory(*) values to submit');
    } else {
      this.submitIntakesForm();
    }
  }

  submitIntakesForm() {
    const f = this.form.value;
    const self = this;
    console.log('Intakes Task Form Value : ', f);
    // TO DO: Updated Task
    this.openInfoDialog('Response', false, 'Not Integrated Yet, Come back later...');
  }

  close() {
    if ( this.form.dirty ) {
      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        data: {
            title: 'Confirm',
            message: `Are you sure you want to discard the changes?`
        },
        minWidth: '250px'
      });

      dialogRef.afterClosed().subscribe((result) => {
          if (result === true) {
            // this.dialogRef.close();
          }
      });
    } else {
      // this.dialogRef.close();
    }
  }

  onResize(event) {
    const s = event.target.innerHTML;
    if (s === 'fullscreen') {
      this.params.maximize(event);
      this.resizeValue = 'fullscreen_exit';
      this.resizeTooltip = 'Minimize';
    } else {
      this.params.resize(event);
      this.resizeValue = 'fullscreen';
      this.resizeTooltip = 'Maximize';
    }
  }

  onPreview() {
    this.showViewer = true;
  }

  fieldValidation( field: string ): string {
    // console.log(field);
    if (this.form.get(field).hasError('required')) {
      // console.log('Error : ', this.validationMessages[field].required);
      return this.validationMessages[field].required;
    } else if (this.form.get(field).hasError('minlength')) {
      return this.validationMessages[field].minLength;
    } else if (this.form.get(field).hasError('isDuplicate')) {
      return this.validationMessages[field].isDuplicate;
    }
    return null;
  }

  openInfoDialog(title, hasTitle, message) {
    const dialogRef = this.dialog.open(BhInfoDialogComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: {title: title, hasTitle: hasTitle, message: message}
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

}
