import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntakesTaskFormComponent } from './intakes-task-form.component';

describe('IntakesTaskFormComponent', () => {
  let component: IntakesTaskFormComponent;
  let fixture: ComponentFixture<IntakesTaskFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntakesTaskFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntakesTaskFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
