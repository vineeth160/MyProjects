import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhTasksComponent } from './bh-tasks.component';

describe('BhTasksComponent', () => {
  let component: BhTasksComponent;
  let fixture: ComponentFixture<BhTasksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhTasksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhTasksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
