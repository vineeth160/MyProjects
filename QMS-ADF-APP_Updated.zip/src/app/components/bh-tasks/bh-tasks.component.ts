import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ActivatedRoute, Router, NavigationEnd, Params } from '@angular/router';

import { MatDialog, MatDialogConfig } from '@angular/material';

import { BhStartWorkflowComponent } from '../bh-start-workflow/bh-start-workflow.component';
import { WfIntakesTaskComponent } from '../workflow/wf-intakes-task/wf-intakes-task.component';
import { WfSmeTaskComponent } from '../workflow/wf-sme-task/wf-sme-task.component';
import { WfAdminTaskComponent } from '../workflow/wf-admin-task/wf-admin-task.component';
import { WfReviewerTaskComponent } from '../workflow/wf-reviewer-task/wf-reviewer-task.component';
import { WfApproverTaskComponent } from '../workflow/wf-approver-task/wf-approver-task.component';
import { WfPublisherTaskComponent } from '../workflow/wf-publisher-task/wf-publisher-task.component';

import { WfAdrAdminTaskComponent } from '../workflow/wf-adr-admin-task/wf-adr-admin-task.component';
import { WfAdrApproverTaskComponent } from '../workflow/wf-adr-approver-task/wf-adr-approver-task.component';
import { WfAdrIntakesTaskComponent } from '../workflow/wf-adr-intakes-task/wf-adr-intakes-task.component';

import { BhWebscriptService, RequestOptions } from '../../services/bh-webscript.service';

import { Pagination, TaskQueryRepresentation, PaginatedList, PersonEntry, Person, QueryBody, RequestQuery } from '@alfresco/js-api';
import { BehaviorSubject, Subscription } from 'rxjs';
import {
  PaginatedComponent,
  PaginationModel,
  RequestPaginationModel,
  AlfrescoApiService,
  PeopleContentService,
  IdentityUserModel,
  IdentityUserService,
  SearchService } from '@alfresco/adf-core';
import { filter } from 'rxjs/operators';
import { PreviewService } from 'app/services/preview.service';
import { BhInfoDialogComponent } from 'app/dialog/bh-info-dialog/bh-info-dialog.component';
/* export declare class RequestPaginationModel {
  skipCount?: number;
  maxItems?: number;
  constructor(input?: any);
} */

export interface Tasks {
  reason: string;
  startDate: string;
  dueDate: string;
  status: string;
  type: string;
  description: string;
  startedBy: string;
}

export interface TasksNew {
  name: string;
  updated: Date;
}

export interface Entry {
  activityDefinitionId: string;
  assignee: string;
  description: string;
  formResourceKey: string;
  id: string;
  name: string;
  priority: any;
  processDefinitionId: string;
  processId: string;
  startedAt: string;
  state: string;
}

interface User {
  email?: string;
  firstName?: string;
  lastName?: string;
  id?: string;
}

@Component({
  selector: 'app-bh-tasks',
  templateUrl: './bh-tasks.component.html',
  styleUrls: ['./bh-tasks.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class BhTasksComponent implements OnInit, OnDestroy {
  DEFAULT_PAGINATION: Pagination = {
    count: 0,
    hasMoreItems: false,
    maxItems: 10,
    skipCount: 0,
    totalItems: 0
  };
  pagination: PaginationModel;

  isLoading = false;

  selectedView = 'all';

  user: User = {
    email: '',
    firstName: '',
    lastName: '',
    id: ''
  };

  tasks = [];

  notes: TasksNew[] = [
    {
      name: 'Vacation Itinerary',
      updated: new Date('2/20/16'),
    },
    {
      name: 'Kitchen Remodel',
      updated: new Date('1/18/16'),
    }
  ];

  expandedElement: TasksNew[] | null;

  displayedColumns: string[] = ['icon', 'reason', 'due', 'started', 'status', 'type', 'description', 'startedBy'];

  displayedColumnsShort: string[] = ['icon', 'reason', 'type', 'due'];

  protected subscriptions: Subscription[] = [];

  constructor(private router: Router,
    private route: ActivatedRoute,
    private dialog: MatDialog,
    private webscript: BhWebscriptService,
    private apiService: AlfrescoApiService,
    private peopleService: PeopleContentService,
    private identityUserService: IdentityUserService,
    private searchService: SearchService,
    private preview: PreviewService) { }

  ngOnInit() {
    this.pagination = this.DEFAULT_PAGINATION;
    this.subscriptions.push(
      this.router.events.pipe(
        filter(event => event instanceof NavigationEnd)
      ).subscribe((event: NavigationEnd) => {
        this.updateRouteChanges();
      })
    );

    this.updateRouteChanges();

    this.getUserDetails();

  }

  ngOnDestroy() {
    this.subscriptions.forEach(subscription => subscription.unsubscribe());
    this.subscriptions = [];
  }

  updateRouteChanges() {
    if (this.route) {
      const isTask = this.router.url.indexOf('/task-details') === 0;
      const isTasks = this.router.url.indexOf('/tasks') === 0;

      if (isTask) {
        this.selectedView = 'list';
        this.route.queryParams.forEach((params: Params) => {
          const taskId = params.hasOwnProperty('taskId') ? params['taskId'] : null;
          if (taskId !== null && taskId !== '' && taskId !== undefined) {
            setTimeout(() => this.getTaskDetails('activiti$' + taskId));
          } else {
            this.openInfoDialog('Error', true, 'Task Id not available, Please check the Task URL');
          }
        });
      }

      if (isTasks) {
        this.route.params.subscribe(params => {
          const view = params.view;
          if (view !== undefined && view !== '' && view !== null) {
            this.selectedView = view;
          } else {
            this.selectedView = 'list';
          }
        });
      }
    }
  }

  getUserDetails() {
    try {
      if (this.apiService.getInstance().isEcmLoggedIn()) {
        const p = this.peopleService.getCurrentPerson();
        p.toPromise().then(
          (r: PersonEntry) => {
            console.log('Logged In user Details r : ', r);
            if (r && r.entry) {
              const person: Person = r.entry;
              const email = person.email;
              if (email !== undefined && email !== null && email !== '') {
                this.user.email = email;
                const fn = person.firstName;
                this.user.firstName = fn !== undefined && fn !== null ? fn : '';
                const ln = person.lastName;
                this.user.lastName = ln !== undefined && ln !== null ? ln : '';
                const id = person.id;
                this.user.id = id !== undefined && id !== null ? id : '';
                this.loadTasks(this.pagination);
              } else {
                this.setIdentityUser();
              }
            } else {
              this.setIdentityUser();
            }
          },
          (c) => {
            console.log('ECM user Details Error : ', c);
            this.openInfoDialog(
              'Error',
              true,
              'Unable to retrieve user details from ECM' +
              ' Please contact Administrator');
          }
        );
      } else {
        this.setIdentityUser();
      }
    } catch (e) {
      console.log('ECM/Identity User Error : ', e);
      this.openInfoDialog(
        'Error',
        true,
        'Unable to retrieve user details from ECM' +
        ' Please contact Administrator');
    }
  }

  setIdentityUser() {
    const person: IdentityUserModel = this.identityUserService.getCurrentUserInfo();
    const email = person.email;
    if (email !== undefined && email !== null && email !== '') {
      this.user.email = email;
      const fn = person.firstName;
      this.user.firstName = fn !== undefined && fn !== null ? fn : '';
      const ln = person.lastName;
      this.user.lastName = ln !== undefined && ln !== null ? ln : '';
      const id = person.username;
      this.user.id = id !== undefined && id !== null ? id : '';
      this.loadTasks(this.pagination);
    } else {
      this.openInfoDialog(
        'Error',
        true,
        'Unable to retrieve user details from IDS,' +
        ' Please contact Administrator');
    }
  }

  getDatalistUser() {
    const person: IdentityUserModel = this.identityUserService.getCurrentUserInfo();
    const q = 'TYPE:"bhdl:hrSystemDataListItem"'
              + ' AND @bhdl:employee_status:"Active"'
              + ' AND @bhdl:is_employee_active:true'
              + ' AND @bhdl:employee_email_id:"' + person.email + '"';
              // + ' AND @bhdl:employee_first_name:"' + person.firstName + '"'
              // + ' AND @bhdl:employee_last_name:"' + person.lastName + '"';

    const queryBody: QueryBody = {
      query: new RequestQuery({
        language: 'afts',
        query: q
      }),
      include: ['path', 'properties', 'allowableOperations', 'permissions', 'aspectNames', 'association']
    };

    this.searchService.searchByQueryBody(queryBody).toPromise().then(
      r => {
        if (r && r.list && r.list.entries && r.list.entries.length > 0) {
          const entry = r.list.entries[0].entry;
          console.log('data list user entry : ', entry);
          this.user.email = entry.properties['bhdl:employee_email_id'];
          this.user.firstName = entry.properties['bhdl:employee_first_name'];
          this.user.lastName = entry.properties['bhdl:employee_last_name'];
          this.user.id = entry.properties['bhdl:employee_sso'];
          this.loadTasks(this.pagination);
        } else {
          console.log('User Details Not available');
        }
      }
    );

  }

  loadTasks(p: Pagination) {
    this.isLoading = true;
    /* const options: RequestOptions = {
      path: '/service/api/task-instances?',
      queryParams: {
        authority: this.apiService.getInstance().getEcmUsername(),
        properties: 'bpm_priority,bpm_status,bpm_dueDate,bpm_description',
        exclude: 'wcmwf:*',
        skipCount: p.skipCount,
        maxItems: p.maxItems
      }
    }; */
    const options: RequestOptions = {
      path: '/service/api/bh-tasks',
      queryParams: {
        taskUser: this.user.email
      }
    };
    this.webscript.get(options).then(
      (r) => {
        this.isLoading = false;
        if (r && r.data) {
          this.tasks = r.data;
        }
      },
      (e) => {
        this.isLoading = false;
        console.log('Error : ', e);
      }
    );

    // OTB API
    /* try {
      const option: RequestOptions = {
        path: '/api/-default-/public/workflow/versions/1/tasks',
        queryParams: {
          skipCount: p.skipCount,
          maxItems: p.maxItems,
          where: '(assignee=\'' + this.apiService.getInstance().getEcmUsername() + '\')'
        }
      };
      this.webscript.get(option).then(
        (r: PaginatedList<Entry>) => {
          console.log('Result: ', r);
          this.pagination = r.list.pagination;
        },
        (e) => {
          console.log('Error: ', e);
        }
      );
    } catch (e) {
      console.log('Exception: ', e);
    } */
  }

  getTaskDetails(taskId: string) {
    const options: RequestOptions = <RequestOptions>{
      path: '/service/api/bh-task-instances/' + taskId
    };
    const tId = taskId.replace('activiti$', '');
    this.webscript.get(options).then(
      (wp) => {
        if ((wp !== undefined && wp !== null) && wp.data) {
          const hrMail = wp.data && wp.data.properties ? wp.data.properties['bhwf_hr_taskowner_mail'] : '';
          const userMail = this.user.email ? this.user.email : '';
          if (hrMail.toLowerCase() === userMail.toLowerCase()) {
            this.onClickTask(wp.data);
          } else {
            this.openInfoDialog('Error', true, 'You don\'t have permissions to access this task --> Task Id : ' + tId);
          }
        } else {
          this.openInfoDialog('Error', true, 'Task details not available --> Task Id : ' + tId);
        }
      },
      (c) => {
        console.log(c);
        this.openInfoDialog('Error', true, 'Unable to get task details --> Task Id : ' + tId);
      }
    );
  }

  onClickTask(t: any) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.minHeight = '550px';
    dialogConfig.height = '84%';
    dialogConfig.maxHeight = '100%';
    dialogConfig.minWidth = '300px';
    dialogConfig.width = '50%';
    dialogConfig.maxWidth = '100%';
    dialogConfig.panelClass = 'start-workflow-dialog';
    dialogConfig.data = {
      requestType: t.properties['bhwf_bh_request_type'],
      revisionNumber: t.properties['bhwf_bh_temp_revision'],
      id: t.id,
      workflowId: t.workflowInstance.id,
      node: t.workflowInstance.package,
      assignees: t.assignees,
      comments: t.comments,
      intakesComments: ''
    };

    let dialogRef = null;
    const type = t.name.toLowerCase();
    if (type === 'bhwf:submittertask') {
      dialogConfig.data.requestType = 'submitter';
      dialogConfig.data.rType = t.properties['bhwf_bh_request_type'];
      dialogRef = this.dialog.open(BhStartWorkflowComponent, dialogConfig);
    } else if (type === 'bhwf:intakestask') {
      dialogRef = this.dialog.open(WfIntakesTaskComponent, dialogConfig);
    } else if (type === 'bhwf:smetask') {
      dialogRef = this.dialog.open(WfSmeTaskComponent, dialogConfig);
    } else if (type === 'bhwf:admintask') {
      dialogRef = this.dialog.open(WfAdminTaskComponent, dialogConfig);
    } else if ( type === 'bhwf:reviewertask' ) {
      dialogRef = this.dialog.open(WfReviewerTaskComponent, dialogConfig);
    } else if ( type === 'bhwf:approvertask' ) {
      dialogRef = this.dialog.open(WfApproverTaskComponent, dialogConfig);
    } else if ( type === 'bhwf:publishertask' ) {
      dialogRef = this.dialog.open(WfPublisherTaskComponent, dialogConfig);
    } else if (type === 'bhwf:archivaltask') {
      dialogRef = this.dialog.open(WfAdrIntakesTaskComponent, dialogConfig);
    } else if (type === 'bhwf:archivaladmintask') {
      dialogRef = this.dialog.open(WfAdrAdminTaskComponent, dialogConfig);
    } else if (type === 'bhwf:archivalapprovertask') {
      dialogRef = this.dialog.open(WfAdrApproverTaskComponent, dialogConfig);
    }

    dialogRef.componentInstance.params = {
      maximize: () => {
        dialogRef.updateSize('100%', '100%');
        // return event;
      },
      resize: () => {
        dialogRef.updateSize('50%', '84%');
      }
    };

    dialogRef.afterClosed().subscribe(
      (val) => {
        console.log('Dialog output : ', val);
        if (val) {
          this.loadTasks(this.pagination);
          this.preview.showTasksList('');
        }
      }
    );
  }

  updatePagination(params: RequestPaginationModel) {
    console.log('pagination params : ', params);
  }

  onNextPage(event) {
    console.log('onNextPage event : ', event);
    this.loadTasks(event);
  }

  onPreviousPage(event) {
    console.log('onPreviousPage event : ', event);
    this.loadTasks(event);
  }

  onChangePageSize(event) {
    console.log('onChangePageSize event : ', event);
    this.loadTasks(event);
  }

  onChangePageNumber(event) {
    console.log('onChangePageNumber event : ', event);
    this.loadTasks(event);
  }

  openInfoDialog(title, hasTitle, message) {
    const dialogRef = this.dialog.open(BhInfoDialogComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: { title: title, hasTitle: hasTitle, message: message }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

}
