import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { RequestOptions, BhWebscriptService } from 'app/services/bh-webscript.service';
import { BhInfoDialogComponent } from 'app/dialog/bh-info-dialog/bh-info-dialog.component';
import { AlfrescoApiService } from '@alfresco/adf-core';
import { BhApiService } from 'app/services/bh-api.service';
import { BhDocumentLinkComponent } from 'app/dialog/bh-document-link/bh-document-link.component';

export interface TasksHistory {
  type: string;
  user: string;
  date: string;
  status: string;
  comment: string;
}

@Component({
  selector: 'app-bh-workflow-history',
  templateUrl: './bh-workflow-history.component.html',
  styleUrls: ['./bh-workflow-history.component.scss']
})
export class BhWorkflowHistoryComponent implements OnInit {

  params;
  title = 'Workflow History';
  resizeValue = 'fullscreen';
  resizeTooltip = 'Maximize';

  workflowId: string;
  workflowData: any;
  documentData: any;
  nodeId: string;
  showViewer = false;

  currentTasks: TasksHistory[] = [];

  tasksHistory: TasksHistory[] = [];

  ctColumnsNames: String[] = ['Type', 'Assigned To', 'Due Date', 'Status'];
  ctColumns: String[] = ['type', 'user', 'date', 'status'];
  htColumns: String[] = ['type', 'user', 'date', 'status', 'comment'];

  constructor(private dialog: MatDialog,
    private dialogRef: MatDialogRef<BhWorkflowHistoryComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private webscript: BhWebscriptService,
    private apiService: BhApiService) { }

  ngOnInit() {
    this.workflowId = this.data.id;
    this.getWorkflowDetails();
  }

  getWorkflowDetails() {
    this.webscript.get(this.getRequestOptions()).then(
      (r) => {
        console.log('Response : ', r);
        this.workflowData = r.data;
        this.updateTasksData(r.data.tasks);
        this.getDocumentDetails(r.data.package);
        // this.dialogRef.close(true);
      },
      (e) => {
        console.log('Error : ', e);
        this.openInfoDialog('Error', true, e);
      }
    );
  }

  updateTasksData(tasks: Array<any>) {
    this.currentTasks = [];
    this.tasksHistory = [];
    tasks.forEach((task: any) => {
      if (task.state === 'IN_PROGRESS') {
        const taskDetails: TasksHistory = <TasksHistory>{};
        taskDetails.type = task.title;
        const hrOwner = task.properties.bhwf_hr_taskowner_name;
        const hrMail = task.properties.bhwf_hr_taskowner_mail;
        if (hrOwner !== undefined && hrOwner !== null && hrOwner !== '') {
          taskDetails.user = hrOwner;
        } else if (task.owner !== undefined && task.owner !== null && task.owner.userName) {
          taskDetails.user = task.owner.firstName + ' ' + task.owner.lastName;
        } else if (hrMail !== undefined && hrMail !== null && hrMail !== '') {
          taskDetails.user = hrMail;
        } else {
          taskDetails.user = '(None)';
        }

        const date = task.properties.bpm_dueDate;
        if (date !== undefined && date !== null && date !== '') {
          taskDetails.date = this.parseDate(date);
        } else {
          taskDetails.date = '(None)';
        }

        const status = task.properties.bpm_status;
        if (status !== undefined && status !== null && status !== '') {
          taskDetails.status = status;
        } else {
          taskDetails.status = '(None)';
        }

        this.currentTasks.push(taskDetails);
      } else if (task.state === 'COMPLETED') {
        const taskDetails: TasksHistory = <TasksHistory>{};
        taskDetails.type = task.title;

        if (taskDetails.type === 'Workflow Submitter Task') {
          const fName = task.properties.wfSubmitterFirstName;
          const lName = task.properties.wfSubmitterLastName;
          taskDetails.user = fName && lName ? lName + ', ' + fName : this.getWorkflowHistoryTaskUser(task);
        } else {
          taskDetails.user = this.getWorkflowHistoryTaskUser(task);
        }

        const date = task.properties.bpm_completionDate;
        if (date !== undefined && date !== null && date !== '') {
          taskDetails.date = this.parseDate(date);
        } else {
          taskDetails.date = '(None)';
        }

        const status = task.outcome;
        if (status !== undefined && status !== null && status !== '') {
          taskDetails.status = status;
        } else {
          taskDetails.status = '(None)';
        }

        const reason = task.properties.bhwf_bh_reason_for_revision;
        const comment = task.properties.bpm_comment;
        if (taskDetails.type === 'Workflow Submitter Task') {
          taskDetails.comment = reason ? reason : (comment ? comment : '(None)');
        } else {
          if (comment !== undefined && comment !== null && comment !== '') {
            taskDetails.comment = comment;
          } else {
            taskDetails.comment = '(None)';
          }
        }

        this.tasksHistory.push(taskDetails);
      }
    });

    if (this.tasksHistory.length > 0) {
      this.tasksHistory.sort(function(a, b) {
        const d1 = new Date(a.date);
        const d2 = new Date(b.date);
        return d2.valueOf() - d1.valueOf();
      });
    }
  }

  getWorkflowHistoryTaskUser(task: any): string {
    let user = '(None)';
    const hrOwner = task.properties.bhwf_hr_taskowner_name;
    const hrMail = task.properties.bhwf_hr_taskowner_mail;

    if (hrOwner !== undefined && hrOwner !== null && hrOwner !== '') {
      user = hrOwner;
    } else if (task.owner !== undefined && task.owner !== null && task.owner.userName) {
      user = task.owner.firstName + ' ' + task.owner.lastName;
    } else if (hrMail !== undefined && hrMail !== null && hrMail !== '') {
      user = hrMail;
    }

    return user;
  }

  getRequestOptions(): RequestOptions {
    return {
      path: '/service/api/bh-workflow-instances/activiti$' + this.workflowId + '?includeTasks=true'
    };
  }

  getDocumentDetails(node: string) {
    const n = node.substring(node.lastIndexOf('/') + 1 );
    // Task Package and Properties API call
    this.apiService.getNodeChildren(n).then(
      (r) => {
        console.log('child result : ', r.list.entries);
        if ( r.list.entries.length > 0 ) {
          const id = r.list.entries[0].entry.id;
          console.log('child id : ', id);
          const opts = {
            include: ['path', 'properties', 'allowableOperations', 'permissions', 'aspectNames', 'association'],
            includeSource: true
          };
          this.apiService.getNodeInfo(id, opts).then(
            (result) => {
              console.log('node data : ', result);
              this.documentData = result;
              this.nodeId = id;
            }
          );
        }
      }
    );
  }

  onResize(event) {
    const s = event.target.innerHTML;
    if (s === 'fullscreen') {
      this.params.maximize(event);
      this.resizeValue = 'fullscreen_exit';
      this.resizeTooltip = 'Minimize';
    } else {
      this.params.resize(event);
      this.resizeValue = 'fullscreen';
      this.resizeTooltip = 'Maximize';
    }
  }

  close() {
    this.dialogRef.close(true);
  }

  openInfoDialog(title, hasTitle, message) {
    const dialogRef = this.dialog.open(BhInfoDialogComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: { title: title, hasTitle: hasTitle, message: message }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

  onPreview(entry: any) {
    if (entry && entry.isFile) {
      const type = entry.properties ? entry.properties['bhqms:content_category'] : undefined;
      if (type === 'Document') {
        this.nodeId = entry.id;
        this.showViewer = true;
      } else if (type === 'URL') {
        this.openDocumentLink('url', entry);
      }
    }
  }

  onViewerToggle(event) {
    // this.nodeId = null;
    this.showViewer = event;
  }

  openDocumentLink(type: string, entry: any) {
    const dialogRef = this.dialog.open(BhDocumentLinkComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: {
        node : entry,
        type : type
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

  parseDate(v: string): any {
    const d = new Date(v);
    const date = this.formatDate(d);
    return v ? date : v;
  }

  formatDate(date) {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    let dayOfMonth = date.getDate();
    const month =  months[date.getMonth()];
    const year = date.getFullYear();
    const day = days[date.getDay()];
    let hour = date.getHours();
    let minutes = date.getMinutes();
    let seconds = date.getSeconds();

    // formatting
    // year = year.toString().slice(-2);
    // month = month < 10 ? '0' + month : month;
    dayOfMonth = dayOfMonth < 10 ? '0' + dayOfMonth : dayOfMonth;
    hour = hour < 10 ? '0' + hour : hour;
    minutes = minutes < 10 ? '0' + minutes : minutes;
    seconds = seconds < 10 ? '0' + seconds : seconds;

    return day + ' ' + dayOfMonth + ' ' + month + ' ' + year + ' ' + hour + ':' + minutes + ':' + seconds;
  }

}
