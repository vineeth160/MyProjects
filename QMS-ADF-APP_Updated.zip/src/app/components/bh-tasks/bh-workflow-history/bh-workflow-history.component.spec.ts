import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhWorkflowHistoryComponent } from './bh-workflow-history.component';

describe('BhWorkflowHistoryComponent', () => {
  let component: BhWorkflowHistoryComponent;
  let fixture: ComponentFixture<BhWorkflowHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhWorkflowHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhWorkflowHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
