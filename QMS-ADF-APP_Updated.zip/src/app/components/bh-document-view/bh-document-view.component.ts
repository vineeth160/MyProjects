import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Subject, Subscription, Observable, of } from 'rxjs';
import { ActivatedRoute, Router, Params, NavigationEnd } from '@angular/router';
import { AlfrescoApiService, NotificationService, TranslationService, AppConfigService } from '@alfresco/adf-core';
import { BreadcrumbComponent } from '@alfresco/adf-content-services';
import { PreviewService } from '../../services/preview.service';

import { BhStartWorkflowComponent } from '../bh-start-workflow/bh-start-workflow.component';
import { MatDialog, MatDialogConfig, MatSelect, MatOption  } from '@angular/material';
import { BhDocumentPropertiesComponent } from '../bh-document-properties/bh-document-properties.component';
import { ResultSetPaging, PathElement, Pagination, ResultNode } from '@alfresco/js-api';

import { BhSearchService } from '../../services/bh-search.service';
import { Moment } from 'moment';
import { filter } from 'rxjs/operators';
import { RequestOptions, BhWebscriptService } from 'app/services/bh-webscript.service';
import { BhInfoDialogComponent } from 'app/dialog/bh-info-dialog/bh-info-dialog.component';
import { BhDocumentLinkComponent } from 'app/dialog/bh-document-link/bh-document-link.component';
import { BhSearchQueryBuilderService, QueryResult } from '../extended/services/bh-search-query-builder.service';
import { BhDocumentListComponent } from '../extended/bh-document-list/bh-document-list.component';
import { BhApiService } from 'app/services/bh-api.service';

@Component({
  selector: 'app-bh-document-view',
  templateUrl: './bh-document-view.component.html',
  styleUrls: ['./bh-document-view.component.scss']
})
export class BhDocumentViewComponent implements OnInit, OnDestroy {

  currentView = false;
  showViewer = false;
  documentId: string;

  node;
  nodeId: string;
  rootId: string;
  rootFolder = '';
  showFolders = false;
  showDocuments = true;

  @ViewChild('breadcrumb')
  breadcrumb: BreadcrumbComponent;

  @ViewChild('documentList')
  documentList: BhDocumentListComponent;

  showFacetFilter$: Observable<boolean>;

  data: ResultSetPaging;
  totalResults = 0;
  hasSelectedFilters = false;
  sorting = ['name', 'asc'];
  isLoading = false;

  private qName = '{http://www.bakerhughes.com/model/qms/content/1.0}';
  private facetProperties = {
    function : 'function',
    subfunction : 'sub_function',
    site : 'site'
  };
  private advancedSearchProperties = {
    id : 'ID',
    documentname : 'cm:name',
    documentreferencenumber : 'reference',
    productcompany : 'product_company',
    productline : 'product_line',
    subproductline : 'sub_product_line',
    site : 'site',
    function : 'function',
    subfunction : 'sub_function',
    documenttype : 'document_type',
    effectivedate : 'effective_date',
    publisheddate : 'published_date',
    expirydate : 'expiry_date',
    isoelement : 'iso_element',
    userrole : 'user_role',
    process : 'process',
    subprocess : 'sub_process',
    contentcategory : 'content_category',
    language : 'language_code',
    documentauthor : 'document_author_noderef',
    documentadmin : 'document_admin_noderef',
    functionalowner : 'functional_owner_noderef',
    documentumobjectid : 'dctm_object_id'
  };

  isAdvancedSearch = false;
  advancedSearchId = false;

  defaultQuery = '';
  searchQuery = '';
  facetQuery = '';
  advancedSearchQuery = '';
  searchedWord = '';
  subscription: Subscription;

  protected subscriptions: Subscription[] = [];

  additionalColumns = [];
  additionalColumnsData = [
    { id : 'subProductLine', value : 'Sub Product Line'},
    { id : 'subFunction', value : 'Sub/Issuing Function'},
    { id : 'process', value : 'Process'},
    { id : 'subProcess', value : 'Sub Process'},
    { id : 'documentType', value : 'Document Type'}
  ];

  selectedAdditionalColumns = {
    subProductLine : false,
    subFunction : false,
    process : false,
    subProcess : false,
    documentType : false
  };

  @ViewChild('selectAdditionalColumns')
  selectAdditionalColumns: MatSelect;

  constructor(private router: Router,
    private appConfig: AppConfigService,
    private translationService: TranslationService,
    private queryBuilder: BhSearchQueryBuilderService,
    private route: ActivatedRoute,
    private apiService: BhApiService,
    private changeDetector: ChangeDetectorRef,
    private preview: PreviewService,
    private dialog: MatDialog,
    private notificationService: NotificationService,
    private searchService: BhSearchService,
    private webscript: BhWebscriptService) {
      queryBuilder.paging = {
        skipCount: 0,
        maxItems: 25
      };

      // this.showFacetFilter$ = store.select(showFacetFilter);
      this.showFacetFilter$ = of(true);
    }

  ngOnInit() {
    this.rootFolder = this.appConfig.get('rootFolder');

    // this.defaultQuery = '(PATH:\'/app:company_home/st:sites/cm:bh-qms-documents/cm:documentLibrary//*\')';
    this.defaultQuery = this.appConfig.get('searchRootPath');

    this.data = undefined;
    this.isLoading = true;
    // Faceted Query
    // Faceted Search
    this.sorting = this.getSorting();

    this.subscriptions.push(
      this.searchService.getFacetQuery().subscribe(
      (facetQuery) => {
        if (this.searchQuery !== '' && this.searchQuery !== undefined && this.searchQuery !== null) {
          this.facetQuery = facetQuery;
          const query = this.searchQuery + facetQuery;
          // this.queryBuilder.userQuery = decodeURIComponent(query);
          // this.queryBuilder.execute();
          this.executeQuery(query);
        }
      }),

      this.searchService.getAdvancedSearchQuery().subscribe(
        (advancedSearchQuery) => {
          this.advancedSearchQuery = advancedSearchQuery;
          // const query = this.defaultQuery + advancedSearchQuery;
          const query = this.appConfig.get('searchRootPath') + advancedSearchQuery;
          this.executeQuery(query);
        }
      ),

      this.router.events.pipe(
        filter(event => event instanceof NavigationEnd)
      ).subscribe((event: NavigationEnd) => {
        this.updateRouteChanges('onNavigation');
      }),

      this.queryBuilder.updated.subscribe(query => {
        if (query) {
          console.log('Pagination updated query : ', query);
          this.sorting = this.getSorting();
          this.data = undefined;
          this.isLoading = true;
          this.queryBuilder.execute();
        }
      }),

      this.queryBuilder.executed.subscribe(data => {
        this.queryBuilder.paging.skipCount = 0;

        this.onSearchResultLoaded(data);
        this.isLoading = false;
      }),

      this.queryBuilder.error.subscribe((err: any) => {
        this.onSearchError(err);
      })
    );

    this.apiService.getNodeInfo('-root-', {
        includeSource: true,
        include: ['path', 'properties', 'allowableOperations', 'permissions', 'aspectNames', 'association'],
        relativePath: this.rootFolder
    })
    .then(
      (node) => {
        this.rootId = node.id;
      },
      (e) => {
        this.rootId = '';
      }
    );

    this.updateRouteChanges('onInit');

  }

  updateRouteChanges(event) {
    console.log('updateRouteChanges ::: ', event);
    if (this.route) {
      const isSearch = this.router.url.indexOf('/search') === 0;
      const isAdvancedSearch = this.router.url.indexOf('/advanced-search') === 0;
      const documentView = this.router.url.indexOf('/document-view') === 0;

      this.isAdvancedSearch = isAdvancedSearch;
      if (isSearch || isAdvancedSearch) {
        this.currentView = false;
        const params = this.route.queryParams['value'];
        console.log('bh-document-view : QueryParamsMap : ', params);
        // this.route.queryParams.forEach((params: Params) => {
          // console.log('bh-document-view : forEach : params : ', params);
          this.searchService.updateAdvancedSearchParams(params);
          if (isSearch) {
            this.advancedSearchId = false;
            this.buildSearchQuery(params);
          } else if (isAdvancedSearch) {
            this.buildAdvanceQuery(params);
          }
        // });
      } else if (documentView) {
        this.advancedSearchId = false;
        this.currentView = true;
        const dParams = this.route.params['value'];
        // this.route.params.subscribe(params => {
          const id = dParams.nodeId;
          if (id !== null && id !== '' && id !== undefined) {
            this.getNodeInfo(id);
            this.getPathElements(id);
          } else {
            this.getRootNodeInfo();
          }
        // });
      } else {
        console.log('URL : ', this.router.url);
      }
    }
  }

  buildSearchQuery(params: any) {
    let query = '';
    const searchedWord = params.hasOwnProperty('searchTerm') ? params['searchTerm'] : null;
    const facetParam = params.hasOwnProperty('facetParams') ? params['facetParams'] : null;
    console.log('Search Word - queryParams: ', searchedWord);
    if (searchedWord !== '' && searchedWord !== undefined && searchedWord !== null) {
      query = ' AND' +
              ' (cm:name:"*' + searchedWord + '*"' +
              ' OR cm:title:"*' + searchedWord + '*"' +
              ' OR cm:description:"*' + searchedWord + '*"' +
              ' OR bhqms:reference:"*' + searchedWord + '*"' +
              ' OR TEXT:"*' + searchedWord + '*")';
    }

    if (query !== '' && query !== undefined && query !== null) {
      // query = this.defaultQuery + query;
      query = this.appConfig.get('searchRootPath') + query;

      const facetQuery = this.buildFacetQuery(facetParam);
      if (facetQuery !== '' && facetQuery !== null && facetQuery !== null) {
        query = query + facetQuery;
      }

      console.log('Search Query : ', query);
      console.log('Facet Query : ', facetQuery);
    }
    this.executeQuery(query);
  }

  buildFacetQuery(facetParam: string): string {
    let facetQuery = '';
    if (facetParam !== null && facetParam !== undefined && facetParam !== '') {
      facetParam = JSON.parse(facetParam);
      Object.keys(facetParam).forEach((key) => {
        const value: string = facetParam[key];
        if (value !== undefined && value !== null && value !== '') {
          const tempQuery = this.qName + this.facetProperties[key];
          const values = value.split(',');
          facetQuery += ' AND (';
          if (values.length >= 2) {
            for (let i = 0; i < values.length; i++) {
              facetQuery += tempQuery + ':\'' + values[i] + '\'';
              if ( values.length > 1 && values.length > (i + 1)) {
                facetQuery += ' OR ';
              }
            }
          } else {
            facetQuery += tempQuery + ':\'' + value + '\'';
          }
          facetQuery += ')';
        }
      });
    }

    return facetQuery;
  }

  buildAdvanceQuery(params: any) {
    this.advancedSearchId = false;
    let query = '';
    const keys = Object.keys(params);
    if (keys.length > 0) {
      keys.forEach(key => {
        const value: string = params[key];
        if (value !== '' && value !== undefined && value !== null ) {
          const tempQuery = this.qName + this.advancedSearchProperties[key];
          const values = value.split(',');
          if (key.toLowerCase().includes('date') && values.length === 2) {
            const startDate = values[0];
            const endDate = values[1];
            const hasStartDate = (startDate !== '' && startDate !== undefined && startDate !== null);
            const hasEndDate = (endDate !== '' && endDate !== undefined && endDate !== null);
            if (hasStartDate && hasEndDate) {
              query += ' AND (';
              query += tempQuery + ':[\'' + startDate + '\' TO \'' + endDate + '\']';
              query += ')';
            } else if (hasStartDate && !hasEndDate) {
              query += ' AND (';
              query += tempQuery + ':[\'' + startDate + '\' TO MAX]';
              query += ')';
            } else if (!hasStartDate && hasEndDate) {
              query += ' AND (';
              query += tempQuery + ':[MIN TO \'' + endDate + '\']';
              query += ')';
            }
          } else if (key === 'facetParams' ) {
            const facetQuery = this.buildFacetQuery(value);
            if (facetQuery !== '' && facetQuery !== null && facetQuery !== null) {
              query = query + facetQuery;
            }
          } else if (key === 'documentname') {
            query += ' AND (';
            query += this.advancedSearchProperties[key] + ':\'*' + value + '*\'';
            query += ')';
          } else if (key === 'documentreferencenumber') {
            query += ' AND (';
            query += tempQuery + ':\'*' + value + '*\'';
            query += ')';
          } else if (key === 'id') {
            this.advancedSearchId = true;
            query += ' AND (';
            query += this.advancedSearchProperties[key] + ':\'workspace://SpacesStore/' + value + '\'';
            query += ')';
          } else {
            query += ' AND (';
            if (values.length >= 1) {
              for (let i = 0; i < values.length; i++) {
                query += tempQuery + ':\'' + values[i] + '\'';
                if ( values.length > 1 && values.length > (i + 1)) {
                  query += ' OR ';
                }
              }
            } else {
              query += tempQuery + ':\'' + value + '\'';
            }
            query += ')';
          }
        }
      });
    }

    console.log('Advanced Search Query : ', query);
    if (query !== '' && query !== undefined && query !== null) {
      // query = this.defaultQuery + query;
      query = this.appConfig.get('searchRootPath') + query;
    }
    this.executeQuery(query);
  }

  ngOnDestroy() {
    this.subscriptions.forEach(subscription => subscription.unsubscribe());
    this.subscriptions = [];
  }

  onSearchError(error: { message: any }) {
    const { statusCode } = JSON.parse(error.message).error;

    const messageKey = `APP.BROWSE.SEARCH.ERRORS.${statusCode}`;
    let translated = this.translationService.instant(messageKey);

    if (translated === messageKey) {
      translated = this.translationService.instant(
        `APP.BROWSE.SEARCH.ERRORS.GENERIC`
      );
    }

    console.log('Search Error : ', translated);

    // this.store.dispatch(new SnackbarErrorAction(translated));
  }

  onPaginationChanged(pagination: Pagination) {
    this.queryBuilder.paging = {
      maxItems: pagination.maxItems,
      skipCount: pagination.skipCount
    };
    this.queryBuilder.update();
  }

  private getSorting(): string[] {
    const primary = this.queryBuilder.getPrimarySorting();

    if (primary) {
      let k = primary.key;
      if (k === undefined || k === null) {
        k = primary.field;
      }
      // k = k.replace('{http://www.bakerhughes.com/model/qms/content/1.0}', 'properties.bhqms:');
      if (k.includes('bhqms:')) {
        k = 'properties.' + k;
      }
      return [k, primary.ascending ? 'asc' : 'desc'];
    }

    return ['name', 'asc'];
  }

  onSortingChanged(e) {
    console.log('onSortingChanged : ', e);
    console.log('sort before update : ', this.sorting);
    let k = e.detail.key;
    const dv = e.detail.direction;
    const sort = [k, dv];
    this.sorting = sort;
    console.log('sort after update : ', this.sorting);

    // k = k.replace('properties.bhqms:', '{http://www.bakerhughes.com/model/qms/content/1.0}');
    k = k.replace('properties.', '');
    let d = dv === 'asc' ? true : false;
    console.log('query sort before update : ', this.queryBuilder.sorting);
    if (this.queryBuilder.sorting.length > 0) {
      const oSort = this.queryBuilder.sorting[0];
      if (k === oSort.field) {
        d = !oSort.ascending;
      }
    }
    const qSort = {
      type: 'FIELD',
      field: k,
      key: k,
      ascending: d
    };
    const qSorting = new Array();
    qSorting.push(qSort);
    this.queryBuilder.sorting = qSorting;
    console.log('query sort after update : ', this.queryBuilder.sorting);
    this.queryBuilder.update();
  }

  onSearchResultLoaded(nodePaging: QueryResult) {
    this.data = nodePaging.result;
    const status = nodePaging.status;
    const totalResults = this.getNumberOfResults();
    if ((this.isAdvancedSearch && this.advancedSearchId) && totalResults === 0 && status === 'success') {
      this.openInfoDialog('Info', true, 'The document has been Archived or not available for Library users');
    }

    // this.totalResults = this.getNumberOfResults();
    // this.hasSelectedFilters = this.isFiltered();

    // Facet Fields update
    // if ((this.facetQuery === '' || this.facetQuery === undefined || this.facetQuery === null)) {
      this.searchService.updateFacetData(nodePaging.result.list.context.facets);
    // }
  }

  getNumberOfResults() {
    if (this.data && this.data.list && this.data.list.pagination) {
      return this.data.list.pagination.totalItems;
    }
    return 0;
  }

  hasCheckedCategories() {
    const checkedCategory = this.queryBuilder.categories.find(
      category => !!this.queryBuilder.queryFragments[category.id]
    );
    return !!checkedCategory;
  }

  onPathNavigate(pathElement: PathElement) {
    console.log('Path Navigate : ', pathElement);
    this.getNodeInfo(pathElement.id);
    this.getPathElements(pathElement.id);
    // this.getPathFolders('navigate', this.breadcrumb.route, pathElement);

  }

  getNodeInfo(id) {
    this.apiService.getNodeInfo(id, {
      includeSource: true,
      include: ['path', 'properties', 'allowableOperations', 'permissions', 'aspectNames', 'association']
    }).then(
      (node) => {
        console.log('Path Node : ', node);
        if (node) {
          this.node = node;
          this.nodeId = id;

          // this.searchDocuments(node);

          this.changeDetector.detectChanges();
        }
      }
    );
  }

  getPathElements(id) {
    const nodeRef = 'workspace://SpacesStore/' + id;
    const queryParams = {
      'nodeRef': nodeRef
    };
    const options: RequestOptions = {
      path: '/service/pathElemets',
      queryParams: queryParams
    };
    this.webscript.get(options).then(
      (r) => {
        if (r) {
          this.searchDocuments(r);
        }
      },
      (c) => {
        console.log('Get Path Elements Error');
      }
    );
  }

  getRootNodeInfo() {
    this.apiService.getNodeInfo('-root-', {
      includeSource: true,
      include: ['path', 'properties', 'allowableOperations', 'permissions', 'aspectNames', 'association'],
      relativePath: this.rootFolder
      // + '/DS Digital Solutions/Bently Nevada/Bangalore/Bently Nevada Global/Manufacturing'
    })
    .then(node => {
        console.log('Root Node : ', node);
        this.node = node;
        this.nodeId = node.id;
        // this.changeDetector.detectChanges();
    });
  }

  searchDocuments(folders) {
    // const folders = this.getPathFolders('load', node.path.elements, node.name);
    let query = this.buildQuery(folders);

    if (query !== '' && query !== undefined && query !== null) {
      this.route.queryParams.forEach((params: Params) => {
        console.log('document view params : ', params);
        this.searchService.updateAdvancedSearchParams(params);
        const facetParam = params.hasOwnProperty('facetParams') ? params['facetParams'] : null;
        const facetQuery = this.buildFacetQuery(facetParam);
        if (facetQuery !== '' && facetQuery !== null && facetQuery !== null) {
          query = query + facetQuery;
        }
      });
    }

    this.executeQuery(query);
  }

  buildDocumentViewFacetQuery() {

  }

  executeQuery(query: string) {
    console.log('query : ', query);
    this.facetQuery = '';
    if (query) {
      this.searchQuery = query;
      this.queryBuilder.userQuery = decodeURIComponent(query);
      this.queryBuilder.execute();
    } else {
      this.queryBuilder.userQuery = null;
      const queryResult = {
        result: this.getEmptyResult(),
        status : 'no-query'
      };
      this.queryBuilder.executed.next(queryResult);
    }
  }

  getEmptyResult(): any {
    const emptyData = {
      list: { pagination: { totalItems: 0 }, entries: [], context: { facets: [] } }
    };
    return emptyData;
  }

  getPathFolders(type: string, all: PathElement[], pathElement: any) {
    console.log('All Folders ::: ', all);
    console.log('Path Folder ::: ', pathElement);
    const allFolders: PathElement[] = all;
    const folders = new Array();
    if (type === 'load') {
      let rootIndex = -1;
      for (let i = 0; i < allFolders.length; i++) {
        const rootFolder = (allFolders[i].name === 'QMS Documents'
        || allFolders[i].name === 'Baker Hughes'
        || allFolders[i].name === 'Published Documents');
        if (rootFolder) {
          rootIndex = i;
        }

        if ( rootIndex !== -1 && !rootFolder) {
          folders.push(allFolders[i].name);
        }
      }
      if (pathElement !== 'QMS Documents' &&
          pathElement !== 'Baker Hughes' &&
          pathElement !== 'Published Documents') {
        folders.push(pathElement);
      }
    } else if (type === 'navigate') {
      for (let i = 0; i < allFolders.length; i++) {
        if (allFolders[i].name === 'QMS Documents'
        || allFolders[i].name === 'Baker Hughes'
        || allFolders[i].name === 'Published Documents') {
          folders.push(allFolders[i].name);
        }
        if (allFolders[i].id === pathElement.id) {
          break;
        }
      }
    }

    return folders;
  }

  /* buildQuery(folders: any[]): string {
    let query = '';
    // query += this.defaultQuery;
    query += this.appConfig.get('searchRootPath');
    console.log('folders : ', folders);
    if (folders.length === 1) {
      query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
    } else if (folders.length === 2) {
      if (folders[0].name === 'BH-Baker Hughes' || folders[0].name === 'BH-GE Legacy Global') {
        query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
        query += ' AND (=bhqms:function:\'' + folders[1].name + '\')';
      } else {
        query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
        query += ' AND (=bhqms:product_line:\'' + folders[1].name + '\')';
      }
    } else if (folders.length === 3) {
      if (folders[0].name === 'BH-Baker Hughes') {
        query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
        query += ' AND (=bhqms:function:\'' + folders[1].name + '\')';
        query += ' AND (=bhqms:sub_function:\'' + folders[2].name + '\')';
      } else if (
        folders[0].name === 'BH-TPS Turbomachinery & Process Solutions' ||
        (folders[0].name === 'BH-DS Digital Solutions' && folders[1].name === 'Process & Pipeline Services')
        ) {
        query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
        query += ' AND (=bhqms:product_line:\'' + folders[1].name + '\')';
        query += ' AND (=bhqms:sub_product_line:\'' + folders[2].name + '\')';
      } else {
        query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
        query += ' AND (=bhqms:product_line:\'' + folders[1].name + '\')';
        query += ' AND (=bhqms:site:\'' + folders[2].name + '\')';
      }
    } else if (folders.length === 4) {
      if (folders[0].name === 'BH-TPS Turbomachinery & Process Solutions') {
        query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
        query += ' AND (=bhqms:product_line:\'' + folders[1].name + '\')';
        query += ' AND (=bhqms:sub_product_line:\'' + folders[2].name + '\')';
        query += ' AND (=bhqms:function:\'' + folders[3].name + '\')';
      } else if (folders[0].name === 'BH-DS Digital Solutions') {
        if (folders[1].name === 'Process & Pipeline Services') {
          query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
          query += ' AND (=bhqms:product_line:\'' + folders[1].name + '\')';
          query += ' AND (=bhqms:sub_product_line:\'' + folders[2].name + '\')';
          query += ' AND (=bhqms:site:\'' + folders[3].name + '\')';
        } else {
          query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
          query += ' AND (=bhqms:product_line:\'' + folders[1].name + '\')';
          query += ' AND (=bhqms:site:\'' + folders[2].name + '\')';
          query += ' AND (=bhqms:function:\'' + folders[3].name + '\')';
        }
      } else {
        query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
        query += ' AND (=bhqms:product_line:\'' + folders[1].name + '\')';
        query += ' AND (=bhqms:site:\'' + folders[2].name + '\')';
        query += ' AND (=bhqms:sub_product_line:\'' + folders[3].name + '\')';
      }
    } else if (folders.length === 5) {
      if (folders[0].name === 'BH-TPS Turbomachinery & Process Solutions') {
        query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
        query += ' AND (=bhqms:product_line:\'' + folders[1].name + '\')';
        query += ' AND (=bhqms:sub_product_line:\'' + folders[2].name + '\')';
        query += ' AND (=bhqms:function:\'' + folders[3].name + '\')';
        query += ' AND (=bhqms:site:\'' + folders[4].name + '\')';
      } else if (folders[0].name === 'BH-DS Digital Solutions' && folders[1].name === 'Process & Pipeline Services') {
        query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
        query += ' AND (=bhqms:product_line:\'' + folders[1].name + '\')';
        query += ' AND (=bhqms:sub_product_line:\'' + folders[2].name + '\')';
        query += ' AND (=bhqms:site:\'' + folders[3].name + '\')';
        query += ' AND (=bhqms:function:\'' + folders[4].name + '\')';
      } else {
        query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
        query += ' AND (=bhqms:product_line:\'' + folders[1].name + '\')';
        query += ' AND (=bhqms:site:\'' + folders[2].name + '\')';
        query += ' AND (=bhqms:sub_product_line:\'' + folders[3].name + '\')';
        query += ' AND (=bhqms:function:\'' + folders[4].name + '\')';
      }
    } else if (folders.length === 6) {
      if (folders[0].name === 'BH-DS Digital Solutions' && folders[1].name === 'Process & Pipeline Services') {
        query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
        query += ' AND (=bhqms:product_line:\'' + folders[1].name + '\')';
        query += ' AND (=bhqms:sub_product_line:\'' + folders[2].name + '\')';
        query += ' AND (=bhqms:site:\'' + folders[3].name + '\')';
        query += ' AND (=bhqms:function:\'' + folders[4].name + '\')';
        query += ' AND (=bhqms:sub_function:\'' + folders[5].name + '\')';
      }
    } else if (folders.length === 7) {
      if (folders[0].name === 'BH-DS Digital Solutions' && folders[1].name === 'Process & Pipeline Services') {
        query += ' AND (=bhqms:product_company:\'' + folders[0].name + '\')';
        query += ' AND (=bhqms:product_line:\'' + folders[1].name + '\')';
        query += ' AND (=bhqms:sub_product_line:\'' + folders[2].name + '\')';
        query += ' AND (=bhqms:site:\'' + folders[3].name + '\')';
        query += ' AND (=bhqms:function:\'' + folders[4].name + '\')';
        query += ' AND (=bhqms:sub_function:\'' + folders[5].name + '\')';
        query += ' AND (=bhqms:document_type:\'' + folders[6].name + '\')';
      }
    }

    return query;
  } */

  buildQuery(folders: any[]): string {
    let query = '';
    // query += this.defaultQuery;
    query += this.appConfig.get('searchRootPath');
    console.log('folders : ', folders);
    if (folders.length > 0) {
      folders.forEach(
        (f) => {
          const name = f.name;
          const desc = f.description;
          switch (desc) {
            case 'Product Company':
              query += ' AND (=bhqms:product_company:\'' + name + '\')';
              break;
            case 'Product Line' :
              query += ' AND (=bhqms:product_line:\'' + name + '\')';
              break;
            case 'Sub Product Line' :
              query += ' AND (=bhqms:sub_product_line:\'' + name + '\')';
              break;
            case 'Site' :
              query += ' AND (=bhqms:site:\'' + name + '\')';
              break;
            case 'Function' :
              query += ' AND (=bhqms:function:\'' + name + '\')';
              break;
            case 'Sub Function' :
              query += ' AND (=bhqms:sub_function:\'' + name + '\')';
              break;
            case 'Document Type' :
              query += ' AND (=bhqms:document_type:\'' + name + '\')';
              break;
          }
        }
      );
    }
    return query;
  }

  onListReady(e) {
    console.log('List ready : ', e);
    console.log('List : ', this.documentList);
  }

  onFolderView() {
    this.preview.showDocumentList(this.node.id);
    /* let id = entry.id;
    let path = entry.path.name.toString();
    path = path.replace('/Company Home', '');
    path = path + '/' + entry.name;
    path = path.replace('SmartFoldersView', 'SmartFolders');

    this.apiService.getNodeInfo('-root-', {
        includeSource: true,
        include: ['path', 'properties'],
        relativePath: path
    })
    .then(node => {
        id = node.id;
        this.preview.showDocumentList(id);
    }); */
  }

  onDocumentView() {
    this.preview.showDocumentListView(this.node.id);
  }

  showPreview(event) {
    const entry = event.value.entry;
    if (entry && entry.isFile) {
      this.preview.showResource(entry.id);
    }
  }

  myCustomAction(event, type) {
    const entry = event.value.entry;
    console.log('document details : ', entry);
    // alert(`Custom document action for ${entry.name}`);
    if (type === 'revision' || type === 'archive') {
      this.checkNode(event, type);
      // this.openStartWorkflowDialog(event, type);
    } else if (type === 'properties') {
      this.openDocumentProperties(entry);
    } else if (type === 'download') {
      this.notificationService.openSnackMessage(`Downloaded file "${entry.name}" `, 2000);
    } else if (type === 'link') {
      this.openDocumentLink('link', entry);
    } else {
      this.notificationService.openSnackMessage(`Custom document action for "${entry.name}" `, 2000);
    }
  }

  checkNode(event, type) {
    const entry = event.value.entry;
    const nodeRef = 'workspace://SpacesStore/' + entry.id;
    const queryParams = '?nodeRef=' + nodeRef + '&type=' + 'all';
    const options: RequestOptions = {
      path: '/service/getNodeDetails' + queryParams
    };
    this.webscript.get(options).then(
      (r) => {
        if (r && r.data && r.data.properties) {
          const p = r.data.properties;
          const hasWorkflow = r.data.hasWorkflow;
          if (hasWorkflow !== null && hasWorkflow !== undefined && hasWorkflow !== '') {
            if (hasWorkflow) {
              this.openInfoDialog(
                'Information',
                true,
                'Workflow can not be Initiated, selected document is already part of a different workflow!');
            } else {
              this.checkSourceAssociation(p, type);
            }
          } else {
            this.checkSourceAssociation(p, type);
          }
        } else {
          this.openInfoDialog('Error', true, 'Unable to retrieve document details, Please try again later');
        }
      },
      (c) => {
        this.openInfoDialog('Error', true, c);
      }
    );
  }

  checkSourceAssociation(p: any, type: string) {
    const event = {
      value: {
        entry: {}
      }
    };
    const a = p['bhqms:revision_association'];
    if (a !== null && a !== undefined && a !== '') {
      const data = this.getDocumentData(a);
      const pr = data['bhqms:publish_revision'];
      if (pr === undefined || pr === null || pr === '' || pr === 'None' ) {
        data['bhqms:publish_revision'] = p['bhqms:publish_revision'];
      }
      event.value.entry = data;
    } else {
      event.value.entry = this.getDocumentData(p);
    }

    console.log('Parsed properties : ', event.value.entry);
    this.openStartWorkflowDialog(event, type);
  }

  getDocumentData(p: any): any {
    const properties = new Object();
    const keys = Object.keys(p);
    keys.forEach(
      (k) => {
        const v = p[k];
        if (v !== null && v !== undefined && v !== '') {
          properties[k] = v;
        }
      });

    return properties;
  }

  openStartWorkflowDialog(event, type) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.minHeight = '550px';
    dialogConfig.height = '84%';
    dialogConfig.maxHeight = '100%';
    dialogConfig.minWidth = '300px';
    dialogConfig.width = '50%';
    dialogConfig.maxWidth = '100%';
    dialogConfig.panelClass = 'start-workflow-dialog';
    dialogConfig.data = { node: event.value.entry, requestType: type };

    const dialogRef = this.dialog.open(BhStartWorkflowComponent, dialogConfig);

    dialogRef.componentInstance.params = {
      maximize: () => {
        dialogRef.updateSize('100%', '100%');
      },
      resize: () => {
        dialogRef.updateSize('50%', '84%');
      }
    };

    dialogRef.afterClosed().subscribe(
      val => console.log('Dialog output:', val)
    );

  }

  openDocumentProperties(entry) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.minHeight = '550px';
    dialogConfig.height = '84%';
    dialogConfig.maxHeight = '100%';
    dialogConfig.minWidth = '300px';
    dialogConfig.width = '50%';
    dialogConfig.maxWidth = '100%';
    dialogConfig.panelClass = 'start-workflow-dialog';
    dialogConfig.data = entry;

    const dialogRef = this.dialog.open(BhDocumentPropertiesComponent, dialogConfig);
    dialogRef.componentInstance.params = {
      maximize: () => {
        dialogRef.updateSize('100%', '100%');
      },
      resize: () => {
        dialogRef.updateSize('50%', '84%');
      }
    };
  }

  onPreview(event) {
    const entry = event.value.entry;
    if (entry && entry.isFile) {
      const type = entry.properties ? entry.properties['bhqms:content_category'] : undefined;
      if (type === 'Document') {
        this.documentId = entry.id;
        this.showViewer = true;
      } else if (type === 'URL') {
        this.openDocumentLink('url', entry);
      }
    }
  }

  onViewerToggle(event) {
    this.documentId = null;
    this.showViewer = event;
  }

  onUpdateAdditionalColumns(e: any) {
    this.additionalColumns = [];
    if ( this.selectAdditionalColumns !== undefined && this.selectAdditionalColumns.options.length > 0 ) {
      this.selectAdditionalColumns.options.forEach(
        (item: MatOption) => {
          // item.selected;
          // console.log('option : ', item);
          if (item.selected) {
            this.selectedAdditionalColumns[item.value] = true;
            this.additionalColumns.push(item.viewValue);
          } else {
            const index = this.additionalColumns.indexOf(item.viewValue, 0);
            if (index !== -1) {
              this.additionalColumns.splice(index, 1);
            }
            this.selectedAdditionalColumns[item.value] = false;
          }
        });
    }
  }

  selectAllAdditionalColumns() {
    if ( this.selectAdditionalColumns !== undefined && this.selectAdditionalColumns.options.length > 0 ) {
      this.selectAdditionalColumns.options.forEach(
        (item: MatOption) => {
          item.select();
        });
    }
  }

  deSelectAdditionalColumns() {
    if ( this.selectAdditionalColumns !== undefined && this.selectAdditionalColumns.options.length > 0 ) {
      this.selectAdditionalColumns.options.forEach(
        (item: MatOption) => {
          item.deselect();
        });
    }
  }

  openDocumentLink(type: string, entry: ResultNode) {
    const dialogRef = this.dialog.open(BhDocumentLinkComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: {
        node : entry,
        type : type
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

  openInfoDialog(title, hasTitle, message) {
    const dialogRef = this.dialog.open(BhInfoDialogComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: { title: title, hasTitle: hasTitle, message: message }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

  isDataAvailable() {
    return this.data && this.data.list && this.data.list.entries && this.data.list.entries.length > 0;
  }

  isDataEmpty() {
    if (!this.data) {
      return true;
    } else {
      if (!this.data.list) {
        return true;
      } else {
        if (!this.data.list.entries) {
          return true;
        } else {
          if (this.data.list.entries.length === 0) {
            return true;
          } else {
            return false;
          }
        }
      }
    }
  }

}
