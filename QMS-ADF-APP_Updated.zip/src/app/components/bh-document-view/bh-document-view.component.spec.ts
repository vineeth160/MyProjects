import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhDocumentViewComponent } from './bh-document-view.component';

describe('BhDocumentViewComponent', () => {
  let component: BhDocumentViewComponent;
  let fixture: ComponentFixture<BhDocumentViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhDocumentViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhDocumentViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
