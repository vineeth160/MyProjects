import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhMyTasksComponent } from './bh-my-tasks.component';

describe('BhMyTasksComponent', () => {
  let component: BhMyTasksComponent;
  let fixture: ComponentFixture<BhMyTasksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhMyTasksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhMyTasksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
