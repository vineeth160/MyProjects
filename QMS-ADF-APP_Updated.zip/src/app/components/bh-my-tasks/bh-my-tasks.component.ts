import { Component, OnInit, ViewChild } from '@angular/core';
import { BhTasksComponent } from '../bh-tasks/bh-tasks.component';
import { PaginationModel } from '@alfresco/adf-core';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-bh-my-tasks',
  templateUrl: './bh-my-tasks.component.html',
  styleUrls: ['./bh-my-tasks.component.scss']
})
export class BhMyTasksComponent implements OnInit {

  @ViewChild('taskList')
  taskList: BhTasksComponent;

  pagination: BehaviorSubject<PaginationModel>;

  constructor() { }

  ngOnInit() {
  }

}
