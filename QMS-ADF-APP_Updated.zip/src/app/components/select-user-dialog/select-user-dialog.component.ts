import { Component, OnInit, ViewChild, Inject, Renderer2, ChangeDetectorRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { NotificationService } from '@alfresco/adf-core';
import { MatSelectionList, MatSelectionListChange, MatListOption, MatRadioGroup } from '@angular/material';
import { Observable } from 'rxjs';

import { BhWebscriptService, RequestOptions } from '../../services/bh-webscript.service';

/* interface ListUser {
  name: string;
  userName: string;
  selected: boolean;
} */

@Component({
  selector: 'app-select-user-dialog',
  templateUrl: './select-user-dialog.component.html',
  styleUrls: ['./select-user-dialog.component.scss']
})
export class SelectUserDialogComponent implements OnInit {

  removable = true;
  multiple = false;
  type = 'hru';

  form: FormGroup;
  userTerm: string;
  selectedUser = '';

  allUsers = [
    { name: 'Administrator', userName: 'admin' },
    { name: 'Test User', userName: 'bhdev1' },
    { name: 'Workflow Admin', userName: 'wfadmin' },
    { name: 'Workflow Approver', userName: 'wfapprover' },
    { name: 'Workflow Reviewer', userName: 'wfreviewer' },
    { name: 'Workflow Publisher', userName: 'wfpublisher' }
  ];

  tempUsers = [];
  selectedUsers = [];

  onLoad = true;
  isLoading = false;

  @ViewChild(MatSelectionList) users: MatSelectionList;

  /* @ViewChild(MatRadioGroup) radioGroup: MatRadioGroup; */

  constructor(private fb: FormBuilder,
    private dialogRef: MatDialogRef<SelectUserDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private ren: Renderer2,
    private changeDetector: ChangeDetectorRef,
    private webscript: BhWebscriptService) {

    this.form = fb.group({
      userTerm: ['', Validators.required],
      selectedUsers: [this.selectedUsers, Validators.required]
    });
  }

  ngOnInit() {

    this.multiple = this.data.multiple;
    this.selectedUsers = this.data.savedUsers;
    this.type = this.data.type;

    /*  this.users.selectionChange.subscribe((s: MatSelectionListChange) => {
       this.users.deselectAll();
       s.option.selected = true;
       console.log('selected user : ', s.option._text.nativeElement.innerText);
       this.selectedUser.name = s.option._text.nativeElement.innerText;
       this.selectedUser.userName = s.option.value;
   }); */

  }

  searchDemo() {
    // this.users.deselectAll();
    this.onLoad = false;
    const f = this.form.value;
    this.tempUsers = [];
    if (f.userTerm !== null && f.userTerm !== '' && f.userTerm !== undefined) {
      for (let i = 0; i < this.allUsers.length; i++) {

        const n = this.allUsers[i].name.toLowerCase().trim();
        const un = this.allUsers[i].userName.toLowerCase().trim();
        if (n.includes(f.userTerm.toLowerCase().trim())) {
          const u = { name: '', userName: '', selected: false };
          u.name = this.allUsers[i].name;
          u.userName = this.allUsers[i].userName;


          /* if (
            (this.selectedUser.userName !== null
              && this.selectedUser.userName !== ''
              && this.selectedUser.userName !== undefined)
              && this.selectedUser.userName === u.userName) {
            u.selected = true;
          } */

          let c = 0;
          for (let s = 0; s < this.selectedUsers.length; s++) {
            const sn = this.selectedUsers[s].userName.toLowerCase().trim();
            if (sn === un) {
              c++;
            }
          }

          if (c !== 0) {
            u.selected = true;
          }

          this.tempUsers.push(u);

        }
      }
    }

    /* if (this.selectedUsers.length === 0 && !this.multiple) {
      this.radioGroup._radios.forEach(el => {
        el.checked = false;
        this.ren.removeClass(el['_elementRef'].nativeElement, 'cdk-focused');
        this.ren.removeClass(el['_elementRef'].nativeElement, 'cdk-program-focused');
      });
    } */

  }

  search() {
    this.onLoad = false;
    const f = this.form.value;
    this.tempUsers = [];
    if ((f.userTerm !== null && f.userTerm !== '' && f.userTerm !== undefined)) {
      this.isLoading = true;
      this.getUsers(f.userTerm);
      // this.getUsersHrWebscript(f.userTerm);
    } else {
      this.onLoad = true;
    }
  }

  getUsers(a) {
    const options: RequestOptions = <RequestOptions>{
      path: '/service/getUsers?searchTerm=' + a + '&type=' + this.type + '&size=100'
    };
    this.webscript.get(options).then(
      (result) => {
        this.isLoading = false;
        console.log('Get Users Result : ', result);
        if (result && result.list && result.list.entries && result.list.entries.length > 0) {
          this.loadUsers(result.list.entries);
        }
      },
      (e) => {
        this.isLoading = false;
        console.log('Get Users Error : ', e);
      }
    );
  }

  loadUsers(result) {
    this.tempUsers = [];
    for (let i = 0; i < result.length; i++) {
      const v = result[i];
      const un = v['nodeRef'];
        v['selected'] = false;
        v['name'] = v.properties.name;
        v['userName'] = un;

        let c = 0;
        for (let s = 0; s < this.selectedUsers.length; s++) {
          const sn = this.selectedUsers[s].userName.toLowerCase().trim();
          if (sn === un.toLowerCase().trim()) {
            c++;
          }
        }

        if (c !== 0) {
          v['selected'] = true;
        }

        this.tempUsers.push(v);
    }
  }

  getUsersHrWebscript(a) {
    const options: RequestOptions = <RequestOptions>{
      path: '/service/bh/qms/datalist/hrsystemdatalistvalues/bh-qms-documents/hrSystemDataListItem',
      queryParams: { 'searchtext': a.toLowerCase() }
    };

    this.webscript.get(options).then(
      (result) => {
        this.isLoading = false;
        const r = JSON.parse(result);
        if (r.total > 0 && r.values.length > 0) {
          for (let i = 0; i < r.values.length; i++) {
            const v = r.values[i];
            const n = v['employee_first_name'].toLowerCase().trim() + ' ' + v['employee_last_name'].toLowerCase().trim();
            const un = v['employee_sso'];
            if (n.includes(a.toLowerCase().trim())) {
              const u = { name: '', userName: '', selected: false };
              u.name = v['employee_first_name'] + ' ' + v['employee_last_name'];
              u.userName = un;

              let c = 0;
              for (let s = 0; s < this.selectedUsers.length; s++) {
                const sn = this.selectedUsers[s].userName.toLowerCase().trim();
                if (sn === un) {
                  c++;
                }
              }

              if (c !== 0) {
                u.selected = true;
              }

              this.tempUsers.push(u);
            }
          }
        }
      },
      (e) => {
        this.isLoading = false;
        console.log('Get Users HR Webscript Error : ', e);
      }
    );
  }

  onClickSingle(u) {
    console.log('onClickSingle : ', u);
    this.selectedUsers = [];
    /* const u = {
      name: event.source._elementRef.nativeElement.innerText,
      userName: event.value,
      selected : true
    }; */
    const su = u;
    su.selected = true;
    this.selectedUsers.push(su);
    const users = [];
    for (let i = 0; i < this.tempUsers.length; i++) {
      const user = this.tempUsers[i];
      if (u.userName === this.tempUsers[i].userName) {
        user.selected = true;
      } else {
        user.selected = false;
      }
      users.push(user);
    }
    this.tempUsers = users;
  }

  onChangeSingle(event) {
    console.log('onChangeSingle : ', event);
    console.log('selected user : ', event.source._elementRef.nativeElement.innerText);
    this.selectedUser = event.value;
    this.selectedUsers = [];
    const u = {
      name: event.source._elementRef.nativeElement.innerText,
      userName: event.value,
      selected: true
    };
    this.selectedUsers.push(u);

    // this.selectedUser.name = event.source._elementRef.nativeElement.innerText;
    // this.selectedUser.userName = event.value;

    /* for (let i = 0; i < this.tempUsers.length; i++) {

      const n = this.tempUsers[i].name.toLowerCase().trim();
      if (n === event.value.toLowerCase().trim()) {
        const s = this.selectedUsers.indexOf(this.tempUsers[i]);
        if (!(s >= 0)) {
          this.selectedUsers.push(this.tempUsers[i]);
        }
      }

    } */
  }

  onChangeMultiple(event) {
    console.log('onChangeMultiple : ', event);
    const tempSelectedUsers = this.selectedUsers;
    this.selectedUsers = [];
    const un = event.option.value;
    const n = event.option._text.nativeElement.innerText;
    const s = event.option._selected;
    const u = {
      name: n,
      userName: un,
      selected: s
    };

    if (s) {
      tempSelectedUsers.push(u);

      // updating temp users
      for (let i = 0; i < this.tempUsers.length; i++) {
        const uname = this.tempUsers[i].userName;
        if (uname === un) {
          this.tempUsers[i].selected = true;
        }
      }

    } else {
      let c = -1;
      for (let i = 0; i < tempSelectedUsers.length; i++) {
        const sn = tempSelectedUsers[i].userName;
        if (sn === un) {
          c = i;
        }
      }

      if (c !== -1) {
        tempSelectedUsers.splice(c, 1);
      }

      // updating temp users
      for (let i = 0; i < this.tempUsers.length; i++) {
        const uname = this.tempUsers[i].userName;
        if (uname === un) {
          this.tempUsers[i].selected = false;
        }
      }

    }

    this.selectedUsers = tempSelectedUsers;

    /* for (let i = 0; i < this.tempUsers.length; i++) {

      const n = this.tempUsers[i].userName.toLowerCase().trim();
      if (n === v.toLowerCase().trim()) {
        let c = 0;
        for (let s = 0; s < this.selectedUsers.length; s++) {
          const sn = this.selectedUsers[s].userName.toLowerCase().trim();
          if (sn === n) {
            c++;
          }
        }

        if (c === 0) {
          this.selectedUsers.push(this.tempUsers[i]);
        }

      }

    } */

  }

  /* remove(user: string): void {
    const i = this.selectedUsers.indexOf(user);

    if (i >= 0) {
      this.selectedUsers.splice(i, 1);
    }
  } */

  remove(user: any): void {
    this.selectedUsers = [];
    this.selectedUser = '';

    const users = [];
    for (let i = 0; i < this.tempUsers.length; i++) {
      const u = this.tempUsers[i];
      u.selected = false;

      users.push(u);
    }

    this.tempUsers = users;

    // this.selectedUser.userName = '';
    // this.selectedUser.name = '';
  }

  removeMultiple(u: any) {
    if (this.multiple) {
      let c = -1;
      for (let i = 0; i < this.selectedUsers.length; i++) {
        const sn = this.selectedUsers[i].userName;
        if (sn === u.userName) {
          c = i;
        }
      }

      if (c !== -1) {
        this.selectedUsers.splice(c, 1);
      }

      const users = [];
      for (let i = 0; i < this.tempUsers.length; i++) {
        const user = this.tempUsers[i];
        if (this.tempUsers[i].userName === u.userName) {
          user.selected = false;
        }

        users.push(user);
      }

      this.tempUsers = [];
      this.tempUsers = users;
      this.changeDetector.detectChanges();
      console.log('multiple selection remove');
    } else {
      this.selectedUsers = [];
      this.selectedUser = '';

      const users = [];
      for (let i = 0; i < this.tempUsers.length; i++) {
        const u1 = this.tempUsers[i];
        u1.selected = false;

        users.push(u1);
      }

      this.tempUsers = users;
      console.log('single selection remove');
      // console.log('radioGroup : ', this.radioGroup);
      // Removing checked radio
      /* this.radioGroup._radios.forEach(el => {
        el.checked = false;
        this.ren.removeClass(el['_elementRef'].nativeElement, 'cdk-focused');
        this.ren.removeClass(el['_elementRef'].nativeElement, 'cdk-program-focused');
      }); */

    }

  }

  ok() {
    this.dialogRef.close(this.selectedUsers);
  }

  cancel() {
    this.dialogRef.close();
  }

}
