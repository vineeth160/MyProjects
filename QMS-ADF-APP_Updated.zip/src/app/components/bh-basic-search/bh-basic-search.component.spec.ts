import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhBasicSearchComponent } from './bh-basic-search.component';

describe('BhBasicSearchComponent', () => {
  let component: BhBasicSearchComponent;
  let fixture: ComponentFixture<BhBasicSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhBasicSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhBasicSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
