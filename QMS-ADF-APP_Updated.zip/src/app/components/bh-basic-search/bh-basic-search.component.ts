import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { QueryBody, RequestQuery, RequestScope, ResultSetPaging, RequestPagination, RequestFilterQueries } from '@alfresco/js-api';
import { SearchService, AppConfigService } from '@alfresco/adf-core';
import { of } from 'rxjs';
import { BhSearchService } from 'app/services/bh-search.service';
import { BhApiService } from 'app/services/bh-api.service';
import { BhDocumentLinkComponent } from 'app/dialog/bh-document-link/bh-document-link.component';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-bh-basic-search',
  templateUrl: './bh-basic-search.component.html',
  styleUrls: ['./bh-basic-search.component.scss']
})
export class BhBasicSearchComponent implements OnInit {

  searchTerm = new FormControl('');
  loading = false;
  showResults = false;
  searchResults = [];

  showViewer = false;
  nodeId: string;

  constructor(private appConfig: AppConfigService,
    private search: SearchService,
    private searchService: BhSearchService,
    private bhApi: BhApiService,
    private dialog: MatDialog) { }

  ngOnInit() {
  }

  onSearch(type: string, e: any) {
    // console.log('search event : ', e);
    const kc = e.code;
    const k = e.key;
    const v = this.searchTerm.value;
    if ((v !== '' && v !== undefined && v !== null) && v.length >= 3) {
      let q = '(' +
      'cm:name:"*' + v + '*" OR ' +
      'cm:title:"*' + v + '*" OR ' +
      'cm:description:"*' + v + '*" OR ' +
      'TEXT:"*' + v + '*" OR ' +
      'bhqms:reference:"*' + v + '*"' +
      ')';
      if (type === 'min' && (kc !== 'Enter' && k !== 'Enter')) {
        if (!this.loading) {
          this.onBasicSearch(q);
        }
      } else if (type === 'max') {
        this.onCloseResults();
        q = ' AND ' + q;

        const queryParams = new Object();
        queryParams['searchTerm'] = v;
        this.searchService.showBasicSearch({ 'queryParams': queryParams});
        // this.searchService.updateAdvancedSearchQuery(q);
      }
    } else {
      this.showResults = false;
    }
  }

  onBasicSearch(q: string) {
    const queryBody: QueryBody = {
      query: new RequestQuery({
        language: 'afts',
        query: this.appConfig.get('searchRootPath') + ' AND ' + q
      }),
      paging: new RequestPagination({
        maxItems: 5,
        skipCount: 0
      }),
      include: ['properties'],
      filterQueries: new RequestFilterQueries(this.appConfig.get('search')['filterQueries'])
    };

    this.loading = true;
    this.searchResults = [];
    this.bhApi.searchByQueryBody(queryBody).toPromise().then(
      (r: ResultSetPaging) => {
        if (r && r.list && r.list.entries && r.list.entries.length > 0) {
          this.searchResults = r.list.entries;
        }
        this.loading = false;
        this.showResults = true;
      },
      (e) => {
        this.loading = false;
        this.showResults = false;
        console.log('Basic Search Error : ', e);
      }
    );
  }

  onCloseResults() {
    this.searchTerm.setValue('');
    this.searchResults = [];
    this.showResults = false;
    this.loading = false;
  }

  onPreview(entry: any) {
    if (entry && entry.isFile) {
      const type = entry.properties ? entry.properties['bhqms:content_category'] : undefined;
      if (type === 'Document') {
        this.nodeId = entry.id;
        this.showViewer = true;
      } else if (type === 'URL') {
        this.openDocumentLink('url', entry);
      }
    }
  }

  onViewerToggle(event) {
    this.nodeId = null;
    this.showViewer = event;
  }

  openDocumentLink(type: string, entry: any) {
    const dialogRef = this.dialog.open(BhDocumentLinkComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: {
        node : entry,
        type : type
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

  onItemClicked(e: any) {
    console.log('onItemClicked : ', e);
  }

  onSearchChange(e: any) {
    console.log('onSearchChange : ', e);
  }

  onSearchSubmit(e: any) {
    console.log('onSearchSubmit : ', e);
  }

}
