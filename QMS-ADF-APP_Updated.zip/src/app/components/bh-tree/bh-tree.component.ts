import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef } from '@angular/core';
import { PreviewService } from '../../services/preview.service';
import {
  AlfrescoApiService,
  AppConfigService,
  IdentityUserModel,
  PeopleContentService,
  IdentityUserService } from '@alfresco/adf-core';

import { BhStartWorkflowComponent } from '../bh-start-workflow/bh-start-workflow.component';
import { MatDialog, MatDialogConfig, MatSelect, MatOption, MatInput, MatDatepickerInput  } from '@angular/material';

import { ActivatedRoute, Router, NavigationStart, RoutesRecognized, NavigationEnd, Params } from '@angular/router';

import { WfAdminTaskComponent } from '../workflow/wf-admin-task/wf-admin-task.component';
import { WfIntakesTaskComponent } from '../workflow/wf-intakes-task/wf-intakes-task.component';
import { FormGroup, FormControl } from '@angular/forms';

import { BhSearchService } from '../../services/bh-search.service';
import { Subscription } from 'rxjs';
import { GenericFacetResponse, PersonEntry, Person, QueryBody, RequestQuery } from '@alfresco/js-api';
import { BhDataListService } from 'app/services/bh-data-list.service';
import { Moment } from 'moment';

import {MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

import { filter, switchMap, map } from 'rxjs/operators';
import { BhInfoDialogComponent } from 'app/dialog/bh-info-dialog/bh-info-dialog.component';
import { BhApiService } from 'app/services/bh-api.service';
import { BhSearchFieldComponent, EventOutput } from '../bh-search-field/bh-search-field.component';
import { SelectUserDialogComponent } from '../select-user-dialog/select-user-dialog.component';
import { RequestOptions, BhWebscriptService } from 'app/services/bh-webscript.service';

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

interface User {
  email?: string;
  firstName?: string;
  lastName?: string;
  id?: string;
}

@Component({
  selector: 'app-bh-tree',
  templateUrl: './bh-tree.component.html',
  styleUrls: ['./bh-tree.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },

    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
})
export class BhTreeComponent implements OnInit, OnDestroy {

  user: User = {
    email: '',
    firstName: '',
    lastName: '',
    id: ''
  };
  productCompany: string;

  private qName = '{http://www.bakerhughes.com/model/content/1.0}';
  private facetProperties = {
    function : 'function',
    subfunction : 'sub_function',
    site : 'site'
  };

  facetOptions = {
    function : [],
    subfunction : [],
    site : []
  };

  facetFormControls = {
    function: new FormControl(new Array()),
    subfunction: new FormControl(new Array()),
    site: new FormControl(new Array())
  };

  private advancedSearchProperties = {
    documentname : 'cm:name',
    documentreferencenumber : 'reference',
    productcompany : 'product_company',
    productline : 'product_line',
    subproductline : 'sub_product_line',
    site : 'site',
    function : 'function',
    subfunction : 'sub_function',
    documenttype : 'document_type',
    effectivedate : 'effective_date',
    publisheddate : 'published_date',
    expirydate : 'expiry_date',
    isoelement : 'iso_element',
    userrole : 'user_role',
    process : 'process',
    subprocess : 'sub_process',
    contentcategory : 'content_category',
    language : 'language_code',
    documentauthor : 'document_author_noderef',
    documentadmin : 'document_admin_noderef',
    functionalowner : 'functional_owner_noderef',
    documentumobjectid : 'dctm_object_id'
  };

  advancedSearchOptions = {
    documentname : '',
    documentreferencenumber : '',
    productcompany : '',
    productline : [],
    subproductline : [],
    site : [],
    function : [],
    subfunction : [],
    documenttype : [],
    isoelement : [],
    userrole : [],
    process : [],
    subprocess : [],
    contentcategory : [],
    language : [],
    documentauthor : [],
    documentadmin : [],
    functionalowner : [],
    documentumobjectid : ''
  };

  advancedSearchFormControls = {
    documentname : new FormControl(''),
    documentreferencenumber : new FormControl(''),
    productcompany : new FormControl(''),
    productline : new FormControl(new Array()),
    subproductline : new FormControl(new Array()),
    site : new FormControl(new Array()),
    function : new FormControl(new Array()),
    subfunction : new FormControl(new Array()),
    documenttype : new FormControl(new Array()),
    effectivedate : new FormGroup({
      starteffectivedate: new FormControl(),
      endeffectivedate: new FormControl()
    }),
    publisheddate : new FormGroup({
      startpublisheddate: new FormControl(),
      endpublisheddate: new FormControl()
    }),
    expirydate : new FormGroup({
      startexpirydate: new FormControl(),
      endexpirydate: new FormControl()
    }),
    isoelement : new FormControl(new Array()),
    userrole : new FormControl(new Array()),
    process : new FormControl(new Array()),
    subprocess : new FormControl(new Array()),
    contentcategory : new FormControl(new Array()),
    language : new FormControl(new Array()),
    documentauthor : new FormControl(new Array()),
    documentadmin : new FormControl(new Array()),
    functionalowner : new FormControl(new Array()),
    documentumobjectid : new FormControl('')
  };

  nodeId = '';

  expanded = 1;
  expandAdditionalRefiners = true;
  expandAdvancedSearch = false;

  panelOneState = true;
  panelTwoState = false;
  panelThreeState = false;

  @ViewChild('selectDocumentName')
  selectDocumentName: BhSearchFieldComponent;

  @ViewChild('selectDocumentReferenceNumber')
  selectDocumentReferenceNumber: BhSearchFieldComponent;

  @ViewChild('selectProductCompany')
  selectProductCompany: BhSearchFieldComponent;

  @ViewChild('selectProductLine')
  selectProductLine: BhSearchFieldComponent;

  @ViewChild('selectSubProductLine')
  selectSubProductLine: BhSearchFieldComponent;

  @ViewChild('selectSite')
  selectSite: BhSearchFieldComponent;

  @ViewChild('selectFunction')
  selectFunction: BhSearchFieldComponent;

  @ViewChild('selectSubFunction')
  selectSubFunction: BhSearchFieldComponent;

  @ViewChild('selectDocumentType')
  selectDocumentType: BhSearchFieldComponent;

  @ViewChild('selectIsoElement')
  selectIsoElement: BhSearchFieldComponent;

  @ViewChild('selectUserRole')
  selectUserRole: BhSearchFieldComponent;

  @ViewChild('selectProcess')
  selectProcess: BhSearchFieldComponent;

  @ViewChild('selectSubProcess')
  selectSubProcess: BhSearchFieldComponent;

  @ViewChild('selectContentCategory')
  selectContentCategory: BhSearchFieldComponent;

  @ViewChild('selectLanguage')
  selectLanguage: BhSearchFieldComponent;

  @ViewChild('selectDocumentAuthor')
  selectDocumentAuthor: BhSearchFieldComponent;

  @ViewChild('selectDocumentAdmin')
  selectDocumentAdmin: BhSearchFieldComponent;

  @ViewChild('selectFunctionalOwner')
  selectFunctionalOwner: BhSearchFieldComponent;

  @ViewChild('selectDocumentumObjectId')
  selectDocumentumObjectId: BhSearchFieldComponent;

  protected subscriptions: Subscription[] = [];

  constructor(private appConfig: AppConfigService,
    private preview: PreviewService,
    private apiService: AlfrescoApiService,
    private bhApi: BhApiService,
    private webscript: BhWebscriptService,
    private dialog: MatDialog,
    private changeDetector: ChangeDetectorRef,
    private router: Router,
    private route: ActivatedRoute,
    private searchService: BhSearchService,
    private dataList: BhDataListService,
    private peopleService: PeopleContentService,
    private identityUserService: IdentityUserService) {

  }

  ngOnInit() {

    this.subscriptions.push(
      this.searchService.getFacetData().subscribe(
        (facetData) => {
          // TO DO : Document List Table Filter Update
          // this.updateFacetData(facetData);
        }
      ),
      this.searchService.getAdvancedSearchParams().subscribe(
        (queryParams) => {
          setTimeout(() => this.applyQueryParams(queryParams));
        }
      ),
      this.router.events.pipe(
        filter(event => event instanceof NavigationEnd)
      ).subscribe((event: NavigationEnd) => {
        this.updateRouteChanges();
      })
    );

    this.updateRouteChanges();

    this.bhApi.getNodeInfo('-root-', {
            includeSource: true,
            include: ['path', 'properties', 'association'],
            relativePath: this.appConfig.get('rootFolder')
        })
        .then(node => {
            // console.log(node);
            this.nodeId = node.id;
            this.changeDetector.detectChanges();
        });

    // User details from Data List
    this.getDatalistUser();

    // Advanced Search Field options - data list
    // Product Company
    this.getDataList('productCompany', 'productcompany', null);
    // Document Type
    // this.getDataList('documentType', 'documenttype', null);  // Demo purpose - commented out, will check later
    // this.getDataList('documentType', 'documenttype', 'productCompany');
    // ISO Element
    this.getDataList('isoElement', 'isoelement', null);
    // Process
    this.getDataList('process', 'process', null);
    // Content Category
    this.getDataList('contentCategory', 'contentcategory', null);
    // Language
    this.getDataList('language', 'language', null);
    // User Role
    this.getDataList('userRole', 'userrole', null);

  }

  updateRouteChanges() {
    // console.log('this.router.url : ', this.router.url);
    const isHome = this.router.url === '/';
    const isSearch = this.router.url.indexOf('/search') === 0;
    const isAdvancedSearch = this.router.url.indexOf('/advanced-search') === 0;
    const isDocumentView = this.router.url.indexOf('/document-view') === 0;
    const isFolderView = this.router.url.indexOf('/folder-view') === 0;

    const hasFacetParams = this.router.url.indexOf('facetParams') !== -1;

    const isTask = this.router.url.indexOf('/task') === 0;
    const isWorkflow = this.router.url.indexOf('/workflow') === 0;
    if (isHome ||
        isFolderView ||
        isDocumentView ||
        isSearch ||
        isAdvancedSearch) {
      this.expanded = 1;

      if (isHome || isFolderView) {
        this.expandAdditionalRefiners = false;
        setTimeout(
          () => {
            // this.arClearSelection();
            // this.arClearOptions();
            this.asClearSelection();
          });
      }

      if (isDocumentView) {
        setTimeout(
          () => {
            if (!hasFacetParams) {
              // this.arClearSelection();
            }
          });
      }

      if (isSearch) {
        setTimeout(
          () => {
            if (!hasFacetParams) {
              // this.arClearSelection();
            }
            this.asClearSelection();
          });
      }

      if (isAdvancedSearch) {
        this.expandAdvancedSearch = true;
        setTimeout(
          () => {
            if (!hasFacetParams) {
              // this.arClearSelection();
            }
          });
      } else {
        this.expandAdvancedSearch = false;
      }
    } else if (isTask || isWorkflow) {
      this.expanded = 3;
      // this.arClearSelection();
      // this.arClearOptions();
      this.asClearSelection();
    }
  }

  arClearOptions() {
    this.facetOptions = {
      function : [],
      subfunction : [],
      site : []
    };
  }

  getDataList(field: string, fieldData: string, parent: string) {
    const p = parent !== null ? parent.toLowerCase() : null;
    const pl = p !== null ? this.advancedSearchFormControls[p].value : null;
    const isEmpty = Array.isArray(pl) ? pl.length === 0 : pl === '' || pl === undefined;
    if (parent !== null && isEmpty) {
      this.resetDependencyValues(parent);
    } else {
      this.advancedSearchFormControls[fieldData].setValue('');
      this.resetDependencyValues(field);

      this.dataList.getFormData(field, this.getFormData()).then(
        (r) => {
          const data = new Array();
          if (r.Values && r.Values.length > 0) {
            r.Values.forEach((item) => {
              data.push({ id: item, name: item });
            });
          }
          this.advancedSearchOptions[fieldData] = data;
        }
      );
    }
  }

  getFormData(): any {
    return {
      'productCompany' : this.advancedSearchFormControls.productcompany.value,
      'productLine' : this.advancedSearchFormControls.productline.value,
      'function' : this.advancedSearchFormControls.function.value,
      'process' : this.advancedSearchFormControls.process.value
    };
  }

  resetDependencyValues(parent: string) {
    if (parent === 'productCompany') {
      /* this.advancedSearchOptions.productline = [];
      this.advancedSearchFormControls.productline.setValue([]);
      this.selectProductLine.onClearSelect(); */
      this.resetValue('ProductLine', 'select', true, true);

      /* this.advancedSearchOptions.subproductline = [];
      this.advancedSearchFormControls.subproductline.setValue([]);
      this.selectSubProductLine.onClearSelect(); */
      this.resetValue('SubProductLine', 'select', true, true);

      /* this.advancedSearchOptions.site = [];
      this.advancedSearchFormControls.site.setValue([]);
      this.selectSite.onClearSelect(); */
      this.resetValue('Site', 'select', true, true);

      /* this.advancedSearchOptions.function = [];
      this.advancedSearchFormControls.function.setValue([]); */
      this.resetValue('Function', 'select', true, true);

      /* this.advancedSearchOptions.subfunction = [];
      this.advancedSearchFormControls.subfunction.setValue([]); */
      this.resetValue('SubFunction', 'select', true, true);

      /* this.advancedSearchOptions.documenttype = [];
      this.advancedSearchFormControls.documenttype.setValue([]); */
      this.resetValue('DocumentType', 'select', true, true);
    } else if (parent === 'productLine') {
      /* this.advancedSearchOptions.subproductline = [];
      this.advancedSearchFormControls.subproductline.setValue([]); */
      this.resetValue('SubProductLine', 'select', true, true);

      /* this.advancedSearchOptions.site = [];
      this.advancedSearchFormControls.site.setValue([]); */
      this.resetValue('Site', 'select', true, true);
    } else if (parent === 'function') {
      /* this.advancedSearchOptions.subfunction = [];
      this.advancedSearchFormControls.subfunction.setValue([]); */
      this.resetValue('SubFunction', 'select', true, true);
    } else if (parent === 'process') {
      /* this.advancedSearchOptions.subprocess = [];
      this.advancedSearchFormControls.subprocess.setValue([]); */
      this.resetValue('SubProcess', 'select', true, true);
    }
  }

  ngOnDestroy() {
    this.subscriptions.forEach(subscription => subscription.unsubscribe());
    this.subscriptions = [];
  }

  getDatalistUser() {
    const person: IdentityUserModel = this.identityUserService.getCurrentUserInfo();
    const iue = person.email; // Identity user email
    if (iue !== undefined && iue !== null && iue !== '') {
      this.getUserProductCompany(iue.trim());
    } else if (this.apiService.getInstance().isEcmLoggedIn()) {
      const p = this.peopleService.getCurrentPerson();
      p.toPromise().then(
        (r: PersonEntry) => {
          console.log('Logged In user Details r : ', r);
          if (r && r.entry) {
            const ep: Person = r.entry;
            const eue = ep.email;
            if (eue !== undefined && eue !== null && eue !== '') {
              this.getUserProductCompany(eue.trim());
            } else {
              this.openInfoDialog(
                'Info',
                true,
                'Email id not available in the system and some of the functionality will not work as expected,' +
                ' Please contact Administrator');
            }
          } else {
            this.openInfoDialog(
              'Info',
              true,
              'Email id not available in the system and some of the functionality will not work as expected' +
              ' Please contact Administrator');
          }
        },
        (c) => {
          this.openInfoDialog(
            'Info',
            true,
            'Unable to get the ECM User Details,' +
            'Please refresh the page or contact Administrator');
        }
      );
    } else {
      this.openInfoDialog(
        'Info',
        true,
        'User Details not available,' +
        'Please contact Administrator');
    }
  }

  buildUserQuery(e: string): string {
    this.user.email = e;
    const a = 'Active';
    let q = 'TYPE:"bhdl:hrSystemDataListItem"'
          + ' AND (@bhdl:employee_status:"' + a + '"'
          + ' OR @bhdl:employee_status:"' + a.toLowerCase() + '"'
          + ' OR @bhdl:employee_status:"' + a.toUpperCase() + '")'
          + ' AND @bhdl:is_employee_active:true';
    q += ' AND (@bhdl:employee_email_id:"' + e + '"';
    q += ' OR @bhdl:employee_email_id:"' + e.toLowerCase() + '"';
    q += ' OR @bhdl:employee_email_id:"' + e.toUpperCase() + '")';
    return q;
  }

  getUserProductCompany(e: string) {
    const q = this.buildUserQuery(e);
    const queryBody: QueryBody = {
      query: new RequestQuery({
        language: 'afts',
        query: q
      }),
      include: ['path', 'properties', 'allowableOperations', 'permissions', 'aspectNames', 'association']
    };

    this.bhApi.searchByQueryBody(queryBody).toPromise().then(
      r => {
        if (r && r.list && r.list.entries && r.list.entries.length > 0) {
          const entry = r.list.entries[0].entry;
          console.log('data list user entry : ', entry);
          let pc = entry.properties['bhdl:employee_business_segment'];
          if (pc !== undefined && pc !== null && pc !== '') {
            pc = pc.toLowerCase().trim();
            if (pc === 'turbomachinery process solutions') {
              this.productCompany = 'BH-TPS Turbomachinery & Process Solutions';
            } else if (pc === 'oilfield services') {
              this.productCompany = 'BH-OFS Oilfield Services';
            } else if (pc === 'digital solutions') {
              this.productCompany = 'BH-DS Digital Solutions';
            } else if (pc === 'headquarters') {
              this.productCompany = 'BH-Global';
            } else {
              // this.productCompany = 'BH-TPS Turbomachinery & Process Solutions';
              this.openInfoDialog(
                'Info',
                true,
                '"Product Company or Business Segment" details not available in "Data List" as expected,' +
                ' Please contact Administrator');
            }
          }
        } else {
          this.openInfoDialog(
            'Info',
            true,
            'User Details Not available in "Data List" and some of the functionality will not work as expected,' +
            ' Please contact Administrator');
        }
      },
      (c) => {
        this.openInfoDialog(
          'Info',
          true,
          'Unable to get the Data List User Details,' +
          'Please refresh the page or contact Administrator');
      }
    );
  }

  updateFacetData(facetData: GenericFacetResponse[]) {
    facetData.forEach(facet => {
      const name = facet.label;
      const tempName = name.replace(/ /g, '').toLowerCase();
      const tempQuery = this.qName + this.facetProperties[name];
      const options = new Array();
      facet.buckets.forEach(bucket => {
        const label = bucket.label;
        if (label !== undefined && label !== '' && label !== null) {
          const count: string = bucket.metrics[0].value['count'].toString();
          /* const count = bucket.metrics.forEach(metric => {
            if (metric.type === 'count') {
              return metric.value['count'];
            }
          }); */

          // Multiple - value - labels
          const labels = label.split(',');
          if (labels.length === 1) {
            const option = new Object();
            const query = bucket.filterQuery;
            if (query !== undefined && query !== '' && query !== null) {
              option['query'] = query;
            } else {
              option['query'] = tempQuery + ':\'' + label + '\'';
            }
            option['count'] = count;
            option['label'] = label;
            options.push(option);
          } else {
            // TO DO: multi value labels and queries
            labels.forEach(l => {
              const option = new Object();
              option['query'] = tempQuery + ':\'*' + l + '*\'';
              option['label'] = l;

              const index = options.findIndex(item => item.label === l);
              if (index > -1) {
                option['count'] = parseInt(count, 0) + 1;
                options[index] = option;
              } else {
                option['count'] = count;
                options.push(option);
              }
            });
          }
        }
        /* if (Object.keys(option).length > 0) {
          options.push(option);
        } */
      });
      if (options.length > 0) {
        this.facetOptions[name] = options;
      }
      this.changeDetector.detectChanges();
    });

    // By Default clear all selection
    // this.arClearSelection();

  }

  applyQueryParams(params: any) {
    const keys = Object.keys(params);
    if (keys.length > 0) {
      keys.forEach(key => {
        const value: string = params[key];
        if (value !== '' && value !== undefined && value !== null ) {
          const values = value.split(',');
          if (key.toLowerCase().includes('date') && values.length === 2) {
            if (key === 'effectivedate') {
              this.advancedSearchFormControls.effectivedate.setValue({
                starteffectivedate : values[0] !== '' ? new Date(values[0]) : null,
                endeffectivedate : values[1] !== '' ? new Date(values[1]) : null
              });
            } else if (key === 'publisheddate') {
              this.advancedSearchFormControls.publisheddate.setValue({
                startpublisheddate : values[0] !== '' ? new Date(values[0]) : null,
                endpublisheddate : values[1] !== '' ? new Date(values[1]) : null
              });
            } else if (key === 'expirydate') {
              this.advancedSearchFormControls.expirydate.setValue({
                startexpirydate : values[0] !== '' ? new Date(values[0]) : null,
                endexpirydate : values[1] !== '' ? new Date(values[1]) : null
              });
            }
          } else if (key === 'facetParams') {
            // TO DO : Document List Table Filter Update
            // By Default clear all selection
            /* this.arClearSelection();
            const facetParam = JSON.parse(value);
            Object.keys(facetParam).forEach((facetKey) => {
              const facetValue: string = facetParam[facetKey];
              if (facetValue !== undefined && facetValue !== null && facetValue !== '') {
                // TO DO: apply facet filters
                this.facetFormControls[facetKey].setValue(facetValue.split(','));
              }
            }); */
          } else {
            if (this.advancedSearchFormControls[key] !== null && this.advancedSearchFormControls[key] !== undefined) {
              if (key === 'documentname' ||
              key === 'documentreferencenumber' ||
              key === 'productcompany' ||
              key === 'documentumobjectid') {
                this.advancedSearchFormControls[key].setValue(value);
              } else if (key === 'documentauthor' ||
              key === 'documentadmin' ||
              key === 'functionalowner') {
                const userValue = value;
                if (userValue !== undefined && userValue !== '' && userValue !== null) {
                  this.loadDataFromNodeRef(userValue, key);
                }
              } else {
                this.advancedSearchFormControls[key].setValue(values);
              }
            }
          }
        }
      });
    }
  }

  onExpand(event) {
    /* console.log('onExpand : ', event);
    if (event === 1) {
      this.expanded = 1;
      this.panelOneState = true;
      this.preview.showDocumentList('');
    } else if (event === 2) {
      this.expanded = 2;
      this.panelTwoState = true;
    } else if (event === 3) {
      this.expanded = 3;
      this.panelThreeState = true;
      this.preview.showTasksList('');
    } */
  }

  onClick(event) {
    // console.log("Tree node : ", event);
    const entry = event.entry;
    if (entry) {
      if (entry.isFile) {
        this.preview.showResource(entry.id);
      } else {
        const url = this.router.url;
        if (url.includes('document-view')) {
          this.preview.showDocumentListView(entry.id);
        } else {
          this.preview.showDocumentList(entry.id);
        }
        // alert(`Tree node : ${entry.name}`);
      }
    }
  }

  openStartWorkflowDialog(event, t) {

    // Testing Purpose only - uncomment - start
    const email = 'gl00640582@techmahindra.com';
    this.productCompany = 'BH-DS Digital Solutions';
    // Testing Purpose only - uncomment - end

    // Testing Purpose only - comment - start
    // const email = this.user.email;


    // if (email === undefined || email === null || email === '') {
    if (email === undefined || email === null) {
    // Testing Purpose only - comment - end
      this.openInfoDialog(
        'Info',
        true,
        'Email id not available in the system,' +
        ' Please contact Administrator');
    } else if (this.productCompany === undefined || this.productCompany === null || this.productCompany === '') {
      this.openInfoDialog('Info', true, 'User Details Not available in "DataList", Please contact Administrator');
    } else if (this.productCompany === 'BH-Global') {
      this.openInfoDialog('Info', true, 'You are not allowed to raise "New QMS Document Request"');
    } else {
      const dialogConfig = new MatDialogConfig();

      dialogConfig.disableClose = true;
      dialogConfig.autoFocus = true;
      dialogConfig.minHeight = '550px';
      // dialogConfig.height = '84%';
      // dialogConfig.maxHeight = '84%';
      // dialogConfig.maxHeight = '100%';
      dialogConfig.minWidth = '300px';
      dialogConfig.width = '50%';
      dialogConfig.maxWidth = '100%';
      dialogConfig.panelClass = 'start-workflow-dialog';
      dialogConfig.data = { requestType: 'new' };

      let dialogRef = null;

      if (t === 'new') {
        dialogConfig.height = '84%';
        dialogConfig.maxHeight = '100%';
        dialogConfig.data = { requestType: 'new' };
        dialogRef = this.dialog.open(BhStartWorkflowComponent, dialogConfig);
      } else if (t === 'admin') {
        dialogConfig.height = '84%';
        dialogConfig.maxHeight = '100%';
        dialogConfig.data = { requestType: 'adminTask' };
        dialogRef = this.dialog.open(WfAdminTaskComponent, dialogConfig);
      } else if (t === 'intakes') {
        dialogConfig.maxHeight = '84%';
        dialogRef = this.dialog.open(WfIntakesTaskComponent, dialogConfig);
      }

      // dialogConfig.data = { requestType: 'adminTask' }

      // const dialogRef = this.dialog.open(BhStartWorkflowComponent, dialogConfig);
      // const dialogRef = this.dialog.open(WfAdminTaskComponent, dialogConfig);
      // const dialogRef = this.dialog.open(WfIntakesTaskComponent, dialogConfig);

      dialogRef.componentInstance.params = {
        maximize: () => {
          dialogRef.updateSize('100%', '100%');
          // return event;
        },
        resize: () => {
          if (t === 'intakes') {
            dialogRef.updateSize('50%', 'auto');
          } else {
            dialogRef.updateSize('50%', '84%');
          }
        }
      };

      dialogRef.afterClosed().subscribe(
        val => console.log('Start Work flow Dialog output:', val)
      );
    }

  }

  onSelectionChange(e, id) {
    console.log(id + ' : selection event : ', e.value);
    if (id === 'productCompany') {
      this.getDataList('documentType', 'documenttype', 'productCompany');
      this.getDataList('productLine', 'productline', 'productCompany');
      this.getDataList('function', 'function', 'productCompany');
    }

    if (id === 'productLine') {
      this.getDataList('subProductLine', 'subproductline', 'productLine');
      this.getDataList('site', 'site', 'productLine');
    }

    if (id === 'function') {
      if (this.advancedSearchFormControls.productcompany.value !== 'BH-TPS Turbomachinery & Process Solutions') {
        this.getDataList('subFunction', 'subfunction', 'function');
      }
    }

    if (id === 'process') {
      this.getDataList('subProcess', 'subprocess', 'process');
    }
  }

  onSelectActionNew(e: EventOutput) {
    console.log(e.action + ' action event : ', e.selection);
      if (e.action === 'clear') {
        e.selection.options.forEach( (item: MatOption) => item.deselect());
      } else if (e.action === 'all') {
        e.selection.options.forEach( (item: MatOption) => item.select());
      } else if ( e.action === 'clearAllAR' ) {
        // this.arClearSelection();
      } else if ( e.action === 'clearAllAS') {
        this.asClearSelection();
      }
  }

  onSelectAction(s: MatSelect, a: string) {
    console.log(a + ' action event : ', s);
    if ( a === 'clear' ) {
      s.options.forEach( (item: MatOption) => item.deselect());
    } else if ( a === 'all' ) {
      s.options.forEach( (item: MatOption) => item.select());
    } else if ( a === 'clearAllAR') {
      // this.arClearSelection();
    } else if ( a === 'clearAllAS') {
      this.asClearSelection();
    }
  }

  applyFacetFilter() {
    /* let query = '';
    // Iterating facet fields
    Object.keys(this.facetFormControls).forEach(key => {
      const values: Array<string> =  this.facetFormControls[key].value;
      // Iterating facet field values
      if (values.length > 0) {
        query += ' AND (';
        for (let i = 0; i < values.length; i++) {
          // Iterating options --> queries
          this.facetOptions[key].forEach(option => {
            if (option.label === values[i]) {
              query += option.query;
            }
          });
          if ( values.length > 1 && values.length > (i + 1)) {
            query += ' OR ';
          }
        }
        query += ')';
      }
    });
    console.log('facet query : ', query);
    this.searchService.updateFacetQuery(query);
    // TO DO : Show info message --> select any refiners to apply */

    const facetQuery = new Object();
    Object.keys(this.facetFormControls).forEach(key => {
      const values: Array<string> =  this.facetFormControls[key].value;
      // Iterating facet field values
      if (values.length > 0) {
        facetQuery[key] = values.join(',');
      }
    });

    // if (Object.keys(facetQuery).length > 0) {
      console.log('Facet Query : ', facetQuery);
      console.log('Facet Query Json String : ', JSON.stringify(facetQuery));

      const isSearch = this.router.url.indexOf('/search') === 0;
      const isAdvancedSearch = this.router.url.indexOf('/advanced-search') === 0;
      const isDocumentView = this.router.url.indexOf('/document-view') === 0;

      const facetQueryValue = Object.keys(facetQuery).length > 0 ? JSON.stringify(facetQuery) : '';
      if (isDocumentView) {
        this.route.firstChild.params.subscribe(params => {
          const id = params.nodeId;
          if (id !== null && id !== '' && id !== undefined) {
            const queryParams = new Object();
            if (facetQueryValue !== undefined && facetQueryValue !== null && facetQueryValue !== '') {
              queryParams['facetParams'] = facetQueryValue;
            }
            this.searchService.showDocumentViewSearch(id, {'queryParams': queryParams});
          }
        });
      } else {
        // Query Params illegal access
        const queryParamsMap = this.route.queryParams['value'];
        console.log('QueryParamsMap : ', queryParamsMap);
        const queryParams = new Object();
        if (isSearch) {
          queryParams['searchTerm'] = queryParamsMap['searchTerm'];
          if (facetQueryValue !== undefined && facetQueryValue !== null && facetQueryValue !== '') {
            queryParams['facetParams'] = facetQueryValue;
          }
          this.searchService.showBasicSearch({'queryParams': queryParams});
        } else if (isAdvancedSearch) {
          Object.keys(this.advancedSearchProperties).forEach((key) => {
            queryParams[key] = queryParamsMap.hasOwnProperty(key) ? queryParamsMap[key] : null;
          });
          if (facetQueryValue !== undefined && facetQueryValue !== null && facetQueryValue !== '') {
            queryParams['facetParams'] = facetQueryValue;
          }
          this.searchService.showAdvancedSearch({'queryParams': queryParams});
        }

        /* this.route.queryParams.forEach((params: Params) => {
          const queryParams = new Object();
          if (isSearch) {
            queryParams['searchTerm'] = params['searchTerm'];
            // queryParams['facetParams'] = JSON.stringify(facetQuery);
            queryParams['facetParams'] = facetQueryValue;
            this.searchService.showBasicSearch({'queryParams': queryParams});
          } else if (isAdvancedSearch) {
            Object.keys(this.advancedSearchProperties).forEach((key) => {
              queryParams[key] = params.hasOwnProperty(key) ? params[key] : null;
            });
            // queryParams['facetParams'] = JSON.stringify(facetQuery);
            queryParams['facetParams'] = facetQueryValue;
            this.searchService.showAdvancedSearch({'queryParams': queryParams});
          }
        }); */
      }
    // }


  }

  /* arClearSelection() {
    this.facetFormControls.function.setValue([]);
    if ( this.selectFunction !== undefined && this.selectFunction.options.length > 0 ) {
      this.selectFunction.options.forEach( (item: MatOption) => item.deselect());
    }

    this.facetFormControls.subfunction.setValue([]);
    if ( this.selectSubFunction !== undefined && this.selectSubFunction.options.length > 0 ) {
      this.selectSubFunction.options.forEach( (item: MatOption) => item.deselect());
    }

    this.facetFormControls.site.setValue([]);
    if ( this.selectSite !== undefined && this.selectSite.options.length > 0 ) {
      this.selectSite.options.forEach( (item: MatOption) => item.deselect());
    }
  } */

  applyAdvancedSearch() {
    /* let query = '';
    // Iterating Advanced Search Fields
    Object.keys(this.advancedSearchFormControls).forEach(key => {
      const values =  this.advancedSearchFormControls[key].value;
      if (values) {
        const tempQuery = this.qName + this.advancedSearchProperties[key];
        if (key.toLowerCase().includes('date')) {
          const startDate: Moment = values['start' + key];
          const endDate: Moment = values['end' + key];
          if ((startDate !== undefined && startDate !== null)
          && (endDate !== undefined && endDate !== null)) {
            query += ' AND (';
            query += tempQuery + ':[\'' + startDate.toISOString() + '\' TO \'' + endDate.toISOString() + '\']';
            query += ')';
          }

        } else if (values.length > 0) {
          query += ' AND (';
          for (let i = 0; i < values.length; i++) {
            query += tempQuery + ':\'' + values[i] + '\'';
            if ( values.length > 1 && values.length > (i + 1)) {
              query += ' OR ';
            }
          }
          query += ')';
        }
      }
    });

    console.log('Advanced Search Query : ', query);
    if (query !== '' && query !== undefined && query !== null) {
      this.searchService.updateAdvancedSearchQuery(query);
    } */

    // TO DO: empty and date validation

    const queryParams = new Object();
    Object.keys(this.advancedSearchFormControls).forEach(key => {
      const values =  this.advancedSearchFormControls[key].value;
      if (values) {
        if (key.toLowerCase().includes('date')) {
          const startDate = values['start' + key];
          const endDate = values['end' + key];
          const hasStartDate = (startDate !== '' && startDate !== undefined && startDate !== null);
          const hasEndDate = (endDate !== '' && endDate !== undefined && endDate !== null);
          if (hasStartDate && hasEndDate) {
            queryParams[key] = startDate.toISOString() + ',' + endDate.toISOString();
          } else if (hasStartDate && !hasEndDate) {
            queryParams[key] = startDate.toISOString() + ',';
          } else if (!hasStartDate && hasEndDate) {
            queryParams[key] = ',' + endDate.toISOString();
          }
        } else if (values.length > 0) {
          if (key === 'documentname' ||
              key === 'productcompany' ||
              key === 'documentumobjectid') {
            queryParams[key] = values.toString();
          } else if (key === 'documentauthor' ||
          key === 'documentadmin' ||
          key === 'functionalowner') {
            queryParams[key] = Array.isArray(values) ? ( values.length > 0 ? values[0].userName : '' ) : values.userName;
          } else if (key === 'documentreferencenumber') {
            // queryParams[key] = values.toString().toUpperCase();
            queryParams[key] = values.toString();
          } else {
            queryParams[key] = Array.isArray(values) ? values.join(',') : values;
          }
        }
      }
    });

    if (Object.keys(queryParams).length > 0) {
      this.searchService.showAdvancedSearch({'queryParams': queryParams});
    } else {
      this.router.navigateByUrl('/');
    }
  }

  asClearSelection() {
    /* this.advancedSearchFormControls.documentname.setValue('');
    this.selectDocumentName.onClearInput(); */
    this.resetValue('DocumentName', 'input', false, false);

    /* this.advancedSearchFormControls.documentreferencenumber.setValue('');
    this.selectDocumentReferenceNumber.onClearInput(); */
    this.resetValue('DocumentReferenceNumber', 'input', false, false);

    /* this.advancedSearchFormControls.productcompany.setValue('');
    this.selectProductCompany.onClearSelect(); */
    this.resetValue('ProductCompany', 'select', false, false);

    /* this.advancedSearchFormControls.productline.setValue([]);
    this.selectProductLine.onClearSelect(); */
    this.resetValue('ProductLine', 'select', true, false);

    /* this.advancedSearchFormControls.subproductline.setValue([]);
    this.selectSubProductLine.onClearSelect(); */
    this.resetValue('SubProductLine', 'select', true, false);

    /* this.advancedSearchFormControls.site.setValue([]);
    this.selectSite.onClearSelect(); */
    this.resetValue('Site', 'select', true, false);

    /* this.advancedSearchFormControls.function.setValue([]);
    this.selectFunction.onClearSelect(); */
    this.resetValue('Function', 'select', true, false);

    /* this.advancedSearchFormControls.subfunction.setValue([]);
    this.selectSubFunction.onClearSelect(); */
    this.resetValue('SubFunction', 'select', true, false);

    /* this.advancedSearchFormControls.documenttype.setValue([]);
    this.selectDocumentType.onClearSelect(); */
    this.resetValue('DocumentType', 'select', true, false);

    /* this.advancedSearchFormControls.effectivedate.setValue({
      starteffectivedate : null,
      endeffectivedate : null
    }); */
    this.resetValue('effectivedate', 'date', false, false);

    /* this.advancedSearchFormControls.publisheddate.setValue({
      startpublisheddate : null,
      endpublisheddate : null
    }); */
    this.resetValue('publisheddate', 'date', false, false);

    /* this.advancedSearchFormControls.expirydate.setValue({
      startexpirydate : null,
      endexpirydate : null
    }); */
    this.resetValue('expirydate', 'date', false, false);

    /* this.advancedSearchFormControls.isoelement.setValue([]);
    this.selectIsoElement.onClearSelect(); */
    this.resetValue('IsoElement', 'select', true, false);

    /* this.advancedSearchFormControls.userrole.setValue([]);
    this.selectUserRole.onClearSelect(); */
    this.resetValue('UserRole', 'select', true, false);

    /* this.advancedSearchFormControls.process.setValue([]);
    this.selectProcess.onClearSelect(); */
    this.resetValue('Process', 'select', true, false);

    /* this.advancedSearchFormControls.subprocess.setValue([]);
    this.selectSubProcess.onClearSelect(); */
    this.resetValue('SubProcess', 'select', true, false);

    /* this.advancedSearchFormControls.contentcategory.setValue([]);
    this.selectContentCategory.onClearSelect(); */
    this.resetValue('ContentCategory', 'select', true, false);

    /* this.advancedSearchFormControls.language.setValue([]);
    this.selectLanguage.onClearSelect(); */
    this.resetValue('Language', 'select', true, false);

    /* this.advancedSearchFormControls.documentauthor.setValue('');
    this.selectDocumentAuthor.onClearInput(); */
    // this.resetValue('DocumentAuthor', 'input', false, false);
    this.advancedSearchFormControls.documentauthor.setValue([]);

    /* this.advancedSearchFormControls.documentadmin.setValue('');
    this.selectDocumentAdmin.onClearInput(); */
    // this.resetValue('DocumentAdmin', 'input', false, false);
    this.advancedSearchFormControls.documentadmin.setValue([]);

    /* this.advancedSearchFormControls.functionalowner.setValue('');
    this.selectFunctionalOwner.onClearInput(); */
    // this.resetValue('FunctionalOwner', 'input', false, false);
    this.advancedSearchFormControls.functionalowner.setValue([]);

    /* this.advancedSearchFormControls.documentumobjectid.setValue('');
    this.selectDocumentumObjectId.onClearInput(); */
    this.resetValue('DocumentumObjectId', 'input', false, false);
  }

  resetValue(field: string, type: string, isMultiple: boolean, clearData: boolean) {
    const f = field.toLowerCase();
    const sf = 'select' + field;
    if (type === 'input') {
      this.advancedSearchFormControls[f].setValue('');
      if (this[sf] !== undefined && this[sf] !== null) { this[sf].onClearInput(); }
    } else if (type === 'select') {
      if (isMultiple) {
        this.advancedSearchFormControls[f].setValue([]);
      } else {
        this.advancedSearchFormControls[f].setValue('');
      }
      if (this[sf] !== undefined && this[sf] !== null) { this[sf].onClearSelect(); }
      if (clearData) { this.advancedSearchOptions[f] = []; }
    } else if (type === 'date') {
      this.advancedSearchFormControls[f].controls['start' + f].setValue(null);
      this.advancedSearchFormControls[f].controls['end' + f].setValue(null);
    }
  }

  launchTasks() {
    this.preview.showTasksList('');
  }

  launchWorkflows() {
    this.preview.showWorkflowsList('');
  }

  openInfoDialog(title, hasTitle, message) {
    const dialogRef = this.dialog.open(BhInfoDialogComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: { title: title, hasTitle: hasTitle, message: message }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do
    });
  }

  remove(id, user) {
    console.log('user remove : ', user);
    const c = this.advancedSearchFormControls[id];
    const index = c.value.indexOf(user, 0);

    if (index !== -1) {
      c.value.splice(index, 1);
    }

    c.updateValueAndValidity();
  }

  openUserSelectionDialog(event: any, m: boolean, t: string) {

    const users = new Array();
    let savedUsers = [];
    const eValue = this.advancedSearchFormControls[event.target.id].value;
    if (eValue !== '' && eValue !== undefined) {
      savedUsers = users.concat(eValue);
    }

    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '30%';
    dialogConfig.minWidth = '300px';

    dialogConfig.data = { multiple: m, savedUsers: savedUsers, type: t};

    const dialogRef = this.dialog.open(SelectUserDialogComponent,
      dialogConfig);


    dialogRef.afterClosed().subscribe(
      (val) => {
        console.log('Value from user select dialog : ', val);
        if (val !== undefined) {
          this.advancedSearchFormControls[event.target.id].setValue(val);
        }
      }
    );

  }

  loadDataFromNodeRef(nodeRef, field) {
    const queryParams = '?nodeRef=' + nodeRef + '&type=' + 'all';
    const options: RequestOptions = {
      path: '/service/getNodeDetails' + queryParams
    };
    this.webscript.get(options).then(
      (r) => {
        if (r && r.data && r.data.properties) {
          const author = [
            {
              name : r.data.properties.properties.name,
              userName : r.data.properties.nodeRef
            }
          ];
          this.advancedSearchFormControls[field].setValue(author);
        }
      },
      (c) => {
        console.log('Getting Author Data Error : ', c);
      }
    );
  }

}
