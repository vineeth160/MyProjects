import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhTreeComponent } from './bh-tree.component';

describe('BhTreeComponent', () => {
  let component: BhTreeComponent;
  let fixture: ComponentFixture<BhTreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhTreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhTreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
