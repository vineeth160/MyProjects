import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WfAdminTaskComponent } from './wf-admin-task.component';

describe('WfAdminTaskComponent', () => {
  let component: WfAdminTaskComponent;
  let fixture: ComponentFixture<WfAdminTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WfAdminTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WfAdminTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
