import { Component, OnInit, Inject, ChangeDetectorRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { AlfrescoApiService, AppConfigService, NotificationService, SearchService } from '@alfresco/adf-core';

import { SelectUserDialogComponent } from '../../select-user-dialog/select-user-dialog.component';
import { MatDialog, MatDialogConfig } from '@angular/material';

import { BhWebscriptService, RequestOptions } from '../../../services/bh-webscript.service';
import { BhDataListService } from '../../../services/bh-data-list.service';

import { QueryBody, RequestQuery, RequestScope } from '@alfresco/js-api';
import { ConfirmDialogComponent } from '@alfresco/adf-content-services';
import { BhInfoDialogComponent } from '../../../dialog/bh-info-dialog/bh-info-dialog.component';

import { IsDuplicate } from '../../../directives/bh-is-duplicate.directive';
import { Moment } from 'moment';
import { BhApiService } from 'app/services/bh-api.service';
import { BhDocumentLinkComponent } from 'app/dialog/bh-document-link/bh-document-link.component';

interface Options {
  id: string;
  name: string;
}

@Component({
  selector: 'app-wf-admin-task',
  templateUrl: './wf-admin-task.component.html',
  styleUrls: ['./wf-admin-task.component.scss']
})
export class WfAdminTaskComponent implements OnInit {

  showViewer = false;

  title: string;
  requestType: string;
  reasonLabel: string;
  submitLabel: string;
  params;
  resizeValue = 'fullscreen';
  resizeTooltip = 'Maximize';

  node: any;
  nodeId: string;
  taskId: string;
  workflowId: string;

  ecmHost: string;

  form: FormGroup;
  documentName: string;
  documentReferenceNumber: string;
  productCompany = '';
  productLine = '';
  subProductLine = '';
  site = '';
  function = '';
  subFunction = '';
  documentAuthor = [];
  documentRevisionNumber: string;

  newRevisionNumber: String;
  newRevisionNumbers: Options[] = [];

  reasonForRevision: string;
  intakesComments: string;

  comments = [];

  documentState: string;

  isoElement: string;
  process: string;
  subProcess: string;
  userRole: string;
  effectiveDate: string;
  expiryDate: string;
  minDate: Date;

  adminComments: string;
  workflowActions = '';

  description = '(None)';
  modifiedOn: string;

  smeMember = [];
  adminMember = [];

  primaryReviewer = [];
  primaryApprover = [];
  additionalReviewer = [];
  additionalApprover = [];
  publisher = [];

  /* primaryReviewer = [
    { name: 'Workflow Reviewer', userName: 'admin' }
  ];
  primaryApprover = [
    { name: 'Workflow Approver', userName: 'admin' }
  ];
  additionalReviewer = [
    { name: 'Administrator', userName: 'admin' },
    { name: 'Workflow Reviewer', userName: 'admin' }
  ];
  additionalApprover = [
    { name: 'Administrator', userName: 'admin' },
    { name: 'Workflow Approver', userName: 'admin' }
  ];
  publisher = [{ name: 'Administrator', userName: 'admin' }]; */
  autoPublishControl = new FormControl(false);

  productCompanies: Options[] = [];
  productLines: Options[] = [];
  subProductLines: Options[] = [];
  sites: Options[] = [];
  functions: Options[] = [];
  subFunctions: Options[] = [];
  isoElements: Options[] = [];
  processes: Options[] = [];
  subProcesses: Options[] = [];
  userRoles: Options[] = [];

  validationMessages = {
    documentName: {
      required: 'Value is required',
      minLength: 'Value must be at least 1 character long'
    },
    documentReferenceNumber: {
      required: 'Value is required',
      isDuplicate: 'Duplicate Document Reference Number'
    },
    productCompany: {
      required: 'Value is required',
    },
    productLine: {
      required: 'Value is required',
    },
    subProductLine: {
      required: 'Value is required',
    },
    site: {
      required: 'Value is required',
    },
    function: {
      required: 'Value is required',
    },
    subFunction: {
      required: 'Value is required',
    },
    newRevisionNumber: {
      required: 'Value is required'
    },
    adminComments: {
      required: 'Value is required',
      minLength: 'Value must be at least 5 characters long'
    },
    isoElement: {
      required: 'Value is required',
    },
    process: {
      required: 'Value is required',
    },
    subProcess: {
      required: 'Value is required',
    },
    expiryDate: {
      required: 'Date value is required'
    },
    primaryReviewer: {
      required: 'Assignee must be selected for \'QMS Document Request\''
    },
    primaryApprover: {
      required: 'Assignee must be selected for \'QMS Document Request\''
    },
    publisher: {
      required: 'Assignee must be selected for \'QMS Document Request\''
    },
    workflowActions: {
      required: 'Value is required',
    },
    smeMember: {
      required: 'Assignee must be selected for \'Send to SME\' action',
    },
    adminMember: {
      required: 'Assignee must be selected for \'Re-assign\' action',
    }
  };

  constructor(private fb: FormBuilder,
    private dialogRef: MatDialogRef<WfAdminTaskComponent>,
    private apiService: BhApiService,
    private appConfig: AppConfigService,
    private dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private notificationService: NotificationService,
    private webScript: BhWebscriptService,
    private dataList: BhDataListService,
    private search: SearchService,
    private isDuplicate: IsDuplicate,
    private webscript: BhWebscriptService) {

    this.ecmHost = this.appConfig.get<string>('ecmHost');

    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth();
    const currentDay = new Date().getDate();
    this.minDate = new Date(currentYear, currentMonth, currentDay);

    this.form = fb.group({
      requestType: [''],
      documentName: ['', [Validators.required, Validators.minLength(1)]],
      documentReferenceNumber: new FormControl('',
        { updateOn : 'blur', validators : [Validators.required, this.referenceValidator]}
      ),
      productCompany: ['', Validators.required],
      productLine: ['', Validators.required],
      subProductLine: [''],
      site: [''],
      function: ['', Validators.required],
      subFunction: [''],
      documentAuthor: [this.documentAuthor],
      documentRevisionNumber: [''],
      newRevisionNumber: [''],
      reasonForRevision: [''],
      intakesComments: [''],
      documentState: [''],
      isoElement: [''],
      process: [''],
      subProcess: [''],
      userRole: [''],
      effectiveDate: [''],
      expiryDate: [''],
      adminComments: ['', [Validators.required, Validators.minLength(5)]],
      primaryReviewer: ['', this.matChipValidator],
      additionalReviewer: [''],
      primaryApprover: ['', this.matChipValidator],
      additionalApprover: [''],
      autoPublish: this.autoPublishControl,
      publisher: ['', this.matChipValidator],
      workflowActions: ['', Validators.required],
      adminMember: [''],
      intakesMember: [''],
      smeMember: ['']
    });
  }

  ngOnInit() {
    const rt = this.data.requestType;
    this.title = 'Workflow Admin Task | QMS Document Request';
    this.requestType = rt;
    this.form.controls.requestType.setValue(rt);
    this.reasonLabel = 'Reason for Revision';
    this.submitLabel = 'Submit';

    if (rt === 'RDR') {
      this.form.controls.newRevisionNumber.setValidators(Validators.required);
    } else {
      this.form.controls.newRevisionNumber.clearValidators();
    }
    this.form.controls.newRevisionNumber.updateValueAndValidity();

    // Data List
    // Product Company
    this.getDataList('productCompany', 'productCompanies', null, true);
    // Function
    // this.getDataList('function', 'functions', null);
    // ISO Element
    this.getDataList('isoElement', 'isoElements', null, true);
    // Process
    this.getDataList('process', 'processes', null, true);
    // User Role
    this.getDataList('userRole', 'userRoles', null, true);

    // Assignees data loading
    // TO DO : static data till user data loading from workflow
    this.form.controls.primaryReviewer.markAsDirty();
    this.form.controls.primaryReviewer.updateValueAndValidity();

    this.form.controls.primaryApprover.markAsDirty();
    this.form.controls.primaryApprover.updateValueAndValidity();

    this.workflowId = this.data.workflowId;
    this.workflowId = this.workflowId.replace('activiti$', '');
    this.taskId = this.data.id;
    this.taskId = this.taskId.replace('activiti$', '');
    let n: string = this.data.node;
    n = n.substring(n.lastIndexOf('/') + 1 );

    this.loadNodeData(n);
    this.loadAssigneesData(this.data.assignees);
    this.loadComments(this.data.comments);
  }

  loadNodeData(n: string) {
    // Task Package and Properties API call
    this.apiService.getNodeChildren(n).then(
      (r) => {
        console.log('child result : ', r.list.entries);
        if ( r.list.entries.length > 0 ) {
          const id = r.list.entries[0].entry.id;
          console.log('child id : ', id);
          this.nodeId = id;
          const opts = {
            include: ['path', 'properties', 'allowableOperations', 'permissions', 'aspectNames', 'association'],
            includeSource: true
          };
          this.apiService.getNodeInfo(id, opts).then(
            (result) => {
              console.log('node data : ', result);
              // Appending the document properties to form
              this.node = result;
              this.form.controls.documentName.setValue(result.name);
              this.form.controls.documentReferenceNumber.setValue(result.properties['bhqms:reference']);
              this.form.controls.productCompany.setValue(result.properties['bhqms:product_company']);

              this.onSelectionChangeWorkflow(result.properties['bhqms:product_company'], 'field');

              // this.form.controls.productCompany.markAsDirty();

              // Single
              // this.form.controls.productLine.setValue(result.properties['bhqms:product_line']);
              // Multiple
              const productLineValue = result.properties['bhqms:product_line']; // TO DO: multiple or single value
              this.form.controls.productLine.setValue(
                Array.isArray(productLineValue) ? productLineValue : (
                  productLineValue !== undefined &&
                  productLineValue !== null &&
                  productLineValue !== '' ? productLineValue.split(',') : productLineValue
                )
              );
              // this.form.controls.productLine.markAsDirty();

              // this.form.controls.subProductLine.setValue(result.properties['bhqms:sub_product_line']);
              const subProductLineValue = result.properties['bhqms:sub_product_line']; // TO DO: multiple or single value
              this.form.controls.subProductLine.setValue(
                Array.isArray(subProductLineValue) ? subProductLineValue : (
                  subProductLineValue !== undefined &&
                  subProductLineValue !== null &&
                  subProductLineValue !== '' ? subProductLineValue.split(',') : subProductLineValue
                )
              );

              // Single Value
              // const siteValue = result.properties['bhqms:site'];
              // this.form.controls.site.setValue(siteValue ? siteValue.split(',') : siteValue);
              // MUltiple value
              const siteValue = result.properties['bhqms:site'];
              this.form.controls.site.setValue(
                Array.isArray(siteValue) ? siteValue : (
                  siteValue !== undefined &&
                  siteValue !== null &&
                  siteValue !== '' ? siteValue.split(',') : siteValue
                )
              );

              // Single
              // const functionValue = result.properties['bhqms:function'];  // TO DO: multiple or single value
              // this.form.controls.function.setValue(Array.isArray(functionValue) ? functionValue.join(', ') : functionValue);
              // Multiple
              const functionValue = result.properties['bhqms:function']; // TO DO: multiple or single value
              this.form.controls.function.setValue(
                Array.isArray(functionValue) ? functionValue : (
                  functionValue !== undefined &&
                  functionValue !== null &&
                  functionValue !== '' ? functionValue.split(',') : functionValue
                )
              );

              this.form.controls.subFunction.setValue(result.properties['bhqms:sub_function']);
              // this.form.controls.documentRevisionNumber.setValue(result.properties['cm:versionLabel']);
              if (this.data.requestType === 'RDR') {
                const rn = result.properties['bhqms:publish_revision'];
                if (rn !== undefined && rn !== null && rn !== '' && rn !== 'None' ) {
                  this.form.controls.documentRevisionNumber.setValue(rn);
                  const rnn = parseFloat(rn);
                  console.log('Parsed Revision Number : ', rnn);
                  const minor = (rnn + 0.1).toFixed(1);
                  const major = (rnn + 1.0).toFixed();
                  console.log('Minor : ', minor);
                  console.log('Major : ', major);
                  this.newRevisionNumbers = [
                    { id : 'Minor-' + minor, name : 'Minor Change (' + minor + ')'},
                    { id : 'Major-' + major + '.0', name : 'Major Change (' + major + '.0)'}
                  ];

                  if (this.data.revisionNumber === minor) {
                    this.form.controls.newRevisionNumber.setValue('Minor-' + minor);
                  } else if (this.data.revisionNumber === (major + '.0')) {
                    this.form.controls.newRevisionNumber.setValue('Major-' + major + '.0');
                  }
                  console.log('New Revision Values : ', this.newRevisionNumbers);
                } else {
                  this.form.controls.documentRevisionNumber.setValue(undefined);
                }
              } else {
                this.form.controls.documentRevisionNumber.setValue(this.data.revisionNumber);
              }

              this.form.controls.reasonForRevision.setValue(result.properties['bhqms:reason_for_revision']);

              this.form.controls.documentState.setValue(result.properties['bhqms:document_state']);

              // Document Author
              const authorValue = result.properties['bhqms:document_author'];
              // TO DO: fetch author details and append the object
              if (authorValue !== undefined && authorValue !== '' && authorValue !== null) {
                this.loadDataFromNodeRef(authorValue);
                /* const author = [{ name : authorValue, userName : authorValue }];
                this.form.controls.documentAuthor.setValue(author);
                this.documentAuthor = author; */
              }

              // Additional Information
              const isoElementValue = result.properties['bhqms:iso_element']; // TO DO: multiple or single value
              this.form.controls.isoElement.setValue(
                Array.isArray(isoElementValue) ? isoElementValue : (
                  isoElementValue !== undefined &&
                  isoElementValue !== null &&
                  isoElementValue !== '' ? isoElementValue.split(',') : isoElementValue
                )
              );

              // Single
              // this.form.controls.process.setValue(result.properties['bhqms:process']);
              // Multiple
              const processValue = result.properties['bhqms:process']; // TO DO: multiple or single value
              this.form.controls.process.setValue(
                Array.isArray(processValue) ? processValue : (
                  processValue !== undefined &&
                  processValue !== null &&
                  processValue !== '' ? processValue.split(',') : processValue
                )
              );

              // Single
              // this.form.controls.subProcess.setValue(result.properties['bhqms:sub_process']);
              // Multiple
              const subProcessValue = result.properties['bhqms:sub_process']; // TO DO: multiple or single value
              this.form.controls.subProcess.setValue(
                Array.isArray(subProcessValue) ? subProcessValue : (
                  subProcessValue !== undefined &&
                  subProcessValue !== null &&
                  subProcessValue !== '' ? subProcessValue.split(',') : subProcessValue
                )
              );

              // User Role Property not available in updated content model :(
              const userRoleValue = result.properties['bhqms:user_role'];
              this.form.controls.userRole.setValue(
                Array.isArray(userRoleValue) ? userRoleValue : (
                  userRoleValue !== undefined &&
                  userRoleValue !== null &&
                  userRoleValue !== '' ? userRoleValue.split(',') : userRoleValue
                )
              );

              const effectiveDate = result.properties['bhqms:effective_date'];
              if (effectiveDate !== undefined && effectiveDate !== null && effectiveDate !== '') {
                const d = Date.parse(effectiveDate);
                this.form.controls.effectiveDate.setValue(new Date(d));
              }

              const expiryDate = result.properties['bhqms:expiry_date'];
              if (expiryDate !== undefined && expiryDate !== null && expiryDate !== '') {
                const d = Date.parse(expiryDate);
                this.form.controls.expiryDate.setValue(new Date(d));
              }


              /* this.form.controls.intakesComments.setValue(''); */
              this.documentName = result.name;
              this.description = result.properties['cm:description'];
              this.modifiedOn = result.modifiedAt.toLocaleDateString();

              // Data List
              // Product Line
              // this.getDataList('productLine', 'productLines', 'productCompany');
              // Site
              // this.getDataList('site', 'sites', 'productLine');
              // Sub Product Line
              // To Do
              // Sub Function
              // To Do

              // new Update - 04-06-2020
              // Product Line Data List
              this.getDataList('productLine', 'productLines', 'productCompany', true);

              // Sub Product Line Data List
              this.getDataList('subProductLine', 'subProductLines', 'productLine', true);

              // Site Data List
              this.getDataList('site', 'sites', 'productLine', true);

              // function
              this.getDataList('function', 'functions', 'productCompany', true);

              // Sub Function Data List
              this.getDataList('subFunction', 'subFunctions', 'function', true);

              // Sub Process data List
              this.getDataList('subProcess', 'subProcesses', 'process', true);
            }
          );
        }
      }
    );
  }

  loadDataFromNodeRef(nodeRef) {
    const queryParams = '?nodeRef=' + nodeRef + '&type=' + 'all';
    const options: RequestOptions = {
      path: '/service/getNodeDetails' + queryParams
    };
    this.webscript.get(options).then(
      (r) => {
        if (r && r.data && r.data.properties) {
          const author = [
            {
              name : r.data.properties.properties.name,
              userName : r.data.properties.nodeRef
            }
          ];
          this.form.controls.documentAuthor.setValue(author);
          this.documentAuthor = author;
        }
      },
      (c) => {
        console.log('Getting Author Data Error : ', c);
      }
    );
  }

  loadAssigneesData(assignees) {
    /* if (this.workflowId !== undefined && this.workflowId !== null && this.workflowId !== '') {
      const options: RequestOptions = <RequestOptions>{
        path: '/service/api/bh-workflow-instances/activiti$' + this.workflowId + '?includeTasks=true'
      };
      this.webscript.get(options).then(
        (wp) => {
          console.log('Workflow details : ', wp);
        },
        (e) => {
          console.log('Workflow details Error : ', e);
        }
      );
    } */

    if (assignees !== undefined && assignees !== null && assignees !== '') {

      if (assignees.smeUser !== undefined && assignees.smeUser !== null && assignees.smeUser !== '') {
        const user = new Array();
        user.push(assignees.smeUser);
        this.smeMember = user;
        this.form.controls.smeMember.setValue(user);
      }

      if (assignees.intakesUser !== undefined && assignees.intakesUser !== null && assignees.intakesUser !== '') {
        const user = new Array();
        user.push(assignees.intakesUser);
        // this.intakesMember = user;
        // this.form.controls.intakesMember.setValue(user);
      }

      if (assignees.primaryReviewerUser !== undefined && assignees.primaryReviewerUser !== null && assignees.primaryReviewerUser !== '') {
        const user = new Array();
        user.push(assignees.primaryReviewerUser);
        this.primaryReviewer = user;
        this.form.controls.primaryReviewer.setValue(user);
      }

      if (assignees.primaryApproverUser !== undefined && assignees.primaryApproverUser !== null && assignees.primaryApproverUser !== '') {
        const user = new Array();
        user.push(assignees.primaryApproverUser);
        this.primaryApprover = user;
        this.form.controls.primaryApprover.setValue(user);
      }

      if (assignees.reviewerUser !== undefined && assignees.reviewerUser !== null && assignees.reviewerUser !== '') {
        if (assignees.reviewerUser.length > 0) {
          this.additionalReviewer = assignees.reviewerUser;
          this.form.controls.additionalReviewer.setValue(assignees.reviewerUser);
        }
      }

      if (assignees.approverUser !== undefined && assignees.approverUser !== null && assignees.approverUser !== '') {
        if (assignees.approverUser.length > 0) {
          this.additionalApprover = assignees.approverUser;
          this.form.controls.additionalApprover.setValue(assignees.approverUser);
        }
      }

      if (assignees.publisherUser !== undefined && assignees.publisherUser !== null && assignees.publisherUser !== '') {
        const user = new Array();
        user.push(assignees.publisherUser);
        this.publisher = user;
        this.form.controls.publisher.setValue(user);
      }

      /* this.form.controls.primaryReviewer.setValue('');
      this.form.controls.additionalReviewer.setValue('');
      this.form.controls.primaryApprover.setValue('');
      this.form.controls.additionalApprover.setValue('');
      this.form.controls.publisher.setValue(''); */
    }
  }

  loadComments(comments: Array<any>) {
    if (comments !== undefined && comments.length > 0) {
      const tempComments = new Array();
      comments.forEach((c) => {
        const tempComment = new Object();
        if (c.type === 'bhwf:submitterTask') {
          tempComment['key'] = 'Submitter Comment';
        } else if (c.type === 'bhwf:intakesTask') {
          tempComment['key'] = 'Intakes Comment';
        } else if (c.type === 'bhwf:smeTask') {
          tempComment['key'] = 'SME Comment';
        } else if (c.type === 'bhwf:adminTask') {
          tempComment['key'] = 'Admin Comment';
        } else if (c.type === 'bhwf:reviewerTask') {
          tempComment['key'] = 'Reviewer Comment';
        } else if (c.type === 'bhwf:approverTask') {
          tempComment['key'] = 'Approver Comment';
        } else if (c.type === 'bhwf:publisherTask') {
          tempComment['key'] = 'Publisher Comment';
        }
        tempComment['value'] = c.comment;
        tempComments.push(tempComment);
      });
      this.comments = tempComments;
    }
    console.log('All Comments : ', comments);
  }

  getDataList(field: string, fieldData: string, parent: string, onLoad: boolean) {

    if (parent === 'productCompany') {
      this.onSelectionChangeWorkflow(this.form.value[parent], 'field');
    }

    if (this.form.value[parent] === '') {
      if (parent === 'productCompany') {
        this.productLines = [];
        this.form.controls.productLine.setValue('');
        this.subProductLines = [];
        this.form.controls.subProductLine.setValue('');
        this.sites = [];
        this.form.controls.site.setValue('');
        this.functions = [];
        this.form.controls.function.setValue('');
        this.subFunctions = [];
        this.form.controls.subFunction.setValue('');
      } else if (parent === 'productLine') {
        this.subProductLines = [];
        this.form.controls.subProductLine.setValue('');
        this.sites = [];
        this.form.controls.site.setValue('');
      } else if (parent === 'function') {
        this.subFunctions = [];
        this.form.controls.subFunction.setValue('');
      } else if (parent === 'process') {
        this.subProcesses = [];
        this.form.controls.subProcess.setValue('');
      }
    } else {
      if (!onLoad) {
        this.form.controls[field].setValue('');

        if (field === 'productLine') {
          this.subProductLines = [];
          this.form.controls.subProductLine.setValue('');
          this.sites = [];
          this.form.controls.site.setValue('');
        } else if (parent === 'function') {
          this.subFunctions = [];
          this.form.controls.subFunction.setValue('');
        } else if (parent === 'process') {
          this.subProcesses = [];
          this.form.controls.subProcess.setValue('');
        }
      }

      this.dataList.getFormData(field, this.form.value).then(
        (r) => {
          const data: Options[] = [];
          if (r.Values && r.Values.length > 0) {
            r.Values.forEach((item) => {
              data.push({ id: item, name: item });
            });
          }
          this[fieldData] = data;
        }
      );
    }
  }

  onSelectionChange(id: string) {
    console.log('onSelectionChange event : ', id);
    if (id === 'productCompany') {
      this.getDataList('productLine', 'productLines', 'productCompany', false);
      this.getDataList('function', 'functions', 'productCompany', false);
    }

    if (id === 'productLine') {
      this.getDataList('subProductLine', 'subProductLines', 'productLine', false);
      this.getDataList('site', 'sites', 'productLine', false);
    }

    if (id === 'function') {
      if (!this.form.get('productCompany').value.includes('TPS Turbomachinery')) {
        this.getDataList('subFunction', 'subFunctions', 'function', false);
      }
    }

    if (id === 'process') {
      this.getDataList('subProcess', 'subProcesses', 'process', false);
    }
  }

  onSelectionChangeWorkflow(val: any, type: string) {
    if (val !== undefined && val !== null && val !== '') {
      if (type === 'field') {
        if (val.includes('TPS Turbomachinery')) {

          this.form.controls.subProductLine.setValidators(Validators.required);
          this.form.controls.subProductLine.updateValueAndValidity();

          this.form.controls.site.setValidators(this.matChipValidator);
          this.form.controls.site.updateValueAndValidity();

          this.form.controls.subFunction.setValidators(Validators.required);
          this.form.controls.subFunction.updateValueAndValidity();

        } else if (val.includes('DS Digital')) {

          this.form.controls.site.setValidators(this.matChipValidator);
          this.form.controls.site.updateValueAndValidity();

          this.form.controls.isoElement.setValidators(Validators.required);
          this.form.controls.isoElement.updateValueAndValidity();

          this.form.controls.process.setValidators(Validators.required);
          this.form.controls.process.updateValueAndValidity();

          this.form.controls.subProcess.setValidators(Validators.required);
          this.form.controls.subProcess.updateValueAndValidity();

          this.form.controls.expiryDate.setValidators(Validators.required);
          this.form.controls.expiryDate.updateValueAndValidity();

          this.form.controls.publisher.clearValidators();
          this.form.controls.publisher.updateValueAndValidity();
        } else {

          this.form.controls.subProductLine.clearValidators();
          this.form.controls.subProductLine.updateValueAndValidity();

          this.form.controls.site.clearValidators();
          this.form.controls.site.updateValueAndValidity();

          this.form.controls.subFunction.clearValidators();
          this.form.controls.subFunction.updateValueAndValidity();

          this.form.controls.isoElement.clearValidators();
          this.form.controls.isoElement.updateValueAndValidity();

          this.form.controls.process.clearValidators();
          this.form.controls.process.updateValueAndValidity();

          this.form.controls.subProcess.clearValidators();
          this.form.controls.subProcess.updateValueAndValidity();

          this.form.controls.expiryDate.clearValidators();
          this.form.controls.expiryDate.updateValueAndValidity();

          this.form.controls.publisher.setValidators(this.matChipValidator);
          this.form.controls.publisher.updateValueAndValidity();
        }
      }

      if (type === 'workflow') {
        if (val.includes('Re-assign')) {
          this.form.controls.adminMember.setValidators(this.matChipValidator);
          this.form.controls.adminMember.updateValueAndValidity();
        } else if (val.includes('Send to SME')) {
          this.form.controls.smeMember.setValidators(this.matChipValidator);
          this.form.controls.smeMember.updateValueAndValidity();
        } else {
          this.form.controls.adminMember.clearValidators();
          this.form.controls.adminMember.updateValueAndValidity();

          this.form.controls.smeMember.clearValidators();
          this.form.controls.smeMember.updateValueAndValidity();
        }
      }

      if (type === 'autoPublish') {
        const pc = this.form.controls.productCompany.value;
        const isDS = pc.includes('DS Digital');
        if (val || (!val && isDS)) {
          this.form.controls.publisher.clearValidators();
          this.form.controls.publisher.updateValueAndValidity();
        } else {
          this.form.controls.publisher.setValidators(this.matChipValidator);
          this.form.controls.publisher.updateValueAndValidity();
        }
      }
    }
  }

  submitForm() {
    if (this.form.invalid || this.form.pending) {
      this.openInfoDialog(null, false, 'Fill the form with all mandatory(*) values to submit');
    } else {
      if (this.taskId !== undefined && this.taskId !== '' && this.taskId !== null) {
        this.submitAdminForm();
      } else {
        this.openInfoDialog('Error', true, 'Task Id is not available, Please check once');
      }
    }
  }

  submitAdminForm() {
    const f = this.form.value;
    const self = this;
    const a = f.workflowActions;
    if ( a !== '' && a !== undefined && a !== null ) {
      // TO DO: Start/show Loading
      this.updateMetadata(a);
    } else {
      this.openInfoDialog('Error', true, 'Workflow Action not available , Please check');
    }
  }

  updateMetadata(a: string) {
    const properties = this.getBhProperties();
    const params = new Object();
    params['node'] = 'workspace://SpacesStore/' + this.nodeId;
    params['properties'] = properties;
    const options: RequestOptions = {
      path: '/service/updateMetadata',
      formParams: params,
      bodyParam: params
    };
    if (Object.keys(properties).length > 0) {
      this.webscript.post(options).then(
        (r) => {
          console.log('Response : ', r);
          // TO DO: Assignees update in workflow - will be enabled once updated workflow integrated
          // this.updateWorkflow(a);
          // TO DO: Update loading message

          // till then for demo - start
          this.updateTask(a);
          // till then for demo -end
        },
        (e) => {
          console.log('Error : ', e);
          this.openInfoDialog('Error', true, e.message);
        }
      );
    } else {
      // TO DO: Assignees update in workflow
      // this.updateWorkflow(a);
      // TO DO: Update loading message
      this.updateTask(a);
    }
  }

  getMetadataRequestOptions(): RequestOptions {
    const p = new Object();
    p['node'] = 'workspace://SpacesStore/' + this.nodeId;
    p['properties'] = this.getBhProperties();
    return {
      path: '/service/updateMetadata',
      formParams: p,
      bodyParam: p
    };
  }

  getBhProperties() {
    const f = this.form.value;
    // To DO:
    // 'cm:name': f.documentName
    // 'bhqms:user_role': f.userRole
    // bhqms:document_submitter
    // bhqms:document_author
    // bhqms:document_admin
    // bhqms:functional_owner
    const data = new Object();
    if (this.form.controls.documentName.dirty) {
      data['cm:name'] = f.documentName;
    }
    if (this.form.controls.documentReferenceNumber.dirty &&
      (f.documentReferenceNumber !== null && f.documentReferenceNumber !== undefined && f.documentReferenceNumber !== '')) {
      data['bhqms:reference'] = f.documentReferenceNumber.toUpperCase();
    }
    if (this.form.controls.productCompany.dirty) {
      data['bhqms:product_company'] = f.productCompany;
    }
    if (this.form.controls.productLine.dirty) {
      // data['bhqms:product_line'] = f.productLine;
      data['bhqms:product_line'] = Array.isArray(f.productLine) ? f.productLine.join() : f.productLine;
    }
    if (this.form.controls.subProductLine.dirty &&
      (f.subProductLine !== null && f.subProductLine !== undefined && f.subProductLine !== '')) {
      data['bhqms:sub_product_line'] = f.subProductLine;
    }
    if (this.form.controls.site.dirty && (f.site !== null && f.site !== undefined && f.site !== '')) {
      data['bhqms:site'] = Array.isArray(f.site) ? f.site.join() : f.site;
    }
    if (this.form.controls.function.dirty) {
      // data['bhqms:function'] = f.function;
      data['bhqms:function'] = Array.isArray(f.function) ? f.function.join() : f.function;
    }
    if (this.form.controls.subFunction.dirty && (f.subFunction !== null && f.subFunction !== undefined && f.subFunction !== '')) {
      data['bhqms:sub_function'] = f.subFunction;
    }
    if (this.form.controls.isoElement.dirty && (f.isoElement !== null && f.isoElement !== undefined && f.isoElement !== '')) {
      data['bhqms:iso_element'] = Array.isArray(f.isoElement) ? f.isoElement.join() : f.isoElement;
    }
    if (this.form.controls.process.dirty && (f.process !== null && f.process !== undefined && f.process !== '')) {
      // data['bhqms:process'] = f.process;
      data['bhqms:process'] = Array.isArray(f.process) ? f.process.join() : f.process;
    }
    if (this.form.controls.subProcess.dirty && (f.subProcess !== null && f.subProcess !== undefined && f.subProcess !== '')) {
      // data['bhqms:sub_process'] = f.subProcess;
      data['bhqms:sub_process'] = Array.isArray(f.subProcess) ? f.subProcess.join() : f.subProcess;
    }
    if (this.form.controls.userRole.dirty && (f.userRole !== null && f.userRole !== undefined && f.userRole !== '')) {
      data['bhqms:user_role'] = f.userRole;
    }
    if (this.form.controls.effectiveDate.dirty && (f.effectiveDate !== null && f.effectiveDate !== undefined && f.effectiveDate !== '')) {
      const d: Date = f.effectiveDate;
      data['bhqms:effective_date'] = d.valueOf().toString();
    }
    if (this.form.controls.expiryDate.dirty && (f.expiryDate !== null && f.expiryDate !== undefined && f.expiryDate !== '')) {
      const d: Date = f.expiryDate;
      data['bhqms:expiry_date'] = d.valueOf().toString();
    }

    return data;
  }

  updateTask(a: string) {
    const p = this.getTaskFormParams(a);
    const options: RequestOptions = {
      path: '/service/api/bh-task-instances/activiti$' + this.taskId,
      formParams: p,
      bodyParam: p
    };

    this.webscript.put(options).then(
      (r) => {
        console.log('Response : ', r);
        this.endTask(a);
      },
      (e) => {
        console.log('Error : ', e);
        this.openInfoDialog('Error', true, e.briefSummary);
      }
    );
  }

  getTaskFormParams(a) {
    const f = this.form.value;
    const properties = new Object();
    properties['bpm_comment'] = this.form.value.adminComments;
    properties['bhwf_wf_actions'] = a;
    properties['bhwf_adminOutcome'] = 'Submit';
    properties['bhwf_bh_auto_publish'] = this.form.value.autoPublish ? 'YES' : 'NO';
    properties['isMailNotifyRequired'] = true;

    const rt = this.data.requestType;
    if (f.requestType === 'RDR') {
      properties['bhwf:bh_revision_type'] = f.newRevisionNumber;
      properties['bhwf_bh_revision_type'] = f.newRevisionNumber;
      let drn = f.documentRevisionNumber;
      if (drn === undefined || drn === null || drn === 'null' || drn === '' ) {
        drn = 'None';
      }
      properties['bhwf:bh_publish_revision'] = drn;
      properties['bhwf_bh_publish_revision'] = drn;
    }

    if (a === 'Approve') {
    } else if (a === 'Send to Reviewer') {
    } else if (a === 'Send to Publisher') {
    } else if (a === 'Send to SME') {
    } else if (a === 'Send Back to Submitter') {
    } else if (a === 'Reject') {}

    if (f.intakesMember && f.intakesMember.length > 0) {
      properties['bhwf_intakes'] = f.intakesMember[0].userName;
    }
    if (f.smeMember && f.smeMember.length > 0) {
      properties['bhwf_sme'] = f.smeMember[0].userName;
    }
    if (f.adminMember && f.adminMember.length > 0) {
      properties['bhwf_admin'] = f.adminMember[0].userName;
    }
    if (f.primaryReviewer.length > 0) {
      properties['bhwf_primaryReviewer'] = f.primaryReviewer[0].userName;
    }
    if (f.additionalReviewer.length > 0) {
      const reviewers = new Array();
      f.additionalReviewer.forEach(u => {
        reviewers.push(u.userName);
      });
      properties['bhwf_reviewer'] = reviewers;
    }
    if (f.primaryApprover.length > 0) {
      properties['bhwf_primaryApprover'] = f.primaryApprover[0].userName;
    }
    if (f.additionalApprover.length > 0) {
      const approvers = new Array();
      f.additionalApprover.forEach(u => {
        approvers.push(u.userName);
      });
      properties['bhwf_approver'] = approvers;
    }
    if (f.publisher.length > 0 && !this.form.controls.autoPublish.value) {
      properties['bhwf_publisher'] = f.publisher[0].userName;
    }

    return properties;
  }

  endTask(a: string) {
    this.webscript.put(this.getRequestOptions(a)).then(
      (r) => {
        console.log('Response : ', r);
        this.dialogRef.close(true);
        this.openInfoDialog('Response', true, 'Admin \'' + a + '\' request submitted successfully');
      },
      (e) => {
        console.log('Error : ', e);
        this.openInfoDialog('Error', true, e.briefSummary);
      }
    );
  }

  getRequestOptions(a: string): RequestOptions {
    const p = this.getFormParams(a);
    return {
      path: '/service/bh/public/workflow/versions/1/tasks/' + this.taskId + '?' + this.getQueryParams(a),
      formParams: p,
      bodyParam: p
    };
  }

  getQueryParams(a: string) {
    if ( a === 'Re-assign' ) {
      return 'select=owner,assignee';
    } else if (a === 'Approve') {
      return 'select=state';
    } else if (a === 'Send to Reviewer') {
      return 'select=state';
    } else if (a === 'Send to Publisher') {
      return 'select=state';
    } else if (a === 'Send to SME') {
      return 'select=state';
    } else if (a === 'Send Back to Submitter') {
      return 'select=state';
    } else if (a === 'Reject') {
      return 'select=state';
    }
  }

  getFormParams(a: string) {
    // Until then use mapping, assignee/sme : bhdev1
    const data = new Object();
    data['state'] = 'completed';
    if ( a === 'Re-assign' ) {
      return {
        owner : 'bhdev1',
        assignee : 'bhdev1'
      };
    }
    return data;
  }

  openUserSelectionDialog(event: any, m: boolean, t: string) {

    const users = new Array();
    let savedUsers = [];
    const v = this[event.target.id];
    if (v !== '' && v !== undefined && v !== null) {
      savedUsers = users.concat(v);
    }

    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '30%';
    dialogConfig.minWidth = '300px';

    dialogConfig.data = { multiple: m, savedUsers: savedUsers, type: t };

    const dialogRef = this.dialog.open(SelectUserDialogComponent,
      dialogConfig);


    dialogRef.afterClosed().subscribe(
      (val) => {
        console.log('Value from user select dialog : ', val);
        if (val !== undefined) {
          this[event.target.id] = val;
          this.form.controls[event.target.id].setValue(val);
        }
      }
    );

  }

  close() {
    if (this.form.dirty) {
      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        data: {
          title: 'Confirm',
          message: `Are you sure you want to discard the changes?`
        },
        minWidth: '250px'
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result === true) {
          this.dialogRef.close();
        }
      });
    } else {
      this.dialogRef.close();
    }
  }

  onResize(event) {
    const s = event.target.innerHTML;
    if (s === 'fullscreen') {
      this.params.maximize(event);
      this.resizeValue = 'fullscreen_exit';
      this.resizeTooltip = 'Minimize';
    } else {
      this.params.resize(event);
      this.resizeValue = 'fullscreen';
      this.resizeTooltip = 'Maximize';
    }
  }

  remove(id, user) {
    console.log('user remove : ', user);
    const c = this.form.controls[id];
    const index = this[id].indexOf(user, 0);

    if (index !== -1) {
      this[id].splice(index, 1);
    }

    // this.form.controls[id].setValue(this[id]);
    if (this[id].length === 0) {
      c.markAsTouched();
    }

    c.markAsDirty();
    c.updateValueAndValidity();
  }

  onPreview(entry: any) {
    if (entry && entry.isFile) {
      const type = entry.properties ? entry.properties['bhqms:content_category'] : undefined;
      if (type === 'Document') {
        this.nodeId = entry.id;
        this.showViewer = true;
      } else if (type === 'URL') {
        this.openDocumentLink('url', entry);
      }
    }
  }

  onViewerToggle(event) {
    // this.nodeId = null;
    this.showViewer = event;
  }

  openDocumentLink(type: string, entry: any) {
    const dialogRef = this.dialog.open(BhDocumentLinkComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: {
        node : entry,
        type : type
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

  fieldValidation(field: string): string {
    // console.log(field);
    if (this.form.get(field).hasError('required')) {
      // console.log('Error : ', this.validationMessages[field].required);
      return this.validationMessages[field].required;
    } else if (this.form.get(field).hasError('minlength')) {
      return this.validationMessages[field].minLength;
    } else if (this.form.get(field).hasError('isDuplicate')) {
      return this.validationMessages[field].isDuplicate;
    }
    return null;
  }

  onAutoPublishChange(e) {
    const c = e.checked;
    this.form.controls.autoPublish.setValue(c);
  }

  openInfoDialog(title, hasTitle, message) {
    const dialogRef = this.dialog.open(BhInfoDialogComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: { title: title, hasTitle: hasTitle, message: message }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

  // Document reference Number validation
  onReferenceNumberChange(e: any) {
    const self = this.form.controls.documentReferenceNumber;
    const v = self.value;
    const n = this.nodeId;
    self.markAsPending();
    console.log('Reference Number Change event : ', e.target.value);
    if (v !== '' && v !== undefined && v !== null) {
      const queryParams = '?reference=' + v + '&nodeRef=' + n;
      const options: RequestOptions = {
        path: '/service/referenceNumberValidation' + queryParams
      };
      this.webScript.get(options).then(
        (r) => {
          if (r) {
            if (r['isDuplicate']) {
              self.setErrors({ isDuplicate : true });
            } else {
              self.setErrors({ isDuplicate : false });
            }
          } else {
            self.setErrors({ isDuplicate : false });
          }
          self.updateValueAndValidity();
        },
        (c) => {
          self.setErrors({ isDuplicate : false });
          self.updateValueAndValidity();
        }
      );
    } else {
      self.setErrors({ isDuplicate : false, required : true });
      self.updateValueAndValidity();
    }
  }

  referenceValidator(c: FormControl) {
    if ((c.value !== undefined && c.value !== null) && c.value.length > 0) {
      if (c.hasError('isDuplicate')) {
        return c.getError('isDuplicate') ? { isDuplicate : true } : null;
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  matChipValidator(c: FormControl) {
    if (c.value.length === 0) {
      return { required: true };
    } else {
      return null;
    }
  }

}
