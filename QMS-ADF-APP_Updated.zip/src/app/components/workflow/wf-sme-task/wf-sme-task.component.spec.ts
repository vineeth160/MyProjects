import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WfSmeTaskComponent } from './wf-sme-task.component';

describe('WfSmeTaskComponent', () => {
  let component: WfSmeTaskComponent;
  let fixture: ComponentFixture<WfSmeTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WfSmeTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WfSmeTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
