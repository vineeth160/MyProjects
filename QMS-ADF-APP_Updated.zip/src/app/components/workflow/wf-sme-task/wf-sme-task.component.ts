import { Component, OnInit, Inject, ChangeDetectorRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {FormBuilder, Validators, FormGroup, FormControl} from '@angular/forms';
import { AlfrescoApiService, AppConfigService, NotificationService } from '@alfresco/adf-core';
import { HttpClient } from '@angular/common/http';
import { SelectUserDialogComponent } from '../../select-user-dialog/select-user-dialog.component';
import { MatDialog, MatDialogConfig } from '@angular/material';

import { ConfirmDialogComponent } from '@alfresco/adf-content-services';
import { BhInfoDialogComponent } from '../../../dialog/bh-info-dialog/bh-info-dialog.component';
import { BhWebscriptService, RequestOptions } from 'app/services/bh-webscript.service';
import { BhApiService } from 'app/services/bh-api.service';
import { BhDocumentLinkComponent } from 'app/dialog/bh-document-link/bh-document-link.component';

@Component({
  selector: 'app-wf-sme-task',
  templateUrl: './wf-sme-task.component.html',
  styleUrls: ['./wf-sme-task.component.scss']
})
export class WfSmeTaskComponent implements OnInit {

  form: FormGroup;
  node: any;
  nodeId: string;
  taskId: string;

  title: string;
  requestType: string;
  reasonLabel: string;
  submitLabel: string;
  params;
  resizeValue = 'fullscreen';
  resizeTooltip = 'Maximize';

  documentName = '';
  description = '(None)';
  modifiedOn: string;

  comments = [];

  reviewerMember = [];

  showViewer = false;

  validationMessages = {
    smeComments: {
      required: 'Value is required',
      minLength: 'Value must be at least 5 characters long'
    },
    workflowActions: {
      required: 'Action is required'
    },
    reviewerMember: {
      required: 'Assignee must be selected to \'Re-assign\''
    }
  };

  constructor(private fb: FormBuilder,
              private dialogRef: MatDialogRef<WfSmeTaskComponent>,
              private apiService: BhApiService,
              private appConfig: AppConfigService,
              private http: HttpClient,
              private dialog: MatDialog,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private changeDetector: ChangeDetectorRef,
              private notificationService: NotificationService,
              private webscript: BhWebscriptService
              ) {

                this.form = fb.group({
                  requestType: [''],
                  documentName: [''],
                  documentReferenceNumber: [''],
                  documentRevisionNumber: [''],
                  reasonForRevision: [''],
                  documentState: [''],
                  intakesComments: [''],
                  adminComments: [''],
                  smeComments: ['', [Validators.required, Validators.minLength(5)]],
                  workflowActions: ['', Validators.required],
                  reviewerMember: ['']
                });

               }

  ngOnInit() {
    const rt = this.data.requestType;
    this.title = 'Workflow SME Task | QMS Document Request';
    this.requestType = rt;
    this.reasonLabel = 'Reason for Revision';
    this.submitLabel = 'Submit';
    this.taskId = this.data.id;
    this.taskId = this.taskId.replace('activiti$', '');
    let n: string = this.data.node;
    n = n.substring(n.lastIndexOf('/') + 1 );

    this.apiService.getNodeChildren(n).then(
      (r) => {
        console.log('child result : ', r.list.entries);
        if ( r.list.entries.length > 0 ) {
          const id = r.list.entries[0].entry.id;
          console.log('child id : ', id);
          this.nodeId = id;
          const opts = {
            include: ['path', 'properties', 'allowableOperations', 'permissions', 'aspectNames', 'association'],
            includeSource: true
          };
          this.apiService.getNodeInfo(id, opts).then(
            (result) => {
              console.log('node data : ', result);
              this.node = result;
              this.form.controls.documentName.setValue(result.name);
              this.form.controls.documentReferenceNumber.setValue(result.properties['bhqms:reference']);

              // this.form.controls.documentRevisionNumber.setValue(result.properties['cm:versionLabel']);
              if (this.data.requestType === 'RDR') {
                const rn = result.properties['bhqms:publish_revision'];
                if (rn !== undefined && rn !== null && rn !== '' && rn !== 'None' ) {
                  this.form.controls.documentRevisionNumber.setValue(rn);
                } else {
                  this.form.controls.documentRevisionNumber.setValue(undefined);
                }
              } else {
                this.form.controls.documentRevisionNumber.setValue(this.data.revisionNumber);
              }

              this.form.controls.reasonForRevision.setValue(result.properties['bhqms:reason_for_revision']);
              this.form.controls.documentState.setValue(result.properties['bhqms:document_state']);
              this.documentName = result.name;
              this.description = result.properties['cm:description'];
              this.modifiedOn = result.modifiedAt.toLocaleDateString();
            }
          );
        }
      }
    );

    this.loadComments(this.data.comments);
  }

  loadComments(comments: Array<any>) {
    if (comments !== undefined && comments.length > 0) {
      const tempComments = new Array();
      comments.forEach((c) => {
        const tempComment = new Object();
        if (c.type === 'bhwf:submitterTask') {
          tempComment['key'] = 'Submitter Comment';
        } else if (c.type === 'bhwf:intakesTask') {
          tempComment['key'] = 'Intakes Comment';
        } else if (c.type === 'bhwf:smeTask') {
          tempComment['key'] = 'SME Comment';
        } else if (c.type === 'bhwf:adminTask') {
          tempComment['key'] = 'Admin Comment';
        } else if (c.type === 'bhwf:reviewerTask') {
          tempComment['key'] = 'Reviewer Comment';
        } else if (c.type === 'bhwf:approverTask') {
          tempComment['key'] = 'Approver Comment';
        } else if (c.type === 'bhwf:publisherTask') {
          tempComment['key'] = 'Publisher Comment';
        }
        tempComment['value'] = c.comment;
        tempComments.push(tempComment);
      });
      this.comments = tempComments;
    }
    console.log('All Comments : ', comments);
  }

  onSelectionChange(e: any) {
    const v = this.form.value['workflowActions'];
    if (v.includes('Re-assign')) {
      this.form.controls.reviewerMember.setValidators(this.matChipValidator);
    } else {
      this.form.controls.reviewerMember.clearValidators();
    }
    this.form.controls.reviewerMember.updateValueAndValidity();
  }

  submitForm() {
    if (this.form.invalid || this.form.pending) {
      this.openInfoDialog(null, false, 'Fill the form with all mandatory(*) values to submit');
    } else {
      if (this.taskId !== undefined && this.taskId !== '' && this.taskId !== null) {
        this.submitSmeForm();
      } else {
        this.openInfoDialog('Error', true, 'Task Id is not available, Please check once');
      }
    }
  }

  submitSmeForm() {
    const f = this.form.value;
    const self = this;
    const a = f.workflowActions;
    if ( a !== '' && a !== undefined && a !== null ) {
      this.updateTask(a);
    } else {
      this.openInfoDialog('Error', true, 'Workflow Action not available , Please check');
    }
  }

  updateTask(a: string) {
    const p = this.getTaskFormParams(a);
    const options: RequestOptions = {
      path: '/service/api/bh-task-instances/activiti$' + this.taskId,
      formParams: p,
      bodyParam: p
    };

    this.webscript.put(options).then(
      (r) => {
        console.log('Response : ', r);
        this.endTask(a);
      },
      (e) => {
        console.log('Error : ', e);
        this.openInfoDialog('Error', true, e.briefSummary);
      }
    );
  }

  getTaskFormParams(a) {
    const f = this.form.value;
    const properties = new Object();
    properties['bpm_comment'] = this.form.value.smeComments;
    properties['bhwf_wf_actions'] = a;
    properties['bhwf_intakesOutcome'] = 'Submit';

    if (a === 'Approve') {
    } else if (a === 'Reject') {}

    return properties;
  }

  endTask(a: string) {
    this.webscript.put(this.getRequestOptions(a)).then(
      (r) => {
        console.log('Response : ', r);
        this.dialogRef.close(true);
        this.openInfoDialog('Response', true, 'SME "' + a + '" request submitted successfully');
      },
      (e) => {
        console.log('Error : ', e);
        this.openInfoDialog('Error', true, e.message);
      }
    );
  }

  getRequestOptions(a: string): RequestOptions {
    const p = this.getFormParams(a);
    return {
      path: '/service/bh/public/workflow/versions/1/tasks/' + this.taskId + '?' + this.getQueryParams(a),
      formParams: p,
      bodyParam: p
    };
  }

  getQueryParams(a: string) {
    if ( a === 'Re-assign' ) {
      return 'select=owner,assignee';
    } else if (a === 'Approve') {
      return 'select=state';
    } else if (a === 'Reject') {
      return 'select=state';
    }
  }

  getFormParams(a: string) {
    // Until then use mapping, assignee/sme : bhdev1
    const data = new Object();
    data['state'] = 'completed';
    if ( a === 'Re-assign' ) {
      return {
        owner : 'bhdev1',
        assignee : 'bhdev1'
      };
    }
    return data;
  }

  close() {
    if ( this.form.dirty ) {
      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        data: {
            title: 'Confirm',
            message: `Are you sure you want to discard the changes?`
        },
        minWidth: '250px'
      });

      dialogRef.afterClosed().subscribe((result) => {
          if (result === true) {
            this.dialogRef.close();
          }
      });
    } else {
      this.dialogRef.close();
    }
  }

  onResize(event) {
    const s = event.target.innerHTML;
    if (s === 'fullscreen') {
      this.params.maximize(event);
      this.resizeValue = 'fullscreen_exit';
      this.resizeTooltip = 'Minimize';
    } else {
      this.params.resize(event);
      this.resizeValue = 'fullscreen';
      this.resizeTooltip = 'Maximize';
    }
  }

  onPreview(entry: any) {
    if (entry && entry.isFile) {
      const type = entry.properties ? entry.properties['bhqms:content_category'] : undefined;
      if (type === 'Document') {
        this.nodeId = entry.id;
        this.showViewer = true;
      } else if (type === 'URL') {
        this.openDocumentLink('url', entry);
      }
    }
  }

  onViewerToggle(event) {
    // this.nodeId = null;
    this.showViewer = event;
  }

  openDocumentLink(type: string, entry: any) {
    const dialogRef = this.dialog.open(BhDocumentLinkComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: {
        node : entry,
        type : type
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

  fieldValidation( field: string ): string {
    // console.log(field);
    if (this.form.get(field).hasError('required')) {
      // console.log('Error : ', this.validationMessages[field].required);
      return this.validationMessages[field].required;
    } else if (this.form.get(field).hasError('minlength')) {
      return this.validationMessages[field].minLength;
    } else if (this.form.get(field).hasError('isDuplicate')) {
      return this.validationMessages[field].isDuplicate;
    }
    return null;
  }

  openInfoDialog(title, hasTitle, message) {
    const dialogRef = this.dialog.open(BhInfoDialogComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: {title: title, hasTitle: hasTitle, message: message}
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

  openUserSelectionDialog(event: any, m: boolean, t: string) {

    const users = new Array();
    let savedUsers = [];
    if (this[event.target.id] !== '') {
      savedUsers = users.concat(this[event.target.id]);
    }

    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '30%';
    dialogConfig.minWidth = '300px';

    dialogConfig.data = { multiple: m, savedUsers: savedUsers, type: t };

    const dialogRef = this.dialog.open(SelectUserDialogComponent,
      dialogConfig);


    dialogRef.afterClosed().subscribe(
      (val) => {
        console.log('Value from user select dialog : ', val);
        if (val !== undefined) {
          this[event.target.id] = val;
          this.form.controls[event.target.id].setValue(val);
        }
      }
    );

  }

  remove(id, user) {
    console.log('user remove : ', user);
    const c = this.form.controls[id];
    const index = this[id].indexOf(user, 0);

    if (index !== -1) {
      this[id].splice(index, 1);
    }

    c.updateValueAndValidity();
    c.markAsDirty();
  }

  matChipValidator(c: FormControl) {
    if (c.value.length === 0) {
      return { required: true };
    } else {
      return null;
    }

  }

}
