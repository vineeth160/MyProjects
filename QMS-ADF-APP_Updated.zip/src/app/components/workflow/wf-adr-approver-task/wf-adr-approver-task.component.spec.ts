import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WfAdrApproverTaskComponent } from './wf-adr-approver-task.component';

describe('WfAdrApproverTaskComponent', () => {
  let component: WfAdrApproverTaskComponent;
  let fixture: ComponentFixture<WfAdrApproverTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WfAdrApproverTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WfAdrApproverTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
