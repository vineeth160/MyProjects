import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WfIntakesTaskComponent } from './wf-intakes-task.component';

describe('WfIntakesTaskComponent', () => {
  let component: WfIntakesTaskComponent;
  let fixture: ComponentFixture<WfIntakesTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WfIntakesTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WfIntakesTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
