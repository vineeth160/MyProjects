import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WfApproverTaskComponent } from './wf-approver-task.component';

describe('WfApproverTaskComponent', () => {
  let component: WfApproverTaskComponent;
  let fixture: ComponentFixture<WfApproverTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WfApproverTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WfApproverTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
