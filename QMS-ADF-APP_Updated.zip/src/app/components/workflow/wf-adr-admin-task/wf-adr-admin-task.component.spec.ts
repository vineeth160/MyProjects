import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WfAdrAdminTaskComponent } from './wf-adr-admin-task.component';

describe('WfAdrAdminTaskComponent', () => {
  let component: WfAdrAdminTaskComponent;
  let fixture: ComponentFixture<WfAdrAdminTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WfAdrAdminTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WfAdrAdminTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
