import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef, MatDialogConfig } from '@angular/material';
import { AlfrescoApiService } from '@alfresco/adf-core';
import { ConfirmDialogComponent } from '@alfresco/adf-content-services';
import { BhInfoDialogComponent } from 'app/dialog/bh-info-dialog/bh-info-dialog.component';
import { SelectUserDialogComponent } from 'app/components/select-user-dialog/select-user-dialog.component';
import { RequestOptions, BhWebscriptService } from 'app/services/bh-webscript.service';
import { BhApiService } from 'app/services/bh-api.service';
import { BhDocumentLinkComponent } from 'app/dialog/bh-document-link/bh-document-link.component';

@Component({
  selector: 'app-wf-adr-admin-task',
  templateUrl: './wf-adr-admin-task.component.html',
  styleUrls: ['./wf-adr-admin-task.component.scss']
})
export class WfAdrAdminTaskComponent implements OnInit {

  showViewer = false;

  node: any;
  nodeId: string;
  taskId: string;
  workflowId: string;

  title: string;
  reasonLabel: string;
  submitLabel: string;
  params;
  resizeValue = 'fullscreen';
  resizeTooltip = 'Maximize';

  form: FormGroup;

  documentAuthor = [];
  archivalApproverMember = [];

  documentName: string;
  description = '(None)';
  modifiedOn: string;

  adminComments: string;
  comments = [];

  workflowActions = '';

  validationMessages = {
    adminComments: {
      required: 'Value is required',
    },
    workflowActions: {
      required: 'Value is required',
    },
    archivalApproverMember: {
      required: 'Value is required',
    }
  };

  constructor(private fb: FormBuilder,
    private apiService: BhApiService,
    private dialogRef: MatDialogRef<WfAdrAdminTaskComponent>,
    private dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private webscript: BhWebscriptService) {

      this.form = fb.group({
        requestType: [''],
        documentType: [''],
        documentName: [''],
        documentReferenceNumber: [''],
        productCompany: [''],
        productLine: [''],
        subProductLine: [''],
        site: [''],
        function: [''],
        subFunction: [''],
        language: [''],
        contentCategory: [''],
        documentAttachment: [''],
        documentUrl: [''],
        documentRevisionType: [''],
        documentRevisionNumber: [''],
        reasonForRevision: [''],
        documentAuthor: [[]],
        priority: ['2'],
        workflowActions: ['', Validators.required],
        documentState: [''],
        isoElement: [''],
        process: [''],
        subProcess: [''],
        userRole: [''],
        effectiveDate: new FormControl({ value: '', disabled: false }),
        expiryDate: new FormControl({ value: '', disabled: false }),
        adminComments: ['', Validators.required],

        archivalApproverMember: [this.archivalApproverMember, Validators.required]
      });
    }

  ngOnInit() {
    // Document Request Type
    const rt = this.data.requestType;

    this.title = 'QMS Document Workflow Archival Admin Task';
    this.form.controls.requestType.setValue('ADR');
    this.reasonLabel = 'Reason for Archival';
    this.submitLabel = 'Submit';

    this.workflowId = this.data.workflowId;
    this.workflowId = this.workflowId.replace('activiti$', '');
    this.taskId = this.data.id;
    this.taskId = this.taskId.replace('activiti$', '');
    let n: string = this.data.node;
    n = n.substring(n.lastIndexOf('/') + 1 );

    this.loadNodeData(n);
    this.loadAssigneesData(this.data.assignees);
    this.loadComments(this.data.comments);
  }

  loadNodeData(n: string) {
    // Task Package and Properties API call
    this.apiService.getNodeChildren(n).then(
      (r) => {
        console.log('child result : ', r.list.entries);
        if ( r.list.entries.length > 0 ) {
          const id = r.list.entries[0].entry.id;
          console.log('child id : ', id);
          this.nodeId = id;
          const opts = {
            include: ['path', 'properties', 'allowableOperations', 'permissions', 'aspectNames', 'association'],
            includeSource: true
          };
          this.apiService.getNodeInfo(id, opts).then(
            (result) => {
              console.log('node data : ', result);
              // Appending the document properties to form
              this.node = result;
              this.form.controls.documentName.setValue(result.name);
              this.form.controls.documentReferenceNumber.setValue(result.properties['bhqms:reference']);
              this.form.controls.productCompany.setValue(result.properties['bhqms:product_company']);

              // Product Line Value
              const productLineValue = result.properties['bhqms:product_line']; // TO DO: multiple or single value
              this.form.controls.productLine.setValue(
                Array.isArray(productLineValue) ? productLineValue : (
                  productLineValue !== undefined &&
                  productLineValue !== null &&
                  productLineValue !== '' ? productLineValue.split(',') : productLineValue
                )
              );

              // Sub Product Line Value
              const subProductLineValue = result.properties['bhqms:sub_product_line']; // TO DO: multiple or single value
              this.form.controls.subProductLine.setValue(
                Array.isArray(subProductLineValue) ? subProductLineValue : (
                  subProductLineValue !== undefined &&
                  subProductLineValue !== null &&
                  subProductLineValue !== '' ? subProductLineValue.split(',') : subProductLineValue
                )
              );

              // Site value
              const siteValue = result.properties['bhqms:site'];
              this.form.controls.site.setValue(
                Array.isArray(siteValue) ? siteValue : (
                  siteValue !== undefined &&
                  siteValue !== null &&
                  siteValue !== '' ? siteValue.split(',') : siteValue
                )
              );

              // Function Value
              const functionValue = result.properties['bhqms:function']; // TO DO: multiple or single value
              this.form.controls.function.setValue(
                Array.isArray(functionValue) ? functionValue : (
                  functionValue !== undefined &&
                  functionValue !== null &&
                  functionValue !== '' ? functionValue.split(',') : functionValue
                )
              );

              this.form.controls.subFunction.setValue(result.properties['bhqms:sub_function']);

              // this.form.controls.documentRevisionType.setValue(result.properties['cm:versionType']);
              // this.form.controls.documentRevisionNumber.setValue(result.properties['cm:versionLabel']);
              const rn = result.properties['bhqms:publish_revision'];
              if (rn !== undefined && rn !== null && rn !== '' && rn !== 'None' ) {
                this.form.controls.documentRevisionNumber.setValue(rn);
              } else {
                this.form.controls.documentRevisionNumber.setValue(undefined);
              }

              this.form.controls.reasonForRevision.setValue(result.properties['bhqms:reason_for_revision']);

              this.form.controls.documentState.setValue(result.properties['bhqms:document_state']);

              // Document Author
              const authorValue = result.properties['bhqms:document_author'];
              // TO DO: fetch author details and append the object
              if (authorValue !== undefined && authorValue !== '' && authorValue !== null) {
                this.loadDataFromNodeRef(authorValue);
                /* const author = [{ name : authorValue, userName : authorValue }];
                this.form.controls.documentAuthor.setValue(author);
                this.documentAuthor = author; */
              }

              // Additional Information
              const isoElementValue = result.properties['bhqms:iso_element']; // TO DO: multiple or single value
              this.form.controls.isoElement.setValue(
                Array.isArray(isoElementValue) ? isoElementValue : (
                  isoElementValue !== undefined &&
                  isoElementValue !== null &&
                  isoElementValue !== '' ? isoElementValue.split(',') : isoElementValue
                )
              );

              // Process Value
              const processValue = result.properties['bhqms:process']; // TO DO: multiple or single value
              this.form.controls.process.setValue(
                Array.isArray(processValue) ? processValue : (
                  processValue !== undefined &&
                  processValue !== null &&
                  processValue !== '' ? processValue.split(',') : processValue
                )
              );

              // Sub Process Value
              const subProcessValue = result.properties['bhqms:sub_process']; // TO DO: multiple or single value
              this.form.controls.subProcess.setValue(
                Array.isArray(subProcessValue) ? subProcessValue : (
                  subProcessValue !== undefined &&
                  subProcessValue !== null &&
                  subProcessValue !== '' ? subProcessValue.split(',') : subProcessValue
                )
              );

              // User Role Property not available in updated content model :(
              const userRoleValue = result.properties['bhqms:user_role'];
              this.form.controls.userRole.setValue(
                Array.isArray(userRoleValue) ? userRoleValue : (
                  userRoleValue !== undefined &&
                  userRoleValue !== null &&
                  userRoleValue !== '' ? userRoleValue.split(',') : userRoleValue
                )
              );

              this.form.controls.effectiveDate.setValue(result.properties['bhqms:effective_date']);
              this.form.controls.expiryDate.setValue(result.properties['bhqms:expiry_date']);

              this.documentName = result.name;
              this.description = result.properties['cm:description'];
              this.modifiedOn = result.modifiedAt.toLocaleDateString();

            }
          );
        }
      }
    );
  }

  loadDataFromNodeRef(nodeRef) {
    const queryParams = '?nodeRef=' + nodeRef + '&type=' + 'all';
    const options: RequestOptions = {
      path: '/service/getNodeDetails' + queryParams
    };
    this.webscript.get(options).then(
      (r) => {
        if (r && r.data && r.data.properties) {
          const author = [
            {
              name : r.data.properties.properties.name,
              userName : r.data.properties.nodeRef
            }
          ];
          this.form.controls.documentAuthor.setValue(author);
          this.documentAuthor = author;
        }
      },
      (c) => {
        console.log('Getting Author Data Error : ', c);
      }
    );
  }

  loadAssigneesData(assignees) {

    if (assignees !== undefined && assignees !== null && assignees !== '') {

      if (assignees.adrApproverUser !== undefined && assignees.adrApproverUser !== null && assignees.adrApproverUser !== '') {
        const user = new Array();
        user.push(assignees.adrApproverUser);
        this.archivalApproverMember = user;
        this.form.controls.archivalApproverMember.setValue(user);
      }
    }
  }

  loadComments(comments: Array<any>) {
    if (comments !== undefined && comments.length > 0) {
      const tempComments = new Array();
      comments.forEach((c) => {
        const tempComment = new Object();
        if (c.type === 'bhwf:submitterTask') {
          tempComment['key'] = 'Submitter Comment';
        } else if (c.type === 'bhwf:archivalAdminTask') {
          tempComment['key'] = 'Admin Comment';
        } else if (c.type === 'bhwf:reviewerTask') {
          tempComment['key'] = 'Reviewer Comment';
        } else if (c.type === 'bhwf:archivalApproverTask') {
          tempComment['key'] = 'Approver Comment';
        }
        tempComment['value'] = c.comment;
        tempComments.push(tempComment);
      });
      this.comments = tempComments;
    }
    console.log('All Comments : ', comments);
  }

  submitForm() {
    if (this.form.invalid || this.form.pending) {
      this.openInfoDialog(null, false, 'Fill the form with all mandatory(*) values to submit');
    } else {
      if (this.taskId !== undefined && this.taskId !== '' && this.taskId !== null) {
        this.submitAdminForm();
      } else {
        this.openInfoDialog('Error', true, 'Task Id is not available, Please check once');
      }
    }
  }

  submitAdminForm() {
    const f = this.form.value;
    const self = this;
    const a = f.workflowActions;
    if ( a !== '' && a !== undefined && a !== null ) {
      // TO DO: Start/show Loading
      this.updateTask(a);
    } else {
      this.openInfoDialog('Error', true, 'Workflow Action not available , Please check');
    }
  }

  updateTask(a) {
    const p = this.getTaskFormParams(a);
    const options: RequestOptions = {
      path: '/service/api/bh-task-instances/activiti$' + this.taskId,
      formParams: p,
      bodyParam: p
    };

    this.webscript.put(options).then(
      (r) => {
        console.log('Response : ', r);
        this.endTask(a);
      },
      (e) => {
        console.log('Error : ', e);
        this.openInfoDialog('Error', true, e.briefSummary);
      }
    );
  }

  getTaskFormParams(a) {
    const f = this.form.value;
    const properties = new Object();
    properties['bpm_comment'] = this.form.value.adminComments;
    properties['bhwf_wf_actions'] = a;
    properties['bhwf_archivalAdminOutcome'] = 'Submit';
    properties['isFromLibrary'] = 'NO';

    if (a === 'Approve') {
    } else if (a === 'Reject') {
    }

    if (f.archivalApproverMember && f.archivalApproverMember.length > 0) {
      properties['bhwf_archivalApprover'] = f.archivalApproverMember[0].userName;
    }

    return properties;
  }

  endTask(a: string) {
    this.webscript.put(this.getRequestOptions(a)).then(
      (r) => {
        console.log('Response : ', r);
        this.dialogRef.close(true);
        this.openInfoDialog('Response', true, 'Admin request \'' + a + '\' submitted successfully');
      },
      (e) => {
        console.log('Error : ', e);
        this.openInfoDialog('Error', true, e.briefSummary);
      }
    );
  }

  getRequestOptions(a: string): RequestOptions {
    const p = this.getFormParams(a);
    return {
      path: '/service/bh/public/workflow/versions/1/tasks/' + this.taskId + '?' + this.getQueryParams(a),
      formParams: p,
      bodyParam: p
    };
  }

  getQueryParams(a: string) {
    if ( a === 'Re-assign' ) {
      return 'select=owner,assignee';
    } else if (a === 'Approve') {
      return 'select=state';
    } else if (a === 'Reject') {
      return 'select=state';
    }
  }

  getFormParams(a: string) {
    // Until then user mapping, assignee/sme : test
    const data = new Object();
    data['state'] = 'completed';
    if ( a === 'Re-assign' ) {
      return {
        owner : 'bhdev1',
        assignee : 'bhdev1'
      };
    }
    return data;
  }

  close() {
    if (this.form.dirty) {
      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        data: {
          title: 'Confirm',
          message: `Are you sure you want to discard the changes?`
        },
        minWidth: '250px'
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result === true) {
          this.dialogRef.close();
        }
      });
    } else {
      this.dialogRef.close();
    }
  }

  openInfoDialog(title, hasTitle, message) {
    const dialogRef = this.dialog.open(BhInfoDialogComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: { title: title, hasTitle: hasTitle, message: message }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

  onResize(event) {
    const s = event.target.innerHTML;
    if (s === 'fullscreen') {
      this.params.maximize(event);
      this.resizeValue = 'fullscreen_exit';
      this.resizeTooltip = 'Minimize';
    } else {
      this.params.resize(event);
      this.resizeValue = 'fullscreen';
      this.resizeTooltip = 'Maximize';
    }
  }

  openUserSelectionDialog(event: any, m: boolean, t: string) {

    const users = new Array();
    let savedUsers = [];
    const v = this[event.target.id];
    if (v !== '' && v !== undefined && v !== null) {
      savedUsers = users.concat(v);
    }

    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '30%';
    dialogConfig.minWidth = '300px';

    dialogConfig.data = { multiple: m, savedUsers: savedUsers, type: t };

    const dialogRef = this.dialog.open(SelectUserDialogComponent,
      dialogConfig);


    dialogRef.afterClosed().subscribe(
      (val) => {
        console.log('Value from user select dialog : ', val);
        if (val !== undefined) {
          this[event.target.id] = val;
          this.form.controls[event.target.id].setValue(val);
        }
      }
    );

  }

  onSelectionChangeWorkflow(val: any) {
    if (val !== undefined && val !== null && val !== '') {

    }
  }

  fieldValidation(field: string): string {
    // console.log(field);
    if (this.form.get(field).hasError('required')) {
      // console.log('Error : ', this.validationMessages[field].required);
      return this.validationMessages[field].required;
    } else if (this.form.get(field).hasError('minlength')) {
      return this.validationMessages[field].minLength;
    } else if (this.form.get(field).hasError('isDuplicate')) {
      return this.validationMessages[field].isDuplicate;
    }
    return null;
  }

  remove(id, user) {
    console.log('user remove : ', user);
    const c = this.form.controls[id];
    const index = this[id].indexOf(user, 0);

    if (index !== -1) {
      this[id].splice(index, 1);
    }

    c.updateValueAndValidity();
    c.markAsDirty();
  }

  onPreview(entry: any) {
    if (entry && entry.isFile) {
      const type = entry.properties ? entry.properties['bhqms:content_category'] : undefined;
      if (type === 'Document') {
        this.nodeId = entry.id;
        this.showViewer = true;
      } else if (type === 'URL') {
        this.openDocumentLink('url', entry);
      }
    }
  }

  onViewerToggle(event) {
    // this.nodeId = null;
    this.showViewer = event;
  }

  openDocumentLink(type: string, entry: any) {
    const dialogRef = this.dialog.open(BhDocumentLinkComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: {
        node : entry,
        type : type
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

}
