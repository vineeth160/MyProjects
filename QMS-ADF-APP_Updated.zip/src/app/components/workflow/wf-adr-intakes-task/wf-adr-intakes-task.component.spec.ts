import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WfAdrIntakesTaskComponent } from './wf-adr-intakes-task.component';

describe('WfAdrIntakesTaskComponent', () => {
  let component: WfAdrIntakesTaskComponent;
  let fixture: ComponentFixture<WfAdrIntakesTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WfAdrIntakesTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WfAdrIntakesTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
