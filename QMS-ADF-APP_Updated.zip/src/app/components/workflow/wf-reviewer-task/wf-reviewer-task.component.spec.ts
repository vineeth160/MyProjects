import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WfReviewerTaskComponent } from './wf-reviewer-task.component';

describe('WfReviewerTaskComponent', () => {
  let component: WfReviewerTaskComponent;
  let fixture: ComponentFixture<WfReviewerTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WfReviewerTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WfReviewerTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
