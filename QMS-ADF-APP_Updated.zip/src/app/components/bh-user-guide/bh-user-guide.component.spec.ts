import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhUserGuideComponent } from './bh-user-guide.component';

describe('BhUserGuideComponent', () => {
  let component: BhUserGuideComponent;
  let fixture: ComponentFixture<BhUserGuideComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhUserGuideComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhUserGuideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
