import { Component, OnInit } from '@angular/core';
import { BhApiService } from 'app/services/bh-api.service';
import { AppConfigService, AlfrescoApiService, NodesApiService, NodeService } from '@alfresco/adf-core';
import { AlfrescoApi } from '@alfresco/js-api';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-bh-user-guide',
  templateUrl: './bh-user-guide.component.html',
  styleUrls: ['./bh-user-guide.component.scss']
})
export class BhUserGuideComponent implements OnInit {

  nodeId: string;

  showViewer = false;

  fileBlob: Blob;

  constructor(private http: HttpClient,
              private apiService: BhApiService,
              private appConfig: AppConfigService) { }

  ngOnInit() {
    // this.getRootNodeInfo();
  }

  getLibraryGuideLink(): string {
    return this.getBaseLink() + this.appConfig.get('userGuidePath');
  }

  getShareGuideLink(): string {
    return this.getBaseLink() + this.appConfig.get('userGuidePathShare');
  }

  getBaseLink(): string {
    let link = '';
    link += window.location.protocol;
    link += '//';
    link += window.location.host;
    link += '/qms-document-library';
    link += '/#/advanced-search?id=';
    return link;
  }

  getRootNodeInfo() {
    const userGuidePath = this.appConfig.get('userGuidePath');
    this.apiService.getNodeInfo('-root-', {
      relativePath: userGuidePath
    })
    .then(
      (node) => {
        console.log('Root Node : ', node);
        this.nodeId = node ? node.id : undefined;
      },
      (c) => {
        console.log('Root Node Error : ', c);
      }
    );
  }

  async onPreview() {
    if (this.nodeId === undefined || this.nodeId === '' || this.nodeId === null) {
      await this.getRootNodeInfo();
    }
    this.showViewer = true;
  }

  onOpen() {
    window.open('http://localhost:8080/share/s/ksMIa9D0RqGMQTBzc5fJ9Q', '_blank');
  }

  onViewerToggle(event) {
    this.showViewer = !this.showViewer;
  }

  // Alf Ticket access test
  async getPreview() {
    await this.apiService.getAlfTicket().then(
      (r) => {
        // console.log('Ticket Result : ', r);
        if (r && r.at) {
          console.log('New Token : ', r.at);
          const token = r.at;
          this.getBlob(token);
        } else {
          console.log('Token not available');
        }
      },
      (c) => {
        console.error('Get Alf ticket Error : ', c);
      }
    );
  }

  async getBlob(token: string) {
    if (this.nodeId === undefined || this.nodeId === '' || this.nodeId === null) {
      await this.getRootNodeInfo();
    }

    const url = this.apiService.getContentUrl(this.nodeId);

    const header = {
      headers: new HttpHeaders()
        .set('Authorization',  'Bearer ' + token),
      responseType: 'blob' as 'json'
    };

    await this.http.get(url, header).subscribe(
      (r: Blob) => {
        this.fileBlob = r;
        console.log('response', r);
      },
      (c) => {
        console.log('error', c);
      }
    );

    this.showViewer = true;
  }

}
