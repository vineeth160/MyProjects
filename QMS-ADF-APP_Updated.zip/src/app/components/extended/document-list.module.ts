/*!
 * @license
 * Copyright 2019 Alfresco Software, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CoreModule, EditJsonDialogModule } from '@alfresco/adf-core';

import { MaterialModule } from './material.module';
import {
  UploadModule,
  TrashcanNameColumnComponent,
  LibraryStatusColumnComponent,
  LibraryRoleColumnComponent,
  LibraryNameColumnComponent,
  NameColumnComponent } from '@alfresco/adf-content-services';
import { BhDocumentListComponent } from './bh-document-list/bh-document-list.component';
import { BhContentActionComponent } from './bh-content-action/bh-content-action.component';
import { BhContentActionListComponent } from './bh-content-action-list/bh-content-action-list.component';

@NgModule({
    imports: [
        CoreModule,
        CommonModule,
        FlexLayoutModule,
        MaterialModule,
        UploadModule,
        EditJsonDialogModule
    ],
    declarations: [
        BhDocumentListComponent,

        BhContentActionComponent,
        BhContentActionListComponent
    ],
    exports: [
        BhDocumentListComponent,

        BhContentActionComponent,
        BhContentActionListComponent
    ],
    entryComponents: [

    ]
})
export class DocumentListModule {}
