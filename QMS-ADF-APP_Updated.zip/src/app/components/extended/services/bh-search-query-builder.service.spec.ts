import { TestBed } from '@angular/core/testing';

import { BhSearchQueryBuilderService } from './bh-search-query-builder.service';

describe('BhSearchQueryBuilderService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BhSearchQueryBuilderService = TestBed.get(BhSearchQueryBuilderService);
    expect(service).toBeTruthy();
  });
});
