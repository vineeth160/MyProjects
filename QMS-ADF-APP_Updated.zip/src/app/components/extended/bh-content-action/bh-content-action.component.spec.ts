import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhContentActionComponent } from './bh-content-action.component';

describe('BhContentActionComponent', () => {
  let component: BhContentActionComponent;
  let fixture: ComponentFixture<BhContentActionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhContentActionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhContentActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
