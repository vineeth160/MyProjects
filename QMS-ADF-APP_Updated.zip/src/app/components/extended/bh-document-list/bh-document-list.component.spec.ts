import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhDocumentListComponent } from './bh-document-list.component';

describe('BhDocumentListComponent', () => {
  let component: BhDocumentListComponent;
  let fixture: ComponentFixture<BhDocumentListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhDocumentListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhDocumentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
