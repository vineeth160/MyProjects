import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhContentActionListComponent } from './bh-content-action-list.component';

describe('BhContentActionListComponent', () => {
  let component: BhContentActionListComponent;
  let fixture: ComponentFixture<BhContentActionListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhContentActionListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhContentActionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
