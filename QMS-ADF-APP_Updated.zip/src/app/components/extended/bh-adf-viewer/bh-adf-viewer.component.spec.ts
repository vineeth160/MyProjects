import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhAdfViewerComponent } from './bh-adf-viewer.component';

describe('BhAdfViewerComponent', () => {
  let component: BhAdfViewerComponent;
  let fixture: ComponentFixture<BhAdfViewerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhAdfViewerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhAdfViewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
