import {
  Component, ContentChild, EventEmitter, HostListener, ElementRef,
    Input, OnChanges, Output, TemplateRef,
    ViewEncapsulation, OnInit, OnDestroy } from '@angular/core';
import {
  ViewerToolbarComponent,
  ViewerSidebarComponent,
  ViewerOpenWithComponent,
  ViewerMoreActionsComponent,
  BaseEvent,
  AlfrescoApiService,
  ViewUtilService,
  LogService,
  AppConfigService} from '@alfresco/adf-core';
import { RenditionPaging, SharedLinkEntry, Node, RenditionEntry, NodeEntry } from '@alfresco/js-api';
import { ViewerExtensionRef, AppExtensionService } from '@alfresco/adf-extensions';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { BhApiService } from 'app/services/bh-api.service';

@Component({
  selector: 'app-bh-adf-viewer',
  templateUrl: './bh-adf-viewer.component.html',
  styleUrls: ['./bh-adf-viewer.component.scss'],
  host: { 'class': 'app-bh-adf-viewer' },
  encapsulation: ViewEncapsulation.None
})
export class BhAdfViewerComponent implements OnChanges, OnInit, OnDestroy {

  @ContentChild(ViewerToolbarComponent)
  toolbar: ViewerToolbarComponent;

  @ContentChild(ViewerSidebarComponent)
  sidebar: ViewerSidebarComponent;

  @ContentChild(ViewerOpenWithComponent)
  mnuOpenWith: ViewerOpenWithComponent;

  @ContentChild(ViewerMoreActionsComponent)
  mnuMoreActions: ViewerMoreActionsComponent;

  /** If you want to load an external file that does not come from ACS you
   * can use this URL to specify where to load the file from.
   */
  @Input()
  urlFile = '';

  /** Viewer to use with the `urlFile` address (`pdf`, `image`, `media`, `text`).
   * Used when `urlFile` has no filename and extension.
   */
  @Input()
  urlFileViewer: string = null;

  /** Loads a Blob File */
  @Input()
  blobFile: Blob;

  /** Node Id of the file to load. */
  @Input()
  nodeId: string = null;

  /** Shared link id (to display shared file). */
  @Input()
  sharedLinkId: string = null;

  /** If `true` then show the Viewer as a full page over the current content.
   * Otherwise fit inside the parent div.
   */
  @Input()
  overlayMode = false;

  /** Hide or show the viewer */
  @Input()
  showViewer = true;

  /** Hide or show the toolbar */
  @Input()
  showToolbar = true;

  /** Specifies the name of the file when it is not available from the URL. */
  @Input()
  displayName: string;

  /** @deprecated 3.2.0 */
  /** Allows `back` navigation */
  @Input()
  allowGoBack = true;

  /** Toggles downloading. */
  @Input()
  allowDownload = true;

  /** Toggles printing. */
  @Input()
  allowPrint = false;

  /** Toggles the 'Full Screen' feature. */
  @Input()
  allowFullScreen = true;

  /** Toggles before/next navigation. You can use the arrow buttons to navigate
   * between documents in the collection.
   */
  @Input()
  allowNavigate = false;

  /** Toggles the "before" ("<") button. Requires `allowNavigate` to be enabled. */
  @Input()
  canNavigateBefore = true;

  /** Toggles the next (">") button. Requires `allowNavigate` to be enabled. */
  @Input()
  canNavigateNext = true;

  /** Allow the left the sidebar. */
  @Input()
  allowLeftSidebar = false;

  /** Allow the right sidebar. */
  @Input()
  allowRightSidebar = false;

  /** Toggles PDF thumbnails. */
  @Input()
  allowThumbnails = true;

  /** Toggles right sidebar visibility. Requires `allowRightSidebar` to be set to `true`. */
  @Input()
  showRightSidebar = false;

  /** Toggles left sidebar visibility. Requires `allowLeftSidebar` to be set to `true`. */
  @Input()
  showLeftSidebar = false;

  /** The template for the right sidebar. The template context contains the loaded node data. */
  @Input()
  sidebarRightTemplate: TemplateRef<any> = null;

  /** The template for the left sidebar. The template context contains the loaded node data. */
  @Input()
  sidebarLeftTemplate: TemplateRef<any> = null;

  /** The template for the pdf thumbnails. */
  @Input()
  thumbnailsTemplate: TemplateRef<any> = null;

  /** MIME type of the file content (when not determined by the filename extension). */
  @Input()
  mimeType: string;

  /** Content filename. */
  @Input()
  fileName: string;

  /** Number of times the Viewer will retry fetching content Rendition.
   * There is a delay of at least one second between attempts.
   */
  @Input()
  maxRetries = 5; // BH updated
  // maxRetries = 30;

  /** Emitted when user clicks the 'Back' button. */
  @Output()
  goBack = new EventEmitter<BaseEvent<any>>();

  /** Emitted when user clicks the 'Print' button. */
  @Output()
  print = new EventEmitter<BaseEvent<any>>();

  /** Emitted when the viewer is shown or hidden. */
  @Output()
  showViewerChange = new EventEmitter<boolean>();

  /** Emitted when the filename extension changes. */
  @Output()
  extensionChange = new EventEmitter<string>();

  /** Emitted when user clicks 'Navigate Before' ("<") button. */
  @Output()
  navigateBefore = new EventEmitter<MouseEvent|KeyboardEvent>();

  /** Emitted when user clicks 'Navigate Next' (">") button. */
  @Output()
  navigateNext = new EventEmitter<MouseEvent|KeyboardEvent>();

  /** Emitted when the shared link used is not valid. */
  @Output()
  invalidSharedLink = new EventEmitter();

  TRY_TIMEOUT = 10000;

  viewerType = 'unknown';
  isLoading = false;
  nodeEntry: NodeEntry;

  extensionTemplates: { template: TemplateRef<any>, isVisible: boolean }[] = [];
  externalExtensions: string[] = [];
  urlFileContent: string;
  otherMenu: any;
  extension: string;
  sidebarRightTemplateContext: { node: Node } = { node: null };
  sidebarLeftTemplateContext: { node: Node } = { node: null };
  fileTitle: string;
  viewerExtensions: Array<ViewerExtensionRef> = [];

  private cacheBusterNumber;

  private subscriptions: Subscription[] = [];

  // Extensions that are supported by the Viewer without conversion
  private extensions = {
      image: ['png', 'jpg', 'jpeg', 'gif', 'bpm', 'svg'],
      media: ['wav', 'mp4', 'mp3', 'webm', 'ogg'],
      text: ['txt', 'xml', 'html', 'json', 'ts', 'css', 'md'],
      pdf: ['pdf']
  };

  // Mime types that are supported by the Viewer without conversion
  private mimeTypes = {
      text: ['text/plain', 'text/csv', 'text/xml', 'text/html', 'application/x-javascript'],
      pdf: ['application/pdf'],
      image: ['image/png', 'image/jpeg', 'image/gif', 'image/bmp', 'image/svg+xml'],
      media: ['video/mp4', 'video/webm', 'video/ogg', 'audio/mpeg', 'audio/mp3', 'audio/ogg', 'audio/wav']
  };

  constructor(private apiService: AlfrescoApiService,
              private bhApi: BhApiService,
              private viewUtils: ViewUtilService,
              private logService: LogService,
              private extensionService: AppExtensionService,
              private el: ElementRef,
              private appConfig: AppConfigService) {
  }

  isSourceDefined(): boolean {
      return (this.urlFile || this.blobFile || this.nodeId || this.sharedLinkId) ? true : false;
  }

  ngOnInit() {
      this.subscriptions.push(
          this.bhApi.nodeUpdated.pipe(
              filter((node) => node && node.id === this.nodeId && node.name !== this.fileName)
          ).subscribe((node) => this.onNodeUpdated(node))
      );

      this.loadExtensions();
  }

  private loadExtensions() {
      this.viewerExtensions = this.extensionService.getViewerExtensions();
      this.viewerExtensions
          .forEach((extension: ViewerExtensionRef) => {
              this.externalExtensions.push(extension.fileExtension);
          });
  }

  ngOnDestroy() {
      this.subscriptions.forEach((subscription) => subscription.unsubscribe());
      this.subscriptions = [];
  }

  private onNodeUpdated(node: Node) {
      if (node && node.id === this.nodeId) {
          this.generateCacheBusterNumber();
          this.isLoading = true;
          this.bhSetUpNodeFile(node).then(() => {
              this.isLoading = false;
          });
      }
  }

  ngOnChanges() {
      if (this.showViewer) {
          if (!this.isSourceDefined()) {
              throw new Error('A content source attribute value is missing.');
          }
          this.isLoading = true;

          if (this.blobFile) {
              this.setUpBlobData();
              this.isLoading = false;
          } else if (this.urlFile) {
              this.setUpUrlFile();
              this.isLoading = false;
          } else if (this.nodeId) {
              this.bhApi.getNode(this.nodeId, { include: ['allowableOperations'] }).then(
                  (node: NodeEntry) => {
                      this.nodeEntry = node;
                      this.bhSetUpNodeFile(node.entry).then(() => {
                        this.isLoading = false;
                      });
                  },
                  () => {
                      this.isLoading = false;
                      this.logService.error('This node does not exist');
                  }
              );
          } else if (this.sharedLinkId) {
              this.allowGoBack = false;

              this.bhApi.getSharedLink(this.sharedLinkId).then(
                  (sharedLinkEntry: SharedLinkEntry) => {
                      this.setUpSharedLinkFile(sharedLinkEntry);
                      this.isLoading = false;
                  },
                  () => {
                      this.isLoading = false;
                      this.logService.error('This sharedLink does not exist');
                      this.invalidSharedLink.next();
                  });
          }
      }
  }

  canPreview(node: Node): boolean {
    let result = false;
    const defaultLimit: number = this.appConfig.get('previewSizeLimitDefault');
    let nodeMimeType = node.content.mimeType;
    const isNodeMimeType = nodeMimeType !== null && nodeMimeType !== undefined && nodeMimeType !== '';
    if (isNodeMimeType) {
      nodeMimeType = nodeMimeType.toLowerCase().trim();
      const size = node.content.sizeInBytes;
      const nodeSizeToMB = Math.floor((size / Math.pow(1024, 2)));
      const preview = this.appConfig.get('previewSizeLimit');
      const isPreview = preview !== null && preview !== undefined && preview !== '' && preview !== {};
      if (isPreview) {
        result = this.checkMimeType(preview, nodeMimeType, nodeSizeToMB, defaultLimit);
      } else {
        result = defaultLimit ? nodeSizeToMB <= defaultLimit : false;
      }
    }

    return result;
  }

  checkMimeType(preview: any, m: string, s: number, dl: number): boolean {
    let result = false;
    const keys = Object.keys(preview);
    let mk = false, ms = dl;
    keys.forEach((k) => {
      const mimeType = preview[k]['mimeType'];
      const isMT = mimeType !== null && mimeType !== undefined && mimeType !== '' && mimeType !== [];
      if (isMT) {
        const index = mimeType.indexOf(m);
        if (index !== -1) {
          mk = true;
          ms = preview[k]['size'];
        }
      }
    });

    if (mk) {
      result = ms === 0 ? true : s <= ms;
    } else {
      result = dl ? s <= dl : false;
    }

    return result;
  }

  private setUpBlobData() {
      this.fileTitle = this.getDisplayName('Unknown');
      this.mimeType = this.blobFile.type;
      this.viewerType = this.getViewerTypeByMimeType(this.mimeType);

      this.allowDownload = true;
      // TODO: wrap blob into the data url and allow downloading

      this.extensionChange.emit(this.mimeType);
      this.scrollTop();
  }

  private setUpUrlFile() {
      const filenameFromUrl = this.getFilenameFromUrl(this.urlFile);
      this.fileTitle = this.getDisplayName(filenameFromUrl);
      this.extension = this.getFileExtension(filenameFromUrl);
      this.urlFileContent = this.urlFile;

      this.fileName = this.displayName;

      this.viewerType = this.urlFileViewer || this.getViewerTypeByExtension(this.extension);
      if (this.viewerType === 'unknown') {
          this.viewerType = this.getViewerTypeByMimeType(this.mimeType);
      }

      this.extensionChange.emit(this.extension);
      this.scrollTop();
  }

  private async bhSetUpNodeFile(data: Node) {
    let setupNode;

    // Bh Document Size Limit Check
    const canPreview = this.canPreview(data);
    if (!canPreview) {
      this.viewerType = 'size_limit';
    }

    if (data.content) {
        this.mimeType = data.content.mimeType;
    }

    this.fileTitle = this.getDisplayName(data.name);

    this.extension = this.getFileExtension(data.name);

    this.fileName = data.name;

    if (this.viewerType !== 'size_limit') {
      this.viewerType = this.getViewerTypeByExtension(this.extension);
      if (this.viewerType === 'unknown') {
          this.viewerType = this.getViewerTypeByMimeType(this.mimeType);
      }

      if (this.viewerType === 'unknown') {
          setupNode = await this.bhDisplayNodeRendition(data.id);
      } else {
        await this.getBlobFile(data.id, false);
      }
    }

    this.extensionChange.emit(this.extension);
    this.sidebarRightTemplateContext.node = data;
    this.sidebarLeftTemplateContext.node = data;
    this.scrollTop();

    return setupNode;
  }

  private async bhGetBlob(url: string, id: string, isRendition: boolean, renditionId?: string) {
    await this.bhApi.bhGetBlob(url).then(
      (r) => {
        console.log('Blob response');
        this.blobFile = r;
      },
      (c) => {
        console.log('Blob Response Error : ', c);
        this.bhBlobUsingToken(id, isRendition, renditionId);
      }
    );
  }

  private async bhBlobUsingToken(id: string, isRendition: boolean, renditionId?: string) {
    let url = this.bhApi.getContentUrl(id, false);
    if (isRendition) {
      url = this.bhApi.getRenditionUrl(id, renditionId, false);
    }
    await this.bhApi.bhGetBlob(url, true).then(
      (r) => {
        console.log('Blob response using token');
        this.blobFile = r;
      },
      (c) => {
        console.log('Blob Response Error : ', c);
        if (isRendition) {
          this.urlFileContent = this.bhApi.getDefaultRenditionUrl(id, renditionId);
        } else {
          this.urlFileContent = this.bhApi.getDefaultContentUrl(id);
        }
        this.urlFileContent += this.bhApi.getLocalTicket();
      }
    );
  }

  private async getBlobFile(nodeId: string, isRendition: boolean, renditionId?: string, ) {
    if (this.blobFile === null || this.blobFile === undefined) {
      if (isRendition) {
        const url = this.bhApi.bhGetRenditionUrl(nodeId, renditionId);
        await this.bhGetBlob(url, nodeId, true, renditionId);
      } else {
        const url = this.bhApi.bhGetContentUrl(nodeId);
        await this.bhGetBlob(url, nodeId, false);
      }
    }
  }

  private async setUpNodeFile(data: Node) {
      let setupNode;

      if (data.content) {
          this.mimeType = data.content.mimeType;
      }

      this.fileTitle = this.getDisplayName(data.name);

      this.urlFileContent = this.bhApi.getContentUrl(data.id);

      await this.bhApi.getAlfTicket().then(
        (r) => {
          // console.log('Ticket Result : ', r);
          if (r && r.ticket) {
            // console.log('Ticket : ', r.ticket);
            this.bhApi.setToken(r.at);
            this.urlFileContent += '&alf_ticket=' + r.ticket;
          } else {
            this.urlFileContent += this.bhApi.getLocalTicket();
          }
        },
        (c) => {
          console.error('Get Alf ticket Error : ', c);
          this.urlFileContent += this.bhApi.getLocalTicket();
        }
      );

      this.urlFileContent = this.cacheBusterNumber ? this.urlFileContent + '&' + this.cacheBusterNumber : this.urlFileContent;
      // Customization - start
      // this.urlFileContent = this.urlFileContent.replace('api/-default-', 'service/bh');
      // Customization - end

      this.extension = this.getFileExtension(data.name);

      this.fileName = data.name;

      this.viewerType = this.getViewerTypeByExtension(this.extension);
      if (this.viewerType === 'unknown') {
          this.viewerType = this.getViewerTypeByMimeType(this.mimeType);
      }

      if (this.viewerType === 'unknown') {
          setupNode = this.bhDisplayNodeRendition(data.id);
      }

      this.extensionChange.emit(this.extension);
      this.sidebarRightTemplateContext.node = data;
      this.sidebarLeftTemplateContext.node = data;
      this.scrollTop();

      return setupNode;
  }

  private setUpSharedLinkFile(details: any) {
      this.mimeType = details.entry.content.mimeType;
      this.fileTitle = this.getDisplayName(details.entry.name);
      this.extension = this.getFileExtension(details.entry.name);
      this.fileName = details.entry.name;

      this.urlFileContent = this.apiService.contentApi.getSharedLinkContentUrl(this.sharedLinkId, false);
      // Customization - start
      this.urlFileContent = this.urlFileContent.replace('api/-default-', 'service/bh');
      // Customization - end

      this.viewerType = this.getViewerTypeByMimeType(this.mimeType);
      if (this.viewerType === 'unknown') {
          this.viewerType = this.getViewerTypeByExtension(this.extension);
      }

      if (this.viewerType === 'unknown') {
          this.displaySharedLinkRendition(this.sharedLinkId);
      }

      this.extensionChange.emit(this.extension);
  }

  toggleSidebar() {
      this.showRightSidebar = !this.showRightSidebar;
      if (this.showRightSidebar && this.nodeId) {
          this.bhApi.getNode(this.nodeId, { include: ['allowableOperations'] })
              .then((nodeEntry: NodeEntry) => {
                  this.sidebarRightTemplateContext.node = nodeEntry.entry;
              });
      }
  }

  toggleLeftSidebar() {
      this.showLeftSidebar = !this.showLeftSidebar;
      if (this.showRightSidebar && this.nodeId) {
          this.bhApi.getNode(this.nodeId, { include: ['allowableOperations'] })
              .then((nodeEntry: NodeEntry) => {
                  this.sidebarLeftTemplateContext.node = nodeEntry.entry;
              });
      }
  }

  private getDisplayName(name) {
      return this.displayName || name;
  }

  scrollTop() {
      window.scrollTo(0, 1);
  }

  getViewerTypeByMimeType(mimeType: string) {
      if (mimeType) {
          mimeType = mimeType.toLowerCase();

          const editorTypes = Object.keys(this.mimeTypes);
          for (const type of editorTypes) {
              if (this.mimeTypes[type].indexOf(mimeType) >= 0) {
                  return type;
              }
          }
      }
      return 'unknown';
  }

  getViewerTypeByExtension(extension: string) {
      if (extension) {
          extension = extension.toLowerCase();
      }

      if (this.isCustomViewerExtension(extension)) {
          return 'custom';
      }

      if (this.extensions.image.indexOf(extension) >= 0) {
          return 'image';
      }

      if (this.extensions.media.indexOf(extension) >= 0) {
          return 'media';
      }

      if (this.extensions.text.indexOf(extension) >= 0) {
          return 'text';
      }

      if (this.extensions.pdf.indexOf(extension) >= 0) {
          return 'pdf';
      }

      return 'unknown';
  }

  onBackButtonClick() {
      this.close();
  }

  onNavigateBeforeClick(event: MouseEvent|KeyboardEvent) {
      this.navigateBefore.next(event);
  }

  onNavigateNextClick(event: MouseEvent|KeyboardEvent) {
      this.navigateNext.next(event);
  }

  /**
   * close the viewer
   */
  close() {
      if (this.otherMenu) {
          this.otherMenu.hidden = false;
      }
      this.showViewer = false;
      this.showViewerChange.emit(this.showViewer);
  }

  /**
   * get File name from url
   *
   * @param  url - url file
   */
  getFilenameFromUrl(url: string): string {
      const anchor = url.indexOf('#');
      const query = url.indexOf('?');
      const end = Math.min(
          anchor > 0 ? anchor : url.length,
          query > 0 ? query : url.length);
      return url.substring(url.lastIndexOf('/', end) + 1, end);
  }

  /**
   * Get file extension from the string.
   * Supports the URL formats like:
   * http://localhost/test.jpg?cache=1000
   * http://localhost/test.jpg#cache=1000
   *
   * @param fileName - file name
   */
  getFileExtension(fileName: string): string {
      if (fileName) {
          const match = fileName.match(/\.([^\./\?\#]+)($|\?|\#)/);
          return match ? match[1] : null;
      }
      return null;
  }

  isCustomViewerExtension(extension: string): boolean {
      const extensions: any = this.externalExtensions || [];

      if (extension && extensions.length > 0) {
          extension = extension.toLowerCase();
          return extensions.flat().indexOf(extension) >= 0;
      }

      return false;
  }

  /**
   * Keyboard event listener
   * @param  event
   */
  @HostListener('document:keyup', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
      const key = event.keyCode;

      // Esc
      if (key === 27 && this.overlayMode) { // esc
          this.close();
      }

      // Left arrow
      if (key === 37 && this.canNavigateBefore) {
          event.preventDefault();
          this.onNavigateBeforeClick(event);
      }

      // Right arrow
      if (key === 39 && this.canNavigateNext) {
          event.preventDefault();
          this.onNavigateNextClick(event);
      }

      // Ctrl+F
      if (key === 70 && event.ctrlKey) {
          event.preventDefault();
          this.enterFullScreen();
      }
  }

  printContent() {
      if (this.allowPrint) {
          const args = new BaseEvent();
          this.print.next(args);

          if (!args.defaultPrevented) {
              this.viewUtils.printFileGeneric(this.nodeId, this.mimeType);
          }
      }
  }

  /**
   * Triggers full screen mode with a main content area displayed.
   */
  enterFullScreen(): void {
      if (this.allowFullScreen) {
          const container = this.el.nativeElement.querySelector('.adf-viewer__fullscreen-container');
          if (container) {
              if (container.requestFullscreen) {
                  container.requestFullscreen();
              } else if (container.webkitRequestFullscreen) {
                  container.webkitRequestFullscreen();
              } else if (container.mozRequestFullScreen) {
                  container.mozRequestFullScreen();
              } else if (container.msRequestFullscreen) {
                  container.msRequestFullscreen();
              }
          }
      }
  }

  private async bhDisplayNodeRendition(nodeId: string) {
    try {
      const rendition = await this.resolveRendition(nodeId, 'pdf');
      /* if (rendition) {
        const renditionId = rendition.entry.id;

        if (renditionId === 'pdf') {
            this.viewerType = 'pdf';
        } else if (renditionId === 'imgpreview') {
            this.viewerType = 'image';
        }

        // TO DO : get blob rendition
        this.getBlobFile(nodeId, true, renditionId);
      } */

    } catch (err) {
      this.logService.error(err);
    }
  }

  private async displayNodeRendition(nodeId: string) {
      try {
          const rendition = await this.resolveRendition(nodeId, 'pdf');
          if (rendition) {
              const renditionId = rendition.entry.id;

              if (renditionId === 'pdf') {
                  this.viewerType = 'pdf';
              } else if (renditionId === 'imgpreview') {
                  this.viewerType = 'image';
              }

              this.urlFileContent = this.bhApi.getRenditionUrl(nodeId, renditionId);

              await this.bhApi.getAlfTicket().then(
                (r) => {
                  // console.log('Ticket Result : ', r);
                  if (r && r.ticket) {
                    // console.log('Ticket : ', r.ticket);
                    this.bhApi.setToken(r.at);
                    this.urlFileContent += '&alf_ticket=' + r.ticket;
                  } else {
                    this.urlFileContent += this.bhApi.getLocalTicket();
                  }
                },
                (c) => {
                  console.error('Get Alf ticket Error : ', c);
                  this.urlFileContent += this.bhApi.getLocalTicket();
                }
              );

              // Customization - start
              // this.urlFileContent = this.urlFileContent.replace('api/-default-', 'service/bh');
              // Customization - end
          }
      } catch (err) {
          this.logService.error(err);
      }
  }

  private async displaySharedLinkRendition(sharedId: string) {
      try {
          const rendition: RenditionEntry = await this.bhApi.getSharedLinkRendition(sharedId, 'pdf');
          if (rendition.entry.status.toString() === 'CREATED') {
              this.viewerType = 'pdf';
              this.urlFileContent = this.apiService.contentApi.getSharedLinkRenditionUrl(sharedId, 'pdf');
              // Customization - start
              this.urlFileContent = this.urlFileContent.replace('api/-default-', 'service/bh');
              // Customization - end
          }
      } catch (error) {
          this.logService.error(error);
          try {
              const rendition: RenditionEntry = await this.bhApi.getSharedLinkRendition(sharedId, 'imgpreview');
              if (rendition.entry.status.toString() === 'CREATED') {
                  this.viewerType = 'image';
                  this.urlFileContent = this.apiService.contentApi.getSharedLinkRenditionUrl(sharedId, 'imgpreview');
                  // Customization - start
                  this.urlFileContent = this.urlFileContent.replace('api/-default-', 'service/bh');
                  // Customization - end
              }
          } catch (error) {
              this.logService.error(error);
          }
      }
  }

  private async resolveRendition(nodeId: string, renditionId: string): Promise<RenditionEntry> {
      this.viewerType = 'pdf';
      renditionId = renditionId.toLowerCase();

      const supportedRendition: RenditionPaging = await this.bhApi.getRenditions(nodeId);

      let rendition: RenditionEntry = supportedRendition.list.entries.find(
        (renditionEntry: RenditionEntry) => renditionEntry.entry.id.toLowerCase() === renditionId);
      if (!rendition) {
          this.viewerType = 'image';
          renditionId = 'imgpreview';
          rendition = supportedRendition.list.entries.find(
            (renditionEntry: RenditionEntry) => renditionEntry.entry.id.toLowerCase() === renditionId);
      }

      if (rendition) {
          const status: string = rendition.entry.status.toString();

          if (status === 'NOT_CREATED') {
              try {
                  await this.bhApi.createRendition(nodeId, { id: renditionId }).then(() => {
                      this.viewerType = 'in_creation';
                  });
                  rendition = await this.bhWaitRendition(nodeId, renditionId);
              } catch (err) {
                  this.logService.error(err);
              }
          } else if (status === 'CREATED') {
            // TO DO: get blob rendition
            this.getRenditionBlobFile(nodeId, renditionId);
          }
      }

      return rendition;
  }

  private async bhWaitRendition(nodeId: string, renditionId: string): Promise<RenditionEntry> {
    let currentRetry = 0;
    return new Promise<RenditionEntry>((resolve, reject) => {
      const intervalId = setInterval(() => {
          currentRetry++;
        if (this.maxRetries >= currentRetry) {
          this.bhApi.getRendition(nodeId, renditionId).then(async (rendition: RenditionEntry) => {
            const status: string = rendition.entry.status.toString();
            if (status === 'CREATED') {

              // TO DO: get blob rendition
              this.getRenditionBlobFile(nodeId, renditionId);

              clearInterval(intervalId);
              return resolve(rendition);
            }
          }, () => {
              this.viewerType = 'error_in_creation';
              return reject();
          });
        } else {
          this.isLoading = false;
          this.viewerType = 'error_in_creation';
          clearInterval(intervalId);
        }
      }, this.TRY_TIMEOUT);
    });
  }

  private getRenditionBlobFile(nodeId: string, renditionId: string) {
    if (renditionId === 'pdf') {
      this.viewerType = 'pdf';
    } else if (renditionId === 'imgpreview') {
        this.viewerType = 'image';
    }

    this.getBlobFile(nodeId, true, renditionId);
  }

  private async waitRendition(nodeId: string, renditionId: string): Promise<RenditionEntry> {
      let currentRetry = 0;
      return new Promise<RenditionEntry>((resolve, reject) => {
          const intervalId = setInterval(() => {
              currentRetry++;
              if (this.maxRetries >= currentRetry) {
                  this.bhApi.getRendition(nodeId, renditionId).then(async (rendition: RenditionEntry) => {
                      const status: string = rendition.entry.status.toString();
                      if (status === 'CREATED') {

                          if (renditionId === 'pdf') {
                              this.viewerType = 'pdf';
                          } else if (renditionId === 'imgpreview') {
                              this.viewerType = 'image';
                          }

                          this.urlFileContent = this.bhApi.getRenditionUrl(nodeId, renditionId);

                          await this.bhApi.getAlfTicket().then(
                            (r) => {
                              // console.log('Ticket Result : ', r);
                              if (r && r.ticket) {
                                // console.log('Ticket : ', r.ticket);
                                this.bhApi.setToken(r.at);
                                this.urlFileContent += '&alf_ticket=' + r.ticket;
                              } else {
                                this.urlFileContent += this.bhApi.getLocalTicket();
                              }
                            },
                            (c) => {
                              console.error('Get Alf ticket Error : ', c);
                              this.urlFileContent += this.bhApi.getLocalTicket();
                            }
                          );

                          clearInterval(intervalId);
                          return resolve(rendition);
                      }
                  }, () => {
                      this.viewerType = 'error_in_creation';
                      return reject();
                  });
              } else {
                  this.isLoading = false;
                  this.viewerType = 'error_in_creation';
                  clearInterval(intervalId);
              }
          }, this.TRY_TIMEOUT);
      });
  }

  checkExtensions(extensionAllowed) {
      if (typeof extensionAllowed === 'string') {
          return this.extension.toLowerCase() === extensionAllowed.toLowerCase();
      } else if (extensionAllowed.length > 0) {
          return extensionAllowed.find((currentExtension) => {
              return this.extension.toLowerCase() === currentExtension.toLowerCase();
          });
      }

  }

  private generateCacheBusterNumber() {
      this.cacheBusterNumber = Date.now();
  }
}
