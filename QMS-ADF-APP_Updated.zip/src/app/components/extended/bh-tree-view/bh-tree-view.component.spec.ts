import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhTreeViewComponent } from './bh-tree-view.component';

describe('BhTreeViewComponent', () => {
  let component: BhTreeViewComponent;
  let fixture: ComponentFixture<BhTreeViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhTreeViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhTreeViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
