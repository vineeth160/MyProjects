import { FlatTreeControl } from '@angular/cdk/tree';
import { Component, Input, OnChanges, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { TreeBaseNode } from '../models/tree-view.model';
import { TreeViewDataSource } from '../data/tree-view-datasource';
import { TreeViewService } from '../services/tree-view.service';
import { NodeEntry } from '@alfresco/js-api';

@Component({
  selector: 'app-bh-tree-view',
  templateUrl: './bh-tree-view.component.html',
  styleUrls: ['./bh-tree-view.component.scss']
})
export class BhTreeViewComponent implements OnChanges {
  /** Identifier of the node to display. */
  @Input()
  nodeId: string;

  /** Emitted when a node in the tree view is clicked. */
  @Output()
  nodeClicked: EventEmitter<NodeEntry> = new EventEmitter();

  /** Emitted when an invalid node id is given. */
  @Output()
  error: EventEmitter<any> = new EventEmitter();

  treeControl: FlatTreeControl<TreeBaseNode>;
  dataSource: TreeViewDataSource;

  isLoading = false;

  constructor(private treeViewService: TreeViewService) {
      this.treeControl = new FlatTreeControl<TreeBaseNode>(this.getLevel, this.isExpandable);
      this.dataSource = new TreeViewDataSource(this.treeControl, this.treeViewService);
  }

  ngOnChanges(changes: SimpleChanges) {
      if (changes['nodeId'] && changes['nodeId'].currentValue &&
          changes['nodeId'].currentValue !== changes['nodeId'].previousValue) {
          // this.loadTreeNode();

          // QMS changes - duplicate tree elements -start
          this.dataSource.data = [];
          if (!this.isLoading) {
            this.loadTreeNode();
          }
          // QMS changes - duplicate tree elements -end
      } else {
          this.dataSource.data = [];
      }
  }

  onNodeClicked(node: NodeEntry) {
      this.nodeClicked.emit(node);
  }

  getLevel = (node: TreeBaseNode) => node.level;

  isExpandable = (node: TreeBaseNode) => node.expandable;

  hasChild = (_: number, nodeData: TreeBaseNode) => nodeData.expandable;

  private loadTreeNode() {
      this.isLoading = true;
      this.treeViewService.getTreeNodes(this.nodeId)
          .subscribe(
              (treeNode: TreeBaseNode[]) => {
                  this.isLoading = false;
                  this.dataSource.data = treeNode;
              },
              (error) => {
                this.isLoading = false;
                this.error.emit(error);
              }
          );
  }

}
