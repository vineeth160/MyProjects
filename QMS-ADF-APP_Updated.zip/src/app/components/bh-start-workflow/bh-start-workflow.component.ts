import { Component, OnInit, Inject, ChangeDetectorRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, Validators, FormGroup, FormControl, ValidationErrors } from '@angular/forms';
import {
  AppConfigService,
  NotificationService,
  AlfrescoApiService,
  PeopleContentService,
  IdentityUserService,
  IdentityUserModel } from '@alfresco/adf-core';

import { SelectUserDialogComponent } from '../select-user-dialog/select-user-dialog.component';
import { MatDialog, MatDialogConfig } from '@angular/material';

import { BhWebscriptService, RequestOptions } from '../../services/bh-webscript.service';
import { BhDataListService } from '../../services/bh-data-list.service';

import { QueryBody, RequestQuery, RequestScope, PersonEntry, Person } from '@alfresco/js-api';
import { ConfirmDialogComponent } from '@alfresco/adf-content-services';
import { BhInfoDialogComponent } from '../../dialog/bh-info-dialog/bh-info-dialog.component';

import { IsDuplicate } from '../../directives/bh-is-duplicate.directive';
import { of, Observable } from 'rxjs';
import { BhApiService } from 'app/services/bh-api.service';

interface Options {
  id: string;
  name: string;
}

interface FormParams {
  requestType?: string;
  nodeRef?: string;
  category?: string;
  document?: File;
  url?: string;
  documentProperties?: any;
  workflowProperties?: any;
  assignees?: any;
  user?: any;
}

interface User {
  email?: string;
  firstName?: string;
  lastName?: string;
  id?: string;
}

@Component({
  selector: 'app-bh-start-workflow',
  templateUrl: './bh-start-workflow.component.html',
  styleUrls: ['./bh-start-workflow.component.scss']
})
export class BhStartWorkflowComponent implements OnInit {

  user: User = {
    email: '',
    firstName: '',
    lastName: '',
    id: ''
  };

  comments = [];

  productCompany: string;
  productCompanyLoading = false;

  showViewer = false;

  node: any;
  nodeId: string;
  taskId: string;
  workflowId: string;

  title: string;
  reasonLabel: string;
  submitLabel: string;
  params;
  resizeValue = 'fullscreen';
  resizeTooltip = 'Maximize';

  ecmHost: string;

  form: FormGroup;
  minDate: Date;

  documentName: string;
  description = '(None)';
  modifiedOn: string;

  documentAuthor = [];

  newRevisionNumber: String;
  newRevisionNumbers: Options[] = [];

  workflowActions = '';

  assigneeLoading = false;

  intakesMember = [];
  smeMember = [];
  adminMember = [];
  primaryReviewer = [];
  primaryApprover = [];
  additionalReviewer = [];
  additionalApprover = [];
  publisher = [];

  // Archival Assignees
  ofsArchivalMember = [];
  archivalAdminMember = [];
  archivalApproverMember = [];

  documentTypes: Options[] = [];
  productCompanies: Options[] = [];
  productLines: Options[] = [];
  subProductLines: Options[] = [];
  sites: Options[] = [];
  functions: Options[] = [];
  subFunctions: Options[] = [];
  languages: Options[] = [];
  contentCategories: Options[] = [];
  isoElements: Options[] = [];
  processes: Options[] = [];
  subProcesses: Options[] = [];
  userRoles: Options[] = [];

  submitLoading = false;

  validationMessages = {
    documentType: {
      required: 'Value is required',
    },
    documentName: {
      required: 'Value is required',
      minLength: 'Value must be at least 1 character long'
    },
    documentReferenceNumber: {
      required: 'Value is required',
      isDuplicate: 'Duplicate value, Please enter new Document Reference Number'
    },
    productCompany: {
      required: 'Value is required',
    },
    productLine: {
      required: 'Value is required',
    },
    subProductLine: {
      required: 'Value is required',
    },
    site: {
      required: 'Value is required',
    },
    function: {
      required: 'Value is required',
    },
    subFunction: {
      required: 'Value is required',
    },
    contentCategory: {
      required: 'Value is required',
    },
    documentAttachment: {
      required: 'Document is required for \'New QMS Document Request\'',
    },
    documentUrl: {
      required: 'Value is required',
    },
    reasonForRevision: {
      required: 'Value is required',
      minLength: 'Value must be at least 5 characters long'
    },
    documentAuthor: {
      required: 'Author must be selected'
    },
    newRevisionNumber: {
      required: 'Value is required'
    },
    isoElement: {
      required: 'Value is required',
    },
    process: {
      required: 'Value is required',
    },
    subProcess: {
      required: 'Value is required',
    },
    expiryDate: {
      required: 'Date value is required'
    },
    workflowActions: {
      required: 'Value is required'
    },
    intakesMember: {
      required: 'Assignee must be selected for \'New QMS Document Request\''
    },
    smeMember: {
      required: 'Assignee must be selected for \'New QMS Document Request\''
    },
    adminMember: {
      required: 'Assignee must be selected for \'New QMS Document Request\''
    },
    primaryReviewer: {
      required: 'Assignee must be selected for \'New QMS Document Request\''
    },
    primaryApprover: {
      required: 'Assignee must be selected for \'New QMS Document Request\''
    },
    ofsArchivalMember: {
      required: 'Assignee must be selected for \'Archival Document Request\''
    },
    archivalAdminMember: {
      required: 'Assignee must be selected for \'Archival Document Request\''
    },
    archivalApproverMember: {
      required: 'Assignee must be selected for \'Archival Document Request\''
    }
  };

  constructor(private fb: FormBuilder,
    private dialogRef: MatDialogRef<BhStartWorkflowComponent>,
    private apiService: AlfrescoApiService,
    private bhApi: BhApiService,
    private appConfig: AppConfigService,
    private dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private notificationService: NotificationService,
    private webScript: BhWebscriptService,
    private dataList: BhDataListService,
    private peopleService: PeopleContentService,
    private identityUserService: IdentityUserService) {

    this.ecmHost = this.appConfig.get<string>('ecmHost');

    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth();
    const currentDay = new Date().getDate();
    this.minDate = new Date(currentYear, currentMonth, currentDay);

    this.form = fb.group({
      requestType: [''],
      documentType: [''],
      documentName: [''],
      documentReferenceNumber: [''],
      productCompany: [''],
      productLine: [''],
      subProductLine: [''],
      site: [''],
      function: [''],
      subFunction: [''],
      language: [''],
      contentCategory: [''],
      documentAttachment: [''],
      documentUrl: [''],
      documentRevisionType: [''],
      documentRevisionNumber: [''],
      reasonForRevision: [''],
      documentAuthor: [this.documentAuthor],
      newRevisionNumber: [''],
      priority: ['2'],
      workflowActions: [''],
      intakesMember: [this.intakesMember],
      smeMember: [this.smeMember],
      adminMember: [this.adminMember],
      primaryReviewer: [this.primaryReviewer],
      additionalReviewer: [this.additionalReviewer],
      primaryApprover: [this.primaryApprover],
      additionalApprover: [this.additionalApprover],
      publisher: [this.publisher],
      isoElement: [''],
      process: [''],
      subProcess: [''],
      userRole: [''],
      effectiveDate: new FormControl({ value: '', disabled: false }),
      expiryDate: new FormControl({ value: '', disabled: false }),

      ofsArchivalMember: [this.ofsArchivalMember],
      archivalAdminMember: [this.archivalAdminMember],
      archivalApproverMember: [this.archivalApproverMember]
    });
  }

  ngOnInit() {

    // Document Request Type
    const rt = this.data.requestType;
    const rType = this.data.rType;

    this.getUserDetails();

    if (rt === 'new' ||
       (rt === 'submitter' && rType === 'NDR')) {
      this.defaultMandatoryFields();
    }

    if (rt === 'submitter' && rType === 'RDR') {
      this.form.controls.newRevisionNumber.setValidators(Validators.required);
    } else {
      this.form.controls.newRevisionNumber.clearValidators();
    }
    this.form.controls.newRevisionNumber.updateValueAndValidity();

    if (rt !== 'archive') {
      this.defaultMandatoryAssignees();
    }

    // Read Only for RDR/ADR
    if (rt === 'new' || (rt === 'submitter' && rType === 'NDR') ) {

      if (rt === 'new') {
        this.getDatalistUser();
      }

      // Data List
      // Document Type
      // this.getDataList('documentType', 'documentTypes', null);

      // Product Company
      this.getDataList('productCompany', 'productCompanies', null, true);

      // Site
      // this.getDataList('site', 'sites', null);

      // Function
      // this.getDataList('function', 'functions', null);

      // Language
      this.getDataList('language', 'languages', null, true);
      // Content Category
      this.getDataList('contentCategory', 'contentCategories', null, true);
      // ISO Element
      this.getDataList('isoElement', 'isoElements', null, true);
      // Process
      this.getDataList('process', 'processes', null, true);
      // User Role
      this.getDataList('userRole', 'userRoles', null, true);
    }

    if (rt === 'new') {
      this.title = 'New QMS Document Request';
      this.form.controls.requestType.setValue('NDR');
      this.form.controls.contentCategory.setValidators(Validators.required);
      this.form.controls.contentCategory.updateValueAndValidity();
      this.reasonLabel = 'Reason for Submission';
      this.submitLabel = 'Start';
    } else {

      this.form.controls.contentCategory.clearValidators();
      this.form.controls.contentCategory.updateValueAndValidity();

      if (rt === 'submitter') {
        this.title = 'Workflow Submitter Task | QMS Document Request';
        this.form.controls.requestType.setValue(rType);
        if (rType === 'NDR') {
          this.reasonLabel = 'Reason for Submission';
        } else if (rType === 'RDR') {
          this.reasonLabel = 'Reason for Latest Revision';
        }
        this.submitLabel = 'Submit';
        this.loadDocumentData(this.data);
        this.loadAssigneesData(this.data.assignees);
        this.loadComments(this.data.comments);
        this.workflowId = this.data.workflowId;
        this.workflowId = this.workflowId.replace('activiti$', '');
        this.form.controls.workflowActions.setValidators(Validators.required);
        this.form.controls.workflowActions.updateValueAndValidity();
      } else if (rt === 'revision') {
        this.title = 'QMS Document Revision Request';
        this.form.controls.requestType.setValue('RDR');
        this.reasonLabel = 'Reason for Latest Revision';
        this.submitLabel = 'Submit';
        this.getDocumentData(this.data.node);
        this.loadURM();
      } else if (rt === 'archive') {
        this.title = 'QMS Document Archive Request';
        this.form.controls.requestType.setValue('ADR');
        this.reasonLabel = 'Reason for Archival';
        this.submitLabel = 'Submit';
        this.getDocumentData(this.data.node);
        this.loadURM();
      }
    }

  }

  defaultMandatoryFields() {
    this.form.controls.documentName.setValidators(Validators.required);
    this.form.controls.documentName.setValidators(Validators.minLength(1));
    this.form.controls.documentName.updateValueAndValidity();

    this.form.controls.productCompany.setValidators(Validators.required);
    this.form.controls.productCompany.updateValueAndValidity();

    this.form.controls.productLine.setValidators(Validators.required);
    this.form.controls.productLine.updateValueAndValidity();

    this.form.controls.function.setValidators(Validators.required);
    this.form.controls.function.updateValueAndValidity();

    const referenceNumberControl = new FormControl('',
      { updateOn : 'blur', validators : [this.referenceValidator]}
    );

    this.form.setControl('documentReferenceNumber', referenceNumberControl);
    this.form.controls.documentReferenceNumber.updateValueAndValidity();

    this.form.controls.reasonForRevision.setValidators(Validators.required);
    this.form.controls.reasonForRevision.setValidators(Validators.minLength(5));
    this.form.controls.reasonForRevision.updateValueAndValidity();
  }

  defaultMandatoryAssignees() {
    this.form.controls.adminMember.setValidators(this.matChipValidator);
    this.form.controls.adminMember.updateValueAndValidity();

    this.form.controls.primaryReviewer.setValidators(this.matChipValidator);
    this.form.controls.primaryReviewer.updateValueAndValidity();

    this.form.controls.primaryApprover.setValidators(this.matChipValidator);
    this.form.controls.primaryApprover.updateValueAndValidity();
  }

  getUserDetails() {
    try {
      if (this.apiService.getInstance().isEcmLoggedIn()) {
        const p = this.peopleService.getCurrentPerson();
        p.toPromise().then(
          (r: PersonEntry) => {
            console.log('Logged In user Details r : ', r);
            if (r && r.entry) {
              const person: Person = r.entry;
              const email = person.email;
              if (email !== undefined && email !== null && email !== '') {
                this.user.email = email;
                const fn = person.firstName;
                this.user.firstName = fn !== undefined && fn !== null ? person.firstName : '';
                const ln = person.lastName;
                this.user.lastName = ln !== undefined && ln !== null ? person.lastName : '';
                this.user.id = person.id;
              } else {
                this.setIdentityUser();
              }
            } else {
              this.setIdentityUser();
            }
          },
          (c) => {
            console.log('ECM user Details Error : ', c);
          }
        );
      } else {
        this.setIdentityUser();
      }
    } catch (e) {
      console.log('ECM/Identity User Error : ', e);
    }
  }

  setIdentityUser() {
    const person: IdentityUserModel = this.identityUserService.getCurrentUserInfo();
    const email = person.email;
    if (email !== undefined && email !== null && email !== '') {
      this.user.email = email;
      const fn = person.firstName;
      this.user.firstName = fn !== undefined && fn !== null ? person.firstName : '';
      const ln = person.lastName;
      this.user.lastName = ln !== undefined && ln !== null ? person.lastName : '';
      this.user.id = person.username;
    } else {
      this.openInfoDialog(
        'Info',
        true,
        'Email id not available in the system and some of the functionality will not work as expected,' +
        ' Please contact Administrator');
    }
  }

  getDatalistUser() {
    this.productCompanyLoading = true;
    const person: IdentityUserModel = this.identityUserService.getCurrentUserInfo();
    let q = 'TYPE:"bhdl:hrSystemDataListItem"'
              + ' AND @bhdl:employee_status:"Active"'
              + ' AND @bhdl:is_employee_active:true';
    if (person.email !== undefined && person.email !== null && person.email !== '') {
      q += ' AND @bhdl:employee_email_id:"' + person.email + '"';
      this.getProductCompanyData(q);
    } else {
      if (this.apiService.getInstance().isEcmLoggedIn()) {
        const p = this.peopleService.getCurrentPerson();
        p.toPromise().then(
          (r: PersonEntry) => {
            console.log('Logged In user Details r : ', r);
            if (r && r.entry) {
              const ap: Person = r.entry;
              q +=  ' AND @bhdl:employee_email_id:"' + ap.email + '"';
              this.getProductCompanyData(q);
            }
          });
        }
    }
  }

  getProductCompanyData(q) {
    const queryBody: QueryBody = {
      query: new RequestQuery({
        language: 'afts',
        query: q
      }),
      include: ['path', 'properties', 'allowableOperations', 'permissions', 'aspectNames', 'association']
    };

    this.bhApi.searchByQueryBody(queryBody).toPromise().then(
      (r) => {
        this.productCompanyLoading = false;
        if (r && r.list && r.list.entries && r.list.entries.length > 0) {
          const entry = r.list.entries[0].entry;
          console.log('data list user entry : ', entry);
          // Author value update
          const user = {
            name: entry.properties['bhdl:employee_first_name']
                    + ' '
                    + entry.properties['bhdl:employee_last_name']
                    + ' '
                    + '('
                    + entry.properties['bhdl:employee_sso']
                    + ')',
            userName: 'workspace://SpacesStore/' + entry.id
          };
          const author = new Array();
          author.push(user);

          this.documentAuthor = author;
          this.form.controls.documentAuthor.setValue(author);
          this.form.controls.documentAuthor.markAsTouched();
          this.form.controls.documentAuthor.markAsDirty();
          this.form.controls.documentAuthor.updateValueAndValidity();

          let pc = entry.properties['bhdl:employee_business_segment'];
          if (pc !== undefined && pc !== null && pc !== '') {
            pc = pc.toLowerCase().trim();
            if (pc === 'turbomachinery process solutions') {
              this.productCompany = 'BH-TPS Turbomachinery & Process Solutions';
            } else if (pc === 'oilfield services') {
              this.productCompany = 'BH-OFS Oilfield Services';
            } else if (pc === 'digital solutions') {
              this.productCompany = 'BH-DS Digital Solutions';
            } else if (pc === 'headquarters') {
              this.productCompany = 'BH-Global';
            } else {
              this.productCompany = 'BH-TPS Turbomachinery & Process Solutions';
            }

            this.form.controls.productCompany.setValue(this.productCompany);
            this.form.controls.productCompany.markAsTouched();
            this.form.controls.productCompany.markAsDirty();
            this.form.controls.productCompany.updateValueAndValidity();
            this.onSelectionChange('productCompany');
          }
        } else {
          this.openInfoDialog('Error', true, 'User Details not available in "DataList"');
          console.log('User Details Not available');
        }
      },
      (c) => {
        this.productCompanyLoading = false;
        this.openInfoDialog('Error', true, c);
      }
    );
  }

  loadDocumentData(d) {
    this.taskId = d.id;
    this.taskId = this.taskId.replace('activiti$', '');
    let n: string = d.node;
    n = n.substring(n.lastIndexOf('/') + 1 );

    // Task Package and Properties API call
    this.bhApi.getNodeChildren(n).then(
      (r) => {
        console.log('child result : ', r.list.entries);
        if ( r.list.entries.length > 0 ) {
          const id = r.list.entries[0].entry.id;
          console.log('child id : ', id);
          this.nodeId = id;
          const opts = {
            include: ['path', 'properties', 'allowableOperations', 'permissions', 'aspectNames', 'association'],
            includeSource: true
          };
          this.bhApi.getNodeInfo(id, opts).then(
            (result) => {
              this.getDocumentDataDirect(result);
            }
          );
        }
      }
    );
  }

  getDocumentData(node) {
    if ( node !== null && node !== '' && node !== undefined ) {
      // Appending the document properties to form
      this.node = node;
      this.nodeId = node.id;
      this.form.controls.documentType.setValue(node['bhqms:document_type']);
      this.form.controls.documentName.setValue(node.name);
      this.form.controls.documentReferenceNumber.setValue(node['bhqms:reference']);
      this.form.controls.productCompany.setValue(node['bhqms:product_company']);
      // this.form.controls.productCompany.markAsDirty();


      // Single
      // this.form.controls.productLine.setValue(node['bhqms:product_line']);
      // Multiple
      const productLineValue = node['bhqms:product_line']; // TO DO: multiple or single value
      this.form.controls.productLine.setValue(
        Array.isArray(productLineValue) ? productLineValue : (
          productLineValue !== undefined &&
          productLineValue !== null &&
          productLineValue !== '' ? productLineValue.split(',') : productLineValue
        )
      );
      // this.form.controls.productLine.markAsDirty();

      // this.form.controls.subProductLine.setValue(node['bhqms:sub_product_line']);
      const subProductLineValue = node['bhqms:sub_product_line']; // TO DO: multiple or single value
      this.form.controls.subProductLine.setValue(
        Array.isArray(subProductLineValue) ? subProductLineValue : (
          subProductLineValue !== undefined &&
          subProductLineValue !== null &&
          subProductLineValue !== '' ? subProductLineValue.split(',') : subProductLineValue
        )
      );

      // Single Value
      // const siteValue = result['bhqms:site'];
      // this.form.controls.site.setValue(siteValue ? siteValue.split(',') : siteValue);
      // MUltiple value
      const siteValue = node['bhqms:site'];
      this.form.controls.site.setValue(
        Array.isArray(siteValue) ? siteValue : (
          siteValue !== undefined &&
          siteValue !== null &&
          siteValue !== '' ? siteValue.split(',') : siteValue
        )
      );

      // Single
      // const functionValue = node['bhqms:function'];  // TO DO: multiple or single value
      // this.form.controls.function.setValue(Array.isArray(functionValue) ? functionValue.join(', ') : functionValue);
      // Multiple
      const functionValue = node['bhqms:function']; // TO DO: multiple or single value
      this.form.controls.function.setValue(
        Array.isArray(functionValue) ? functionValue : (
          functionValue !== undefined &&
          functionValue !== null &&
          functionValue !== '' ? functionValue.split(',') : functionValue
        )
      );
      this.form.controls.subFunction.setValue(node['bhqms:sub_function']);
      this.form.controls.language.setValue(node['bhqms:language_code']);
      this.form.controls.contentCategory.setValue(node['bhqms:content_category']);
      // this.form.controls.documentRevisionType.setValue(node['cm:versionType']);
      // this.form.controls.documentRevisionNumber.setValue(node['cm:versionLabel']);

      const rn = node['bhqms:publish_revision'];
      if (rn !== undefined && rn !== null && rn !== '' && rn !== 'None' ) {
        this.form.controls.documentRevisionNumber.setValue(rn);
        const rnn = parseFloat(rn);
        console.log('Parsed Revision Number : ', rnn);
        const minor = (rnn + 0.1).toFixed(1);
        const major = (rnn + 1.0).toFixed();
        console.log('Minor : ', minor);
        console.log('Major : ', major);
        this.newRevisionNumbers = [
          { id : 'Minor-' + minor, name : 'Minor Change (' + minor + ')'},
          { id : 'Major-' + major + '.0', name : 'Major Change (' + major + '.0)'}
        ];
        console.log('New Revision Values : ', this.newRevisionNumbers);
      } else {
        this.form.controls.documentRevisionNumber.setValue(undefined);
      }

      // User need to fill the reason for RDR/ADR
      // this.form.controls.reasonForRevision.setValue(node['bhqms:reason_for_revision']);

      /* // Document Author
      const authorValue = node['bhqms:document_author'];
      // TO DO: fetch author details and append the object
      const author = [{ name : '', userName : authorValue }];
      this.form.controls.documentAuthor.setValue(author); */

      // Document Author
      const authorValue = node['bhqms:document_author'];
      // TO DO: fetch author details and append the object
      if (authorValue !== undefined && authorValue !== '' && authorValue !== null) {
        const a = new Array();
        a.push(authorValue);
        this.form.controls.documentAuthor.setValue(a);
        this.documentAuthor = a;
        // this.loadDataFromNodeRef(authorValue);
        /* const author = [{ name : authorValue, userName : authorValue }];
        this.form.controls.documentAuthor.setValue(author);
        this.documentAuthor = author; */
      }

      // Additional Information
      const isoElementValue = node['bhqms:iso_element']; // TO DO: multiple or single value
      this.form.controls.isoElement.setValue(
        Array.isArray(isoElementValue) ? isoElementValue : (
          isoElementValue !== undefined &&
          isoElementValue !== null &&
          isoElementValue !== '' ? isoElementValue.split(',') : isoElementValue
        )
      );

      // Single
      // this.form.controls.process.setValue(node['bhqms:process']);
      // Multiple
      const processValue = node['bhqms:process']; // TO DO: multiple or single value
      this.form.controls.process.setValue(
        Array.isArray(processValue) ? processValue : (
          processValue !== undefined &&
          processValue !== null &&
          processValue !== '' ? processValue.split(',') : processValue
        )
      );

      // Single
      // this.form.controls.subProcess.setValue(node['bhqms:sub_process']);
      // Multiple
      const subProcessValue = node['bhqms:sub_process']; // TO DO: multiple or single value
      this.form.controls.subProcess.setValue(
        Array.isArray(subProcessValue) ? subProcessValue : (
          subProcessValue !== undefined &&
          subProcessValue !== null &&
          subProcessValue !== '' ? subProcessValue.split(',') : subProcessValue
        )
      );

      // User Role Property not available in updated content model :(
      const userRoleValue = node['bhqms:user_role'];
      this.form.controls.userRole.setValue(
        Array.isArray(userRoleValue) ? userRoleValue : (
          userRoleValue !== undefined &&
          userRoleValue !== null &&
          userRoleValue !== '' ? userRoleValue.split(',') : userRoleValue
        )
      );

      this.form.controls.effectiveDate.setValue(node['bhqms:effective_date']);
      this.form.controls.expiryDate.setValue(node['bhqms:expiry_date']);

      this.documentName = node.name;
      this.description = node['cm:description'];
      const modifiedAt = node.modifiedAt;
      const d = Date.parse(modifiedAt);

      this.modifiedOn = new Date(d).toLocaleDateString();

      // Read Only data for RDR/ADR
      // Document Type
      // this.getDataList('documentType', 'documentTypes', 'productCompany', true);

      // Product Line Data List
      // this.getDataList('productLine', 'productLines', 'productCompany', true);

      // Sub Product Line Data List
      // this.getDataList('subProductLine', 'subProductLines', 'productLine', true);

      // Site Data List
      // this.getDataList('site', 'sites', 'productLine', true);

      // function
      // this.getDataList('function', 'functions', 'productCompany', true);

      // Sub Function Data List
      // this.getDataList('subFunction', 'subFunctions', 'function', true);

      // Sub Process data List
      // this.getDataList('subProcess', 'subProcesses', 'process', true);

      this.setMandatoryProperties('productCompany');

    } else {
      this.openInfoDialog('Error', false, 'Document details not available, please try again later');
    }
  }

  getDocumentDataDirect(node) {
    if ( node !== null && node !== '' && node !== undefined ) {
      // Appending the document properties to form
      this.node = node;
      this.nodeId = node.id;
      this.form.controls.documentType.setValue(node.properties['bhqms:document_type']);
      this.form.controls.documentName.setValue(node.name);
      this.form.controls.documentReferenceNumber.setValue(node.properties['bhqms:reference']);
      this.form.controls.productCompany.setValue(node.properties['bhqms:product_company']);
      // this.form.controls.productCompany.markAsDirty();


      // Single
      // this.form.controls.productLine.setValue(node.properties['bhqms:product_line']);
      // Multiple
      const productLineValue = node.properties['bhqms:product_line']; // TO DO: multiple or single value
      this.form.controls.productLine.setValue(
        Array.isArray(productLineValue) ? productLineValue : (
          productLineValue !== undefined &&
          productLineValue !== null &&
          productLineValue !== '' ? productLineValue.split(',') : productLineValue
        )
      );
      // this.form.controls.productLine.markAsDirty();

      // this.form.controls.subProductLine.setValue(node.properties['bhqms:sub_product_line']);
      const subProductLineValue = node.properties['bhqms:sub_product_line']; // TO DO: multiple or single value
      this.form.controls.subProductLine.setValue(
        Array.isArray(subProductLineValue) ? subProductLineValue : (
          subProductLineValue !== undefined &&
          subProductLineValue !== null &&
          subProductLineValue !== '' ? subProductLineValue.split(',') : subProductLineValue
        )
      );

      // Single Value
      // const siteValue = result.properties['bhqms:site'];
      // this.form.controls.site.setValue(siteValue ? siteValue.split(',') : siteValue);
      // MUltiple value
      const siteValue = node.properties['bhqms:site'];
      this.form.controls.site.setValue(
        Array.isArray(siteValue) ? siteValue : (
          siteValue !== undefined &&
          siteValue !== null &&
          siteValue !== '' ? siteValue.split(',') : siteValue
        )
      );

      // Single
      // const functionValue = node.properties['bhqms:function'];  // TO DO: multiple or single value
      // this.form.controls.function.setValue(Array.isArray(functionValue) ? functionValue.join(', ') : functionValue);
      // Multiple
      const functionValue = node.properties['bhqms:function']; // TO DO: multiple or single value
      this.form.controls.function.setValue(
        Array.isArray(functionValue) ? functionValue : (
          functionValue !== undefined &&
          functionValue !== null &&
          functionValue !== '' ? functionValue.split(',') : functionValue
        )
      );
      this.form.controls.subFunction.setValue(node.properties['bhqms:sub_function']);
      this.form.controls.language.setValue(node.properties['bhqms:language_code']);
      this.form.controls.contentCategory.setValue(node.properties['bhqms:content_category']);
      // this.form.controls.documentRevisionType.setValue(node.properties['cm:versionType']);
      // this.form.controls.documentRevisionNumber.setValue(node.properties['cm:versionLabel']);

      if (this.data.rType === 'RDR') {
        const rn = node.properties['bhqms:publish_revision'];
        if (rn !== undefined && rn !== null && rn !== '' && rn !== 'None' ) {
          this.form.controls.documentRevisionNumber.setValue(rn);
          const rnn = parseFloat(rn);
          console.log('Parsed Revision Number : ', rnn);
          const minor = (rnn + 0.1).toFixed(1);
          const major = (rnn + 1.0).toFixed();
          console.log('Minor : ', minor);
          console.log('Major : ', major);
          this.newRevisionNumbers = [
            { id : 'Minor-' + minor, name : 'Minor Change (' + minor + ')'},
            { id : 'Major-' + major + '.0', name : 'Major Change (' + major + '.0)'}
          ];
          console.log('New Revision Values : ', this.newRevisionNumbers);
        } else {
          this.form.controls.documentRevisionNumber.setValue(undefined);
        }
      } else if (this.data.rType === 'NDR') {
        this.form.controls.documentRevisionNumber.setValue(this.data.revisionNumber);
      }

      // User need to fill the reason for RDR/ADR
      // this.form.controls.reasonForRevision.setValue(node.properties['bhqms:reason_for_revision']);

      /* // Document Author
      const authorValue = node.properties['bhqms:document_author'];
      // TO DO: fetch author details and append the object
      const author = [{ name : '', userName : authorValue }];
      this.form.controls.documentAuthor.setValue(author); */

      // Document Author
      const authorValue = node.properties['bhqms:document_author'];
      // TO DO: fetch author details and append the object
      if (authorValue !== undefined && authorValue !== '' && authorValue !== null) {
        this.loadDataFromNodeRef(authorValue);
        /* const author = [{ name : authorValue, userName : authorValue }];
        this.form.controls.documentAuthor.setValue(author);
        this.documentAuthor = author; */
      }

      // Additional Information
      const isoElementValue = node.properties['bhqms:iso_element']; // TO DO: multiple or single value
      this.form.controls.isoElement.setValue(
        Array.isArray(isoElementValue) ? isoElementValue : (
          isoElementValue !== undefined &&
          isoElementValue !== null &&
          isoElementValue !== '' ? isoElementValue.split(',') : isoElementValue
        )
      );

      // Single
      // this.form.controls.process.setValue(node.properties['bhqms:process']);
      // Multiple
      const processValue = node.properties['bhqms:process']; // TO DO: multiple or single value
      this.form.controls.process.setValue(
        Array.isArray(processValue) ? processValue : (
          processValue !== undefined &&
          processValue !== null &&
          processValue !== '' ? processValue.split(',') : processValue
        )
      );

      // Single
      // this.form.controls.subProcess.setValue(node.properties['bhqms:sub_process']);
      // Multiple
      const subProcessValue = node.properties['bhqms:sub_process']; // TO DO: multiple or single value
      this.form.controls.subProcess.setValue(
        Array.isArray(subProcessValue) ? subProcessValue : (
          subProcessValue !== undefined &&
          subProcessValue !== null &&
          subProcessValue !== '' ? subProcessValue.split(',') : subProcessValue
        )
      );

      // User Role Property not available in updated content model :(
      const userRoleValue = node.properties['bhqms:user_role'];
      this.form.controls.userRole.setValue(
        Array.isArray(userRoleValue) ? userRoleValue : (
          userRoleValue !== undefined &&
          userRoleValue !== null &&
          userRoleValue !== '' ? userRoleValue.split(',') : userRoleValue
        )
      );

      this.form.controls.effectiveDate.setValue(node.properties['bhqms:effective_date']);
      this.form.controls.expiryDate.setValue(node.properties['bhqms:expiry_date']);

      this.documentName = node.name;
      this.description = node.properties['cm:description'];
      this.modifiedOn = node.modifiedAt.toLocaleDateString();

      // Read Only data for RDR/ADR
      // Document Type
      this.getDataList('documentType', 'documentTypes', 'productCompany', true);

      // Product Line Data List
      this.getDataList('productLine', 'productLines', 'productCompany', true);

      // Sub Product Line Data List
      this.getDataList('subProductLine', 'subProductLines', 'productLine', true);

      // Site Data List
      this.getDataList('site', 'sites', 'productLine', true);

      // function
      this.getDataList('function', 'functions', 'productCompany', true);

      // Sub Function Data List
      this.getDataList('subFunction', 'subFunctions', 'function', true);

      // Sub Process data List
      this.getDataList('subProcess', 'subProcesses', 'process', true);

      this.setMandatoryProperties('productCompany');

    } else {
      this.openInfoDialog('Error', false, 'Document details not available, please try again later');
    }
  }

  loadDataFromNodeRef(nodeRef) {
    const queryParams = '?nodeRef=' + nodeRef + '&type=' + 'all';
    const options: RequestOptions = {
      path: '/service/getNodeDetails' + queryParams
    };
    this.webScript.get(options).then(
      (r) => {
        if (r && r.data && r.data.properties) {
          const author = [
            {
              name : r.data.properties.properties.name,
              userName : r.data.properties.nodeRef
            }
          ];
          this.form.controls.documentAuthor.setValue(author);
          this.documentAuthor = author;
        }
      },
      (c) => {
        console.log('Getting Author Data Error : ', c);
      }
    );
  }

  loadAssigneesData(assignees) {

    if (assignees !== undefined && assignees !== null && assignees !== '') {

      if (assignees.smeUser !== undefined && assignees.smeUser !== null && assignees.smeUser !== '') {
        const user = new Array();
        user.push(assignees.smeUser);
        this.smeMember = user;
        this.form.controls.smeMember.setValue(user);
      }

      if (assignees.intakesUser !== undefined && assignees.intakesUser !== null && assignees.intakesUser !== '') {
        const user = new Array();
        user.push(assignees.intakesUser);
        this.intakesMember = user;
        this.form.controls.intakesMember.setValue(user);
      }

      if (assignees.adminUser !== undefined && assignees.adminUser !== null && assignees.adminUser !== '') {
        const user = new Array();
        user.push(assignees.adminUser);
        this.adminMember = user;
        this.form.controls.adminMember.setValue(user);
      }

      if (assignees.primaryReviewerUser !== undefined && assignees.primaryReviewerUser !== null && assignees.primaryReviewerUser !== '') {
        const user = new Array();
        user.push(assignees.primaryReviewerUser);
        this.primaryReviewer = user;
        this.form.controls.primaryReviewer.setValue(user);
      }

      if (assignees.primaryApproverUser !== undefined && assignees.primaryApproverUser !== null && assignees.primaryApproverUser !== '') {
        const user = new Array();
        user.push(assignees.primaryApproverUser);
        this.primaryApprover = user;
        this.form.controls.primaryApprover.setValue(user);
      }

      if (assignees.reviewerUser !== undefined && assignees.reviewerUser !== null && assignees.reviewerUser !== '') {
        if (assignees.reviewerUser.length > 0) {
          this.additionalReviewer = assignees.reviewerUser;
          this.form.controls.additionalReviewer.setValue(assignees.reviewerUser);
        }
      }

      if (assignees.approverUser !== undefined && assignees.approverUser !== null && assignees.approverUser !== '') {
        if (assignees.approverUser.length > 0) {
          this.additionalApprover = assignees.approverUser;
          this.form.controls.additionalApprover.setValue(assignees.approverUser);
        }
      }

      if (assignees.publisherUser !== undefined && assignees.publisherUser !== null && assignees.publisherUser !== '') {
        const user = new Array();
        user.push(assignees.publisherUser);
        this.publisher = user;
        this.form.controls.publisher.setValue(user);
      }
    }
  }

  loadComments(comments: Array<any>) {
    if (comments !== undefined && comments.length > 0) {
      const tempComments = new Array();
      comments.forEach((c) => {
        const tempComment = new Object();
        if (c.type === 'bhwf:submitterTask') {
          tempComment['key'] = 'Submitter Comment';
        } else if (c.type === 'bhwf:intakesTask') {
          tempComment['key'] = 'Intakes Comment';
        } else if (c.type === 'bhwf:smeTask') {
          tempComment['key'] = 'SME Comment';
        } else if (c.type === 'bhwf:adminTask') {
          tempComment['key'] = 'Admin Comment';
        } else if (c.type === 'bhwf:reviewerTask') {
          tempComment['key'] = 'Reviewer Comment';
        } else if (c.type === 'bhwf:approverTask') {
          tempComment['key'] = 'Approver Comment';
        } else if (c.type === 'bhwf:publisherTask') {
          tempComment['key'] = 'Publisher Comment';
        }
        tempComment['value'] = c.comment;
        tempComments.push(tempComment);
      });
      this.comments = tempComments;
    }
    console.log('All Comments : ', comments);
  }

  loadURM() {
    const f = this.form.value;
    const pc = f.productCompany;
    if (pc !== undefined && pc !== null && pc !== '') {
      this.assigneeLoading = true;
      const p = this.getURMParams(f);
      const options: RequestOptions = {
        path: '/service/bh/qms/datalist/urmdatalistvalues/' + 'bh-qms-documents' + '/' + 'userRoleMappingDataListItem',
        formParams: p,
        bodyParam: p
      };
      this.webScript.post(options).then(
        (r) => {
          this.assigneeLoading = false;
          // console.log('Response : ', r);
          // TO DO : update assignees data
          if (r) {
            this.loadURMMap(r);
          } else {
            this.openInfoDialog('Error', true, 'Unable to get "User Mapping" details');
          }
        },
        (e) => {
          this.assigneeLoading = false;
          console.log('Error : ', e);
          this.openInfoDialog('Error', true, e);
        }
      );
    } else {
      this.openInfoDialog('Information', true, 'Please select "Product Company" value and then proceed');
    }
  }

  getURMParams(f: any) {
    const json = {
      'urm_document_type': '',
      'urm_product_company': '',
      'urm_product_line': '',
      'urm_sub_product_line': '',
      'urm_function': '',
      'urm_sub_function': '',
      'urm_site': ''
   };
    if (f.productCompany !== null && f.productCompany !== undefined && f.productCompany !== '') {
      json['urm_product_company'] = f.productCompany;
    }

    if (f.productLine !== null && f.productLine !== undefined && f.productLine !== '') {
      json['urm_product_line'] = Array.isArray(f.productLine) ? f.productLine.join(',') : f.productLine;
    }

    if (f.subProductLine !== null && f.subProductLine !== undefined && f.subProductLine !== '') {
      json['urm_sub_product_line'] = Array.isArray(f.subProductLine) ? f.subProductLine.join(',') : f.subProductLine;
    }

    if (f.function !== null && f.function !== undefined && f.function !== '') {
      json['urm_function'] = Array.isArray(f.function) ? f.function.join(',') : f.function;
    }

    if (f.subFunction !== null && f.subFunction !== undefined && f.subFunction !== '') {
      json['urm_sub_function'] = Array.isArray(f.subFunction) ? f.subFunction.join(',') : f.subFunction;
    }

    if (f.site !== null && f.site !== undefined && f.site !== '') {
      json['urm_site'] = Array.isArray(f.site) ? f.site.join(',') : f.site;
    }

    if (f.documentType !== null && f.documentType !== undefined && f.documentType !== '') {
      json['urm_document_type'] = f.documentType;
    }

    return json;
  }

  loadURMMap(result: any) {
    const rt = this.form.controls.requestType.value;
    const r = JSON.parse(result);
    const keys = Object.keys(r);
    if (keys.length > 0) {
      keys.forEach(
        (k: string) => {
          let userMember = '';
          switch (k) {
            case 'urm_sme_user':
              userMember = 'smeMember';
              break;
            case 'urm_intake_user':
              if (rt === 'ADR') {
                userMember = 'ofsArchivalMember';
              } else {
                userMember = 'intakesMember';
              }
              break;
            case 'urm_admin_user':
              if (rt === 'ADR') {
                userMember = 'archivalAdminMember';
              } else {
                userMember = 'adminMember';
              }
              break;
            case 'urm_reviewer_user':
              userMember = 'primaryReviewer';
              break;
            case 'urm_approver_user':
              if (rt === 'ADR') {
                userMember = 'archivalApproverMember';
              } else {
                userMember = 'primaryApprover';
              }
              break;
            case 'urm_publisher_user':
              userMember = 'publisher';
              break;
          }

          if (userMember !== '') {
            const user = new Array();
            const u = {
              name: r[k].properties.name + ' ' + '(' + r[k].properties.userName + ')',
              userName: r[k].nodeRef
            };
            user.push(u);
            this[userMember] = user;
            this.form.controls[userMember].setValue(user);
            this.form.controls[userMember].markAsDirty();
            this.form.controls[userMember].markAsTouched();
            this.form.controls[userMember].updateValueAndValidity();
          }
        }
      );
    }
  }

  getDataList(field: string, fieldData: string, parent: string, onLoad: boolean) {

    this.setMandatoryProperties(parent);

    if (this.form.value[parent] === '') {
      if (parent === 'productCompany') {
        this.productLines = [];
        this.form.controls.productLine.setValue('');
        this.subProductLines = [];
        this.form.controls.subProductLine.setValue('');
        this.sites = [];
        this.form.controls.site.setValue('');
        this.functions = [];
        this.form.controls.function.setValue('');
        this.subFunctions = [];
        this.form.controls.subFunction.setValue('');
        this.documentTypes = [];
        this.form.controls.documentType.setValue('');
      } else if (parent === 'productLine') {
        this.subProductLines = [];
        this.form.controls.subProductLine.setValue('');
        this.sites = [];
        this.form.controls.site.setValue('');
      } else if (parent === 'function') {
        this.subFunctions = [];
        this.form.controls.subFunction.setValue('');
      } else if (parent === 'process') {
        this.subProcesses = [];
        this.form.controls.subProcess.setValue('');
      }
    } else {
      if (!onLoad) {
        this.form.controls[field].setValue('');

        if (field === 'productLine') {
          this.subProductLines = [];
          this.form.controls.subProductLine.setValue('');
          this.sites = [];
          this.form.controls.site.setValue('');
        } else if (parent === 'function') {
          this.subFunctions = [];
          this.form.controls.subFunction.setValue('');
        } else if (parent === 'process') {
          this.subProcesses = [];
          this.form.controls.subProcess.setValue('');
        }
      }

      this.dataList.getFormData(field, this.form.value).then(
        (r) => {
          const data: Options[] = [];
          if (r.Values && r.Values.length > 0) {
            r.Values.forEach((item) => {
              data.push({ id: item, name: item });
            });
          }
          this[fieldData] = data;
        }
      );
    }
  }

  setMandatoryProperties(parent: string) {
    if (this.data.requestType === 'archive') {
      this.form.controls.documentAttachment.clearValidators();
      this.form.controls.documentUrl.clearValidators();
      this.form.controls.documentAttachment.updateValueAndValidity();
      this.form.controls.documentUrl.updateValueAndValidity();

      // Assignees
      if (this.form.value[parent].includes('OFS Oilfield')) {
        this.form.controls.ofsArchivalMember.setValidators(Validators.required);
        this.form.controls.ofsArchivalMember.updateValueAndValidity();

        this.form.controls.archivalAdminMember.clearValidators();
        this.form.controls.archivalAdminMember.updateValueAndValidity();
        this.form.controls.archivalApproverMember.clearValidators();
        this.form.controls.archivalApproverMember.updateValueAndValidity();
      } else {
        this.form.controls.archivalAdminMember.setValidators(Validators.required);
        this.form.controls.archivalAdminMember.updateValueAndValidity();
        this.form.controls.archivalApproverMember.setValidators(Validators.required);
        this.form.controls.archivalApproverMember.updateValueAndValidity();

        this.form.controls.ofsArchivalMember.clearValidators();
        this.form.controls.ofsArchivalMember.updateValueAndValidity();
      }

      // Default Mandatory Assignees
      this.form.controls.adminMember.clearValidators();
      this.form.controls.adminMember.updateValueAndValidity();
      this.form.controls.primaryReviewer.clearValidators();
      this.form.controls.primaryReviewer.updateValueAndValidity();
      this.form.controls.primaryApprover.clearValidators();
      this.form.controls.primaryApprover.updateValueAndValidity();
    } else {
      if (this.form.get('contentCategory').value.includes('Document')) {
        this.form.controls.documentAttachment.setValidators(Validators.required);
        this.form.controls.documentUrl.clearValidators();
      } else if (this.form.get('contentCategory').value.includes('URL')) {
        this.form.controls.documentAttachment.clearValidators();
        this.form.controls.documentUrl.setValidators(Validators.required);
      }
      this.form.controls.documentAttachment.updateValueAndValidity();
      this.form.controls.documentUrl.updateValueAndValidity();

      // Assignees
      this.form.controls.ofsArchivalMember.clearValidators();
      this.form.controls.ofsArchivalMember.updateValueAndValidity();
      this.form.controls.archivalAdminMember.clearValidators();
      this.form.controls.archivalAdminMember.updateValueAndValidity();
      this.form.controls.archivalApproverMember.clearValidators();
      this.form.controls.archivalApproverMember.updateValueAndValidity();

      // Default Mandatory Assignees
      this.form.controls.adminMember.setValidators(this.matChipValidator);
      this.form.controls.adminMember.updateValueAndValidity();
      this.form.controls.primaryReviewer.setValidators(this.matChipValidator);
      this.form.controls.primaryReviewer.updateValueAndValidity();
      this.form.controls.primaryApprover.setValidators(this.matChipValidator);
      this.form.controls.primaryApprover.updateValueAndValidity();
    }

    if (parent === 'productCompany') {
      if (this.form.value[parent].includes('TPS Turbomachinery')) {

        if (this.data.requestType !== 'archive') {
          this.form.controls.documentAuthor.setValidators(Validators.required);
          this.form.controls.documentAuthor.updateValueAndValidity();
        } else {
          this.form.controls.documentAuthor.clearValidators();
          this.form.controls.documentAuthor.updateValueAndValidity();
        }

        if (this.data.requestType !== 'new' || this.data.rType !== 'NDR') {
          this.form.controls.adminMember.clearValidators();
          this.form.controls.adminMember.updateValueAndValidity();
        } else {
          this.form.controls.adminMember.setValidators(this.matChipValidator);
          this.form.controls.adminMember.updateValueAndValidity();
        }

        if (this.data.requestType === 'archive') {
          this.form.controls.primaryReviewer.clearValidators();
          this.form.controls.primaryReviewer.updateValueAndValidity();
        } else {
          this.form.controls.primaryReviewer.setValidators(this.matChipValidator);
          this.form.controls.primaryReviewer.updateValueAndValidity();
        }

        if (this.data.requestType === 'new' || this.data.rType === 'NDR') {
          this.form.controls.subProductLine.setValidators(Validators.required);
          this.form.controls.subProductLine.updateValueAndValidity();

          this.form.controls.site.setValidators(this.matChipValidator);
          this.form.controls.site.updateValueAndValidity();

          this.form.controls.subFunction.setValidators(Validators.required);
          this.form.controls.subFunction.updateValueAndValidity();
        } else {
          this.removeMandatoryProperties();
        }

      } else if (this.form.value[parent].includes('DS Digital')) {

        if (this.data.requestType === 'new' || this.data.rType === 'NDR') {
          this.form.controls.documentType.setValidators(Validators.required);
          this.form.controls.documentType.updateValueAndValidity();

          this.form.controls.site.setValidators(this.matChipValidator);
          this.form.controls.site.updateValueAndValidity();

          this.form.controls.documentAuthor.setValidators(Validators.required);
          this.form.controls.documentAuthor.updateValueAndValidity();

          // this.form.controls.expiryDate.setValidators(Validators.required);
          // this.form.controls.expiryDate.updateValueAndValidity();

          this.form.controls.isoElement.setValidators(Validators.required);
          this.form.controls.isoElement.updateValueAndValidity();

          this.form.controls.process.setValidators(Validators.required);
          this.form.controls.process.updateValueAndValidity();

          this.form.controls.subProcess.setValidators(Validators.required);
          this.form.controls.subProcess.updateValueAndValidity();
        } else {
          this.removeMandatoryProperties();
        }
      } else if (this.form.value[parent].includes('OFS Oilfield')) {
        if (this.data.requestType !== 'archive') {
          this.form.controls.intakesMember.setValidators(this.matChipValidator);
          this.form.controls.intakesMember.updateValueAndValidity();

          /* this.form.controls.smeMember.setValidators(this.matChipValidator);
          this.form.controls.smeMember.updateValueAndValidity(); */
        } else {
          this.form.controls.intakesMember.clearValidators();
          this.form.controls.intakesMember.updateValueAndValidity();
        }
      } else if (this.form.value[parent].includes('BH-Global')) {
        if (this.data.requestType !== 'new' && this.data.rType !== 'NDR') {
          this.removeMandatoryProperties();
        }
      } else {
        this.removeMandatoryProperties();
      }
    }
  }

  removeMandatoryProperties() {
    this.form.controls.documentType.clearValidators();
    this.form.controls.documentType.updateValueAndValidity();

    this.form.controls.subProductLine.clearValidators();
    this.form.controls.subProductLine.updateValueAndValidity();

    this.form.controls.site.clearValidators();
    this.form.controls.site.updateValueAndValidity();

    this.form.controls.subFunction.clearValidators();
    this.form.controls.subFunction.updateValueAndValidity();

    this.form.controls.documentAuthor.clearValidators();
    this.form.controls.documentAuthor.updateValueAndValidity();

    this.form.controls.expiryDate.clearValidators();
    this.form.controls.expiryDate.updateValueAndValidity();

    this.form.controls.isoElement.clearValidators();
    this.form.controls.isoElement.updateValueAndValidity();

    this.form.controls.process.clearValidators();
    this.form.controls.process.updateValueAndValidity();

    this.form.controls.subProcess.clearValidators();
    this.form.controls.subProcess.updateValueAndValidity();

    this.form.controls.intakesMember.clearValidators();
    this.form.controls.intakesMember.updateValueAndValidity();

    this.form.controls.smeMember.clearValidators();
    this.form.controls.smeMember.updateValueAndValidity();
  }

  onSelectionChange(id: string) {
    console.log('onSelectionChange event : ', id);
    if (id === 'productCompany') {
      this.getDataList('documentType', 'documentTypes', 'productCompany', false);
      this.getDataList('productLine', 'productLines', 'productCompany', false);
      this.getDataList('function', 'functions', 'productCompany', false);
    }

    if (id === 'productLine') {
      this.getDataList('subProductLine', 'subProductLines', 'productLine', false);
      this.getDataList('site', 'sites', 'productLine', false);
    }

    if (id === 'function') {
      if (!this.form.get('productCompany').value.includes('TPS Turbomachinery')) {
        this.getDataList('subFunction', 'subFunctions', 'function', false);
      }
    }

    if (id === 'contentCategory') {
      const v = this.form.value[id];
      // TO DO : URL validator
      if (v.includes('Document')) {
        this.form.controls.documentAttachment.setValidators(Validators.required);
        this.form.controls.documentUrl.clearValidators();
      } else if (v.includes('URL')) {
        this.form.controls.documentAttachment.clearValidators();
        this.form.controls.documentUrl.setValidators(Validators.required);
      }
      this.form.controls.documentAttachment.updateValueAndValidity();
      this.form.controls.documentUrl.updateValueAndValidity();
    }

    if (id === 'process') {
      this.getDataList('subProcess', 'subProcesses', 'process', false);
    }
  }

  onDocumentChange(event: any) {
    const rt = this.data.requestType;
    if (rt === 'new') {
      console.log('document change event : ', event);
      const a = this.checkFilledAssignees();
      if (a) {
        /* const dialogRef = this.dialog.open(ConfirmDialogComponent, {
          data: {
            title: 'Confirm',
            message: 'Do you want to "Refresh" the the "Assignees"?'
          },
          minWidth: '250px'
        });

        dialogRef.afterClosed().subscribe((result) => {
          if (result === true) {
            this.loadURM();
          }
        }); */
      } else {
        this.loadURM();
      }
    }
  }

  checkFilledAssignees(): boolean {
    const f = this.form.value;
    const p = f.productCompany.includes('OFS Oilfield');

    if (p) {
      if (f.intakesMember.length > 0) {
        return true;
      }
      if (f.smeMember.length > 0) {
        return true;
      }
    }

    if (f.adminMember.length > 0) {
      return true;
    }
    if (f.primaryReviewer.length > 0) {
      return true;
    }
    if (f.additionalReviewer.length > 0) {
      return true;
    }
    if (f.primaryApprover.length > 0) {
      return true;
    }
    if (f.additionalApprover.length > 0) {
      return true;
    }
    if (f.publisher.length > 0) {
      return true;
    }

    return false;
  }

  submitForm() {
    const email = this.user.email;
    if (email === undefined || email === null || email === '') {
      this.openInfoDialog(
        'Info',
        true,
        'Email id not available in the system,' +
        ' Please contact Administrator');
    } else if (this.form.invalid || this.form.pending) {
      this.openInfoDialog(null, false, 'Fill the form with all mandatory(*) values to start');
    } else {
      const rt = this.data.requestType;
      const rType = this.data.rType;
      if (rt === 'new') {
        this.startWorkflow('NDR-NEW');
      } else if ((rt === 'submitter' || rt === 'RDR') && rType === 'NDR') {
        this.startWorkflow('NDR');
      } else if ((rt === 'submitter' || rt === 'RDR') && rType === 'RDR') {
        this.startWorkflow('RDR');
      } else if (rt === 'revision') {
        this.startWorkflow('RDR-NEW');
      } else if (rt === 'archive') {
        this.startWorkflow('ADR');
      }
    }
  }

  startWorkflow(rt: string) {
    this.submitLoading = true;
    const self = this;
    const f = this.form.value;

    // Document upload api call
    this.webScript.post(this.getStartWorkflowOptions(rt)).then(
      (response) => {
        console.log('Message : ', response);
        if (rt === 'NDR-NEW') {
          this.submitLoading = false;
          this.dialogRef.close(this.form.value);
          this.openInfoDialog(
            null,
            false,
            'New "QMS Document Request" Submitted successfully... '
            + 'Mail notification has been triggered to respective assignees.');
        } else if (rt === 'RDR-NEW') {
          this.submitLoading = false;
          this.dialogRef.close(this.form.value);
          this.openInfoDialog(
            null,
            false,
            'Revision Request Submitted successfully... '
            + 'Mail notification has been triggered to respective assignees.');
        } else if (rt === 'ADR') {
          this.submitLoading = false;
          this.dialogRef.close(this.form.value);
          this.openInfoDialog(
            null,
            false,
            '"Archival Document" request submitted successfully... ');
        } else {
          // Checking Task Id and update workflow/task
          if (this.taskId !== undefined && this.taskId !== '' && this.taskId !== null) {
            const a = f.workflowActions;
            if ( a !== '' && a !== undefined && a !== null ) {
              this.updateTask(a, rt);
            } else {
              this.openInfoDialog('Error', true, 'Workflow Action not available , Please check');
            }
          } else {
            this.openInfoDialog('Error', true, 'Task Id is not available, Please check once');
          }
        }
      },
      (error) => {
        this.submitLoading = false;
        console.log('Error : ', error);
        this.openInfoDialog('Error', true, error.message);
      }
    );
  }

  updateTask(a: string, rt: string) {
    const p = this.getUpdateTaskFormParams(a);
    const options: RequestOptions = {
      path: '/service/api/bh-task-instances/activiti$' + this.taskId,
      formParams: p,
      bodyParam: p
    };

    this.webScript.put(options).then(
      (r) => {
        console.log('Response : ', r);
        this.endTask(a, rt);
      },
      (e) => {
        this.submitLoading = false;
        console.log('Error : ', e);
        this.openInfoDialog('Error', true, e.briefSummary);
      }
    );
  }

  getUpdateTaskFormParams(a) {
    const f = this.form.value;
    const properties = new Object();
    properties['bpm_comment'] = this.form.value.reasonForRevision;
    properties['bhwf_submitterOutcome'] = a;
    properties['isMailNotifyRequired'] = true;

    if (a === 'Submit') {
    } else if (a === 'End Workflow') {}

    if (f.intakesMember && f.intakesMember.length > 0) {
      properties['bhwf_intakes'] = f.intakesMember[0].userName;
    }
    if (f.smeMember && f.smeMember.length > 0) {
      properties['bhwf_sme'] = f.smeMember[0].userName;
    }
    if (f.adminMember && f.adminMember.length > 0) {
      properties['bhwf_admin'] = f.adminMember[0].userName;
    }
    if (f.primaryReviewer.length > 0) {
      properties['bhwf_primaryReviewer'] = f.primaryReviewer[0].userName;
    }
    if (f.additionalReviewer.length > 0) {
      const reviewers = new Array();
      f.additionalReviewer.forEach(u => {
        reviewers.push(u.userName);
      });
      properties['bhwf_reviewer'] = reviewers;
    }
    if (f.primaryApprover.length > 0) {
      properties['bhwf_primaryApprover'] = f.primaryApprover[0].userName;
    }
    if (f.additionalApprover.length > 0) {
      const approvers = new Array();
      f.additionalApprover.forEach(u => {
        approvers.push(u.userName);
      });
      properties['bhwf_approver'] = approvers;
    }
    if (f.publisher.length > 0) {
      properties['bhwf_publisher'] = f.publisher[0].userName;
    }

    return properties;
  }

  endTask(a: string, rt: string) {
    this.webScript.put(this.getTaskRequestOptions(a, rt)).then(
      (r) => {
        this.submitLoading = false;
        console.log('Response : ', r);
        this.dialogRef.close(true);
        this.openInfoDialog('Response', true, 'Submitter request "' + a + '" submitted successfully');
      },
      (e) => {
        this.submitLoading = false;
        console.log('Error : ', e);
        this.openInfoDialog('Error', true, e.briefSummary);
      }
    );
  }

  getTaskRequestOptions(a: string, rt: string): RequestOptions {
    const p = this.getTaskFormParams(a, rt);
    return {
      path: '/service/bh/public/workflow/versions/1/tasks/' + this.taskId + '?' + this.getTaskQueryParams(a, rt),
      formParams: p,
      bodyParam: p
    };
  }

  getTaskQueryParams(a: string, rt: string) {
    if ( a === 'Re-assign' ) {
      return 'select=owner,assignee';
    } else if (a === 'Submit') {
      return 'select=state';
    } else if (a === 'End Workflow') {
      return 'select=state';
    }
  }

  getTaskFormParams(a: string, rt: string) {
    // Until then user mapping, assignee/sme : bhdev1
    const data = new Object();
    data['state'] = 'completed';
    if ( a === 'Re-assign' ) {
      return {
        owner : 'bhdev1',
        assignee : 'bhdev1'
      };
    }
    return data;
  }

  getStartWorkflowOptions(rt: string): RequestOptions {
    const options: RequestOptions = <RequestOptions>{
      path: '/service/startworkflow',
      headerParams: new Headers({ 'encrypt': 'multipart/form-data' }),
      formParams: this.getFormParams(rt),
      contentTypes: ['multipart/form-data'],
      accepts: ['application/json', 'text/html']
    };
    return options;
  }

  getFormParams(rt: string): FormParams {
    const f = this.form.value;
    const formParams: FormParams = <FormParams>{
      category: f.contentCategory.toLowerCase(),
      requestType: rt,
      user: JSON.stringify(this.user)
    };

    if (rt === 'NDR' || rt === 'RDR-NEW' || rt === 'RDR' || rt === 'ADR') {
      formParams.nodeRef = 'workspace://SpacesStore/' + this.nodeId;
    }

    if (f.contentCategory.includes('Document')) {
      if (f.documentAttachment && f.documentAttachment.files && f.documentAttachment.files.length > 0) {
        formParams.document = f.documentAttachment.files[0];
      }
    } else if (f.contentCategory.includes('URL')) {
      formParams.url = f.documentUrl;
    }
    formParams.documentProperties = JSON.stringify(this.getBhProperties());
    if (rt === 'NDR-NEW' || rt === 'RDR-NEW' || rt === 'ADR') {
      formParams.workflowProperties = JSON.stringify(this.getBhWorkflowProperties());
      formParams.assignees = JSON.stringify(this.getBhAssignees());
    }

    return formParams;
  }

  getBhProperties() {
    const f = this.form.value;
    // To DO:
    // 'cm:name': f.documentName
    // 'bhqms:user_role': f.userRole
    // bhqms:document_submitter
    // bhqms:document_author
    // bhqms:document_admin
    // bhqms:functional_owner
    const data = new Object();
    if (this.data.requestType === 'new') {
      if (this.form.controls.documentName.dirty) {
        data['cm:name'] = f.documentName;
        data['cm:title'] = f.documentName;
        data['cm:description'] = f.documentName;
      }
      if (this.form.controls.documentType.dirty &&
        (f.documentType !== null && f.documentType !== undefined && f.documentType !== '')) {
        data['bhqms:document_type'] = f.documentType;
      }
      if (this.form.controls.documentReferenceNumber.dirty &&
        (f.documentReferenceNumber !== null && f.documentReferenceNumber !== undefined && f.documentReferenceNumber !== '')) {
        data['bhqms:reference'] = f.documentReferenceNumber.toUpperCase();
      }
      if (this.form.controls.productCompany.dirty) {
        data['bhqms:product_company'] = f.productCompany;
      }
      if (this.form.controls.productLine.dirty) {
        data['bhqms:product_line'] = f.productLine;
        // data['bhqms:product_line'] = Array.isArray(f.productLine) ? f.productLine.join() : f.productLine;
      }
      if (this.form.controls.subProductLine.dirty &&
        (f.subProductLine !== null && f.subProductLine !== undefined && f.subProductLine !== '')) {
        data['bhqms:sub_product_line'] = f.subProductLine;
      }
      if (this.form.controls.site.dirty && (f.site !== null && f.site !== undefined && f.site !== '')) {
        data['bhqms:site'] = f.site;
        // data['bhqms:site'] = Array.isArray(f.site) ? f.site.join() : f.site;
      }
      if (this.form.controls.function.dirty) {
        data['bhqms:function'] = f.function;
        // data['bhqms:function'] = Array.isArray(f.function) ? f.function.join() : f.function;
      }
      if (this.form.controls.subFunction.dirty && (f.subFunction !== null && f.subFunction !== undefined && f.subFunction !== '')) {
        data['bhqms:sub_function'] = f.subFunction;
      }
      if (this.form.controls.language.dirty && (f.language !== null && f.language !== undefined && f.language !== '')) {
        data['bhqms:language_code'] = f.language;
      }
      if (this.form.controls.contentCategory.dirty &&
        (f.contentCategory !== null && f.contentCategory !== undefined && f.contentCategory !== '')) {
        data['bhqms:content_category'] = f.contentCategory;
      }
      if (this.form.controls.isoElement.dirty && (f.isoElement !== null && f.isoElement !== undefined && f.isoElement !== '')) {
        data['bhqms:iso_element'] = f.isoElement;
        // data['bhqms:iso_element'] = Array.isArray(f.isoElement) ? f.isoElement.join() : f.isoElement;
      }
      if (this.form.controls.process.dirty && (f.process !== null && f.process !== undefined && f.process !== '')) {
        data['bhqms:process'] = f.process;
        // data['bhqms:process'] = Array.isArray(f.process) ? f.process.join() : f.process;
      }
      if (this.form.controls.subProcess.dirty && (f.subProcess !== null && f.subProcess !== undefined && f.subProcess !== '')) {
        data['bhqms:sub_process'] = f.subProcess;
        // data['bhqms:sub_process'] = Array.isArray(f.subProcess) ? f.subProcess.join() : f.subProcess;
      }
      if (this.form.controls.userRole.dirty && (f.userRole !== null && f.userRole !== undefined && f.userRole !== '')) {
        data['bhqms:user_role'] = f.userRole;
        // data['bhqms:user_role'] = Array.isArray(f.userRole) ? f.userRole.join() : f.userRole;
      }
      if (this.form.controls.effectiveDate.dirty && (f.effectiveDate !== null && f.effectiveDate !== undefined && f.effectiveDate !== '')) {
        const d: Date = f.effectiveDate;
        data['bhqms:effective_date'] = d.valueOf().toString();
      }
      if (this.form.controls.expiryDate.dirty && (f.expiryDate !== null && f.expiryDate !== undefined && f.expiryDate !== '')) {
        const d: Date = f.expiryDate;
        data['bhqms:expiry_date'] = d.valueOf().toString();
      }
    }

    if (this.data.requestType !== 'archive') {
      if (this.form.controls.documentUrl.dirty &&
        (f.documentUrl !== null && f.documentUrl !== undefined && f.documentUrl !== '')) {
        data['bhqms:document_url'] = f.documentUrl;
      }
    }

    if (this.form.controls.reasonForRevision.dirty &&
      (f.reasonForRevision !== null && f.reasonForRevision !== undefined && f.reasonForRevision !== '')) {
      data['bhqms:reason_for_revision'] = f.reasonForRevision;
    }

    if (f.documentAuthor.length > 0) {
      data['bhqms:document_author'] = f.documentAuthor[0].userName;
    }

    if (f.adminMember.length > 0) {
      data['bhqms:document_admin'] = f.adminMember[0].userName;
    }

    return data;
  }

  getBhWorkflowProperties() {
    const f = this.form.value;
    const data = {
      'bpm:workflowDescription': f.reasonForRevision,
      'bpm:workflowPriority': f.priority,
      'bhwf:bh_revision_type': null,
      'bhwf_bh_revision_type': null,
      'bhwf:bh_publish_revision': null,
      'bhwf_bh_publish_revision': null
    };

    if (f.requestType === 'RDR') {
      data['bhwf:bh_revision_type'] = f.newRevisionNumber;
      data['bhwf_bh_revision_type'] = f.newRevisionNumber;
      let drn = f.documentRevisionNumber;
      if (drn === undefined || drn === null || drn === 'null' || drn === '' ) {
        drn = 'None';
      }
      // data['bhwf:bh_publish_revision'] = drn;
      // data['bhwf_bh_publish_revision'] = drn;
    }
    return data;
  }

  getBhAssignees() {
    const f = this.form.value;
    const data = new Object();

    if (this.data.requestType !== 'archive') {
      if (f.intakesMember.length > 0) {
        data['bhwf:intakes'] = f.intakesMember[0].userName;
      }
      if (f.smeMember.length > 0) {
        data['bhwf:sme'] = f.smeMember[0].userName;
      }
      if (f.adminMember.length > 0) {
        data['bhwf:admin'] = f.adminMember[0].userName;
        // data['bhwf:admin'] = 'workspace://SpacesStore/d582d1e2-9712-49ff-bef2-c9c2395f5a77';
      }
      if (f.primaryReviewer.length > 0) {
        data['bhwf:primaryReviewer'] = f.primaryReviewer[0].userName;
      }
      if (f.additionalReviewer.length > 0) {
        const reviewers = new Array();
        f.additionalReviewer.forEach(u => {
          reviewers.push(u.userName);
        });
        data['bhwf:reviewer'] = reviewers.join(',');
      }
      if (f.primaryApprover.length > 0) {
        data['bhwf:primaryApprover'] = f.primaryApprover[0].userName;
      }
      if (f.additionalApprover.length > 0) {
        const approvers = new Array();
        f.additionalApprover.forEach(u => {
          approvers.push(u.userName);
        });
        data['bhwf:approver'] = approvers.join(',');
      }
      if (f.publisher.length > 0) {
        data['bhwf:publisher'] = f.publisher[0].userName;
        // data['bhwf:publisher'] = 'workspace://SpacesStore/d582d1e2-9712-49ff-bef2-c9c2395f5a77';
      } else {
        // for DS, the Admin Member name as default to the Publisher
        if (this.form.value.productCompany.includes('DS Digital') && f.adminMember.length > 0) {
          data['bhwf:publisher'] = f.adminMember[0].userName;
        }
      }
    } else {
      // Assignees for archival workflow
      if (f.productCompany.includes('OFS Oilfield')) {
        if (f.ofsArchivalMember.length > 0) {
          data['bhwf:archival'] = f.ofsArchivalMember[0].userName;
          // data['bhwf:admin'] = 'workspace://SpacesStore/d582d1e2-9712-49ff-bef2-c9c2395f5a77';
        }
      } else {
        if (f.archivalAdminMember.length > 0) {
          data['bhwf:admin'] = f.archivalAdminMember[0].userName;
          // data['bhwf:admin'] = 'workspace://SpacesStore/d582d1e2-9712-49ff-bef2-c9c2395f5a77';
        }

        if (f.archivalApproverMember.length > 0) {
          data['bhwf:archivalApprover'] = f.archivalApproverMember[0].userName;
          // data['bhwf:admin'] = 'workspace://SpacesStore/d582d1e2-9712-49ff-bef2-c9c2395f5a77';
        }
      }
    }

    return data;

    // TO DO
    // bhwf:additional_reviewer --> f.additionalReviewer
    // bhwf:additional_approver  --> f.additionalApprover
    /* return {
      'bhwf:intakes' : f.intakesMember[0].userName,
      'bhwf:admin' : f.adminMember[0].userName,
      'bhwf:reviewer': f.primaryReviewer[0].userName,
      'bhwf:approver': f.primaryApprover[0].userName,
      'bhwf:publisher': f.publisher[0].userName,
    }; */
    /* return {
      'bhwf:intakes': 'admin',
      'bhwf:sme': 'admin',
      'bhwf:admin': 'admin',
      'bhwf:reviewer': 'admin,wfadmin1,wfadmin2',
      'bhwf:approver': 'admin,wfadmin1,wfadmin2',
      'bhwf:publisher': 'admin',
    }; */
  }

  openUserSelectionDialog(event: any, m: boolean, t: string) {

    const users = new Array();
    let savedUsers = [];
    if (this[event.target.id] !== '') {
      savedUsers = users.concat(this[event.target.id]);
    }

    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '30%';
    dialogConfig.minWidth = '300px';

    dialogConfig.data = { multiple: m, savedUsers: savedUsers, type: t};

    const dialogRef = this.dialog.open(SelectUserDialogComponent,
      dialogConfig);


    dialogRef.afterClosed().subscribe(
      (val) => {
        console.log('Value from user select dialog : ', val);
        if (val !== undefined) {
          this[event.target.id] = val;
          this.form.controls[event.target.id].setValue(val);
        }
      }
    );

  }

  close() {
    if (this.form.dirty) {
      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        data: {
          title: 'Confirm',
          message: `Are you sure you want to discard the changes?`
        },
        minWidth: '250px'
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result === true) {
          this.dialogRef.close();
        }
      });
    } else {
      this.dialogRef.close();
    }

  }

  onResize(event) {
    const s = event.target.innerHTML;
    if (s === 'fullscreen') {
      this.params.maximize(event);
      this.resizeValue = 'fullscreen_exit';
      this.resizeTooltip = 'Minimize';
    } else {
      this.params.resize(event);
      this.resizeValue = 'fullscreen';
      this.resizeTooltip = 'Maximize';
    }
  }

  remove(id, user) {
    console.log('user remove : ', user);
    const c = this.form.controls[id];
    const index = this[id].indexOf(user, 0);

    if (index !== -1) {
      this[id].splice(index, 1);
    }

    if (this[id].length === 0) {
      c.markAsTouched();
    }

    c.updateValueAndValidity();
    c.markAsDirty();
  }

  onPreview() {
    this.showViewer = true;
  }

  onViewerToggle(event) {
    // this.nodeId = null;
    this.showViewer = event;
  }

  // Document reference Number validation
  onReferenceNumberChange(e: any) {
    const self = this.form.controls.documentReferenceNumber;
    const v = self.value;
    const n = this.nodeId;
    self.markAsPending();
    console.log('Reference Number Change event : ', e.target.value);
    if (v !== '' && v !== undefined && v !== null) {
      const queryParams = {
        'reference': v,
        'nodeRef': n
      };
      const options: RequestOptions = {
        path: '/service/referenceNumberValidation',
        queryParams: queryParams
      };
      this.webScript.get(options).then(
        (r) => {
          if (r) {
            if (r['isDuplicate']) {
              self.setErrors({ isDuplicate : true });
            } else {
              self.setErrors({ isDuplicate : false });
            }
          } else {
            self.setErrors({ isDuplicate : false });
          }
          self.updateValueAndValidity();
        },
        (c) => {
          self.setErrors({ isDuplicate : false });
          self.updateValueAndValidity();
        }
      );
    } else {
      self.setErrors({ isDuplicate : false, required : true });
      self.updateValueAndValidity();
    }
  }

  referenceValidator(c: FormControl) {
    if ((c.value !== undefined && c.value !== null) && c.value.length > 0) {
      if (c.hasError('isDuplicate')) {
        return c.getError('isDuplicate') ? { isDuplicate : true } : null;
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  documentReferenceNumberValidation(field: any): Promise<ValidationErrors | null> | Observable<ValidationErrors | null> {
    console.log('documentReferenceNumberValidation local : ', field);
    if (field.form !== undefined && field.form !== null ) {
      const v = field.form.controls.documentReferenceNumber.value;
      const n = field.nodeId;
      if (v !== '' && v !== undefined && v !== null) {
        let q = 'TYPE:\'bhqms:iso_qty_manual\' AND ISNOTNULL:\'bhqms:reference\' AND bhqms:reference:\'' + v + '\'';
        if (n !== '' && n !== undefined && n !== null) {
          q += ' AND NOT ID:\'' + 'workspace://SpacesStore/' + n + '\'';
        }
        const queryBody: QueryBody = {
          query: new RequestQuery({
            language: 'afts',
            query: q
          }),
          scope: new RequestScope({
            locations: ['nodes', 'deleted-nodes']
          })
        };
        return (v === '') ? of(null) : field.bhApi.searchByQueryBody(queryBody).toPromise().then(
          r => {
            return (r && r.list && r.list.entries && r.list.entries.length > 0) ? { isDuplicate : true } : null;
          }
        );
      } else {
        return of(null);
      }
    } else {
      return of(null);
    }
  }

  fieldValidation(field: string): string {
    // console.log(field);
    if (this.form.get(field).hasError('required')) {
      // console.log('Error : ', this.validationMessages[field].required);
      return this.validationMessages[field].required;
    } else if (this.form.get(field).hasError('minlength')) {
      return this.validationMessages[field].minLength;
    } else if (this.form.get(field).hasError('isDuplicate')) {
      return this.validationMessages[field].isDuplicate;
    }
    return null;
  }

  openInfoDialog(title, hasTitle, message) {
    const dialogRef = this.dialog.open(BhInfoDialogComponent, {
      width: '400px',
      minWidth: '250px',
      disableClose: true,
      data: { title: title, hasTitle: hasTitle, message: message }
    });

    dialogRef.afterClosed().subscribe(result => {
      // To Do filed focus
    });
  }

  matChipValidator(c: FormControl) {
    if (c.value.length === 0) {
      return { required: true };
    } else {
      return null;
    }

  }

}
