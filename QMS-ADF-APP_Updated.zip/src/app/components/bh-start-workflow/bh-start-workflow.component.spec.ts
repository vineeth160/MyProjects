import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhStartWorkflowComponent } from './bh-start-workflow.component';

import { BhWebscriptService } from '../../services/bh-webscript.service';

describe('BhStartWorkflowComponent', () => {
  let component: BhStartWorkflowComponent;
  let fixture: ComponentFixture<BhStartWorkflowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhStartWorkflowComponent ],
      providers: [BhWebscriptService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhStartWorkflowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
