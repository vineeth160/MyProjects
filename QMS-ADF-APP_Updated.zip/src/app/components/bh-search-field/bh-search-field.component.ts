import { Component, OnInit, EventEmitter, Output, Input, ViewChild } from '@angular/core';
import { MatSelect, MatInput, MatOption } from '@angular/material';

export interface EventOutput  {
  selection?: MatSelect;
  action: string;
}

@Component({
  selector: 'app-bh-search-field',
  templateUrl: './bh-search-field.component.html',
  styleUrls: ['./bh-search-field.component.scss']
})
export class BhSearchFieldComponent implements OnInit {

  @ViewChild('selectInput')
  selectInput: MatInput;

  @ViewChild('selectDropdown')
  selectDropdown: MatSelect;

  @Input()
  inputType: string;

  @Input()
  isMultiple: boolean;

  @Input()
  name: string;

  @Input()
  fieldControl: string;

  @Input()
  fieldValue: any;

  @Input()
  fieldData: any[];

  @Input()
  fieldType: string;

  @Output()
  selectAction: EventEmitter<EventOutput> = new EventEmitter();

  @Output()
  selectChange: EventEmitter<any> = new EventEmitter();

  constructor() { }

  ngOnInit() {
    // console.log(this);
  }

  onSelectAction(s: MatSelect, a: string) {
    const event: EventOutput = {
      selection: s,
      action: a
    };
    this.selectAction.emit(event);
  }

  onSelectionChange(event: any) {
    this.selectChange.emit(event);
  }

  onClearInput() {
    if (this.selectInput !== undefined) {
      this.selectInput.value = '';
    }
  }

  onClearSelect() {
    if ( this.selectDropdown !== undefined ) {
      if (this.selectDropdown.multiple && this.selectDropdown.options && this.selectDropdown.options.length > 0 ) {
        this.selectDropdown.options.forEach( (item: MatOption) => item.deselect());
      } else {
        this.selectDropdown.writeValue('');
      }
    }
  }

  inputUpdate(i: MatInput) {
    if (this.fieldType !== undefined && this.fieldType !== null && this.fieldType !== '') {
      switch (this.fieldType) {
        case 'upper':
          i.value = i.value.toLocaleUpperCase();
          break;
        case 'lower':
          i.value = i.value.toLocaleLowerCase();
          break;
        default:
          i.value = i.value;
          break;
      }
    }
  }

  getTitleData(fieldValue: any) {
    return fieldValue ? (Array.isArray(fieldValue) ? fieldValue.join(', ') : fieldValue ) : '';
  }

}
