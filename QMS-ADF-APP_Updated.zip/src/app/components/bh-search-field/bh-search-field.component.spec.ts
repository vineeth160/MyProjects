import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhSearchFieldComponent } from './bh-search-field.component';

describe('BhSearchFieldComponent', () => {
  let component: BhSearchFieldComponent;
  let fixture: ComponentFixture<BhSearchFieldComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhSearchFieldComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhSearchFieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
