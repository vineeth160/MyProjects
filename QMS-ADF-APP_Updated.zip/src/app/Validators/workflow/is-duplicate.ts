import { Injectable } from '@angular/core';
import { AsyncValidator, AbstractControl, ValidationErrors } from '@angular/forms';
import { Observable } from 'rxjs';
import { SearchService } from '@alfresco/adf-core';
import { QueryBody, RequestQuery, RequestScope } from '@alfresco/js-api';


@Injectable({ providedIn: 'root' })
export class IsDuplicate implements AsyncValidator {

  constructor(private search: SearchService) {}

  validate(
    control: AbstractControl
  ): Promise<ValidationErrors | null> | Observable<ValidationErrors | null> {
    const queryBody: QueryBody = {
      query: new RequestQuery({
        language: 'afts',
        query: 'TYPE:\'bhqms:iso_qty_manual\' AND ISNOTNULL:\'bhqms:reference\' AND bhqms:reference:' + control.value
      }),
      scope: new RequestScope({
        locations: ['nodes', 'deleted-nodes']
      })
    };
    return this.search.searchByQueryBody(queryBody).toPromise().then(
      r => {
        return (r && r.list && r.list.entries && r.list.entries.length > 0) ? { isDuplicate : true } : null;
      }
    );
  }

}
