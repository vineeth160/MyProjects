import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-bh-document-link',
  templateUrl: './bh-document-link.component.html',
  styleUrls: ['./bh-document-link.component.scss']
})
export class BhDocumentLinkComponent implements OnInit {

  link = '';
  linkType = '';
  title = '';
  node: any;

  copyText = 'Copy';

  constructor(
    public dialogRef: MatDialogRef<BhDocumentLinkComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    if (this.data) {
      this.node = this.data.node;
      const t = this.data.type;
      if (t === 'link') {
        this.title = 'Document Link';
        this.linkType = 'Document Link';
        this.link = this.buildLink();
      } else if (t === 'url') {
        this.title = 'Content Category "URL"';
        this.linkType = 'Document URL';
        if (this.node && this.node.properties) {
          const link: string = this.node.properties['bhqms:document_url'];
          if (link.startsWith('http') || link.startsWith('https')) {
            this.link = link;
          } else {
            this.link = 'http://' + link;
          }
        }
      }
      console.log('Link/URL : ', this.link);
    }
  }

  buildLink(): string {
    let link = '';
    link += window.location.protocol;
    link += '//';
    link += window.location.host;
    link += '/qms-document-library';
    link += '/#/advanced-search?id=';
    let id = '';
    if (this.data && this.data.node) {
      id = this.data.node.id;
      if (this.data.node.properties) {
        let sid = this.data.node.properties['smf:actualNodeRef'];
        if (sid !== undefined && sid !== null && sid !== '') {
          sid = sid.replace('workspace://SpacesStore/', '');
          id = sid;
        }
      }
    }
    link += id;
    return link;
  }

  open() {
    window.open(this.link, '_blank');
  }

  notify(event: string): void {
    this.copyText = 'Copied';
    setTimeout(() => {
      this.copyText = 'Copy';
    }, 5000);
  }

  onClose() {
    this.dialogRef.close();
  }

}
