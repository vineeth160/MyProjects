import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  selector: 'app-bh-info-dialog',
  templateUrl: './bh-info-dialog.component.html',
  styleUrls: ['./bh-info-dialog.component.scss']
})
export class BhInfoDialogComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<BhInfoDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
  }

  onOk() {
    this.dialogRef.close();
  }

}
