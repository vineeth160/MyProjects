import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BhInfoDialogComponent } from './bh-info-dialog.component';

describe('BhInfoDialogComponent', () => {
  let component: BhInfoDialogComponent;
  let fixture: ComponentFixture<BhInfoDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BhInfoDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BhInfoDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
