import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CoreModule, TRANSLATION_PROVIDER, TranslateLoaderService } from '@alfresco/adf-core';
import { ContentModule } from '@alfresco/adf-content-services';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';


import { appRoutes } from './app.routes';
import { PreviewService } from './services/preview.service';
import { FileViewComponent } from './components/file-view/file-view.component';

// App components
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { DocumentlistComponent } from './components/documentlist/documentlist.component';
import { BhFolderViewComponent } from './components/bh-folder-view/bh-folder-view.component';
import { AppLayoutComponent } from './app-layout/app-layout.component';

import { MaterialFileInputModule } from 'ngx-material-file-input';

// Localization
import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import localeDe from '@angular/common/locales/de';
import localeIt from '@angular/common/locales/it';
import localeEs from '@angular/common/locales/es';
import localeJa from '@angular/common/locales/ja';
import localeNl from '@angular/common/locales/nl';
import localePt from '@angular/common/locales/pt';
import localeNb from '@angular/common/locales/nb';
import localeRu from '@angular/common/locales/ru';
import localeCh from '@angular/common/locales/zh';
import localeAr from '@angular/common/locales/ar';
import localeCs from '@angular/common/locales/cs';
import localePl from '@angular/common/locales/pl';
import localeFi from '@angular/common/locales/fi';
import localeDa from '@angular/common/locales/da';
import localeSv from '@angular/common/locales/sv';
import { BhBasicSearchComponent } from './components/bh-basic-search/bh-basic-search.component';
import { BhUserInfoComponent } from './components/bh-user-info/bh-user-info.component';
import { BhStartWorkflowComponent } from './components/bh-start-workflow/bh-start-workflow.component';
import { SelectUserDialogComponent } from './components/select-user-dialog/select-user-dialog.component';
import { BhTreeComponent } from './components/bh-tree/bh-tree.component';
import { BhTasksComponent } from './components/bh-tasks/bh-tasks.component';
import { BhDocumentPropertiesComponent } from './components/bh-document-properties/bh-document-properties.component';
import { WfAdminTaskComponent } from './components/workflow/wf-admin-task/wf-admin-task.component';
import { WfIntakesTaskComponent } from './components/workflow/wf-intakes-task/wf-intakes-task.component';
import { WfReviewerTaskComponent } from './components/workflow/wf-reviewer-task/wf-reviewer-task.component';
import { WfApproverTaskComponent } from './components/workflow/wf-approver-task/wf-approver-task.component';
import { WfPublisherTaskComponent } from './components/workflow/wf-publisher-task/wf-publisher-task.component';

import { BhApiService } from './services/bh-api.service';
import { BhWebscriptService } from './services/bh-webscript.service';
import { BhDataListService } from './services/bh-data-list.service';
import { BhSearchService } from './services/bh-search.service';
import { BhWorkflowService } from './services/bh-workflow.service';
import { BhMyTasksComponent } from './components/bh-my-tasks/bh-my-tasks.component';
import { BhInfoDialogComponent } from './dialog/bh-info-dialog/bh-info-dialog.component';
import { BhIsDuplicateDirective } from './directives/bh-is-duplicate.directive';
import { BhTaskFormComponent } from './components/bh-tasks/bh-task-form/bh-task-form.component';
import { IntakesTaskFormComponent } from './components/bh-tasks/intakes-task-form/intakes-task-form.component';
import { BhMyWorkflowsComponent } from './components/bh-tasks/bh-my-workflows/bh-my-workflows.component';
import { WfSmeTaskComponent } from './components/workflow/wf-sme-task/wf-sme-task.component';
import { BhDocumentViewComponent } from './components/bh-document-view/bh-document-view.component';
import { BhWorkflowHistoryComponent } from './components/bh-tasks/bh-workflow-history/bh-workflow-history.component';
import { ErrorComponent } from './error/error.component';
import { WfAdrAdminTaskComponent } from './components/workflow/wf-adr-admin-task/wf-adr-admin-task.component';
import { WfAdrApproverTaskComponent } from './components/workflow/wf-adr-approver-task/wf-adr-approver-task.component';
import { WfAdrIntakesTaskComponent } from './components/workflow/wf-adr-intakes-task/wf-adr-intakes-task.component';
import { BhDocumentLinkComponent } from './dialog/bh-document-link/bh-document-link.component';

import { CopyClipboardModule } from './directives/copy-clipboard.module';
import { MaterialModule } from './components/extended/material.module';
import { BhTreeViewComponent } from './components/extended/bh-tree-view/bh-tree-view.component';

import { DocumentListModule } from './components/extended/document-list.module';

import { BhAdfViewerComponent } from './components/extended/bh-adf-viewer/bh-adf-viewer.component';
import { A11yModule } from '@angular/cdk/a11y';
import { ExtensionsModule } from '@alfresco/adf-extensions';
import { FlexLayoutModule } from '@angular/flex-layout';

import { BhNodeDownloadDirective } from './components/extended/directives/bh-node-download.directive';
import { BhUserGuideComponent } from './components/bh-user-guide/bh-user-guide.component';
import { BhSearchFieldComponent } from './components/bh-search-field/bh-search-field.component';
import { LogoutComponent } from './logout/logout.component';

registerLocaleData(localeFr);
registerLocaleData(localeDe);
registerLocaleData(localeIt);
registerLocaleData(localeEs);
registerLocaleData(localeJa);
registerLocaleData(localeNl);
registerLocaleData(localePt);
registerLocaleData(localeNb);
registerLocaleData(localeRu);
registerLocaleData(localeCh);
registerLocaleData(localeAr);
registerLocaleData(localeCs);
registerLocaleData(localePl);
registerLocaleData(localeFi);
registerLocaleData(localeDa);
registerLocaleData(localeSv);

@NgModule({
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        RouterModule.forRoot(
            appRoutes, {
              useHash: true,
              enableTracing: false // enable for debug only
            } // ,
            // { enableTracing: true } // <-- debugging purposes only
        ),

        // ADF modules
        CoreModule.forRoot(),
        ContentModule.forRoot(),
        TranslateModule.forRoot({
            loader: { provide: TranslateLoader, useClass: TranslateLoaderService }
        }),
        MaterialFileInputModule,
        CopyClipboardModule,
        MaterialModule,
        DocumentListModule,
        ExtensionsModule,
        A11yModule,
        FlexLayoutModule
    ],
    declarations: [
        AppComponent,
        HomeComponent,
        LoginComponent,
        DocumentlistComponent,
        BhFolderViewComponent,
        AppLayoutComponent,
        FileViewComponent,
        BhBasicSearchComponent,
        BhUserInfoComponent,
        BhStartWorkflowComponent,
        SelectUserDialogComponent,
        BhTreeComponent,
        BhTasksComponent,
        BhDocumentPropertiesComponent,
        WfAdminTaskComponent,
        WfIntakesTaskComponent,
        WfReviewerTaskComponent,
        WfApproverTaskComponent,
        WfPublisherTaskComponent,
        BhMyTasksComponent,
        BhInfoDialogComponent,
        BhIsDuplicateDirective,
        BhTaskFormComponent,
        IntakesTaskFormComponent,
        BhMyWorkflowsComponent,
        WfSmeTaskComponent,
        BhDocumentViewComponent,
        BhWorkflowHistoryComponent,
        ErrorComponent,
        WfAdrAdminTaskComponent,
        WfAdrApproverTaskComponent,
        WfAdrIntakesTaskComponent,
        BhDocumentLinkComponent,
        BhTreeViewComponent,
        BhAdfViewerComponent,
        BhNodeDownloadDirective,
        BhUserGuideComponent,
        BhSearchFieldComponent,
        LogoutComponent
    ],
    exports: [
      BhTreeViewComponent,
      BhAdfViewerComponent,
      BhNodeDownloadDirective
    ],
    entryComponents: [
      BhStartWorkflowComponent,
      SelectUserDialogComponent,
      BhDocumentPropertiesComponent,
      WfAdminTaskComponent,
      WfIntakesTaskComponent,
      WfSmeTaskComponent,
      WfReviewerTaskComponent,
      WfApproverTaskComponent,
      WfPublisherTaskComponent,
      BhInfoDialogComponent,
      BhDocumentLinkComponent,
      BhWorkflowHistoryComponent,
      WfAdrAdminTaskComponent,
      WfAdrApproverTaskComponent,
      WfAdrIntakesTaskComponent
    ],
    providers: [
        PreviewService,
        BhApiService,
        BhWebscriptService,
        BhDataListService,
        BhSearchService,
        BhWorkflowService,
        {
            provide: TRANSLATION_PROVIDER,
            multi: true,
            useValue: {
                name: 'app',
                source: 'resources'
            }
        }
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
