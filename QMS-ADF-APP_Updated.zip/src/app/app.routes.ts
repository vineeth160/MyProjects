/*!
 * @license
 * Copyright 2016 Alfresco Software, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardEcm } from '@alfresco/adf-core';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { DocumentlistComponent } from './components/documentlist/documentlist.component';
import { BhFolderViewComponent } from './components/bh-folder-view/bh-folder-view.component';
import { BhDocumentViewComponent } from './components/bh-document-view/bh-document-view.component';
import { AppLayoutComponent } from './app-layout/app-layout.component';
import { FileViewComponent } from './components/file-view/file-view.component';
import { BhTasksComponent } from './components/bh-tasks/bh-tasks.component';
import { BhMyTasksComponent } from './components/bh-my-tasks/bh-my-tasks.component';
import { BhMyWorkflowsComponent } from './components/bh-tasks/bh-my-workflows/bh-my-workflows.component';

import { WfIntakesTaskComponent } from './components/workflow/wf-intakes-task/wf-intakes-task.component';
import { IntakesTaskFormComponent } from './components/bh-tasks/intakes-task-form/intakes-task-form.component';
import { WfAdminTaskComponent } from './components/workflow/wf-admin-task/wf-admin-task.component';

import { ErrorComponent } from './error/error.component';

export const appRoutes: Routes = [
  { path: 'files/:nodeId/view', component: FileViewComponent, canActivate: [AuthGuardEcm], outlet: 'overlay' },
  {
    path: '',
    component: AppLayoutComponent,
    canActivate: [AuthGuardEcm],
    children: [
      {
        path: '',
        // redirectTo: '/folder-view',
        // pathMatch: 'full'
        component: BhFolderViewComponent
      },
      {
        path: 'documentlist',
        component: DocumentlistComponent
      },
      {
        path: 'home',
        component: BhFolderViewComponent
      },
      {
        path: 'folder-view',
        component: BhFolderViewComponent
      },
      {
        path: 'folder-view/:nodeId',
        component: BhFolderViewComponent
      },
      {
        path: 'document-view',
        component: BhDocumentViewComponent
      },
      {
        path: 'document-view/:nodeId',
        component: BhDocumentViewComponent
      },
      {
        path: 'search',
        children: [
          {
            path: '',
            component: BhDocumentViewComponent
          }
        ]
      },
      {
        path: 'advanced-search',
        children: [
          {
            path: '',
            component: BhDocumentViewComponent
          }
        ]
      },
      {
        path: 'task-details',
        children: [
          {
            path: '',
            component: BhMyTasksComponent
          }
        ]
      },
      {
        path: 'tasks',
        component: BhMyTasksComponent
      },
      {
        path: 'tasks/:view',
        component: BhMyTasksComponent
      },
      {
        path: 'workflows',
        component: BhMyWorkflowsComponent
      },
      {
        path: 'workflows/:view',
        component: BhMyWorkflowsComponent
      },
      {
        path: 'workflow/:id',
        component: BhMyWorkflowsComponent
      },
      {
        path: 'intakes-tasks',
        component: WfIntakesTaskComponent
      },
      {
        path: 'admin-tasks',
        component: WfAdminTaskComponent
      }/* ,
      {
        path: '**',
        component: ErrorComponent
      } */
    ],
    canActivateChild: [AuthGuardEcm]
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'logout',
    component: LogoutComponent
  }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);
