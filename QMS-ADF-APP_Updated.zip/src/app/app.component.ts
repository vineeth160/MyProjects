import { Component, ViewEncapsulation, OnInit, OnDestroy } from '@angular/core';
import { TranslationService, AuthenticationService } from '@alfresco/adf-core';
import { Router, NavigationEnd, RoutesRecognized } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter, pairwise } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit, OnDestroy {

  protected subscriptions: Subscription[] = [];

  constructor(translationService: TranslationService,
              private authService: AuthenticationService,
              private router: Router) {
    translationService.use('en');
    this.checkLogin();
  }

  ngOnInit() {
    this.subscriptions.push(
      this.router.events.pipe(
        filter(event => event instanceof NavigationEnd)
      ).subscribe((event: NavigationEnd) => {
        const currentUrl = event.url;
        if (currentUrl !== null && currentUrl !== undefined && currentUrl !== '' && currentUrl !== '/logout') {
          localStorage.setItem('currentUrl', this.getBaseUrl() + '/#' + currentUrl);
        }
        this.checkLogin();
      }),

      /* this.router.events.pipe(
        filter((evt: any) => evt instanceof RoutesRecognized), pairwise()
      ).subscribe((events: RoutesRecognized[]) => {
        console.log('previous url ::: ', events[0].urlAfterRedirects);
        console.log('current url ::: ', events[1].urlAfterRedirects);
        const currentUrl = events[1].urlAfterRedirects;
        if (currentUrl === '/logout') {
          const url = events[0].urlAfterRedirects;
          localStorage.setItem('previousUrl', url);
        }
      }) */
    );

    this.checkLogin();
  }

  ngOnDestroy() {
    this.subscriptions.forEach(subscription => subscription.unsubscribe());
    this.subscriptions = [];
  }

  checkLogin() {
    const login = this.authService.isLoggedIn();
    const url = window.location.href;
    const pUrl = localStorage.getItem('previousUrl');
    const hasPUrl = pUrl !== undefined && pUrl !== null && pUrl !== '';
    const isBaseUrl = this.isBaseUrl(pUrl);
    const isLogoutUrl = url === this.getLogoutUrl();
    if (!login) {
      if (hasPUrl && !isBaseUrl) {
        localStorage.setItem('previousUrl', pUrl);
      } else if (!isLogoutUrl) {
        localStorage.setItem('previousUrl', url);
      }
    } else {
      if (hasPUrl) {
        console.log('Previous Url : ', pUrl);
        location.replace(pUrl);
        localStorage.removeItem('previousUrl');
      }
    }
  }

  isBaseUrl(u: string): boolean {
    const baseUrl = this.getBaseUrl();
    const baseUrl1 = baseUrl + '/';
    const baseUrl2 = baseUrl + '/#';
    const baseUrl3 = baseUrl + '/#/';
    const baseUrl4 = baseUrl3 + 'folder-view';
    const logoutUrl = this.getLogoutUrl();
    return u === baseUrl || u === baseUrl1 || u === baseUrl2 || u === baseUrl3 || u === baseUrl4 || u === logoutUrl;
  }

  getLogoutUrl(): string {
    return this.getBaseUrl() + '/#/logout';
  }

  getBaseUrl(): string {
    let baseUrl = '';
    baseUrl += window.location.protocol;
    baseUrl += '//';
    baseUrl += window.location.host;
    baseUrl += '/qms-document-library';
    return baseUrl;
  }

  logout() {
    this.authService.logout().subscribe(() => {
      this.router.navigate(['/login']);
    });
  }

}
