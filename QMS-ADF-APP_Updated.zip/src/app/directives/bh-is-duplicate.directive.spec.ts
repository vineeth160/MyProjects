import { BhIsDuplicateDirective } from './bh-is-duplicate.directive';

describe('BhIsDuplicateDirective', () => {
  it('should create an instance', () => {
    const directive = new BhIsDuplicateDirective();
    expect(directive).toBeTruthy();
  });
});
