import { Directive, forwardRef, Injectable } from '@angular/core';
import { AsyncValidator, AbstractControl, ValidationErrors, NG_ASYNC_VALIDATORS } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { SearchService } from '@alfresco/adf-core';
import { QueryBody, RequestQuery, RequestScope } from '@alfresco/js-api';

@Injectable({ providedIn: 'root' })
export class IsDuplicate implements AsyncValidator {

  constructor(private search: SearchService) {}

  validate(
    field: any
  ): Promise<ValidationErrors | null> | Observable<ValidationErrors | null> {

    if (field.form !== undefined && field.form !== null ) {
      const v = field.form.controls.documentReferenceNumber.value;
      const n = field.nodeId;
      if (v !== '' && v !== undefined && v !== null) {
        let q = 'TYPE:\'bhqms:iso_qty_manual\' AND ISNOTNULL:\'bhqms:reference\' AND bhqms:reference:\'' + v + '\'';
        if (n !== '' && n !== undefined && n !== null) {
          q += ' AND NOT ID:\'' + 'workspace://SpacesStore/' + n + '\'';
        }
        const queryBody: QueryBody = {
          query: new RequestQuery({
            language: 'afts',
            query: q
          }),
          scope: new RequestScope({
            locations: ['nodes', 'deleted-nodes']
          })
        };
        return (v === '') ? of(null) : field.search.searchByQueryBody(queryBody).toPromise().then(
          r => {
            return (r && r.list && r.list.entries && r.list.entries.length > 0) ? { isDuplicate : true } : null;
          }
        );
      } else {
        return of(null);
      }
    } else {
      return of(null);
    }
  }

}

@Directive({
  selector: '[appBhIsDuplicate]',
  providers: [
    {
      provide: NG_ASYNC_VALIDATORS,
      useExisting: forwardRef(() => IsDuplicate),
      multi: true
    }
  ]
})
export class BhIsDuplicateDirective {

  constructor(private validator: IsDuplicate) {}

  validate(control: AbstractControl) {
    this.validator.validate(control);
  }

}
