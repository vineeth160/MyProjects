# Alfresco AIO Project - SDK 3.1.0 With RM - 2.7.a

This is an All-In-One (AIO) project for Alfresco SDK 3.1.0 

* Command to create a maven structure : mvn archetype:generate -Dfilter=org.alfresco: 
* Choose allinone structure : org.alfresco.maven.archetype:alfresco-allinone-archetype 
* Choose the latest version of maven SDK : 3.0.1 (current project) 
* Define value for property 'groupId': 
* Define value for property 'artifactId': 
* Define value for property 'package':

Run with `mvn clean install -DskipTests=true alfresco:run` or `./run.sh` and verify that it 

 * Runs the embedded Tomcat + H2 DB 
 * Runs Alfresco Platform (Repository)
 * Runs Alfresco Solr4
 * Runs Alfresco Share
 * Packages both as JAR and AMP assembly for modules
 
# POM Configurations
New AMPs when needs to be they should be overlayed to alfresco.war and share.war. So, the dependencies are added to moduleDependency tag under platformModules and shareModules
 * Add moduleDependency of share and repo amp of Records Management AMP
 * Add moduleDependency of share and repo amp of JavaScript Console, Reference https://github.com/share-extras/js-console
 
# Repo Changes Included are
 
 ## Java Webscripts
  * Sample hello world webscript (GET /api/custom/hello-world)
  * webscript for Upload which uploads documents to specified site under a folder called 'Upload' by creating today's folder
  * Webscript for Multi Upload functionality (POST /api/custom/multiupload) with site,files,folderName in formdata
  * Webscript for Download of a document (GET /api/custom/download?nodeid=) converts to stream 
  * Webscript for Split of a pdf document (POST /api/custom/pdf-split) with nodeid, pages for split
  * Webscript for Merge of a pdf document (POST /api/custom/pdf-merge) with nodeids for merge
  * Webscript for Update of a document (POST /api/custom/update) with nodeid, propertiesJson, versionInfo(minor, major, nochange)
  * Webscript for Bulk Update of a document (POST /api/custom/bulk-update) with nodeId, propertiesJson [audit param]
  * Webscript for Copy-Move of document (POST /api/custom/copy-move) with nodeId, destiantion, action (Move/Copy)
  * Webscript for Locking/Un-Locking document (GET /api/custom/lockDocument?noderef={noderef}&amp;action={action})
  * Webscript for Ending Other Users Tasks (GET /api/custom/deleteTask)
  
  ## JavaScript Webscripts
  * Webscript to get the Node details (GET /api/custom/fileinfo?nodeRef={nodeRef})
  
  ## Behaviours/Polcies
  * Sample onMove and beforeMove Polcies which prints source/destination folder names along with file name
  
  ## Schedulers
  * Sample Job just prints the job fire time on a regular corn intervals
  
  ## Actions
  * Sample Action which adds sent values as Tags to a Document
  
  ## Content Model
  * Introduced a custom content model, with aspects, types and properties
  * Implemented a Java Backed custom constraints.
 
# Share Changes Included are 

  ## Webscripts
  * Custom Hello world webscript (GET /api/custom/hello-world)
  
  ## Share Configuration
  * Custom Share Config XML for the content model (Node Type, Model Type, Advance Search)
  
  ## Surf Customizations
  * Custom page with Alfresco headers and footers with body being the hello-world webscript loaded (http://localhost:8080/share/page/custom-page)
  * Custom page loading the Surf based dashlet, with a sample click button (http://localhost:8080/share/page/custom-dashlet-page)
  
  ## Aikau Customizations
  * Modified OOTB Share Header under site 'SAMPLE' by removing OOTB options, added AlfMenuItem, AlfMenuGroup, AlfMenuBarPopup, AlfCascadingMenu, and Implemented custom site dropdown overriding the default 
  * Custom Aikau page with aikau widgets (MenuList, Cascade List, Simple Menu) (http://localhost:8080/share/page/dp/ws/custom/aikau/page)
  * Custom Aikau Dashlet (settings > Customisation dashboard > Add Dashlets - we see a dashlet with name 'Sample Aikau Dashlet')
  
  
  ## Document Library
  * Introduced a custom button on docLib breadcrum 
  * Added Custom action on document and folder level (calling a webscript, calling action, calling normal message)
  * Added extra option (Create a document of custom type) in Create dropdown of doclib breadcrum
  * Modified Metadata template to show custom fields on custom type documents on document library page
   
  
 
