package org.alfresco.sample.evaluators;

import org.alfresco.web.evaluator.BaseEvaluator;
import org.json.simple.JSONObject;

public class OnSiteIdEvaluator extends BaseEvaluator {
	private static final String SITE_ID = "sample";

	@Override
	public boolean evaluate(JSONObject jsonObject) {
		try {

			String siteName = getSiteId(jsonObject);
			if (siteName == null) {
				return false;
			} else {
				if (siteName.contains(SITE_ID)) {
					return true;
				} else {
					return false;
				}
			}
		} catch (Exception err) {
			throw new RuntimeException("JSONException whilst running action evaluator: " + err.getMessage());
		}
	}
}