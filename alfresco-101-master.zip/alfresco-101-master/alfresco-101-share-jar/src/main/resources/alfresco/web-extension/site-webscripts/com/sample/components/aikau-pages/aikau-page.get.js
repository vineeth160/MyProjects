var logoWidget = {
	name : "alfresco/logo/Logo"
};

var simpleMenu = {
	name : "alfresco/menus/AlfMenuBar",
	config : {
		widgets : [ {
			name : "alfresco/menus/AlfMenuBarItem",
			config : {
				label : "One"
			}
		}, {
			name : "alfresco/menus/AlfMenuBarItem",
			config : {
				label : "Two"
			}
		} ]
	}
};

var menuList = {
	name : "alfresco/menus/AlfMenuBar",
	config : {
		widgets : [ {
			name : "alfresco/menus/AlfMenuBarPopup",
			config : {
				label : "One",
				widgets : [ {
					name : "alfresco/menus/AlfMenuItem",
					config : {
						label : "Popup item 1"
					}
				}, {
					name : "alfresco/menus/AlfMenuItem",
					config : {
						label : "Popup item 2"
					}
				} ]
			}
		}, {
			name : "alfresco/menus/AlfMenuBarItem",
			config : {
				label : "Two"
			}
		} ]
	}
};

var hybridMenu = {
	name : "alfresco/menus/AlfMenuBar",
	config : {
		widgets : [ {
			name : "alfresco/menus/AlfMenuBarPopup",
			config : {
				label : "One",
				widgets : [ {
					name : "alfresco/menus/AlfMenuGroup",
					config : {
						label : "Group 1",
						widgets : [ {
							name : "alfresco/menus/AlfMenuItem",
							config : {
								label : "Popup item 1",
								iconClass : "alf-edit-icon"
							}
						}, {
							name : "alfresco/menus/AlfCascadingMenu",
							config : {
								label : "Popup item 2",
								iconClass : "alf-cog-icon",
								widgets : [ {
									name : "alfresco/menus/AlfMenuItem",
									config : {
										label : "Cascaded menu item 1",
										iconClass : "alf-leave-icon"
									}
								}, {
									name : "alfresco/menus/AlfMenuItem",
									config : {
										label : "Cascaded menu item 2",
										iconClass : "alf-help-icon"
									}
								} ]
							}
						} ]
					}
				}, {
					name : "alfresco/menus/AlfMenuGroup",
					config : {
						label : "Group 2",
						iconClass : "alf-logout-icon",
						widgets : [ {
							name : "alfresco/menus/AlfMenuItem",
							config : {
								label : "Popup item 3",
								iconClass : "alf-profile-icon"
							}
						} ]
					}
				} ]
			}
		}, {
			name : "alfresco/menus/AlfMenuBarItem",
			config : {
				label : "Two"
			}
		} ]
	}
}

model.jsonModel = {
	widgets : [ logoWidget, simpleMenu, menuList, hybridMenu ]
};