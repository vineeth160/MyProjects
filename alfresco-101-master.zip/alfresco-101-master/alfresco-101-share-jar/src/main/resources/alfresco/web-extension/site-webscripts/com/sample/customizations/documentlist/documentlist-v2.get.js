// Find the default DocumentList widget and replace it with the custom widget
if (page.url.templateArgs.site == "sample") {
	for (var i = 0; i < model.widgets.length; i++) {
		if (model.widgets[i].id == "DocumentList") {
			model.widgets[i].name = "Custom.components.DocumentList";
		}
		if (model.widgets[i].id == "DocListToolbar") {
			model.widgets[i].name = "Custom.components.Toolbar";
		}
	}
}
