/**
 * This is share-header file which overrides share-header.lib.js
 * Aikau Widgets list is provided under https://dev.alfresco.com/resource/docs/aikau-jsdoc/
 */

if (page.url.templateArgs.site == "sample") {

	// Deleting OOTB MENU_OPTIONS START
	widgetUtils.deleteObjectFromArray(model.jsonModel, "id", "HEADER_TASKS");
	widgetUtils.deleteObjectFromArray(model.jsonModel, "id",
			"HEADER_CUSTOM_PROFILE_LINK");
	widgetUtils.deleteObjectFromArray(model.jsonModel, "id", "HEADER_MY_FILES");
	widgetUtils.deleteObjectFromArray(model.jsonModel, "id",
			"HEADER_SHARED_FILES");
	/*widgetUtils.deleteObjectFromArray(model.jsonModel, "id",
			"HEADER_SITES_MENU");*/
	widgetUtils.deleteObjectFromArray(model.jsonModel, "id", "HEADER_PEOPLE");
	widgetUtils.deleteObjectFromArray(model.jsonModel, "id",
			"HEADER_REPOSITORY");
	widgetUtils.deleteObjectFromArray(model.jsonModel, "id",
			"HEADER_ADMIN_CONSOLE");
	// Deleting OOTB MENU_OPTIONS END

	// Define custom Menu Bar item
	var menubarItem = {
		id : "HEADER_CUSTOM_MENU_ITEM",
		name : "alfresco/menus/AlfMenuBarItem",
		config : {
			label : "Custom Menu Bar",
			targetUrl : "custom-dashlet-page" // pointing to my custom
		}
	};

	// Menu Bar Group
	var menuItemGroup = {
		id : "HEADER_CUSTOM_MENU_GROUP",
		name : "alfresco/menus/AlfMenuGroup",
		config : {
			label : "AlfMenuGroups",
			widgets : [ 
				{
					name : "alfresco/menus/AlfMenuItem",
					config : {
						label : "AlfMenuItem 1",
						targetUrl : ""
					}
				},
				{
					name : "alfresco/menus/AlfMenuItem",
					config : {
						label : "AlfMenuItem 2",
						targetUrl : ""
					}
				} 
			]
		}
	};

	// Define custom menu popup items with menu group
	var menuPopUp = {
		name : "alfresco/header/AlfMenuBarPopup",
		config : {
			id : "HEADER_CUSTOM_MENU_POPUP",
			label : "Menu Bar Popup",
			widgets : []
		}
	};
	menuPopUp.config.widgets.push(menuItemGroup);

	// Define custom menu Mixup items with menu groups, items, popups and misc
	var menuMixUp = {
		name : "alfresco/header/AlfMenuBarPopup",
		config : {
			id : "HEADER_CUSTOM_MENU_MIXUP",
			label : "Menu Misc Options",
			widgets : [
				{
					name : "alfresco/menus/AlfCheckableMenuItem",
					config : {
						label : "AlfCheckableMenuItem",
						value : "send",
						checked : false
					}
				},
				{
					name : "alfresco/menus/AlfCascadingMenu",
					config : {
						label : "AlfCascadingMenu",
						widgets : [
							{
								name : "alfresco/menus/AlfMenuItem",
								config : {
									label : "AlfMenuItem 1",
									targetUrl : ""
								}
							},
							{
								name : "alfresco/menus/AlfMenuItem",
								config : {
									label : "AlfMenuItem 2",
									targetUrl : ""
								}
							} 
						]
					}
				}
			]
		}
	};
	
	// Define custom menu popup items with menu group
	var menuPopUp = {
		name : "alfresco/header/AlfMenuBarPopup",
		config : {
			id : "HEADER_CUSTOM_MENU_POPUP",
			label : "Menu Bar Popup",
			widgets : []
		}
	};

	// Find the HEADER_APP_MENU_BAR where all the apps are loaded
	var headerMenubar = widgetUtils.findObject(model.jsonModel, "id",
			"HEADER_APP_MENU_BAR");
	if (headerMenubar != null) {
		// Add Custom Menu Bar item, Menu PopUp, Menu MixUp
		headerMenubar.config.widgets.push(menubarItem, menuPopUp, menuMixUp);
	}
	
	
	﻿//Find the "Sites" menu...
	   var sitesMenu = 
	     widgetUtils.findObject(model.jsonModel, "id", "HEADER_SITES_MENU");
	   if (sitesMenu != null)
	   {
	     // Change the widget to our custom menu...
	     sitesMenu.name = "resources/alfresco-101-share-jar/sample/components/widgets/sitesmenu/SitesMenu";
	   }   
}
