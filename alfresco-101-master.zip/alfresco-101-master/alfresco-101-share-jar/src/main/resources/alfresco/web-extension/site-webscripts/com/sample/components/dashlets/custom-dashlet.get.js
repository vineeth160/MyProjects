function widgets() {
	
	// Surf Dashlet widgets
	var widgets = [];

	// Main component pointing to the name specified in our js (custom-dashlet.js)
	widgets.push({
	    id: "CustomDashlet",
	    name: "Alfresco.dashlet.Custom",
	    options: {
	        componentId: instance.object.id
	    }
	});

	// Resizer
	widgets.push({
	    id : "DashletResizer",
	    name : "Alfresco.widget.DashletResizer",
	    initArgs : ["\"" + args.htmlid + "\"","\"" + instance.object.id + "\""],
	    useMessages: false
	});
	
	// Widget instantiation metdata...
	var dashletTitleBarActions = {
		id : "DashletTitleBarActions",
		name : "Alfresco.widget.DashletTitleBarActions",
		useMessages : false,
		options : {
			actions : [ {
				cssClass : "help",
				bubbleOnClick : {
					message : "This is an example dashlet"
				},
				tooltip : "Custom Dashlet Example"
			} ]
		}
	};
	
	widgets.push(dashletTitleBarActions);
	model.widgets = widgets;
	
	//model.widgets = [ dashletTitleBarActions ];
}

// main function called at the beginning
widgets();
