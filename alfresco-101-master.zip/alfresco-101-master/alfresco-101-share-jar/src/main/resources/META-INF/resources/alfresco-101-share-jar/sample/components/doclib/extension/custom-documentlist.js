if (typeof Custom == undefined || !Custom) {

	var Custom = {};
}
if (!Custom.components) {
	Custom.components = {};
}

(function() {
	var $siteURL = Alfresco.util.siteURL;
	Custom.components.DocumentList = function CustomDocumentList_constructor(
			htmlId) {
		Custom.components.DocumentList.superclass.constructor
				.call(this, htmlId);
		return this;
	};

	YAHOO.extend(Custom.components.DocumentList, Alfresco.DocumentList, {
		onReady : function CustomDL_onReady() {

			//document.getElementById(this.id+"-fileUpload-button").style.visibility="hidden";

			if (Alfresco.constants.SITE == "sample") {

			}
			Custom.components.DocumentList.superclass.onReady.call(this);
			var elms = Dom.getElementsByClassName("left");
			var spn = document.createElement('span');
			var btn = document.createElement('button');
			var t = document.createTextNode("Custom Upload");
			btn.appendChild(t);
			btn.onclick = this.onButtonClick;
			spn.setAttribute('class', 'yui-button yui-push-button');
			spn.appendChild(btn);
			elms[0].appendChild(spn);

		},

		onButtonClick : function CustomDL_onButtonClick(e, p_obj) {
			/*Alfresco.util.PopupManager.displayMessage({
				text : "Button clicked in Custom Document List!"
			});*/

			if (!this.fileUpload) {
				this.fileUpload = Alfresco.getFileUploadInstance();
			}

			// Show uploader for single file select - override the upload URL to use appropriate upload service
			var uploadConfig = {
				username : Alfresco.constants.USERNAME,
				siteId : Alfresco.constants.SITE,
				uploadDirectory : '/',
				containerId : 'Logo',
				filter : [],
				mode : this.fileUpload.MODE_MULTI_UPLOAD,
				thumbnails : "doclib",
				onFileUploadComplete : {
					fn : this.onUsersUploadComplete,
					scope : this
				}
			};


			this.fileUpload.show(uploadConfig);

			// Make sure the "use Flash" tip is hidden just in case Flash is enabled...
			var singleUploadTip = Dom.get(this.fileUpload.id
					+ "-singleUploadTip-span");
			
			Dom.addClass(singleUploadTip, "hidden");
			Event.preventDefault(e);
		}

	});

})();