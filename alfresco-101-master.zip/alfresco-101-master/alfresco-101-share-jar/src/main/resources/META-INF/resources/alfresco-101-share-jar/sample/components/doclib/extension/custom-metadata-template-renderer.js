(function () {
    YAHOO.Bubbling.fire("registerRenderer",
        {
            propertyName: "invoiceNumberCustomRendition",
            renderer: function invoiceNumber_renderer(record, label) {
                var jsNode = record.jsNode,
                    properties = jsNode.properties,
                    html = "";
                var invoiceNumber = properties["if:invoiceNumber"] || "";
                html = '<span>' + label + '<h2>' + invoiceNumber + '</h2></span>';

                return html;
            }
        });
})();