(function () {
    YAHOO.Bubbling.fire("registerAction",{
    	actionName: "onActionCallWebScript",
    	fn: function custom_onActionCallWebScript(file) {
    		this.modules.actions.genericAction({
    			success: {
    				callback: {
    					fn: function custom_onActionCallWebScriptSuccess(response) {
    						Alfresco.util.PopupManager.displayPrompt({
    							title: this.msg("custom.webscript.action.callWebScript.msg.success"),
    							text: JSON.stringify(response.json),
    							buttons: [
    								{
    									text: this.msg("button.ok"),
    									handler: function custom_onActionCallWebScriptSuccess_success_ok() {
    										this.destroy();
    									},
    									isDefault: true
    								},
    								{
    									text: this.msg("button.cancel"),
    									handler: function custom_onActionCallWebScriptSuccess_cancel() {
    										this.destroy();
    									}
    								}]
    						});
    					},
    					scope: this
    				}
    			},
    			failure: {
    				message: this.msg("custom.webscript.action.callWebScript.msg.failure",
    						file.displayName, Alfresco.constants.USERNAME)
    			},
    			webscript: {
    				name: "/api/custom/fileinfo?nodeRef={nodeRef}",
    				stem: Alfresco.constants.PROXY_URI,
    				method: Alfresco.util.Ajax.GET,
    				params: {
    					nodeRef: file.nodeRef
    				}
    			},
    			config: {}
    		});
    	}
    });
})();