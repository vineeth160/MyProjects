 if (typeof Custom == undefined || !Custom) {

	var Custom = {};
}
if (!Custom.components) {
	Custom.components = {};
}

(function() {

	// Define constructor...
	Custom.components.Toolbar = function CustomDocumentList_constructor(htmlId) {
		Custom.components.Toolbar.superclass.constructor.call(this, htmlId);
		return this;
	};

	YAHOO.extend(Custom.components.Toolbar, Alfresco.DocListToolbar, {
		onReady : function CustomDL_onReady() {

			Custom.components.Toolbar.superclass.onReady.call(this);
			this.widgets.CustomFileUpload = Alfresco.util.createYUIButton("yui-gen94", this.onCustomFileUpload, {
						disabled : true,
						value : "CreateChildren"
					});

			/*if (Alfresco.constants.SITE == "sample") {
				Dom.removeClass(this.id + "fileUpload-button", "hidden");
			} else {
				Dom.addClass(this.id + "fileUpload-button", "hidden");
			}*/
			this.dynamicControls.push(this.widgets.CustomFileUpload);
		},
		
		onCustomFileUpload: function q(Q, R) {
            /*//if (this.fileUpload === null) {
                //this.fileUpload1 = Alfresco.getCustomFileUploadInstance()
			this.fileUpload1 = Alfresco.getFileUploadInstance()
				
            //}
            var O = {
                siteId: this.options.siteId,
                containerId: this.options.containerId,
                uploadDirectory: this.currentPath,
                filter: [],
                mode: this.fileUpload1.MODE_MULTI_UPLOAD,
                thumbnails: "doclib",
                onFileUploadComplete: {
                    fn: this.onFileUploadComplete,
                    scope: this
                }
            };
            this.fileUpload1.show(O);
            if (YAHOO.lang.isArray(R) && R[1].tooltip) {
                var P = Alfresco.util.createBalloon(this.fileUpload1.uploader.id + "-dialog", {
                    html: R[1].tooltip,
                    width: "30em"
                });
                P.show();
                this.fileUpload1.uploader.widgets.panel.hideEvent.subscribe(function() {
                    P.hide()
                })
            }*/
				Alfresco.util.PopupManager.displayMessage({
					text : "Button clicked in Custom Document List!"
				});
        }

	});
})();