/**
 * Custom Dashlet component.
 *
 * @namespace  Alfresco.dashlet.Custom
 * @class  Alfresco.dashlet.Custom
 */
(function() {
	/**
	 * YUI Library aliases
	 */
	var Dom = YAHOO.util.Dom;

	/**
	 * Alfresco Slingshot aliases
	 */
	var $html = Alfresco.util.encodeHTML;

	/**
	 * Custom Dashlet constructor.
	 *
	 * @param {String} htmlId The HTML id of the parent element
	 * @return {Alfresco.dashlet.Custom} The new component instance
	 * @constructor
	 */
	Alfresco.dashlet.Custom = function Custom_constructor(htmlId) {
		return Alfresco.dashlet.Custom.superclass.constructor.call(this,
				" Alfresco.dashlet.Custom", htmlId, [ "button" ]);
	};

	/**
	 * Extend from Alfresco.component.Base and add class implementation
	 */
	YAHOO.extend(Alfresco.dashlet.Custom, Alfresco.component.Base, {
		options : {},
		/**
		 * Fired by YUI when parent element is available for scripting
		 *
		 * @method onReady
		 */
		onReady : function onReady() {
			this.widgets.testButton = Alfresco.util.createYUIButton(this,
					"testButton", this.onButtonClick);
		},

		/**
		 * Button click event handler
		 *
		 * @method onButtonClick
		 */
		onButtonClick : function onButtonClick(e) {
			Alfresco.util.PopupManager.displayMessage({
				text : "Button clicked in Custom Surf Dashlet!"
			});
		},

	});
})();