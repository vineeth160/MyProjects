(function () {
    YAHOO.Bubbling.fire("registerAction",{
    	actionName: "onShowCustomMessage",
    	fn: function custom_onShowCustomMessage(file) {
    		Alfresco.util.PopupManager.displayMessage({
    			text: this.msg("custom.js.action.showCustomMessage.text", file.displayName, Alfresco.constants.USERNAME)
            });
        }
    });
})();