# Installation of Alfresco Content Services using the Distribution Zip

 ## Installing overview
 * This includes a JRE, a supported database, Tomcat application server, Alfresco Search Services, and additional components 
 * Download the distribution zip file by accessing the [Support Portal](https://support.alfresco.com)
 * Click Product Downloads, and then select the version of the product you require.
 
 ### Download the required binaries
 * Alfresco content services 
 * Alfresco Search Services 
 * Postgres DB 

| Installation file    					     | File name                                          | Description        |
|------------------------------------------------------------|----------------------------------------------------|--------------------------------------------------------------|
| Alfresco Content Services Distribution zip | alfresco-content-services-distribution-6.2.x.zip  | Distribution zip for new installations or for upgrades. Alfresco WAR files (in distribution zip) for a manual install into an existing Tomcat application server. This distribution zip also contains the Module Management Tool (MMT) and the sample extension files, such as alfresco-global.properties. |
| Alfresco Search Services Distribution zip  | alfresco-search-services-2.2.x.zip  | Alfresco Search Services installation file. |
	
 ### Create the folder structure alfresco
 * Under main folder '**alfresco**' create below folders
	 1. *alfresco-content-services*
	 2. *alfresco-search-services*
	 3. *alfresco-database-services* 
 
 * Copy the extracted files from alfresco-content-services.zip to alfresco-content-services folder. 
 * Copy the extracted files from alfresco-search-services.zip to alfresco-search-services folder
 
 ## Create a new database for Alfresco Content Services
 * Install postgres DB in alfresco-database-services folder. Give Password as postgres. [You can give any other password to] 
 * Open **pgAdmin4.exe** from the installation path. C:\Program Files\PostgreSQL\13\pgAdmin 4\bin\pgAdmin4.exe. It opens application in browser
 * Go to Tools > Query Tool, Execute the below commands, For PostgreSQL, run the following commands:
 
	 | create database alfresco encoding 'utf8'; <br /> create role alfresco LOGIN password 'alfresco'; <br /> grant all on database alfresco to alfresco;  |
	 |------------------------------------------------------------|
 
 ![alt text](https://github.com/srikanth-josyula/alfresco-101/blob/master/docs/images/distribution-zip-db-1.png?raw=true)
 
 *Tip :: Run commands one by one, if there is error while running all 3 at a time*
 
 ## Installing Alfresco Content Services on Tomcat
 * Download and install Tomcat following the instructions from [Tomcat Portal](http://tomcat.apache.org).
 * Place it under ‘**alfresco-content-services**’ folder and rename it to **tomcat**.
 * Create an additional classpath to Tomcat, which will be shared among all web applications. 

 * Create the directories required for an Alfresco Content Services installation under <**TOMCAT_HOME**>:
	1. *Create the **shared/classes** directory.*
	2. *Create the **shared/lib** directory.*

 * Open the **<TOMCAT_HOME>/conf/catalina.properties** file.
 * Change the value of the shared.loader= property to the following: <b>shared.loader=${catalina.base}/shared/classes,${catalina.base}/shared/lib/*.jar</b>
 
  ### Installing alfresco wars
 * Copy the JDBC drivers for the database you are using to the lib directory. 
 * In case if you are using postgres, <b>postgresql-42.2.6.jar</b>
 
	 1. Copy '<b>postgresql-42.2.6.jar</b>' from 'alfresco-content-services\web-server\lib\' To 'alfresco-content-services\tomcat\shared\lib\'
	 2. Copy '<b>wars</b>' From 'alfresco-content-services\web-server\webapps\' To 'alfresco-content-services\tomcat\webapps\'
	 3. Copy folder '<b>catalina</b>' from 'alfresco-content-services\web-server\conf\' to 'alfresco-content-services\tomcat\conf\'
	 4. Copy all contents from below folders From 'alfresco-content-services\web-server\shared\classes\' To 'alfresco-content-services\tomcat\shared\classes\'
	 5. Rename alfresco-global-properties.sample to <b>alfresco-global-properties</b>

  ### Tailoring your installation
* Add the following in the alfresco-global-properties

	 |  dir.root=/path/folder/dir/alf_data <br />dir.keystore={dir.root}/keystore <br />db.username=alfresco <br />  db.password=alfresco <br />db.driver=org.postgresql.Driver <br />db.url=jdbc:postgresql://localhost:5432/alfresco <br /><br />alfresco.context=alfresco <br />alfresco.host=localhost <br />alfresco.port=8080 <br />alfresco.protocol=http <br /><br />share.context=share<br />share.host=localhost <br />share.port=8080 <br />share.protocol=http <br /><br />messaging.subsystem.autoStart=false <br /><br />jodconverter.enabled=false  <br />jodconverter.officeHome=null <br />jodconverter.portNumbers=8100 |
	 |------------------------------------------------------------|
	 
* Create folder **modules** under the tomcat ,Create folders **share** and **platform** under modules 
* SKIPPED_____Go to '*alfresco-content-services\tomcat\conf\Catalina\localhost*' & modify paths in alfresco.xml and share.xml, (make sure the value base is pointing to the share and platform folders located under tomcat\modules eg : <i>base="${catalina.base}/modules/share*)</i>

## Installing Alfresco search Services

* Verify extracted search services are copied to alfresco-search-services folder
*  Add below properties in alfresco-global-properties

	 | index.subsystem.name=solr6  <br /><br />solr.secureComms=none <br />solr.port=8983 <br />solr.base.url=/solr <br />solr.host=localhost |
	 |------------------------------------------------------------|

* Configure HTTP, Open solrhome/templates/rerank/conf/solrcore.properties & \alfresco-search-services\solrhome\templates\noRerank\conf\solrcore.properties.Replace alfresco.secureComms=https with:
* alfresco.secureComms=none

* (Optional) If you want to install Search Services on a separate machine, set the SOLR_SOLR_HOST and SOLR_ALFRESCO_HOST environment variables before starting Search Services, for more see Search Services externalized configuration.
(Windows) update the alfresco-search-services/solr.in.cmd file:

* set SOLR_SOLR_HOST=localhost
* set SOLR_ALFRESCO_HOST=localhost

## Starting and stopping Alfresco Content Services and Alfresco Search Services

* Start solr ; 
* Go to ../alfresco-search-services/solr/bin/and run this command <b>solr start -a "-Dcreate.alfresco.defaults=alfresco,archive" </b>


* Start the tomcat; 
* Go to alfresco-content-services/tomcat/bin And run this – <b>startup.bat </b>








In some cases, there may be more than 1 Java installed and configured on the servers or development workstations. In such cases, we may have to pick the desired one for Alfresco. This is a simple configuration change. Please add the below 2 lines in the catalina.sh or catalina.bat file
alfresco-content-services/tomcat/bin/catalina.bat
set "JAVA_HOME=C:\Program Files\Java\jdk-11.0.6" set "Path=%JAVA_HOME%\bin" 

