package alfresco.sample.webscripts;

/**
 * This is a Merge Webscript, where it takes nodeID of the PDF files in alfresco as input string array
 * takes input filename and endpage values and merges the files and 
 * upload the new doc to alfresco with give file name
 * 
 **/

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.content.MimetypeMap;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.util.PDFMergerUtility;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

public class MergePDFDocument extends DeclarativeWebScript {
	private ServiceRegistry serviceRegistry;

	private static Log logger = LogFactory.getLog(MergePDFDocument.class);

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest request, Status status, Cache cache) {
		Map<String, Object> model = new HashMap<String, Object>(5);
		JSONObject requestJson;
		NodeRef newDocNoderef = null;
		String noderef = "";
		String fileName = "";
		try {
			if (request != null && !StringUtils.isEmpty(request.getContent().getContent())) {
				requestJson = new JSONObject(request.getContent().getContent());

				if (requestJson.has("noderef")) {
					noderef = requestJson.getString("noderef");
					logger.debug("Missing nodeRef in the request json");
				}
				if (requestJson.has("fileName")) {
					fileName = requestJson.getString("fileName");
					logger.debug("Missing fileName in the request json");
				}
				if (StringUtils.isEmpty(noderef) || StringUtils.isEmpty(fileName)) {
					model.put("code", "400");
					model.put("message", "Please pass a valid request body");
					model.put("newdocument_noderef", "");
				}

				if (noderef.contains(",")) {
					String[] noderefsArray = noderef.split(",");
					List<NodeRef> noderefsList = new ArrayList<>();
					for (String string : noderefsArray) {
						noderefsList.add(new NodeRef(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, string));
					}
					newDocNoderef = mergePdfs(noderefsList, fileName);

					model.put("code", "200");
					model.put("message", "Merged document created successfully.");
					model.put("newdocument_noderef", newDocNoderef.getId());
				}else {
					logger.debug("Only one nodeRef selected for merge");
					model.put("code", "200");
					model.put("message", "single nodeRef found. Returning the same document nnodeRef");
					model.put("newdocumentnoderef",new NodeRef(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, noderef).getId());
				}

				return model;
			}

		} catch (Exception e) {
			model.put("code", "400");
			model.put("message", "OAException: " + e);
			model.put("newdocument_noderef", "");
		}
		return model;
	}

	private NodeRef mergePdfs(List<NodeRef> nodeRefList, String fileName) throws FileNotFoundException {
		InputStream originalInputStream = null;
		ContentReader reader = null;
		NodeRef newDocNoderef = null;
		PDFMergerUtility PDFmerger = new PDFMergerUtility();
		ByteArrayOutputStream outputstream = new ByteArrayOutputStream();

		try {
			logger.debug("Merging of Doc Started");
			for (NodeRef node : nodeRefList) {
				reader = serviceRegistry.getContentService().getReader(node, ContentModel.PROP_CONTENT);
				originalInputStream = reader.getContentInputStream();
				PDFmerger.addSource(originalInputStream);
			}
			PDFmerger.setDestinationStream(outputstream);
			PDFmerger.mergeDocuments();
			originalInputStream.close();
			newDocNoderef = writeContentToAlfresco(outputstream, nodeRefList, fileName);
			logger.debug("Documents are merged and new pdf is created at "+newDocNoderef);

		} catch (IOException e) {
			e.printStackTrace();
		} catch (COSVisitorException e) {
			e.printStackTrace();
		}

		return newDocNoderef;
	}

	public NodeRef writeContentToAlfresco(ByteArrayOutputStream outputstream, List<NodeRef> childRefList,
			String fileName) throws IOException {
		NodeRef pdf = null;
		try {

			/*
			 * FileOutputStream foutputStream = new FileOutputStream( new
			 * File("C:/Users/SriKanth/Desktop/PDF merger utility/merged.pdf"));
			 * outputstream.writeTo(foutputStream);
			 */
			logger.debug("Upload to Alfresco Started");

			NodeRef parentNodeRef = serviceRegistry.getNodeService().getPrimaryParent(childRefList.get(0))
					.getParentRef();

			FileInfo pdfInfo = serviceRegistry.getFileFolderService().create(parentNodeRef, fileName + ".pdf",
					ContentModel.TYPE_CONTENT);
			pdf = pdfInfo.getNodeRef();

			ContentWriter writer = serviceRegistry.getContentService().getWriter(pdf, ContentModel.PROP_CONTENT, true);
			writer.setMimetype(MimetypeMap.MIMETYPE_PDF);
			writer.setEncoding("UTF-8");
			writer.putContent(new ByteArrayInputStream(outputstream.toByteArray()));

			logger.debug("Upload to Alfresco Ended");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (outputstream != null)
				outputstream.close();
		}

		return pdf;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
}
