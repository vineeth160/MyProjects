package alfresco.sample.webscripts;

/**
 * "nodeId" <nodeID>
 * "propertiesJson" : <{"title":"SampleDoc","description":"Sample Document to test update webscript",
 * 						"filename":"New Bulk Update.pdf","author":"Kanth","createdDate":"26/03/1994","modifiedDate":"16/06/1993",
 * 						"creator":"kanth","modifier":"srikanth"}>
 **/

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.namespace.QName;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.servlet.FormData;

public class BulkUpdateMetadata extends DeclarativeWebScript{

	private static Log logger = LogFactory.getLog(BulkUpdateMetadata.class);

	private BehaviourFilter behaviourFilter;
	private ServiceRegistry serviceRegistry;

	protected Map<String, Object> executeImpl(WebScriptRequest request, Status status, Cache cache) {
		Map<String, Object> model = new HashMap<String, Object>();

		String nodeId = null;
		String propertiesJson = null;
		try {
			if (request.getContentType().equalsIgnoreCase("multipart/form-data")) {
				FormData formData = (FormData) request.parseContent();
				FormData.FormField[] fields = formData.getFields();
				for (FormData.FormField field : fields) {
					switch (field.getName()) {
					case "nodeId":
						nodeId = field.getValue();
						if (StringUtils.isEmpty(nodeId)) {
							model.put("code", "400");
							model.put("message", "nodeId is null/empty in the request");
							model.put("newdocument_noderef", "");
						}
						logger.info("Input parameter nodeId value :" + nodeId);
						break;
					case "propertiesJson":
						propertiesJson = field.getValue();
						if (StringUtils.isEmpty(propertiesJson)) {
							model.put("code", "400");
							model.put("message", "propertiesJson is null/empty in the request");
							model.put("newdocument_noderef", "");
						}
						logger.info("Input parameter propertiesJson value :" + propertiesJson);
						break;

					}

					NodeRef docNodeRef = new NodeRef(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, nodeId);
					Map<QName, Serializable> props = new HashMap<>();
					try {

						JSONObject propValues = new JSONObject(propertiesJson);
						props.put(ContentModel.PROP_TITLE, propValues.getString("title"));
						props.put(ContentModel.PROP_DESCRIPTION, propValues.getString("description"));
						props.put(ContentModel.PROP_NAME, propValues.getString("filename"));
						props.put(ContentModel.PROP_AUTHOR, propValues.getString("author"));

						// setting a map of properties
						serviceRegistry.getNodeService().setProperties(docNodeRef, props);

						behaviourFilter.disableBehaviour(ContentModel.ASPECT_AUDITABLE);
						// setting a single properties
						serviceRegistry.getNodeService().setProperty(docNodeRef, ContentModel.PROP_CREATED,
								formatDate(propValues.getString("createdDate")));
						serviceRegistry.getNodeService().setProperty(docNodeRef, ContentModel.PROP_MODIFIED,
								formatDate(propValues.getString("modifiedDate")));
						serviceRegistry.getNodeService().setProperty(docNodeRef, ContentModel.PROP_CREATOR,
								propValues.getString("creator"));
						serviceRegistry.getNodeService().setProperty(docNodeRef, ContentModel.PROP_MODIFIER,
								propValues.getString("modifier"));
						behaviourFilter.enableBehaviour(ContentModel.ASPECT_AUDITABLE);

						model.put("code", "200");
						model.put("message", "Document Updated");
						model.put("newdocument_noderef", docNodeRef.getId());

					} catch (Exception e) {
						model.put("code", "400");
						model.put("message", "Exception Occured " + e);
						model.put("newdocument_noderef", "");
					}
				}
			}
		}

		catch (Exception e) {
			model.put("code", "");
			model.put("message", e);
			model.put("newdocument_noderef", "");
			logger.error("Error occured while creating node :" + e);
		}
		return model;
	}

	private Date formatDate(String dateStr) throws ParseException {
		DateFormat srcDf = new SimpleDateFormat("dd/MM/yyyy");
		Date date = srcDf.parse(dateStr);
		DateFormat destDf = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.US);
		dateStr = destDf.format(date);
		System.out.println("Converted date is : " + destDf.parse(dateStr));
		return destDf.parse(dateStr);

	}

	public BehaviourFilter getBehaviourFilter() {
		return behaviourFilter;
	}

	public void setBehaviourFilter(BehaviourFilter behaviourFilter) {
		this.behaviourFilter = behaviourFilter;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

}
