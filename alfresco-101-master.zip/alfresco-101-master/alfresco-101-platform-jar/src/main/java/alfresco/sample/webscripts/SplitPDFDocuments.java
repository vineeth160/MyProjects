package alfresco.sample.webscripts;

/**
 * This is a Split Webscript, where it takes nodeID of the PDF file in alfresco as input
 * takes input startpage and endpage values and splits the file from start to end page and 
 * upload the new doc to alfresco
 * 
 **/

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.content.MimetypeMap;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.Splitter;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

public class SplitPDFDocuments extends DeclarativeWebScript {
	private ServiceRegistry serviceRegistry;
	
	private static Log logger = LogFactory.getLog(SplitPDFDocuments.class);
	Map<String, Object> statusObj = new HashMap<String, Object>();

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest request, Status status, Cache cache) {
		Map<String, Object> model = new HashMap<String, Object>(5);
		JSONObject requestJson;
		String nodeid = "";
		String startpage = "";
		String endpage = "";
		
		NodeRef newDocNoderef = null;
		String fileName = "";
		NodeRef noderef = null;
		try {
			if (request != null && !StringUtils.isEmpty(request.getContent().getContent())) {
				requestJson = new JSONObject(request.getContent().getContent());

				if (requestJson.has("nodeid")) {
					nodeid = requestJson.getString("nodeid");
					noderef = new NodeRef(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, nodeid);
					logger.debug("Missing Nodeid in the request json");
				}
				if (requestJson.has("startpage")) {
					startpage = requestJson.getString("startpage");
					logger.debug("Missing startPage in the request json");
				}
				if (requestJson.has("endpage")) {
					endpage = requestJson.getString("endpage");
					logger.debug("Missing endPage in the request json");
				}
				if (requestJson.has("fileName")) {
					fileName = requestJson.getString("fileName");
					logger.debug("Missing fileName in the request json");
				}
				
				if (StringUtils.isEmpty(nodeid) || StringUtils.isEmpty(startpage) || StringUtils.isEmpty(endpage) || StringUtils.isEmpty(fileName) ) {
					model.put("code", "400");
					model.put("message", "Please pass a valid request body");
					model.put("newdocument_noderef", "");
				}	

				
				newDocNoderef = splitPdfs(noderef,startpage,endpage,fileName);
				model.put("code", "200");
				model.put("message", "Split document created successfully.");
				model.put("newdocument_noderef", newDocNoderef.getId());
				return model;
			}

		} catch (Exception e) {
			model.put("code", "400");
			model.put("message", "OAException: " + e);
			model.put("newdocument_noderef", "");
		}
		return model;
	}

	private NodeRef splitPdfs(NodeRef nodeRef, String startPage, String endPage, String fileName) throws FileNotFoundException {
		InputStream originalInputStream = null;
		ContentReader reader = null;
		NodeRef newDocNoderef = null;
		
		try {
			logger.debug("Service call for Splitting of Doc started");
			reader = serviceRegistry.getContentService().getReader(nodeRef, ContentModel.PROP_CONTENT);
			originalInputStream = reader.getContentInputStream();
			ByteArrayOutputStream outputstream = new ByteArrayOutputStream();

			PDDocument document = PDDocument.load(originalInputStream);
			
			Splitter splitter = new Splitter();
			splitter.setStartPage(Integer.parseInt(startPage));
			splitter.setEndPage(Integer.parseInt(endPage));
		    splitter.setSplitAtPage(Integer.parseInt(endPage));
			
		    List<PDDocument> Pages = splitter.split(document);
			Iterator<PDDocument> iterator = Pages.listIterator();
			if (iterator.hasNext()) {
				PDDocument pd = iterator.next();
				pd.save(outputstream);
				newDocNoderef=writeContentToAlfresco(outputstream, nodeRef,fileName);
			}
			
			document.close();
			logger.debug("Document is created at nodeRef "+newDocNoderef);
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		return newDocNoderef; 
	}

	public NodeRef writeContentToAlfresco(ByteArrayOutputStream outputstream, NodeRef childRef, String fileName) throws IOException {
		NodeRef pdf = null;
		try {
			/*
			 * FileOutputStream foutputStream = new FileOutputStream( new
			 * File("C:/Users/SriKanth/Desktop/PDF merger utility/Split.pdf"));
			 * outputstream.writeTo(foutputStream);
			 */
			logger.debug("Upload to Alfresco started");
			NodeRef parentNodeRef = serviceRegistry.getNodeService().getPrimaryParent(childRef).getParentRef();

			FileInfo pdfInfo = serviceRegistry.getFileFolderService().create(parentNodeRef, fileName+".pdf",
					ContentModel.TYPE_CONTENT);
			pdf = pdfInfo.getNodeRef();

			ContentWriter writer = serviceRegistry.getContentService().getWriter(pdf, ContentModel.PROP_CONTENT, true);
			writer.setMimetype(MimetypeMap.MIMETYPE_PDF);
			writer.setEncoding("UTF-8");
			writer.putContent(new ByteArrayInputStream(outputstream.toByteArray()));
			logger.debug("Document Uploaded in Alfresco");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (outputstream != null)
				outputstream.close();
		}
		return pdf;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
}
