package alfresco.sample.schedulers;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import alfresco.sample.schedulers.utils.AbstractUtils;

public class CustomJobScheduler implements Job {

	private ServiceRegistry serviceRegistry;
	private AbstractUtils abstractUtils;

	@Override
	public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {

		final JobExecutionContext jobExecute = jobExecutionContext;
		JobDataMap jobMap = jobExecute.getJobDetail().getJobDataMap();
		String enableJob = (String) jobMap.get("enableJob");

		System.out.println("Condition CustomJobScheduler " + enableJob);
		if (Boolean.valueOf(enableJob)) {
			System.out.println("Running CustomJobScheduler..");
			AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				public Object doWork() throws Exception {
					System.out.println("Values from abstractUtils class " + abstractUtils.getCurrentTime());
					System.out.println("Fire time of CustomJobScheduler is " + jobExecute.getFireTime());
					return null;
				}
			}, AuthenticationUtil.getSystemUserName());
		}

	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public AbstractUtils getAbstractUtils() {
		return abstractUtils;
	}

	public void setAbstractUtils(AbstractUtils abstractUtils) {
		this.abstractUtils = abstractUtils;
	}
}
