package alfresco.sample.schedulers.utils;

import java.util.Calendar;
import java.util.TimeZone;

public class AbstractUtils {

	private String timeZone;

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getCurrentTime() {
		String currentTime = null;
		if(timeZone.equalsIgnoreCase("IST")) {
			Calendar cal = Calendar.getInstance();
			cal.setTimeZone(TimeZone.getTimeZone("IST"));
			currentTime = Calendar.HOUR_OF_DAY +":"+Calendar.MINUTE+":"+Calendar.SECOND+"T"+cal.getTimeZone();
		}
		return currentTime;
	}

}
