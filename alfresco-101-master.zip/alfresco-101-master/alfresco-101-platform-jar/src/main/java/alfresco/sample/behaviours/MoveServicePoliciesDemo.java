package alfresco.sample.behaviours;

import java.util.Properties;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.node.NodeServicePolicies;
import org.alfresco.repo.policy.Behaviour;
import org.alfresco.repo.policy.JavaBehaviour;
import org.alfresco.repo.policy.PolicyComponent;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;

public class MoveServicePoliciesDemo
		implements NodeServicePolicies.OnMoveNodePolicy, NodeServicePolicies.BeforeMoveNodePolicy {
	
	// Dependencies
	private PolicyComponent policyComponent;
	private ServiceRegistry serviceRegistry;
	private Properties properties;

	public void registerEventHandlers() {
		System.out.println("Init method of Behaviour initiated");
		this.policyComponent.bindClassBehaviour(QName.createQName(NamespaceService.ALFRESCO_URI, "beforeMoveNode"),
				ContentModel.TYPE_CONTENT,
				new JavaBehaviour(this, "beforeMoveNode", Behaviour.NotificationFrequency.FIRST_EVENT));

		this.policyComponent.bindClassBehaviour(NodeServicePolicies.OnMoveNodePolicy.QNAME, ContentModel.TYPE_CONTENT,
				new JavaBehaviour(this, "onMoveNode", Behaviour.NotificationFrequency.TRANSACTION_COMMIT));

	}

	@Override
	public void onMoveNode(ChildAssociationRef oldChildAssociationRef, ChildAssociationRef newChildAssociationRef) {
		System.out.println("onMoveNode method of behaviour initiated");
		String docName = this.serviceRegistry.getNodeService()
				.getProperty(oldChildAssociationRef.getChildRef(), ContentModel.PROP_NAME).toString();
		String srcFolderName = this.serviceRegistry.getNodeService()
				.getProperty(oldChildAssociationRef.getParentRef(), ContentModel.PROP_NAME).toString();
		String destFolderName = this.serviceRegistry.getNodeService()
				.getProperty(newChildAssociationRef.getParentRef(), ContentModel.PROP_NAME).toString();
		System.out.println("onMoveNode method of behaviour ended");
		System.out.println("Document " + docName + " is moved from " + srcFolderName + "to" + destFolderName);

	}

	@Override
	public void beforeMoveNode(ChildAssociationRef oldChildAssocRef, NodeRef newParentRef) {
		System.out.println("beforeMoveNode method of behaviour initiated");
		String docName = this.serviceRegistry.getNodeService()
				.getProperty(oldChildAssocRef.getChildRef(), ContentModel.PROP_NAME).toString();
		String srcFolderName = this.serviceRegistry.getNodeService()
				.getProperty(oldChildAssocRef.getParentRef(), ContentModel.PROP_NAME).toString();
		System.out.println("beforeMoveNode method of behaviour ended");
		System.out.println("Document " + docName + " is about to move from " + srcFolderName);

	}

	public PolicyComponent getPolicyComponent() {
		return policyComponent;
	}

	public void setPolicyComponent(PolicyComponent policyComponent) {
		this.policyComponent = policyComponent;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

}
