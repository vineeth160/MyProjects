package alfresco.sample.constraints;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.alfresco.repo.dictionary.constraint.ListOfValuesConstraint;
import org.alfresco.service.cmr.i18n.MessageLookup;
import org.json.JSONException;

public class CustomConstraint extends ListOfValuesConstraint implements Serializable {

	private static final long serialVersionUID = 1L;
	private TreeMap<String, String> constraintsMap;

	private static final String values = "Property Damage Claims,Vehicle Insurance, Health Insurance";

	private List<String> getValues() throws JSONException {

		int count = values.split(",").length;

		if (null == constraintsMap) {
			constraintsMap = new TreeMap<>();
			// for initial values
			constraintsMap.put("Please Select", "");

			for (int i = 0; i < count; i++) {
				String data = values.split(",")[i];
				constraintsMap.put(data, data);
			}
		}

		List<String> allowedValueList = new ArrayList<String>();
		for (Map.Entry<String, String> entry : constraintsMap.entrySet()) {
			allowedValueList.add(entry.getKey());
		}
		return allowedValueList;
	}

	@Override
	public void setAllowedValues(@SuppressWarnings("rawtypes") List allowedValues) {
	}

	@Override
	public void setCaseSensitive(boolean caseSensitive) {
	}

	public void initialize() {

		super.setCaseSensitive(false);
		try {
			this.getAllConstraintListValues();
		} catch (JSONException e) {
			e.printStackTrace();
		}

	}

	public String getDisplayLabel(String constraintAllowableValue, MessageLookup messageLookup) {
		return constraintAllowableValue != null ? constraintsMap.get(constraintAllowableValue) : "Invalid";
	}

	public void getAllConstraintListValues() throws JSONException {
		// Get the final List
		super.setAllowedValues(getValues());
	}

	public TreeMap<String, String> getConstraintsMap() {
		return constraintsMap;
	}

	public void setConstraintsMap(TreeMap<String, String> constraintsMap) {
		this.constraintsMap = constraintsMap;
	}

}
