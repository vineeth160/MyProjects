package alfresco.sample.webscripts;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.security.AuthorityType;
import org.alfresco.service.cmr.workflow.WorkflowTask;
import org.alfresco.service.namespace.QName;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

public class EndWorkflowTask extends DeclarativeWebScript {

	private ServiceRegistry serviceRegistry;

	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {
		Map<String, Object> model = new HashMap<String, Object>(5);

		String taskid = req.getParameter("taskid");

		try {

			boolean isAdmin = serviceRegistry.getAuthorityService().hasAdminAuthority();
			System.out.println("Logged in user is admin " + isAdmin);

			System.out.println("authorities to admin");
			System.out.println(serviceRegistry.getAuthorityService().createAuthority(AuthorityType.ADMIN,
					AuthenticationUtil.getFullyAuthenticatedUser()));

			boolean isAdminafrer = serviceRegistry.getAuthorityService().hasAdminAuthority();
			System.out.println("Logged in user is admin " + isAdminafrer);

			WorkflowTask workflowTask = serviceRegistry.getWorkflowService().getTaskById(taskid);
			Map<QName, Serializable> props = workflowTask.getProperties();

		} catch (Exception e) {
			e.printStackTrace();
		}

		model.put("code", "200");
		model.put("message", "success");

		return model;

	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

}
