package alfresco.sample.schedulers;

import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.service.ServiceRegistry;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.StatefulJob;

import alfresco.sample.schedulers.utils.AbstractUtils;

public class CustomStatefulJobScheduler implements StatefulJob {

	private ServiceRegistry serviceRegistry;
	private AbstractUtils abstractUtils;

	@Override
	public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {

		final JobExecutionContext jobExecute = jobExecutionContext;
		JobDataMap jobMap = jobExecute.getJobDetail().getJobDataMap();
		String enableJob = (String) jobMap.get("enableJob");

		System.out.println("Condition CustomStatefulJobScheduler "+enableJob);
		if (Boolean.valueOf(enableJob)) {
			System.out.println("Running CustomStatefulJobScheduler..");
			AuthenticationUtil.runAs(new AuthenticationUtil.RunAsWork<Object>() {
				public Object doWork() throws Exception {
					System.out.println("Values from abstractUtils class "+abstractUtils.getTimeZone());
					System.out.println("Fire time of CustomStatefulJobScheduler is "+jobExecute.getFireTime());
					return null;
				}
			}, AuthenticationUtil.getSystemUserName());
		}
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public AbstractUtils getAbstractUtils() {
		return abstractUtils;
	}

	public void setAbstractUtils(AbstractUtils abstractUtils) {
		this.abstractUtils = abstractUtils;
	}

}
