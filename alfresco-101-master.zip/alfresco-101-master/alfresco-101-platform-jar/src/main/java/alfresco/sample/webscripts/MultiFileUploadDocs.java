package alfresco.sample.webscripts;

import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.DuplicateChildNodeNameException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.ISO9075;
import org.apache.commons.lang3.StringUtils;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.servlet.FormData;
import org.springframework.extensions.webscripts.servlet.FormData.FormField;

public class MultiFileUploadDocs extends DeclarativeWebScript {

	private ServiceRegistry serviceRegistry;
	
	Map<String, Object> model = new HashMap<String, Object>(5);
	String siteName = null;

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest request, Status status, Cache cache) {

		List<FormField> filesList = new ArrayList<FormField>();
		Map<QName, Serializable> props = new HashMap<>();
		NodeRef docNodeRef = null;
		String folderName = null;

		try {
			if (request.getContentType().equalsIgnoreCase("multipart/form-data")) {
				FormData formData = (FormData) request.parseContent();
				FormData.FormField[] fields = formData.getFields();
				for (FormData.FormField field : fields) {
					switch (field.getName()) {
					case "files":
						if (field.getIsFile()) {
							filesList.add(field);
						} else {
							model.put("code", "400");
							model.put("message", "file is null/empty in the request");
						}
						break;
					case "site":
						if (!StringUtils.isEmpty(field.getName())) {
							siteName = field.getValue();
						} else {
							model.put("code", "400");
							model.put("message", "site is null/empty in the request");
						}
						break;
					case "folderName":
						if (!StringUtils.isEmpty(field.getName())) {
							folderName = field.getValue();
						} else {
							model.put("code", "400");
							model.put("message", "folderName is null/empty in the request");
						}
						break;
					}

				}

				NodeRef descFolderNodeRef = getPathNodeRef(folderName);

				for (FormField field : filesList) {

					props.put(ContentModel.PROP_NAME, field.getFilename());
					docNodeRef = serviceRegistry.getNodeService()
							.createNode(descFolderNodeRef, ContentModel.ASSOC_CONTAINS,
									QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, field.getFilename()),
									ContentModel.TYPE_CONTENT, props)
							.getChildRef();

					boolean successFlag = writeContentStreamToCustomDocument(field.getInputStream(), docNodeRef,
							field.getMimetype());

					if (successFlag) {
						model.put("code", "200");
						model.put("message", "Metadata Updated Successfully");
					} else {
						model.put("code", "400");
						model.put("message", "Metadata Updated is Failed ");
					}
				}
			}

		} catch (DuplicateChildNodeNameException e) {
			model.put("code", "400");
			model.put("message", "DuplicateChildNodeNameException Occured " + e);
		} catch (Exception e) {
			model.put("code", "400");
			model.put("message", e);
		}

		return model;
	}

	private NodeRef getPathNodeRef(String foldername) {

		String alfrescoFolderName = ISO9075.encode(foldername);
		Map<String, Serializable> params = new HashMap<>();
		params.put("query",
				"./app:company_home/st:sites/cm:" + siteName + "/cm:documentLibrary/cm:" + alfrescoFolderName);
		return serviceRegistry.getNodeLocatorService().getNode("xpath", null, params);

	}

	public boolean writeContentStreamToCustomDocument(InputStream contentInputStream, NodeRef docNodeRef,
			String mimeType) {
		boolean successFlag = false;
		try {
			ContentWriter writer = serviceRegistry.getContentService().getWriter(docNodeRef, ContentModel.PROP_CONTENT,
					true);
			writer.setMimetype(mimeType);
			writer.putContent(contentInputStream);
			successFlag = true;
		} catch (Exception e) {
			model.put("code", "400");
			model.put("message", "Exception Occurred " + e);
		}
		return successFlag;
	}
	
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
}
