package alfresco.sample.webscripts;

/**
 *Sample Upload Webscript, where 
 *@author SriKanth
 *@param 
 *site : <siteName> 
 *propertiesJson : <{"title":"SampleDoc","description":"Sample Document to test upload webscript"}>
 *file : <fileInput>
 *
 *This webscript uploads a cm type file with set title and description under Upload/<Todays folder>
 **/

import java.io.InputStream;
import java.io.Serializable;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.ChildAssociationRef;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.DuplicateChildNodeNameException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.alfresco.util.ISO9075;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.servlet.FormData;

public class UploadDocuments extends DeclarativeWebScript {

	private static Log logger = LogFactory.getLog(UploadDocuments.class);
	private ServiceRegistry serviceRegistry;
	private static final String  INITIAL_FOLDER =  "Upload";
	Map<String, Object> model = new HashMap<String, Object>();

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest request, Status status, Cache cache) {

		NodeRef parentFolderNodeRef = null;
		NodeRef reportFolderNodeRef = null;
		
		String site = null;
		String propertiesJson = null;
		String fileName = null;
		String mimetype = null;
		InputStream contentStream = null;
		
		try {
			if (request.getContentType().equalsIgnoreCase("multipart/form-data")) {
				FormData formData = (FormData) request.parseContent();
				FormData.FormField[] fields = formData.getFields();
				for (FormData.FormField field : fields) {
					switch (field.getName()) {
					case "site":
						site = field.getValue();
						if (StringUtils.isEmpty(site)) {
							model.put("code", "400");
							model.put("message", "site is null/empty in the request");
							model.put("newdocument_noderef", "");
						}
						logger.info("Input parameter Site value :" + site);
						break;
					case "propertiesJson":
						propertiesJson = field.getValue();
						if (StringUtils.isEmpty(propertiesJson)) {
							model.put("code", "400");
							model.put("message", "propertiesJson is null/empty in the request");
							model.put("newdocument_noderef", "");
						}
						logger.info("Input parameter propertiesJson value :" + propertiesJson);
						break;
					case "file":
						if (field.getIsFile()) {
							fileName = field.getFilename();
							mimetype = field.getMimetype();
							contentStream = field.getInputStream();
						} else {
							model.put("code", "400");
							model.put("message", "file is null/empty in the request");
							model.put("newdocument_noderef", "");
						}
						break;
					}
				}

				Calendar now = Calendar.getInstance();
				String folderName = String
						.valueOf(now.get(Calendar.YEAR) + "-" + now.get(Calendar.MONTH) + "-" + now.get(Calendar.DATE));

				parentFolderNodeRef = getPathNodeRef(INITIAL_FOLDER,site);
				reportFolderNodeRef = getFinalFolderNodeRef(parentFolderNodeRef, folderName);

				NodeRef docNodeRef = null;
				Map<QName, Serializable> props = new HashMap<>();
				JSONObject propValues = new JSONObject(propertiesJson);
				props.put(ContentModel.PROP_TITLE, propValues.getString("title"));
				props.put(ContentModel.PROP_DESCRIPTION, propValues.getString("description"));
				props.put(ContentModel.PROP_NAME, fileName);

				try {

					docNodeRef = serviceRegistry.getNodeService()
							.createNode(reportFolderNodeRef, ContentModel.ASSOC_CONTAINS,
									QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, fileName),
									ContentModel.TYPE_CONTENT, props)
							.getChildRef();

					writeContentStreamToCustomDocument(contentStream, docNodeRef, mimetype);

					model.put("code", "200");
					model.put("message", "Document Uploaded");
					model.put("newdocument_noderef", docNodeRef.getId());

				} catch (DuplicateChildNodeNameException e) {
					model.put("code", "400");
					model.put("message", "Exception Occured "+e);
					model.put("newdocument_noderef", "");
				}
			}

		} catch (Exception e) {
			model.put("code", "");
			model.put("message", e);
			model.put("newdocument_noderef", "");
			logger.error("Error occured while creating node :" + e);
		}
		return model;
	}

	public void writeContentStreamToCustomDocument(InputStream contentInputStream, NodeRef docNodeRef,
			String mimeType) {
		try {
			ContentWriter writer = this.serviceRegistry.getContentService().getWriter(docNodeRef,
					ContentModel.PROP_CONTENT, true);
			writer.setMimetype(mimeType);
			writer.putContent(contentInputStream);
		} catch (Exception e) {
			model.put("code", "400");
			model.put("message", "Exception Occurred "+e);
			model.put("newdocument_noderef", "");
			logger.error("Error occured while creating node :" + e);
		}
	}

	public NodeRef getFinalFolderNodeRef(NodeRef nodeRef, String folderName) {
		NodeRef requiredNodeRef = null;
		FileInfo fileInfo = null;

		List<ChildAssociationRef> docLibChilds = serviceRegistry.getNodeService().getChildAssocs(nodeRef);
		for (ChildAssociationRef docLibChild : docLibChilds) {
			NodeRef childNodeRef = docLibChild.getChildRef();
			if (((String) serviceRegistry.getNodeService().getProperty(childNodeRef, ContentModel.PROP_NAME))
					.equals(folderName)) {
				requiredNodeRef = childNodeRef;
			}
		}
		if (requiredNodeRef == null) {
			fileInfo = serviceRegistry.getFileFolderService().create(nodeRef, folderName, ContentModel.TYPE_FOLDER);
			requiredNodeRef = fileInfo.getNodeRef();
		}
		return requiredNodeRef;
	}

	public NodeRef getPathNodeRef(String path, String site) {
		NodeRef parentFolderNodeRef = null;
		
		String parentXpath = "PATH:\"/app:company_home/st:sites/cm:"+site+"/cm:documentLibrary/";
		String xpath = getXpathByPath(path);
		String finalXpath = parentXpath + xpath + "\"";

		ResultSet rs = getNodeRefList(serviceRegistry, StoreRef.STORE_REF_WORKSPACE_SPACESSTORE,
				SearchService.LANGUAGE_LUCENE, finalXpath);
		try {
			if (rs.length() == 0) {
				parentFolderNodeRef = null;
			} else {
				parentFolderNodeRef = rs.getNodeRef(0);
			}
		} finally {
			rs.close();
		}
		return parentFolderNodeRef;
	}

	public static ResultSet getNodeRefList(ServiceRegistry serviceRegistry, StoreRef storeRef, String language,
			String path) {
		ResultSet rs = null;
		try {
			rs = serviceRegistry.getSearchService().query(storeRef, language, path);
		} catch (Exception e) {
			System.out.println("Error occured while getting result:" + e);
		}
		return rs;
	}

	public static String getXpathByPath(String path) {
		String[] parts = null;
		parts = path.split("/");
		for (int i = 0; i < parts.length; i++) {
			path = path.replace(parts[i], "cm:" + ISO9075.encode(parts[i]));
		}
		return path;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
}