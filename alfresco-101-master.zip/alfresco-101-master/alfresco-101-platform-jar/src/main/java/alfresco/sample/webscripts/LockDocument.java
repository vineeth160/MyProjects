package alfresco.sample.webscripts;

/**
 * http://localhost:8080/alfresco/s/api/custom/lockDocument?noderef=<nodeId>&action=<lock/unlock/check>&alf_ticket= 
 * This webscript locks / unlocks / and checks who is the lock owner
 **/


import java.util.HashMap;
import java.util.Map;

import org.alfresco.repo.lock.mem.LockState;
import org.alfresco.repo.transaction.RetryingTransactionHelper;
import org.alfresco.service.cmr.lock.LockService;
import org.alfresco.service.cmr.lock.LockType;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

public class LockDocument extends DeclarativeWebScript {

	private NodeService nodeService;
	private LockService lockService;
	private RetryingTransactionHelper retryingTransactionHelper;

	private static final Logger LOGGER = Logger.getLogger(LockDocument.class);

	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {
		Map<String, Object> model = new HashMap<String, Object>(5);
		try {
			String nodeId = req.getParameter("noderef") != null ? req.getParameter("noderef").toString() : "";
			String action = req.getParameter("action") != null ? req.getParameter("action").toString() : "";

			if (StringUtils.isEmpty(nodeId) || StringUtils.isEmpty(action)) {
				model.put("code", "400");
				model.put("message", "Please provide mandatory parameters!");
				model.put("locked", "");
				model.put("lockowner", "");
				return model;
			}

			final NodeRef node = new NodeRef(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, nodeId);
			if (nodeService.exists(node) == false) {
				model.put("code", Status.STATUS_BAD_REQUEST);
				model.put("message", "Please pass the noderef of existing document");
				model.put("locked", "");
				model.put("lockowner", "");
				return model;
			}

			if (action.equalsIgnoreCase("lock")) {
				
				NodeRef lockedNode = retryingTransactionHelper
						.doInTransaction(new RetryingTransactionHelper.RetryingTransactionCallback<NodeRef>() {
							public NodeRef execute() throws Throwable {
								lockService.lock(node, LockType.WRITE_LOCK);
								return node;
							}
						});
				model.put("code", "200");
				model.put("message", "Document locked successfully");
				
				boolean lockStatus = lockService.isLocked(node);
				LockState ls = lockService.getLockState(node);
				model.put("locked", String.valueOf(lockStatus));
				model.put("lockowner", (ls != null && ls.getOwner() != null) ? ls.getOwner().toString() : "");
			
			} else if (action.equalsIgnoreCase("unlock")) {
				NodeRef unlockedNode = retryingTransactionHelper
						.doInTransaction(new RetryingTransactionHelper.RetryingTransactionCallback<NodeRef>() {
							public NodeRef execute() throws Throwable {
								lockService.unlock(node);
								return node;
							}
						});

				model.put("code", "200");
				model.put("message", "Document unlocked successfully");
				
				boolean lockStatus = lockService.isLocked(node);
				model.put("locked", String.valueOf(lockStatus));
				model.put("lockowner", "");
				
			} else { // assuming the action passed will be 'check'
				boolean lockStatus = lockService.isLocked(node);
				LockState ls = lockService.getLockState(node);
				model.put("code", "200");
				model.put("message", "Document lock status fetched successfully");
				model.put("locked", String.valueOf(lockStatus));
				model.put("lockowner", (ls != null && ls.getOwner() != null) ? ls.getOwner().toString() : "");
			}

			return model;

		} catch (Exception e) {
			LOGGER.debug("execption occured: " + e);
			e.printStackTrace();
			model.put("code", "400");
			model.put("message", "Exception occured.");
			model.put("locked", "");
			model.put("lockowner", "");
			status.setCode(500);
			return model;
		}

	}

	public NodeService getNodeService() {
		return nodeService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	public LockService getLockService() {
		return lockService;
	}

	public void setLockService(LockService lockService) {
		this.lockService = lockService;
	}

	public RetryingTransactionHelper getRetryingTransactionHelper() {
		return retryingTransactionHelper;
	}

	public void setRetryingTransactionHelper(RetryingTransactionHelper retryingTransactionHelper) {
		this.retryingTransactionHelper = retryingTransactionHelper;
	}

}