package alfresco.sample.webscripts;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.model.FileInfo;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.util.ISO9075;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.servlet.FormData;

public class CopyMoveDocuments extends DeclarativeWebScript {

	private ServiceRegistry serviceRegistry;

	private static final Log logger = LogFactory.getLog(CopyMoveDocuments.class);

	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {

		Map<String, Object> model = new HashMap<String, Object>(5);
		String site = null;
		String destination = null;
		String action = null;
		String nodeId = null;

		try {
			if (req.getContentType().equalsIgnoreCase("multipart/form-data")) {
				FormData formData = (FormData) req.parseContent();
				FormData.FormField[] fields = formData.getFields();
				for (FormData.FormField field : fields) {
					switch (field.getName()) {
					case "site":
						site = field.getValue();
						if (StringUtils.isEmpty(site)) {
							model.put("code", "400");
							model.put("message", "site is null/empty in the request");
							model.put("link_nodeRef", "");
						}
						logger.info("Input parameter Site value :" + site);
						break;
					case "destinationFolderName":
						destination = field.getValue();
						if (StringUtils.isEmpty(destination)) {
							model.put("code", "400");
							model.put("message", "destinationFolderName is null/empty in the request");
							model.put("link_nodeRef", "");
						}
						logger.info("Input parameter propertiesJson value :" + destination);
						break;
					case "action":
						action = field.getValue();
						if (StringUtils.isEmpty(action)) {
							model.put("code", "400");
							model.put("message", "action is null/empty in the request");
							model.put("link_nodeRef", "");
						}
						logger.info("Input parameter propertiesJson value :" + action);
						break;

					case "nodeId":
						nodeId = field.getValue();
						if (StringUtils.isEmpty(nodeId)) {
							model.put("code", "400");
							model.put("message", "nodeId is null/empty in the request");
							model.put("link_nodeRef", "");
						}
						logger.info("Input parameter propertiesJson value :" + nodeId);
						break;
					}
				}

				NodeRef node = new NodeRef(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, nodeId);
				if (serviceRegistry.getNodeService().exists(node) == false) {
					model.put("code", Status.STATUS_BAD_REQUEST);
					model.put("message", "Please pass the noderef of existing document");
					model.put("link_nodeRef", "");
					return model;
				}

				if (action.equalsIgnoreCase("copy")) {

					String fileName = (String) serviceRegistry.getNodeService().getProperty(node,
							ContentModel.PROP_NAME);
					NodeRef destFolder = getDestinationFolderNodeRefFromName(destination, site);
					FileInfo movedFile = serviceRegistry.getFileFolderService().copy(node, destFolder, fileName);

					model.put("code", "200");
					model.put("message", "Document locked successfully");
					model.put("link_nodeRef", movedFile.getNodeRef().toString());

				} else if (action.equalsIgnoreCase("move")) {

					String fileName = (String) serviceRegistry.getNodeService().getProperty(node,
							ContentModel.PROP_NAME);
					NodeRef destFolder = getDestinationFolderNodeRefFromName(destination, site);
					FileInfo movedFile = serviceRegistry.getFileFolderService().move(node, destFolder, fileName);

					model.put("code", "200");
					model.put("message", "Document locked successfully");
					model.put("link_nodeRef", movedFile.getNodeRef().toString());

				}
			}
		} catch (Exception e) {
			logger.debug("execption occured: " + e);
			e.printStackTrace();
			model.put("code", "400");
			model.put("message", "Exception occured.");
			model.put("link_nodeRef", "");
			status.setCode(500);
		}
		return model;
	}

	public NodeRef getDestinationFolderNodeRefFromName(String folderName, String site) {
		String alfrescoFolderName = ISO9075.encode(folderName);
		Map<String, Serializable> params = new HashMap<>();
		params.put("query", "./app:company_home/st:sites/cm:" + site + "/cm:documentLibrary/cm:" + alfrescoFolderName);
		return serviceRegistry.getNodeLocatorService().getNode("xpath", null, params);
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
}
