package alfresco.sample.webscripts;

/**
 * This is a Download Webscript, where it takes nodeId in headers and downloads the content
 * 
 **/

import java.io.ByteArrayOutputStream;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ApplicationModel;
import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentData;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.namespace.QName;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

public class DownloadWebscript extends DeclarativeWebScript {
	private ServiceRegistry serviceRegistry;

	private static Log logger = LogFactory.getLog(DownloadWebscript.class);
	Map<String, Object> model = new HashMap<String, Object>();

	protected Map<String, Object> executeImpl(WebScriptRequest request, Status status, Cache cache) {
		String nodeid = request.getParameter("nodeid");
		try {
			logger.debug("Docuemnt Download service started");
			if (nodeid == null) {
				status.setCode(400);
				model.put("code", "400");
				model.put("message", "NodeID is null");
				model.put("stream", "");
			}
			NodeRef documentNodeRef = new NodeRef(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, nodeid);
			if (null != documentNodeRef && serviceRegistry.getNodeService().exists(documentNodeRef)) {
				documentNodeRef = getContentNodeRef(documentNodeRef);
				byte[] base64EncodedData = getEncodedDataForNodeId(documentNodeRef, status);
				// String originalMimeType = getMimeTypeFromDocNode(documentNodeRef);
				status.setCode(200);
				model.put("code", "200");
				model.put("message", "Document downloaded Successfully");
				model.put("stream", new String(base64EncodedData));
			} else {
				status.setCode(400);
				model.put("code", "400");
				model.put("message", "NodeID is Invalid");
				model.put("stream", "");
			}

		} catch (Exception e) {
			status.setCode(400);
			model.put("code", "400");
			model.put("message", "Exception " + e);
			model.put("stream", "");
		}
		return model;
	}

	private NodeRef getContentNodeRef(NodeRef linkNodeRef) {
		QName contentTypeQname = serviceRegistry.getNodeService().getType(linkNodeRef);
		if (contentTypeQname.equals(ApplicationModel.TYPE_FILELINK)) {
			return (NodeRef) serviceRegistry.getNodeService().getProperty(linkNodeRef,
					ContentModel.PROP_LINK_DESTINATION);
		}
		return linkNodeRef;
	}

	public byte[] getEncodedDataForNodeId(NodeRef documentNodeRef, Status status) {
		byte[] base64EncodedData = null;
		InputStream originalInputStream = null;
		ContentReader reader = null;

		if (null != documentNodeRef) {
			try {
				reader = serviceRegistry.getContentService().getReader(documentNodeRef, ContentModel.PROP_CONTENT);
				originalInputStream = reader.getContentInputStream();
				ByteArrayOutputStream outputstream = new ByteArrayOutputStream();
				final int BUF_SIZE = 1 << 8; // 1KiB buffer
				byte[] buffer = new byte[BUF_SIZE];
				int bytesRead = -1;
				while ((bytesRead = originalInputStream.read(buffer)) > -1) {
					outputstream.write(buffer, 0, bytesRead);
				}
				originalInputStream.close();
				byte[] c = outputstream.toByteArray();
				boolean isChunked = true;
				base64EncodedData = Base64.encodeBase64(c, isChunked);
			} catch (Exception e) {
				status.setCode(400);
				model.put("code", "400");
				model.put("message", "Exception " + e);
				model.put("stream", "");
			}
		}
		return base64EncodedData;

	}

	public String getMimeTypeFromDocNode(NodeRef docNode) {
		String originalMimeType = null;
		ContentData contentData = (ContentData) serviceRegistry.getNodeService().getProperty(docNode,
				ContentModel.PROP_CONTENT);
		originalMimeType = contentData.getMimetype();
		return originalMimeType;
	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

}
