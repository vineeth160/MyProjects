package alfresco.sample.actions;

import java.util.ArrayList;
import java.util.List;

import org.alfresco.repo.action.ParameterDefinitionImpl;
import org.alfresco.repo.action.executer.ActionExecuterAbstractBase;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.action.Action;
import org.alfresco.service.cmr.action.ParameterDefinition;
import org.alfresco.service.cmr.dictionary.DataTypeDefinition;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CustomDocTaggingAction extends ActionExecuterAbstractBase {

	private static Log logger = LogFactory.getLog(CustomDocTaggingAction.class);

	public static final String PARAM_TAG_NAME = "tag_name";

	private ServiceRegistry serviceRegistry;

	@Override
	protected void addParameterDefinitions(List<ParameterDefinition> paramList) {
		for (String s : new String[] { PARAM_TAG_NAME }) {
			paramList.add(new ParameterDefinitionImpl(s, DataTypeDefinition.TEXT, true, getParamDisplayLabel(s)));
		}
	}

	@Override
	protected void executeImpl(Action action, NodeRef actionedUponNodeRef) {

		logger.info("Add Tag Action Initiated");

		String tagName = (String) action.getParameterValue(PARAM_TAG_NAME);

		System.out.println("tagName :: " + tagName);
		List<String> tags = new ArrayList<String>();

		for (String tag : tagName.split(",")) {
			tags.add(tag);
		}
		serviceRegistry.getTaggingService().addTags(actionedUponNodeRef, tags);

	}

	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}
}
