package alfresco.sample.webscripts;

import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.content.MimetypeMap;
import org.alfresco.repo.content.transform.ContentTransformer;
import org.alfresco.service.cmr.model.FileExistsException;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.google.common.io.Files;

public class ContentTransform extends DeclarativeWebScript{

	@Autowired
	private ContentService contentService;
	@Autowired
	private NodeService nodeService;

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {
		Map<String, Object> model = new HashMap<String, Object>(5);
		try {
			String doc = req.getParameter("docNodeRef") != null
					? req.getParameter("docNodeRef").toString()
					: "";
					
					if (StringUtils.isEmpty(doc)) {
						model.put("code", "400");
						model.put("message", "Please provide mandatory parameters!");
						model.put("newdocument_noderef", "");
						return model;
					}
					NodeRef node = new NodeRef(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE,doc);
					if (!nodeService.exists(node)) {
						model.put("code", Status.STATUS_BAD_REQUEST);
						model.put("message", "Please pass the noderef of existing file");
						model.put("newdocument_noderef", "");
						return model;
					}
					
					System.out.println("Converting doc to PDF through rendition");
			        String mimeType = contentService.getReader(node, ContentModel.PROP_CONTENT).getMimetype().trim();
			        System.out.println("mimeType="+mimeType);
			        if(mimeType.equalsIgnoreCase("application/pdf")) {
			        	 model.put("code", "200");
						 model.put("message", "Document already a PDF.");
						 model.put("newdocument_noderef", node.getId()); 
						 return model;
			        }
			        ContentReader docReader = contentService.getReader(node, ContentModel.PROP_CONTENT);
			        System.out.println("docReader: " + docReader);
			        
			        //Get the name of word document so that we can set it on the pdf document.
			        String pdfName = nodeService.getProperty(node, ContentModel.PROP_NAME).toString();
			        
			        String fileExtension = Files.getFileExtension(pdfName);
			        
			        pdfName = pdfName.replace(fileExtension, "pdf");
			        
			        String targetMimetype = "application/pdf";
			        // get the writer and set it up
			        ContentWriter writer = contentService.getWriter(node, ContentModel.PROP_CONTENT, true);
			        writer.setMimetype(targetMimetype); // new mimetype
			        writer.setEncoding(docReader.getEncoding()); // original encoding
			        nodeService.setProperty(node,ContentModel.PROP_NAME,pdfName);
			  
			        // Try and transform the content using the supplied delegate
			        ContentTransformer pdfTransformer = contentService.getTransformer(mimeType, MimetypeMap.MIMETYPE_PDF);
			        System.out.println("pdfTransformer="+pdfTransformer);
			        System.out.println("writer="+writer);
			        pdfTransformer.transform(docReader, writer);
			        
			        model.put("code", "200");
					model.put("message", "PDF conversion successful.");
					model.put("newdocument_noderef", node.getId());     
			
		}catch(FileExistsException fee) {
			ExceptionUtils.printRootCauseStackTrace(fee);
			model.put("code", "400");
			model.put("message", "File already exists: " + fee);
			model.put("newdocument_noderef", "");
		}
		catch(Exception e) {
			model.put("code", "400");
			model.put("message", "Exception occured.");
			model.put("newdocument_noderef", "");
			return model;
		}
		return model;
	}
}
