package alfresco.sample.webscripts;

/**
 *Sample Update Webscript, where 
 *@author SriKanth
 *@param 
 *nodeid : <nodeid> 
 *propertiesJson : <{"title":"SampleDoc","description":"Sample Document to test update webscript","fileName":"New Update.pdf"}>
 *versionInfo : nochange/minor/major
 *file : <fileInput>
 *
 *This webscript uploads a cm type file with set title and description under Upload/<Todays folder>
 **/

import java.io.InputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.repo.policy.BehaviourFilter;
import org.alfresco.repo.version.VersionModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentData;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.version.Version;
import org.alfresco.service.cmr.version.VersionType;
import org.alfresco.service.namespace.QName;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.servlet.FormData;

public class UpdateDocument extends DeclarativeWebScript {

	private static Log logger = LogFactory.getLog(UploadDocuments.class);
	
	private ServiceRegistry serviceRegistry;
	private BehaviourFilter behaviourFilter;

	Map<String, Object> model = new HashMap<String, Object>();
	

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest request, Status status, Cache cache) {

		String nodeid = null;
		String propertiesJson = null;
		String fileName = null;
		String versionInfo = null;
		
		String mimetype = null;
		InputStream contentStream = null;

		try {
			if (request.getContentType().equalsIgnoreCase("multipart/form-data")) {
				FormData formData = (FormData) request.parseContent();
				FormData.FormField[] fields = formData.getFields();
				for (FormData.FormField field : fields) {
					switch (field.getName()) {
					case "nodeid":
						nodeid = field.getValue();
						logger.info("Input parameter nodeid value :" + nodeid);
						if (StringUtils.isEmpty(nodeid)) {
							model.put("code", "400");
							model.put("message", "nodeid is null/not valid in the request");
							model.put("version", "");
						}
						break;
					case "versionInfo":
						versionInfo = field.getValue();
						logger.info("Input parameter versionInfo value :" + versionInfo);
						if (!(versionInfo.equalsIgnoreCase("major") || versionInfo.equalsIgnoreCase("minor")
								|| versionInfo.equalsIgnoreCase("nochange"))) {
							model.put("code", "400");
							model.put("message", "versionInfo is null/not valid in the request");
							model.put("version", "");
						}
						break;
					case "propertiesJson":
						propertiesJson = field.getValue();
						if (StringUtils.isEmpty(propertiesJson)) {
							model.put("code", "400");
							model.put("message", "propertiesJson is null/empty in the request");
							model.put("version", "");
						}
						logger.info("Input parameter propertiesJson value :" + propertiesJson);
						break;
					case "file":
						if (field.getIsFile()) {
							fileName = field.getFilename();
							mimetype = field.getMimetype();
							contentStream = field.getInputStream();
						}
						break;
					}
				}

				NodeRef docNodeRef = new NodeRef(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, nodeid);
				if (!serviceRegistry.getNodeService().exists(docNodeRef)) {
					model.put("code", "400");
					model.put("message", "Please Provide Valid NodeID");
					model.put("version", "");
				}
				if (mimetype == null) {
					ContentData contentData = (ContentData) serviceRegistry.getNodeService().getProperty(docNodeRef,
							ContentModel.PROP_CONTENT);
					mimetype = contentData.getMimetype();
				}
				if (contentStream == null) {
					contentStream = (InputStream) serviceRegistry.getContentService().getReader(docNodeRef,
							ContentModel.PROP_CONTENT);
				}
				Map<QName, Serializable> props = new HashMap<>();
				JSONObject propValues = new JSONObject(propertiesJson);
				props.put(ContentModel.PROP_TITLE, propValues.getString("title"));
				props.put(ContentModel.PROP_DESCRIPTION, propValues.getString("description"));
				if (propValues.getString("fileName") != null) {
					props.put(ContentModel.PROP_NAME, propValues.getString("fileName"));
				} else {
					props.put(ContentModel.PROP_NAME, fileName);
				}

				Version currentVersion = updateCustomDocument(contentStream, docNodeRef, mimetype, props, fileName,versionInfo);

				model.put("code", "200");
				model.put("message", "Document Updated Successfully");
				model.put("version", currentVersion.getVersionLabel().toString());

			}
		} catch (Exception e) {
			model.put("code", "");
			model.put("message", e);
			model.put("version", "");
			logger.error("Error occured while creating node :" + e);
		}
		return model;
	}

	private Version updateCustomDocument(InputStream contentStream, NodeRef docNodeRef, String mimetype,
			Map<QName, Serializable> props, String fileName, String versionInfo) {
		
		Version currentVersion = serviceRegistry.getVersionService().getCurrentVersion(docNodeRef);
		
		try {
			Map<String, Serializable> versionProperties = new HashMap<String, Serializable>();
			if (versionInfo.equalsIgnoreCase("major")) {
				writeContentVersion(props, fileName, docNodeRef, contentStream, mimetype);
				updateWithMajorVersion(versionProperties);
				serviceRegistry.getVersionService().createVersion(docNodeRef, versionProperties);
				currentVersion = serviceRegistry.getVersionService().getCurrentVersion(docNodeRef);

			} else if (versionInfo.equalsIgnoreCase("minor")) {

				writeContentVersion(props, fileName, docNodeRef, contentStream, mimetype);
				updateWithMinorVersion(versionProperties);
				serviceRegistry.getVersionService().createVersion(docNodeRef, versionProperties);
				currentVersion = serviceRegistry.getVersionService().getCurrentVersion(docNodeRef);

			} else if (versionInfo.equalsIgnoreCase("nochange")) {

				updateDocumentWithNoVersionChange(docNodeRef, fileName, props, mimetype, contentStream, versionInfo);

			}

		} catch (Exception e) {
			logger.error("error occurred while updating document :" + e);
		}
		return currentVersion;
	}

	private Map<String, Serializable> updateWithMajorVersion(Map<String, Serializable> versionProperties) {
		versionProperties.put(VersionModel.PROP_VERSION_TYPE, VersionType.MAJOR);
		return versionProperties;

	}

	private Map<String, Serializable> updateWithMinorVersion(Map<String, Serializable> versionProperties) {
		versionProperties.put(VersionModel.PROP_VERSION_TYPE, VersionType.MINOR);
		return versionProperties;

	}

	// If don't want to update any version, we need to enable versionable aspect on nodeRef
	public void updateDocumentWithNoVersionChange(NodeRef documentNodeRef, String fileName,
			Map<QName, Serializable> propValues, String mimeType, InputStream contentInputStream, String versionInfo) {
		try {
			behaviourFilter.disableBehaviour(documentNodeRef, ContentModel.ASPECT_VERSIONABLE);
			if (contentInputStream != null) {
				ContentWriter writer = this.serviceRegistry.getContentService().getWriter(documentNodeRef,
						ContentModel.PROP_CONTENT, true);
				writer.setMimetype(mimeType);
				writer.putContent(contentInputStream);
			}
			if (propValues != null) {
				serviceRegistry.getNodeService().addProperties(documentNodeRef, propValues);
			}
		} finally {
			behaviourFilter.enableBehaviour(documentNodeRef, ContentModel.ASPECT_VERSIONABLE);
		}

	}

	public void writeContentVersion(Map<QName, Serializable> props2, String fileName, NodeRef documentNodeRef,
			InputStream contentInputStream, String mimeType) {

		if (contentInputStream != null) {

			ContentWriter writer = this.serviceRegistry.getContentService().getWriter(documentNodeRef,
					ContentModel.PROP_CONTENT, true);
			writer.setMimetype(mimeType);
			writer.putContent(contentInputStream);
		}

		if (props2 != null) {
			serviceRegistry.getNodeService().addProperties(documentNodeRef, props2);
		}
	}
	
	public ServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	public void setServiceRegistry(ServiceRegistry serviceRegistry) {
		this.serviceRegistry = serviceRegistry;
	}

	public BehaviourFilter getBehaviourFilter() {
		return behaviourFilter;
	}

	public void setBehaviourFilter(BehaviourFilter behaviourFilter) {
		this.behaviourFilter = behaviourFilter;
	}

}
