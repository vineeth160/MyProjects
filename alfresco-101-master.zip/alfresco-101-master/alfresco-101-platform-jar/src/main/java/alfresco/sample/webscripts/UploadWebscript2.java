package com.vcm.alfresco.webscripts;

import java.io.InputStream;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.alfresco.model.ContentModel;
import org.alfresco.service.ServiceRegistry;
import org.alfresco.service.cmr.repository.ContentWriter;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.namespace.NamespaceException;
import org.alfresco.service.namespace.NamespaceService;
import org.alfresco.service.namespace.QName;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.extensions.webscripts.servlet.FormData;


public class UploadWebscript2 extends DeclarativeWebScript {

	private static Log logger = LogFactory.getLog(UploadWebscript2.class);
	private Map<String, Object> model = new HashMap<String, Object>(5);
	
	//public static final QName PROP_VCM_USAA_MEMBERID = QName.createQName(VCM_NAMESPACE_URI, "usaamemberid");
	
	/*public static final QName[] vcmModelProps = { VCMModel.PROP_VCM_USAA_MEMBERID, VCMModel.PROP_VCM_USAA_RECEIVED_DATE,
			VCMModel.PROP_VCM_USAA_DOC_CATEGORY, VCMModel.PROP_VCM_USAA_DCTM_ID, VCMModel.PROP_VCM_ENTITY,
			VCMModel.PROP_VCM_ID, VCMModel.PROP_VCM_ACCOUNT_NUMBER, VCMModel.PROP_VCM_VIEWABLE,
			VCMModel.PROP_VCM_RETURNABLE, VCMModel.PROP_VCM_FORM_CODE, VCMModel.PROP_VCM_DOCUMENT_CATEGORY,
			VCMModel.PROP_VCM_DOCUMENT_CATEGORY_TYPE, VCMModel.PROP_VCM_EXPIRATION_DATE,
			VCMModel.PROP_VCM_DESTINATION_DETAILS, VCMModel.PROP_VCM_SIGNEDDATE, VCMModel.PROP_VCM_CATALOGUE_TEMPLATE,
			VCMModel.PROP_VCM_ESIGNREQUIRED };*/

	@Autowired
	private ServiceRegistry serviceRegistry;

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest request, Status status, Cache cache) {

		String propertiesJson = null;
		String fileName = null;
		String mimetype = null;
		InputStream contentStream = null;

		try {
			if (request.getContentType().equalsIgnoreCase("multipart/form-data")) {
				FormData formData = (FormData) request.parseContent();
				FormData.FormField[] fields = formData.getFields();

				for (FormData.FormField field : fields) {
					switch (field.getName()) {
					case "propertiesJson":
						propertiesJson = field.getValue();
						if (StringUtils.isEmpty(propertiesJson)) {
							model.put("code", "400");
							model.put("message", "propertiesJson is null/empty in the request");
							model.put("data", "");
						}
						logger.info("Input parameter propertiesJson value :" + propertiesJson);
						break;
					case "file":
						if (field.getIsFile()) {
							fileName = field.getFilename();
							mimetype = field.getMimetype();
							contentStream = field.getInputStream();
						} else {
							model.put("code", "400");
							model.put("message", "file is null/empty in the request");
							model.put("data", "");
						}
						break;
					}
				}

				NodeRef descFolderNodeRef = getPathNodeRef();
				NodeRef docNodeRef = null;

				Map<QName, Serializable> props = new HashMap<>();
				JSONObject propValues = new JSONObject(propertiesJson);
				props = getPropertiesMap(propValues);
				props.put(ContentModel.PROP_NAME, fileName);

				Map<String, String> dataMap = new HashMap<>();
					docNodeRef = serviceRegistry.getNodeService()
							.createNode(descFolderNodeRef, ContentModel.ASSOC_CONTAINS,
									QName.createQName(NamespaceService.CONTENT_MODEL_1_0_URI, fileName),
									"", props)
							.getChildRef();
					
				writeContentStreamToCustomDocument(contentStream, docNodeRef, mimetype);

				dataMap.put("nodeId", docNodeRef.getId());
				dataMap.put("fileName",serviceRegistry.getNodeService().getProperty(docNodeRef, ContentModel.PROP_NAME).toString());
				//dataMap.put("title",serviceRegistry.getNodeService().getProperty(docNodeRef, ContentModel.PROP_TITLE).toString());
				//dataMap.put("description", serviceRegistry.getNodeService().getProperty(docNodeRef, ContentModel.PROP_DESCRIPTION).toString());
				dataMap.put("createdDate", serviceRegistry.getNodeService().getProperty(docNodeRef, ContentModel.PROP_CREATED).toString());
				dataMap.put("creator", serviceRegistry.getNodeService().getProperty(docNodeRef, ContentModel.PROP_CREATOR).toString());
				dataMap.put("contentType", mimetype);
				
				/*QName[] vcmModelProps = CommonConstants.vcmModelProps;
				for (QName vcmModelProp : vcmModelProps) {
					String vcmModelPropValues = null;
					if(serviceRegistry.getNodeService().getProperty(docNodeRef, vcmModelProp) != null) {
						vcmModelPropValues = serviceRegistry.getNodeService().getProperty(docNodeRef, vcmModelProp).toString();
					}else {
						vcmModelPropValues = "";
					}
					
					System.out.println(vcmModelProp.getLocalName() +" :: "+vcmModelPropValues);
					dataMap.put(vcmModelProp.getLocalName(), vcmModelPropValues);
				}*/

				model.put("code", "200");
				model.put("message", "Document Uploaded");
				model.put("data", dataMap);
			}

		} catch (Exception e) {
			model.put("code", "");
			model.put("message", e);
			model.put("newdocument_noderef", "");
			logger.error("Error occured while creating node :" + e);
		}
		return model;
	}

	private NodeRef getPathNodeRef() {
		Map<String, Serializable> params = new HashMap<>();
		params.put("query", "FolderXPath");
		return serviceRegistry.getNodeLocatorService().getNode("xpath", null, params);
	}

	public void writeContentStreamToCustomDocument(InputStream contentInputStream, NodeRef docNodeRef,
			String mimeType) {
		try {
			System.out.println(docNodeRef);
			ContentWriter writer = serviceRegistry.getContentService().getWriter(docNodeRef, ContentModel.PROP_CONTENT,
					true);
			System.out.println(writer);
			writer.setMimetype(mimeType);
			writer.putContent(contentInputStream);
			System.out.println(writer);
		} catch (Exception e) {
			model.put("code", "400");
			model.put("message", "Exception Occurred " + e);
			model.put("data", "");
			logger.error("Error occured while creating node :" + e);
		}
	}
	
	public Map<QName, Serializable> getPropertiesMap(JSONObject propValues) {
		Map<QName, Serializable> props = new HashMap<QName, Serializable>();
		@SuppressWarnings("unchecked")
		Iterator<String> keysToCopyIterator = propValues.keys();
		while (keysToCopyIterator.hasNext()) {
			String propertyName = (String) keysToCopyIterator.next();
			try {
				if (propertyName.equalsIgnoreCase("usaareceiveddate") || propertyName.equalsIgnoreCase("expirationdate")
						|| propertyName.equalsIgnoreCase("Signeddate")) {
					props.put(QName.createQName(VCMModel.VCM_NAMESPACE_URI, propertyName),
							dateConverter(propValues.getString(propertyName)));
				} else if (propertyName.equalsIgnoreCase("esignrequired") || propertyName.equalsIgnoreCase("viewable")
						|| propertyName.equalsIgnoreCase("returnable")) {
					props.put(QName.createQName(VCMModel.VCM_NAMESPACE_URI, propertyName),
							Boolean.parseBoolean(propValues.getString(propertyName)));
				} else {
					props.put(QName.createQName(VCMModel.VCM_NAMESPACE_URI, propertyName),
							propValues.getString(propertyName));
				}
			} catch (NamespaceException | JSONException e) {
				logger.error("Error occured while reading json and puting them into map :" + e);
			}
		}
		return props;
	}

	private Date dateConverter(String inputDate) {
		Date date1 = null;
		Date finalDateTime = null;
		try {
			if (!(inputDate.isEmpty()) && inputDate != null) {
				SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
				date1 = format.parse(inputDate);
			}
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
			finalDateTime = dateFormat.parse(date1.toString());
			System.out.println("finalDateTime " + finalDateTime);
		} catch (ParseException e) {
			ExceptionUtils.printRootCauseStackTrace(e);
		}
		return finalDateTime;
	}
}
