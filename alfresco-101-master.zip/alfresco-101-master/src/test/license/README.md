# Enterprise License location

Put the Alfresco Enterprise license file in this directory.
It will then be copied into the Platform WAR in the  
WEB-INF/classes/alfresco/extension/license directory.

And then not be part of any other classpaths.
   
  
 
